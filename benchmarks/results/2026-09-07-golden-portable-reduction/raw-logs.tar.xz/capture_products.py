import argparse
import hashlib
import inspect
import json
from pathlib import Path
import subprocess
import sys
import zipfile

parser = argparse.ArgumentParser()
for name in ["repo", "wheel", "web", "output"]:
    parser.add_argument("--" + name, type=Path, required=True)
parser.add_argument("--compiled-source", required=True)
args = parser.parse_args()
import spiraltorch as st
import spiraltorch.spiraltorch as native

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*parts):
    return subprocess.check_output(["git", "-C", str(args.repo), *parts], text=True).strip()

assert not git("status", "--porcelain")
assert not git("diff", "--exit-code", args.compiled_source, "HEAD", "--", "crates", "bindings/st-py/src", "bindings/st-py/spiraltorch", "bindings/st-wasm/src")
assert inspect.isbuiltin(st.mean_tensors_scaled)
extension = Path(native.__file__).resolve()
assert extension.is_relative_to(Path(sys.prefix).resolve())
with zipfile.ZipFile(args.wheel) as archive:
    entries = [name for name in archive.namelist() if name.endswith("/" + extension.name)]
    assert len(entries) == 1
    assert hashlib.sha256(archive.read(entries[0])).hexdigest() == digest(extension)
report = {
    "schema": "spiraltorch.tensor_mean_products.v1", "status": "passed",
    "compiled_source": args.compiled_source, "snapshot_source": git("rev-parse", "HEAD"),
    "attribution": "clean source, unchanged library files, preserved build logs and byte-matched installed extension; not embedded Git attestation",
    "python": sys.executable, "extension": str(extension), "extension_sha256": digest(extension),
    "wheel_sha256": digest(args.wheel), "build_info": st.build_info(),
    "wasm_assets": {path.relative_to(args.web).as_posix(): digest(path) for path in sorted(args.web.rglob("*")) if path.is_file()},
}
with args.output.open("x") as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps({"status": report["status"], "compiled_source": args.compiled_source, "extension_sha256": report["extension_sha256"]}))
