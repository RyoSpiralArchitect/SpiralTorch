"""Replay numerical cross-client fixtures, timing groups, and preserved lint deltas."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import statistics as stats

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--root", type=Path, default=Path(__file__).parent)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
root = args.root

def read(name):
    return json.loads((root / name).read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def key(case):
    return (case["rows"], case["cols"], case["count"], case["seed"])

expected = {(r, c, n, s) for r, c in [(1, 1025), (32, 2048), (128, 2048)] for n in [4, 16, 64] for s in [17, 29, 43]}
baseline = read("native-tiled.json")
canonical = {key(case): case["checksum"] for case in baseline["cases"] if not case["mixed_col_major"]}
assert set(canonical) == expected

def validate(data, native=False):
    cases = data["cases"]
    assert data.get("status", "passed") == "passed"
    assert len(cases) == (54 if native else 27)
    assert {key(case) for case in cases} == expected
    if native:
        assert data["contract"] == "ordered-f64-mean-scaled.v1"
        assert {(key(c), c["mixed_col_major"]) for c in cases} == {(k, m) for k in expected for m in [False, True]}
    for case in cases:
        assert case["scale"] == 1.25 and case["checksum"] == canonical[key(case)]
        for name, samples in case.items():
            if name.endswith("_ms"):
                assert len(samples) == 16 and all(math.isfinite(x) and x >= 0 for x in samples)
                assert stats.mean(samples) > 0

def groups(cases, numerator, denominator):
    result = []
    for rows in [1, 32, 128]:
        for count in [4, 16, 64]:
            selected = [c for c in cases if c["rows"] == rows and c["count"] == count]
            assert len(selected) == 3
            ratios = [stats.mean(c[numerator]) / stats.mean(c[denominator]) for c in selected]
            result.append({"rows": rows, "count": count, "seeds": 3,
                           "median_ratio": stats.median(ratios), "min_ratio": min(ratios), "max_ratio": max(ratios)})
    return result

def native_summary(name):
    data = read(name)
    validate(data, native=True)
    return {str(mixed): groups([c for c in data["cases"] if c["mixed_col_major"] == mixed], "blocked_ms", "legacy_ms") for mixed in [False, True]}

native_names = ["native-initial.json", "native-initial-repeat.json", "native-fused.json", "native-vector.json", "native-vector-repeat.json", "native-tiled.json", "native-tiled-repeat.json", "native-tiled-confirm.json", "furnace/native-vector.json", "furnace/native-tiled.json", "furnace/native-tiled-repeat.json"]
native = {name: native_summary(name) for name in native_names}
browser = read("browser-portable-fixed.json")
validate(browser)
assert browser["execution"] == "wasm_cpu" and not browser["page_errors"]
assert browser["page_sha256"] == sha(root / "browser-fixture.html")
products = read("products.json")
assert browser["wasm_sha256"] == products["wasm_assets"]["spiraltorch_wasm_bg.wasm"]
for path, digest in products["wasm_assets"].items():
    if path.endswith((".wasm", ".js")):
        assert browser["asset_sha256"]["/module/" + path] == digest

python = read("python-torch-cpu.json")
validate(python)
torch_cpu = read("furnace/torch-cpu.json")
torch_cuda = read("furnace/torch-cuda.json")
for data in [torch_cpu, torch_cuda]:
    validate(data)
    assert data["native_results_sha256"] == sha(root / "furnace/native-vector.json")
assert torch_cuda["device"] == "cuda"
assert len(torch_cuda["gpu_availability"]) == 55
for point in torch_cuda["gpu_availability"]:
    assert all(pid == point["own_pid"] for pid in point["compute_pids"])

def signatures(name):
    return re.findall(r"^error: (.*)\n +--> ([^\n]+)", (root / name).read_text(), re.M)

lint = {}
for prefix, count in [("golden", 23), ("wasm", 19)]:
    current, old = signatures(prefix + "-clippy.log"), signatures(prefix + "-baseline-clippy.log")
    assert current == old and len(current) == count
    lint[prefix] = {"status": "preexisting_failure", "unchanged_diagnostics": count, "signatures": current}
assert "Finished" in (root / "tensor-clippy.log").read_text()
assert "error:" not in (root / "tensor-clippy.log").read_text()
assert not (root / "rustfmt.log").read_text().strip()
assert not (root / "rustfmt-final.log").read_text().strip()
assert "Finished" in (root / "tensor-clippy-final.log").read_text()
assert "error:" not in (root / "tensor-clippy-final.log").read_text()
for before, after in [("native-image-2928e357.sha256", "native-image-2928e357-after.sha256"), ("furnace-image-tiled.sha256", "furnace-image-tiled-after.sha256")]:
    assert (root / before).read_text().split()[0] == (root / after).read_text().split()[0]
for name, text in [("tensor-full-tests.log", "433 passed; 0 failed"), ("golden-final-tests.log", "17 passed; 0 failed"), ("python-final-tests.log", "19 passed"), ("tensor-ensemble-integration.log", "2 passed; 0 failed"), ("wasm-final-tests.log", "2 passed; 0 failed"), ("node-tests.log", "regressions passed")]:
    assert text in (root / name).read_text()

paired_furnace = []
cpu_by_key, cuda_by_key = [{key(c): c for c in d["cases"]} for d in [torch_cpu, torch_cuda]]
for case in read("furnace/native-tiled.json")["cases"]:
    if case["mixed_col_major"]:
        continue
    paired_furnace.append({**case, "torch_cpu_ms": cpu_by_key[key(case)]["torch_ms"], "torch_cuda_ms": cuda_by_key[key(case)]["torch_ms"]})

summary = {
    "schema": "spiraltorch.golden_portable_reduction_summary.v1",
    "compiled_source": products["compiled_source"], "products": products,
    "fixture": {"seeds": [17, 29, 43], "counts": [4, 16, 64], "shapes": [[1, 1025], [32, 2048], [128, 2048]], "scale": 1.25, "retained_samples": 16, "warmup": 3},
    "native_candidate_over_legacy": native,
    "browser_wasm_over_js": groups(browser["cases"], "wasm_ms", "javascript_ms"),
    "mac_python_spiraltorch_over_torch_cpu": groups(python["cases"], "spiraltorch_ms", "torch_ms"),
    "furnace_native_over_torch_cpu": groups(paired_furnace, "blocked_ms", "torch_cpu_ms"),
    "furnace_native_over_torch_cuda": groups(paired_furnace, "blocked_ms", "torch_cuda_ms"),
    "validation": {"tensor_tests": 433, "tensor_integration_tests": 2, "golden_tests": 17, "python_tests": 19, "wasm_native_tests": 2, "wasm_node_test": "passed", "browser_cases": 27, "furnace_torch_cpu_cases": 27, "furnace_torch_cuda_cases": 27, "gpu_availability_points": 55, "tensor_strict_clippy": "passed", "workspace_rustfmt": "passed", "preexisting_strict_clippy": lint},
    "boundaries": [
        "All reductions retain per-coordinate input-order f64 sums; no f32 reassociation or GPU fallback.",
        "Native legacy is the previous reduction body, not the entire Golden runtime or planner.",
        "CPU Torch uses one thread. Torch inputs are prevalidated outside timing; SpiralTorch validates every call.",
        "CUDA is PyTorch 2.13.0+cu132 on RTX 5090, not a new SpiralTorch CUDA implementation; host-clock plus synchronization, transfers excluded.",
        "Browser timings include fresh Float32Array output and run portable WASM CPU, not WebGPU or SIMD128.",
        "Furnace native and Torch runs are separate, same-host observations, not interleaved arms. GPU contention checks are point observations, not continuous monitoring.",
        "First native-initial run overlapped an unrelated Torch import; retain as exploratory only. Initial repeat and later confirmed timings are retained separately.",
        "Failed Chimera test used invalid 7x11 geometry, browser fixture had exponent syntax error, Python test used shape property instead of native method; all fixed, failure logs retained.",
        "Regenerating web glue from the same retained raw WASM changed adapter helper numbering and output hashes; no byte-reproducible build claim. Browser measurements bind the original frozen generated assets. Node is a separate generated product.",
        "No model-quality, training-speed, GPU-kernel, or general framework superiority claim.",
    ],
}
files = [p for p in root.rglob("*") if p.is_file() and p.suffix in {".log", ".json", ".txt", ".sha256", ".py", ".bundle", ".html", ".cjs"} and p.parent in [root, root / "furnace"] and p.name not in {"summary.json", args.output.name}]
summary["raw_sha256"] = {p.relative_to(root).as_posix(): sha(p) for p in sorted(files)}
with args.output.open("w") as stream:
    json.dump(summary, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write("\n")
print(json.dumps({"status": "passed", "compiled_source": summary["compiled_source"], "raw_files": len(files)}))
