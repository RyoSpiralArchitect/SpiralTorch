"""One fixed source-bound interval matrix; never restart or select by timing."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
BASE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/parameter-content-stamps-20260912/verified-a')
NEW = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-inline-guard-20260912/verified-a')
P = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
if sys.argv[1:] == ['--launch']:
    if (LOG/'receipt.json').exists():
        raise ValueError('existing run; inspect its process and evidence rather than retry')
    with (LOG/'run.log').open('xb') as out:
        child = subprocess.Popen([P, '-S', str(Path(__file__).resolve())], cwd=ROOT,
            stdin=subprocess.DEVNULL, stdout=out, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps(dict(pid=child.pid, log=str(LOG/'run.log')))); raise SystemExit(0)
if sys.argv[1:]:
    raise ValueError('--launch or no arguments')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_bytes())

git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
report = dict(status='running', pid=os.getpid(), steps=[],
    harness_source=dict(commit=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}')),
    harness_sha256=sha(Path(__file__)), started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    boundary='Four fixed same-page browser matrices; 256 separately completed reads per interval. No runtime edits, rebuild, retry, filtering, CUDA, parallel owned GPU work or exclusive-host claim. The old protocol regression run remains a separate endpoint.')
if git('status', '--porcelain'):
    raise ValueError('dirty harness source')
env = dict(os.environ, NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')

def save():
    temp = LOG/'receipt.json.tmp'
    temp.write_text(json.dumps(report, indent=2) + '\n'); temp.replace(LOG/'receipt.json')

def products():
    result = {}
    for version, base in [('baseline', BASE), ('candidate', NEW)]:
        receipt = read(base/'receipt.json')
        if receipt['status'] != 'passed': raise ValueError('unverified runtime')
        for name, value in receipt['products'].items():
            if sha(base/name) != value: raise ValueError('product drift: ' + name)
        result[version] = dict(source=receipt['source'], receipt_sha256=sha(base/'receipt.json'), products=receipt['products'])
    return result

def run(name, command):
    print('START', name, flush=True); start = time.monotonic()
    with (LOG/(name+'.log')).open('xb') as log:
        child = subprocess.Popen([str(v) for v in command], cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        report['active'] = dict(name=name, pid=child.pid, command=[str(v) for v in command]); save()
        try: code = child.wait(timeout=2100)
        except subprocess.TimeoutExpired:
            child.kill(); child.wait(); raise
    report.pop('active')
    report['steps'].append(dict(name=name, exit_code=code, seconds=time.monotonic()-start,
                              command=[str(v) for v in command])); save()
    print('END', name, code, flush=True)
    if code: raise RuntimeError(name)

start = time.monotonic()
try:
    save(); report['products'] = products(); save()
    run('interval-js-tests', ['node', '--test', 'tools/test_module_resident_intervals.mjs'])
    run('interval-admission-tests', [P, '-I', 'tools/test_module_interval_validation.py', '-v'])
    run('old-admission-tests', [P, '-I', 'tools/test_module_direct_io.py', '-v'])
    run('forward-admission-tests', [P, '-I', 'tests/test_graph_forward_paths.py', '-v'])
    run('driver-syntax', ['node', '--check', 'tools/test_resident_browser.cjs'])
    run('diff-check', ['git', 'diff', '--check'])
    run('old-browser', ['node', 'tools/test_resident_browser.cjs', NEW/'client', CHROME,
        LOG/'old-browser.json', '', '', '', '', 'nn-module-matched', BASE/'client'])
    run('old-validation', [P, '-I', 'tools/validate_module_direct_io.py',
        '--fixture', NEW/'native-forward-bench.json', '--baseline-python', NEW/'baseline-module-bench.json',
        '--candidate-python', NEW/'module-forward-bench.json', '--browser', LOG/'old-browser.json',
        '--baseline-receipt', BASE/'receipt.json', '--candidate-library', NEW/'python-release.dylib',
        '--candidate-wasm', NEW/'client/spiraltorch_wasm_bg.wasm', '--output', LOG/'old-validation.json'])
    run('interval-browser', ['node', 'tools/test_resident_browser.cjs', NEW/'client', CHROME,
        LOG/'interval-browser.json', '', '', '', '', 'nn-module-intervals', BASE/'client'])
    run('interval-validation', [P, '-I', 'tools/validate_module_resident_intervals.py',
        '--fixture', NEW/'native-forward-bench.json', '--browser', LOG/'interval-browser.json',
        '--baseline-receipt', BASE/'receipt.json', '--candidate-receipt', NEW/'receipt.json',
        '--output', LOG/'interval-validation.json'])
    if read(LOG/'interval-validation.json')['status'] != 'passed': raise ValueError('interval admission failed')
    if products() != report['products']: raise ValueError('products changed')
    if git('rev-parse', 'HEAD') != report['harness_source']['commit'] or git('status', '--porcelain'):
        raise ValueError('harness source changed')
    report['status'] = 'passed'
except BaseException as error:
    report.update(status='error', error=repr(error)); raise
finally:
    report['seconds'] = time.monotonic() - start
    report['artifacts'] = {p.name: sha(p) for p in LOG.iterdir()
        if p.is_file() and p.name not in ('receipt.json', 'receipt.json.tmp', 'run.log')}
    save()
