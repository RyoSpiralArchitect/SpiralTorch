"""Preserve every completed interval and bind it to the frozen runtime pair."""
import hashlib
import json
import lzma
from pathlib import Path
import subprocess

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
OUT = ROOT/'benchmarks/results/2026-09-12-module-completed-intervals'
BASE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/parameter-content-stamps-20260912/verified-a')
NEW = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-inline-guard-20260912/verified-a')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_bytes())

run, validation = read(LOG/'receipt.json'), read(LOG/'interval-validation.json')
if run['status'] != 'passed' or validation['status'] != 'passed' or len(run['steps']) != 10:
    raise ValueError('incomplete experiment')
if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() != run['harness_source']['commit']:
    raise ValueError('measurement source changed')
checked = 0
for version, base in [('baseline', BASE), ('candidate', NEW)]:
    receipt = read(base/'receipt.json')
    if sha((base/'receipt.json').read_bytes()) != run['products'][version]['receipt_sha256']:
        raise ValueError('receipt changed')
    for name, digest in receipt['products'].items():
        if sha((base/name).read_bytes()) != digest: raise ValueError('frozen product changed: '+name)
        checked += 1
for name, digest in run['artifacts'].items():
    if sha((LOG/name).read_bytes()) != digest: raise ValueError('run artifact changed: '+name)
if OUT.exists(): raise ValueError('archive exists; inspect rather than overwrite')
(OUT/'raw').mkdir(parents=True)
files = {'run/'+p.name: p for p in LOG.iterdir() if p.is_file()}
files.update({
    'inputs/baseline-receipt.json': BASE/'receipt.json',
    'inputs/candidate-receipt.json': NEW/'receipt.json',
    'inputs/native-fixture.json': NEW/'native-forward-bench.json',
    'inputs/earlier-python-baseline.json': NEW/'baseline-module-bench.json',
    'inputs/earlier-python-candidate.json': NEW/'module-forward-bench.json',
    'inputs/earlier-single-call-summary.json': ROOT/'benchmarks/results/2026-09-12-module-inline-guard/summary.json',
})
for name in [
    'bindings/st-wasm/tests/module_resident_intervals.html',
    'bindings/st-wasm/tests/module_resident_intervals.mjs',
    'bindings/st-wasm/tests/module_resident_matched.html',
    'tools/test_resident_browser.cjs', 'tools/validate_module_resident_intervals.py',
    'tools/test_module_interval_validation.py', 'tools/test_module_resident_intervals.mjs',
    'tools/bench_graph_forward_paths.py', 'tools/validate_module_direct_io.py',
    'tools/validate_module_forward_paths.py', 'tools/test_module_direct_io.py',
    'tests/test_graph_forward_paths.py',
]:
    files['source/'+name] = ROOT/name
entries = []
for name, path in sorted(files.items()):
    data = path.read_bytes(); compressed = lzma.compress(data)
    archived = OUT/'raw'/Path(name + '.xz')
    archived.parent.mkdir(parents=True, exist_ok=True); archived.write_bytes(compressed)
    if lzma.decompress(archived.read_bytes()) != data: raise ValueError('archive roundtrip failed')
    entries.append(dict(archive=str(archived.relative_to(OUT)), origin=str(path), bytes=len(data),
        sha256=sha(data), compressed_bytes=len(compressed), compressed_sha256=sha(compressed)))
manifest = dict(schema='spiraltorch.source_archive.v1', status='passed', records=entries,
    raw_bytes=sum(row['bytes'] for row in entries), compressed_bytes=sum(row['compressed_bytes'] for row in entries))
(OUT/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
browser = read(LOG/'interval-browser.json')
summary = dict(schema='spiraltorch.module_completed_intervals_record.v1', status='passed',
    harness_source=run['harness_source'], baseline_source=validation['baseline_source'],
    candidate_source=validation['candidate_source'], runtime_changed=False,
    protocol=validation['protocol'], aggregates=validation['aggregates'],
    checked_forwards_including_warmup=validation['checked_forwards_including_warmup'],
    checked_values_including_warmup=validation['checked_values_including_warmup'],
    max_abs_error=validation['max_abs_error'], minimum_interval_ms=validation['minimum_interval_ms'],
    clock_minimum_positive_delta_ms=validation['clock_minimum_positive_delta_ms'],
    minimum_interval_over_observed_clock_delta=validation['minimum_interval_over_observed_clock_delta'],
    browser_version=browser['browser_version'], cross_origin_isolated=browser['cross_origin_isolated'],
    adapters=browser['cases'][0]['adapters'], validation_steps=len(run['steps']),
    verification_seconds=run['seconds'], frozen_products_checked=checked,
    raw_records=len(entries), manifest_sha256=sha((OUT/'manifest.json').read_bytes()),
    validation_sha256=sha((LOG/'interval-validation.json').read_bytes()),
    decision='Keep in-pass guard grouping: this sustained completed-read browser workload has no material consistent speed change; no browser speedup or universal regression-free claim. Earlier isolated-call results remain separate evidence. No platform-specific fallback selected.',
    next_candidate='ResidentTensor::snapshot still allocates an unpooled readback buffer, whereas graph snapshots reuse a bounded pool. This is an implementation difference, not yet a measured bottleneck or a demonstrated optimization.',
    boundary=validation['boundary'])
(OUT/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(dict(status='passed', records=len(entries), raw_bytes=manifest['raw_bytes'],
    compressed_bytes=manifest['compressed_bytes'], frozen_products_checked=checked)))
