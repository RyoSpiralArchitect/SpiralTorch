"""Archive bounded client correctness evidence without publishing native binaries."""
import hashlib
import json
import lzma
from pathlib import Path
import subprocess

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
FINAL = LOG / 'final'
DEST = ROOT / 'benchmarks/results/2026-09-10-resident-graph-forward-clients'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return json.loads((FINAL / name).read_bytes())


receipt = read('receipt.json')
assert receipt['status'] == 'passed'
assert len(receipt['steps']) == 20
assert all(step['exit_code'] == 0 for step in receipt['steps'])
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == receipt['base']
for name, expected in receipt['source_files'].items():
    assert digest((ROOT / name).read_bytes()) == expected, name
for name, expected in receipt['products'].items():
    assert digest((FINAL / name).read_bytes()) == expected, name

gpu, cpu, python, browser, torch = [read(name) for name in
    ('python-gpu-tests.json', 'python-cpu-tests.json', 'python.json', 'browser.json', 'torch.json')]
assert all(result['status'] == 'passed' for result in (gpu, cpu, python, browser, torch))
assert (gpu['tests'], gpu['skipped'], gpu['wgpu_available']) == (30, 0, True)
assert (cpu['tests'], cpu['skipped'], cpu['wgpu_available']) == (30, 19, False)
assert len(python['cases']) == len(browser['cases']) == 12
assert browser['assertions'] == 536 and browser['page_errors'] == []
assert '111 passed; 0 failed; 0 ignored' in (FINAL / 'backend-serial.log').read_text()
assert len(torch['cases']) == 72
comparisons = sum(case['comparisons'] for case in torch['cases'])
maximum = max(case['max_abs_error'] for case in torch['cases'])
assert comparisons == 432 and maximum == 1.1920928955078125e-7
assert sorted({case['device'] for case in torch['cases']}) == ['cpu', 'mps']
for source in torch['sources']:
    assert digest(Path(source['path']).read_bytes()) == source['sha256']
assert python['source_fixture_sha256'] == browser['source_fixture_sha256'] == receipt['fixture_sha256']
assert browser['asset_sha256']['/fixture.json'] == receipt['fixture_sha256']
assert browser['wasm_sha256'] == receipt['products']['webgpu/spiraltorch_wasm_bg.wasm']
assert browser['page_sha256'] == receipt['source_files']['bindings/st-wasm/tests/resident_graph_forward_clients.html']

raw_dir = DEST / 'raw'
raw_dir.mkdir(parents=True)
artifacts = sorted(path for path in FINAL.iterdir() if path.suffix in ('.json', '.log'))
artifacts += sorted(path for path in LOG.iterdir() if path.suffix in ('.json', '.log'))
artifacts += [LOG / name for name in ('python-client.py', 'verify-clients.py', 'pack-evidence.py')]
artifacts += sorted(FINAL.glob('*/*.d.ts'))
entries = []
for path in artifacts:
    name = str(path.relative_to(LOG))
    raw = path.read_bytes()
    packed = lzma.compress(raw, preset=6)
    target = raw_dir / (name + '.xz')
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as output:
        output.write(packed)
    assert lzma.decompress(packed) == raw
    entries.append(dict(path=str(target.relative_to(DEST)), original_name=name,
                        bytes=len(raw), sha256=digest(raw), compressed_sha256=digest(packed)))

summary = dict(
    schema='spiraltorch.resident_graph_forward_clients.evidence.v1',
    status='bounded_correctness_passed',
    source=dict(base=receipt['base'], form='working-tree patch bound by source-file SHA-256',
                files=receipt['source_files']),
    native=dict(adapter=python['adapter'], build_info=gpu['build_info'], tests=30, skipped=0, recipes=12),
    cpu_python=dict(build_info=cpu['build_info'], discovered_tests=30, executed_tests=11,
                    gpu_only_skips=19, gpu_available=False),
    browser=dict(version=browser['browser_version'], adapter=browser['adapter'],
                 physical_gpu_identity='UNKNOWN', production_package=True, recipes=12,
                 assertions=536, page_errors=browser['page_errors'], asset_sha256=browser['asset_sha256']),
    torch=dict(version=torch['torch'], devices=['cpu', 'mps'], mps_fallback='disabled',
               frozen_core_replays=24, python_replays=24, wasm_replays=24,
               total_replays=72, tensor_comparisons=comparisons, max_abs_error=maximum,
               sources=torch['sources']),
    serial_backend=dict(tests=111, failed=0, ignored=0, runtime_opt_in=True),
    admission_only_tests=dict(forward=6, existing_clients=5),
    final_check_count=len(receipt['steps']),
    products=receipt['products'],
    fixture_sha256=receipt['fixture_sha256'],
    initial_evidence='Preserved separately; only final/ is bound to all current source hashes.',
    unresolved_parallel_failure=dict(
        status='UNKNOWN',
        evidence='../2026-09-10-resident-graph-forward/README.md',
        note='Earlier default-parallel backend suite failed once; not claimed fixed or pre-existing. This run is serial.'),
    boundaries=[
        'Correctness, ownership and CPU feature boundaries only; no throughput or model-quality claim.',
        'Python debug/native Metal, production WASM release/BrowserWebGpu, Torch eager CPU/MPS.',
        'The frozen Rust fixture is reused, not a fresh third-client execution in this run.',
        'Compiled internal graph edges share buffers; graph admission and output capture use GPU-only copies.',
        'No automatic Module::forward, pure::Tensor, autograd or ModuleTrainer rerouting.',
        'No CUDA execution, PyPI publication, push or merge in this validation.',
    ],
)
for name, data in (('manifest.json', dict(schema='spiraltorch.hash_archive.v1', entries=entries)),
                   ('summary.json', summary)):
    with (DEST / name).open('x') as output:
        json.dump(data, output, indent=2, allow_nan=False)
        output.write('\n')
print(json.dumps(dict(artifacts=len(entries), compressed_bytes=sum((DEST / e['path']).stat().st_size for e in entries),
                      comparisons=comparisons, max_abs_error=maximum, source_files=len(receipt['source_files']))))
