"""Serial native/CPU/browser validation with frozen products and source hashes."""
import ast
import hashlib
import json
import lzma
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

W=Path('/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-resident-graph-forward-v1')
T=Path('/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-spiralk-golden-blackcat-contract-v1/target')
L=Path(__file__).parent/sys.argv[1]
L.mkdir()
P='/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
BINDGEN='/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen'
CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_TARGET_DIR=str(T),PYO3_PYTHON=P,
         SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1',PYTORCH_ENABLE_MPS_FALLBACK='0',
         NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
files=subprocess.check_output(['git','ls-files','-mo','--exclude-standard'],cwd=W,text=True).splitlines()
report=dict(schema='spiraltorch.forward_clients.validation.v1',status='error',base=source,steps=[],products={},
            source_files={name:hashlib.sha256((W/name).read_bytes()).hexdigest() for name in files})
fixture_path=W/'benchmarks/results/2026-09-10-resident-graph-forward/raw/native-final.json.xz'
fixture=lzma.decompress(fixture_path.read_bytes())
manifest=json.loads((fixture_path.parents[1]/'manifest.json').read_text())
expected=next(e['sha256'] for e in manifest['entries'] if e['original_name']=='native-final.json')
assert hashlib.sha256(fixture).hexdigest()==expected
(L/'core-fixture.json').write_bytes(fixture)
report['fixture_sha256']=expected


def run(name,args,overrides=None):
    print('START',name,flush=True)
    start=time.monotonic()
    with (L/(name+'.log')).open('xb') as log:
        p=subprocess.run(args,cwd=W,env=dict(env,**(overrides or {})),stdout=log,stderr=subprocess.STDOUT)
    report['steps'].append(dict(name=name,command=args,exit_code=p.returncode,seconds=time.monotonic()-start))
    (L/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print('END',name,p.returncode,flush=True)
    if p.returncode: raise RuntimeError(name)


def register(path):
    path.chmod(0o444)
    report['products'][str(path.relative_to(L))]=hashlib.sha256(path.read_bytes()).hexdigest()


def py(library,mode,*args):
    return [P,'-I',str(Path(__file__).with_name('python-client.py')),str(library),str(W),mode,*map(str,args)]


try:
    run('fmt',['cargo','+nightly-2026-04-15','fmt','--all','--','--check'])
    run('admission',[P,'-I','tests/test_resident_graph_forward_validation.py'])
    run('legacy-admission',[P,'-I','tests/test_resident_graph_client_validation.py'])
    ast.parse((W/'bindings/st-py/spiraltorch/__init__.pyi').read_text())
    run('wgpu-only-check',['cargo','+1.98.0','check','--locked','-p','spiraltorch-py','--no-default-features',
                           '--features','extension-module,wgpu'])
    run('python-gpu-build',['cargo','+1.98.0','build','--locked','-p','spiraltorch-py'])
    shutil.copyfile(T/'debug/libspiraltorch.dylib',L/'python-wgpu.dylib');register(L/'python-wgpu.dylib')
    run('python-gpu-tests',py(L/'python-wgpu.dylib','tests',L/'python-gpu-tests.json'))
    run('python-capture',py(L/'python-wgpu.dylib','bindings/st-py/examples/resident_graph_forward.py',
        '--fixture',L/'core-fixture.json','--output',L/'python.json'))
    for name,feature,target in [('webgpu','webgpu','web'),('cpu','nn','nodejs')]:
        run(name+'-wasm-build',['cargo','+1.98.0','build','--locked','--release','-p','spiraltorch-wasm',
            '--target','wasm32-unknown-unknown','--no-default-features','--features',feature])
        run(name+'-bindgen',[BINDGEN,str(T/'wasm32-unknown-unknown/release/spiraltorch_wasm.wasm'),
            '--target',target,'--out-dir',str(L/name),'--out-name','spiraltorch_wasm'])
        for path in (L/name).rglob('*'):
            if path.is_file(): register(path)
    shutil.copyfile(L/'core-fixture.json',L/'webgpu/forward-fixture.json')
    run('types',['node','bindings/st-wasm/tests/resident_types.cjs',str(L/'webgpu/spiraltorch_wasm.js')])
    run('cpu-wasm-transport',['node','bindings/st-wasm/tests/nn_plan.cjs',str(L/'cpu/spiraltorch_wasm.js')])
    run('cpu-wasm-tensor-absence',['node','-e',
        'const assert=require("node:assert/strict"), st=require(process.argv[1]); for(const name of ["WgpuTensor","WgpuTensorDevice","WgpuTensorSnapshot"]) assert.equal(st[name],undefined); console.log("CPU-only WASM has no GPU tensor constructors");',
        str(L/'cpu/spiraltorch_wasm.js')])
    run('browser',['node','tools/test_resident_browser.cjs',str(L/'webgpu'),CHROME,str(L/'browser.json'),'', '', '', '', 'nn-forward-clients'])
    run('torch',[TORCH,'-I','tools/verify_resident_graph_forward_torch.py',str(L/'core-fixture.json'),
        str(L/'python.json'),str(L/'browser.json'),'--output',str(L/'torch.json')])
    run('python-cpu-build',['cargo','+1.98.0','build','--locked','-p','spiraltorch-py',
        '--no-default-features','--features','python-default,cpu'])
    shutil.copyfile(T/'debug/libspiraltorch.dylib',L/'python-cpu.dylib');register(L/'python-cpu.dylib')
    run('python-cpu-tests',py(L/'python-cpu.dylib','tests',L/'python-cpu-tests.json'),{'SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS':'0'})
    run('backend-serial',['cargo','+1.98.0','test','--locked','--release','-p','st-backend-wgpu','--lib','--','--test-threads=1'])
    run('diff-check',['git','diff','--check'])
    gpu,cpu=[json.loads((L/name).read_text()) for name in ('python-gpu-tests.json','python-cpu-tests.json')]
    if gpu['tests']!=30 or gpu['skipped']!=0 or not gpu['wgpu_available']: raise RuntimeError('GPU coverage drift')
    if cpu['tests']!=30 or cpu['skipped']!=19 or cpu['wgpu_available']: raise RuntimeError('CPU coverage drift')
    for name,expected in report['source_files'].items():
        if hashlib.sha256((W/name).read_bytes()).hexdigest()!=expected: raise RuntimeError('source changed during checks: '+name)
    if subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()!=source: raise RuntimeError('HEAD changed')
    for name,expected in report['products'].items():
        if hashlib.sha256((L/name).read_bytes()).hexdigest()!=expected: raise RuntimeError('product changed')
    report['status']='passed'
except Exception as error:
    report['error']=repr(error)
    raise
finally:
    (L/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
