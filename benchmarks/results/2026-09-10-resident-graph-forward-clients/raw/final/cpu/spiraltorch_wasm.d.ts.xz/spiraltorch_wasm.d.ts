/* tslint:disable */
/* eslint-disable */
export function fractalFieldProbeObject(octaves: number, lacunarity: number, gain: number, iterations: number, log_start: number, log_step: number, len: number, preview_len: number): any;
export function fractalFieldProbeJson(octaves: number, lacunarity: number, gain: number, iterations: number, log_start: number, log_step: number, len: number, preview_len: number): string;
export function trainerExternalStateCheckpointJson(checkpoint_json: string): string;
export function trainerExternalStateCheckpointObject(checkpoint: any): any;
export function zspaceStochasticSchrodingerForwardJson(request_json: string): string;
export function validateZspaceStochasticSchrodingerForwardJson(receipt_json: string): string;
export function zspaceStochasticSchrodingerVjpJson(request_json: string): string;
export function validateZspaceStochasticSchrodingerVjpJson(receipt_json: string): string;
/**
 * Returns the native semantic contract version exposed by the browser client.
 */
export function autogradContractVersion(): string;
/**
 * Returns the crate that owns reverse-mode semantics.
 */
export function autogradSemanticOwner(): string;
export function trainerOptimizerConfigJson(config_json: string): string;
export function trainerOptimizerConfigObject(config: any): any;
export function trainerOptimizerCheckpointJson(checkpoint_json: string): string;
export function trainerOptimizerCheckpointObject(checkpoint: any): any;
export function zspaceStochasticSchrodingerComplexStepJson(request_json: string): string;
export function validateZspaceStochasticSchrodingerComplexJson(receipt_json: string): string;
export function zspaceCoherenceProjectJson(request_json: string): string;
export function zspaceCoherenceProjectObject(request: any): any;
export function zspaceCoherenceDistributionWitnessJson(normalized_weights_json: string): string;
export function zspaceCoherenceDistributionWitnessObject(normalized_weights: any): any;
export function zspaceCoherenceDistributionValidateJson(witness_json: string): string;
export function zspaceCoherenceDistributionValidateObject(witness: any): any;
export function trainerRuntimeCheckpointBundleJson(bundle_json: string): string;
export function trainerRuntimeCheckpointBundleObject(bundle: any): any;
export function zspaceGenerationEvidenceJson(request_json: string): string;
export function zspaceGenerationEvidenceObject(request: any): any;
export function validateZspaceGenerationEvidenceJson(report_json: string): string;
export function validateZspaceGenerationEvidenceObject(report: any): any;
export function runtimeDeviceRouteJson(request_json: string): string;
export function runtimeDeviceRouteObject(request: any): any;
export function runtimeDeviceRouteFromProbesJson(request_json: string): string;
export function runtimeDeviceRouteFromProbesObject(request: any): any;
export function runtimeDeviceRouteValidateJson(payload_json: string): string;
export function runtimeDeviceRouteValidateObject(payload: any): any;
export function runtimeDeviceRouteValidateAgainstJson(payload_json: string, request_json: string): string;
export function runtimeDeviceRouteValidateAgainstObject(payload: any, request: any): any;
export function zspaceFreeEnergyJson(request_json: string): string;
export function zspaceFreeEnergyObject(request: any): any;
export function toposRoutePolicyEvaluateJson(request_json: string): string;
export function toposRoutePolicyEvaluateObject(request: any): any;
export function toposRoutePolicyRewardsJson(request_json: string): string;
export function toposRoutePolicyRewardsObject(request: any): any;
export function toposRoutePolicyResolveJson(request_json: string): string;
export function toposRoutePolicyResolveObject(request: any): any;
export function zspaceTelemetryFusionJson(payloads_json: string): string;
export function zspaceTelemetryFusionObject(payloads: any): any;
export function zspacePartialFusionJson(request_json: string): string;
export function zspacePartialFusionObject(request: any): any;
export function zspaceMetricGradientProjectionJson(request_json: string): string;
export function zspaceMetricGradientProjectionObject(request: any): any;
export function zspaceMetaOptimizerInitJson(config_json: string): string;
export function zspaceOptimizerFeedbackInitObject(config: any): any;
export function zspaceOptimizerFeedbackRestoreJson(request_json: string): string;
export function zspaceOptimizerFeedbackRestoreObject(request: any): any;
export function zspaceOptimizerFeedbackObserveJson(request_json: string): string;
export function zspaceOptimizerFeedbackObserveObject(request: any): any;
export function zspaceOptimizerFeedbackControlJson(request_json: string): string;
export function zspaceOptimizerFeedbackControlObject(request: any): any;
export function zspaceMetaOptimizerInitObject(config: any): any;
export function zspaceMetaOptimizerRestoreJson(request_json: string): string;
export function zspaceMetaOptimizerRestoreObject(request: any): any;
export function zspaceParameterTrajectoryPolicyJson(source_report_json: string, policy: string): string;
export function zspaceParameterTrajectoryPolicyObject(source_report: any, policy: string): any;
export function zspaceParameterTrajectoryPolicyValidateJson(report_json: string): string;
export function zspaceParameterTrajectoryPolicyValidateObject(report: any): any;
export function zspacePolarityEvidenceJson(request_json: string): string;
export function zspacePolarityEvidenceObject(request: any): any;
export function zspacePolarityEvidenceValidateJson(report_json: string): string;
export function zspacePolarityEvidenceValidateObject(report: any): any;
export function zspaceOptimizerFeedbackInitJson(config_json: string): string;
export function zspaceMetaOptimizerStepJson(request_json: string): string;
export function zspaceMetaOptimizerStepObject(request: any): any;
export function zspaceMetaOptimizerParameterControlJson(report_json: string): string;
export function zspaceMetaOptimizerParameterControlObject(report: any): any;
export function zspaceParameterTrajectoryJson(request_json: string): string;
export function zspaceParameterTrajectoryObject(request: any): any;
export function zspaceParameterTrajectoryValidateJson(report_json: string): string;
export function zspaceParameterTrajectoryValidateObject(report: any): any;
export function zspacePosteriorDecodeJson(request_json: string): string;
export function zspacePosteriorDecodeObject(request: any): any;
export function zspacePosteriorProjectJson(request_json: string): string;
export function zspacePosteriorProjectObject(request: any): any;
export function zspaceConceptDiffusionJson(request_json: string): string;
export function zspaceConceptDiffusionObject(request: any): any;
export function zspaceGenerationControlJson(request_json: string): string;
export function zspaceGenerationControlObject(request: any): any;
export function zspaceTemperatureControlJson(request_json: string): string;
export function zspaceTemperatureControlObject(request: any): any;
export function trainingTelemetryProjectionJson(request_json: string): string;
export function trainingTelemetryProjectionObject(request: any): any;
export function zspaceImaginaryTimeSchrodingerJson(request_json: string): string;
export function zspaceImaginaryTimeSchrodingerObject(request: any): any;
export function toposControlSignalJson(input_json: string): string;
export function toposControlSignalObject(input: any): any;
export function toposOptimizerSnapshotJson(input_json: string): string;
export function toposOptimizerSnapshotObject(input: any): any;
export function toposZSpaceProjectionJson(input_json: string, gradient_dim: number): string;
export function toposZSpaceProjectionObject(input: any, gradient_dim: number): any;
export function apiLlmRoutePolicyEvaluateJson(request_json: string): string;
export function apiLlmRoutePolicyEvaluateObject(request: any): any;
export function zspaceRuntimeProtocolCatalogJson(): string;
export function zspaceRuntimeProtocolCatalogObject(): any;
export function validateZspaceRuntimeProtocolCatalogJson(catalog_json: string): string;
export function zspacePeriodicityJson(request_json: string): string;
export function zspacePeriodicityObject(request: any): any;
export function validateZspacePeriodicityJson(report_json: string): string;
export function validateZspacePeriodicityObject(report: any): any;
export function runtimeExecutionPlanJson(request_json: string): string;
export function runtimeExecutionPlanObject(request: any): any;
export function runtimeExecutionPlanObserveCapabilitiesJson(request_json: string): string;
export function runtimeExecutionPlanObserveCapabilitiesObject(request: any): any;
export function runtimeExecutionPlanValidateJson(payload_json: string): string;
export function runtimeExecutionPlanValidateObject(payload: any): any;
export function runtimeExecutionPlanValidateAgainstJson(payload_json: string, request_json: string): string;
export function runtimeExecutionPlanValidateAgainstObject(payload: any, request: any): any;
export function tensorExecutionReceiptValidateJson(receipt_json: string): string;
export function tensorExecutionReceiptValidateObject(receipt: any): any;
export function tensorExecutionReceiptValidateAgainstRuntimePlanJson(receipt_json: string, runtime_plan_json: string): string;
export function tensorExecutionReceiptValidateAgainstRuntimePlanObject(receipt: any, runtime_plan: any): any;
export function scalarScaleStackProbeObject(field: Float32Array, shape: Uint32Array, scales: Float32Array, threshold: number, ambient_dim: number, dimension_window: number, levels: Float32Array): any;
export function scalarScaleStackProbeJson(field: Float32Array, shape: Uint32Array, scales: Float32Array, threshold: number, ambient_dim: number, dimension_window: number, levels: Float32Array): string;
export function semanticScaleStackProbeObject(embeddings: Float32Array, rows: number, dims: number, scales: Float32Array, threshold: number, metric: string, ambient_dim: number, dimension_window: number, levels: Float32Array): any;
export function semanticScaleStackProbeJson(embeddings: Float32Array, rows: number, dims: number, scales: Float32Array, threshold: number, metric: string, ambient_dim: number, dimension_window: number, levels: Float32Array): string;
export function sealZspaceSemanticReviewPacketJson(request_json: string): string;
export function sealZspaceSemanticReviewPacketObject(request: any): any;
export function zspaceSemanticReviewMapIdJson(request_json: string): string;
export function zspaceSemanticReviewMapIdObject(request: any): string;
export function unblindZspaceSemanticReviewJson(request_json: string): string;
export function unblindZspaceSemanticReviewObject(request: any): any;
export function validateZspaceSemanticReviewUnblindJson(report_json: string): string;
export function validateZspaceSemanticReviewUnblindObject(report: any): any;
export function validateZspaceSemanticReviewPacketJson(packet_json: string): string;
export function validateZspaceSemanticReviewPacketObject(packet: any): any;
export function validateZspaceSemanticReviewPacketReceiptJson(receipt_json: string): string;
export function validateZspaceSemanticReviewPacketReceiptObject(receipt: any): any;
export function summarizeZspaceSemanticReviewDraftJson(request_json: string): string;
export function summarizeZspaceSemanticReviewDraftObject(request: any): any;
export function validateZspaceSemanticReviewDraftReceiptJson(receipt_json: string): string;
export function validateZspaceSemanticReviewDraftReceiptObject(receipt: any): any;
export function zspaceRepetitionUnlikelihoodPlanJson(request_json: string): string;
export function zspaceRepetitionUnlikelihoodPlanObject(request: any): any;
export function validateZspaceRepetitionUnlikelihoodPlanJson(plan_json: string): string;
export function validateZspaceRepetitionUnlikelihoodPlanObject(plan: any): any;
export function auditWasmReportJson(report_json: string): string;
export function auditWasmReportObject(report: any): any;
export function compareWasmReportsJson(reports_json: string): string;
export function compareWasmReportsObject(reports: any): any;
export function auto_plan_fft(rows: number, cols: number, k: number, subgroup: boolean): WasmFftPlan | undefined;
export function auto_fft_wgsl(rows: number, cols: number, k: number, subgroup: boolean): string | undefined;
export function auto_fft_spiralk(rows: number, cols: number, k: number, subgroup: boolean): string | undefined;
export function auto_fft_plan_json(rows: number, cols: number, k: number, subgroup: boolean): string | undefined;
export function auto_fft_plan_object(rows: number, cols: number, k: number, subgroup: boolean): any;
export function fft_forward(buffer: Float32Array): Float32Array;
export function fft_inverse(buffer: Float32Array): Float32Array;
export function fft_forward_in_place(buffer: Float32Array): void;
export function fft_inverse_in_place(buffer: Float32Array): void;
/**
 * Compute the baseline WGPU choice without consulting an override table.
 */
export function baseChoice(rows: number, cols: number, k: number, subgroup: boolean): any;
export function available_palettes(): Array<any>;
export function mellin_exp_decay_samples(log_start: number, log_step: number, len: number): Float32Array;
export function mellin_exp_decay_samples_scaled(log_start: number, log_step: number, len: number, rate: number): Float32Array;
export function toposRuntimeRouteJson(profile_json: string): string;
export function toposRuntimeRouteObject(profile: any): any;
export function runtimeDeviceProbeJson(request_json: string): string;
export function runtimeDeviceProbeObject(request: any): any;
export function runtimeDeviceProbeObserveJson(request_json: string): string;
export function runtimeDeviceProbeObserveObject(request: any): any;
export function runtimeDeviceProbeValidateJson(payload_json: string): string;
export function runtimeDeviceProbeValidateObject(payload: any): any;
export function runtimeDeviceProbeValidateAgainstJson(payload_json: string, request_json: string): string;
export function runtimeDeviceProbeValidateAgainstObject(payload: any, request: any): any;
export function logZSeriesProbeObject(log_start: number, log_step: number, samples: Float32Array, window: string, normalisation: string, z_values: Float32Array, preview_len: number): any;
export function logZSeriesProbeJson(log_start: number, log_step: number, samples: Float32Array, window: string, normalisation: string, z_values: Float32Array, preview_len: number): string;
export function rankPlanJson(request_json: string): string;
export function rankPlanObject(request: any): any;
export enum WasmFftPlanSource {
  Override = 0,
  Heuristic = 1,
  Fallback = 2,
}
/**
 * Frozen RHS whose source graph and packed storage are both owned by Rust.
 */
export class AutogradPackedRhs {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  requiresGrad(): boolean;
  cols(): number;
  rows(): number;
  sourceId(): string;
}
/**
 * Plain CPU SGD with fresh immutable parameter handles after every step.
 */
export class AutogradSgd {
  free(): void;
  [Symbol.dispose](): void;
  addParameter(parameter: AutogradTensor): number;
  learningRate(): number;
  parameterCount(): number;
  setLearningRate(learning_rate: number): void;
  constructor(learning_rate: number);
  step(): void;
  parameter(index: number): AutogradTensor;
  zeroGrad(): void;
}
/**
 * Browser handle over the same immutable graph used by native Rust and Python.
 */
export class AutogradTensor {
  free(): void;
  [Symbol.dispose](): void;
  gatherRows(indices: any): AutogradTensor;
  prepackRhs(): AutogradPackedRhs;
  rowSoftmax(): AutogradTensor;
  hasGradient(): boolean;
  graphSummary(): any;
  requiresGrad(): boolean;
  operationName(): string;
  gradientValues(): Float32Array;
  rowLogSoftmax(): AutogradTensor;
  zeroGradGraph(): void;
  matmulPrepacked(rhs: AutogradPackedRhs): AutogradTensor;
  scatterAddRows(indices: any, output_rows: number): AutogradTensor;
  /**
   * Affine row LayerNorm; omitted epsilon defaults to 1e-5.
   */
  layerNormAffine(gamma: AutogradTensor, beta: AutogradTensor, epsilon?: number | null): AutogradTensor;
  backwardWithGrad(values: Float32Array): any;
  meanSquaredError(target: AutogradTensor): AutogradTensor;
  vectorJacobianProduct(input: AutogradTensor, values: Float32Array): Float32Array;
  /**
   * Integer-label logits loss. Optional arguments default to mean, -100 and zero smoothing.
   */
  crossEntropyWithLogits(labels: Int32Array, reduction?: string | null, ignore_index?: number | null, label_smoothing?: number | null): AutogradTensor;
  add(rhs: AutogradTensor): AutogradTensor;
  dot(rhs: AutogradTensor): AutogradTensor;
  constructor(rows: number, cols: number, values: Float32Array, requires_grad: boolean);
  sub(rhs: AutogradTensor): AutogradTensor;
  sum(): AutogradTensor;
  cols(): number;
  gelu(): AutogradTensor;
  item(): number;
  mean(): AutogradTensor;
  relu(): AutogradTensor;
  rows(): number;
  scale(factor: number): AutogradTensor;
  detach(): AutogradTensor;
  matmul(rhs: AutogradTensor): AutogradTensor;
  values(): Float32Array;
  addRow(bias: AutogradTensor): AutogradTensor;
  backward(): any;
  hadamard(rhs: AutogradTensor): AutogradTensor;
  id(): string;
  transpose(): AutogradTensor;
  zeroGrad(): void;
}
export class CanvasDesireControl {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  eventsMask(): number;
  eventLabels(): Array<any>;
  readonly clipFloor: number;
  readonly tuningGain: number;
  readonly clipCeiling: number;
  readonly operatorMix: number;
  readonly penaltyGain: number;
  readonly qualityBias: number;
  readonly qualityGain: number;
  readonly operatorGain: number;
  readonly targetEntropy: number;
  readonly observationGain: number;
  readonly temperatureSlew: number;
  readonly learningRateEta: number;
  readonly learningRateMax: number;
  readonly learningRateMin: number;
  readonly temperatureKappa: number;
  readonly learningRateSlew: number;
  readonly realLearningRateScale: number;
  readonly hyperLearningRateScale: number;
  readonly damping: number;
  readonly biasMix: number;
  readonly clipEma: number;
  readonly clipNorm: number;
}
export class CanvasDesireInterpretation {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly saturation: number;
  readonly penaltyGain: number;
  readonly realPressure: number;
  readonly hyperPressure: number;
  readonly observationGain: number;
  readonly balance: number;
  readonly biasMix: number;
  readonly stability: number;
}
export class CanvasFftLayout {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Total byte length required for the `FieldSample` storage buffer.
   */
  readonly fieldBytes: number;
  /**
   * Size in bytes of each vector field sample.
   */
  readonly fieldStride: number;
  /**
   * Byte length of the `CanvasFftParams` uniform buffer.
   */
  readonly uniformBytes: number;
  /**
   * Total byte length required for the FFT spectrum storage buffer.
   */
  readonly spectrumBytes: number;
  /**
   * Size in bytes of each FFT spectrum sample.
   */
  readonly spectrumStride: number;
}
export class CanvasFramePacket {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly saturation: number;
  readonly eventsMask: number;
  readonly operatorMix: number;
  readonly realgradRms: number;
  readonly hypergradRms: number;
  readonly operatorGain: number;
  readonly realgradCount: number;
  readonly hypergradCount: number;
  readonly realLearningRateScale: number;
  readonly hyperLearningRateScale: number;
  readonly field: Float32Array;
  readonly trail: Float32Array;
  readonly width: number;
  readonly height: number;
  readonly pixels: Uint8Array;
  readonly balance: number;
  readonly relation: Float32Array;
  readonly stability: number;
}
export class CanvasGradientSummary {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly realgradL1: number;
  readonly realgradL2: number;
  readonly hypergradL1: number;
  readonly hypergradL2: number;
  readonly realgradRms: number;
  readonly hypergradRms: number;
  readonly realgradLInf: number;
  readonly hypergradLInf: number;
  readonly realgradCount: number;
  readonly hypergradCount: number;
  readonly realgradMeanAbs: number;
  readonly hypergradMeanAbs: number;
}
export class CobolDispatchPlanner {
  free(): void;
  [Symbol.dispose](): void;
  cicsRoute(): any;
  clearRoute(): void;
  static fromObject(value: any): CobolDispatchPlanner;
  loadObject(value: any): void;
  setDataset(dataset?: string | null): void;
  setMqRoute(manager: string, queue: string, commit?: string | null): void;
  clearDataset(): void;
  toCobolStub(): string;
  addAnnotation(annotation: string): void;
  clearMetadata(): void;
  clearMqRoute(): void;
  mergeMetadata(metadata: any): void;
  setCicsRoute(transaction: string, program?: string | null, channel?: string | null): void;
  setCreatedAt(timestamp: string): void;
  toUint8Array(): Uint8Array;
  setDatasetLog(log?: boolean | null): void;
  clearCicsRoute(): void;
  clearInitiators(): void;
  resetCreatedAt(): void;
  setCoefficients(coefficients: Float32Array): void;
  setDatasetLike(like_dataset?: string | null): void;
  setDatasetType(dataset_type?: string | null): void;
  setDatasetUnit(unit?: string | null): void;
  toCobolPreview(): any;
  setDatasetReuse(reuse?: boolean | null): void;
  validationIssues(): Array<any>;
  setDatasetMember(member?: string | null): void;
  setDatasetVolume(volume?: string | null): void;
  addHumanInitiator(name: string, persona?: string | null, contact?: string | null, note?: string | null): void;
  addModelInitiator(name: string, revision?: string | null, persona?: string | null, note?: string | null): void;
  setNarratorConfig(curvature: number, temperature: number, encoder: string, locale?: string | null): void;
  setReleaseChannel(channel: string): void;
  coefficientsAsBytes(): Uint8Array;
  setDatasetBlockSize(block_size?: number | null): void;
  setDatasetDataClass(data_class?: string | null): void;
  setDatasetKeyLength(key_length?: number | null): void;
  setDatasetKeyOffset(key_offset?: number | null): void;
  setDatasetSpaceUnit(space_unit?: string | null): void;
  setDatasetUnitCount(unit_count?: number | null): void;
  setDatasetDisposition(disposition?: string | null): void;
  addAutomationInitiator(name: string, persona?: string | null, note?: string | null): void;
  setDatasetOrganization(organization?: string | null): void;
  setDatasetRecordFormat(record_format?: string | null): void;
  setDatasetRecordLength(record_length?: number | null): void;
  setDatasetReleaseSpace(release_space?: boolean | null): void;
  setDatasetSpacePrimary(space_primary?: number | null): void;
  setDatasetStorageClass(storage_class?: string | null): void;
  setDatasetEraseOnDelete(erase_on_delete?: boolean | null): void;
  setDatasetExpirationDate(expiration_date?: string | null): void;
  setDatasetSpaceSecondary(space_secondary?: number | null): void;
  setDatasetCatalogBehavior(catalog_behavior?: string | null): void;
  setDatasetDirectoryBlocks(directory_blocks?: number | null): void;
  setDatasetManagementClass(management_class?: string | null): void;
  setDatasetRetentionPeriod(retention_period?: number | null): void;
  setDatasetAverageRecordUnit(average_record_unit?: string | null): void;
  setDatasetControlIntervalSize(control_interval_size?: number | null): void;
  setDatasetShareOptionsCrossRegion(share_options_cross_region?: number | null): void;
  setDatasetShareOptionsCrossSystem(share_options_cross_system?: number | null): void;
  constructor(job_id: string, release_channel?: string | null);
  addTag(tag: string): void;
  toJson(): string;
  isValid(): boolean;
  mqRoute(): any;
  static fromJson(json: string): CobolDispatchPlanner;
  loadJson(json: string): void;
  toObject(): any;
  readonly createdAt: string;
}
export class FractalCanvas {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Push a new fractal relation patch into the scheduler.
   *
   * The input buffer must contain `width * height` values laid out in row-major
   * order.
   */
  push_patch(relation: Float32Array, coherence: number, tension: number, depth: number): void;
  /**
   * Switch the active colour palette.
   */
  set_palette(name: string): void;
  /**
   * Refresh the canvas once and return a compact packet with the current
   * RGBA pixels, relation tensor, colour field, hyperbolic trail, and
   * gradient-derived Desire signals. Use this when you want to drive
   * multiple visualisations (2D canvas, WebGPU trails, telemetry) without
   * re-rendering the canvas for each query.
   */
  framePacket(curvature: number): CanvasFramePacket;
  /**
   * Refresh the projector and expose the colour vector field as a `Float32Array`.
   */
  vector_field(): Float32Array;
  /**
   * Refresh the projector and emit the Euclidean gradient update for the
   * current canvas relation.
   */
  realgradWave(): Float32Array;
  /**
   * Refresh the projector and collapse the gradient summaries into Desire's
   * control packet, exposing precomputed gains and learning-rate scales.
   */
  desireControl(curvature: number): CanvasDesireControl;
  /**
   * Refresh the projector and emit the hypergradient-aligned update for the
   * current canvas relation.
   */
  hypergradWave(curvature: number): Float32Array;
  /**
   * Refresh the projector and emit the AR particle trail for the current
   * vector field. Each particle contributes `(x, y, z, energy, r, g, b)` so
   * WebGPU/WebXR callers can upload the buffer without additional packing.
   */
  emitWasmTrail(curvature: number): Float32Array;
  /**
   * Summarise the current canvas relation across both the hypergradient and
   * Euclidean tapes. The returned object exposes the common norms so callers
   * can monitor gradient stability without materialising the full buffers.
   */
  gradientSummary(curvature: number): CanvasGradientSummary;
  /**
   * Render the current scheduler state onto the provided HTML canvas.
   */
  render_to_canvas(canvas: HTMLCanvasElement): void;
  /**
   * Reset the internal normaliser so the next frame recomputes brightness ranges.
   */
  reset_normalizer(): void;
  /**
   * Refresh the projector and return the interleaved FFT spectrum for each
   * canvas row. Each frequency sample contributes eight floats (real/imag
   * pairs for energy + RGB chroma).
   */
  vectorFieldFft(inverse: boolean): Float32Array;
  /**
   * Refresh the projector and interpret the gradient health into Desire's
   * feedback coordinates.
   */
  desireInterpretation(curvature: number): CanvasDesireInterpretation;
  /**
   * Compute the Euclidean wave update against the current relation tensor
   * without refreshing the canvas first.
   */
  realgradWaveCurrent(): Float32Array;
  /**
   * Refresh the projector, derive Desire's control packet, and pack it into
   * a WGSL-friendly uniform layout. The returned `Uint32Array` holds the raw
   * IEEE-754 bits so callers can reinterpret the underlying buffer as a
   * `Float32Array` when uploading to WebGPU.
   */
  desireControlUniform(curvature: number): Uint32Array;
  /**
   * Compute the hypergradient wave update against the current relation
   * tensor without refreshing the canvas first. Use `framePacket()` or
   * `render_to_canvas()` to refresh the internal state before calling this.
   */
  hypergradWaveCurrent(curvature: number): Float32Array;
  /**
   * Emit the WGSL kernel that mirrors [`vector_field_fft`] so WebGPU
   * consumers can reproduce the spectral pass directly on the GPU.
   */
  vectorFieldFftKernel(subgroup: boolean): string;
  /**
   * Byte layout metadata mirroring the WGSL `FieldSample`, `SpectrumSample`
   * and uniform structs so WebGPU callers can size buffers without manual
   * calculations.
   */
  vectorFieldFftLayout(): CanvasFftLayout;
  /**
   * Generate the uniform parameters expected by [`vector_field_fft_kernel`].
   *
   * The returned array packs the canvas `width`, `height`, the `inverse`
   * flag (1 = inverse, 0 = forward) and a padding slot so the buffer aligns
   * to 16 bytes as required by WGSL uniform layout rules.
   */
  vectorFieldFftUniform(inverse: boolean): Uint32Array;
  /**
   * Emit the WGSL kernel that accumulates the relation tensor directly into
   * a hypergradient buffer without leaving the GPU.
   */
  hypergradOperatorKernel(subgroup: boolean): string;
  /**
   * Compute the workgroup dispatch dimensions that pair with
   * [`vector_field_fft_kernel`]. The returned `[x, y, z]` triplet already
   * accounts for the workgroup size when toggling subgroup execution.
   */
  vectorFieldFftDispatch(subgroup: boolean): Uint32Array;
  /**
   * Uniform parameters (width, height, blend, gain) consumed by the
   * hypergradient WGSL operator.
   */
  hypergradOperatorUniform(mix: number, gain: number): Float32Array;
  /**
   * Workgroup dispatch dimensions matching `hypergradOperatorKernel`.
   */
  hypergradOperatorDispatch(subgroup: boolean): Uint32Array;
  /**
   * Refresh the canvas, derive the Desire control packet, and emit the
   * matching hypergradient operator uniform in a single step.
   */
  hypergradOperatorUniformAuto(curvature: number): Float32Array;
  /**
   * Compute the hypergradient operator uniform directly from the current
   * Desire control packet. Useful when the control data is computed once on
   * the Rust side and then cached in JavaScript.
   */
  hypergradOperatorUniformFromControl(control: CanvasDesireControl): Float32Array;
  /**
   * Construct a projector-backed canvas with the requested queue capacity.
   */
  constructor(capacity: number, width: number, height: number);
  /**
   * Refresh the projector and return a view of the RGBA buffer as a typed array.
   */
  pixels(): Uint8Array;
  /**
   * Current palette name.
   */
  palette(): string;
  /**
   * Refresh the projector and expose the raw relation tensor feeding the canvas.
   */
  relation(): Float32Array;
  /**
   * Canvas width in pixels.
   */
  readonly width: number;
  /**
   * Canvas height in pixels.
   */
  readonly height: number;
}
export class GraphInferenceSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class GraphTrainingParametersSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class GraphTrainingSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class GraphTrainingState {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class InferencePlan {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  compileWebGpu(): Promise<ResidentInference>;
  compileGraphWebGpu(tile_mnk?: Array<any> | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentGraphInference>;
  compileTrainingWebGpu(tile_mnk?: Array<any> | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentTraining>;
  compileGraphTrainingWebGpu(gradient_policy: string, tile_mnk?: Array<any> | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentGraphTraining>;
  toJson(): string;
  static fromJson(payload: string, max_bytes?: number | null): InferencePlan;
  readonly inputShape: Uint32Array;
  readonly stageCount: number;
  readonly outputShape: Uint32Array;
  readonly sourceOperationCount: number;
  readonly isDense: boolean;
}
export class InferenceSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class RankAdaptationSession {
  free(): void;
  [Symbol.dispose](): void;
  pendingSelectionId(): number | undefined;
  constructor(request: any);
  choose(): any;
  abandon(selection_id: number): any;
  observe(selection_id: number, elapsed_ms: number, correctness_passed: boolean): any;
  snapshot(): any;
}
export class ResidentGraphInference {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class ResidentGraphTraining {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class ResidentInference {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class ResidentTraining {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class ResolvedWasmFftPlan {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  static fromObject(value: any): ResolvedWasmFftPlan;
  toJson(): string;
  static fromJson(json: string): ResolvedWasmFftPlan;
  toObject(): any;
  readonly heuristicUsed: boolean;
  readonly overrideApplied: boolean;
  readonly plan: WasmFftPlan;
  readonly source: WasmFftPlanSource;
}
/**
 * A reusable batch in WASM linear memory, not GPU-resident storage.
 * Construction copies partial-major row-major f32 data once. Repeated means
 * execute the same ordered-f64 Rust reducer used by GoldenRetriever.
 */
export class TensorMeanBatch {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Returns a new Float32Array. No input buffer or earlier result is mutated.
   */
  meanScaled(scale: number): Float32Array;
  constructor(rows: number, cols: number, partial_count: number, data: Float32Array);
}
export class TrainingLossSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class TrainingParametersSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class TrainingSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class TrainingState {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
}
export class WasmFftPlan {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Rebuild a plan from a plain JavaScript object with the same fields as [`toObject`].
   */
  static fromObject(value: any): WasmFftPlan;
  spiralkHint(): string;
  workgroupSize(): number;
  dispatchManifestJson(): string;
  dispatchManifestObject(): any;
  constructor(radix: number, tile_cols: number, segments: number, subgroup: boolean);
  wgsl(): string;
  /**
   * Serialise the plan into a JSON string so it can be persisted or sent over the network.
   */
  toJson(): string;
  /**
   * Rebuild a plan from a JSON string produced by [`toJson`].
   */
  static fromJson(json: string): WasmFftPlan;
  /**
   * Convert the plan into a plain JavaScript object with the same fields as [`toJson`].
   */
  toObject(): any;
  readonly radix: number;
  readonly segments: number;
  readonly subgroup: boolean;
  readonly tileCols: number;
}
export class WasmFractalFieldGenerator {
  free(): void;
  [Symbol.dispose](): void;
  probeJson(log_start: number, log_step: number, len: number, preview_len: number): string;
  probeObject(log_start: number, log_step: number, len: number, preview_len: number): any;
  branchingField(log_start: number, log_step: number, len: number): Float32Array;
  constructor(octaves: number, lacunarity: number, gain: number, iterations: number);
  readonly iterations: number;
  readonly lacunarity: number;
  readonly gain: number;
  readonly octaves: number;
}
export class WasmLogZSeries {
  free(): void;
  [Symbol.dispose](): void;
  evaluateZ(z: Float32Array): Float32Array;
  probeJson(z_values: Float32Array, preview_len: number): string;
  probeObject(z_values: Float32Array, preview_len: number): any;
  evaluateManyZ(z_values: Float32Array): Float32Array;
  len(): number;
  constructor(log_start: number, log_step: number, samples: Float32Array, window: string, normalisation: string);
  samples(): Float32Array;
  weights(): Float32Array;
  isEmpty(): boolean;
  readonly normalisation: string;
  readonly window: string;
  readonly logStep: number;
  readonly logStart: number;
}
export class WasmMellinEvalPlan {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  static verticalLine(log_start: number, log_step: number, real: number, imag_values: Float32Array): WasmMellinEvalPlan;
  len(): number;
  static many(log_start: number, log_step: number, s_values: Float32Array): WasmMellinEvalPlan;
  static mesh(log_start: number, log_step: number, real_values: Float32Array, imag_values: Float32Array): WasmMellinEvalPlan;
  shape(): Uint32Array;
  readonly logStep: number;
  readonly logStart: number;
}
export class WasmMellinLogGrid {
  free(): void;
  [Symbol.dispose](): void;
  hilbertNorm(): number;
  evaluateMany(s_values: Float32Array): Float32Array;
  evaluateMesh(real_values: Float32Array, imag_values: Float32Array): Float32Array;
  evaluatePlan(plan: WasmMellinEvalPlan): Float32Array;
  evaluateStable(s: Float32Array): Float32Array;
  static newWithWindow(log_start: number, log_step: number, samples: Float32Array, window: string, preserve_sum: boolean): WasmMellinLogGrid;
  weightedSeries(): Float32Array;
  static expDecayScaled(log_start: number, log_step: number, len: number, rate: number, window: string, preserve_sum: boolean): WasmMellinLogGrid;
  planVerticalLine(real: number, imag_values: Float32Array): WasmMellinEvalPlan;
  evaluateManyStable(s_values: Float32Array): Float32Array;
  evaluatePlanStable(plan: WasmMellinEvalPlan): Float32Array;
  hilbertInnerProduct(other: WasmMellinLogGrid): Float32Array;
  evaluateVerticalLine(real: number, imag_values: Float32Array): Float32Array;
  evaluateMeshMagnitude(real_values: Float32Array, imag_values: Float32Array): Float32Array;
  evaluatePlanMagnitude(plan: WasmMellinEvalPlan): Float32Array;
  evaluateWithDerivative(s: Float32Array): Array<any>;
  trainStepMatchGridPlan(plan: WasmMellinEvalPlan, target: WasmMellinLogGrid, lr: number): number;
  evaluateMeshLogMagnitude(real_values: Float32Array, imag_values: Float32Array, epsilon: number): Float32Array;
  evaluatePlanLogMagnitude(plan: WasmMellinEvalPlan, epsilon: number): Float32Array;
  evaluateManyWithDerivative(s_values: Float32Array): Array<any>;
  evaluatePlanWithDerivative(plan: WasmMellinEvalPlan): Array<any>;
  evaluateWithDerivativeStable(s: Float32Array): Array<any>;
  evaluateManyWithDerivativeStable(s_values: Float32Array): Array<any>;
  evaluatePlanWithDerivativeStable(plan: WasmMellinEvalPlan): Array<any>;
  len(): number;
  constructor(log_start: number, log_step: number, samples: Float32Array);
  samples(): Float32Array;
  support(): Float32Array;
  weights(): Float32Array;
  evaluate(s: Float32Array): Float32Array;
  isEmpty(): boolean;
  static expDecay(log_start: number, log_step: number, len: number, window: string, preserve_sum: boolean): WasmMellinLogGrid;
  planMany(s_values: Float32Array): WasmMellinEvalPlan;
  planMesh(real_values: Float32Array, imag_values: Float32Array): WasmMellinEvalPlan;
  readonly logStep: number;
  readonly logStart: number;
}
export class WasmScaleStack {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  persistence(): Float32Array;
  coherenceProfile(levels: Float32Array): Float32Array;
  interfaceDensity(): number | undefined;
  boundaryDimension(ambient_dim: number, window: number): number | undefined;
  coherenceBreakScale(level: number): number | undefined;
  moment(order: number): number;
  static scalar(field: Float32Array, shape: Uint32Array, scales: Float32Array, threshold: number): WasmScaleStack;
  samples(): Float32Array;
  toJson(ambient_dim: number, dimension_window: number, levels: Float32Array): string;
  static semantic(embeddings: Float32Array, rows: number, dims: number, scales: Float32Array, threshold: number, metric: string): WasmScaleStack;
  toObject(ambient_dim: number, dimension_window: number, levels: Float32Array): any;
  readonly sampleCount: number;
  readonly mode: string;
  readonly threshold: number;
}
export class WasmTuner {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Merge additional overrides from a JSON blob, keeping the ordering stable.
   */
  mergeJson(json: string): void;
  /**
   * Locate the first record matching the provided workload. Returns `undefined` when nothing matches.
   */
  findRecord(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Construct a tuner from a JavaScript array of records.
   */
  static fromObject(value: any): WasmTuner;
  /**
   * Replace the table contents with the provided array of records.
   */
  loadObject(value: any): void;
  /**
   * Merge additional overrides from a JavaScript array of records.
   */
  mergeObject(value: any): void;
  /**
   * Remove a record by index. Returns `undefined` for an out-of-bounds integer index.
   */
  removeIndex(index: number): any;
  /**
   * Produce a tuned FFT plan encoded as JSON when an override exists.
   */
  planFftJson(rows: number, cols: number, k: number, subgroup: boolean): string | undefined;
  /**
   * Remove the first record matching the workload. Returns `undefined` when nothing matched.
   */
  removeRecord(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Replace the record at the provided index. Returns `true` when the index existed.
   */
  replaceIndex(index: number, record: any): boolean;
  /**
   * Produce a tuned FFT plan encoded as a plain JavaScript object when an override exists.
   */
  planFftObject(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Resolve a tuned FFT plan and return a JSON-ready report describing how the plan was
   * assembled (override vs. heuristic vs. fallback).
   */
  planFftReport(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Resolve a tuned FFT plan and return metadata describing how the plan was
   * assembled (override vs. heuristic vs. fallback).
   */
  planFftResolution(rows: number, cols: number, k: number, subgroup: boolean): ResolvedWasmFftPlan;
  /**
   * Resolve a tuned FFT plan. Falls back to heuristics (or base device caps)
   * when no explicit override matches.
   */
  planFftWithFallback(rows: number, cols: number, k: number, subgroup: boolean): WasmFftPlan;
  /**
   * Resolve a tuned FFT plan and encode the metadata report as JSON.
   */
  planFftResolutionJson(rows: number, cols: number, k: number, subgroup: boolean): string;
  /**
   * Resolve a tuned FFT plan and encode the metadata report as a plain JavaScript object.
   */
  planFftResolutionObject(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Resolve a tuned FFT plan and encode it as JSON.
   */
  planFftWithFallbackJson(rows: number, cols: number, k: number, subgroup: boolean): string;
  /**
   * Resolve a tuned FFT plan and encode it as a plain JavaScript object.
   */
  planFftWithFallbackObject(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Number of records available in the table.
   */
  len(): number;
  /**
   * Construct a tuner table. Pass `None` to start from an empty dataset or a JSON string to seed it.
   */
  constructor(json?: string | null);
  /**
   * Append a new record represented as a JavaScript object.
   */
  push(record: any): void;
  /**
   * Clear every record from the table.
   */
  clear(): void;
  /**
   * Query the tuner for a given workload. Returns `undefined` when no override matches.
   */
  choose(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Return the dataset as an array of JavaScript objects.
   */
  records(): any;
  /**
   * Return the internal dataset as a JSON string.
   */
  to_json(): string;
  /**
   * Returns `true` when no overrides are stored.
   */
  isEmpty(): boolean;
  /**
   * Produce a tuned FFT plan for the provided workload if an override exists.
   */
  planFft(rows: number, cols: number, k: number, subgroup: boolean): WasmFftPlan | undefined;
  /**
   * Replace the table contents with the provided JSON blob.
   */
  loadJson(json: string): void;
  /**
   * Retrieve a record by index. Returns `undefined` when the index is out of bounds.
   */
  recordAt(index: number): any;
  /**
   * Export the dataset into a JavaScript array of records.
   */
  toObject(): any;
}
