import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

W = Path('/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-resident-graph-clients-v1')
T = Path('/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-spiralk-golden-blackcat-contract-v1/target')
L = Path(__file__).parent / 'final'
L.mkdir()
python = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
torch = '/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
bindgen = '/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen'
chrome = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
env = dict(os.environ, CARGO_BUILD_JOBS='4', CARGO_TARGET_DIR=str(T), PYO3_PYTHON=python,
           SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1', PYTORCH_ENABLE_MPS_FALLBACK='0',
           NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=W, text=True).strip()
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=W): raise RuntimeError('dirty source')
report = dict(schema='spiraltorch.graph_clients.validation_receipt.v1', source=source, tree=tree,
              status='error', steps=[], products={})
def run(name, args, overrides=None):
    print('start', name, flush=True)
    start = time.monotonic()
    with (L/(name+'.log')).open('xb') as out:
        p = subprocess.run(args, cwd=W, env=dict(env, **(overrides or {})), stdout=out, stderr=subprocess.STDOUT)
    record = dict(name=name, command=args, returncode=p.returncode, seconds=time.monotonic()-start)
    report['steps'].append(record)
    print(json.dumps(record), flush=True)
    if p.returncode: raise RuntimeError(name+' failed')
def register(path):
    path.chmod(0o444)
    report['products'][str(path.relative_to(L))] = hashlib.sha256(path.read_bytes()).hexdigest()
def py(library, mode, *args):
    return [python, '-I', str(Path(__file__).with_name('python-client.py')), str(library), str(W), mode, *map(str, args)]
def browser(name, suite):
    run(name, ['node', str(W/'tools/test_resident_browser.cjs'), str(L/suite.split('-')[0]), chrome,
               str(L/(name+'.json')), '', '', '', '', suite.split(':')[-1]])
with (L/'receipt.json').open('x') as out:
    try:
        run('fmt', ['cargo', '+nightly-2026-04-15', 'fmt', '--all', '--', '--check'])
        run('admission', [python, '-I', 'tests/test_resident_graph_client_validation.py'])
        run('legacy-admission', [python, '-I', 'tests/test_resident_training_client_validation.py'])
        run('contracts', ['cargo', '+1.98.0', 'test', '--locked', '-p', 'st-kernel-contracts'])
        run('contracts-clippy', ['cargo', '+1.98.0', 'clippy', '--locked', '-p', 'st-kernel-contracts', '--all-targets', '--', '-D', 'warnings'])
        run('backend', ['cargo', '+1.98.0', 'test', '--locked', '--release', '-p', 'st-backend-wgpu', '--lib', '--', '--test-threads=1'])
        run('nn', ['cargo', '+1.98.0', 'test', '--locked', '--release', '-p', 'st-nn', '--no-default-features', '--features', 'wgpu', '--lib',
                   '--test', 'resident_training', '--test', 'resident_nd_tensor', '--test', 'resident_graph_training', '--test', 'resident_inference', '--', '--test-threads=1'])
        run('backend-clippy', ['cargo', '+1.98.0', 'clippy', '--locked', '-p', 'st-backend-wgpu', '--all-targets', '--', '-D', 'warnings'])
        run('backend-wasm-clippy', ['cargo', '+1.98.0', 'clippy', '--locked', '-p', 'st-backend-wgpu', '--target', 'wasm32-unknown-unknown', '--all-targets', '--', '-D', 'warnings'])
        run('python-wgpu-build', ['cargo', '+1.98.0', 'build', '--locked', '-p', 'spiraltorch-py'])
        shutil.copyfile(T/'debug/libspiraltorch.dylib', L/'python-wgpu.dylib'); register(L/'python-wgpu.dylib')
        run('python-wgpu-tests', py(L/'python-wgpu.dylib', 'tests', L/'python-wgpu-tests.json'))
        run('python-graph-capture', py(L/'python-wgpu.dylib', 'bindings/st-py/examples/resident_graph_training.py', '--output', L/'graph-fixture.json'))
        run('python-dense-capture', py(L/'python-wgpu.dylib', 'bindings/st-py/examples/resident_nn_roundtrip.py', '--output', L/'nn-fixture.json'))
        for name, feature in [('webgpu', 'webgpu'), ('cpu', 'nn')]:
            run(name+'-build', ['cargo', '+1.98.0', 'build', '--locked', '--release', '-p', 'spiraltorch-wasm', '--target', 'wasm32-unknown-unknown', '--features', feature])
            run(name+'-bindgen', [bindgen, '--target', 'web', '--out-dir', str(L/name), '--out-name', 'spiraltorch_wasm', str(T/'wasm32-unknown-unknown/release/spiraltorch_wasm.wasm')])
            for path in (L/name).rglob('*'):
                if path.is_file(): register(path)
            for filename in ('graph-fixture.json', 'nn-fixture.json'):
                shutil.copyfile(L/filename, L/name/filename)
            suffix = '-cpu' if name == 'cpu' else ''
            for case in ('graph', 'dense'):
                suite = ('nn-graph-clients' if case == 'graph' else 'nn-clients') + suffix
                run(name+'-'+case+'-browser', ['node', str(W/'tools/test_resident_browser.cjs'), str(L/name), chrome,
                     str(L/(name+'-'+case+'-browser.json')), '', '', '', '', suite])
        run('python-return', py(L/'python-wgpu.dylib', 'bindings/st-py/examples/resident_graph_training.py',
            '--fixture', L/'graph-fixture.json', '--browser-report', L/'webgpu-graph-browser.json', '--output', L/'return.json'))
        run('torch-replay', [torch, '-I', 'tools/verify_resident_graph_clients_torch.py', '--python-report', str(L/'graph-fixture.json'),
            '--browser-report', str(L/'webgpu-graph-browser.json'), '--return-report', str(L/'return.json'), '--output', str(L/'torch.json')])
        run('python-cpu-build', ['cargo', '+1.98.0', 'build', '--locked', '-p', 'spiraltorch-py', '--no-default-features', '--features', 'python-default,cpu'])
        shutil.copyfile(T/'debug/libspiraltorch.dylib', L/'python-cpu.dylib'); register(L/'python-cpu.dylib')
        run('python-cpu-tests', py(L/'python-cpu.dylib', 'tests', L/'python-cpu-tests.json'), {'SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS':'0'})
        if subprocess.check_output(['git', 'status', '--porcelain'], cwd=W): raise RuntimeError('source changed during validation')
        if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip() != source: raise RuntimeError('head changed')
        for name, expected in report['products'].items():
            if hashlib.sha256((L/name).read_bytes()).hexdigest() != expected: raise RuntimeError('build product changed')
        gpu_test, cpu_test = [json.loads((L/name).read_text()) for name in ('python-wgpu-tests.json', 'python-cpu-tests.json')]
        if gpu_test['skipped'] != 0 or gpu_test['tests'] != 20 or cpu_test['skipped'] != 12: raise RuntimeError('test coverage drift')
        report['status'] = 'passed'
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        json.dump(report, out, indent=2)
        out.write('\n')
