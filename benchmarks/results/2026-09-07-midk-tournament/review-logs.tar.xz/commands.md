# Post-review replay

Frozen source: ed21f2000d49b3add759b8a4b53fb3b46b4e60ee.
All GPU processes were awaited to terminal before starting the next. No
same-host build overlapped a native or browser timing run. The existing
Furnace CPU llama-server was not changed.

## Tests and builds

Run in the source checkout, with an isolated Cargo target. Local Rust 1.98.0,
Furnace private Rust 1.98.1, and the existing nightly-2026-04-15 formatter:

```bash
cargo +nightly-2026-04-15 fmt --all -- --check
python3 -I tools/sync_rankk_wgsl.py --check
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 cargo test --locked -p st-backend-wgpu -- --test-threads=1
cargo clippy --locked -p st-backend-wgpu --all-targets -- -D warnings
cargo check --locked -p spiraltorch-wasm --target wasm32-unknown-unknown --features webgpu --all-targets
cargo build --locked --release -p spiraltorch-wasm --target wasm32-unknown-unknown --features webgpu
wasm-bindgen --target web --out-dir WEB_ED21F200 TARGET/wasm32-unknown-unknown/release/spiraltorch_wasm.wasm
maturin build --locked --release --manifest-path bindings/st-py/Cargo.toml --features wgpu-rt --interpreter PRIVATE_PYTHON --out WHEELS_ED21F200
PRIVATE_PYTHON -I -m pip install --force-reinstall --no-deps WHEELS_ED21F200/spiraltorch-0.4.27-cp38-abi3-macosx_11_0_arm64.whl
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 PRIVATE_PYTHON -I -m pytest --import-mode=importlib -q bindings/st-py/tests/test_wgpu_rank.py bindings/st-py/tests/test_wgpu_resident.py bindings/st-py/tests/test_spiralk_rank_tile.py bindings/st-py/tests/test_resident_rank_adaptation.py bindings/st-py/tests/test_wgpu_rank_reports.py
```

The first local test/check pass also succeeded on the older installed stable
1.97.0; its strict Clippy failed on two pre-existing unknown lint names.
Those logs are preserved, and the Rust 1.98 reruns pass without relaxing lints.
The post-review wheel explicitly enables wgpu-rt, unlike the earlier study's
default-feature wheel. This replay does not claim Python timing equivalence.
An initial adapter-inspection command passed tile_cols positionally and failed
before constructing a GPU workspace; its empty JSON is retained. The corrected
keyword-argument invocation is python-adapter-ed21f200-ok.json.

## Native and browser replay

On Furnace, build the release example, copy it outside the shared Cargo target,
set the copy read-only, and retain --build-info before invoking the harness:

```bash
cargo build --locked --release -p st-core --features wgpu-rt,kdsl --example resident_rank_adaptation_bench
COPIED_EXECUTABLE --build-info
/usr/bin/python3 tools/bench_resident_rank_adaptation_vs_torch.py --executable COPIED_EXECUTABLE --output NEW_NATIVE_JSON
```

On macOS, use the already frozen 5caf3182 web module as baseline. NODE_PATH
points only to the study's private Playwright installation. No user profile:

```bash
node tools/test_resident_browser.cjs WEB_ED21F200 CHROME NEW_BROWSER_JSON '' '' '' '' rank-matched WEB_5CAF3182
```

Recompute summary from extracted logs, with a repo containing both source
commits (1ed7d2f3 and ed21f200) and the unchanged benchmark harness:

```bash
PRIVATE_PYTHON -I replay_review.py --repo REPO --output summary-recomputed.json
```

The products themselves are not in this small archive; build logs, native
embedded source binding, wheel/WASM hashes and browser asset hashes are.
Python/WASM source attribution is build-log based, not embedded attestation.
