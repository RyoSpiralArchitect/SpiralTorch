"""Validate the frozen post-review native/browser replay without running a GPU."""

import argparse
from array import array
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--repo", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parent
repo = args.repo.resolve()
sys.path.insert(0, str(repo / "tools"))
import bench_resident_rank_adaptation_vs_torch as audit

source = "ed21f2000d49b3add759b8a4b53fb3b46b4e60ee"
measured_before = "1ed7d2f394cf19ad13b33c47b14c3bd4fc4ab2af"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return json.loads((root / name).read_text())


def git_file(commit, path):
    return subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=repo)


shaders = {}
prefix = "crates/st-backend-wgpu/src/shaders/"
for name in ("rankk_exact_2ce.wgsl", "rankk_exact_2ce_midk_tournament.wgsl"):
    before = git_file(measured_before, prefix + "rankk_exact_2ce_common.wgsl") + b"\n" + git_file(measured_before, prefix + name)
    after = git_file(source, prefix + name)
    assert before == after
    shaders[name] = {"sha256": sha(after), "bytes": len(after), "unchanged_gpu_source": True}

native = read("rank-suite-ed21f200.json")
assert native["status"] == "passed" and len(native["cases"]) == 36
assert native["source"]["commit"] == source and not native["source"]["tracked_dirty"]
assert native["provenance"]["valid"] and native["source"] == native["provenance"]["source_after"]
assert native["build_source_binding"]["valid"] and native["build_source_binding"]["embedded_commit"] == source
assert native["build_source_binding"] == audit.audit.validate_source_binding(native["native_build_identity"], native["source"])
assert native["native_build_identity"] == read("build-info-ed21f200.json")
assert native["native_returncode"] == 0 and not native["native_stderr"]
bench = audit.audit.load_bench_module()
requests = list(audit.requests(bench))
payload = "".join(json.dumps(r, allow_nan=False) + "\n" for r, _ in requests)
assert sha(payload.encode()) == native["request_sha256"]
ratios = []
observations = 0
for case, (request, tiles) in zip(native["cases"], requests):
    assert case["request"] == {k: v for k, v in request.items() if k != "input"}
    assert case["tiles"] == tiles
    result = case["native"]
    audit.validate_native(result, request, tiles)
    values = array("f", request["input"])
    expected_values, expected_ids = [], []
    cols, k = request["cols"], request["k"]
    for row in range(request["rows"]):
        data = values[row * cols : (row + 1) * cols]
        ids = sorted(range(cols), key=lambda i: (-data[i] if request["kind"] == "topk" else data[i], i))
        start = (cols - k) // 2 if request["kind"] == "midk" else 0
        chosen = ids[start : start + k]
        expected_values.extend(data[i] for i in chosen)
        expected_ids.extend(chosen)
    assert result["values"] == expected_values and result["indices"] == expected_ids
    assert result["adapter"]["name"] == native["torch_device"]
    assert case["torch_operation"] == audit.resident.cuda_rank_operation(request)
    cuda_samples = case["torch_timing"]["samples_ms"]
    assert len(cuda_samples) == 12 and all(math.isfinite(x) and x > 0 for x in cuda_samples)
    assert case["torch_timing"] == bench.summarize(cuda_samples)
    assert case["controls"] == [bench.summarize(s) for s in result["control_samples_per_op_ms"]]
    assert case["adaptive"] == bench.summarize([o["per_op_ms"] for o in result["observations"]])
    observations += len(result["observations"])
    ratios.append(min(c["median_ms"] for c in case["controls"]) / case["torch_timing"]["median_ms"])

browser = read("matched-browser-ed21f200.json")
assert browser["status"] == "passed" and not browser["page_errors"]
assert len(browser["cases"]) == 44
assert (browser["repetitions"], browser["warmup_batches"], browser["retained_batches"]) == (64, 4, 16)
fixture = "bindings/st-wasm/tests/resident_rank_matched_webgpu.html"
assert browser["page_sha256"] == sha(git_file(source, fixture))
assert browser["wasm_sha256"] == browser["asset_sha256"]["/module/spiraltorch_wasm_bg.wasm"]
products = dict(line.split(None, 1)[::-1] for line in (root / "build-products.sha256").read_text().splitlines())
for suffix in ("spiraltorch_wasm.js", "spiraltorch_wasm_bg.wasm"):
    matches = [value for path, value in products.items() if path.endswith("/web-ed21f200/" + suffix)]
    assert matches == [browser["asset_sha256"]["/module/" + suffix]]
baseline_assets = read("baseline-assets.json")
for path, digest in baseline_assets.items():
    assert browser["asset_sha256"][path] == digest
cells = []
expected_cases = [(tiles, k) for tiles in [32, 33, 63, 64, 65, 127, 128, 129, 255, 256, 257] for k in [1, 7, 65, 256]]
for case, (tiles, k) in zip(browser["cases"], expected_cases):
    assert (case["kind"], case["rows"], case["cols"], case["k"], case["tile_cols"]) == ("midk", 2, tiles * 32 - 1, k, 32)
    assert case["status"] == "passed" and len(case["samples"]) == 16
    assert Counter(tuple(s["order"]) for s in case["samples"]) == {("baseline", "candidate"): 8, ("candidate", "baseline"): 8}
    a, b = ([s[key] for s in case["samples"]] for key in ("baseline_ms", "candidate_ms"))
    assert all(math.isfinite(x) and x > 0 for x in a + b)
    cells.append({"tiles": tiles, "k": k, "mean_ratio": statistics.mean(b) / statistics.mean(a)})

assert "92 passed" in (root / "python-rank-resident-all-ed21f200.log").read_text()
for name in ("backend-full-green.log", "backend-full-ed21f200-mac198.log", "backend-full-ed21f200-linux.log"):
    log = (root / name).read_text()
    assert "74 passed; 0 failed" in log and "1 passed; 0 failed" in log
for name in ("backend-clippy-1.98.log", "backend-clippy-ed21f200-linux.log", "wasm-all-targets-ed21f200.log"):
    assert "Finished `dev` profile" in (root / name).read_text()
identity = read("python-identity-ed21f200.json")
assert identity["build_info"]["features"]["wgpu"] and identity["build_info"]["features"]["kdsl"]
result = {
    "schema": "spiraltorch.midk_tournament_review_replay.v1", "status": "passed", "source": source,
    "gpu_sources": shaders,
    "native": {"cases": 36, "observations": observations, "torch": native["torch"], "adapter": native["torch_device"],
               "build_identity": native["native_build_identity"], "hindsight_best_over_cuda_range": [min(ratios), max(ratios)]},
    "browser": {"cases": 44, "version": browser["browser_version"], "adapters": browser["adapters"], "cells": cells,
                "asset_sha256": browser["asset_sha256"], "interpretation": "one matched replay, not independent seeds or a physical adapter attestation"},
    "python": {"passed": 92, "identity": identity, "adapter": read("python-adapter-ed21f200-ok.json")},
    "raw_sha256": {p.name: sha(p.read_bytes()) for p in sorted(root.iterdir()) if p.suffix in (".json", ".log", ".sha256", ".py") and p.resolve() != args.output.resolve() and not p.name.startswith("summary")},
}
with args.output.open("x") as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
    handle.write("\n")
print(json.dumps({"status": result["status"], "native": 36, "observations": observations, "browser": 44, "python": 92}))
