"""Execute the unmodified resident Topos EMA guide with the frozen native build."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import spiraltorch as st

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
RUN = LOG/'verified-a'
receipt=json.loads((RUN/'receipt.json').read_bytes())
assert receipt['status']=='passed' and 'active' not in receipt
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==receipt['source']['commit']
library=Path(st._rs.__file__).resolve();assert library==RUN/'python-release.dylib'
digest=lambda value:hashlib.sha256(value).hexdigest()
assert digest(library.read_bytes())==receipt['products']['python-release.dylib']
blocks=re.findall(r'```python\n(.*?)\n```',(ROOT/'docs/module_resident_momentum.md').read_text(),re.S)
assert len(blocks)==1
scope={};exec(compile(blocks[0],'docs/module_resident_momentum.md','exec'),scope)
l=scope['learner'];assert l.input_generation==32 and l.update_snapshot().read()==32
assert l.submitted_backwards==32 and len(scope['history'])==2
prediction=l.forward().prediction_tensor().snapshot().read_values()
actual=scope['model'](scope['x']).snapshot().read_values()
assert len(actual)==len(prediction)==18
assert all(abs(a-b)<=2e-5+2e-4*abs(b) for a,b in zip(actual,prediction))
l.reset_momentum()
for t in l.momentum_tensors(): assert all(v==0. for v in t.snapshot().read_values())
l.clear_momentum();assert l.momentum_damping is None
adapter=scope['device'].adapter_info();assert adapter['device_type'].lower()!='cpu'
del scope['learner'],l
history=[t.snapshot().read_values() for t in scope['history']]
assert any(v!=0. for tensor in history for v in tensor)
report=dict(status='passed',source=receipt['source'],library=str(library),
    library_sha256=receipt['products']['python-release.dylib'],code_sha256=digest(blocks[0].encode()),
    adapter=adapter,updates=32,microbatches=32,output_shape=[2,3,3],momentum=history,
    retained_history_after_reset_disable_drop=True,
    handoff_max_abs_error=max(abs(a-b) for a,b in zip(actual,prediction)),
    boundary='Unmodified guide code plus explicit history lifetime/reset checks, separate from the 69-stage run. This is weight-only handoff, not optimizer resume or quality/performance evidence.')
with (LOG/'docs-example.json').open('x') as stream:json.dump(report,stream,indent=2,allow_nan=False);stream.write('\n')
print(json.dumps(report))
