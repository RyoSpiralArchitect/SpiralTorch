"""Archive complete measurements and immutable source pairs without keeping binaries in Git."""
import hashlib
import io
import json
import lzma
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
RUN, MEASURE = LOG/'verified-a', LOG/'measurement-a'
CONTROL = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-inline-guard-20260912/verified-a')
OUT = ROOT/'benchmarks/results/2026-09-12-resident-momentum-fusion'
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
read = lambda p: json.loads(p.read_bytes())
digest = lambda b: hashlib.sha256(b).hexdigest()

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')

assert not OUT.exists()
assert not git('status', '--porcelain').strip()
run, measured = read(RUN/'receipt.json'), read(MEASURE/'receipt.json')
repeat = read(LOG/'measurement-b/receipt.json')
assert run['status'] == measured['status'] == 'passed' and 'active' not in run and 'active' not in measured
assert len(run['steps']) == 69 and len(measured['steps']) == 12
assert repeat['status'] == 'passed' and 'active' not in repeat and len(repeat['steps']) == 9
assert repeat['source'] == measured['source'] and repeat['first_receipt_sha256'] == sha(MEASURE/'receipt.json')
assert repeat['harness_sha256'] == sha(LOG/'repeat.py')
assert all(s['exit_code'] == 0 for r in [run, measured, repeat] for s in r['steps'])
source, baseline = measured['source'], measured['baseline_source']
assert source == run['source'] and git('rev-parse', 'HEAD').decode().strip() == source['commit']
for path, expected in measured['harness_sha256'].items(): assert sha(LOG/path) == expected
for path, expected in measured['products'].items(): assert sha(LOG/path) == expected
for path, expected in repeat['products'].items(): assert sha(LOG/path) == expected
assert sha(CONTROL/'receipt.json') == run['baseline_receipt_sha256']
assert sha(LOG/'run.py') == run['harness_sha256']
products = []
for role, folder in [('forward-control', CONTROL), ('benchmark-baseline', LOG/'baseline-a'),
                     ('benchmark-candidate', LOG/'candidate-a'), ('candidate-regression', RUN)]:
    receipt = read(folder/'receipt.json')
    assert receipt['status'] == 'passed'
    for name, expected in receipt['products'].items():
        path = folder/name
        assert sha(path) == expected
        products.append(dict(role=role, path=str(path), sha256=expected))
guide = read(LOG/'docs-example.json')
assert guide['status'] == 'passed' and guide['source'] == source
assert guide['library_sha256'] == run['products']['python-release.dylib']
torch = read(RUN/'torch-correctness.json')
assert torch['status'] == 'passed' and len(torch['cases']) == 432 and len(torch['reference_gaps']) == 4
for row in torch['inputs']: assert sha(Path(row['path'])) == row['sha256']
momentum = [c for c in torch['cases'] if c.get('topos_momentum')]
assert len(momentum) == 24
validations = {}
timings = []
for execution in ['measurement-a', 'measurement-b']:
    for mode in ['plain', 'topos_ema', 'clipped_topos_ema']:
        path = LOG/execution/(mode+'-validation.json')
        value = read(path)
        assert value['status'] == 'passed' and len(value['cases']) == 9
        assert value['learner_optimizer'] == (None if mode == 'plain' else mode)
        assert value['browser_intervals_revalidated'] == 360
        for row in value['inputs']: assert sha(Path(row['path'])) == row['sha256']
        validations[execution+'/'+mode] = dict(path=str(path), sha256=sha(path),
            source_bindings=value['source_bindings'], torch=value['torch'], browser_version=value['browser_version'],
            browser_assets=value['browser_assets'], browser_adapter_probe=value['browser_adapter_probe'],
            browser_intervals_revalidated=value['browser_intervals_revalidated'])
        for row in value['cases']:
            timings.append(dict(run=execution, mode=mode, config=row['config'], native=row['native'], browser=row['browser'],
                max_abs_error=max(row['max_abs_errors'].values())))
tests = {}
for path in RUN.glob('*.log'):
    content = path.read_text()
    rust = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', content)
    python = re.findall(r'^Ran (\d+) tests? in', content, re.MULTILINE)
    if rust or python:
        assert all(int(f) == 0 for _, f, _ in rust)
        tests[path.name] = dict(rust_passed=sum(int(p) for p, _, _ in rust),
            rust_ignored=sum(int(i) for _, _, i in rust), python_ran=sum(map(int, python)))
benchmark_files = [
    'bindings/st-wasm/tests/resident_training_bench.html',
    'crates/st-nn/examples/support/resident_training_bench.rs',
    'crates/st-nn/examples/support/resident_learner_bench.rs',
    'crates/st-nn/examples/support/resident_training_profile.rs',
    'crates/st-nn/examples/resident_training_bench.rs',
    'crates/st-nn/examples/resident_training_bench_browser.rs',
    'tools/bench_resident_training_browser.cjs', 'tools/bench_resident_training_vs_torch.py',
    'tools/resident_learner_bench_reference.py', 'tools/validate_resident_training_bench.py',
    'tests/test_resident_training_bench.py',
]
identities = {}
for name in benchmark_files:
    before = git('show', baseline['commit']+':'+name)
    after = git('show', source['commit']+':'+name)
    assert before == after
    identities[name] = digest(after)
files = {str(p.relative_to(LOG)): p for p in LOG.rglob('*') if p.is_file() and '__pycache__' not in p.parts
         and p.suffix in ('.json', '.jsonl', '.log', '.py', '.js', '.mjs', '.cjs', '.ts', '.html', '.md', '.stderr')}
names = set(git('diff', '--name-only', baseline['commit'], source['commit']).decode().splitlines())
names.update(benchmark_files)
names.update(['Cargo.toml', 'Cargo.lock', 'crates/st-backend-wgpu/Cargo.toml', 'crates/st-nn/Cargo.toml',
    'crates/st-kernel-contracts/src/momentum.rs', 'crates/st-kernel-contracts/src/gradient_clip.rs',
    'crates/st-backend-wgpu/src/shaders/gradient_composition.wgsl',
    'crates/st-backend-wgpu/src/shaders/gradient_source_guard.wgsl',
    'crates/st-backend-wgpu/src/shaders/graph_parameter.wgsl',
    'crates/st-backend-wgpu/src/shaders/dense_training.wgsl',
    'crates/st-backend-wgpu/src/resident_training/graph.rs',
    'crates/st-nn/examples/support/resident_graph_training/microbatch.rs',
    'tools/validate_resident_graph_training_vs_torch.py'])
(OUT/'raw').mkdir(parents=True)
entries = []

def archive(name, original, origin):
    path = OUT/'raw'/(name+'.xz')
    path.parent.mkdir(parents=True, exist_ok=True)
    h, size = hashlib.sha256(), 0
    stream = io.BytesIO(original) if isinstance(original, bytes) else original.open('rb')
    with stream, lzma.open(path, 'xb') as packed:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
            size += len(chunk)
            packed.write(chunk)
    entries.append(dict(archive=str(path.relative_to(OUT)), origin=origin, bytes=size, sha256=h.hexdigest(),
        compressed_bytes=path.stat().st_size, compressed_sha256=sha(path)))

for name, path in sorted(files.items()): archive('runs/'+name, path, dict(path=str(path)))
for name, path in [('forward-control-receipt.json', CONTROL/'receipt.json'),
                   ('python-client.py', Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py'))]:
    archive('inputs/'+name, path, dict(path=str(path)))
for role, ref in [('baseline', baseline['commit']), ('candidate', source['commit'])]:
    existing = set(git('ls-tree', '-r', '--name-only', ref).decode().splitlines())
    for name in sorted(names & existing):
        archive('source/'+role+'/'+name, git('show', ref+':'+name), dict(git_commit=ref, git_path=name))
manifest = dict(schema='spiraltorch.source_archive.v1', status='passed', records=entries,
    raw_bytes=sum(e['bytes'] for e in entries), compressed_bytes=sum(e['compressed_bytes'] for e in entries))
write(OUT/'manifest.json', manifest)
def matched(cases):
    return dict(version=torch['torch'], cases=len(cases), tensor_or_scalar_comparisons=sum(c['comparisons'] for c in cases),
        max_abs_error=max(c['max_abs_error'] for c in cases), devices=sorted({c['device'] for c in cases}))
summary = dict(schema='spiraltorch.resident_momentum_fusion_record.v1', status='passed',
    candidate_source=source, baseline_source=baseline, verification_steps=69, verification_seconds=run['seconds'],
    measurement_stages=12, measurement_seconds=measured['seconds'],
    repeat_stages=9, repeat_seconds=repeat['seconds'], repeat_reason=repeat['reason'],
    test_counts=tests, torch_all_matched=matched(torch['cases']), torch_momentum_matched=matched(momentum),
    existing_torch_reference_gaps=torch['reference_gaps'], validations=validations, timings=timings, docs_example=guide,
    unchanged_benchmark_sha256=identities, frozen_products_checked=len(products), products=products,
    raw_records=len(entries), manifest_sha256=sha(OUT/'manifest.json'),
    decision='Fuse policy normalization and optional clip scaling into EMA candidate preparation. Preserve global norm/validation, all-state commit and disabled-SGD execution. One fewer intermediate read/write and dispatch per parameter; reuse clipped bindings.',
    boundary=measured['boundary']+' Full regression has four separately labelled Torch tail-reference gaps and one ignored tensor-WGPU fractional-GL test. History checkpoint/resume remains unimplemented. No release, push or merge.')
write(OUT/'summary.json', summary)
print(json.dumps(dict(status='passed', records=len(entries), products=len(products),
    raw_bytes=manifest['raw_bytes'], compressed_bytes=manifest['compressed_bytes'],
    paired_recipes=len(timings), regression_comparisons=summary['torch_all_matched']['tensor_or_scalar_comparisons'])))
