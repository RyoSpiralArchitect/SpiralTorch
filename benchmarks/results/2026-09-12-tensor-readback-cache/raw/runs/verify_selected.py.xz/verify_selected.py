"""Verify restored production source and retained snapshot regressions."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
TARGET = ROOT.parent/'spiraltorch-spiralk-golden-blackcat-contract-v1/target'
LOG = Path(__file__).parent
OUT = LOG/'selected'
BASE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-inline-guard-20260912/verified-a')
P = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
BINDGEN = '/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen'
LOADER = '/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py'
if sys.argv[1:] == ['--launch']:
    if OUT.exists(): raise ValueError('selected verification exists; inspect rather than restart')
    with (LOG/'selected.log').open('xb') as log:
        child = subprocess.Popen([P, '-S', str(Path(__file__).resolve())], cwd=ROOT, stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps(dict(pid=child.pid, log=str(LOG/'selected.log')))); raise SystemExit(0)
if sys.argv[1:]: raise ValueError('--launch or no arguments')
OUT.mkdir()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_bytes())
base = read(BASE/'receipt.json'); assert base['status'] == 'passed'
source = dict(commit=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'))
assert not git('status', '--porcelain')
changes = git('diff', '--name-only', base['source']['commit'], 'HEAD').splitlines()
for name in changes:
    assert (name.startswith(('benchmarks/', 'docs/', 'tools/', 'bindings/st-py/tests/', 'bindings/st-wasm/tests/'))
            or name in ('crates/st-backend-wgpu/src/resident_tensor/tests.rs',
                        'crates/st-nn/examples/support/resident_nd_tensor.rs',
                        'crates/st-nn/examples/support/resident_tensor_snapshots.rs')), name
runtime_files = ['crates/st-backend-wgpu/src/runtime.rs', 'crates/st-backend-wgpu/src/resident_tensor.rs']
for name in runtime_files:
    assert (ROOT/name).read_bytes() == subprocess.check_output(['git', 'show', base['source']['commit']+':'+name], cwd=ROOT)
for name, digest in base['products'].items(): assert sha(BASE/name) == digest
env = dict(os.environ, CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='4', SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
report = dict(status='running', pid=os.getpid(), source=source, steps=[], products={},
    library_source_identical_to=base['source'], changed_nonproduction_paths=changes,
    runtime_sha256={name:sha(ROOT/name) for name in runtime_files},
    inherited_product_receipt_sha256=sha(BASE/'receipt.json'), harness_sha256=sha(Path(__file__)),
    boundary='Selected source restores the original library implementation and manifests exactly. Freshly built backend and native/browser N-D regression fixtures; original source-bound frozen Python/WASM/CPU libraries run the strengthened client tests. This is not a new selected performance measurement or a claim that rejected staging caches shipped.')

def save():
    temp=OUT/'receipt.json.tmp'; temp.write_text(json.dumps(report, indent=2)+'\n'); temp.replace(OUT/'receipt.json')

def run(name, args, output=None):
    args=[str(value) for value in args]; print('START', name, flush=True); start=time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        out=(OUT/output).open('xb') if output else log
        try:
            child=subprocess.Popen(args, cwd=ROOT, env=env, stdout=out, stderr=log if output else subprocess.STDOUT)
            report['active']=dict(name=name,pid=child.pid,command=args); save()
            try: code=child.wait(timeout=1800)
            except subprocess.TimeoutExpired:
                child.kill(); child.wait(); raise
        finally:
            if output: out.close()
    report.pop('active'); report['steps'].append(dict(name=name,exit_code=code,seconds=time.monotonic()-start,command=args)); save()
    print('END', name, code, flush=True)
    if code: raise RuntimeError(name)

def python(name, file, *args, cpu=False):
    run(name,[P,'-I',LOADER,BASE/('python-cpu.dylib' if cpu else 'python-release.dylib'),ROOT,file,*args])

C=['cargo','+1.98.0']
start=time.monotonic()
try:
    save()
    run('format',['cargo','+nightly-2026-04-15','fmt','--all','--','--check'])
    run('backend',C+['test','--locked','--release','-p','st-backend-wgpu','--lib','--','--test-threads=1'])
    python('python-tests','tests',OUT/'python-tests.json')
    python('python-module-forward','bindings/st-py/tests/test_nn_module_resident_forward.py','-v')
    run('module-browser',['node','tools/test_resident_browser.cjs',BASE/'client',CHROME,OUT/'module-browser.json','','','','','nn-module-forward'])
    run('native-nd-build',C+['build','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu','--example','resident_nd_tensor'])
    binary=TARGET/'release/examples/resident_nd_tensor'
    report['products'][str(binary)]=sha(binary); save()
    run('native-nd',[binary],output='native-nd.json')
    run('wasm-nd-build',C+['build','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu','--target','wasm32-unknown-unknown','--example','resident_nd_tensor_browser'])
    run('nd-bindgen',[BINDGEN,TARGET/'wasm32-unknown-unknown/release/examples/resident_nd_tensor_browser.wasm','--target','web','--out-dir',OUT/'nd','--out-name','spiraltorch_wasm'])
    for path in (OUT/'nd').rglob('*'):
        if path.is_file(): report['products'][str(path)]=sha(path)
    save()
    run('nd-browser',['node','tools/test_resident_browser.cjs',OUT/'nd',CHROME,OUT/'nd-browser.json','','','','','nd-tensor'])
    python('cpu-tensor-surface','bindings/st-py/tests/test_wgpu_tensor.py','TensorSurface','-v',cpu=True)
    python('cpu-module-surface','bindings/st-py/tests/test_nn_module_resident_forward.py','Surface','-v',cpu=True)
    python('cpu-handoff-surface','bindings/st-py/tests/test_nn_resident_module_update.py','Surface','-v',cpu=True)
    assert read(OUT/'module-browser.json')['tensor_readback_ownership'] is True
    assert read(OUT/'nd-browser.json')['tensor_snapshots']['cancelled_pending_maps']==4
    assert read(OUT/'native-nd.json')['tensor_snapshots']['held_snapshots']==24
    for name,digest in base['products'].items(): assert sha(BASE/name)==digest
    for name,digest in report['products'].items(): assert sha(Path(name))==digest
    for name,digest in report['runtime_sha256'].items(): assert sha(ROOT/name)==digest
    assert git('rev-parse','HEAD')==source['commit'] and not git('status','--porcelain')
    report['status']='passed'
except BaseException as error:
    report.update(status='error',error=repr(error)); raise
finally:
    report['seconds']=time.monotonic()-start; save()
