import { spiraltorchPreflightJsonString, spiraltorchSnapshotJsonCompatible } from './snippets/spiraltorch-wasm-2db06a8f9d36fd62/inline0.js';

let wasm;

let cachedUint8ArrayMemory0 = null;

function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let WASM_VECTOR_LEN = 0;

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    }
}

function passStringToWasm0(arg, malloc, realloc) {

    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }

    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

let cachedDataViewMemory0 = null;

function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_export_4.set(idx, obj);
    return idx;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedInt32ArrayMemory0 = null;

function getInt32ArrayMemory0() {
    if (cachedInt32ArrayMemory0 === null || cachedInt32ArrayMemory0.byteLength === 0) {
        cachedInt32ArrayMemory0 = new Int32Array(wasm.memory.buffer);
    }
    return cachedInt32ArrayMemory0;
}

function getArrayI32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getInt32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

let cachedUint32ArrayMemory0 = null;

function getUint32ArrayMemory0() {
    if (cachedUint32ArrayMemory0 === null || cachedUint32ArrayMemory0.byteLength === 0) {
        cachedUint32ArrayMemory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32ArrayMemory0;
}

function getArrayU32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

let cachedFloat32ArrayMemory0 = null;

function getFloat32ArrayMemory0() {
    if (cachedFloat32ArrayMemory0 === null || cachedFloat32ArrayMemory0.byteLength === 0) {
        cachedFloat32ArrayMemory0 = new Float32Array(wasm.memory.buffer);
    }
    return cachedFloat32ArrayMemory0;
}

function getArrayF32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getFloat32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

let cachedUint8ClampedArrayMemory0 = null;

function getUint8ClampedArrayMemory0() {
    if (cachedUint8ClampedArrayMemory0 === null || cachedUint8ClampedArrayMemory0.byteLength === 0) {
        cachedUint8ClampedArrayMemory0 = new Uint8ClampedArray(wasm.memory.buffer);
    }
    return cachedUint8ClampedArrayMemory0;
}

function getClampedArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ClampedArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}

const CLOSURE_DTORS = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(
state => {
    wasm.__wbindgen_export_5.get(state.dtor)(state.a, state.b);
}
);

function makeMutClosure(arg0, arg1, dtor, f) {
    const state = { a: arg0, b: arg1, cnt: 1, dtor };
    const real = (...args) => {

        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            if (--state.cnt === 0) {
                wasm.__wbindgen_export_5.get(state.dtor)(a, state.b);
                CLOSURE_DTORS.unregister(state);
            } else {
                state.a = a;
            }
        }
    };
    real.original = state;
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_export_4.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}
/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceFreeEnergyJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceFreeEnergyJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceFreeEnergyObject(request) {
    const ret = wasm.zspaceFreeEnergyObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {number} rows
 * @param {number} cols
 * @param {number} k
 * @param {boolean} subgroup
 * @returns {WasmFftPlan | undefined}
 */
export function auto_plan_fft(rows, cols, k, subgroup) {
    const ret = wasm.auto_plan_fft(rows, cols, k, subgroup);
    return ret === 0 ? undefined : WasmFftPlan.__wrap(ret);
}

/**
 * @param {number} rows
 * @param {number} cols
 * @param {number} k
 * @param {boolean} subgroup
 * @returns {string | undefined}
 */
export function auto_fft_wgsl(rows, cols, k, subgroup) {
    const ret = wasm.auto_fft_wgsl(rows, cols, k, subgroup);
    let v1;
    if (ret[0] !== 0) {
        v1 = getStringFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    }
    return v1;
}

/**
 * @param {number} rows
 * @param {number} cols
 * @param {number} k
 * @param {boolean} subgroup
 * @returns {string | undefined}
 */
export function auto_fft_spiralk(rows, cols, k, subgroup) {
    const ret = wasm.auto_fft_spiralk(rows, cols, k, subgroup);
    let v1;
    if (ret[0] !== 0) {
        v1 = getStringFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    }
    return v1;
}

/**
 * @param {number} rows
 * @param {number} cols
 * @param {number} k
 * @param {boolean} subgroup
 * @returns {string | undefined}
 */
export function auto_fft_plan_json(rows, cols, k, subgroup) {
    const ret = wasm.auto_fft_plan_json(rows, cols, k, subgroup);
    if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
    }
    let v1;
    if (ret[0] !== 0) {
        v1 = getStringFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    }
    return v1;
}

/**
 * @param {number} rows
 * @param {number} cols
 * @param {number} k
 * @param {boolean} subgroup
 * @returns {any}
 */
export function auto_fft_plan_object(rows, cols, k, subgroup) {
    const ret = wasm.auto_fft_plan_object(rows, cols, k, subgroup);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {Float32Array} buffer
 * @returns {Float32Array}
 */
export function fft_forward(buffer) {
    const ret = wasm.fft_forward(buffer);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {Float32Array} buffer
 * @returns {Float32Array}
 */
export function fft_inverse(buffer) {
    const ret = wasm.fft_inverse(buffer);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {Float32Array} buffer
 */
export function fft_forward_in_place(buffer) {
    const ret = wasm.fft_forward_in_place(buffer);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * @param {Float32Array} buffer
 */
export function fft_inverse_in_place(buffer) {
    const ret = wasm.fft_inverse_in_place(buffer);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Compute the baseline WGPU choice without consulting an override table.
 * @param {number} rows
 * @param {number} cols
 * @param {number} k
 * @param {boolean} subgroup
 * @returns {any}
 */
export function baseChoice(rows, cols, k, subgroup) {
    const ret = wasm.baseChoice(rows, cols, k, subgroup);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @returns {Array<any>}
 */
export function available_palettes() {
    const ret = wasm.available_palettes();
    return ret;
}

/**
 * @param {number} log_start
 * @param {number} log_step
 * @param {number} len
 * @returns {Float32Array}
 */
export function mellin_exp_decay_samples(log_start, log_step, len) {
    const ret = wasm.mellin_exp_decay_samples(log_start, log_step, len);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {number} log_start
 * @param {number} log_step
 * @param {number} len
 * @param {number} rate
 * @returns {Float32Array}
 */
export function mellin_exp_decay_samples_scaled(log_start, log_step, len, rate) {
    const ret = wasm.mellin_exp_decay_samples_scaled(log_start, log_step, len, rate);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}
/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspacePeriodicityJson(request_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.zspacePeriodicityJson(request_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspacePeriodicityObject(request) {
    const ret = wasm.zspacePeriodicityObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} report_json
 * @returns {string}
 */
export function validateZspacePeriodicityJson(report_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.validateZspacePeriodicityJson(report_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} report
 * @returns {any}
 */
export function validateZspacePeriodicityObject(report) {
    const ret = wasm.validateZspacePeriodicityObject(report);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} profile_json
 * @returns {string}
 */
export function toposRuntimeRouteJson(profile_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(profile_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.toposRuntimeRouteJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} profile
 * @returns {any}
 */
export function toposRuntimeRouteObject(profile) {
    const ret = wasm.toposRuntimeRouteObject(profile);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} receipt_json
 * @returns {string}
 */
export function tensorExecutionReceiptValidateJson(receipt_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(receipt_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.tensorExecutionReceiptValidateJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} receipt
 * @returns {any}
 */
export function tensorExecutionReceiptValidateObject(receipt) {
    const ret = wasm.tensorExecutionReceiptValidateObject(receipt);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} receipt_json
 * @param {string} runtime_plan_json
 * @returns {string}
 */
export function tensorExecutionReceiptValidateAgainstRuntimePlanJson(receipt_json, runtime_plan_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(receipt_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(runtime_plan_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.tensorExecutionReceiptValidateAgainstRuntimePlanJson(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * @param {any} receipt
 * @param {any} runtime_plan
 * @returns {any}
 */
export function tensorExecutionReceiptValidateAgainstRuntimePlanObject(receipt, runtime_plan) {
    const ret = wasm.tensorExecutionReceiptValidateAgainstRuntimePlanObject(receipt, runtime_plan);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceStochasticSchrodingerComplexStepJson(request_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.zspaceStochasticSchrodingerComplexStepJson(request_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {string} receipt_json
 * @returns {string}
 */
export function validateZspaceStochasticSchrodingerComplexJson(receipt_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.validateZspaceStochasticSchrodingerComplexJson(receipt_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function rankPlanJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.rankPlanJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function rankPlanObject(request) {
    const ret = wasm.rankPlanObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {Float32Array} field
 * @param {Uint32Array} shape
 * @param {Float32Array} scales
 * @param {number} threshold
 * @param {number} ambient_dim
 * @param {number} dimension_window
 * @param {Float32Array} levels
 * @returns {any}
 */
export function scalarScaleStackProbeObject(field, shape, scales, threshold, ambient_dim, dimension_window, levels) {
    const ret = wasm.scalarScaleStackProbeObject(field, shape, scales, threshold, ambient_dim, dimension_window, levels);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {Float32Array} field
 * @param {Uint32Array} shape
 * @param {Float32Array} scales
 * @param {number} threshold
 * @param {number} ambient_dim
 * @param {number} dimension_window
 * @param {Float32Array} levels
 * @returns {string}
 */
export function scalarScaleStackProbeJson(field, shape, scales, threshold, ambient_dim, dimension_window, levels) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.scalarScaleStackProbeJson(field, shape, scales, threshold, ambient_dim, dimension_window, levels);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {Float32Array} embeddings
 * @param {number} rows
 * @param {number} dims
 * @param {Float32Array} scales
 * @param {number} threshold
 * @param {string} metric
 * @param {number} ambient_dim
 * @param {number} dimension_window
 * @param {Float32Array} levels
 * @returns {any}
 */
export function semanticScaleStackProbeObject(embeddings, rows, dims, scales, threshold, metric, ambient_dim, dimension_window, levels) {
    const ptr0 = passStringToWasm0(metric, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.semanticScaleStackProbeObject(embeddings, rows, dims, scales, threshold, ptr0, len0, ambient_dim, dimension_window, levels);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {Float32Array} embeddings
 * @param {number} rows
 * @param {number} dims
 * @param {Float32Array} scales
 * @param {number} threshold
 * @param {string} metric
 * @param {number} ambient_dim
 * @param {number} dimension_window
 * @param {Float32Array} levels
 * @returns {string}
 */
export function semanticScaleStackProbeJson(embeddings, rows, dims, scales, threshold, metric, ambient_dim, dimension_window, levels) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(metric, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.semanticScaleStackProbeJson(embeddings, rows, dims, scales, threshold, ptr0, len0, ambient_dim, dimension_window, levels);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {string} checkpoint_json
 * @returns {string}
 */
export function trainerExternalStateCheckpointJson(checkpoint_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(checkpoint_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.trainerExternalStateCheckpointJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} checkpoint
 * @returns {any}
 */
export function trainerExternalStateCheckpointObject(checkpoint) {
    const ret = wasm.trainerExternalStateCheckpointObject(checkpoint);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceCoherenceProjectJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceCoherenceProjectJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceCoherenceProjectObject(request) {
    const ret = wasm.zspaceCoherenceProjectObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} normalized_weights_json
 * @returns {string}
 */
export function zspaceCoherenceDistributionWitnessJson(normalized_weights_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(normalized_weights_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceCoherenceDistributionWitnessJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} normalized_weights
 * @returns {any}
 */
export function zspaceCoherenceDistributionWitnessObject(normalized_weights) {
    const ret = wasm.zspaceCoherenceDistributionWitnessObject(normalized_weights);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} witness_json
 * @returns {string}
 */
export function zspaceCoherenceDistributionValidateJson(witness_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(witness_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceCoherenceDistributionValidateJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} witness
 * @returns {any}
 */
export function zspaceCoherenceDistributionValidateObject(witness) {
    const ret = wasm.zspaceCoherenceDistributionValidateObject(witness);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} config_json
 * @returns {string}
 */
export function trainerOptimizerConfigJson(config_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(config_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.trainerOptimizerConfigJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} config
 * @returns {any}
 */
export function trainerOptimizerConfigObject(config) {
    const ret = wasm.trainerOptimizerConfigObject(config);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} checkpoint_json
 * @returns {string}
 */
export function trainerOptimizerCheckpointJson(checkpoint_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(checkpoint_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.trainerOptimizerCheckpointJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} checkpoint
 * @returns {any}
 */
export function trainerOptimizerCheckpointObject(checkpoint) {
    const ret = wasm.trainerOptimizerCheckpointObject(checkpoint);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} bundle_json
 * @returns {string}
 */
export function trainerRuntimeCheckpointBundleJson(bundle_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(bundle_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.trainerRuntimeCheckpointBundleJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} bundle
 * @returns {any}
 */
export function trainerRuntimeCheckpointBundleObject(bundle) {
    const ret = wasm.trainerRuntimeCheckpointBundleObject(bundle);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceRepetitionUnlikelihoodPlanJson(request_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.zspaceRepetitionUnlikelihoodPlanJson(request_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceRepetitionUnlikelihoodPlanObject(request) {
    const ret = wasm.zspaceRepetitionUnlikelihoodPlanObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} plan_json
 * @returns {string}
 */
export function validateZspaceRepetitionUnlikelihoodPlanJson(plan_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.validateZspaceRepetitionUnlikelihoodPlanJson(plan_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} plan
 * @returns {any}
 */
export function validateZspaceRepetitionUnlikelihoodPlanObject(plan) {
    const ret = wasm.validateZspaceRepetitionUnlikelihoodPlanObject(plan);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Returns the native semantic contract version exposed by the browser client.
 * @returns {string}
 */
export function autogradContractVersion() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.autogradContractVersion();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

/**
 * Returns the crate that owns reverse-mode semantics.
 * @returns {string}
 */
export function autogradSemanticOwner() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.autogradSemanticOwner();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

function passArrayF32ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 4, 4) >>> 0;
    getFloat32ArrayMemory0().set(arg, ptr / 4);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArray32ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 4, 4) >>> 0;
    getUint32ArrayMemory0().set(arg, ptr / 4);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}
/**
 * @param {string} request_json
 * @returns {string}
 */
export function toposRoutePolicyEvaluateJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.toposRoutePolicyEvaluateJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function toposRoutePolicyEvaluateObject(request) {
    const ret = wasm.toposRoutePolicyEvaluateObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function toposRoutePolicyRewardsJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.toposRoutePolicyRewardsJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function toposRoutePolicyRewardsObject(request) {
    const ret = wasm.toposRoutePolicyRewardsObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function toposRoutePolicyResolveJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.toposRoutePolicyResolveJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function toposRoutePolicyResolveObject(request) {
    const ret = wasm.toposRoutePolicyResolveObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function runtimeDeviceRouteJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeDeviceRouteJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function runtimeDeviceRouteObject(request) {
    const ret = wasm.runtimeDeviceRouteObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function runtimeDeviceRouteFromProbesJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeDeviceRouteFromProbesJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function runtimeDeviceRouteFromProbesObject(request) {
    const ret = wasm.runtimeDeviceRouteFromProbesObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} payload_json
 * @returns {string}
 */
export function runtimeDeviceRouteValidateJson(payload_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(payload_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeDeviceRouteValidateJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} payload
 * @returns {any}
 */
export function runtimeDeviceRouteValidateObject(payload) {
    const ret = wasm.runtimeDeviceRouteValidateObject(payload);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} payload_json
 * @param {string} request_json
 * @returns {string}
 */
export function runtimeDeviceRouteValidateAgainstJson(payload_json, request_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(payload_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeDeviceRouteValidateAgainstJson(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * @param {any} payload
 * @param {any} request
 * @returns {any}
 */
export function runtimeDeviceRouteValidateAgainstObject(payload, request) {
    const ret = wasm.runtimeDeviceRouteValidateAgainstObject(payload, request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} payloads_json
 * @returns {string}
 */
export function zspaceTelemetryFusionJson(payloads_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(payloads_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceTelemetryFusionJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} payloads
 * @returns {any}
 */
export function zspaceTelemetryFusionObject(payloads) {
    const ret = wasm.zspaceTelemetryFusionObject(payloads);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspacePartialFusionJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspacePartialFusionJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspacePartialFusionObject(request) {
    const ret = wasm.zspacePartialFusionObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceMetricGradientProjectionJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceMetricGradientProjectionJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceMetricGradientProjectionObject(request) {
    const ret = wasm.zspaceMetricGradientProjectionObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function sealZspaceSemanticReviewPacketJson(request_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.sealZspaceSemanticReviewPacketJson(request_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function sealZspaceSemanticReviewPacketObject(request) {
    const ret = wasm.sealZspaceSemanticReviewPacketObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceSemanticReviewMapIdJson(request_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.zspaceSemanticReviewMapIdJson(request_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {string}
 */
export function zspaceSemanticReviewMapIdObject(request) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.zspaceSemanticReviewMapIdObject(request);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function unblindZspaceSemanticReviewJson(request_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.unblindZspaceSemanticReviewJson(request_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function unblindZspaceSemanticReviewObject(request) {
    const ret = wasm.unblindZspaceSemanticReviewObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} report_json
 * @returns {string}
 */
export function validateZspaceSemanticReviewUnblindJson(report_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.validateZspaceSemanticReviewUnblindJson(report_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} report
 * @returns {any}
 */
export function validateZspaceSemanticReviewUnblindObject(report) {
    const ret = wasm.validateZspaceSemanticReviewUnblindObject(report);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} packet_json
 * @returns {string}
 */
export function validateZspaceSemanticReviewPacketJson(packet_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.validateZspaceSemanticReviewPacketJson(packet_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} packet
 * @returns {any}
 */
export function validateZspaceSemanticReviewPacketObject(packet) {
    const ret = wasm.validateZspaceSemanticReviewPacketObject(packet);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} receipt_json
 * @returns {string}
 */
export function validateZspaceSemanticReviewPacketReceiptJson(receipt_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.validateZspaceSemanticReviewPacketReceiptJson(receipt_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} receipt
 * @returns {any}
 */
export function validateZspaceSemanticReviewPacketReceiptObject(receipt) {
    const ret = wasm.validateZspaceSemanticReviewPacketReceiptObject(receipt);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function summarizeZspaceSemanticReviewDraftJson(request_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.summarizeZspaceSemanticReviewDraftJson(request_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function summarizeZspaceSemanticReviewDraftObject(request) {
    const ret = wasm.summarizeZspaceSemanticReviewDraftObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} receipt_json
 * @returns {string}
 */
export function validateZspaceSemanticReviewDraftReceiptJson(receipt_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.validateZspaceSemanticReviewDraftReceiptJson(receipt_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} receipt
 * @returns {any}
 */
export function validateZspaceSemanticReviewDraftReceiptObject(receipt) {
    const ret = wasm.validateZspaceSemanticReviewDraftReceiptObject(receipt);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} config_json
 * @returns {string}
 */
export function zspaceMetaOptimizerInitJson(config_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(config_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceMetaOptimizerInitJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} config
 * @returns {any}
 */
export function zspaceOptimizerFeedbackInitObject(config) {
    const ret = wasm.zspaceOptimizerFeedbackInitObject(config);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceOptimizerFeedbackRestoreJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceOptimizerFeedbackRestoreJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceOptimizerFeedbackRestoreObject(request) {
    const ret = wasm.zspaceOptimizerFeedbackRestoreObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceOptimizerFeedbackObserveJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceOptimizerFeedbackObserveJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceOptimizerFeedbackObserveObject(request) {
    const ret = wasm.zspaceOptimizerFeedbackObserveObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceOptimizerFeedbackControlJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceOptimizerFeedbackControlJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceOptimizerFeedbackControlObject(request) {
    const ret = wasm.zspaceOptimizerFeedbackControlObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} config
 * @returns {any}
 */
export function zspaceMetaOptimizerInitObject(config) {
    const ret = wasm.zspaceMetaOptimizerInitObject(config);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceMetaOptimizerRestoreJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceMetaOptimizerRestoreJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceMetaOptimizerRestoreObject(request) {
    const ret = wasm.zspaceMetaOptimizerRestoreObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} source_report_json
 * @param {string} policy
 * @returns {string}
 */
export function zspaceParameterTrajectoryPolicyJson(source_report_json, policy) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(source_report_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(policy, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceParameterTrajectoryPolicyJson(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * @param {any} source_report
 * @param {string} policy
 * @returns {any}
 */
export function zspaceParameterTrajectoryPolicyObject(source_report, policy) {
    const ptr0 = passStringToWasm0(policy, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.zspaceParameterTrajectoryPolicyObject(source_report, ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} report_json
 * @returns {string}
 */
export function zspaceParameterTrajectoryPolicyValidateJson(report_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(report_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceParameterTrajectoryPolicyValidateJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} report
 * @returns {any}
 */
export function zspaceParameterTrajectoryPolicyValidateObject(report) {
    const ret = wasm.zspaceParameterTrajectoryPolicyValidateObject(report);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspacePolarityEvidenceJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspacePolarityEvidenceJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspacePolarityEvidenceObject(request) {
    const ret = wasm.zspacePolarityEvidenceObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} report_json
 * @returns {string}
 */
export function zspacePolarityEvidenceValidateJson(report_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(report_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspacePolarityEvidenceValidateJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} report
 * @returns {any}
 */
export function zspacePolarityEvidenceValidateObject(report) {
    const ret = wasm.zspacePolarityEvidenceValidateObject(report);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} config_json
 * @returns {string}
 */
export function zspaceOptimizerFeedbackInitJson(config_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(config_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceOptimizerFeedbackInitJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceMetaOptimizerStepJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceMetaOptimizerStepJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceMetaOptimizerStepObject(request) {
    const ret = wasm.zspaceMetaOptimizerStepObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} report_json
 * @returns {string}
 */
export function zspaceMetaOptimizerParameterControlJson(report_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(report_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceMetaOptimizerParameterControlJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} report
 * @returns {any}
 */
export function zspaceMetaOptimizerParameterControlObject(report) {
    const ret = wasm.zspaceMetaOptimizerParameterControlObject(report);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceParameterTrajectoryJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceParameterTrajectoryJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceParameterTrajectoryObject(request) {
    const ret = wasm.zspaceParameterTrajectoryObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} report_json
 * @returns {string}
 */
export function zspaceParameterTrajectoryValidateJson(report_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(report_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceParameterTrajectoryValidateJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} report
 * @returns {any}
 */
export function zspaceParameterTrajectoryValidateObject(report) {
    const ret = wasm.zspaceParameterTrajectoryValidateObject(report);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspacePosteriorDecodeJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspacePosteriorDecodeJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspacePosteriorDecodeObject(request) {
    const ret = wasm.zspacePosteriorDecodeObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspacePosteriorProjectJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspacePosteriorProjectJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspacePosteriorProjectObject(request) {
    const ret = wasm.zspacePosteriorProjectObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceConceptDiffusionJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceConceptDiffusionJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceConceptDiffusionObject(request) {
    const ret = wasm.zspaceConceptDiffusionObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceGenerationControlJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceGenerationControlJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceGenerationControlObject(request) {
    const ret = wasm.zspaceGenerationControlObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceTemperatureControlJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceTemperatureControlJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceTemperatureControlObject(request) {
    const ret = wasm.zspaceTemperatureControlObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function trainingTelemetryProjectionJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.trainingTelemetryProjectionJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function trainingTelemetryProjectionObject(request) {
    const ret = wasm.trainingTelemetryProjectionObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @returns {string}
 */
export function zspaceRuntimeProtocolCatalogJson() {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.zspaceRuntimeProtocolCatalogJson();
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @returns {any}
 */
export function zspaceRuntimeProtocolCatalogObject() {
    const ret = wasm.zspaceRuntimeProtocolCatalogObject();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} catalog_json
 * @returns {string}
 */
export function validateZspaceRuntimeProtocolCatalogJson(catalog_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.validateZspaceRuntimeProtocolCatalogJson(catalog_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceImaginaryTimeSchrodingerJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.zspaceImaginaryTimeSchrodingerJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceImaginaryTimeSchrodingerObject(request) {
    const ret = wasm.zspaceImaginaryTimeSchrodingerObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function apiLlmRoutePolicyEvaluateJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.apiLlmRoutePolicyEvaluateJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function apiLlmRoutePolicyEvaluateObject(request) {
    const ret = wasm.apiLlmRoutePolicyEvaluateObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceGenerationEvidenceJson(request_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.zspaceGenerationEvidenceJson(request_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function zspaceGenerationEvidenceObject(request) {
    const ret = wasm.zspaceGenerationEvidenceObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} report_json
 * @returns {string}
 */
export function validateZspaceGenerationEvidenceJson(report_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.validateZspaceGenerationEvidenceJson(report_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {any} report
 * @returns {any}
 */
export function validateZspaceGenerationEvidenceObject(report) {
    const ret = wasm.validateZspaceGenerationEvidenceObject(report);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {number} octaves
 * @param {number} lacunarity
 * @param {number} gain
 * @param {number} iterations
 * @param {number} log_start
 * @param {number} log_step
 * @param {number} len
 * @param {number} preview_len
 * @returns {any}
 */
export function fractalFieldProbeObject(octaves, lacunarity, gain, iterations, log_start, log_step, len, preview_len) {
    const ret = wasm.fractalFieldProbeObject(octaves, lacunarity, gain, iterations, log_start, log_step, len, preview_len);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {number} octaves
 * @param {number} lacunarity
 * @param {number} gain
 * @param {number} iterations
 * @param {number} log_start
 * @param {number} log_step
 * @param {number} len
 * @param {number} preview_len
 * @returns {string}
 */
export function fractalFieldProbeJson(octaves, lacunarity, gain, iterations, log_start, log_step, len, preview_len) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.fractalFieldProbeJson(octaves, lacunarity, gain, iterations, log_start, log_step, len, preview_len);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function runtimeDeviceProbeJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeDeviceProbeJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function runtimeDeviceProbeObject(request) {
    const ret = wasm.runtimeDeviceProbeObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function runtimeDeviceProbeObserveJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeDeviceProbeObserveJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function runtimeDeviceProbeObserveObject(request) {
    const ret = wasm.runtimeDeviceProbeObserveObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} payload_json
 * @returns {string}
 */
export function runtimeDeviceProbeValidateJson(payload_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(payload_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeDeviceProbeValidateJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} payload
 * @returns {any}
 */
export function runtimeDeviceProbeValidateObject(payload) {
    const ret = wasm.runtimeDeviceProbeValidateObject(payload);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} payload_json
 * @param {string} request_json
 * @returns {string}
 */
export function runtimeDeviceProbeValidateAgainstJson(payload_json, request_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(payload_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeDeviceProbeValidateAgainstJson(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * @param {any} payload
 * @param {any} request
 * @returns {any}
 */
export function runtimeDeviceProbeValidateAgainstObject(payload, request) {
    const ret = wasm.runtimeDeviceProbeValidateAgainstObject(payload, request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} input_json
 * @returns {string}
 */
export function toposControlSignalJson(input_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(input_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.toposControlSignalJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} input
 * @returns {any}
 */
export function toposControlSignalObject(input) {
    const ret = wasm.toposControlSignalObject(input);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} input_json
 * @returns {string}
 */
export function toposOptimizerSnapshotJson(input_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(input_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.toposOptimizerSnapshotJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} input
 * @returns {any}
 */
export function toposOptimizerSnapshotObject(input) {
    const ret = wasm.toposOptimizerSnapshotObject(input);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} input_json
 * @param {number} gradient_dim
 * @returns {string}
 */
export function toposZSpaceProjectionJson(input_json, gradient_dim) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(input_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.toposZSpaceProjectionJson(ptr0, len0, gradient_dim);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} input
 * @param {number} gradient_dim
 * @returns {any}
 */
export function toposZSpaceProjectionObject(input, gradient_dim) {
    const ret = wasm.toposZSpaceProjectionObject(input, gradient_dim);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function runtimeExecutionPlanJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeExecutionPlanJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function runtimeExecutionPlanObject(request) {
    const ret = wasm.runtimeExecutionPlanObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function runtimeExecutionPlanObserveCapabilitiesJson(request_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeExecutionPlanObserveCapabilitiesJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} request
 * @returns {any}
 */
export function runtimeExecutionPlanObserveCapabilitiesObject(request) {
    const ret = wasm.runtimeExecutionPlanObserveCapabilitiesObject(request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} payload_json
 * @returns {string}
 */
export function runtimeExecutionPlanValidateJson(payload_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(payload_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeExecutionPlanValidateJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} payload
 * @returns {any}
 */
export function runtimeExecutionPlanValidateObject(payload) {
    const ret = wasm.runtimeExecutionPlanValidateObject(payload);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} payload_json
 * @param {string} request_json
 * @returns {string}
 */
export function runtimeExecutionPlanValidateAgainstJson(payload_json, request_json) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(payload_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(request_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.runtimeExecutionPlanValidateAgainstJson(ptr0, len0, ptr1, len1);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * @param {any} payload
 * @param {any} request
 * @returns {any}
 */
export function runtimeExecutionPlanValidateAgainstObject(payload, request) {
    const ret = wasm.runtimeExecutionPlanValidateAgainstObject(payload, request);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} report_json
 * @returns {string}
 */
export function auditWasmReportJson(report_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(report_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.auditWasmReportJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} report
 * @returns {any}
 */
export function auditWasmReportObject(report) {
    const ret = wasm.auditWasmReportObject(report);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} reports_json
 * @returns {string}
 */
export function compareWasmReportsJson(reports_json) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(reports_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.compareWasmReportsJson(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * @param {any} reports
 * @returns {any}
 */
export function compareWasmReportsObject(reports) {
    const ret = wasm.compareWasmReportsObject(reports);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {number} log_start
 * @param {number} log_step
 * @param {Float32Array} samples
 * @param {string} window
 * @param {string} normalisation
 * @param {Float32Array} z_values
 * @param {number} preview_len
 * @returns {any}
 */
export function logZSeriesProbeObject(log_start, log_step, samples, window, normalisation, z_values, preview_len) {
    const ptr0 = passStringToWasm0(window, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(normalisation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ret = wasm.logZSeriesProbeObject(log_start, log_step, samples, ptr0, len0, ptr1, len1, z_values, preview_len);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {number} log_start
 * @param {number} log_step
 * @param {Float32Array} samples
 * @param {string} window
 * @param {string} normalisation
 * @param {Float32Array} z_values
 * @param {number} preview_len
 * @returns {string}
 */
export function logZSeriesProbeJson(log_start, log_step, samples, window, normalisation, z_values, preview_len) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(window, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(normalisation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.logZSeriesProbeJson(log_start, log_step, samples, ptr0, len0, ptr1, len1, z_values, preview_len);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceStochasticSchrodingerForwardJson(request_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.zspaceStochasticSchrodingerForwardJson(request_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {string} receipt_json
 * @returns {string}
 */
export function validateZspaceStochasticSchrodingerForwardJson(receipt_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.validateZspaceStochasticSchrodingerForwardJson(receipt_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {string} request_json
 * @returns {string}
 */
export function zspaceStochasticSchrodingerVjpJson(request_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.zspaceStochasticSchrodingerVjpJson(request_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {string} receipt_json
 * @returns {string}
 */
export function validateZspaceStochasticSchrodingerVjpJson(receipt_json) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.validateZspaceStochasticSchrodingerVjpJson(receipt_json);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

function __wbg_adapter_8(arg0, arg1, arg2) {
    wasm.closure1320_externref_shim(arg0, arg1, arg2);
}

function __wbg_adapter_11(arg0, arg1, arg2) {
    wasm.closure1315_externref_shim(arg0, arg1, arg2);
}

function __wbg_adapter_1168(arg0, arg1, arg2, arg3) {
    wasm.closure1344_externref_shim(arg0, arg1, arg2, arg3);
}

/**
 * @enum {0 | 1 | 2}
 */
export const WasmFftPlanSource = Object.freeze({
    Override: 0, "0": "Override",
    Heuristic: 1, "1": "Heuristic",
    Fallback: 2, "2": "Fallback",
});

const __wbindgen_enum_GpuDeviceLostReason = ["unknown", "destroyed"];

const __wbindgen_enum_GpuErrorFilter = ["validation", "out-of-memory", "internal"];

const __wbindgen_enum_GpuIndexFormat = ["uint16", "uint32"];

const __wbindgen_enum_GpuTextureFormat = ["r8unorm", "r8snorm", "r8uint", "r8sint", "r16uint", "r16sint", "r16float", "rg8unorm", "rg8snorm", "rg8uint", "rg8sint", "r32uint", "r32sint", "r32float", "rg16uint", "rg16sint", "rg16float", "rgba8unorm", "rgba8unorm-srgb", "rgba8snorm", "rgba8uint", "rgba8sint", "bgra8unorm", "bgra8unorm-srgb", "rgb9e5ufloat", "rgb10a2uint", "rgb10a2unorm", "rg11b10ufloat", "rg32uint", "rg32sint", "rg32float", "rgba16uint", "rgba16sint", "rgba16float", "rgba32uint", "rgba32sint", "rgba32float", "stencil8", "depth16unorm", "depth24plus", "depth24plus-stencil8", "depth32float", "depth32float-stencil8", "bc1-rgba-unorm", "bc1-rgba-unorm-srgb", "bc2-rgba-unorm", "bc2-rgba-unorm-srgb", "bc3-rgba-unorm", "bc3-rgba-unorm-srgb", "bc4-r-unorm", "bc4-r-snorm", "bc5-rg-unorm", "bc5-rg-snorm", "bc6h-rgb-ufloat", "bc6h-rgb-float", "bc7-rgba-unorm", "bc7-rgba-unorm-srgb", "etc2-rgb8unorm", "etc2-rgb8unorm-srgb", "etc2-rgb8a1unorm", "etc2-rgb8a1unorm-srgb", "etc2-rgba8unorm", "etc2-rgba8unorm-srgb", "eac-r11unorm", "eac-r11snorm", "eac-rg11unorm", "eac-rg11snorm", "astc-4x4-unorm", "astc-4x4-unorm-srgb", "astc-5x4-unorm", "astc-5x4-unorm-srgb", "astc-5x5-unorm", "astc-5x5-unorm-srgb", "astc-6x5-unorm", "astc-6x5-unorm-srgb", "astc-6x6-unorm", "astc-6x6-unorm-srgb", "astc-8x5-unorm", "astc-8x5-unorm-srgb", "astc-8x6-unorm", "astc-8x6-unorm-srgb", "astc-8x8-unorm", "astc-8x8-unorm-srgb", "astc-10x5-unorm", "astc-10x5-unorm-srgb", "astc-10x6-unorm", "astc-10x6-unorm-srgb", "astc-10x8-unorm", "astc-10x8-unorm-srgb", "astc-10x10-unorm", "astc-10x10-unorm-srgb", "astc-12x10-unorm", "astc-12x10-unorm-srgb", "astc-12x12-unorm", "astc-12x12-unorm-srgb"];

const AutogradPackedRhsFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_autogradpackedrhs_free(ptr >>> 0, 1));
/**
 * Frozen RHS whose source graph and packed storage are both owned by Rust.
 */
export class AutogradPackedRhs {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(AutogradPackedRhs.prototype);
        obj.__wbg_ptr = ptr;
        AutogradPackedRhsFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AutogradPackedRhsFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_autogradpackedrhs_free(ptr, 0);
    }
    /**
     * @returns {boolean}
     */
    requiresGrad() {
        const ret = wasm.autogradpackedrhs_requiresGrad(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    cols() {
        const ret = wasm.autogradpackedrhs_cols(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    rows() {
        const ret = wasm.autogradpackedrhs_rows(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {string}
     */
    sourceId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.autogradpackedrhs_sourceId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) AutogradPackedRhs.prototype[Symbol.dispose] = AutogradPackedRhs.prototype.free;

const AutogradSgdFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_autogradsgd_free(ptr >>> 0, 1));
/**
 * Plain CPU SGD with fresh immutable parameter handles after every step.
 */
export class AutogradSgd {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AutogradSgdFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_autogradsgd_free(ptr, 0);
    }
    /**
     * @param {AutogradTensor} parameter
     * @returns {number}
     */
    addParameter(parameter) {
        _assertClass(parameter, AutogradTensor);
        const ret = wasm.autogradsgd_addParameter(this.__wbg_ptr, parameter.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] >>> 0;
    }
    /**
     * @returns {number}
     */
    learningRate() {
        const ret = wasm.autogradsgd_learningRate(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    parameterCount() {
        const ret = wasm.autogradsgd_parameterCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} learning_rate
     */
    setLearningRate(learning_rate) {
        const ret = wasm.autogradsgd_setLearningRate(this.__wbg_ptr, learning_rate);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {number} learning_rate
     */
    constructor(learning_rate) {
        const ret = wasm.autogradsgd_new(learning_rate);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        AutogradSgdFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    step() {
        const ret = wasm.autogradsgd_step(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {number} index
     * @returns {AutogradTensor}
     */
    parameter(index) {
        const ret = wasm.autogradsgd_parameter(this.__wbg_ptr, index);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    zeroGrad() {
        wasm.autogradsgd_zeroGrad(this.__wbg_ptr);
    }
}
if (Symbol.dispose) AutogradSgd.prototype[Symbol.dispose] = AutogradSgd.prototype.free;

const AutogradTensorFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_autogradtensor_free(ptr >>> 0, 1));
/**
 * Browser handle over the same immutable graph used by native Rust and Python.
 */
export class AutogradTensor {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(AutogradTensor.prototype);
        obj.__wbg_ptr = ptr;
        AutogradTensorFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AutogradTensorFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_autogradtensor_free(ptr, 0);
    }
    /**
     * @param {any} indices
     * @returns {AutogradTensor}
     */
    gatherRows(indices) {
        const ret = wasm.autogradtensor_gatherRows(this.__wbg_ptr, indices);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @returns {AutogradPackedRhs}
     */
    prepackRhs() {
        const ret = wasm.autogradtensor_prepackRhs(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradPackedRhs.__wrap(ret[0]);
    }
    /**
     * @returns {AutogradTensor}
     */
    rowSoftmax() {
        const ret = wasm.autogradtensor_rowSoftmax(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @returns {boolean}
     */
    hasGradient() {
        const ret = wasm.autogradtensor_hasGradient(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {any}
     */
    graphSummary() {
        const ret = wasm.autogradtensor_graphSummary(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {boolean}
     */
    requiresGrad() {
        const ret = wasm.autogradtensor_requiresGrad(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {string}
     */
    operationName() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.autogradtensor_operationName(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {Float32Array}
     */
    gradientValues() {
        const ret = wasm.autogradtensor_gradientValues(this.__wbg_ptr);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {AutogradTensor}
     */
    rowLogSoftmax() {
        const ret = wasm.autogradtensor_rowLogSoftmax(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    zeroGradGraph() {
        wasm.autogradtensor_zeroGradGraph(this.__wbg_ptr);
    }
    /**
     * @param {AutogradPackedRhs} rhs
     * @returns {AutogradTensor}
     */
    matmulPrepacked(rhs) {
        _assertClass(rhs, AutogradPackedRhs);
        const ret = wasm.autogradtensor_matmulPrepacked(this.__wbg_ptr, rhs.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @param {any} indices
     * @param {number} output_rows
     * @returns {AutogradTensor}
     */
    scatterAddRows(indices, output_rows) {
        const ret = wasm.autogradtensor_scatterAddRows(this.__wbg_ptr, indices, output_rows);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * Affine row LayerNorm; omitted epsilon defaults to 1e-5.
     * @param {AutogradTensor} gamma
     * @param {AutogradTensor} beta
     * @param {number | null} [epsilon]
     * @returns {AutogradTensor}
     */
    layerNormAffine(gamma, beta, epsilon) {
        _assertClass(gamma, AutogradTensor);
        _assertClass(beta, AutogradTensor);
        const ret = wasm.autogradtensor_layerNormAffine(this.__wbg_ptr, gamma.__wbg_ptr, beta.__wbg_ptr, isLikeNone(epsilon) ? 0x100000001 : Math.fround(epsilon));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @param {Float32Array} values
     * @returns {any}
     */
    backwardWithGrad(values) {
        const ptr0 = passArrayF32ToWasm0(values, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.autogradtensor_backwardWithGrad(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {AutogradTensor} target
     * @returns {AutogradTensor}
     */
    meanSquaredError(target) {
        _assertClass(target, AutogradTensor);
        const ret = wasm.autogradtensor_meanSquaredError(this.__wbg_ptr, target.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @param {AutogradTensor} input
     * @param {Float32Array} values
     * @returns {Float32Array}
     */
    vectorJacobianProduct(input, values) {
        _assertClass(input, AutogradTensor);
        const ptr0 = passArrayF32ToWasm0(values, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.autogradtensor_vectorJacobianProduct(this.__wbg_ptr, input.__wbg_ptr, ptr0, len0);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v2;
    }
    /**
     * Integer-label logits loss. Optional arguments default to mean, -100 and zero smoothing.
     * @param {Int32Array} labels
     * @param {string | null} [reduction]
     * @param {number | null} [ignore_index]
     * @param {number | null} [label_smoothing]
     * @returns {AutogradTensor}
     */
    crossEntropyWithLogits(labels, reduction, ignore_index, label_smoothing) {
        const ptr0 = passArray32ToWasm0(labels, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(reduction) ? 0 : passStringToWasm0(reduction, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.autogradtensor_crossEntropyWithLogits(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(ignore_index) ? 0 : addToExternrefTable0(ignore_index), !isLikeNone(label_smoothing), isLikeNone(label_smoothing) ? 0 : label_smoothing);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @param {AutogradTensor} rhs
     * @returns {AutogradTensor}
     */
    add(rhs) {
        _assertClass(rhs, AutogradTensor);
        const ret = wasm.autogradtensor_add(this.__wbg_ptr, rhs.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @param {AutogradTensor} rhs
     * @returns {AutogradTensor}
     */
    dot(rhs) {
        _assertClass(rhs, AutogradTensor);
        const ret = wasm.autogradtensor_dot(this.__wbg_ptr, rhs.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @param {number} rows
     * @param {number} cols
     * @param {Float32Array} values
     * @param {boolean} requires_grad
     */
    constructor(rows, cols, values, requires_grad) {
        const ptr0 = passArrayF32ToWasm0(values, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.autogradtensor_new(rows, cols, ptr0, len0, requires_grad);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        AutogradTensorFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {AutogradTensor} rhs
     * @returns {AutogradTensor}
     */
    sub(rhs) {
        _assertClass(rhs, AutogradTensor);
        const ret = wasm.autogradtensor_sub(this.__wbg_ptr, rhs.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @returns {AutogradTensor}
     */
    sum() {
        const ret = wasm.autogradtensor_sum(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @returns {number}
     */
    cols() {
        const ret = wasm.autogradtensor_cols(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {AutogradTensor}
     */
    gelu() {
        const ret = wasm.autogradtensor_gelu(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @returns {number}
     */
    item() {
        const ret = wasm.autogradtensor_item(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @returns {AutogradTensor}
     */
    mean() {
        const ret = wasm.autogradtensor_mean(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @returns {AutogradTensor}
     */
    relu() {
        const ret = wasm.autogradtensor_relu(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @returns {number}
     */
    rows() {
        const ret = wasm.autogradtensor_rows(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} factor
     * @returns {AutogradTensor}
     */
    scale(factor) {
        const ret = wasm.autogradtensor_scale(this.__wbg_ptr, factor);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @returns {AutogradTensor}
     */
    detach() {
        const ret = wasm.autogradtensor_detach(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @param {AutogradTensor} rhs
     * @returns {AutogradTensor}
     */
    matmul(rhs) {
        _assertClass(rhs, AutogradTensor);
        const ret = wasm.autogradtensor_matmul(this.__wbg_ptr, rhs.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @returns {Float32Array}
     */
    values() {
        const ret = wasm.autogradtensor_values(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {AutogradTensor} bias
     * @returns {AutogradTensor}
     */
    addRow(bias) {
        _assertClass(bias, AutogradTensor);
        const ret = wasm.autogradtensor_addRow(this.__wbg_ptr, bias.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @returns {any}
     */
    backward() {
        const ret = wasm.autogradtensor_backward(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {AutogradTensor} rhs
     * @returns {AutogradTensor}
     */
    hadamard(rhs) {
        _assertClass(rhs, AutogradTensor);
        const ret = wasm.autogradtensor_hadamard(this.__wbg_ptr, rhs.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    /**
     * @returns {string}
     */
    id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.autogradtensor_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {AutogradTensor}
     */
    transpose() {
        const ret = wasm.autogradtensor_transpose(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return AutogradTensor.__wrap(ret[0]);
    }
    zeroGrad() {
        wasm.autogradtensor_zeroGrad(this.__wbg_ptr);
    }
}
if (Symbol.dispose) AutogradTensor.prototype[Symbol.dispose] = AutogradTensor.prototype.free;

const CanvasDesireControlFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_canvasdesirecontrol_free(ptr >>> 0, 1));

export class CanvasDesireControl {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CanvasDesireControl.prototype);
        obj.__wbg_ptr = ptr;
        CanvasDesireControlFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CanvasDesireControlFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_canvasdesirecontrol_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get clipFloor() {
        const ret = wasm.canvasdesirecontrol_clipFloor(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    eventsMask() {
        const ret = wasm.canvasdesirecontrol_eventsMask(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get tuningGain() {
        const ret = wasm.canvasdesirecontrol_tuningGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get clipCeiling() {
        const ret = wasm.canvasdesirecontrol_clipCeiling(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Array<any>}
     */
    eventLabels() {
        const ret = wasm.canvasdesirecontrol_eventLabels(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get operatorMix() {
        const ret = wasm.canvasdesirecontrol_operatorMix(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get penaltyGain() {
        const ret = wasm.canvasdesirecontrol_penaltyGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get qualityBias() {
        const ret = wasm.canvasdesirecontrol_qualityBias(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get qualityGain() {
        const ret = wasm.canvasdesirecontrol_qualityGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get operatorGain() {
        const ret = wasm.canvasdesirecontrol_operatorGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get targetEntropy() {
        const ret = wasm.canvasdesirecontrol_targetEntropy(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get observationGain() {
        const ret = wasm.canvasdesirecontrol_observationGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get temperatureSlew() {
        const ret = wasm.canvasdesirecontrol_temperatureSlew(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get learningRateEta() {
        const ret = wasm.canvasdesirecontrol_learningRateEta(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get learningRateMax() {
        const ret = wasm.canvasdesirecontrol_learningRateMax(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get learningRateMin() {
        const ret = wasm.canvasdesirecontrol_learningRateMin(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get temperatureKappa() {
        const ret = wasm.canvasdesirecontrol_temperatureKappa(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get learningRateSlew() {
        const ret = wasm.canvasdesirecontrol_learningRateSlew(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get realLearningRateScale() {
        const ret = wasm.canvasdesirecontrol_realLearningRateScale(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get hyperLearningRateScale() {
        const ret = wasm.canvasdesirecontrol_hyperLearningRateScale(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get damping() {
        const ret = wasm.canvasdesirecontrol_damping(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get biasMix() {
        const ret = wasm.canvasdesirecontrol_biasMix(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get clipEma() {
        const ret = wasm.canvasdesirecontrol_clipEma(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get clipNorm() {
        const ret = wasm.canvasdesirecontrol_clipNorm(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) CanvasDesireControl.prototype[Symbol.dispose] = CanvasDesireControl.prototype.free;

const CanvasDesireInterpretationFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_canvasdesireinterpretation_free(ptr >>> 0, 1));

export class CanvasDesireInterpretation {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CanvasDesireInterpretation.prototype);
        obj.__wbg_ptr = ptr;
        CanvasDesireInterpretationFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CanvasDesireInterpretationFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_canvasdesireinterpretation_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get saturation() {
        const ret = wasm.canvasdesirecontrol_hyperLearningRateScale(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get penaltyGain() {
        const ret = wasm.canvasdesirecontrol_realLearningRateScale(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get realPressure() {
        const ret = wasm.canvasdesirecontrol_biasMix(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get hyperPressure() {
        const ret = wasm.canvasdesirecontrol_penaltyGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get observationGain() {
        const ret = wasm.canvasdesirecontrol_operatorGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get balance() {
        const ret = wasm.canvasdesirecontrol_observationGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get biasMix() {
        const ret = wasm.canvasdesirecontrol_operatorMix(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get stability() {
        const ret = wasm.canvasdesirecontrol_damping(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) CanvasDesireInterpretation.prototype[Symbol.dispose] = CanvasDesireInterpretation.prototype.free;

const CanvasFftLayoutFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_canvasfftlayout_free(ptr >>> 0, 1));

export class CanvasFftLayout {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CanvasFftLayout.prototype);
        obj.__wbg_ptr = ptr;
        CanvasFftLayoutFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CanvasFftLayoutFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_canvasfftlayout_free(ptr, 0);
    }
    /**
     * Total byte length required for the `FieldSample` storage buffer.
     * @returns {number}
     */
    get fieldBytes() {
        const ret = wasm.canvasfftlayout_fieldBytes(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Size in bytes of each vector field sample.
     * @returns {number}
     */
    get fieldStride() {
        const ret = wasm.canvasfftlayout_fieldStride(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Byte length of the `CanvasFftParams` uniform buffer.
     * @returns {number}
     */
    get uniformBytes() {
        const ret = wasm.canvasfftlayout_uniformBytes(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Total byte length required for the FFT spectrum storage buffer.
     * @returns {number}
     */
    get spectrumBytes() {
        const ret = wasm.canvasfftlayout_spectrumBytes(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Size in bytes of each FFT spectrum sample.
     * @returns {number}
     */
    get spectrumStride() {
        const ret = wasm.canvasfftlayout_spectrumStride(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) CanvasFftLayout.prototype[Symbol.dispose] = CanvasFftLayout.prototype.free;

const CanvasFramePacketFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_canvasframepacket_free(ptr >>> 0, 1));

export class CanvasFramePacket {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CanvasFramePacket.prototype);
        obj.__wbg_ptr = ptr;
        CanvasFramePacketFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CanvasFramePacketFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_canvasframepacket_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get saturation() {
        const ret = wasm.canvasdesirecontrol_learningRateMax(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get eventsMask() {
        const ret = wasm.canvasframepacket_eventsMask(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get operatorMix() {
        const ret = wasm.canvasdesirecontrol_clipFloor(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get realgradRms() {
        const ret = wasm.canvasdesirecontrol_operatorGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get hypergradRms() {
        const ret = wasm.canvasdesirecontrol_operatorMix(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get operatorGain() {
        const ret = wasm.canvasdesirecontrol_clipCeiling(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get realgradCount() {
        const ret = wasm.canvasframepacket_realgradCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get hypergradCount() {
        const ret = wasm.canvasframepacket_hypergradCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get realLearningRateScale() {
        const ret = wasm.canvasdesirecontrol_clipNorm(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get hyperLearningRateScale() {
        const ret = wasm.canvasdesirecontrol_learningRateSlew(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Float32Array}
     */
    get field() {
        const ret = wasm.canvasframepacket_field(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Float32Array}
     */
    get trail() {
        const ret = wasm.canvasframepacket_trail(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get width() {
        const ret = wasm.canvasfftlayout_fieldBytes(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get height() {
        const ret = wasm.canvasfftlayout_fieldStride(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {Uint8Array}
     */
    get pixels() {
        const ret = wasm.canvasframepacket_pixels(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get balance() {
        const ret = wasm.canvasdesirecontrol_learningRateEta(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Float32Array}
     */
    get relation() {
        const ret = wasm.canvasframepacket_relation(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get stability() {
        const ret = wasm.canvasdesirecontrol_learningRateMin(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) CanvasFramePacket.prototype[Symbol.dispose] = CanvasFramePacket.prototype.free;

const CanvasGradientSummaryFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_canvasgradientsummary_free(ptr >>> 0, 1));

export class CanvasGradientSummary {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CanvasGradientSummary.prototype);
        obj.__wbg_ptr = ptr;
        CanvasGradientSummaryFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CanvasGradientSummaryFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_canvasgradientsummary_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get realgradL1() {
        const ret = wasm.canvasdesirecontrol_operatorMix(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get realgradL2() {
        const ret = wasm.canvasdesirecontrol_operatorGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get hypergradL1() {
        const ret = wasm.canvasdesirecontrol_penaltyGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get hypergradL2() {
        const ret = wasm.canvasdesirecontrol_biasMix(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get realgradRms() {
        const ret = wasm.canvasdesirecontrol_learningRateEta(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get hypergradRms() {
        const ret = wasm.canvasdesirecontrol_hyperLearningRateScale(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get realgradLInf() {
        const ret = wasm.canvasdesirecontrol_tuningGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get hypergradLInf() {
        const ret = wasm.canvasdesirecontrol_observationGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get realgradCount() {
        const ret = wasm.canvasgradientsummary_realgradCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get hypergradCount() {
        const ret = wasm.canvasgradientsummary_hypergradCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get realgradMeanAbs() {
        const ret = wasm.canvasdesirecontrol_targetEntropy(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get hypergradMeanAbs() {
        const ret = wasm.canvasdesirecontrol_damping(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) CanvasGradientSummary.prototype[Symbol.dispose] = CanvasGradientSummary.prototype.free;

const CobolDispatchPlannerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_coboldispatchplanner_free(ptr >>> 0, 1));

export class CobolDispatchPlanner {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(CobolDispatchPlanner.prototype);
        obj.__wbg_ptr = ptr;
        CobolDispatchPlannerFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CobolDispatchPlannerFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_coboldispatchplanner_free(ptr, 0);
    }
    /**
     * @returns {any}
     */
    cicsRoute() {
        const ret = wasm.coboldispatchplanner_cicsRoute(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {string}
     */
    get createdAt() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.coboldispatchplanner_createdAt(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    clearRoute() {
        wasm.coboldispatchplanner_clearRoute(this.__wbg_ptr);
    }
    /**
     * @param {any} value
     * @returns {CobolDispatchPlanner}
     */
    static fromObject(value) {
        const ret = wasm.coboldispatchplanner_fromObject(value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return CobolDispatchPlanner.__wrap(ret[0]);
    }
    /**
     * @param {any} value
     */
    loadObject(value) {
        const ret = wasm.coboldispatchplanner_loadObject(this.__wbg_ptr, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string | null} [dataset]
     */
    setDataset(dataset) {
        var ptr0 = isLikeNone(dataset) ? 0 : passStringToWasm0(dataset, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDataset(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {string} manager
     * @param {string} queue
     * @param {string | null} [commit]
     */
    setMqRoute(manager, queue, commit) {
        const ptr0 = passStringToWasm0(manager, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(queue, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(commit) ? 0 : passStringToWasm0(commit, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len2 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setMqRoute(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
    }
    clearDataset() {
        wasm.coboldispatchplanner_clearDataset(this.__wbg_ptr);
    }
    /**
     * @returns {string}
     */
    toCobolStub() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.coboldispatchplanner_toCobolStub(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {string} annotation
     */
    addAnnotation(annotation) {
        const ptr0 = passStringToWasm0(annotation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_addAnnotation(this.__wbg_ptr, ptr0, len0);
    }
    clearMetadata() {
        wasm.coboldispatchplanner_clearMetadata(this.__wbg_ptr);
    }
    clearMqRoute() {
        wasm.coboldispatchplanner_clearMqRoute(this.__wbg_ptr);
    }
    /**
     * @param {any} metadata
     */
    mergeMetadata(metadata) {
        const ret = wasm.coboldispatchplanner_mergeMetadata(this.__wbg_ptr, metadata);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} transaction
     * @param {string | null} [program]
     * @param {string | null} [channel]
     */
    setCicsRoute(transaction, program, channel) {
        const ptr0 = passStringToWasm0(transaction, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(program) ? 0 : passStringToWasm0(program, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(channel) ? 0 : passStringToWasm0(channel, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len2 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setCicsRoute(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
    }
    /**
     * @param {string} timestamp
     */
    setCreatedAt(timestamp) {
        const ptr0 = passStringToWasm0(timestamp, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setCreatedAt(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @returns {Uint8Array}
     */
    toUint8Array() {
        const ret = wasm.coboldispatchplanner_toUint8Array(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {boolean | null} [log]
     */
    setDatasetLog(log) {
        wasm.coboldispatchplanner_setDatasetLog(this.__wbg_ptr, isLikeNone(log) ? 0xFFFFFF : log ? 1 : 0);
    }
    clearCicsRoute() {
        wasm.coboldispatchplanner_clearCicsRoute(this.__wbg_ptr);
    }
    clearInitiators() {
        wasm.coboldispatchplanner_clearInitiators(this.__wbg_ptr);
    }
    resetCreatedAt() {
        wasm.coboldispatchplanner_resetCreatedAt(this.__wbg_ptr);
    }
    /**
     * @param {Float32Array} coefficients
     */
    setCoefficients(coefficients) {
        wasm.coboldispatchplanner_setCoefficients(this.__wbg_ptr, coefficients);
    }
    /**
     * @param {string | null} [like_dataset]
     */
    setDatasetLike(like_dataset) {
        var ptr0 = isLikeNone(like_dataset) ? 0 : passStringToWasm0(like_dataset, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetLike(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {string | null} [dataset_type]
     */
    setDatasetType(dataset_type) {
        var ptr0 = isLikeNone(dataset_type) ? 0 : passStringToWasm0(dataset_type, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetType(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {string | null} [unit]
     */
    setDatasetUnit(unit) {
        var ptr0 = isLikeNone(unit) ? 0 : passStringToWasm0(unit, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetUnit(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @returns {any}
     */
    toCobolPreview() {
        const ret = wasm.coboldispatchplanner_toCobolPreview(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {boolean | null} [reuse]
     */
    setDatasetReuse(reuse) {
        wasm.coboldispatchplanner_setDatasetReuse(this.__wbg_ptr, isLikeNone(reuse) ? 0xFFFFFF : reuse ? 1 : 0);
    }
    /**
     * @returns {Array<any>}
     */
    validationIssues() {
        const ret = wasm.coboldispatchplanner_validationIssues(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {string | null} [member]
     */
    setDatasetMember(member) {
        var ptr0 = isLikeNone(member) ? 0 : passStringToWasm0(member, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetMember(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {string | null} [volume]
     */
    setDatasetVolume(volume) {
        var ptr0 = isLikeNone(volume) ? 0 : passStringToWasm0(volume, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetVolume(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {string} name
     * @param {string | null} [persona]
     * @param {string | null} [contact]
     * @param {string | null} [note]
     */
    addHumanInitiator(name, persona, contact, note) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(persona) ? 0 : passStringToWasm0(persona, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(contact) ? 0 : passStringToWasm0(contact, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len2 = WASM_VECTOR_LEN;
        var ptr3 = isLikeNone(note) ? 0 : passStringToWasm0(note, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len3 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_addHumanInitiator(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
    }
    /**
     * @param {string} name
     * @param {string | null} [revision]
     * @param {string | null} [persona]
     * @param {string | null} [note]
     */
    addModelInitiator(name, revision, persona, note) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(revision) ? 0 : passStringToWasm0(revision, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(persona) ? 0 : passStringToWasm0(persona, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len2 = WASM_VECTOR_LEN;
        var ptr3 = isLikeNone(note) ? 0 : passStringToWasm0(note, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len3 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_addModelInitiator(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
    }
    /**
     * @param {number} curvature
     * @param {number} temperature
     * @param {string} encoder
     * @param {string | null} [locale]
     */
    setNarratorConfig(curvature, temperature, encoder, locale) {
        const ptr0 = passStringToWasm0(encoder, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(locale) ? 0 : passStringToWasm0(locale, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setNarratorConfig(this.__wbg_ptr, curvature, temperature, ptr0, len0, ptr1, len1);
    }
    /**
     * @param {string} channel
     */
    setReleaseChannel(channel) {
        const ptr0 = passStringToWasm0(channel, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setReleaseChannel(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @returns {Uint8Array}
     */
    coefficientsAsBytes() {
        const ret = wasm.coboldispatchplanner_coefficientsAsBytes(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number | null} [block_size]
     */
    setDatasetBlockSize(block_size) {
        wasm.coboldispatchplanner_setDatasetBlockSize(this.__wbg_ptr, isLikeNone(block_size) ? 0x100000001 : (block_size) >>> 0);
    }
    /**
     * @param {string | null} [data_class]
     */
    setDatasetDataClass(data_class) {
        var ptr0 = isLikeNone(data_class) ? 0 : passStringToWasm0(data_class, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetDataClass(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number | null} [key_length]
     */
    setDatasetKeyLength(key_length) {
        wasm.coboldispatchplanner_setDatasetKeyLength(this.__wbg_ptr, isLikeNone(key_length) ? 0x100000001 : (key_length) >>> 0);
    }
    /**
     * @param {number | null} [key_offset]
     */
    setDatasetKeyOffset(key_offset) {
        wasm.coboldispatchplanner_setDatasetKeyOffset(this.__wbg_ptr, isLikeNone(key_offset) ? 0x100000001 : (key_offset) >>> 0);
    }
    /**
     * @param {string | null} [space_unit]
     */
    setDatasetSpaceUnit(space_unit) {
        var ptr0 = isLikeNone(space_unit) ? 0 : passStringToWasm0(space_unit, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetSpaceUnit(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number | null} [unit_count]
     */
    setDatasetUnitCount(unit_count) {
        wasm.coboldispatchplanner_setDatasetUnitCount(this.__wbg_ptr, isLikeNone(unit_count) ? 0x100000001 : (unit_count) >>> 0);
    }
    /**
     * @param {string | null} [disposition]
     */
    setDatasetDisposition(disposition) {
        var ptr0 = isLikeNone(disposition) ? 0 : passStringToWasm0(disposition, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetDisposition(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {string} name
     * @param {string | null} [persona]
     * @param {string | null} [note]
     */
    addAutomationInitiator(name, persona, note) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(persona) ? 0 : passStringToWasm0(persona, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(note) ? 0 : passStringToWasm0(note, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len2 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_addAutomationInitiator(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
    }
    /**
     * @param {string | null} [organization]
     */
    setDatasetOrganization(organization) {
        var ptr0 = isLikeNone(organization) ? 0 : passStringToWasm0(organization, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetOrganization(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {string | null} [record_format]
     */
    setDatasetRecordFormat(record_format) {
        var ptr0 = isLikeNone(record_format) ? 0 : passStringToWasm0(record_format, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetRecordFormat(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number | null} [record_length]
     */
    setDatasetRecordLength(record_length) {
        wasm.coboldispatchplanner_setDatasetRecordLength(this.__wbg_ptr, isLikeNone(record_length) ? 0x100000001 : (record_length) >>> 0);
    }
    /**
     * @param {boolean | null} [release_space]
     */
    setDatasetReleaseSpace(release_space) {
        wasm.coboldispatchplanner_setDatasetReleaseSpace(this.__wbg_ptr, isLikeNone(release_space) ? 0xFFFFFF : release_space ? 1 : 0);
    }
    /**
     * @param {number | null} [space_primary]
     */
    setDatasetSpacePrimary(space_primary) {
        wasm.coboldispatchplanner_setDatasetSpacePrimary(this.__wbg_ptr, isLikeNone(space_primary) ? 0x100000001 : (space_primary) >>> 0);
    }
    /**
     * @param {string | null} [storage_class]
     */
    setDatasetStorageClass(storage_class) {
        var ptr0 = isLikeNone(storage_class) ? 0 : passStringToWasm0(storage_class, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetStorageClass(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {boolean | null} [erase_on_delete]
     */
    setDatasetEraseOnDelete(erase_on_delete) {
        wasm.coboldispatchplanner_setDatasetEraseOnDelete(this.__wbg_ptr, isLikeNone(erase_on_delete) ? 0xFFFFFF : erase_on_delete ? 1 : 0);
    }
    /**
     * @param {string | null} [expiration_date]
     */
    setDatasetExpirationDate(expiration_date) {
        var ptr0 = isLikeNone(expiration_date) ? 0 : passStringToWasm0(expiration_date, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetExpirationDate(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number | null} [space_secondary]
     */
    setDatasetSpaceSecondary(space_secondary) {
        wasm.coboldispatchplanner_setDatasetSpaceSecondary(this.__wbg_ptr, isLikeNone(space_secondary) ? 0x100000001 : (space_secondary) >>> 0);
    }
    /**
     * @param {string | null} [catalog_behavior]
     */
    setDatasetCatalogBehavior(catalog_behavior) {
        var ptr0 = isLikeNone(catalog_behavior) ? 0 : passStringToWasm0(catalog_behavior, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetCatalogBehavior(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number | null} [directory_blocks]
     */
    setDatasetDirectoryBlocks(directory_blocks) {
        wasm.coboldispatchplanner_setDatasetDirectoryBlocks(this.__wbg_ptr, isLikeNone(directory_blocks) ? 0x100000001 : (directory_blocks) >>> 0);
    }
    /**
     * @param {string | null} [management_class]
     */
    setDatasetManagementClass(management_class) {
        var ptr0 = isLikeNone(management_class) ? 0 : passStringToWasm0(management_class, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetManagementClass(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number | null} [retention_period]
     */
    setDatasetRetentionPeriod(retention_period) {
        wasm.coboldispatchplanner_setDatasetRetentionPeriod(this.__wbg_ptr, isLikeNone(retention_period) ? 0x100000001 : (retention_period) >>> 0);
    }
    /**
     * @param {string | null} [average_record_unit]
     */
    setDatasetAverageRecordUnit(average_record_unit) {
        var ptr0 = isLikeNone(average_record_unit) ? 0 : passStringToWasm0(average_record_unit, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_setDatasetAverageRecordUnit(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number | null} [control_interval_size]
     */
    setDatasetControlIntervalSize(control_interval_size) {
        wasm.coboldispatchplanner_setDatasetControlIntervalSize(this.__wbg_ptr, isLikeNone(control_interval_size) ? 0x100000001 : (control_interval_size) >>> 0);
    }
    /**
     * @param {number | null} [share_options_cross_region]
     */
    setDatasetShareOptionsCrossRegion(share_options_cross_region) {
        wasm.coboldispatchplanner_setDatasetShareOptionsCrossRegion(this.__wbg_ptr, isLikeNone(share_options_cross_region) ? 0x100000001 : (share_options_cross_region) >>> 0);
    }
    /**
     * @param {number | null} [share_options_cross_system]
     */
    setDatasetShareOptionsCrossSystem(share_options_cross_system) {
        wasm.coboldispatchplanner_setDatasetShareOptionsCrossSystem(this.__wbg_ptr, isLikeNone(share_options_cross_system) ? 0x100000001 : (share_options_cross_system) >>> 0);
    }
    /**
     * @param {string} job_id
     * @param {string | null} [release_channel]
     */
    constructor(job_id, release_channel) {
        const ptr0 = passStringToWasm0(job_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(release_channel) ? 0 : passStringToWasm0(release_channel, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.coboldispatchplanner_new(ptr0, len0, ptr1, len1);
        this.__wbg_ptr = ret >>> 0;
        CobolDispatchPlannerFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {string} tag
     */
    addTag(tag) {
        const ptr0 = passStringToWasm0(tag, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.coboldispatchplanner_addTag(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @returns {string}
     */
    toJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.coboldispatchplanner_toJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @returns {boolean}
     */
    isValid() {
        const ret = wasm.coboldispatchplanner_isValid(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {any}
     */
    mqRoute() {
        const ret = wasm.coboldispatchplanner_mqRoute(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {string} json
     * @returns {CobolDispatchPlanner}
     */
    static fromJson(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.coboldispatchplanner_fromJson(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return CobolDispatchPlanner.__wrap(ret[0]);
    }
    /**
     * @param {string} json
     */
    loadJson(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.coboldispatchplanner_loadJson(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {any}
     */
    toObject() {
        const ret = wasm.coboldispatchplanner_toObject(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) CobolDispatchPlanner.prototype[Symbol.dispose] = CobolDispatchPlanner.prototype.free;

const FractalCanvasFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fractalcanvas_free(ptr >>> 0, 1));

export class FractalCanvas {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FractalCanvasFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fractalcanvas_free(ptr, 0);
    }
    /**
     * Push a new fractal relation patch into the scheduler.
     *
     * The input buffer must contain `width * height` values laid out in row-major
     * order.
     * @param {Float32Array} relation
     * @param {number} coherence
     * @param {number} tension
     * @param {number} depth
     */
    push_patch(relation, coherence, tension, depth) {
        const ret = wasm.fractalcanvas_push_patch(this.__wbg_ptr, relation, coherence, tension, depth);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Switch the active colour palette.
     * @param {string} name
     */
    set_palette(name) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.fractalcanvas_set_palette(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Refresh the canvas once and return a compact packet with the current
     * RGBA pixels, relation tensor, colour field, hyperbolic trail, and
     * gradient-derived Desire signals. Use this when you want to drive
     * multiple visualisations (2D canvas, WebGPU trails, telemetry) without
     * re-rendering the canvas for each query.
     * @param {number} curvature
     * @returns {CanvasFramePacket}
     */
    framePacket(curvature) {
        const ret = wasm.fractalcanvas_framePacket(this.__wbg_ptr, curvature);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return CanvasFramePacket.__wrap(ret[0]);
    }
    /**
     * Refresh the projector and expose the colour vector field as a `Float32Array`.
     * @returns {Float32Array}
     */
    vector_field() {
        const ret = wasm.fractalcanvas_vector_field(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Refresh the projector and emit the Euclidean gradient update for the
     * current canvas relation.
     * @returns {Float32Array}
     */
    realgradWave() {
        const ret = wasm.fractalcanvas_realgradWave(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Refresh the projector and collapse the gradient summaries into Desire's
     * control packet, exposing precomputed gains and learning-rate scales.
     * @param {number} curvature
     * @returns {CanvasDesireControl}
     */
    desireControl(curvature) {
        const ret = wasm.fractalcanvas_desireControl(this.__wbg_ptr, curvature);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return CanvasDesireControl.__wrap(ret[0]);
    }
    /**
     * Refresh the projector and emit the hypergradient-aligned update for the
     * current canvas relation.
     * @param {number} curvature
     * @returns {Float32Array}
     */
    hypergradWave(curvature) {
        const ret = wasm.fractalcanvas_hypergradWave(this.__wbg_ptr, curvature);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Refresh the projector and emit the AR particle trail for the current
     * vector field. Each particle contributes `(x, y, z, energy, r, g, b)` so
     * WebGPU/WebXR callers can upload the buffer without additional packing.
     * @param {number} curvature
     * @returns {Float32Array}
     */
    emitWasmTrail(curvature) {
        const ret = wasm.fractalcanvas_emitWasmTrail(this.__wbg_ptr, curvature);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Summarise the current canvas relation across both the hypergradient and
     * Euclidean tapes. The returned object exposes the common norms so callers
     * can monitor gradient stability without materialising the full buffers.
     * @param {number} curvature
     * @returns {CanvasGradientSummary}
     */
    gradientSummary(curvature) {
        const ret = wasm.fractalcanvas_gradientSummary(this.__wbg_ptr, curvature);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return CanvasGradientSummary.__wrap(ret[0]);
    }
    /**
     * Render the current scheduler state onto the provided HTML canvas.
     * @param {HTMLCanvasElement} canvas
     */
    render_to_canvas(canvas) {
        const ret = wasm.fractalcanvas_render_to_canvas(this.__wbg_ptr, canvas);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Reset the internal normaliser so the next frame recomputes brightness ranges.
     */
    reset_normalizer() {
        wasm.fractalcanvas_reset_normalizer(this.__wbg_ptr);
    }
    /**
     * Refresh the projector and return the interleaved FFT spectrum for each
     * canvas row. Each frequency sample contributes eight floats (real/imag
     * pairs for energy + RGB chroma).
     * @param {boolean} inverse
     * @returns {Float32Array}
     */
    vectorFieldFft(inverse) {
        const ret = wasm.fractalcanvas_vectorFieldFft(this.__wbg_ptr, inverse);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Refresh the projector and interpret the gradient health into Desire's
     * feedback coordinates.
     * @param {number} curvature
     * @returns {CanvasDesireInterpretation}
     */
    desireInterpretation(curvature) {
        const ret = wasm.fractalcanvas_desireInterpretation(this.__wbg_ptr, curvature);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return CanvasDesireInterpretation.__wrap(ret[0]);
    }
    /**
     * Compute the Euclidean wave update against the current relation tensor
     * without refreshing the canvas first.
     * @returns {Float32Array}
     */
    realgradWaveCurrent() {
        const ret = wasm.fractalcanvas_realgradWaveCurrent(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Refresh the projector, derive Desire's control packet, and pack it into
     * a WGSL-friendly uniform layout. The returned `Uint32Array` holds the raw
     * IEEE-754 bits so callers can reinterpret the underlying buffer as a
     * `Float32Array` when uploading to WebGPU.
     * @param {number} curvature
     * @returns {Uint32Array}
     */
    desireControlUniform(curvature) {
        const ret = wasm.fractalcanvas_desireControlUniform(this.__wbg_ptr, curvature);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Compute the hypergradient wave update against the current relation
     * tensor without refreshing the canvas first. Use `framePacket()` or
     * `render_to_canvas()` to refresh the internal state before calling this.
     * @param {number} curvature
     * @returns {Float32Array}
     */
    hypergradWaveCurrent(curvature) {
        const ret = wasm.fractalcanvas_hypergradWaveCurrent(this.__wbg_ptr, curvature);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Emit the WGSL kernel that mirrors [`vector_field_fft`] so WebGPU
     * consumers can reproduce the spectral pass directly on the GPU.
     * @param {boolean} subgroup
     * @returns {string}
     */
    vectorFieldFftKernel(subgroup) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.fractalcanvas_vectorFieldFftKernel(this.__wbg_ptr, subgroup);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Byte layout metadata mirroring the WGSL `FieldSample`, `SpectrumSample`
     * and uniform structs so WebGPU callers can size buffers without manual
     * calculations.
     * @returns {CanvasFftLayout}
     */
    vectorFieldFftLayout() {
        const ret = wasm.fractalcanvas_vectorFieldFftLayout(this.__wbg_ptr);
        return CanvasFftLayout.__wrap(ret);
    }
    /**
     * Generate the uniform parameters expected by [`vector_field_fft_kernel`].
     *
     * The returned array packs the canvas `width`, `height`, the `inverse`
     * flag (1 = inverse, 0 = forward) and a padding slot so the buffer aligns
     * to 16 bytes as required by WGSL uniform layout rules.
     * @param {boolean} inverse
     * @returns {Uint32Array}
     */
    vectorFieldFftUniform(inverse) {
        const ret = wasm.fractalcanvas_vectorFieldFftUniform(this.__wbg_ptr, inverse);
        return ret;
    }
    /**
     * Emit the WGSL kernel that accumulates the relation tensor directly into
     * a hypergradient buffer without leaving the GPU.
     * @param {boolean} subgroup
     * @returns {string}
     */
    hypergradOperatorKernel(subgroup) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.fractalcanvas_hypergradOperatorKernel(this.__wbg_ptr, subgroup);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Compute the workgroup dispatch dimensions that pair with
     * [`vector_field_fft_kernel`]. The returned `[x, y, z]` triplet already
     * accounts for the workgroup size when toggling subgroup execution.
     * @param {boolean} subgroup
     * @returns {Uint32Array}
     */
    vectorFieldFftDispatch(subgroup) {
        const ret = wasm.fractalcanvas_vectorFieldFftDispatch(this.__wbg_ptr, subgroup);
        return ret;
    }
    /**
     * Uniform parameters (width, height, blend, gain) consumed by the
     * hypergradient WGSL operator.
     * @param {number} mix
     * @param {number} gain
     * @returns {Float32Array}
     */
    hypergradOperatorUniform(mix, gain) {
        const ret = wasm.fractalcanvas_hypergradOperatorUniform(this.__wbg_ptr, mix, gain);
        return ret;
    }
    /**
     * Workgroup dispatch dimensions matching `hypergradOperatorKernel`.
     * @param {boolean} subgroup
     * @returns {Uint32Array}
     */
    hypergradOperatorDispatch(subgroup) {
        const ret = wasm.fractalcanvas_hypergradOperatorDispatch(this.__wbg_ptr, subgroup);
        return ret;
    }
    /**
     * Refresh the canvas, derive the Desire control packet, and emit the
     * matching hypergradient operator uniform in a single step.
     * @param {number} curvature
     * @returns {Float32Array}
     */
    hypergradOperatorUniformAuto(curvature) {
        const ret = wasm.fractalcanvas_hypergradOperatorUniformAuto(this.__wbg_ptr, curvature);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Compute the hypergradient operator uniform directly from the current
     * Desire control packet. Useful when the control data is computed once on
     * the Rust side and then cached in JavaScript.
     * @param {CanvasDesireControl} control
     * @returns {Float32Array}
     */
    hypergradOperatorUniformFromControl(control) {
        _assertClass(control, CanvasDesireControl);
        const ret = wasm.fractalcanvas_hypergradOperatorUniformFromControl(this.__wbg_ptr, control.__wbg_ptr);
        return ret;
    }
    /**
     * Construct a projector-backed canvas with the requested queue capacity.
     * @param {number} capacity
     * @param {number} width
     * @param {number} height
     */
    constructor(capacity, width, height) {
        const ret = wasm.fractalcanvas_new(capacity, width, height);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        FractalCanvasFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Canvas width in pixels.
     * @returns {number}
     */
    get width() {
        const ret = wasm.fractalcanvas_width(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Canvas height in pixels.
     * @returns {number}
     */
    get height() {
        const ret = wasm.fractalcanvas_height(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Refresh the projector and return a view of the RGBA buffer as a typed array.
     * @returns {Uint8Array}
     */
    pixels() {
        const ret = wasm.fractalcanvas_pixels(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Current palette name.
     * @returns {string}
     */
    palette() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.fractalcanvas_palette(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Refresh the projector and expose the raw relation tensor feeding the canvas.
     * @returns {Float32Array}
     */
    relation() {
        const ret = wasm.fractalcanvas_relation(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) FractalCanvas.prototype[Symbol.dispose] = FractalCanvas.prototype.free;

const GraphForwardFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_graphforward_free(ptr >>> 0, 1));

export class GraphForward {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(GraphForward.prototype);
        obj.__wbg_ptr = ptr;
        GraphForwardFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GraphForwardFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_graphforward_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get inputGeneration() {
        const ret = wasm.graphforward_inputGeneration(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {WgpuTensor}
     */
    predictionTensor() {
        const ret = wasm.graphforward_predictionTensor(this.__wbg_ptr);
        return WgpuTensor.__wrap(ret);
    }
    /**
     * @returns {bigint}
     */
    get submittedForward() {
        const ret = wasm.graphforward_submittedForward(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) GraphForward.prototype[Symbol.dispose] = GraphForward.prototype.free;

const GraphGradientBatchFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_graphgradientbatch_free(ptr >>> 0, 1));

export class GraphGradientBatch {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GraphGradientBatchFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_graphgradientbatch_free(ptr, 0);
    }
    /**
     * @param {GraphGradients} gradients
     * @param {number} weight
     */
    add(gradients, weight) {
        _assertClass(gradients, GraphGradients);
        const ret = wasm.graphgradientbatch_add(this.__wbg_ptr, gradients.__wbg_ptr, weight);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    constructor() {
        const ret = wasm.graphgradientbatch_new();
        this.__wbg_ptr = ret >>> 0;
        GraphGradientBatchFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {number}
     */
    get length() {
        const ret = wasm.graphgradientbatch_length(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) GraphGradientBatch.prototype[Symbol.dispose] = GraphGradientBatch.prototype.free;

const GraphGradientsFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_graphgradients_free(ptr >>> 0, 1));

export class GraphGradients {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(GraphGradients.prototype);
        obj.__wbg_ptr = ptr;
        GraphGradientsFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GraphGradientsFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_graphgradients_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get parameterCount() {
        const ret = wasm.graphgradients_parameterCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {bigint}
     */
    get inputGeneration() {
        const ret = wasm.graphgradients_inputGeneration(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get submittedForward() {
        const ret = wasm.graphgradients_submittedForward(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get submittedBackward() {
        const ret = wasm.graphgradients_submittedBackward(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {WgpuTensor}
     */
    inputGradientTensor() {
        const ret = wasm.graphgradients_inputGradientTensor(this.__wbg_ptr);
        return WgpuTensor.__wrap(ret);
    }
    /**
     * @param {number} index
     * @returns {WgpuTensor}
     */
    parameterGradientTensor(index) {
        const ret = wasm.graphgradients_parameterGradientTensor(this.__wbg_ptr, index);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
}
if (Symbol.dispose) GraphGradients.prototype[Symbol.dispose] = GraphGradients.prototype.free;

const GraphInferenceSnapshotFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_graphinferencesnapshot_free(ptr >>> 0, 1));

export class GraphInferenceSnapshot {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(GraphInferenceSnapshot.prototype);
        obj.__wbg_ptr = ptr;
        GraphInferenceSnapshotFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GraphInferenceSnapshotFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_graphinferencesnapshot_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get generation() {
        const ret = wasm.graphinferencesnapshot_generation(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {Promise<Float32Array>}
     */
    readValues() {
        const ret = wasm.graphinferencesnapshot_readValues(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {bigint}
     */
    get submittedDispatch() {
        const ret = wasm.graphinferencesnapshot_submittedDispatch(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {Uint32Array}
     */
    get shape() {
        const ret = wasm.graphinferencesnapshot_shape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) GraphInferenceSnapshot.prototype[Symbol.dispose] = GraphInferenceSnapshot.prototype.free;

const GraphTrainingParametersSnapshotFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_graphtrainingparameterssnapshot_free(ptr >>> 0, 1));

export class GraphTrainingParametersSnapshot {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(GraphTrainingParametersSnapshot.prototype);
        obj.__wbg_ptr = ptr;
        GraphTrainingParametersSnapshotFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GraphTrainingParametersSnapshotFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_graphtrainingparameterssnapshot_free(ptr, 0);
    }
    /**
     * @returns {Promise<InferencePlan>}
     */
    readPlan() {
        const ret = wasm.graphtrainingparameterssnapshot_readPlan(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) GraphTrainingParametersSnapshot.prototype[Symbol.dispose] = GraphTrainingParametersSnapshot.prototype.free;

const GraphTrainingSnapshotFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_graphtrainingsnapshot_free(ptr >>> 0, 1));

export class GraphTrainingSnapshot {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(GraphTrainingSnapshot.prototype);
        obj.__wbg_ptr = ptr;
        GraphTrainingSnapshotFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GraphTrainingSnapshotFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_graphtrainingsnapshot_free(ptr, 0);
    }
    /**
     * @returns {Promise<GraphTrainingState>}
     */
    readState() {
        const ret = wasm.graphtrainingsnapshot_readState(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get inputShape() {
        const ret = wasm.graphtrainingsnapshot_inputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {Uint32Array}
     */
    get outputShape() {
        const ret = wasm.graphtrainingsnapshot_outputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {bigint}
     */
    get submittedStep() {
        const ret = wasm.graphtrainingsnapshot_submittedStep(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {string}
     */
    get gradientPolicy() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.graphtrainingsnapshot_gradientPolicy(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {bigint}
     */
    get batchGeneration() {
        const ret = wasm.graphtrainingsnapshot_batchGeneration(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) GraphTrainingSnapshot.prototype[Symbol.dispose] = GraphTrainingSnapshot.prototype.free;

const GraphTrainingStateFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_graphtrainingstate_free(ptr >>> 0, 1));

export class GraphTrainingState {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(GraphTrainingState.prototype);
        obj.__wbg_ptr = ptr;
        GraphTrainingStateFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GraphTrainingStateFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_graphtrainingstate_free(ptr, 0);
    }
    /**
     * @returns {Uint32Array}
     */
    get inputShape() {
        const ret = wasm.graphtrainingstate_inputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    get stageCount() {
        const ret = wasm.graphtrainingstate_stageCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {Uint32Array}
     */
    get outputShape() {
        const ret = wasm.graphtrainingstate_outputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} parameter
     * @returns {string}
     */
    parameterRole(parameter) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.graphtrainingstate_parameterRole(this.__wbg_ptr, parameter);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @returns {bigint}
     */
    get submittedStep() {
        const ret = wasm.graphtrainingstate_submittedStep(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {string}
     */
    get gradientPolicy() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.graphtrainingstate_gradientPolicy(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    get parameterCount() {
        const ret = wasm.graphtrainingstate_parameterCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} parameter
     * @returns {Uint32Array}
     */
    parameterShape(parameter) {
        const ret = wasm.graphtrainingstate_parameterShape(this.__wbg_ptr, parameter);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {bigint}
     */
    get batchGeneration() {
        const ret = wasm.graphtrainingstate_batchGeneration(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @param {number} parameter
     * @returns {Float32Array}
     */
    parameterValues(parameter) {
        const ret = wasm.graphtrainingstate_parameterValues(this.__wbg_ptr, parameter);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Float32Array}
     */
    predictionValues() {
        const ret = wasm.graphtrainingstate_predictionValues(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Float32Array}
     */
    inputGradientValues() {
        const ret = wasm.graphtrainingstate_inputGradientValues(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} parameter
     * @returns {Float32Array}
     */
    effectiveGradientValues(parameter) {
        const ret = wasm.graphtrainingstate_effectiveGradientValues(this.__wbg_ptr, parameter);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number} parameter
     * @returns {Float32Array}
     */
    parameterGradientValues(parameter) {
        const ret = wasm.graphtrainingstate_parameterGradientValues(this.__wbg_ptr, parameter);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {number}
     */
    get loss() {
        const ret = wasm.graphtrainingstate_loss(this.__wbg_ptr);
        return ret;
    }
    /**
     * Weight-only v2 plan; runtime counters, batch and policy are not serialized.
     * @returns {InferencePlan}
     */
    toPlan() {
        const ret = wasm.graphtrainingstate_toPlan(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return InferencePlan.__wrap(ret[0]);
    }
}
if (Symbol.dispose) GraphTrainingState.prototype[Symbol.dispose] = GraphTrainingState.prototype.free;

const GraphUpdateSnapshotFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_graphupdatesnapshot_free(ptr >>> 0, 1));

export class GraphUpdateSnapshot {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(GraphUpdateSnapshot.prototype);
        obj.__wbg_ptr = ptr;
        GraphUpdateSnapshotFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        GraphUpdateSnapshotFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_graphupdatesnapshot_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get inputGeneration() {
        const ret = wasm.graphupdatesnapshot_inputGeneration(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get submittedUpdate() {
        const ret = wasm.graphupdatesnapshot_submittedUpdate(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get submittedForward() {
        const ret = wasm.graphupdatesnapshot_submittedForward(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {Promise<bigint>}
     */
    read() {
        const ret = wasm.graphupdatesnapshot_read(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) GraphUpdateSnapshot.prototype[Symbol.dispose] = GraphUpdateSnapshot.prototype.free;

const InferencePlanFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_inferenceplan_free(ptr >>> 0, 1));

export class InferencePlan {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(InferencePlan.prototype);
        obj.__wbg_ptr = ptr;
        InferencePlanFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        InferencePlanFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_inferenceplan_free(ptr, 0);
    }
    /**
     * @returns {Uint32Array}
     */
    get inputShape() {
        const ret = wasm.inferenceplan_inputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    get stageCount() {
        const ret = wasm.inferenceplan_stageCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {Uint32Array}
     */
    get outputShape() {
        const ret = wasm.inferenceplan_outputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {Array<any> | null} [tile_mnk]
     * @param {string | null} [kernel]
     * @param {string | null} [accumulation]
     * @returns {Promise<ResidentInference>}
     */
    compileWebGpu(tile_mnk, kernel, accumulation) {
        const ret = wasm.inferenceplan_compileWebGpu(this.__wbg_ptr, isLikeNone(tile_mnk) ? 0 : addToExternrefTable0(tile_mnk), isLikeNone(kernel) ? 0 : addToExternrefTable0(kernel), isLikeNone(accumulation) ? 0 : addToExternrefTable0(accumulation));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Return a new Rust-fused plan; parameter IDs stay fixed, stage IDs may change.
     * @returns {InferencePlan}
     */
    fusePointwise() {
        const ret = wasm.inferenceplan_fusePointwise(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return InferencePlan.__wrap(ret[0]);
    }
    /**
     * Checked handoff to the original browser-owned Rust Module.
     * @param {Sequential} module
     * @param {InferencePlan} updated
     * @param {string | null} [optimizer_state]
     * @returns {number}
     */
    applyParametersTo(module, updated, optimizer_state) {
        _assertClass(module, Sequential);
        _assertClass(updated, InferencePlan);
        const ret = wasm.inferenceplan_applyParametersTo(this.__wbg_ptr, module.__wbg_ptr, updated.__wbg_ptr, isLikeNone(optimizer_state) ? 0 : addToExternrefTable0(optimizer_state));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] >>> 0;
    }
    /**
     * @param {Array<any> | null} [tile_mnk]
     * @param {string | null} [kernel]
     * @param {string | null} [accumulation]
     * @returns {Promise<ResidentGraphInference>}
     */
    compileGraphWebGpu(tile_mnk, kernel, accumulation) {
        const ret = wasm.inferenceplan_compileGraphWebGpu(this.__wbg_ptr, isLikeNone(tile_mnk) ? 0 : addToExternrefTable0(tile_mnk), isLikeNone(kernel) ? 0 : addToExternrefTable0(kernel), isLikeNone(accumulation) ? 0 : addToExternrefTable0(accumulation));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {number}
     */
    get sourceOperationCount() {
        const ret = wasm.inferenceplan_sourceOperationCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {Array<any> | null} [tile_mnk]
     * @param {string | null} [kernel]
     * @param {string | null} [accumulation]
     * @returns {Promise<ResidentTraining>}
     */
    compileTrainingWebGpu(tile_mnk, kernel, accumulation) {
        const ret = wasm.inferenceplan_compileTrainingWebGpu(this.__wbg_ptr, isLikeNone(tile_mnk) ? 0 : addToExternrefTable0(tile_mnk), isLikeNone(kernel) ? 0 : addToExternrefTable0(kernel), isLikeNone(accumulation) ? 0 : addToExternrefTable0(accumulation));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {string} gradient_policy
     * @param {Array<any> | null} [tile_mnk]
     * @param {string | null} [kernel]
     * @param {string | null} [accumulation]
     * @returns {Promise<ResidentGraphLearner>}
     */
    compileGraphLearnerWebGpu(gradient_policy, tile_mnk, kernel, accumulation) {
        const ret = wasm.inferenceplan_compileGraphLearnerWebGpu(this.__wbg_ptr, gradient_policy, isLikeNone(tile_mnk) ? 0 : addToExternrefTable0(tile_mnk), isLikeNone(kernel) ? 0 : addToExternrefTable0(kernel), isLikeNone(accumulation) ? 0 : addToExternrefTable0(accumulation));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Array<any> | null} [tile_mnk]
     * @param {string | null} [kernel]
     * @param {string | null} [accumulation]
     * @returns {Promise<ResidentGraphAutograd>}
     */
    compileGraphAutogradWebGpu(tile_mnk, kernel, accumulation) {
        const ret = wasm.inferenceplan_compileGraphAutogradWebGpu(this.__wbg_ptr, isLikeNone(tile_mnk) ? 0 : addToExternrefTable0(tile_mnk), isLikeNone(kernel) ? 0 : addToExternrefTable0(kernel), isLikeNone(accumulation) ? 0 : addToExternrefTable0(accumulation));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {string} gradient_policy
     * @param {Array<any> | null} [tile_mnk]
     * @param {string | null} [kernel]
     * @param {string | null} [accumulation]
     * @returns {Promise<ResidentGraphTraining>}
     */
    compileGraphTrainingWebGpu(gradient_policy, tile_mnk, kernel, accumulation) {
        const ret = wasm.inferenceplan_compileGraphTrainingWebGpu(this.__wbg_ptr, gradient_policy, isLikeNone(tile_mnk) ? 0 : addToExternrefTable0(tile_mnk), isLikeNone(kernel) ? 0 : addToExternrefTable0(kernel), isLikeNone(accumulation) ? 0 : addToExternrefTable0(accumulation));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {string}
     */
    toJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.inferenceplan_toJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @returns {boolean}
     */
    get isDense() {
        const ret = wasm.inferenceplan_isDense(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {string} payload
     * @param {number | null} [max_bytes]
     * @returns {InferencePlan}
     */
    static fromJson(payload, max_bytes) {
        const ret = wasm.inferenceplan_fromJson(payload, isLikeNone(max_bytes) ? 0 : addToExternrefTable0(max_bytes));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return InferencePlan.__wrap(ret[0]);
    }
}
if (Symbol.dispose) InferencePlan.prototype[Symbol.dispose] = InferencePlan.prototype.free;

const InferenceSnapshotFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_inferencesnapshot_free(ptr >>> 0, 1));

export class InferenceSnapshot {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(InferenceSnapshot.prototype);
        obj.__wbg_ptr = ptr;
        InferenceSnapshotFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        InferenceSnapshotFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_inferencesnapshot_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get generation() {
        const ret = wasm.inferencesnapshot_generation(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {Promise<Float32Array>}
     */
    readValues() {
        const ret = wasm.inferencesnapshot_readValues(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get shape() {
        const ret = wasm.inferencesnapshot_shape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) InferenceSnapshot.prototype[Symbol.dispose] = InferenceSnapshot.prototype.free;

const RankAdaptationSessionFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_rankadaptationsession_free(ptr >>> 0, 1));

export class RankAdaptationSession {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RankAdaptationSessionFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_rankadaptationsession_free(ptr, 0);
    }
    /**
     * @returns {number | undefined}
     */
    pendingSelectionId() {
        const ret = wasm.rankadaptationsession_pendingSelectionId(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : ret[1];
    }
    /**
     * @param {any} request
     */
    constructor(request) {
        const ret = wasm.rankadaptationsession_new(request);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        RankAdaptationSessionFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {any}
     */
    choose() {
        const ret = wasm.rankadaptationsession_choose(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number} selection_id
     * @returns {any}
     */
    abandon(selection_id) {
        const ret = wasm.rankadaptationsession_abandon(this.__wbg_ptr, selection_id);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number} selection_id
     * @param {number} elapsed_ms
     * @param {boolean} correctness_passed
     * @returns {any}
     */
    observe(selection_id, elapsed_ms, correctness_passed) {
        const ret = wasm.rankadaptationsession_observe(this.__wbg_ptr, selection_id, elapsed_ms, correctness_passed);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {any}
     */
    snapshot() {
        const ret = wasm.rankadaptationsession_snapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) RankAdaptationSession.prototype[Symbol.dispose] = RankAdaptationSession.prototype.free;

const ResidentForwardStatsFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_residentforwardstats_free(ptr >>> 0, 1));

export class ResidentForwardStats {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ResidentForwardStats.prototype);
        obj.__wbg_ptr = ptr;
        ResidentForwardStatsFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ResidentForwardStatsFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_residentforwardstats_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get compilations() {
        const ret = wasm.__wbg_get_residentforwardstats_compilations(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get cacheHits() {
        const ret = wasm.__wbg_get_residentforwardstats_cacheHits(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get submittedForwards() {
        const ret = wasm.__wbg_get_residentforwardstats_submittedForwards(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) ResidentForwardStats.prototype[Symbol.dispose] = ResidentForwardStats.prototype.free;

const ResidentGraphAutogradFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_residentgraphautograd_free(ptr >>> 0, 1));

export class ResidentGraphAutograd {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ResidentGraphAutograd.prototype);
        obj.__wbg_ptr = ptr;
        ResidentGraphAutogradFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ResidentGraphAutogradFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_residentgraphautograd_free(ptr, 0);
    }
    /**
     * @returns {Uint32Array}
     */
    get inputShape() {
        const ret = wasm.residentgraphautograd_inputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    get stageCount() {
        const ret = wasm.residentgraphautograd_stageCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {{ name: string; backend: string; device_type: string }}
     */
    adapterInfo() {
        const ret = wasm.residentgraphautograd_adapterInfo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get outputShape() {
        const ret = wasm.residentgraphautograd_outputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {WgpuTensorDevice}
     */
    tensorDevice() {
        const ret = wasm.residentgraphautograd_tensorDevice(this.__wbg_ptr);
        return WgpuTensorDevice.__wrap(ret);
    }
    /**
     * @returns {number}
     */
    get parameterCount() {
        const ret = wasm.residentgraphautograd_parameterCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {bigint}
     */
    get inputGeneration() {
        const ret = wasm.residentgraphautograd_inputGeneration(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @param {WgpuTensor} input
     */
    setInputTensor(input) {
        _assertClass(input, WgpuTensor);
        const ret = wasm.residentgraphautograd_setInputTensor(this.__wbg_ptr, input.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {bigint}
     */
    get submittedForwards() {
        const ret = wasm.residentgraphautograd_submittedForwards(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get submittedBackwards() {
        const ret = wasm.residentgraphautograd_submittedBackwards(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @param {Float32Array} data
     */
    upload(data) {
        const ret = wasm.residentgraphautograd_upload(this.__wbg_ptr, data);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {GraphForward}
     */
    forward() {
        const ret = wasm.residentgraphautograd_forward(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GraphForward.__wrap(ret[0]);
    }
    /**
     * @param {GraphForward} forward
     * @param {WgpuTensor} cotangent
     * @returns {GraphGradients}
     */
    backward(forward, cotangent) {
        _assertClass(forward, GraphForward);
        _assertClass(cotangent, WgpuTensor);
        const ret = wasm.residentgraphautograd_backward(this.__wbg_ptr, forward.__wbg_ptr, cotangent.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GraphGradients.__wrap(ret[0]);
    }
}
if (Symbol.dispose) ResidentGraphAutograd.prototype[Symbol.dispose] = ResidentGraphAutograd.prototype.free;

const ResidentGraphInferenceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_residentgraphinference_free(ptr >>> 0, 1));

export class ResidentGraphInference {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ResidentGraphInference.prototype);
        obj.__wbg_ptr = ptr;
        ResidentGraphInferenceFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ResidentGraphInferenceFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_residentgraphinference_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get generation() {
        const ret = wasm.residentgraphinference_generation(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {Uint32Array}
     */
    get inputShape() {
        const ret = wasm.residentgraphinference_inputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    get stageCount() {
        const ret = wasm.residentgraphinference_stageCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {{ name: string; backend: string; device_type: string }}
     */
    adapterInfo() {
        const ret = wasm.residentgraphinference_adapterInfo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get outputShape() {
        const ret = wasm.residentgraphinference_outputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {WgpuTensor}
     */
    outputTensor() {
        const ret = wasm.residentgraphinference_outputTensor(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @returns {WgpuTensorDevice}
     */
    tensorDevice() {
        const ret = wasm.residentgraphinference_tensorDevice(this.__wbg_ptr);
        return WgpuTensorDevice.__wrap(ret);
    }
    /**
     * @param {WgpuTensor} input
     * @returns {WgpuTensor}
     */
    forwardTensor(input) {
        _assertClass(input, WgpuTensor);
        const ret = wasm.residentgraphinference_forwardTensor(this.__wbg_ptr, input.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @returns {number}
     */
    get parameterCount() {
        const ret = wasm.residentgraphinference_parameterCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {WgpuTensor} input
     */
    setInputTensor(input) {
        _assertClass(input, WgpuTensor);
        const ret = wasm.residentgraphinference_setInputTensor(this.__wbg_ptr, input.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {bigint}
     */
    get submittedDispatches() {
        const ret = wasm.residentgraphinference_submittedDispatches(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @param {Float32Array} data
     */
    upload(data) {
        const ret = wasm.residentgraphinference_upload(this.__wbg_ptr, data);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {bigint}
     */
    dispatch() {
        const ret = wasm.residentgraphinference_dispatch(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BigInt.asUintN(64, ret[0]);
    }
    /**
     * @returns {GraphInferenceSnapshot}
     */
    snapshot() {
        const ret = wasm.residentgraphinference_snapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GraphInferenceSnapshot.__wrap(ret[0]);
    }
}
if (Symbol.dispose) ResidentGraphInference.prototype[Symbol.dispose] = ResidentGraphInference.prototype.free;

const ResidentGraphLearnerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_residentgraphlearner_free(ptr >>> 0, 1));

export class ResidentGraphLearner {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ResidentGraphLearner.prototype);
        obj.__wbg_ptr = ptr;
        ResidentGraphLearnerFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ResidentGraphLearnerFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_residentgraphlearner_free(ptr, 0);
    }
    /**
     * @returns {Uint32Array}
     */
    get inputShape() {
        const ret = wasm.residentgraphlearner_inputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    get stageCount() {
        const ret = wasm.residentgraphlearner_stageCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {{ name: string; backend: string; device_type: string }}
     */
    adapterInfo() {
        const ret = wasm.residentgraphlearner_adapterInfo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get outputShape() {
        const ret = wasm.residentgraphlearner_outputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {GraphGradientBatch} batch
     * @param {number} rate
     * @returns {bigint}
     */
    sgdWeighted(batch, rate) {
        _assertClass(batch, GraphGradientBatch);
        const ret = wasm.residentgraphlearner_sgdWeighted(this.__wbg_ptr, batch.__wbg_ptr, rate);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BigInt.asUintN(64, ret[0]);
    }
    /**
     * @returns {WgpuTensorDevice}
     */
    tensorDevice() {
        const ret = wasm.residentgraphlearner_tensorDevice(this.__wbg_ptr);
        return WgpuTensorDevice.__wrap(ret);
    }
    /**
     * @returns {string}
     */
    get gradientPolicy() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.residentgraphlearner_gradientPolicy(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    get parameterCount() {
        const ret = wasm.residentgraphlearner_parameterCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {GraphUpdateSnapshot}
     */
    updateSnapshot() {
        const ret = wasm.residentgraphlearner_updateSnapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GraphUpdateSnapshot.__wrap(ret[0]);
    }
    /**
     * @returns {bigint}
     */
    get inputGeneration() {
        const ret = wasm.residentgraphlearner_inputGeneration(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @param {WgpuTensor} input
     */
    setInputTensor(input) {
        _assertClass(input, WgpuTensor);
        const ret = wasm.residentgraphlearner_setInputTensor(this.__wbg_ptr, input.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {bigint}
     */
    get submittedUpdates() {
        const ret = wasm.residentgraphlearner_submittedUpdates(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {GraphTrainingParametersSnapshot}
     */
    parameterSnapshot() {
        const ret = wasm.residentgraphlearner_parameterSnapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GraphTrainingParametersSnapshot.__wrap(ret[0]);
    }
    /**
     * @returns {bigint}
     */
    get submittedForwards() {
        const ret = wasm.residentgraphlearner_submittedForwards(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get submittedBackwards() {
        const ret = wasm.residentgraphlearner_submittedBackwards(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @param {GraphGradients} gradients
     * @param {number} rate
     * @returns {bigint}
     */
    sgd(gradients, rate) {
        _assertClass(gradients, GraphGradients);
        const ret = wasm.residentgraphlearner_sgd(this.__wbg_ptr, gradients.__wbg_ptr, rate);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BigInt.asUintN(64, ret[0]);
    }
    /**
     * @param {Float32Array} input
     */
    upload(input) {
        const ret = wasm.residentgraphlearner_upload(this.__wbg_ptr, input);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {GraphForward}
     */
    forward() {
        const ret = wasm.residentgraphlearner_forward(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GraphForward.__wrap(ret[0]);
    }
    /**
     * @param {GraphForward} forward
     * @param {WgpuTensor} cotangent
     * @returns {GraphGradients}
     */
    backward(forward, cotangent) {
        _assertClass(forward, GraphForward);
        _assertClass(cotangent, WgpuTensor);
        const ret = wasm.residentgraphlearner_backward(this.__wbg_ptr, forward.__wbg_ptr, cotangent.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GraphGradients.__wrap(ret[0]);
    }
}
if (Symbol.dispose) ResidentGraphLearner.prototype[Symbol.dispose] = ResidentGraphLearner.prototype.free;

const ResidentGraphTrainingFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_residentgraphtraining_free(ptr >>> 0, 1));

export class ResidentGraphTraining {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ResidentGraphTraining.prototype);
        obj.__wbg_ptr = ptr;
        ResidentGraphTrainingFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ResidentGraphTrainingFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_residentgraphtraining_free(ptr, 0);
    }
    /**
     * @returns {Uint32Array}
     */
    get inputShape() {
        const ret = wasm.residentgraphtraining_inputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    get stageCount() {
        const ret = wasm.residentgraphautograd_stageCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {{ name: string; backend: string; device_type: string }}
     */
    adapterInfo() {
        const ret = wasm.residentgraphtraining_adapterInfo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get outputShape() {
        const ret = wasm.residentgraphtraining_outputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {Float32Array} input
     * @param {Float32Array} target
     */
    uploadBatch(input, target) {
        const ret = wasm.residentgraphtraining_uploadBatch(this.__wbg_ptr, input, target);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {TrainingLossSnapshot}
     */
    lossSnapshot() {
        const ret = wasm.residentgraphtraining_lossSnapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return TrainingLossSnapshot.__wrap(ret[0]);
    }
    /**
     * @returns {GraphTrainingSnapshot}
     */
    stateSnapshot() {
        const ret = wasm.residentgraphtraining_stateSnapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GraphTrainingSnapshot.__wrap(ret[0]);
    }
    /**
     * @returns {string}
     */
    get gradientPolicy() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.residentgraphtraining_gradientPolicy(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    get parameterCount() {
        const ret = wasm.residentgraphautograd_parameterCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {bigint}
     */
    get submittedSteps() {
        const ret = wasm.residentgraphtraining_submittedSteps(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get batchGeneration() {
        const ret = wasm.residentgraphautograd_inputGeneration(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {WgpuTensor}
     */
    predictionTensor() {
        const ret = wasm.residentgraphtraining_predictionTensor(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @returns {GraphTrainingParametersSnapshot}
     */
    parameterSnapshot() {
        const ret = wasm.residentgraphtraining_parameterSnapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return GraphTrainingParametersSnapshot.__wrap(ret[0]);
    }
    /**
     * @param {WgpuTensor} input
     * @param {WgpuTensor} target
     */
    uploadBatchTensors(input, target) {
        _assertClass(input, WgpuTensor);
        _assertClass(target, WgpuTensor);
        const ret = wasm.residentgraphtraining_uploadBatchTensors(this.__wbg_ptr, input.__wbg_ptr, target.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {WgpuTensor}
     */
    inputGradientTensor() {
        const ret = wasm.residentgraphtraining_inputGradientTensor(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * Enqueued attempt, not proof of acceptance. Read an owning loss/state snapshot.
     * @param {number} learning_rate
     * @returns {bigint}
     */
    step(learning_rate) {
        const ret = wasm.residentgraphtraining_step(this.__wbg_ptr, learning_rate);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BigInt.asUintN(64, ret[0]);
    }
}
if (Symbol.dispose) ResidentGraphTraining.prototype[Symbol.dispose] = ResidentGraphTraining.prototype.free;

const ResidentInferenceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_residentinference_free(ptr >>> 0, 1));

export class ResidentInference {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ResidentInference.prototype);
        obj.__wbg_ptr = ptr;
        ResidentInferenceFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ResidentInferenceFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_residentinference_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get generation() {
        const ret = wasm.residentinference_generation(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {Uint32Array}
     */
    get inputShape() {
        const ret = wasm.residentinference_inputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    get stageCount() {
        const ret = wasm.residentinference_stageCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {{ name: string; backend: string; device_type: string }}
     */
    adapterInfo() {
        const ret = wasm.residentinference_adapterInfo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get outputShape() {
        const ret = wasm.residentinference_outputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {WgpuTensorDevice} device
     * @returns {WgpuTensor}
     */
    tensorSnapshot(device) {
        _assertClass(device, WgpuTensorDevice);
        const ret = wasm.residentinference_tensorSnapshot(this.__wbg_ptr, device.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @param {WgpuTensor} input
     */
    setInputTensor(input) {
        _assertClass(input, WgpuTensor);
        const ret = wasm.residentinference_setInputTensor(this.__wbg_ptr, input.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {Float32Array} values
     */
    upload(values) {
        const ret = wasm.residentinference_upload(this.__wbg_ptr, values);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {bigint}
     */
    dispatch() {
        const ret = wasm.residentinference_dispatch(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BigInt.asUintN(64, ret[0]);
    }
    /**
     * @returns {InferenceSnapshot}
     */
    snapshot() {
        const ret = wasm.residentinference_snapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return InferenceSnapshot.__wrap(ret[0]);
    }
}
if (Symbol.dispose) ResidentInference.prototype[Symbol.dispose] = ResidentInference.prototype.free;

const ResidentTrainingFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_residenttraining_free(ptr >>> 0, 1));

export class ResidentTraining {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ResidentTraining.prototype);
        obj.__wbg_ptr = ptr;
        ResidentTrainingFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ResidentTrainingFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_residenttraining_free(ptr, 0);
    }
    /**
     * @returns {Uint32Array}
     */
    get inputShape() {
        const ret = wasm.residenttraining_inputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    get stageCount() {
        const ret = wasm.residenttraining_stageCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {{ name: string; backend: string; device_type: string }}
     */
    adapterInfo() {
        const ret = wasm.residenttraining_adapterInfo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get outputShape() {
        const ret = wasm.residenttraining_outputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {Float32Array} input
     * @param {Float32Array} target
     */
    uploadBatch(input, target) {
        const ret = wasm.residenttraining_uploadBatch(this.__wbg_ptr, input, target);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {TrainingLossSnapshot}
     */
    lossSnapshot() {
        const ret = wasm.residenttraining_lossSnapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return TrainingLossSnapshot.__wrap(ret[0]);
    }
    /**
     * @returns {TrainingSnapshot}
     */
    stateSnapshot() {
        const ret = wasm.residenttraining_stateSnapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return TrainingSnapshot.__wrap(ret[0]);
    }
    /**
     * @returns {bigint}
     */
    get submittedSteps() {
        const ret = wasm.residenttraining_submittedSteps(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get batchGeneration() {
        const ret = wasm.residenttraining_batchGeneration(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {TrainingParametersSnapshot}
     */
    parameterSnapshot() {
        const ret = wasm.residenttraining_parameterSnapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return TrainingParametersSnapshot.__wrap(ret[0]);
    }
    /**
     * Enqueued attempt, not proof of acceptance. Read the owning snapshot.
     * @param {number} learning_rate
     * @returns {bigint}
     */
    step(learning_rate) {
        const ret = wasm.residenttraining_step(this.__wbg_ptr, learning_rate);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BigInt.asUintN(64, ret[0]);
    }
}
if (Symbol.dispose) ResidentTraining.prototype[Symbol.dispose] = ResidentTraining.prototype.free;

const ResolvedWasmFftPlanFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_resolvedwasmfftplan_free(ptr >>> 0, 1));

export class ResolvedWasmFftPlan {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ResolvedWasmFftPlan.prototype);
        obj.__wbg_ptr = ptr;
        ResolvedWasmFftPlanFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ResolvedWasmFftPlanFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_resolvedwasmfftplan_free(ptr, 0);
    }
    /**
     * @param {any} value
     * @returns {ResolvedWasmFftPlan}
     */
    static fromObject(value) {
        const ret = wasm.resolvedwasmfftplan_fromObject(value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ResolvedWasmFftPlan.__wrap(ret[0]);
    }
    /**
     * @returns {boolean}
     */
    get heuristicUsed() {
        const ret = wasm.resolvedwasmfftplan_heuristicUsed(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    get overrideApplied() {
        const ret = wasm.resolvedwasmfftplan_overrideApplied(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {WasmFftPlan}
     */
    get plan() {
        const ret = wasm.resolvedwasmfftplan_plan(this.__wbg_ptr);
        return WasmFftPlan.__wrap(ret);
    }
    /**
     * @returns {WasmFftPlanSource}
     */
    get source() {
        const ret = wasm.resolvedwasmfftplan_source(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {string}
     */
    toJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.resolvedwasmfftplan_toJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @param {string} json
     * @returns {ResolvedWasmFftPlan}
     */
    static fromJson(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.resolvedwasmfftplan_fromJson(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ResolvedWasmFftPlan.__wrap(ret[0]);
    }
    /**
     * @returns {any}
     */
    toObject() {
        const ret = wasm.resolvedwasmfftplan_toObject(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) ResolvedWasmFftPlan.prototype[Symbol.dispose] = ResolvedWasmFftPlan.prototype.free;

const SequentialFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sequential_free(ptr >>> 0, 1));

export class Sequential {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SequentialFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sequential_free(ptr, 0);
    }
    /**
     * @param {string} name
     * @param {number} input_dim
     * @param {number} output_dim
     */
    addLinear(name, input_dim, output_dim) {
        const ret = wasm.sequential_addLinear(this.__wbg_ptr, name, input_dim, output_dim);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} name
     * @param {Float32Array} gain
     */
    addScaler(name, gain) {
        const ret = wasm.sequential_addScaler(this.__wbg_ptr, name, gain);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {number[]} shape
     * @returns {InferencePlan}
     */
    inferencePlan(shape) {
        const ret = wasm.sequential_inferencePlan(this.__wbg_ptr, shape);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return InferencePlan.__wrap(ret[0]);
    }
    /**
     * @returns {ResidentForwardStats}
     */
    residentCacheInfo() {
        const ret = wasm.sequential_residentCacheInfo(this.__wbg_ptr);
        return ResidentForwardStats.__wrap(ret);
    }
    clearResidentCache() {
        wasm.sequential_clearResidentCache(this.__wbg_ptr);
    }
    constructor() {
        const ret = wasm.sequential_new();
        this.__wbg_ptr = ret >>> 0;
        SequentialFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * GPU submission only. The output owns its capture; readback is explicit.
     * @param {WgpuTensor} input
     * @returns {WgpuTensor}
     */
    forward(input) {
        _assertClass(input, WgpuTensor);
        const ret = wasm.sequential_forward(this.__wbg_ptr, input.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    addGelu() {
        wasm.sequential_addGelu(this.__wbg_ptr);
    }
    addRelu() {
        wasm.sequential_addRelu(this.__wbg_ptr);
    }
}
if (Symbol.dispose) Sequential.prototype[Symbol.dispose] = Sequential.prototype.free;

const TensorMeanBatchFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_tensormeanbatch_free(ptr >>> 0, 1));
/**
 * A reusable batch in WASM linear memory, not GPU-resident storage.
 * Construction copies partial-major row-major f32 data once. Repeated means
 * execute the same ordered-f64 Rust reducer used by GoldenRetriever.
 */
export class TensorMeanBatch {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TensorMeanBatchFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_tensormeanbatch_free(ptr, 0);
    }
    /**
     * Returns a new Float32Array. No input buffer or earlier result is mutated.
     * @param {number} scale
     * @returns {Float32Array}
     */
    meanScaled(scale) {
        const ret = wasm.tensormeanbatch_meanScaled(this.__wbg_ptr, scale);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} rows
     * @param {number} cols
     * @param {number} partial_count
     * @param {Float32Array} data
     */
    constructor(rows, cols, partial_count, data) {
        const ptr0 = passArrayF32ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.tensormeanbatch_new(rows, cols, partial_count, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        TensorMeanBatchFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) TensorMeanBatch.prototype[Symbol.dispose] = TensorMeanBatch.prototype.free;

const TrainingLossSnapshotFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_traininglosssnapshot_free(ptr >>> 0, 1));

export class TrainingLossSnapshot {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(TrainingLossSnapshot.prototype);
        obj.__wbg_ptr = ptr;
        TrainingLossSnapshotFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TrainingLossSnapshotFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_traininglosssnapshot_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get submittedStep() {
        const ret = wasm.traininglosssnapshot_submittedStep(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get batchGeneration() {
        const ret = wasm.graphupdatesnapshot_submittedUpdate(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {Promise<number>}
     */
    read() {
        const ret = wasm.traininglosssnapshot_read(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) TrainingLossSnapshot.prototype[Symbol.dispose] = TrainingLossSnapshot.prototype.free;

const TrainingParametersSnapshotFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_trainingparameterssnapshot_free(ptr >>> 0, 1));

export class TrainingParametersSnapshot {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(TrainingParametersSnapshot.prototype);
        obj.__wbg_ptr = ptr;
        TrainingParametersSnapshotFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TrainingParametersSnapshotFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_trainingparameterssnapshot_free(ptr, 0);
    }
    /**
     * @returns {Promise<InferencePlan>}
     */
    readPlan() {
        const ret = wasm.trainingparameterssnapshot_readPlan(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) TrainingParametersSnapshot.prototype[Symbol.dispose] = TrainingParametersSnapshot.prototype.free;

const TrainingSnapshotFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_trainingsnapshot_free(ptr >>> 0, 1));

export class TrainingSnapshot {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(TrainingSnapshot.prototype);
        obj.__wbg_ptr = ptr;
        TrainingSnapshotFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TrainingSnapshotFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_trainingsnapshot_free(ptr, 0);
    }
    /**
     * @returns {Promise<TrainingState>}
     */
    readState() {
        const ret = wasm.trainingsnapshot_readState(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get inputShape() {
        const ret = wasm.trainingsnapshot_inputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {Uint32Array}
     */
    get outputShape() {
        const ret = wasm.trainingsnapshot_outputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {bigint}
     */
    get submittedStep() {
        const ret = wasm.trainingsnapshot_submittedStep(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get batchGeneration() {
        const ret = wasm.trainingsnapshot_batchGeneration(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) TrainingSnapshot.prototype[Symbol.dispose] = TrainingSnapshot.prototype.free;

const TrainingStateFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_trainingstate_free(ptr >>> 0, 1));

export class TrainingState {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(TrainingState.prototype);
        obj.__wbg_ptr = ptr;
        TrainingStateFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TrainingStateFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_trainingstate_free(ptr, 0);
    }
    /**
     * @param {number} stage
     * @returns {Float32Array}
     */
    biasValues(stage) {
        const ret = wasm.trainingstate_biasValues(this.__wbg_ptr, stage);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get inputShape() {
        const ret = wasm.trainingstate_inputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} stage
     * @returns {Uint32Array}
     */
    layerShape(stage) {
        const ret = wasm.trainingstate_layerShape(this.__wbg_ptr, stage);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {number}
     */
    get stageCount() {
        const ret = wasm.trainingstate_stageCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {Uint32Array}
     */
    get outputShape() {
        const ret = wasm.trainingstate_outputShape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {number} stage
     * @returns {Float32Array}
     */
    weightValues(stage) {
        const ret = wasm.trainingstate_weightValues(this.__wbg_ptr, stage);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {bigint}
     */
    get submittedStep() {
        const ret = wasm.trainingstate_submittedStep(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get batchGeneration() {
        const ret = wasm.trainingstate_batchGeneration(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {Float32Array}
     */
    predictionValues() {
        const ret = wasm.trainingstate_predictionValues(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} stage
     * @returns {Float32Array}
     */
    biasGradientValues(stage) {
        const ret = wasm.trainingstate_biasGradientValues(this.__wbg_ptr, stage);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Float32Array}
     */
    inputGradientValues() {
        const ret = wasm.trainingstate_inputGradientValues(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} stage
     * @returns {Float32Array}
     */
    weightGradientValues(stage) {
        const ret = wasm.trainingstate_weightGradientValues(this.__wbg_ptr, stage);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {number}
     */
    get loss() {
        const ret = wasm.trainingstate_loss(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {InferencePlan}
     */
    toPlan() {
        const ret = wasm.trainingstate_toPlan(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return InferencePlan.__wrap(ret[0]);
    }
}
if (Symbol.dispose) TrainingState.prototype[Symbol.dispose] = TrainingState.prototype.free;

const WasmFftPlanFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmfftplan_free(ptr >>> 0, 1));

export class WasmFftPlan {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmFftPlan.prototype);
        obj.__wbg_ptr = ptr;
        WasmFftPlanFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmFftPlanFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmfftplan_free(ptr, 0);
    }
    /**
     * Rebuild a plan from a plain JavaScript object with the same fields as [`toObject`].
     * @param {any} value
     * @returns {WasmFftPlan}
     */
    static fromObject(value) {
        const ret = wasm.wasmfftplan_fromObject(value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmFftPlan.__wrap(ret[0]);
    }
    /**
     * @returns {string}
     */
    spiralkHint() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.wasmfftplan_spiralkHint(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    workgroupSize() {
        const ret = wasm.wasmfftplan_workgroupSize(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {string}
     */
    dispatchManifestJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmfftplan_dispatchManifestJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    dispatchManifestObject() {
        const ret = wasm.wasmfftplan_dispatchManifestObject(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number} radix
     * @param {number} tile_cols
     * @param {number} segments
     * @param {boolean} subgroup
     */
    constructor(radix, tile_cols, segments, subgroup) {
        const ret = wasm.wasmfftplan_new(radix, tile_cols, segments, subgroup);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        WasmFftPlanFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {string}
     */
    wgsl() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.wasmfftplan_wgsl(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    get radix() {
        const ret = wasm.canvasfftlayout_fieldBytes(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Serialise the plan into a JSON string so it can be persisted or sent over the network.
     * @returns {string}
     */
    toJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmfftplan_toJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    get segments() {
        const ret = wasm.canvasfftlayout_spectrumBytes(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {boolean}
     */
    get subgroup() {
        const ret = wasm.wasmfftplan_subgroup(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Rebuild a plan from a JSON string produced by [`toJson`].
     * @param {string} json
     * @returns {WasmFftPlan}
     */
    static fromJson(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmfftplan_fromJson(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmFftPlan.__wrap(ret[0]);
    }
    /**
     * @returns {number}
     */
    get tileCols() {
        const ret = wasm.canvasfftlayout_fieldStride(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Convert the plan into a plain JavaScript object with the same fields as [`toJson`].
     * @returns {any}
     */
    toObject() {
        const ret = wasm.wasmfftplan_toObject(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) WasmFftPlan.prototype[Symbol.dispose] = WasmFftPlan.prototype.free;

const WasmFractalFieldGeneratorFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmfractalfieldgenerator_free(ptr >>> 0, 1));

export class WasmFractalFieldGenerator {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmFractalFieldGeneratorFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmfractalfieldgenerator_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    get iterations() {
        const ret = wasm.wasmfractalfieldgenerator_iterations(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get lacunarity() {
        const ret = wasm.wasmfractalfieldgenerator_lacunarity(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} log_start
     * @param {number} log_step
     * @param {number} len
     * @param {number} preview_len
     * @returns {string}
     */
    probeJson(log_start, log_step, len, preview_len) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmfractalfieldgenerator_probeJson(this.__wbg_ptr, log_start, log_step, len, preview_len);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @param {number} log_start
     * @param {number} log_step
     * @param {number} len
     * @param {number} preview_len
     * @returns {any}
     */
    probeObject(log_start, log_step, len, preview_len) {
        const ret = wasm.wasmfractalfieldgenerator_probeObject(this.__wbg_ptr, log_start, log_step, len, preview_len);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number} log_start
     * @param {number} log_step
     * @param {number} len
     * @returns {Float32Array}
     */
    branchingField(log_start, log_step, len) {
        const ret = wasm.wasmfractalfieldgenerator_branchingField(this.__wbg_ptr, log_start, log_step, len);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number} octaves
     * @param {number} lacunarity
     * @param {number} gain
     * @param {number} iterations
     */
    constructor(octaves, lacunarity, gain, iterations) {
        const ret = wasm.wasmfractalfieldgenerator_new(octaves, lacunarity, gain, iterations);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        WasmFractalFieldGeneratorFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {number}
     */
    get gain() {
        const ret = wasm.wasmfractalfieldgenerator_gain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get octaves() {
        const ret = wasm.wasmfractalfieldgenerator_octaves(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) WasmFractalFieldGenerator.prototype[Symbol.dispose] = WasmFractalFieldGenerator.prototype.free;

const WasmLogZSeriesFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmlogzseries_free(ptr >>> 0, 1));

export class WasmLogZSeries {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmLogZSeriesFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmlogzseries_free(ptr, 0);
    }
    /**
     * @param {Float32Array} z
     * @returns {Float32Array}
     */
    evaluateZ(z) {
        const ret = wasm.wasmlogzseries_evaluateZ(this.__wbg_ptr, z);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Float32Array} z_values
     * @param {number} preview_len
     * @returns {string}
     */
    probeJson(z_values, preview_len) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmlogzseries_probeJson(this.__wbg_ptr, z_values, preview_len);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @param {Float32Array} z_values
     * @param {number} preview_len
     * @returns {any}
     */
    probeObject(z_values, preview_len) {
        const ret = wasm.wasmlogzseries_probeObject(this.__wbg_ptr, z_values, preview_len);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {string}
     */
    get normalisation() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.wasmlogzseries_normalisation(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {Float32Array} z_values
     * @returns {Float32Array}
     */
    evaluateManyZ(z_values) {
        const ret = wasm.wasmlogzseries_evaluateManyZ(this.__wbg_ptr, z_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {number}
     */
    len() {
        const ret = wasm.wasmlogzseries_len(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} log_start
     * @param {number} log_step
     * @param {Float32Array} samples
     * @param {string} window
     * @param {string} normalisation
     */
    constructor(log_start, log_step, samples, window, normalisation) {
        const ptr0 = passStringToWasm0(window, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(normalisation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmlogzseries_new(log_start, log_step, samples, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        WasmLogZSeriesFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {string}
     */
    get window() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.wasmlogzseries_window(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {Float32Array}
     */
    samples() {
        const ret = wasm.wasmlogzseries_samples(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Float32Array}
     */
    weights() {
        const ret = wasm.wasmlogzseries_weights(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {boolean}
     */
    isEmpty() {
        const ret = wasm.wasmlogzseries_isEmpty(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    get logStep() {
        const ret = wasm.wasmlogzseries_logStep(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get logStart() {
        const ret = wasm.wasmlogzseries_logStart(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) WasmLogZSeries.prototype[Symbol.dispose] = WasmLogZSeries.prototype.free;

const WasmMellinEvalPlanFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmmellinevalplan_free(ptr >>> 0, 1));

export class WasmMellinEvalPlan {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmMellinEvalPlan.prototype);
        obj.__wbg_ptr = ptr;
        WasmMellinEvalPlanFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmMellinEvalPlanFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmmellinevalplan_free(ptr, 0);
    }
    /**
     * @param {number} log_start
     * @param {number} log_step
     * @param {number} real
     * @param {Float32Array} imag_values
     * @returns {WasmMellinEvalPlan}
     */
    static verticalLine(log_start, log_step, real, imag_values) {
        const ret = wasm.wasmmellinevalplan_verticalLine(log_start, log_step, real, imag_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmMellinEvalPlan.__wrap(ret[0]);
    }
    /**
     * @returns {number}
     */
    len() {
        const ret = wasm.wasmmellinevalplan_len(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} log_start
     * @param {number} log_step
     * @param {Float32Array} s_values
     * @returns {WasmMellinEvalPlan}
     */
    static many(log_start, log_step, s_values) {
        const ret = wasm.wasmmellinevalplan_many(log_start, log_step, s_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmMellinEvalPlan.__wrap(ret[0]);
    }
    /**
     * @param {number} log_start
     * @param {number} log_step
     * @param {Float32Array} real_values
     * @param {Float32Array} imag_values
     * @returns {WasmMellinEvalPlan}
     */
    static mesh(log_start, log_step, real_values, imag_values) {
        const ret = wasm.wasmmellinevalplan_mesh(log_start, log_step, real_values, imag_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmMellinEvalPlan.__wrap(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    shape() {
        const ret = wasm.wasmmellinevalplan_shape(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get logStep() {
        const ret = wasm.canvasdesirecontrol_operatorGain(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get logStart() {
        const ret = wasm.canvasdesirecontrol_operatorMix(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) WasmMellinEvalPlan.prototype[Symbol.dispose] = WasmMellinEvalPlan.prototype.free;

const WasmMellinLogGridFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmmellinloggrid_free(ptr >>> 0, 1));

export class WasmMellinLogGrid {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmMellinLogGrid.prototype);
        obj.__wbg_ptr = ptr;
        WasmMellinLogGridFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmMellinLogGridFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmmellinloggrid_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    hilbertNorm() {
        const ret = wasm.wasmmellinloggrid_hilbertNorm(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @param {Float32Array} s_values
     * @returns {Float32Array}
     */
    evaluateMany(s_values) {
        const ret = wasm.wasmmellinloggrid_evaluateMany(this.__wbg_ptr, s_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Float32Array} real_values
     * @param {Float32Array} imag_values
     * @returns {Float32Array}
     */
    evaluateMesh(real_values, imag_values) {
        const ret = wasm.wasmmellinloggrid_evaluateMesh(this.__wbg_ptr, real_values, imag_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {WasmMellinEvalPlan} plan
     * @returns {Float32Array}
     */
    evaluatePlan(plan) {
        _assertClass(plan, WasmMellinEvalPlan);
        const ret = wasm.wasmmellinloggrid_evaluatePlan(this.__wbg_ptr, plan.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Float32Array} s
     * @returns {Float32Array}
     */
    evaluateStable(s) {
        const ret = wasm.wasmmellinloggrid_evaluateStable(this.__wbg_ptr, s);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number} log_start
     * @param {number} log_step
     * @param {Float32Array} samples
     * @param {string} window
     * @param {boolean} preserve_sum
     * @returns {WasmMellinLogGrid}
     */
    static newWithWindow(log_start, log_step, samples, window, preserve_sum) {
        const ptr0 = passStringToWasm0(window, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmmellinloggrid_newWithWindow(log_start, log_step, samples, ptr0, len0, preserve_sum);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmMellinLogGrid.__wrap(ret[0]);
    }
    /**
     * @returns {Float32Array}
     */
    weightedSeries() {
        const ret = wasm.wasmmellinloggrid_weightedSeries(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number} log_start
     * @param {number} log_step
     * @param {number} len
     * @param {number} rate
     * @param {string} window
     * @param {boolean} preserve_sum
     * @returns {WasmMellinLogGrid}
     */
    static expDecayScaled(log_start, log_step, len, rate, window, preserve_sum) {
        const ptr0 = passStringToWasm0(window, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmmellinloggrid_expDecayScaled(log_start, log_step, len, rate, ptr0, len0, preserve_sum);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmMellinLogGrid.__wrap(ret[0]);
    }
    /**
     * @param {number} real
     * @param {Float32Array} imag_values
     * @returns {WasmMellinEvalPlan}
     */
    planVerticalLine(real, imag_values) {
        const ret = wasm.wasmmellinloggrid_planVerticalLine(this.__wbg_ptr, real, imag_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmMellinEvalPlan.__wrap(ret[0]);
    }
    /**
     * @param {Float32Array} s_values
     * @returns {Float32Array}
     */
    evaluateManyStable(s_values) {
        const ret = wasm.wasmmellinloggrid_evaluateManyStable(this.__wbg_ptr, s_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {WasmMellinEvalPlan} plan
     * @returns {Float32Array}
     */
    evaluatePlanStable(plan) {
        _assertClass(plan, WasmMellinEvalPlan);
        const ret = wasm.wasmmellinloggrid_evaluatePlanStable(this.__wbg_ptr, plan.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {WasmMellinLogGrid} other
     * @returns {Float32Array}
     */
    hilbertInnerProduct(other) {
        _assertClass(other, WasmMellinLogGrid);
        const ret = wasm.wasmmellinloggrid_hilbertInnerProduct(this.__wbg_ptr, other.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number} real
     * @param {Float32Array} imag_values
     * @returns {Float32Array}
     */
    evaluateVerticalLine(real, imag_values) {
        const ret = wasm.wasmmellinloggrid_evaluateVerticalLine(this.__wbg_ptr, real, imag_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Float32Array} real_values
     * @param {Float32Array} imag_values
     * @returns {Float32Array}
     */
    evaluateMeshMagnitude(real_values, imag_values) {
        const ret = wasm.wasmmellinloggrid_evaluateMeshMagnitude(this.__wbg_ptr, real_values, imag_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {WasmMellinEvalPlan} plan
     * @returns {Float32Array}
     */
    evaluatePlanMagnitude(plan) {
        _assertClass(plan, WasmMellinEvalPlan);
        const ret = wasm.wasmmellinloggrid_evaluatePlanMagnitude(this.__wbg_ptr, plan.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Float32Array} s
     * @returns {Array<any>}
     */
    evaluateWithDerivative(s) {
        const ret = wasm.wasmmellinloggrid_evaluateWithDerivative(this.__wbg_ptr, s);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {WasmMellinEvalPlan} plan
     * @param {WasmMellinLogGrid} target
     * @param {number} lr
     * @returns {number}
     */
    trainStepMatchGridPlan(plan, target, lr) {
        _assertClass(plan, WasmMellinEvalPlan);
        _assertClass(target, WasmMellinLogGrid);
        const ret = wasm.wasmmellinloggrid_trainStepMatchGridPlan(this.__wbg_ptr, plan.__wbg_ptr, target.__wbg_ptr, lr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @param {Float32Array} real_values
     * @param {Float32Array} imag_values
     * @param {number} epsilon
     * @returns {Float32Array}
     */
    evaluateMeshLogMagnitude(real_values, imag_values, epsilon) {
        const ret = wasm.wasmmellinloggrid_evaluateMeshLogMagnitude(this.__wbg_ptr, real_values, imag_values, epsilon);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {WasmMellinEvalPlan} plan
     * @param {number} epsilon
     * @returns {Float32Array}
     */
    evaluatePlanLogMagnitude(plan, epsilon) {
        _assertClass(plan, WasmMellinEvalPlan);
        const ret = wasm.wasmmellinloggrid_evaluatePlanLogMagnitude(this.__wbg_ptr, plan.__wbg_ptr, epsilon);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Float32Array} s_values
     * @returns {Array<any>}
     */
    evaluateManyWithDerivative(s_values) {
        const ret = wasm.wasmmellinloggrid_evaluateManyWithDerivative(this.__wbg_ptr, s_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {WasmMellinEvalPlan} plan
     * @returns {Array<any>}
     */
    evaluatePlanWithDerivative(plan) {
        _assertClass(plan, WasmMellinEvalPlan);
        const ret = wasm.wasmmellinloggrid_evaluatePlanWithDerivative(this.__wbg_ptr, plan.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Float32Array} s
     * @returns {Array<any>}
     */
    evaluateWithDerivativeStable(s) {
        const ret = wasm.wasmmellinloggrid_evaluateWithDerivativeStable(this.__wbg_ptr, s);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Float32Array} s_values
     * @returns {Array<any>}
     */
    evaluateManyWithDerivativeStable(s_values) {
        const ret = wasm.wasmmellinloggrid_evaluateManyWithDerivativeStable(this.__wbg_ptr, s_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {WasmMellinEvalPlan} plan
     * @returns {Array<any>}
     */
    evaluatePlanWithDerivativeStable(plan) {
        _assertClass(plan, WasmMellinEvalPlan);
        const ret = wasm.wasmmellinloggrid_evaluatePlanWithDerivativeStable(this.__wbg_ptr, plan.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {number}
     */
    len() {
        const ret = wasm.wasmmellinloggrid_len(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} log_start
     * @param {number} log_step
     * @param {Float32Array} samples
     */
    constructor(log_start, log_step, samples) {
        const ret = wasm.wasmmellinloggrid_new(log_start, log_step, samples);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        WasmMellinLogGridFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {Float32Array}
     */
    samples() {
        const ret = wasm.wasmmellinloggrid_samples(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Float32Array}
     */
    support() {
        const ret = wasm.wasmmellinloggrid_support(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Float32Array}
     */
    weights() {
        const ret = wasm.wasmmellinloggrid_weights(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {Float32Array} s
     * @returns {Float32Array}
     */
    evaluate(s) {
        const ret = wasm.wasmmellinloggrid_evaluate(this.__wbg_ptr, s);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {boolean}
     */
    isEmpty() {
        const ret = wasm.wasmmellinloggrid_isEmpty(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    get logStep() {
        const ret = wasm.canvasdesirecontrol_learningRateEta(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} log_start
     * @param {number} log_step
     * @param {number} len
     * @param {string} window
     * @param {boolean} preserve_sum
     * @returns {WasmMellinLogGrid}
     */
    static expDecay(log_start, log_step, len, window, preserve_sum) {
        const ptr0 = passStringToWasm0(window, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmmellinloggrid_expDecay(log_start, log_step, len, ptr0, len0, preserve_sum);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmMellinLogGrid.__wrap(ret[0]);
    }
    /**
     * @returns {number}
     */
    get logStart() {
        const ret = wasm.canvasdesirecontrol_targetEntropy(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {Float32Array} s_values
     * @returns {WasmMellinEvalPlan}
     */
    planMany(s_values) {
        const ret = wasm.wasmmellinloggrid_planMany(this.__wbg_ptr, s_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmMellinEvalPlan.__wrap(ret[0]);
    }
    /**
     * @param {Float32Array} real_values
     * @param {Float32Array} imag_values
     * @returns {WasmMellinEvalPlan}
     */
    planMesh(real_values, imag_values) {
        const ret = wasm.wasmmellinloggrid_planMesh(this.__wbg_ptr, real_values, imag_values);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmMellinEvalPlan.__wrap(ret[0]);
    }
}
if (Symbol.dispose) WasmMellinLogGrid.prototype[Symbol.dispose] = WasmMellinLogGrid.prototype.free;

const WasmScaleStackFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmscalestack_free(ptr >>> 0, 1));

export class WasmScaleStack {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmScaleStack.prototype);
        obj.__wbg_ptr = ptr;
        WasmScaleStackFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmScaleStackFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmscalestack_free(ptr, 0);
    }
    /**
     * @returns {Float32Array}
     */
    persistence() {
        const ret = wasm.wasmscalestack_persistence(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get sampleCount() {
        const ret = wasm.wasmscalestack_sampleCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {Float32Array} levels
     * @returns {Float32Array}
     */
    coherenceProfile(levels) {
        const ret = wasm.wasmscalestack_coherenceProfile(this.__wbg_ptr, levels);
        return ret;
    }
    /**
     * @returns {number | undefined}
     */
    interfaceDensity() {
        const ret = wasm.wasmscalestack_interfaceDensity(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : ret[1];
    }
    /**
     * @param {number} ambient_dim
     * @param {number} window
     * @returns {number | undefined}
     */
    boundaryDimension(ambient_dim, window) {
        const ret = wasm.wasmscalestack_boundaryDimension(this.__wbg_ptr, ambient_dim, window);
        return ret[0] === 0 ? undefined : ret[1];
    }
    /**
     * @param {number} level
     * @returns {number | undefined}
     */
    coherenceBreakScale(level) {
        const ret = wasm.wasmscalestack_coherenceBreakScale(this.__wbg_ptr, level);
        return ret[0] === 0 ? undefined : ret[1];
    }
    /**
     * @returns {string}
     */
    get mode() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.wasmscalestack_mode(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {number} order
     * @returns {number}
     */
    moment(order) {
        const ret = wasm.wasmscalestack_moment(this.__wbg_ptr, order);
        return ret;
    }
    /**
     * @param {Float32Array} field
     * @param {Uint32Array} shape
     * @param {Float32Array} scales
     * @param {number} threshold
     * @returns {WasmScaleStack}
     */
    static scalar(field, shape, scales, threshold) {
        const ret = wasm.wasmscalestack_scalar(field, shape, scales, threshold);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmScaleStack.__wrap(ret[0]);
    }
    /**
     * @returns {Float32Array}
     */
    samples() {
        const ret = wasm.wasmscalestack_samples(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} ambient_dim
     * @param {number} dimension_window
     * @param {Float32Array} levels
     * @returns {string}
     */
    toJson(ambient_dim, dimension_window, levels) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmscalestack_toJson(this.__wbg_ptr, ambient_dim, dimension_window, levels);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @param {Float32Array} embeddings
     * @param {number} rows
     * @param {number} dims
     * @param {Float32Array} scales
     * @param {number} threshold
     * @param {string} metric
     * @returns {WasmScaleStack}
     */
    static semantic(embeddings, rows, dims, scales, threshold, metric) {
        const ptr0 = passStringToWasm0(metric, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmscalestack_semantic(embeddings, rows, dims, scales, threshold, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmScaleStack.__wrap(ret[0]);
    }
    /**
     * @returns {number}
     */
    get threshold() {
        const ret = wasm.wasmscalestack_threshold(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} ambient_dim
     * @param {number} dimension_window
     * @param {Float32Array} levels
     * @returns {any}
     */
    toObject(ambient_dim, dimension_window, levels) {
        const ret = wasm.wasmscalestack_toObject(this.__wbg_ptr, ambient_dim, dimension_window, levels);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) WasmScaleStack.prototype[Symbol.dispose] = WasmScaleStack.prototype.free;

const WasmTunerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmtuner_free(ptr >>> 0, 1));

export class WasmTuner {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmTuner.prototype);
        obj.__wbg_ptr = ptr;
        WasmTunerFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmTunerFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmtuner_free(ptr, 0);
    }
    /**
     * Merge additional overrides from a JSON blob, keeping the ordering stable.
     * @param {string} json
     */
    mergeJson(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmtuner_mergeJson(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Locate the first record matching the provided workload. Returns `undefined` when nothing matches.
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {any}
     */
    findRecord(rows, cols, k, subgroup) {
        const ret = wasm.wasmtuner_findRecord(this.__wbg_ptr, rows, cols, k, subgroup);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Construct a tuner from a JavaScript array of records.
     * @param {any} value
     * @returns {WasmTuner}
     */
    static fromObject(value) {
        const ret = wasm.wasmtuner_fromObject(value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmTuner.__wrap(ret[0]);
    }
    /**
     * Replace the table contents with the provided array of records.
     * @param {any} value
     */
    loadObject(value) {
        const ret = wasm.wasmtuner_loadObject(this.__wbg_ptr, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Merge additional overrides from a JavaScript array of records.
     * @param {any} value
     */
    mergeObject(value) {
        const ret = wasm.wasmtuner_mergeObject(this.__wbg_ptr, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Remove a record by index. Returns `undefined` for an out-of-bounds integer index.
     * @param {number} index
     * @returns {any}
     */
    removeIndex(index) {
        const ret = wasm.wasmtuner_removeIndex(this.__wbg_ptr, index);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Produce a tuned FFT plan encoded as JSON when an override exists.
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {string | undefined}
     */
    planFftJson(rows, cols, k, subgroup) {
        const ret = wasm.wasmtuner_planFftJson(this.__wbg_ptr, rows, cols, k, subgroup);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * Remove the first record matching the workload. Returns `undefined` when nothing matched.
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {any}
     */
    removeRecord(rows, cols, k, subgroup) {
        const ret = wasm.wasmtuner_removeRecord(this.__wbg_ptr, rows, cols, k, subgroup);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Replace the record at the provided index. Returns `true` when the index existed.
     * @param {number} index
     * @param {any} record
     * @returns {boolean}
     */
    replaceIndex(index, record) {
        const ret = wasm.wasmtuner_replaceIndex(this.__wbg_ptr, index, record);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Produce a tuned FFT plan encoded as a plain JavaScript object when an override exists.
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {any}
     */
    planFftObject(rows, cols, k, subgroup) {
        const ret = wasm.wasmtuner_planFftObject(this.__wbg_ptr, rows, cols, k, subgroup);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Resolve a tuned FFT plan and return a JSON-ready report describing how the plan was
     * assembled (override vs. heuristic vs. fallback).
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {any}
     */
    planFftReport(rows, cols, k, subgroup) {
        const ret = wasm.wasmtuner_planFftReport(this.__wbg_ptr, rows, cols, k, subgroup);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Resolve a tuned FFT plan and return metadata describing how the plan was
     * assembled (override vs. heuristic vs. fallback).
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {ResolvedWasmFftPlan}
     */
    planFftResolution(rows, cols, k, subgroup) {
        const ret = wasm.wasmtuner_planFftResolution(this.__wbg_ptr, rows, cols, k, subgroup);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ResolvedWasmFftPlan.__wrap(ret[0]);
    }
    /**
     * Resolve a tuned FFT plan. Falls back to heuristics (or base device caps)
     * when no explicit override matches.
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {WasmFftPlan}
     */
    planFftWithFallback(rows, cols, k, subgroup) {
        const ret = wasm.wasmtuner_planFftWithFallback(this.__wbg_ptr, rows, cols, k, subgroup);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmFftPlan.__wrap(ret[0]);
    }
    /**
     * Resolve a tuned FFT plan and encode the metadata report as JSON.
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {string}
     */
    planFftResolutionJson(rows, cols, k, subgroup) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmtuner_planFftResolutionJson(this.__wbg_ptr, rows, cols, k, subgroup);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Resolve a tuned FFT plan and encode the metadata report as a plain JavaScript object.
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {any}
     */
    planFftResolutionObject(rows, cols, k, subgroup) {
        const ret = wasm.wasmtuner_planFftResolutionObject(this.__wbg_ptr, rows, cols, k, subgroup);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Resolve a tuned FFT plan and encode it as JSON.
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {string}
     */
    planFftWithFallbackJson(rows, cols, k, subgroup) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmtuner_planFftWithFallbackJson(this.__wbg_ptr, rows, cols, k, subgroup);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Resolve a tuned FFT plan and encode it as a plain JavaScript object.
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {any}
     */
    planFftWithFallbackObject(rows, cols, k, subgroup) {
        const ret = wasm.wasmtuner_planFftWithFallbackObject(this.__wbg_ptr, rows, cols, k, subgroup);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Number of records available in the table.
     * @returns {number}
     */
    len() {
        const ret = wasm.wasmtuner_len(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Construct a tuner table. Pass `None` to start from an empty dataset or a JSON string to seed it.
     * @param {string | null} [json]
     */
    constructor(json) {
        var ptr0 = isLikeNone(json) ? 0 : passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmtuner_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        WasmTunerFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Append a new record represented as a JavaScript object.
     * @param {any} record
     */
    push(record) {
        const ret = wasm.wasmtuner_push(this.__wbg_ptr, record);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Clear every record from the table.
     */
    clear() {
        wasm.wasmtuner_clear(this.__wbg_ptr);
    }
    /**
     * Query the tuner for a given workload. Returns `undefined` when no override matches.
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {any}
     */
    choose(rows, cols, k, subgroup) {
        const ret = wasm.wasmtuner_choose(this.__wbg_ptr, rows, cols, k, subgroup);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Return the dataset as an array of JavaScript objects.
     * @returns {any}
     */
    records() {
        const ret = wasm.wasmtuner_records(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Return the internal dataset as a JSON string.
     * @returns {string}
     */
    to_json() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.wasmtuner_to_json(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Returns `true` when no overrides are stored.
     * @returns {boolean}
     */
    isEmpty() {
        const ret = wasm.wasmtuner_isEmpty(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Produce a tuned FFT plan for the provided workload if an override exists.
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {boolean} subgroup
     * @returns {WasmFftPlan | undefined}
     */
    planFft(rows, cols, k, subgroup) {
        const ret = wasm.wasmtuner_planFft(this.__wbg_ptr, rows, cols, k, subgroup);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] === 0 ? undefined : WasmFftPlan.__wrap(ret[0]);
    }
    /**
     * Replace the table contents with the provided JSON blob.
     * @param {string} json
     */
    loadJson(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmtuner_loadJson(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Retrieve a record by index. Returns `undefined` when the index is out of bounds.
     * @param {number} index
     * @returns {any}
     */
    recordAt(index) {
        const ret = wasm.wasmtuner_recordAt(this.__wbg_ptr, index);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Export the dataset into a JavaScript array of records.
     * @returns {any}
     */
    toObject() {
        const ret = wasm.wasmtuner_toObject(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) WasmTuner.prototype[Symbol.dispose] = WasmTuner.prototype.free;

const WgpuMatmulFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wgpumatmul_free(ptr >>> 0, 1));
/**
 * An explicit WebGPU workspace. It never falls back to WASM CPU tensor math.
 */
export class WgpuMatmul {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WgpuMatmul.prototype);
        obj.__wbg_ptr = ptr;
        WgpuMatmulFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WgpuMatmulFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wgpumatmul_free(ptr, 0);
    }
    /**
     * @param {number} rows
     * @param {number} inner
     * @param {number} cols
     * @param {number} tile_m
     * @param {number} tile_n
     * @param {number} tile_k
     * @returns {Promise<WgpuMatmul>}
     */
    static createWithTile(rows, inner, cols, tile_m, tile_n, tile_k) {
        const ret = wasm.wgpumatmul_createWithTile(rows, inner, cols, tile_m, tile_n, tile_k);
        return ret;
    }
    /**
     * @param {number} rows
     * @param {number} inner
     * @param {number} cols
     * @param {number} tile_m
     * @param {number} tile_n
     * @param {number} tile_k
     * @param {string} kernel
     * @returns {Promise<WgpuMatmul>}
     */
    static createWithKernel(rows, inner, cols, tile_m, tile_n, tile_k, kernel) {
        const ret = wasm.wgpumatmul_createWithKernel(rows, inner, cols, tile_m, tile_n, tile_k, kernel);
        return ret;
    }
    /**
     * @param {number} rows
     * @param {number} inner
     * @param {number} cols
     * @param {number} tile_m
     * @param {number} tile_n
     * @param {number} tile_k
     * @param {string} kernel
     * @param {string} accumulation
     * @returns {Promise<WgpuMatmul>}
     */
    static createWithOptions(rows, inner, cols, tile_m, tile_n, tile_k, kernel, accumulation) {
        const ret = wasm.wgpumatmul_createWithOptions(rows, inner, cols, tile_m, tile_n, tile_k, kernel, accumulation);
        return ret;
    }
    /**
     * @param {number} rows
     * @param {number} inner
     * @param {number} cols
     * @returns {Promise<WgpuMatmul>}
     */
    static create(rows, inner, cols) {
        const ret = wasm.wgpumatmul_create(rows, inner, cols);
        return ret;
    }
    /**
     * @returns {bigint}
     */
    get generation() {
        const ret = wasm.wgpumatmul_generation(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @param {Float32Array} rhs
     */
    uploadRhs(rhs) {
        const ret = wasm.wgpumatmul_uploadRhs(this.__wbg_ptr, rhs);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {Promise<void>}
     */
    synchronize() {
        const ret = wasm.wgpumatmul_synchronize(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {string}
     */
    get accumulation() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.wgpumatmul_accumulation(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    adapterInfo() {
        const ret = wasm.wgpumatmul_adapterInfo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {WgpuMatmul} source
     */
    setLhsFrom(source) {
        _assertClass(source, WgpuMatmul);
        const ret = wasm.wgpumatmul_setLhsFrom(this.__wbg_ptr, source.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {Uint32Array}
     */
    workgroupSize() {
        const ret = wasm.wgpumatmul_workgroupSize(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {boolean}
     */
    get outputIsCurrent() {
        const ret = wasm.wgpumatmul_outputIsCurrent(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {Uint32Array}
     */
    outputsPerThread() {
        const ret = wasm.wgpumatmul_outputsPerThread(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {Uint32Array}
     */
    shape() {
        const ret = wasm.wgpumatmul_shape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {string}
     */
    get kernel() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.wgpumatmul_kernel(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {Float32Array} lhs
     * @param {Float32Array} rhs
     */
    upload(lhs, rhs) {
        const ret = wasm.wgpumatmul_upload(this.__wbg_ptr, lhs, rhs);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Repetitions are validated before any JS-to-u32 narrowing.
     * @param {number | null} [repetitions]
     * @returns {bigint}
     */
    dispatch(repetitions) {
        const ret = wasm.wgpumatmul_dispatch(this.__wbg_ptr, isLikeNone(repetitions) ? 0 : addToExternrefTable0(repetitions));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BigInt.asUintN(64, ret[0]);
    }
    /**
     * Snapshot synchronously, then await mapping without holding a JS object borrow.
     * @returns {Promise<Float32Array>}
     */
    readback() {
        const ret = wasm.wgpumatmul_readback(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    tileMNK() {
        const ret = wasm.wgpumatmul_tileMNK(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) WgpuMatmul.prototype[Symbol.dispose] = WgpuMatmul.prototype.free;

const WgpuPointwiseInputsFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wgpupointwiseinputs_free(ptr >>> 0, 1));

export class WgpuPointwiseInputs {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WgpuPointwiseInputsFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wgpupointwiseinputs_free(ptr, 0);
    }
    /**
     * @param {WgpuTensor} tensor
     */
    add(tensor) {
        _assertClass(tensor, WgpuTensor);
        const ret = wasm.wgpupointwiseinputs_add(this.__wbg_ptr, tensor.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    constructor() {
        const ret = wasm.wgpupointwiseinputs_new();
        this.__wbg_ptr = ret >>> 0;
        WgpuPointwiseInputsFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} slot
     * @param {WgpuTensor} tensor
     */
    set(slot, tensor) {
        _assertClass(tensor, WgpuTensor);
        const ret = wasm.wgpupointwiseinputs_set(this.__wbg_ptr, slot, tensor.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {number}
     */
    get length() {
        const ret = wasm.wgpupointwiseinputs_length(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * JSON array of [operation, original-input-slot-or-null] pairs.
     * @param {string} steps
     * @returns {WgpuPointwisePlan}
     */
    compile(steps) {
        const ptr0 = passStringToWasm0(steps, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wgpupointwiseinputs_compile(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuPointwisePlan.__wrap(ret[0]);
    }
}
if (Symbol.dispose) WgpuPointwiseInputs.prototype[Symbol.dispose] = WgpuPointwiseInputs.prototype.free;

const WgpuPointwisePlanFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wgpupointwiseplan_free(ptr >>> 0, 1));

export class WgpuPointwisePlan {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WgpuPointwisePlan.prototype);
        obj.__wbg_ptr = ptr;
        WgpuPointwisePlanFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WgpuPointwisePlanFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wgpupointwiseplan_free(ptr, 0);
    }
    /**
     * @param {WgpuPointwiseInputs} inputs
     * @param {string} execution
     * @returns {WgpuTensor}
     */
    run(inputs, execution) {
        _assertClass(inputs, WgpuPointwiseInputs);
        const ptr0 = passStringToWasm0(execution, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wgpupointwiseplan_run(this.__wbg_ptr, inputs.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
}
if (Symbol.dispose) WgpuPointwisePlan.prototype[Symbol.dispose] = WgpuPointwisePlan.prototype.free;

const WgpuRankFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wgpurank_free(ptr >>> 0, 1));
/**
 * Exact rank workspace sharing Rust kernels, with no WASM CPU fallback.
 */
export class WgpuRank {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WgpuRank.prototype);
        obj.__wbg_ptr = ptr;
        WgpuRankFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WgpuRankFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wgpurank_free(ptr, 0);
    }
    /**
     * Construct from Rust-owned candidate geometry, without rebuilding the plan in JS.
     * @param {RankAdaptationSession} session
     * @param {number} candidate_index
     * @param {boolean | null} [timestamp_queries]
     * @returns {Promise<WgpuRank>}
     */
    static createFromAdaptation(session, candidate_index, timestamp_queries) {
        _assertClass(session, RankAdaptationSession);
        const ret = wasm.wgpurank_createFromAdaptation(session.__wbg_ptr, candidate_index, isLikeNone(timestamp_queries) ? 0 : addToExternrefTable0(timestamp_queries));
        return ret;
    }
    /**
     * @param {string} kind
     * @param {number} rows
     * @param {number} cols
     * @param {number} k
     * @param {number | null} [tile_cols]
     * @param {boolean | null} [timestamp_queries]
     * @returns {Promise<WgpuRank>}
     */
    static create(kind, rows, cols, k, tile_cols, timestamp_queries) {
        const ret = wasm.wgpurank_create(kind, rows, cols, k, isLikeNone(tile_cols) ? 0 : addToExternrefTable0(tile_cols), isLikeNone(timestamp_queries) ? 0 : addToExternrefTable0(timestamp_queries));
        return ret;
    }
    /**
     * @returns {bigint}
     */
    get generation() {
        const ret = wasm.wgpurank_generation(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {Promise<void>}
     */
    synchronize() {
        const ret = wasm.wgpurank_synchronize(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {any}
     */
    adapterInfo() {
        const ret = wasm.wgpurank_adapterInfo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {boolean}
     */
    get outputIsCurrent() {
        const ret = wasm.wgpurank_outputIsCurrent(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {WgpuMatmul} source
     * @param {number | null} [repetitions]
     * @returns {bigint}
     */
    dispatchFromMatmul(source, repetitions) {
        _assertClass(source, WgpuMatmul);
        const ret = wasm.wgpurank_dispatchFromMatmul(this.__wbg_ptr, source.__wbg_ptr, isLikeNone(repetitions) ? 0 : addToExternrefTable0(repetitions));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BigInt.asUintN(64, ret[0]);
    }
    /**
     * @param {WgpuMatmul} source
     */
    setInputFromMatmul(source) {
        _assertClass(source, WgpuMatmul);
        const ret = wasm.wgpurank_setInputFromMatmul(this.__wbg_ptr, source.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {boolean}
     */
    get timestampQueriesEnabled() {
        const ret = wasm.wgpurank_timestampQueriesEnabled(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {string}
     */
    get kind() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.wgpurank_kind(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {Uint32Array}
     */
    shape() {
        const ret = wasm.wgpurank_shape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {Float32Array} input
     */
    upload(input) {
        const ret = wasm.wgpurank_upload(this.__wbg_ptr, input);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * The promise owns query storage; later uploads or freeing the workspace are safe.
     * @param {number | null} [repetitions]
     * @returns {Promise<Record<string, unknown>>}
     */
    profile(repetitions) {
        const ret = wasm.wgpurank_profile(this.__wbg_ptr, isLikeNone(repetitions) ? 0 : addToExternrefTable0(repetitions));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number | null} [repetitions]
     * @returns {bigint}
     */
    dispatch(repetitions) {
        const ret = wasm.wgpurank_dispatch(this.__wbg_ptr, isLikeNone(repetitions) ? 0 : addToExternrefTable0(repetitions));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return BigInt.asUintN(64, ret[0]);
    }
    /**
     * @returns {Promise<{values: Float32Array; indices: Int32Array; generation: bigint}>}
     */
    readback() {
        const ret = wasm.wgpurank_readback(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {number}
     */
    get tileCols() {
        const ret = wasm.wgpurank_tileCols(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) WgpuRank.prototype[Symbol.dispose] = WgpuRank.prototype.free;

const WgpuTensorFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wgputensor_free(ptr >>> 0, 1));

export class WgpuTensor {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WgpuTensor.prototype);
        obj.__wbg_ptr = ptr;
        WgpuTensorFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WgpuTensorFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wgputensor_free(ptr, 0);
    }
    /**
     * @returns {WgpuTensor}
     */
    contiguous() {
        const ret = wasm.wgputensor_contiguous(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @param {number[]} shape
     * @returns {WgpuTensor}
     */
    broadcastTo(shape) {
        const ret = wasm.wgputensor_broadcastTo(this.__wbg_ptr, shape);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @returns {boolean}
     */
    get isContiguous() {
        const ret = wasm.wgputensor_isContiguous(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {WgpuTensor} other
     * @returns {boolean}
     */
    sharesStorageWith(other) {
        _assertClass(other, WgpuTensor);
        const ret = wasm.wgputensor_sharesStorageWith(this.__wbg_ptr, other.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {WgpuTensor} rhs
     * @returns {WgpuTensor}
     */
    add(rhs) {
        _assertClass(rhs, WgpuTensor);
        const ret = wasm.wgputensor_add(this.__wbg_ptr, rhs.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @param {WgpuTensor} rhs
     * @returns {WgpuTensor}
     */
    mul(rhs) {
        _assertClass(rhs, WgpuTensor);
        const ret = wasm.wgputensor_mul(this.__wbg_ptr, rhs.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @returns {WgpuTensor}
     */
    gelu() {
        const ret = wasm.wgputensor_gelu(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @returns {WgpuTensor}
     */
    relu() {
        const ret = wasm.wgputensor_relu(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @returns {number}
     */
    get numel() {
        const ret = wasm.wgputensor_numel(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {Uint32Array}
     */
    get shape() {
        const ret = wasm.wgputensor_shape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {WgpuTensorDevice}
     */
    device() {
        const ret = wasm.wgputensor_device(this.__wbg_ptr);
        return WgpuTensorDevice.__wrap(ret);
    }
    /**
     * @param {number} axis
     * @param {number} start
     * @param {number} length
     * @returns {WgpuTensor}
     */
    narrow(axis, start, length) {
        const ret = wasm.wgputensor_narrow(this.__wbg_ptr, axis, start, length);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @returns {number}
     */
    get offset() {
        const ret = wasm.wgputensor_offset(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number[]} axes
     * @returns {WgpuTensor}
     */
    permute(axes) {
        const ret = wasm.wgputensor_permute(this.__wbg_ptr, axes);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @param {number[]} shape
     * @returns {WgpuTensor}
     */
    reshape(shape) {
        const ret = wasm.wgputensor_reshape(this.__wbg_ptr, shape);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get strides() {
        const ret = wasm.wgputensor_strides(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {WgpuTensorSnapshot}
     */
    snapshot() {
        const ret = wasm.wgputensor_snapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensorSnapshot.__wrap(ret[0]);
    }
}
if (Symbol.dispose) WgpuTensor.prototype[Symbol.dispose] = WgpuTensor.prototype.free;

const WgpuTensorDeviceFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wgputensordevice_free(ptr >>> 0, 1));

export class WgpuTensorDevice {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WgpuTensorDevice.prototype);
        obj.__wbg_ptr = ptr;
        WgpuTensorDeviceFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WgpuTensorDeviceFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wgputensordevice_free(ptr, 0);
    }
    /**
     * @returns {Promise<WgpuTensorDevice>}
     */
    static create() {
        const ret = wasm.wgputensordevice_create();
        return ret;
    }
    /**
     * @returns {{ name: string; backend: string; device_type: string }}
     */
    adapterInfo() {
        const ret = wasm.wgputensordevice_adapterInfo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number[]} shape
     * @param {Float32Array} data
     * @returns {WgpuTensor}
     */
    upload(shape, data) {
        const ret = wasm.wgputensordevice_upload(this.__wbg_ptr, shape, data);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WgpuTensor.__wrap(ret[0]);
    }
}
if (Symbol.dispose) WgpuTensorDevice.prototype[Symbol.dispose] = WgpuTensorDevice.prototype.free;

const WgpuTensorSnapshotFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wgputensorsnapshot_free(ptr >>> 0, 1));

export class WgpuTensorSnapshot {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WgpuTensorSnapshot.prototype);
        obj.__wbg_ptr = ptr;
        WgpuTensorSnapshotFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WgpuTensorSnapshotFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wgputensorsnapshot_free(ptr, 0);
    }
    /**
     * @returns {Promise<Float32Array>}
     */
    readValues() {
        const ret = wasm.wgputensorsnapshot_readValues(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Uint32Array}
     */
    get shape() {
        const ret = wasm.wgputensorsnapshot_shape(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) WgpuTensorSnapshot.prototype[Symbol.dispose] = WgpuTensorSnapshot.prototype.free;

const EXPECTED_RESPONSE_TYPES = new Set(['basic', 'cors', 'default']);

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);

            } catch (e) {
                const validResponse = module.ok && EXPECTED_RESPONSE_TYPES.has(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else {
                    throw e;
                }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);

    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };

        } else {
            return instance;
        }
    }
}

function __wbg_get_imports() {
    const imports = {};
    imports.wbg = {};
    imports.wbg.__wbg_Error_e17e777aac105295 = function(arg0, arg1) {
        const ret = Error(getStringFromWasm0(arg0, arg1));
        return ret;
    };
    imports.wbg.__wbg_String_eecc4a11987127d6 = function(arg0, arg1) {
        const ret = String(arg1);
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_Window_563bd2ea5e20327e = function(arg0) {
        const ret = arg0.Window;
        return ret;
    };
    imports.wbg.__wbg_WorkerGlobalScope_e695d6876d82e4fa = function(arg0) {
        const ret = arg0.WorkerGlobalScope;
        return ret;
    };
    imports.wbg.__wbg_beginComputePass_0aa18bfccdf69741 = function(arg0, arg1) {
        const ret = arg0.beginComputePass(arg1);
        return ret;
    };
    imports.wbg.__wbg_beginRenderPass_53ef815f41b28864 = function(arg0, arg1) {
        const ret = arg0.beginRenderPass(arg1);
        return ret;
    };
    imports.wbg.__wbg_buffer_8d40b1d762fb3c66 = function(arg0) {
        const ret = arg0.buffer;
        return ret;
    };
    imports.wbg.__wbg_call_13410aac570ffff7 = function() { return handleError(function (arg0, arg1) {
        const ret = arg0.call(arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_call_a5400b25a865cfd8 = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = arg0.call(arg1, arg2);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_clearBuffer_ccef148cf9ae820f = function(arg0, arg1, arg2) {
        arg0.clearBuffer(arg1, arg2);
    };
    imports.wbg.__wbg_clearBuffer_e12c26bfd255cc00 = function(arg0, arg1, arg2, arg3) {
        arg0.clearBuffer(arg1, arg2, arg3);
    };
    imports.wbg.__wbg_configure_44a29c6c4754af44 = function(arg0, arg1) {
        arg0.configure(arg1);
    };
    imports.wbg.__wbg_copyBufferToBuffer_fda25f28a360b893 = function(arg0, arg1, arg2, arg3, arg4, arg5) {
        arg0.copyBufferToBuffer(arg1, arg2, arg3, arg4, arg5);
    };
    imports.wbg.__wbg_copyBufferToTexture_441ec4783f46a140 = function(arg0, arg1, arg2, arg3) {
        arg0.copyBufferToTexture(arg1, arg2, arg3);
    };
    imports.wbg.__wbg_copyExternalImageToTexture_89f962660b70a96f = function(arg0, arg1, arg2, arg3) {
        arg0.copyExternalImageToTexture(arg1, arg2, arg3);
    };
    imports.wbg.__wbg_copyTextureToBuffer_adba4c374bb3f154 = function(arg0, arg1, arg2, arg3) {
        arg0.copyTextureToBuffer(arg1, arg2, arg3);
    };
    imports.wbg.__wbg_copyTextureToTexture_aa157cfda6a09746 = function(arg0, arg1, arg2, arg3) {
        arg0.copyTextureToTexture(arg1, arg2, arg3);
    };
    imports.wbg.__wbg_createBindGroupLayout_e5ea24d36f8738cd = function(arg0, arg1) {
        const ret = arg0.createBindGroupLayout(arg1);
        return ret;
    };
    imports.wbg.__wbg_createBindGroup_532dcf2b1d1517a2 = function(arg0, arg1) {
        const ret = arg0.createBindGroup(arg1);
        return ret;
    };
    imports.wbg.__wbg_createBuffer_68bbbb0ad2796954 = function(arg0, arg1) {
        const ret = arg0.createBuffer(arg1);
        return ret;
    };
    imports.wbg.__wbg_createCommandEncoder_ffb9c73757fd784f = function(arg0, arg1) {
        const ret = arg0.createCommandEncoder(arg1);
        return ret;
    };
    imports.wbg.__wbg_createComputePipeline_561a4a1d7e15d99a = function(arg0, arg1) {
        const ret = arg0.createComputePipeline(arg1);
        return ret;
    };
    imports.wbg.__wbg_createPipelineLayout_f638db6fd667b6ec = function(arg0, arg1) {
        const ret = arg0.createPipelineLayout(arg1);
        return ret;
    };
    imports.wbg.__wbg_createQuerySet_3f3f140611ddd6e2 = function(arg0, arg1) {
        const ret = arg0.createQuerySet(arg1);
        return ret;
    };
    imports.wbg.__wbg_createRenderBundleEncoder_648fed7a6cff9f0c = function(arg0, arg1) {
        const ret = arg0.createRenderBundleEncoder(arg1);
        return ret;
    };
    imports.wbg.__wbg_createRenderPipeline_5d836d188509f115 = function(arg0, arg1) {
        const ret = arg0.createRenderPipeline(arg1);
        return ret;
    };
    imports.wbg.__wbg_createSampler_5d636601494930d6 = function(arg0, arg1) {
        const ret = arg0.createSampler(arg1);
        return ret;
    };
    imports.wbg.__wbg_createShaderModule_9651f9e267678889 = function(arg0, arg1) {
        const ret = arg0.createShaderModule(arg1);
        return ret;
    };
    imports.wbg.__wbg_createTexture_5066eb1c20d2a17a = function(arg0, arg1) {
        const ret = arg0.createTexture(arg1);
        return ret;
    };
    imports.wbg.__wbg_createView_0873fe69e39fb7e1 = function(arg0, arg1) {
        const ret = arg0.createView(arg1);
        return ret;
    };
    imports.wbg.__wbg_destroy_20cd29e4833ae16f = function(arg0) {
        arg0.destroy();
    };
    imports.wbg.__wbg_destroy_a6a67ddd44990768 = function(arg0) {
        arg0.destroy();
    };
    imports.wbg.__wbg_destroy_aa63504c83aafcdf = function(arg0) {
        arg0.destroy();
    };
    imports.wbg.__wbg_destroy_c13dd004df6ad4b1 = function(arg0) {
        arg0.destroy();
    };
    imports.wbg.__wbg_dispatchWorkgroupsIndirect_0ff33fbd92c36452 = function(arg0, arg1, arg2) {
        arg0.dispatchWorkgroupsIndirect(arg1, arg2);
    };
    imports.wbg.__wbg_dispatchWorkgroups_67069bd10c4f401e = function(arg0, arg1, arg2, arg3) {
        arg0.dispatchWorkgroups(arg1 >>> 0, arg2 >>> 0, arg3 >>> 0);
    };
    imports.wbg.__wbg_document_7d29d139bd619045 = function(arg0) {
        const ret = arg0.document;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_done_75ed0ee6dd243d9d = function(arg0) {
        const ret = arg0.done;
        return ret;
    };
    imports.wbg.__wbg_drawIndexedIndirect_d2f77a326e20788f = function(arg0, arg1, arg2) {
        arg0.drawIndexedIndirect(arg1, arg2);
    };
    imports.wbg.__wbg_drawIndexedIndirect_ee49d125c486cb17 = function(arg0, arg1, arg2) {
        arg0.drawIndexedIndirect(arg1, arg2);
    };
    imports.wbg.__wbg_drawIndexed_88aca11dfdc2d177 = function(arg0, arg1, arg2, arg3, arg4, arg5) {
        arg0.drawIndexed(arg1 >>> 0, arg2 >>> 0, arg3 >>> 0, arg4, arg5 >>> 0);
    };
    imports.wbg.__wbg_drawIndexed_c9a61ea0f89b53fa = function(arg0, arg1, arg2, arg3, arg4, arg5) {
        arg0.drawIndexed(arg1 >>> 0, arg2 >>> 0, arg3 >>> 0, arg4, arg5 >>> 0);
    };
    imports.wbg.__wbg_drawIndirect_8ff3489a5c8c662c = function(arg0, arg1, arg2) {
        arg0.drawIndirect(arg1, arg2);
    };
    imports.wbg.__wbg_drawIndirect_d955a377ff046f98 = function(arg0, arg1, arg2) {
        arg0.drawIndirect(arg1, arg2);
    };
    imports.wbg.__wbg_draw_2ffb72300ee8cc2e = function(arg0, arg1, arg2, arg3, arg4) {
        arg0.draw(arg1 >>> 0, arg2 >>> 0, arg3 >>> 0, arg4 >>> 0);
    };
    imports.wbg.__wbg_draw_332a9c15636395ba = function(arg0, arg1, arg2, arg3, arg4) {
        arg0.draw(arg1 >>> 0, arg2 >>> 0, arg3 >>> 0, arg4 >>> 0);
    };
    imports.wbg.__wbg_end_3e5311324e67731f = function(arg0) {
        arg0.end();
    };
    imports.wbg.__wbg_end_c2f472aecb85259d = function(arg0) {
        arg0.end();
    };
    imports.wbg.__wbg_entries_2be2f15bd5554996 = function(arg0) {
        const ret = Object.entries(arg0);
        return ret;
    };
    imports.wbg.__wbg_error_d622e8e577addd73 = function(arg0) {
        const ret = arg0.error;
        return ret;
    };
    imports.wbg.__wbg_executeBundles_b0e648db8dc1b716 = function(arg0, arg1) {
        arg0.executeBundles(arg1);
    };
    imports.wbg.__wbg_features_3546fcef4ce4ecdc = function(arg0) {
        const ret = arg0.features;
        return ret;
    };
    imports.wbg.__wbg_features_d41a6de13773f2bd = function(arg0) {
        const ret = arg0.features;
        return ret;
    };
    imports.wbg.__wbg_finish_14a374457d14ecd4 = function(arg0) {
        const ret = arg0.finish();
        return ret;
    };
    imports.wbg.__wbg_finish_381e236404f87d87 = function(arg0, arg1) {
        const ret = arg0.finish(arg1);
        return ret;
    };
    imports.wbg.__wbg_finish_3c69a489f855d8b6 = function(arg0, arg1) {
        const ret = arg0.finish(arg1);
        return ret;
    };
    imports.wbg.__wbg_finish_633c3004d2cdfa16 = function(arg0) {
        const ret = arg0.finish();
        return ret;
    };
    imports.wbg.__wbg_from_88bc52ce20ba6318 = function(arg0) {
        const ret = Array.from(arg0);
        return ret;
    };
    imports.wbg.__wbg_getBindGroupLayout_419be41b4a0002b5 = function(arg0, arg1) {
        const ret = arg0.getBindGroupLayout(arg1 >>> 0);
        return ret;
    };
    imports.wbg.__wbg_getBindGroupLayout_48a2c08f87001d6f = function(arg0, arg1) {
        const ret = arg0.getBindGroupLayout(arg1 >>> 0);
        return ret;
    };
    imports.wbg.__wbg_getContext_15e158d04230a6f6 = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = arg0.getContext(getStringFromWasm0(arg1, arg2));
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    }, arguments) };
    imports.wbg.__wbg_getContext_8b08935510bf607c = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = arg0.getContext(getStringFromWasm0(arg1, arg2));
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    }, arguments) };
    imports.wbg.__wbg_getCurrentTexture_b103c75d72d87929 = function(arg0) {
        const ret = arg0.getCurrentTexture();
        return ret;
    };
    imports.wbg.__wbg_getMappedRange_ad618ba2d1e3f591 = function(arg0, arg1, arg2) {
        const ret = arg0.getMappedRange(arg1, arg2);
        return ret;
    };
    imports.wbg.__wbg_getOwnPropertyDescriptor_b58e9c0d5f644b26 = function(arg0, arg1) {
        const ret = Object.getOwnPropertyDescriptor(arg0, arg1);
        return ret;
    };
    imports.wbg.__wbg_getPreferredCanvasFormat_d0d0494efb1ab417 = function(arg0) {
        const ret = arg0.getPreferredCanvasFormat();
        return (__wbindgen_enum_GpuTextureFormat.indexOf(ret) + 1 || 96) - 1;
    };
    imports.wbg.__wbg_getPrototypeOf_5f6a7286bc86df66 = function(arg0) {
        const ret = Object.getPrototypeOf(arg0);
        return ret;
    };
    imports.wbg.__wbg_get_0da715ceaecea5c8 = function(arg0, arg1) {
        const ret = arg0[arg1 >>> 0];
        return ret;
    };
    imports.wbg.__wbg_get_2a8fe8079145daf7 = function(arg0, arg1) {
        const ret = arg0[arg1 >>> 0];
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_get_458e874b43b18b25 = function() { return handleError(function (arg0, arg1) {
        const ret = Reflect.get(arg0, arg1);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_getwithrefkey_6550b2c093d2eb18 = function(arg0, arg1) {
        const ret = arg0[arg1];
        return ret;
    };
    imports.wbg.__wbg_gpu_e588d24cdee270c7 = function(arg0) {
        const ret = arg0.gpu;
        return ret;
    };
    imports.wbg.__wbg_graphtrainingstate_new = function(arg0) {
        const ret = GraphTrainingState.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_has_54425913d46d860c = function(arg0, arg1, arg2) {
        const ret = arg0.has(getStringFromWasm0(arg1, arg2));
        return ret;
    };
    imports.wbg.__wbg_height_228fe8a75d4d09d6 = function(arg0) {
        const ret = arg0.height;
        return ret;
    };
    imports.wbg.__wbg_inferenceplan_new = function(arg0) {
        const ret = InferencePlan.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_instanceof_ArrayBuffer_67f3012529f6a2dd = function(arg0) {
        let result;
        try {
            result = arg0 instanceof ArrayBuffer;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_CanvasRenderingContext2d_8c616198ec03b12f = function(arg0) {
        let result;
        try {
            result = arg0 instanceof CanvasRenderingContext2D;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_GpuAdapter_756c7c5930793c56 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof GPUAdapter;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_GpuCanvasContext_97084852a24cda42 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof GPUCanvasContext;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_GpuDeviceLostInfo_23dc505e0f4c6916 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof GPUDeviceLostInfo;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_GpuError_a95d6d675323b1ca = function(arg0) {
        let result;
        try {
            result = arg0 instanceof GPUError;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_GpuOutOfMemoryError_a10b029451767dba = function(arg0) {
        let result;
        try {
            result = arg0 instanceof GPUOutOfMemoryError;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_GpuValidationError_2d9aaa1f6d534392 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof GPUValidationError;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_Object_fbf5fef4952ff29b = function(arg0) {
        let result;
        try {
            result = arg0 instanceof Object;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_Uint8Array_9a8378d955933db7 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof Uint8Array;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_instanceof_Window_12d20d558ef92592 = function(arg0) {
        let result;
        try {
            result = arg0 instanceof Window;
        } catch (_) {
            result = false;
        }
        const ret = result;
        return ret;
    };
    imports.wbg.__wbg_isArray_030cce220591fb41 = function(arg0) {
        const ret = Array.isArray(arg0);
        return ret;
    };
    imports.wbg.__wbg_isSafeInteger_1c0d1af5542e102a = function(arg0) {
        const ret = Number.isSafeInteger(arg0);
        return ret;
    };
    imports.wbg.__wbg_isView_525e096e23d1c53b = function(arg0) {
        const ret = ArrayBuffer.isView(arg0);
        return ret;
    };
    imports.wbg.__wbg_iterator_f370b34483c71a1c = function() {
        const ret = Symbol.iterator;
        return ret;
    };
    imports.wbg.__wbg_label_595ec72f4fb05a87 = function(arg0, arg1) {
        const ret = arg1.label;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_length_186546c51cd61acd = function(arg0) {
        const ret = arg0.length;
        return ret;
    };
    imports.wbg.__wbg_length_555ae304a7c78975 = function(arg0) {
        const ret = arg0.length;
        return ret;
    };
    imports.wbg.__wbg_length_6bb7e81f9d7713e4 = function(arg0) {
        const ret = arg0.length;
        return ret;
    };
    imports.wbg.__wbg_length_9d771c54845e987f = function(arg0) {
        const ret = arg0.length;
        return ret;
    };
    imports.wbg.__wbg_length_a8cca01d07ea9653 = function(arg0) {
        const ret = arg0.length;
        return ret;
    };
    imports.wbg.__wbg_limits_00b1acc533d895ed = function(arg0) {
        const ret = arg0.limits;
        return ret;
    };
    imports.wbg.__wbg_limits_6b4a778fc459718c = function(arg0) {
        const ret = arg0.limits;
        return ret;
    };
    imports.wbg.__wbg_lost_34c2b392ca3313a8 = function(arg0) {
        const ret = arg0.lost;
        return ret;
    };
    imports.wbg.__wbg_mapAsync_77528428189fd95e = function(arg0, arg1, arg2, arg3) {
        const ret = arg0.mapAsync(arg1 >>> 0, arg2, arg3);
        return ret;
    };
    imports.wbg.__wbg_maxBindGroups_e0e2005bf277e29c = function(arg0) {
        const ret = arg0.maxBindGroups;
        return ret;
    };
    imports.wbg.__wbg_maxBindingsPerBindGroup_dca64e50cfa942bc = function(arg0) {
        const ret = arg0.maxBindingsPerBindGroup;
        return ret;
    };
    imports.wbg.__wbg_maxBufferSize_5d5aba3e80274c4c = function(arg0) {
        const ret = arg0.maxBufferSize;
        return ret;
    };
    imports.wbg.__wbg_maxColorAttachmentBytesPerSample_bb8c4bbc2e02d5ba = function(arg0) {
        const ret = arg0.maxColorAttachmentBytesPerSample;
        return ret;
    };
    imports.wbg.__wbg_maxColorAttachments_fc943e6b4aa801dd = function(arg0) {
        const ret = arg0.maxColorAttachments;
        return ret;
    };
    imports.wbg.__wbg_maxComputeInvocationsPerWorkgroup_25f50a6129b52ade = function(arg0) {
        const ret = arg0.maxComputeInvocationsPerWorkgroup;
        return ret;
    };
    imports.wbg.__wbg_maxComputeWorkgroupSizeX_10e229023642213e = function(arg0) {
        const ret = arg0.maxComputeWorkgroupSizeX;
        return ret;
    };
    imports.wbg.__wbg_maxComputeWorkgroupSizeY_6be9a12596cdad6a = function(arg0) {
        const ret = arg0.maxComputeWorkgroupSizeY;
        return ret;
    };
    imports.wbg.__wbg_maxComputeWorkgroupSizeZ_9e5a8c47db59725f = function(arg0) {
        const ret = arg0.maxComputeWorkgroupSizeZ;
        return ret;
    };
    imports.wbg.__wbg_maxComputeWorkgroupStorageSize_45bdd386bfb1a994 = function(arg0) {
        const ret = arg0.maxComputeWorkgroupStorageSize;
        return ret;
    };
    imports.wbg.__wbg_maxComputeWorkgroupsPerDimension_01ead98ba0d8c05e = function(arg0) {
        const ret = arg0.maxComputeWorkgroupsPerDimension;
        return ret;
    };
    imports.wbg.__wbg_maxDynamicStorageBuffersPerPipelineLayout_3a1d53b00d9867ee = function(arg0) {
        const ret = arg0.maxDynamicStorageBuffersPerPipelineLayout;
        return ret;
    };
    imports.wbg.__wbg_maxDynamicUniformBuffersPerPipelineLayout_798c55e04b3ecff1 = function(arg0) {
        const ret = arg0.maxDynamicUniformBuffersPerPipelineLayout;
        return ret;
    };
    imports.wbg.__wbg_maxSampledTexturesPerShaderStage_60a854f17955c20f = function(arg0) {
        const ret = arg0.maxSampledTexturesPerShaderStage;
        return ret;
    };
    imports.wbg.__wbg_maxSamplersPerShaderStage_22d1858ad4d60b31 = function(arg0) {
        const ret = arg0.maxSamplersPerShaderStage;
        return ret;
    };
    imports.wbg.__wbg_maxStorageBufferBindingSize_4c123b124dda3418 = function(arg0) {
        const ret = arg0.maxStorageBufferBindingSize;
        return ret;
    };
    imports.wbg.__wbg_maxStorageBuffersPerShaderStage_cb0f610196e32663 = function(arg0) {
        const ret = arg0.maxStorageBuffersPerShaderStage;
        return ret;
    };
    imports.wbg.__wbg_maxStorageTexturesPerShaderStage_eb5429b7737386f2 = function(arg0) {
        const ret = arg0.maxStorageTexturesPerShaderStage;
        return ret;
    };
    imports.wbg.__wbg_maxTextureArrayLayers_7f64e10e81f65012 = function(arg0) {
        const ret = arg0.maxTextureArrayLayers;
        return ret;
    };
    imports.wbg.__wbg_maxTextureDimension1D_25a39ba1a487f178 = function(arg0) {
        const ret = arg0.maxTextureDimension1D;
        return ret;
    };
    imports.wbg.__wbg_maxTextureDimension2D_0ac15d35ef467425 = function(arg0) {
        const ret = arg0.maxTextureDimension2D;
        return ret;
    };
    imports.wbg.__wbg_maxTextureDimension3D_88dad06c70e45e51 = function(arg0) {
        const ret = arg0.maxTextureDimension3D;
        return ret;
    };
    imports.wbg.__wbg_maxUniformBufferBindingSize_8c156e8aff2a098d = function(arg0) {
        const ret = arg0.maxUniformBufferBindingSize;
        return ret;
    };
    imports.wbg.__wbg_maxUniformBuffersPerShaderStage_3ddf2d5726e7220c = function(arg0) {
        const ret = arg0.maxUniformBuffersPerShaderStage;
        return ret;
    };
    imports.wbg.__wbg_maxVertexAttributes_85b5eb12fe4fced9 = function(arg0) {
        const ret = arg0.maxVertexAttributes;
        return ret;
    };
    imports.wbg.__wbg_maxVertexBufferArrayStride_1d940c152fb5cf61 = function(arg0) {
        const ret = arg0.maxVertexBufferArrayStride;
        return ret;
    };
    imports.wbg.__wbg_maxVertexBuffers_cb33605226776560 = function(arg0) {
        const ret = arg0.maxVertexBuffers;
        return ret;
    };
    imports.wbg.__wbg_message_82aca63a2754594a = function(arg0, arg1) {
        const ret = arg1.message;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_message_c8f868406260dbb1 = function(arg0, arg1) {
        const ret = arg1.message;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_minStorageBufferOffsetAlignment_1088f401e9416c78 = function(arg0) {
        const ret = arg0.minStorageBufferOffsetAlignment;
        return ret;
    };
    imports.wbg.__wbg_minUniformBufferOffsetAlignment_499665b117399a99 = function(arg0) {
        const ret = arg0.minUniformBufferOffsetAlignment;
        return ret;
    };
    imports.wbg.__wbg_navigator_65d5ad763926b868 = function(arg0) {
        const ret = arg0.navigator;
        return ret;
    };
    imports.wbg.__wbg_navigator_bfaf1b0b0eb48da2 = function(arg0) {
        const ret = arg0.navigator;
        return ret;
    };
    imports.wbg.__wbg_new_19c25a3f2fa63a02 = function() {
        const ret = new Object();
        return ret;
    };
    imports.wbg.__wbg_new_1f3a344cf3123716 = function() {
        const ret = new Array();
        return ret;
    };
    imports.wbg.__wbg_new_2e3c58a15f39f5f9 = function(arg0, arg1) {
        try {
            var state0 = {a: arg0, b: arg1};
            var cb0 = (arg0, arg1) => {
                const a = state0.a;
                state0.a = 0;
                try {
                    return __wbg_adapter_1168(a, state0.b, arg0, arg1);
                } finally {
                    state0.a = a;
                }
            };
            const ret = new Promise(cb0);
            return ret;
        } finally {
            state0.a = state0.b = 0;
        }
    };
    imports.wbg.__wbg_new_2ff1f68f3676ea53 = function() {
        const ret = new Map();
        return ret;
    };
    imports.wbg.__wbg_new_638ebfaedbf32a5e = function(arg0) {
        const ret = new Uint8Array(arg0);
        return ret;
    };
    imports.wbg.__wbg_new_da9dc54c5db29dfa = function(arg0, arg1) {
        const ret = new Error(getStringFromWasm0(arg0, arg1));
        return ret;
    };
    imports.wbg.__wbg_newfromslice_074c56947bd43469 = function(arg0, arg1) {
        const ret = new Uint8Array(getArrayU8FromWasm0(arg0, arg1));
        return ret;
    };
    imports.wbg.__wbg_newfromslice_32279e2fa6414ad4 = function(arg0, arg1) {
        const ret = new Int32Array(getArrayI32FromWasm0(arg0, arg1));
        return ret;
    };
    imports.wbg.__wbg_newfromslice_bd5b07f10e7e3c36 = function(arg0, arg1) {
        const ret = new Uint32Array(getArrayU32FromWasm0(arg0, arg1));
        return ret;
    };
    imports.wbg.__wbg_newfromslice_eb3df67955925a7c = function(arg0, arg1) {
        const ret = new Float32Array(getArrayF32FromWasm0(arg0, arg1));
        return ret;
    };
    imports.wbg.__wbg_newnoargs_254190557c45b4ec = function(arg0, arg1) {
        const ret = new Function(getStringFromWasm0(arg0, arg1));
        return ret;
    };
    imports.wbg.__wbg_newwithbyteoffsetandlength_e8f53910b4d42b45 = function(arg0, arg1, arg2) {
        const ret = new Uint8Array(arg0, arg1 >>> 0, arg2 >>> 0);
        return ret;
    };
    imports.wbg.__wbg_newwithlength_44bfcf58f92f38aa = function(arg0) {
        const ret = new Uint32Array(arg0 >>> 0);
        return ret;
    };
    imports.wbg.__wbg_newwithlength_a167dcc7aaa3ba77 = function(arg0) {
        const ret = new Uint8Array(arg0 >>> 0);
        return ret;
    };
    imports.wbg.__wbg_newwithu8clampedarrayandsh_132382d049b78e28 = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        const ret = new ImageData(getClampedArrayU8FromWasm0(arg0, arg1), arg2 >>> 0, arg3 >>> 0);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_next_5b3530e612fde77d = function(arg0) {
        const ret = arg0.next;
        return ret;
    };
    imports.wbg.__wbg_next_692e82279131b03c = function() { return handleError(function (arg0) {
        const ret = arg0.next();
        return ret;
    }, arguments) };
    imports.wbg.__wbg_now_1e80617bcee43265 = function() {
        const ret = Date.now();
        return ret;
    };
    imports.wbg.__wbg_onSubmittedWorkDone_f16ceab73d163a12 = function(arg0) {
        const ret = arg0.onSubmittedWorkDone();
        return ret;
    };
    imports.wbg.__wbg_parse_442f5ba02e5eaf8b = function() { return handleError(function (arg0, arg1) {
        const ret = JSON.parse(getStringFromWasm0(arg0, arg1));
        return ret;
    }, arguments) };
    imports.wbg.__wbg_popErrorScope_edc93dd0f448a5c0 = function(arg0) {
        const ret = arg0.popErrorScope();
        return ret;
    };
    imports.wbg.__wbg_prototypesetcall_3d4a26c1ed734349 = function(arg0, arg1, arg2) {
        Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
    };
    imports.wbg.__wbg_prototypesetcall_5521f1dd01df76fd = function(arg0, arg1, arg2) {
        Float32Array.prototype.set.call(getArrayF32FromWasm0(arg0, arg1), arg2);
    };
    imports.wbg.__wbg_prototypesetcall_c805289d23423a87 = function(arg0, arg1, arg2) {
        Uint32Array.prototype.set.call(getArrayU32FromWasm0(arg0, arg1), arg2);
    };
    imports.wbg.__wbg_pushErrorScope_18298b29344c9d0f = function(arg0, arg1) {
        arg0.pushErrorScope(__wbindgen_enum_GpuErrorFilter[arg1]);
    };
    imports.wbg.__wbg_push_330b2eb93e4e1212 = function(arg0, arg1) {
        const ret = arg0.push(arg1);
        return ret;
    };
    imports.wbg.__wbg_putImageData_0324b5d1f2cb58d9 = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        arg0.putImageData(arg1, arg2, arg3);
    }, arguments) };
    imports.wbg.__wbg_querySelectorAll_71b924f0e83d096b = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = arg0.querySelectorAll(getStringFromWasm0(arg1, arg2));
        return ret;
    }, arguments) };
    imports.wbg.__wbg_queueMicrotask_25d0739ac89e8c88 = function(arg0) {
        queueMicrotask(arg0);
    };
    imports.wbg.__wbg_queueMicrotask_4488407636f5bf24 = function(arg0) {
        const ret = arg0.queueMicrotask;
        return ret;
    };
    imports.wbg.__wbg_queue_c8d677144b5fc1d3 = function(arg0) {
        const ret = arg0.queue;
        return ret;
    };
    imports.wbg.__wbg_reason_180db105dffbd51c = function(arg0) {
        const ret = arg0.reason;
        return (__wbindgen_enum_GpuDeviceLostReason.indexOf(ret) + 1 || 3) - 1;
    };
    imports.wbg.__wbg_requestAdapter_a39a5f697bf04d1b = function(arg0, arg1) {
        const ret = arg0.requestAdapter(arg1);
        return ret;
    };
    imports.wbg.__wbg_requestDevice_09a893eceaf71338 = function(arg0, arg1) {
        const ret = arg0.requestDevice(arg1);
        return ret;
    };
    imports.wbg.__wbg_residentgraphautograd_new = function(arg0) {
        const ret = ResidentGraphAutograd.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_residentgraphinference_new = function(arg0) {
        const ret = ResidentGraphInference.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_residentgraphlearner_new = function(arg0) {
        const ret = ResidentGraphLearner.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_residentgraphtraining_new = function(arg0) {
        const ret = ResidentGraphTraining.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_residentinference_new = function(arg0) {
        const ret = ResidentInference.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_residenttraining_new = function(arg0) {
        const ret = ResidentTraining.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_resolveQuerySet_cb73a5901f965971 = function(arg0, arg1, arg2, arg3, arg4, arg5) {
        arg0.resolveQuerySet(arg1, arg2 >>> 0, arg3 >>> 0, arg4, arg5 >>> 0);
    };
    imports.wbg.__wbg_resolve_4055c623acdd6a1b = function(arg0) {
        const ret = Promise.resolve(arg0);
        return ret;
    };
    imports.wbg.__wbg_setBindGroup_2bc3cdb7b5fd543d = function(arg0, arg1, arg2) {
        arg0.setBindGroup(arg1 >>> 0, arg2);
    };
    imports.wbg.__wbg_setBindGroup_37888b649b0d48d2 = function(arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
        arg0.setBindGroup(arg1 >>> 0, arg2, getArrayU32FromWasm0(arg3, arg4), arg5, arg6 >>> 0);
    };
    imports.wbg.__wbg_setBindGroup_6b5ea9f3bcadfa9f = function(arg0, arg1, arg2) {
        arg0.setBindGroup(arg1 >>> 0, arg2);
    };
    imports.wbg.__wbg_setBindGroup_76a495defdde498f = function(arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
        arg0.setBindGroup(arg1 >>> 0, arg2, getArrayU32FromWasm0(arg3, arg4), arg5, arg6 >>> 0);
    };
    imports.wbg.__wbg_setBindGroup_9beb498b55637c21 = function(arg0, arg1, arg2) {
        arg0.setBindGroup(arg1 >>> 0, arg2);
    };
    imports.wbg.__wbg_setBindGroup_e39de9d193a7ceb6 = function(arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
        arg0.setBindGroup(arg1 >>> 0, arg2, getArrayU32FromWasm0(arg3, arg4), arg5, arg6 >>> 0);
    };
    imports.wbg.__wbg_setBlendConstant_7cac140c963a9b5a = function(arg0, arg1) {
        arg0.setBlendConstant(arg1);
    };
    imports.wbg.__wbg_setIndexBuffer_330351cc38a43d89 = function(arg0, arg1, arg2, arg3, arg4) {
        arg0.setIndexBuffer(arg1, __wbindgen_enum_GpuIndexFormat[arg2], arg3, arg4);
    };
    imports.wbg.__wbg_setIndexBuffer_58b60f5726bf7e43 = function(arg0, arg1, arg2, arg3, arg4) {
        arg0.setIndexBuffer(arg1, __wbindgen_enum_GpuIndexFormat[arg2], arg3, arg4);
    };
    imports.wbg.__wbg_setIndexBuffer_5b74d4dd90a2c2de = function(arg0, arg1, arg2, arg3) {
        arg0.setIndexBuffer(arg1, __wbindgen_enum_GpuIndexFormat[arg2], arg3);
    };
    imports.wbg.__wbg_setIndexBuffer_6b80b7fe969d3519 = function(arg0, arg1, arg2, arg3) {
        arg0.setIndexBuffer(arg1, __wbindgen_enum_GpuIndexFormat[arg2], arg3);
    };
    imports.wbg.__wbg_setPipeline_7e68b7c7817e4fe5 = function(arg0, arg1) {
        arg0.setPipeline(arg1);
    };
    imports.wbg.__wbg_setPipeline_97ccf1b76527774b = function(arg0, arg1) {
        arg0.setPipeline(arg1);
    };
    imports.wbg.__wbg_setPipeline_b6d8f788172b8330 = function(arg0, arg1) {
        arg0.setPipeline(arg1);
    };
    imports.wbg.__wbg_setScissorRect_3d49675315e5e211 = function(arg0, arg1, arg2, arg3, arg4) {
        arg0.setScissorRect(arg1 >>> 0, arg2 >>> 0, arg3 >>> 0, arg4 >>> 0);
    };
    imports.wbg.__wbg_setStencilReference_e804dad82d81ed90 = function(arg0, arg1) {
        arg0.setStencilReference(arg1 >>> 0);
    };
    imports.wbg.__wbg_setVertexBuffer_1bbfef15594ff6fb = function(arg0, arg1, arg2, arg3) {
        arg0.setVertexBuffer(arg1 >>> 0, arg2, arg3);
    };
    imports.wbg.__wbg_setVertexBuffer_842c9332d2f6c4c8 = function(arg0, arg1, arg2, arg3, arg4) {
        arg0.setVertexBuffer(arg1 >>> 0, arg2, arg3, arg4);
    };
    imports.wbg.__wbg_setVertexBuffer_868733126ee16523 = function(arg0, arg1, arg2, arg3, arg4) {
        arg0.setVertexBuffer(arg1 >>> 0, arg2, arg3, arg4);
    };
    imports.wbg.__wbg_setVertexBuffer_df8e60c180575a72 = function(arg0, arg1, arg2, arg3) {
        arg0.setVertexBuffer(arg1 >>> 0, arg2, arg3);
    };
    imports.wbg.__wbg_setViewport_6ef9c53815f4c00d = function(arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
        arg0.setViewport(arg1, arg2, arg3, arg4, arg5, arg6);
    };
    imports.wbg.__wbg_set_1353b2a5e96bc48c = function(arg0, arg1, arg2) {
        arg0.set(getArrayU8FromWasm0(arg1, arg2));
    };
    imports.wbg.__wbg_set_3807d5f0bfc24aa7 = function(arg0, arg1, arg2) {
        arg0[arg1] = arg2;
    };
    imports.wbg.__wbg_set_453345bcda80b89a = function() { return handleError(function (arg0, arg1, arg2) {
        const ret = Reflect.set(arg0, arg1, arg2);
        return ret;
    }, arguments) };
    imports.wbg.__wbg_set_90f6c0f7bd8c0415 = function(arg0, arg1, arg2) {
        arg0[arg1 >>> 0] = arg2;
    };
    imports.wbg.__wbg_set_a8d46c21281c7551 = function(arg0, arg1, arg2) {
        arg0.set(arg1, arg2 >>> 0);
    };
    imports.wbg.__wbg_set_b5c08c7b8e37640f = function(arg0, arg1, arg2) {
        arg0.set(arg1, arg2 >>> 0);
    };
    imports.wbg.__wbg_set_b7f1cf4fae26fe2a = function(arg0, arg1, arg2) {
        const ret = arg0.set(arg1, arg2);
        return ret;
    };
    imports.wbg.__wbg_setheight_2b7714c57b2b4597 = function(arg0, arg1) {
        arg0.height = arg1 >>> 0;
    };
    imports.wbg.__wbg_setheight_4fce583024b2d088 = function(arg0, arg1) {
        arg0.height = arg1 >>> 0;
    };
    imports.wbg.__wbg_setonuncapturederror_70a99f37edd9e34a = function(arg0, arg1) {
        arg0.onuncapturederror = arg1;
    };
    imports.wbg.__wbg_setwidth_40a6ed203b92839d = function(arg0, arg1) {
        arg0.width = arg1 >>> 0;
    };
    imports.wbg.__wbg_setwidth_503fa5eeec717db8 = function(arg0, arg1) {
        arg0.width = arg1 >>> 0;
    };
    imports.wbg.__wbg_size_5434d001afd6e519 = function(arg0) {
        const ret = arg0.size;
        return ret;
    };
    imports.wbg.__wbg_spiraltorchPreflightJsonString_75e8c64333b2b9e9 = function() { return handleError(function (arg0, arg1, arg2, arg3) {
        spiraltorchPreflightJsonString(arg0, arg1, getStringFromWasm0(arg2, arg3));
    }, arguments) };
    imports.wbg.__wbg_spiraltorchSnapshotJsonCompatible_40e511058f09b3a4 = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5) {
        const ret = spiraltorchSnapshotJsonCompatible(arg0, arg1, arg2, arg3 >>> 0, getStringFromWasm0(arg4, arg5));
        return ret;
    }, arguments) };
    imports.wbg.__wbg_static_accessor_GLOBAL_8921f820c2ce3f12 = function() {
        const ret = typeof global === 'undefined' ? null : global;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_static_accessor_GLOBAL_THIS_f0a4409105898184 = function() {
        const ret = typeof globalThis === 'undefined' ? null : globalThis;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_static_accessor_SELF_995b214ae681ff99 = function() {
        const ret = typeof self === 'undefined' ? null : self;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_static_accessor_WINDOW_cde3890479c675ea = function() {
        const ret = typeof window === 'undefined' ? null : window;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    };
    imports.wbg.__wbg_submit_2be1c4af0a5b62a2 = function(arg0, arg1) {
        arg0.submit(arg1);
    };
    imports.wbg.__wbg_then_b33a773d723afa3e = function(arg0, arg1, arg2) {
        const ret = arg0.then(arg1, arg2);
        return ret;
    };
    imports.wbg.__wbg_then_e22500defe16819f = function(arg0, arg1) {
        const ret = arg0.then(arg1);
        return ret;
    };
    imports.wbg.__wbg_toStringTag_10b5cf84da7db06a = function() {
        const ret = Symbol.toStringTag;
        return ret;
    };
    imports.wbg.__wbg_trainingstate_new = function(arg0) {
        const ret = TrainingState.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_unmap_c1162e2b1ee3b140 = function(arg0) {
        arg0.unmap();
    };
    imports.wbg.__wbg_usage_abeadd7ac4e9fac8 = function(arg0) {
        const ret = arg0.usage;
        return ret;
    };
    imports.wbg.__wbg_valueOf_7aa1f7f32182102e = function(arg0) {
        const ret = arg0.valueOf();
        return ret;
    };
    imports.wbg.__wbg_value_dd9372230531eade = function(arg0) {
        const ret = arg0.value;
        return ret;
    };
    imports.wbg.__wbg_wbindgenbigintgetasi64_ac743ece6ab9bba1 = function(arg0, arg1) {
        const v = arg1;
        const ret = typeof(v) === 'bigint' ? v : undefined;
        getDataViewMemory0().setBigInt64(arg0 + 8 * 1, isLikeNone(ret) ? BigInt(0) : ret, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
    };
    imports.wbg.__wbg_wbindgenbooleanget_3fe6f642c7d97746 = function(arg0) {
        const v = arg0;
        const ret = typeof(v) === 'boolean' ? v : undefined;
        return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
    };
    imports.wbg.__wbg_wbindgencbdrop_eb10308566512b88 = function(arg0) {
        const obj = arg0.original;
        if (obj.cnt-- == 1) {
            obj.a = 0;
            return true;
        }
        const ret = false;
        return ret;
    };
    imports.wbg.__wbg_wbindgendebugstring_99ef257a3ddda34d = function(arg0, arg1) {
        const ret = debugString(arg1);
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_wbindgenin_d7a1ee10933d2d55 = function(arg0, arg1) {
        const ret = arg0 in arg1;
        return ret;
    };
    imports.wbg.__wbg_wbindgenisbigint_ecb90cc08a5a9154 = function(arg0) {
        const ret = typeof(arg0) === 'bigint';
        return ret;
    };
    imports.wbg.__wbg_wbindgenisfunction_8cee7dce3725ae74 = function(arg0) {
        const ret = typeof(arg0) === 'function';
        return ret;
    };
    imports.wbg.__wbg_wbindgenisnull_f3037694abe4d97a = function(arg0) {
        const ret = arg0 === null;
        return ret;
    };
    imports.wbg.__wbg_wbindgenisobject_307a53c6bd97fbf8 = function(arg0) {
        const val = arg0;
        const ret = typeof(val) === 'object' && val !== null;
        return ret;
    };
    imports.wbg.__wbg_wbindgenisstring_d4fa939789f003b0 = function(arg0) {
        const ret = typeof(arg0) === 'string';
        return ret;
    };
    imports.wbg.__wbg_wbindgenisundefined_c4b71d073b92f3c5 = function(arg0) {
        const ret = arg0 === undefined;
        return ret;
    };
    imports.wbg.__wbg_wbindgenjsvaleq_e6f2ad59ccae1b58 = function(arg0, arg1) {
        const ret = arg0 === arg1;
        return ret;
    };
    imports.wbg.__wbg_wbindgenjsvallooseeq_9bec8c9be826bed1 = function(arg0, arg1) {
        const ret = arg0 == arg1;
        return ret;
    };
    imports.wbg.__wbg_wbindgennumberget_f74b4c7525ac05cb = function(arg0, arg1) {
        const obj = arg1;
        const ret = typeof(obj) === 'number' ? obj : undefined;
        getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
    };
    imports.wbg.__wbg_wbindgenstringget_0f16a6ddddef376f = function(arg0, arg1) {
        const obj = arg1;
        const ret = typeof(obj) === 'string' ? obj : undefined;
        var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    };
    imports.wbg.__wbg_wbindgenthrow_451ec1a8469d7eb6 = function(arg0, arg1) {
        throw new Error(getStringFromWasm0(arg0, arg1));
    };
    imports.wbg.__wbg_wgpumatmul_new = function(arg0) {
        const ret = WgpuMatmul.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_wgpurank_new = function(arg0) {
        const ret = WgpuRank.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_wgputensordevice_new = function(arg0) {
        const ret = WgpuTensorDevice.__wrap(arg0);
        return ret;
    };
    imports.wbg.__wbg_width_c7a070ac56976582 = function(arg0) {
        const ret = arg0.width;
        return ret;
    };
    imports.wbg.__wbg_writeBuffer_2ff9c76b83fa9c59 = function(arg0, arg1, arg2, arg3, arg4, arg5) {
        arg0.writeBuffer(arg1, arg2, arg3, arg4, arg5);
    };
    imports.wbg.__wbg_writeTexture_beb37a6e023d84a3 = function(arg0, arg1, arg2, arg3, arg4) {
        arg0.writeTexture(arg1, arg2, arg3, arg4);
    };
    imports.wbg.__wbindgen_cast_2241b6af4c4b2941 = function(arg0, arg1) {
        // Cast intrinsic for `Ref(String) -> Externref`.
        const ret = getStringFromWasm0(arg0, arg1);
        return ret;
    };
    imports.wbg.__wbindgen_cast_2f16cb9accdd0cc8 = function(arg0, arg1) {
        // Cast intrinsic for `Closure(Closure { dtor_idx: 1314, function: Function { arguments: [NamedExternref("GPUUncapturedErrorEvent")], shim_idx: 1315, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
        const ret = makeMutClosure(arg0, arg1, 1314, __wbg_adapter_11);
        return ret;
    };
    imports.wbg.__wbindgen_cast_4625c577ab2ec9ee = function(arg0) {
        // Cast intrinsic for `U64 -> Externref`.
        const ret = BigInt.asUintN(64, arg0);
        return ret;
    };
    imports.wbg.__wbindgen_cast_636d7cb33c79e99f = function(arg0, arg1) {
        // Cast intrinsic for `Closure(Closure { dtor_idx: 1319, function: Function { arguments: [Externref], shim_idx: 1320, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
        const ret = makeMutClosure(arg0, arg1, 1319, __wbg_adapter_8);
        return ret;
    };
    imports.wbg.__wbindgen_cast_9ae0607507abb057 = function(arg0) {
        // Cast intrinsic for `I64 -> Externref`.
        const ret = arg0;
        return ret;
    };
    imports.wbg.__wbindgen_cast_cb9088102bce6b30 = function(arg0, arg1) {
        // Cast intrinsic for `Ref(Slice(U8)) -> NamedExternref("Uint8Array")`.
        const ret = getArrayU8FromWasm0(arg0, arg1);
        return ret;
    };
    imports.wbg.__wbindgen_cast_d6cd19b81560fd6e = function(arg0) {
        // Cast intrinsic for `F64 -> Externref`.
        const ret = arg0;
        return ret;
    };
    imports.wbg.__wbindgen_init_externref_table = function() {
        const table = wasm.__wbindgen_export_4;
        const offset = table.grow(4);
        table.set(0, undefined);
        table.set(offset + 0, undefined);
        table.set(offset + 1, null);
        table.set(offset + 2, true);
        table.set(offset + 3, false);
        ;
    };

    return imports;
}

function __wbg_init_memory(imports, memory) {

}

function __wbg_finalize_init(instance, module) {
    wasm = instance.exports;
    __wbg_init.__wbindgen_wasm_module = module;
    cachedDataViewMemory0 = null;
    cachedFloat32ArrayMemory0 = null;
    cachedInt32ArrayMemory0 = null;
    cachedUint32ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    cachedUint8ClampedArrayMemory0 = null;


    wasm.__wbindgen_start();
    return wasm;
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (typeof module !== 'undefined') {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();

    __wbg_init_memory(imports);

    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }

    const instance = new WebAssembly.Instance(module, imports);

    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (typeof module_or_path !== 'undefined') {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (typeof module_or_path === 'undefined') {
        module_or_path = new URL('spiraltorch_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    __wbg_init_memory(imports);

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync };
export default __wbg_init;
