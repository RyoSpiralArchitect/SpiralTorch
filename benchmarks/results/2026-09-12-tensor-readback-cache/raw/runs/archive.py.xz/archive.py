"""Archive both rejected staging experiments and the selected-source checks."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import shutil
import statistics
import subprocess
import sys

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
BASE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-inline-guard-20260912/verified-a')
OUT = ROOT/'benchmarks/results/2026-09-12-tensor-readback-cache'
LOADER = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py')
CPU_PROBE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-parameter-handoff-20260912/cpu_probe.py')
sys.path.insert(0, str(ROOT/'tools'))
from validate_module_resident_intervals import admit_case_stream, admit_native, validate


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def checked_receipt(path, steps=None):
    receipt = read(path)
    assert receipt['status'] == 'passed' and 'active' not in receipt, str(path)
    assert all(step['exit_code'] == 0 for step in receipt['steps']), str(path)
    if steps is not None:
        assert len(receipt['steps']) == steps, str(path)
    assert git('rev-parse', receipt['source']['commit']+'^{tree}').decode().strip() == receipt['source']['tree']
    return receipt


assert not OUT.exists(), 'archive exists; inspect rather than overwrite'
base = checked_receipt(BASE/'receipt.json')
one = checked_receipt(LOG/'verified-a/receipt.json', 55)
measurement = checked_receipt(LOG/'measurement/receipt.json', 14)
two = checked_receipt(LOG/'two-slot/screen-receipt.json', 10)
two_functional = checked_receipt(LOG/'two-slot/receipt.json', 8)
selected = checked_receipt(LOG/'selected/receipt.json', 13)
assert git('rev-parse', 'HEAD').decode().strip() == selected['source']['commit']
assert not git('status', '--porcelain').strip()
assert selected['library_source_identical_to'] == base['source']
assert measurement['source'] == one['source']
assert two_functional['source'] == two['source']
assert sha((LOG/'two-slot/receipt.json').read_bytes()) == two['functional_receipt_sha256']
assert sha((LOG/'verified-a/receipt.json').read_bytes()) == measurement['initial_receipt_sha256']
for report in (one, two, measurement):
    assert sha((BASE/'receipt.json').read_bytes()) == report['baseline_receipt_sha256']
assert sha((BASE/'receipt.json').read_bytes()) == selected['inherited_product_receipt_sha256']
for report, name in ((one, 'run.py'), (measurement, 'measure.py'),
                     (two, 'screen_two.py'), (selected, 'verify_selected.py')):
    assert sha((LOG/name).read_bytes()) == report['harness_sha256']
assert sha(LOADER.read_bytes()) == one['loader_sha256']
for name, digest in selected['runtime_sha256'].items():
    expected = git('show', base['source']['commit']+':'+name)
    assert sha(expected) == digest and (ROOT/name).read_bytes() == expected
changes = git('diff', '--name-only', base['source']['commit'], selected['source']['commit']).decode().splitlines()
assert changes == selected['changed_nonproduction_paths']
for name in changes:
    assert (name.startswith(('benchmarks/', 'docs/', 'tools/', 'bindings/st-py/tests/', 'bindings/st-wasm/tests/'))
            or name in ('crates/st-backend-wgpu/src/resident_tensor/tests.rs',
                        'crates/st-nn/examples/support/resident_nd_tensor.rs',
                        'crates/st-nn/examples/support/resident_tensor_snapshots.rs')), name

# Preserve the one selected executable that was originally verified in target/.
relocations = []
for name, digest in selected['products'].items():
    path = Path(name)
    assert sha(path.read_bytes()) == digest, name
    if not path.is_relative_to(LOG/'selected'):
        target = LOG/'selected/frozen-products'/path.name
        target.parent.mkdir(exist_ok=True)
        if not target.exists():
            shutil.copyfile(path, target)
            target.chmod(0o555)
        assert sha(target.read_bytes()) == digest
        relocations.append(dict(original=name, frozen=str(target), sha256=digest))
write(LOG/'selected/frozen-products.json', dict(status='passed',
    source=selected['source'], source_receipt_sha256=sha((LOG/'selected/receipt.json').read_bytes()),
    boundary='Byte-identical durable copy after terminal verification; the original receipt is not rewritten.',
    relocations=relocations))

products = []
for label, folder, receipt in [('baseline', BASE, base), ('one_slot', LOG/'verified-a', one),
                              ('two_slots', LOG/'two-slot', two), ('selected', LOG/'selected', selected)]:
    for name, digest in receipt['products'].items():
        path = folder/name
        for relocation in relocations if label == 'selected' else []:
            if name == relocation['original']:
                path = Path(relocation['frozen'])
        assert sha(path.read_bytes()) == digest, str(path)
        products.append(dict(version=label, path=str(path), sha256=digest))
assert len(products) == 54

fixtures = [read(BASE/'native-forward-bench.json'), read(LOG/'verified-a/native-forward-bench.json')]
for fixture in fixtures:
    admit_native(fixture)
for old, new in zip(fixtures[0]['cases'], fixtures[1]['cases'], strict=True):
    keys = set(old) - {'samples', 'compile_two_graphs_ms'}
    assert keys == set(new) - {'samples', 'compile_two_graphs_ms'}
    assert {key:old[key] for key in keys} == {key:new[key] for key in keys}

intervals = {}
for label, folder, fixture, source in [('one_slot', LOG/'measurement', fixtures[1], one['source']),
                                      ('two_slots', LOG/'two-slot', fixtures[0], two['source'])]:
    report = read(folder/'interval-validation.json')
    browser = read(folder/'interval-browser.json')
    assert report['status'] == 'passed' and report['baseline_source'] == base['source']
    assert report['candidate_source'] == source
    for name, digest in report['sources'].items():
        assert sha(Path(name).read_bytes()) == digest, name
    admit_case_stream(browser, folder/'interval-browser.json')
    recalculated = validate(browser, fixture)
    assert all(report[key] == value for key, value in recalculated.items())
    intervals[label] = dict(source=source, protocol=report['protocol'],
        **{key:value for key, value in recalculated.items() if key != 'cases'},
        browser_version=browser['browser_version'], cross_origin_isolated=browser['cross_origin_isolated'],
        adapters=browser['cases'][0]['adapters'], validation_sha256=sha((folder/'interval-validation.json').read_bytes()),
        disposition='rejected; retain original fresh Tensor staging')

short_paths = [LOG/'verified-a/direct-io-validation.json'] + [LOG/f'measurement/{n}-validation.json' for n in range(1, 4)]
short_reports = [read(path) for path in short_paths]
assert all(report['status'] == 'passed' for report in short_reports)
short = {}
for client in ('python', 'browser'):
    rows = [dict(matrix=matrix, **row) for matrix, report in enumerate(short_reports) for row in report[client]]
    assert len(rows) == 36
    aggregates = []
    for shape in dict.fromkeys(tuple(row['shape']) for row in rows):
        subset = [row for row in rows if tuple(row['shape']) == shape]
        routes = {}
        for route in subset[0]['candidate_over_baseline']:
            ratios = [row['candidate_over_baseline'][route] for row in subset]
            routes[route] = dict(median_of_case_median_ratios=statistics.median(ratios),
                min_ratio=min(ratios), max_ratio=max(ratios), regressions=sum(v > 1 for v in ratios),
                total_cases=len(ratios))
        aggregates.append(dict(shape=list(shape), routes=routes))
    short[client] = aggregates

torch = read(LOG/'verified-a/torch-correctness.json')
assert torch['status'] == 'passed'
checks = {}
for label, folder, module, nd in [('one_slot', LOG/'verified-a', 'browser-module-forward.json', 'browser-nd.json'),
                                ('two_slots', LOG/'two-slot', 'module-browser.json', 'nd-browser.json'),
                                ('selected', LOG/'selected', 'module-browser.json', 'nd-browser.json')]:
    page, nd_page = read(folder/module), read(folder/nd)
    assert page['status'] == nd_page['status'] == 'passed'
    assert page['assertions'] == 210 and page['tensor_readback_ownership']
    assert page['page_errors'] == nd_page['page_errors'] == []
    assert nd_page['tensor_snapshots']['cancelled_pending_maps'] == 4
    checks[label] = dict(module_assertions=page['assertions'], tensor_snapshots=nd_page['tensor_snapshots'])
test_counts = {}
for label, folder in [('one_slot', LOG/'verified-a'), ('two_slots', LOG/'two-slot'), ('selected', LOG/'selected')]:
    counts = {}
    for path in folder.glob('*.log'):
        text = path.read_text()
        rust = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
        python = re.findall(r'^Ran (\d+) tests? in', text, re.MULTILINE)
        if rust or python:
            assert all(int(failed) == 0 for _, failed, _ in rust)
            counts[path.name] = dict(rust_passed=sum(int(p) for p, _, _ in rust),
                rust_ignored=sum(int(i) for _, _, i in rust), python_ran=sum(map(int, python)))
    test_counts[label] = counts

files = {'runs/'+str(path.relative_to(LOG)): path for path in LOG.rglob('*')
         if path.is_file() and '__pycache__' not in path.parts
         and path.suffix in ('.json', '.jsonl', '.log', '.py', '.js', '.mjs', '.ts', '.html')}
files.update({'inputs/baseline-receipt.json': BASE/'receipt.json',
              'inputs/baseline-native-fixture.json': BASE/'native-forward-bench.json',
              'inputs/python-client.py': LOADER, 'inputs/cpu_probe.py': CPU_PROBE})
payloads = {name:(path.read_bytes(), {'path':str(path)}) for name, path in files.items()}
variants = dict(baseline=base['source'], one_slot=one['source'], two_slots=two['source'], selected=selected['source'])
for label, source in variants.items():
    for name in ['crates/st-backend-wgpu/src/runtime.rs', 'crates/st-backend-wgpu/src/resident_tensor.rs',
                 'crates/st-backend-wgpu/src/resident_tensor/tests.rs']:
        payloads[f'source/{label}/{name}'] = (git('show', source['commit']+':'+name),
                                            dict(git_commit=source['commit'], git_path=name))
shared = [
    'bindings/st-wasm/tests/module_resident_intervals.html', 'bindings/st-wasm/tests/module_resident_intervals.mjs',
    'bindings/st-wasm/tests/module_resident_matched.html', 'bindings/st-wasm/tests/module_resident_forward.html',
    'bindings/st-wasm/tests/resident_nd_tensor.html', 'bindings/st-py/tests/test_wgpu_tensor.py',
    'bindings/st-py/tests/test_nn_module_resident_forward.py', 'bindings/st-wasm/tests/resident_types.cjs',
    'crates/st-nn/examples/support/resident_nd_tensor.rs', 'crates/st-nn/examples/support/resident_tensor_snapshots.rs',
    'tools/test_resident_browser.cjs', 'tools/validate_module_resident_intervals.py',
    'tools/test_module_interval_validation.py', 'tools/test_module_resident_intervals.mjs',
    'tools/bench_graph_forward_paths.py', 'tools/bench_resident_nn_vs_torch.py',
    'tools/validate_module_direct_io.py', 'tools/validate_module_forward_paths.py',
    'tools/test_module_direct_io.py', 'tools/test_module_forward_reference.py',
    'tools/validate_resident_graph_training_vs_torch.py', 'tools/resident_module_handoff_fixture.py',
    'tests/test_graph_forward_paths.py',
]
for name in shared:
    data = git('show', selected['source']['commit']+':'+name)
    for version in (one, two):
        assert data == git('show', version['source']['commit']+':'+name), name
    payloads['source/shared/'+name] = (data, dict(git_commit=selected['source']['commit'], git_path=name,
        identical_at=[one['source']['commit'], two['source']['commit']]))

(OUT/'raw').mkdir(parents=True)
entries = []
for name, (data, origin) in sorted(payloads.items()):
    compressed = lzma.compress(data)
    path = OUT/'raw'/(name+'.xz')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(compressed)
    assert lzma.decompress(path.read_bytes()) == data
    entries.append(dict(archive=str(path.relative_to(OUT)), origin=origin, bytes=len(data), sha256=sha(data),
                        compressed_bytes=len(compressed), compressed_sha256=sha(compressed)))
manifest = dict(schema='spiraltorch.source_archive.v1', status='passed', records=entries,
    raw_bytes=sum(row['bytes'] for row in entries), compressed_bytes=sum(row['compressed_bytes'] for row in entries))
write(OUT/'manifest.json', manifest)
summary = dict(schema='spiraltorch.tensor_readback_cache_record.v1', status='passed',
    decision='Reject both staging caches; restore original production library source and keep stronger ownership/cancellation tests.',
    sources=variants, selected_library_source=base['source'], production_cache_enabled=False,
    verification={label:dict(source=report['source'], steps=len(report['steps']), seconds=report['seconds'])
                  for label, report in [('one_slot_full', one), ('one_slot_measurement', measurement),
                                        ('two_slot_screen', two), ('selected', selected)]},
    qualification_boundaries=dict(two_slots=two_functional['qualification'], selected=selected['boundary']),
    runtime_sha256=selected['runtime_sha256'], test_counts=test_counts, browser_checks=checks,
    torch_correctness=dict(version=torch['torch'], cases=len(torch['cases']),
        comparisons=sum(row['comparisons'] for row in torch['cases']),
        max_abs_error=max(row['max_abs_error'] for row in torch['cases']),
        devices=sorted({row['device'] for row in torch['cases']}), scope=torch['scope']),
    sustained_browser=intervals, short_one_slot_aggregates=short,
    short_protocol_boundary='Four fixed paired matrices; isolated completed-read and eight-forward/final-read-only burst are separate endpoints, not the sustained interval protocol. No samples filtered or retries. Small native results are noisy; no universal speedup.',
    experimental_interval_reads=sum(item['checked_forwards_including_warmup'] for item in intervals.values()),
    experimental_interval_values=sum(item['checked_values_including_warmup'] for item in intervals.values()),
    baseline_and_one_slot_fixture_semantics_equal=True, frozen_products_checked=len(products), products=products,
    raw_records=len(entries), manifest_sha256=sha((OUT/'manifest.json').read_bytes()),
    boundary='Native Apple M4/Metal, no MPS CPU fallback. Browser physical GPU and host exclusivity UNKNOWN. One-slot and two-slot are separate comparisons against the same original runtime, not a simultaneous three-way trial. No selected-source new timing, CUDA/Furnace, package release or push.',
    next_candidate='Combine terminal forward and snapshot copy in one submission through an explicit API; not implemented or measured here. Cache regressions do not establish the causal bottleneck.')
write(OUT/'summary.json', summary)
print(json.dumps(dict(status='passed', records=len(entries), raw_bytes=manifest['raw_bytes'],
    compressed_bytes=manifest['compressed_bytes'], products_checked=len(products),
    selected_steps=len(selected['steps']), experiment_reads=summary['experimental_interval_reads'])))
