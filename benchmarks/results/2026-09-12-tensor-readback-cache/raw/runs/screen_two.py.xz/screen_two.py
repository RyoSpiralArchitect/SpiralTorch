"""Fixed WASM-first screen of alternating staging against the original runtime."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
TARGET = ROOT.parent/'spiraltorch-spiralk-golden-blackcat-contract-v1/target'
LOG = Path(__file__).parent
OUT = LOG/'two-slot'
BASE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-inline-guard-20260912/verified-a')
P = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
BINDGEN = '/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen'
if sys.argv[1:] == ['--launch']:
    if OUT.exists(): raise ValueError('screen already exists; inspect rather than retry')
    with (LOG/'two-slot.log').open('xb') as log:
        child = subprocess.Popen([P, '-S', str(Path(__file__).resolve())], cwd=ROOT, stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps(dict(pid=child.pid, log=str(LOG/'two-slot.log')))); raise SystemExit(0)
if sys.argv[1:]: raise ValueError('--launch or no arguments')
OUT.mkdir()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_bytes())
assert not git('status', '--porcelain')
base = read(BASE/'receipt.json'); assert base['status'] == 'passed'
for name, digest in base['products'].items(): assert sha(BASE/name) == digest
env = dict(os.environ, CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='4', SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
report = dict(status='running', pid=os.getpid(), source=dict(commit=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}')),
    steps=[], products={}, harness_sha256=sha(Path(__file__)), baseline_source=base['source'],
    baseline_receipt_sha256=sha(BASE/'receipt.json'),
    boundary='Two alternating exact-sized idle buffers, 16 MiB each, against the original unpooled tensor snapshots. Same 4-matrix completed-read browser protocol; no adaptive counts or discarded runs. This is a backend/WASM functional screen, not full Python/native matched qualification.')

def save():
    temp = OUT/'screen-receipt.json.tmp'; temp.write_text(json.dumps(report, indent=2)+'\n'); temp.replace(OUT/'screen-receipt.json')

def run(name, args):
    args = [str(value) for value in args]; print('START', name, flush=True); start = time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        child = subprocess.Popen(args, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        report['active'] = dict(name=name, pid=child.pid, command=args); save()
        try: code = child.wait(timeout=2100)
        except subprocess.TimeoutExpired:
            child.kill(); child.wait(); raise
    report.pop('active'); report['steps'].append(dict(name=name, exit_code=code, seconds=time.monotonic()-start, command=args)); save()
    print('END', name, code, flush=True)
    if code: raise RuntimeError(name)

def bindgen(source, folder):
    run(folder+'-bindgen', [BINDGEN, source, '--target', 'web', '--out-dir', OUT/folder, '--out-name', 'spiraltorch_wasm'])
    for path in (OUT/folder).rglob('*'):
        if path.is_file(): report['products'][str(path.relative_to(OUT))] = sha(path)
    save()

C = ['cargo', '+1.98.0']
start = time.monotonic()
try:
    save()
    run('format', ['cargo', '+nightly-2026-04-15', 'fmt', '--all', '--', '--check'])
    run('backend', C+['test', '--locked', '--release', '-p', 'st-backend-wgpu', '--lib', '--', '--test-threads=1'])
    run('client-build', C+['build', '--locked', '--release', '-p', 'spiraltorch-wasm', '--features', 'webgpu', '--target', 'wasm32-unknown-unknown'])
    bindgen(TARGET/'wasm32-unknown-unknown/release/spiraltorch_wasm.wasm', 'client')
    dest = OUT/'client/forward-bench-fixture.json'; shutil.copyfile(BASE/'native-forward-bench.json', dest)
    report['products'][str(dest.relative_to(OUT))] = sha(dest); save()
    run('module-browser', ['node', 'tools/test_resident_browser.cjs', OUT/'client', CHROME, OUT/'module-browser.json', '', '', '', '', 'nn-module-forward'])
    run('nd-build', C+['build', '--locked', '--release', '-p', 'st-nn', '--no-default-features', '--features', 'wgpu', '--target', 'wasm32-unknown-unknown', '--example', 'resident_nd_tensor_browser'])
    bindgen(TARGET/'wasm32-unknown-unknown/release/examples/resident_nd_tensor_browser.wasm', 'nd')
    run('nd-browser', ['node', 'tools/test_resident_browser.cjs', OUT/'nd', CHROME, OUT/'nd-browser.json', '', '', '', '', 'nd-tensor'])
    assert read(OUT/'module-browser.json')['tensor_readback_ownership'] is True
    assert read(OUT/'nd-browser.json')['tensor_snapshots']['cancelled_pending_maps'] == 4
    for name, digest in report['products'].items(): assert sha(OUT/name) == digest
    # Seal a separate, immutable functional receipt before timing validation.
    functional = dict(report, status='passed', qualification='backend/WASM screen only; full native/Python suite not run for this candidate')
    (OUT/'receipt.json').write_text(json.dumps(functional, indent=2)+'\n')
    report['functional_receipt_sha256'] = sha(OUT/'receipt.json'); save()
    run('interval-browser', ['node', 'tools/test_resident_browser.cjs', OUT/'client', CHROME,
        OUT/'interval-browser.json', '', '', '', '', 'nn-module-intervals', BASE/'client'])
    run('interval-validation', [P, '-I', 'tools/validate_module_resident_intervals.py', '--fixture', BASE/'native-forward-bench.json',
        '--browser', OUT/'interval-browser.json', '--baseline-receipt', BASE/'receipt.json', '--candidate-receipt', OUT/'receipt.json',
        '--output', OUT/'interval-validation.json'])
    assert read(OUT/'interval-validation.json')['status'] == 'passed'
    for name, digest in report['products'].items(): assert sha(OUT/name) == digest
    for name, digest in base['products'].items(): assert sha(BASE/name) == digest
    assert sha(OUT/'receipt.json') == report['functional_receipt_sha256']
    assert git('rev-parse', 'HEAD') == report['source']['commit'] and not git('status', '--porcelain')
    report['status'] = 'passed'
except BaseException as error:
    report.update(status='error', error=repr(error)); raise
finally:
    report['seconds'] = time.monotonic()-start; save()
