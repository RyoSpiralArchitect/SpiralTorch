#!/usr/bin/env python3
"""Offline validation and summaries; never executes a GPU or admits timing runs."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys


def identity(path):
    data = path.read_bytes()
    return dict(file=path.name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def analyze(repo, directory):
    sys.path.insert(0, str(repo / "tools"))
    import bench_resident_nn_vs_torch as bench
    import bench_rank_vs_torch as audit
    paths = [directory / ("mps-comparison-37e726f6" + suffix + ".json")
             for suffix in ("", "-r2", "-r3")]
    rows, identities = [], []
    source = None
    executable = None
    for run, path in enumerate(paths, 1):
        report = json.loads(path.read_text())
        assert report["status"] == "passed" and report["torch_device"] == "mps"
        assert report["torch"] == "2.12.1"
        assert report["device_admission"]["name"] == "Apple M4"
        assert report["device_admission"]["contention"].startswith("unknown:")
        binding = audit.validate_source_binding(report["native_build_identity"], report["source"])
        assert binding["valid"] and binding == report["build_source_binding"]
        if source is None:
            source = report["source"]
            executable = report["executable"]
        assert source == report["source"] and executable == report["executable"]
        matrix = list(bench.requests())
        assert len(report["cases"]) == len(matrix) == 9
        payload = "".join(json.dumps(r, separators=(",", ":")) + "\n" for r in matrix)
        assert hashlib.sha256(payload.encode()).hexdigest() == report["request_sha256"]
        for case, request in zip(report["cases"], matrix):
            bench.validate_native(case, request)
            bench.match_adapter(case["adapter"], "mps", "Apple M4")
            samples = case["torch_samples_ms"]
            assert len(samples) == 12 and all(math.isfinite(x) and x > 0 for x in samples)
            assert math.isclose(statistics.mean(samples), case["torch_mean_ms"], rel_tol=1e-12)
            assert math.isclose(case["resident_mean_ms"] / case["torch_mean_ms"],
                                case["resident_over_torch"], rel_tol=1e-12)
            assert math.isclose(case["resident_mean_ms"] / case["legacy_mean_ms"],
                                case["resident_over_legacy"], rel_tol=1e-12)
            assert math.isfinite(case["max_abs_error"]) and 0 <= case["max_abs_error"] < 1e-5
            rows.append(dict(run=run, **{key: value for key, value in case.items()
                if key not in ("input", "parameters", "reference", "boundary")}))
        identities.append(identity(path))
    groups = []
    for shape, depth in (([2, 3, 7], 2), ([2, 8, 64], 16), ([4, 8, 128], 16)):
        cases = [row for row in rows if row["shape"] == shape and row["depth"] == depth]
        assert len(cases) == 9
        speedup = [1 / row["resident_over_legacy"] for row in cases]
        torch_ratio = [row["resident_over_torch"] for row in cases]
        groups.append(dict(shape=shape, depth=depth, cases=len(cases),
            legacy_speedup_median=statistics.median(speedup),
            legacy_speedup_range=[min(speedup), max(speedup)],
            resident_over_torch_median=statistics.median(torch_ratio),
            resident_over_torch_range=[min(torch_ratio), max(torch_ratio)],
            faster_than_legacy=sum(r["resident_over_legacy"] < 1 for r in cases),
            faster_than_torch=sum(r["resident_over_torch"] < 1 for r in cases),
            max_abs_error=max(r["max_abs_error"] for r in cases)))
    browser_path = directory / "browser-37e726f6.json"
    browser = json.loads(browser_path.read_text())
    assert browser["status"] == "passed" and browser["page_errors"] == []
    assert browser["adapter"]["backend"] == "BrowserWebGpu"
    assert browser["build_manifest"]["git"]["commit"] == source["commit"]
    assert browser["build_manifest"]["git"]["tree"] == source["tree"]
    assert browser["build_manifest"]["git"]["dirty"] is False
    assert len(browser["cases"]) == 6 and browser["intermediate_guard_cases"] == 4
    assert [(c["seed"], c["gpu_stages"]) for c in browser["cases"]] == [
        (seed, depth) for seed in (17, 29, 43) for depth in (2, 16)]
    for case in browser["cases"]:
        assert case["shape"] == [2, 3, 7]
        assert case["source_operations"] == case["gpu_stages"] * 2
        assert math.isfinite(case["max_abs_error"]) and 0 <= case["max_abs_error"] < 1e-5
    identities.append(identity(browser_path))
    raw_paths = set(directory.glob("*.log")) | set(directory.glob("*.jsonl"))
    raw_paths.update(paths + [browser_path, directory / "product-sha256.txt", directory / "analyze_nn.py"])
    raw_files = [identity(path) for path in sorted(raw_paths, key=lambda path: path.name)]
    return dict(schema="spiraltorch.resident_nn_study.v1", status="passed",
        source=source, executable=executable, torch="2.12.1", torch_device="mps",
        retained_samples_per_implementation=324, full_matrix_runs=3,
        estimator="median of nine per-case sample-mean ratios: three seeds times three runs",
        measurement_boundary=report["boundary"], semantics=report["semantics"],
        contention=report["device_admission"]["contention"],
        groups=groups, cases=rows, browser=browser, raw_reports=identities, raw_files=raw_files)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--directory", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    summary = analyze(args.repo.resolve(), args.directory.resolve())
    import bench_rank_vs_torch as audit
    audit.write_report_exclusive(args.output, summary)
    print(json.dumps(dict(status=summary["status"], cases=len(summary["cases"]))))


if __name__ == "__main__":
    main()
