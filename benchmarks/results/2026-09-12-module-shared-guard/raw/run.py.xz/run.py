"""Finite source-bound verification; owned GPU work is serial, no retries."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
TARGET = ROOT.parent / 'spiraltorch-spiralk-golden-blackcat-contract-v1/target'
LOG = Path(__file__).parent
BASELINE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-output-reuse-20260912/verified-a')
P = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH = '/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
BINDGEN = '/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen'
LOADER = '/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py'
if len(sys.argv) == 3 and sys.argv[1] == '--launch':
    name = sys.argv[2]
    if Path(name).name != name or (LOG/name).exists():
        raise ValueError('fresh output name required; inspect old run before retrying')
    with (LOG/(name+'.log')).open('xb') as output:
        child = subprocess.Popen([P, '-S', str(Path(__file__).resolve()), name],
            cwd=ROOT, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT,
            start_new_session=True)
    print(json.dumps(dict(pid=child.pid, log=str(LOG/(name+'.log')))))
    raise SystemExit(0)
if len(sys.argv) != 2 or Path(sys.argv[1]).name != sys.argv[1]:
    raise ValueError('OUTPUT_NAME or --launch OUTPUT_NAME')
OUT = LOG/sys.argv[1]
OUT.mkdir()
env = dict(os.environ, CARGO_BUILD_JOBS='4', CARGO_TARGET_DIR=str(TARGET), PYO3_PYTHON=P,
    SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1', PYTORCH_ENABLE_MPS_FALLBACK='0',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
git = lambda *a: subprocess.check_output(['git', *a], cwd=ROOT, text=True).strip()

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''): h.update(block)
    return h.hexdigest()

source = dict(commit=git('rev-parse','HEAD'), tree=git('rev-parse','HEAD^{tree}'))
assert not git('status','--porcelain')
report = dict(status='running', pid=os.getpid(), source=source, steps=[], products={},
    harness_sha256=digest(Path(__file__)), loader_sha256=digest(Path(LOADER)),
    contention='UNKNOWN; owned GPU work serial, not host exclusivity',
    boundary='Direct indexed pointwise graph guards replace per-stage clear/copy commands; output-slot reuse and graph arithmetic remain unchanged. Serial correctness, same-page browser A/B and separate-process native matched eager timing. No generic autograd migration or globally allocation-free/fastest-Torch claim.')

def save():
    temporary = OUT/'receipt.json.tmp'
    temporary.write_text(json.dumps(report, indent=2)+'\n')
    temporary.replace(OUT/'receipt.json')

def run(name, args, output=None):
    print('START', name, flush=True)
    start = time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        if output:
            with (OUT/output).open('xb') as out:
                child = subprocess.Popen(args, cwd=ROOT, env=env, stdout=out, stderr=log)
                report['active'] = dict(name=name, pid=child.pid, command=args); save()
                try: code = child.wait(timeout=1800)
                except subprocess.TimeoutExpired:
                    child.kill(); child.wait(); raise
        else:
            child = subprocess.Popen(args, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
            report['active'] = dict(name=name, pid=child.pid, command=args); save()
            try: code = child.wait(timeout=1800)
            except subprocess.TimeoutExpired:
                child.kill(); child.wait(); raise
    report.pop('active')
    report['steps'].append(dict(name=name, command=args, exit_code=code, seconds=time.monotonic()-start))
    save(); print('END', name, code, flush=True)
    if code: raise RuntimeError(name)

def product(path):
    report['products'][str(path.relative_to(OUT))] = digest(path); save()

def freeze(src, name):
    dest = OUT/name
    shutil.copyfile(src, dest); dest.chmod(0o555); product(dest)

def bindgen(src, folder):
    run(folder+'-bindgen', [BINDGEN, str(src), '--target','web','--out-dir',str(OUT/folder),'--out-name','spiraltorch_wasm'])
    for path in (OUT/folder).rglob('*'):
        if path.is_file(): product(path)

def browser(name, folder, suite):
    run(name, ['node','tools/test_resident_browser.cjs',str(OUT/folder),CHROME,str(OUT/(name+'.json')),'','','','',suite])

def python(name, file, *args, cpu=False):
    run(name, [P,'-I',LOADER,str(OUT/('python-cpu.dylib' if cpu else 'python-release.dylib')),str(ROOT),file,*args])

C = ['cargo','+1.98.0']
TEST = C+['test','--locked','--release']
BUILD = C+['build','--locked','--release']
NN = ['-p','st-nn','--no-default-features','--features','wgpu']
SERIAL = ['--','--test-threads=1']
try:
    baseline_receipt=json.loads((BASELINE/'receipt.json').read_bytes())
    assert baseline_receipt['status']=='passed'
    for name,sha in baseline_receipt['products'].items(): assert digest(BASELINE/name)==sha,name
    report['baseline_source']=baseline_receipt['source']
    report['baseline_receipt_sha256']=digest(BASELINE/'receipt.json')
    save()
    run('admission-tests',[P,'-I','tools/test_module_direct_io.py','-v'])
    run('format',['cargo','+nightly-2026-04-15','fmt','--all','--','--check'])
    run('contracts',TEST+['-p','st-kernel-contracts','--lib'])
    run('tensor-cpu',TEST+['-p','st-tensor','--no-default-features','--lib']+SERIAL)
    run('tensor-wgpu',TEST+['-p','st-tensor','--no-default-features','--features','wgpu','--lib']+SERIAL)
    run('nn-cpu-handoff',TEST+['-p','st-nn','--no-default-features','--lib','resident::module_update::tests']+SERIAL)
    run('nn-serial',TEST+NN+['--lib']+SERIAL)
    run('backend-serial',TEST+['-p','st-backend-wgpu','--lib']+SERIAL)
    run('integration',TEST+NN+['--test','resident_graph_forward','--test','resident_graph_training','--test','resident_nd_tensor','--test','resident_training']+SERIAL)
    run('python-build',BUILD+['-p','spiraltorch-py'])
    freeze(TARGET/'release/libspiraltorch.dylib','python-release.dylib')
    python('python-tests','tests',str(OUT/'python-tests.json'))
    for name in ['graph_autograd','graph_learner','module_update']:
        python('python-'+name,'bindings/st-py/tests/test_nn_resident_'+name+'.py','-v')
    python('python-module-forward','bindings/st-py/tests/test_nn_module_resident_forward.py','-v')
    python('python-pointwise','bindings/st-py/tests/test_wgpu_pointwise.py','-v')
    run('wasm-client-build',BUILD+['-p','spiraltorch-wasm','--features','webgpu','--target','wasm32-unknown-unknown'])
    bindgen(TARGET/'wasm32-unknown-unknown/release/spiraltorch_wasm.wasm','client')
    python('handoff-fixture','tools/resident_module_handoff_fixture.py','export',str(OUT/'client/handoff-fixture.json'))
    product(OUT/'client/handoff-fixture.json')
    browser('browser-handoff','client','nn-module-handoff')
    browser('browser-module-forward','client','nn-module-forward')
    python('browser-to-python','tools/resident_module_handoff_fixture.py','apply',str(OUT/'browser-handoff.json'),str(OUT/'browser-to-python.json'))
    for name,suite in [('pointwise','pointwise-clients'),('learner','nn-learner-clients'),('autograd','nn-autograd-clients'),('fusion','nn-fusion-clients')]:
        browser('wasm-'+name,'client',suite)
    run('client-types',['node','bindings/st-wasm/tests/resident_types.cjs',str(OUT/'client/spiraltorch_wasm.d.ts'),str(ROOT/'bindings/st-wasm/types/spiraltorch-wasm.d.ts')])
    run('native-build',BUILD+NN+['--example','resident_graph_forward','--example','resident_graph_training','--example','resident_graph_forward_bench'])
    for name in ['resident_graph_forward','resident_graph_training','resident_graph_forward_bench']: freeze(TARGET/'release/examples'/name,name)
    run('forward-fixture',[str(OUT/'resident_graph_forward')],output='client/forward-fixture.json')
    product(OUT/'client/forward-fixture.json')
    browser('wasm-forward','client','nn-forward-clients')
    run('wasm-example-build',BUILD+NN+['--target','wasm32-unknown-unknown','--example','resident_graph_training_browser'])
    bindgen(TARGET/'wasm32-unknown-unknown/release/examples/resident_graph_training_browser.wasm','correctness')
    run('native-correctness',[str(OUT/'resident_graph_training')],output='native-correctness.json')
    browser('browser-correctness','correctness','nn-graph-training')
    run('torch-correctness',[TORCH,'-I','tools/validate_resident_graph_training_vs_torch.py',str(OUT/'native-correctness.json'),str(OUT/'browser-correctness.json'),'--devices','cpu','mps','--output',str(OUT/'torch-correctness.json')])
    run('native-forward-bench',[str(OUT/'resident_graph_forward_bench')],output='native-forward-bench.json')
    run('torch-reference-shapes',[TORCH,'-I','tools/test_module_forward_reference.py','-v'])
    run('baseline-module-bench',[TORCH,'-I','tools/bench_graph_forward_paths.py','--fixture',str(OUT/'native-forward-bench.json'),'--native-library',str(BASELINE/'python-release.dylib'),'--include-module','--output',str(OUT/'baseline-module-bench.json')])
    run('module-forward-bench',[TORCH,'-I','tools/bench_graph_forward_paths.py','--fixture',str(OUT/'native-forward-bench.json'),'--native-library',str(OUT/'python-release.dylib'),'--include-module','--output',str(OUT/'module-forward-bench.json')])
    run('module-forward-validation',[TORCH,'-I','tools/validate_module_forward_paths.py','--native',str(OUT/'native-forward-bench.json'),'--python',str(OUT/'module-forward-bench.json'),'--browser',str(OUT/'browser-module-forward.json'),'--output',str(OUT/'module-forward-validation.json')])
    freeze(OUT/'native-forward-bench.json','client/forward-bench-fixture.json')
    run('browser-module-matched',['node','tools/test_resident_browser.cjs',str(OUT/'client'),CHROME,str(OUT/'browser-module-matched.json'),'','','','','nn-module-matched',str(BASELINE/'client')])
    run('direct-io-validation',[P,'-I','tools/validate_module_direct_io.py','--fixture',str(OUT/'native-forward-bench.json'),
        '--baseline-python',str(OUT/'baseline-module-bench.json'),'--candidate-python',str(OUT/'module-forward-bench.json'),
        '--browser',str(OUT/'browser-module-matched.json'),'--baseline-receipt',str(BASELINE/'receipt.json'),
        '--candidate-library',str(OUT/'python-release.dylib'),'--candidate-wasm',str(OUT/'client/spiraltorch_wasm_bg.wasm'),
        '--output',str(OUT/'direct-io-validation.json')])
    run('python-cpu-build',BUILD+['-p','spiraltorch-py','--no-default-features','--features','python-default'])
    freeze(TARGET/'release/libspiraltorch.dylib','python-cpu.dylib')
    python('python-cpu-probe','/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-parameter-handoff-20260912/cpu_probe.py',str(OUT/'python-cpu-probe.json'),cpu=True)
    python('python-cpu-module-forward','bindings/st-py/tests/test_nn_module_resident_forward.py','Surface','-v',cpu=True)
    python('python-cpu-handoff','bindings/st-py/tests/test_nn_resident_module_update.py','Surface','-v',cpu=True)
    python('browser-to-cpu-python','tools/resident_module_handoff_fixture.py','apply',str(OUT/'browser-handoff.json'),str(OUT/'browser-to-cpu-python.json'),cpu=True)
    run('wasm-cpu-check',C+['check','--locked','-p','spiraltorch-wasm','--no-default-features','--features','nn','--target','wasm32-unknown-unknown'])
    for name,sha in report['products'].items(): assert digest(OUT/name)==sha,name
    for name,sha in baseline_receipt['products'].items(): assert digest(BASELINE/name)==sha,name
    assert json.loads((OUT/'browser-module-forward.json').read_bytes())['direct_io_guards'] is True
    assert json.loads((OUT/'browser-module-forward.json').read_bytes())['output_reuse_guards'] is True
    assert json.loads((OUT/'browser-module-forward.json').read_bytes())['shared_stage_guards'] is True
    assert git('rev-parse','HEAD')==source['commit'] and not git('status','--porcelain')
    report['status']='passed'
except BaseException as error:
    report['status']='error'; report['error']=repr(error)
    raise
finally:
    save()

