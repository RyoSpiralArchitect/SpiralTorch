# Window-Aware CUDA Admission

Compiled/benchmark source: 2effcf948692e921a358b4f6d9e60d32d4709537.
The published source-delta.bundle requires e952513661c1956582ea719e73fb4cbdabe2527e.
The full original Furnace handoff is retained separately, not nested into the
publication again. Later commits only add documentation/evidence. Rust/backend/WASM sources are unchanged from
8a3624f8. Timed RankControl/measure bodies are unchanged; this corrects fixed
fixture admission outside timing and adds regression tests.

## Test And Build

Local Torch 2.12.1 uses -I. Furnace Torch 2.13.0+cu132 uses the existing user
site, so omit -I remotely. Neither requested CUDA tests nor benchmarks may
fall back to CPU. Native Rust uses the private 1.98.1 toolchain and four jobs.

```sh
SPIRALTORCH_RUN_TORCH_RANK_TESTS=1 SPIRALTORCH_TORCH_RANK_DEVICE=cpu PRIVATE_PYTHON -I tests/test_resident_rank_bench.py -v
SPIRALTORCH_RUN_TORCH_RANK_TESTS=1 SPIRALTORCH_TORCH_RANK_DEVICE=cuda python3 tests/test_resident_rank_bench.py -v
cargo +1.98.1 build -p st-core --no-default-features --features wgpu-rt,kdsl --example resident_rank_adaptation_bench --example resident_rank_bench --release
install -m 555 TARGET/release/examples/resident_rank_adaptation_bench NEW_ADAPTATION_IMAGE
install -m 555 TARGET/release/examples/resident_rank_bench NEW_RANK_IMAGE
NEW_ADAPTATION_IMAGE --build-info
NEW_RANK_IMAGE --build-info
sha256sum NEW_ADAPTATION_IMAGE NEW_RANK_IMAGE
```

An intermediate positive MidK test accidentally intersected the reversed-zero
window; its failure is retained in cpu-controls.log. The positive fixture was
corrected and the original case retained as a negative test. Final CPU/CUDA
runs pass 22 tests. This was a test expectation correction, not a runtime
failure hidden by removing coverage.

## Run

Inspect `spiral status` before EACH GPU launch and decide whether to proceed.
Keep owned GPU jobs non-overlapping, including across hosts; no same-host build
overlaps timing. Leave existing CPU workloads and system configuration alone.
Use the matching clean detached Furnace worktree and immutable images:

```sh
python3 run_native_finite_probe.py --repo MATCHING_WORKTREE --executable NEW_ADAPTATION_IMAGE --output NEW_FIRST_JSON
python3 run_native_finite_probe.py --repo MATCHING_WORKTREE --executable NEW_ADAPTATION_IMAGE --output NEW_REPEAT_JSON
python3 tools/bench_resident_rank_vs_torch.py --executable NEW_RANK_IMAGE --suite standard --resident-only --output NEW_STANDARD_JSON
python3 run_tail_ties_probe.py --repo MATCHING_WORKTREE --executable NEW_ADAPTATION_IMAGE --output NEW_TAIL_FIRST_JSON
python3 run_tail_ties_probe.py --repo MATCHING_WORKTREE --executable NEW_ADAPTATION_IMAGE --output NEW_TAIL_REPEAT_JSON
```

This repeats all 98 cases with the corrected source, including two 18-case
runs, the standard 54 cases, and two targeted four-case tail-tie diagnostics.
Both fixture generators remain byte-identical to the initial study. Retain
all controls and label best fixed as hindsight, not policy or the fastest
possible PyTorch implementation. Readbacks/checks occur outside each timed
interval; value-key encoding, repair and gather occur inside every operation.

## Replay

```sh
python -I analyze_references.py --repo /path/to/SpiralTorch --output recomputed.json
```

Use unchanged measured benchmark files; their hashes are checked. No Torch,
GPU or browser is needed. The initial dc840c97 study is separately replayed
against its pinned checkout, not reinterpreted with the new admission rule.
Large executables and private session listings are excluded from publication.
