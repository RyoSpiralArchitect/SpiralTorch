"""Targeted diagnostic: duplicate values occur only outside the retained set."""
import argparse
import hashlib
import json
from pathlib import Path
import random
import sys


def requests(bench):
    for kind in ("topk", "bottomk"):
        for rows in (2, 64):
            seed, cols, k = 29, 8193, 65
            rng = random.Random(seed)
            values = []
            for _ in range(rows):
                row = [(index - 4096) / 8192 for index in range(cols)]
                row = [0. if abs(value) < .25 else value for value in row]
                rng.shuffle(row)
                values.extend(row)
            tiles = [2048, 32, 128, 256, 512, 1024]
            scripts = [f"u2: true; rank_tile: {tile}; ctile: {tile};" for tile in tiles]
            yield dict(kind=kind, rows=rows, cols=cols, k=k, scripts=scripts,
                       input=values, seed=seed, policy="ucb", rounds=16), tiles


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--executable", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    import bench_resident_rank_adaptation_vs_torch as adaptation
    import bench_resident_rank_vs_torch as resident
    import torch_rank_reference as reference
    for request, _ in requests(None):
        assert resident.cuda_rank_operation(request) == "stable_sort"
        assert reference.contract(request)["operations"] == ["topk", "stable_sort", "packed_topk"]
    adaptation.requests = requests
    report = adaptation.run(args.executable.resolve(strict=True))
    report["probe"] = dict(schema="spiraltorch.tail_tie_admission_probe.v1",
        runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        boundary="Targeted synthetic admission diagnostic, not a representative workload or backend speedup: repeated interior zeros with unique retained values and cutoff.")
    audit.write_report_exclusive(args.output, report)
    print(json.dumps({"status": report["status"], "cases": len(report["cases"]), "error": report.get("error")}))
    raise SystemExit(report["status"] != "passed")


if __name__ == "__main__":
    main()
