"""Capture source identities and publish GPU-only availability observations."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path("/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-canonical-cuda-rank-reference-v1")
SOURCE = "2effcf948692e921a358b4f6d9e60d32d4709537"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO).decode().strip()


availability = []
for path in sorted(ROOT.glob("private-status-*.txt")):
    raw = path.read_text()
    gpu = raw.split("── gpu ──", 1)[1].split("── tmux ──", 1)[0].strip()
    assert "(no compute processes)" in gpu
    availability.append(dict(check=path.name, private_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                             captured_at_unix=path.stat().st_mtime, gpu=gpu))
(ROOT / "availability.json").write_text(json.dumps(dict(point_checks_only=True, observations=availability),
                                                   indent=2, sort_keys=True) + "\n")
if sys.argv[1:] == ["--availability-only"]:
    print(json.dumps(dict(availability_checks=len(availability))))
    raise SystemExit(0)
assert not sys.argv[1:]
assert git("rev-parse", "HEAD") == SOURCE and not git("status", "--porcelain", "--untracked-files=no")
assert not git("diff", "8a3624f89b60b1586167e5c2978b2d19848dadeb", "--", "crates", "bindings/st-wasm/src", "bindings/st-py/src")
products = dict(compiled_source=SOURCE, git_tree=git("rev-parse", "HEAD^{tree}"), source_clean=True,
    backend_and_binding_rust_identical_to="8a3624f89b60b1586167e5c2978b2d19848dadeb",
    local_torch=subprocess.check_output(["/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python", "-I", "-c", "import torch; print(torch.__version__)"]).decode().strip(),
    runtime_files={name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() for name in (
        "tools/torch_rank_reference.py", "tools/bench_resident_rank_vs_torch.py",
        "tools/bench_resident_rank_adaptation_vs_torch.py", "tests/test_resident_rank_bench.py")},
    native_builds={name: json.loads((ROOT / name).read_text()) for name in (
        "rank-2effcf94-build-info.json", "adaptation-2effcf94-build-info.json")})
(ROOT / "products.json").write_text(json.dumps(products, indent=2, sort_keys=True) + "\n")
print(json.dumps(dict(source=SOURCE, availability_checks=len(availability), local_torch=products["local_torch"])))
