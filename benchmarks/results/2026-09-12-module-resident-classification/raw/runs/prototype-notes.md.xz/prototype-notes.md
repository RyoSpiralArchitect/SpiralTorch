# Preliminary Failures

These logs predate the frozen source-bound verification and are retained as
development history, not counted as validation of the committed candidate.

- `initial-backend.log`: WGSL parser rejected the reserved identifier `active`.
- `backend-b.log`: WGSL parser rejected the reserved identifier `target`.
- `backend-c.log` and `backend-d.log`: ordinary cases and tiny tails passed,
  but the wide finite mean loss was rejected by the whole-loss guard. The
  half-difference prototype did not satisfy the extreme-value contract. No
  compiler-level root cause was proven. Aligned-significand differences replaced
  that prototype; the same wide mean, smoothing and failure checks then passed.
- `backend-e.log`: all three backend tests passed before the final common-range
  fast path. Final committed-source results are in the `verified-*` run.
- `initial-nn.log`: test-fixture macro was out of lexical scope; the local
  native/WASM read helper fixed the compilation failure.
- `nn-b.log`: the integrated 64-step classifier and numerical probes passed
  before the final source freeze.

No performance claim follows from any of these preliminary checks.

## First Frozen Run

`verified-a` is separately source-bound to commit `318a1072`. Native and Python
checks and browser classification updates passed, but the 39th stage rejected
the generated configured constructor because the type-test helper assumed a
zero-argument constructor. `types-repair.log` checks the exact optional-argument
signature on those same frozen generated and shipped declarations. The
subsequent `verified-b` run uses a new source commit; all old artifacts remain.

## Documentation Check

After all 65 stages passed, `docs-example-a.log` records a harness-only error:
the guide had already successfully read its 32 single-use update receipts, and
the extra check attempted to read them again. The failed helper is retained as
`docs_example_a.py`. The corrected helper requests a fresh terminal receipt;
neither library source nor the executed guide block changed.
