"""Freeze class-last CrossEntropy learning, including explicit reference gaps."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
RUN = LOG / 'verified-b'
BASE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-inline-guard-20260912/verified-a')
OUT = ROOT / 'benchmarks/results/2026-09-12-module-resident-classification'
LOADER = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py')
CPU_PROBE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-parameter-handoff-20260912/cpu_probe.py')
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_bytes())
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def checked(path, count=None):
    receipt = read(path)
    assert receipt['status'] == 'passed' and 'active' not in receipt
    assert all(step['exit_code'] == 0 for step in receipt['steps'])
    if count is not None:
        assert len(receipt['steps']) == count, len(receipt['steps'])
    return receipt


assert not OUT.exists(), 'archive exists; inspect rather than overwrite'
run = checked(RUN / 'receipt.json', 65)
first = read(LOG / 'verified-a/receipt.json')
assert first['status'] == 'error' and first['error'] == "RuntimeError('client-types')"
assert 'active' not in first and len(first['steps']) == 39 and first['steps'][-1]['exit_code'] == 1
base = checked(BASE / 'receipt.json')
assert git('rev-parse', 'HEAD').decode().strip() == run['source']['commit']
assert not git('status', '--porcelain').strip()
assert sha((LOG / 'run.py').read_bytes()) == run['harness_sha256']
assert sha(LOADER.read_bytes()) == run['loader_sha256']
assert sha((BASE / 'receipt.json').read_bytes()) == run['baseline_receipt_sha256']
products = []
for label, folder, receipt in [('baseline-control', BASE, base), ('failed-types', LOG/'verified-a', first), ('candidate', RUN, run)]:
    for name, digest in receipt['products'].items():
        path = folder / name
        assert sha(path.read_bytes()) == digest, str(path)
        products.append(dict(version=label, path=str(path), sha256=digest))

torch = read(RUN / 'torch-correctness.json')
assert torch['status'] == 'passed'
for item in torch['inputs']:
    assert sha(Path(item['path']).read_bytes()) == item['sha256']
new_torch = [case for case in torch['cases'] if case.get('classification')]
assert len(new_torch) == 188
assert len(torch['reference_gaps']) == 4
trajectories = []
for route, filename in [('native', 'native-correctness.json'), ('browser', 'browser-correctness.json')]:
    fixture = read(RUN / filename)
    section = fixture['classification']
    assert fixture['status'] == section['status'] == 'passed'
    assert len(section['cases']) == 6 and len(section['probes']) == 43
    for case in section['cases']:
        assert len(case['steps']) == case['observations_after_updates'] == 64
        assert case['module_parameters_applied'] == 7
        initial = case['steps'][0]['loss']
        final = case['final_loss']
        assert 0 <= final < initial
        trajectories.append(dict(route=route, seed=case['seed'], policy=case['policy'],
            shape=case['input_shape'], initial_loss=initial, final_loss=final,
            final_over_initial=final / initial, updates=64, first_observation_after_updates=64,
            module_parameters_applied=7, optimizer=case['optimizer'], label_smoothing=case['label_smoothing']))
clients = read(RUN / 'browser-classification.json')
assert clients['status'] == 'passed' and clients['exact_ignore_transport'] is True
assert len(clients['cases']) == 6
guide = read(LOG / 'docs-example.json')
assert guide['status'] == 'passed' and guide['source'] == run['source']
assert guide['library_sha256'] == run['products']['python-release.dylib']
assert guide['updates'] == 32
for name in ['direct-io-validation', 'module-forward-validation']:
    assert read(RUN / (name + '.json'))['status'] == 'passed'
counts = {}
for path in RUN.glob('*.log'):
    content = path.read_text()
    rust = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', content)
    python = re.findall(r'^Ran (\d+) tests? in', content, re.MULTILINE)
    if rust or python:
        assert all(int(failed) == 0 for _, failed, _ in rust)
        counts[path.name] = dict(rust_passed=sum(int(p) for p, _, _ in rust),
            rust_ignored=sum(int(i) for _, _, i in rust), python_ran=sum(map(int, python)))

files = {'runs/' + str(path.relative_to(LOG)): path for path in LOG.rglob('*')
    if path.is_file() and '__pycache__' not in path.parts
    and path.suffix in ('.json', '.jsonl', '.log', '.py', '.js', '.mjs', '.ts', '.html', '.md')}
files.update({'inputs/baseline-receipt.json': BASE / 'receipt.json',
    'inputs/baseline-native-fixture.json': BASE / 'native-forward-bench.json',
    'inputs/python-client.py': LOADER, 'inputs/cpu_probe.py': CPU_PROBE})
payloads = {name: (path.read_bytes(), dict(path=str(path))) for name, path in files.items()}
source = run['source']['commit']
parent = git('rev-parse', '318a1072^').decode().strip()
names = set(git('diff', '--name-only', parent, source).decode().splitlines())
names.update(['Cargo.toml', 'Cargo.lock', 'crates/st-backend-wgpu/Cargo.toml',
    'crates/st-backend-wgpu/src/shaders/dense_training.wgsl',
    'crates/st-backend-wgpu/src/runtime.rs', 'crates/st-nn/Cargo.toml',
    'crates/st-nn/tests/resident_graph_training.rs', 'crates/st-tensor/tests/classification.rs',
    'crates/st-nn/examples/resident_graph_training.rs',
    'crates/st-nn/examples/resident_graph_training_browser.rs',
    'bindings/st-py/Cargo.toml', 'bindings/st-wasm/Cargo.toml',
    'tools/validate_module_forward_paths.py', 'tools/validate_module_direct_io.py',
    'tools/bench_graph_forward_paths.py', 'tools/resident_module_handoff_fixture.py'])
for label, commit in [('feature-base', parent), ('failed-types', first['source']['commit']), ('candidate', source)]:
    existing = set(git('ls-tree', '-r', '--name-only', commit).decode().splitlines())
    for name in sorted(names & existing):
        payloads[f'source/{label}/{name}'] = (git('show', commit + ':' + name),
            dict(git_commit=commit, git_path=name))
shader = 'crates/st-backend-wgpu/src/shaders/dense_training.wgsl'
shader_identity = sha(git('show', parent + ':' + shader))
assert shader_identity == sha(git('show', source + ':' + shader))
(OUT / 'raw').mkdir(parents=True)
entries = []
for name, (data, origin) in sorted(payloads.items()):
    packed = lzma.compress(data)
    path = OUT / 'raw' / (name + '.xz')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(packed)
    assert lzma.decompress(path.read_bytes()) == data
    entries.append(dict(archive=str(path.relative_to(OUT)), origin=origin,
        bytes=len(data), sha256=sha(data), compressed_bytes=len(packed), compressed_sha256=sha(packed)))
manifest = dict(schema='spiraltorch.source_archive.v1', status='passed', records=entries,
    raw_bytes=sum(record['bytes'] for record in entries),
    compressed_bytes=sum(record['compressed_bytes'] for record in entries))
write(OUT / 'manifest.json', manifest)


def torch_summary(cases):
    return dict(version=torch['torch'], cases=len(cases),
        tensor_or_scalar_comparisons=sum(case['comparisons'] for case in cases),
        max_abs_error=max(case['max_abs_error'] for case in cases),
        devices=sorted({case['device'] for case in cases}), scope=torch['scope'])


summary = dict(schema='spiraltorch.module_resident_classification_record.v1', status='passed',
    candidate_source=run['source'], feature_base_commit=parent, baseline_control_source=base['source'],
    failed_runs=[dict(source=first['source'], steps=len(first['steps']), error=first['error'],
        receipt_sha256=sha((LOG/'verified-a/receipt.json').read_bytes()))],
    decision='Connect CrossEntropyWithLogits to resident VJP and explicit learner updates through shared Rust label/configuration semantics, stable class-last GPU kernels and thin Python/WASM clients. No generic ModuleTrainer policy substitution or throughput claim.',
    verification_steps=len(run['steps']), verification_seconds=run['seconds'], test_counts=counts,
    torch_all_matched=torch_summary(torch['cases']), torch_classification_matched=torch_summary(new_torch),
    torch_reference_gaps=torch['reference_gaps'],
    trajectories=trajectories, browser_clients=clients, docs_example=guide,
    existing_mse_training_shader_sha256=shader_identity,
    existing_mse_training_shader_unchanged_from_feature_base=True,
    empty_contract='Empty or all-ignored mean fails; sum is zero and none returns zero ignored rows. None uses an all-ones loss seed, as the ordinary Loss backward does.',
    frozen_products_checked=len(products), products=products,
    raw_records=len(entries), manifest_sha256=sha((OUT / 'manifest.json').read_bytes()),
    preliminary_logs='See prototype-notes.md in the raw archive. Reserved WGSL names, a rejected wide-value prototype and a fixture macro-scope failure are retained, not counted as committed-source verification.',
    boundary='Small deterministic class-last graph learning and numerical correctness, not LLM/FT quality or a speedup. Six 64-update cases plus 43 probes on each native/browser route; explicit SGD only. Native Apple M4/Metal. Eager Torch CPU/MPS, MPS fallback disabled; wide-value probes explicitly use CPU-f64 references. Tiny-tail differences are outside matched-comparison counts. Browser physical GPU and host exclusivity UNKNOWN. Ordinary forward controls are retained, not sustained-interval performance proof. No CUDA/Furnace, generic ModuleTrainer migration, release, push or merge.')
write(OUT / 'summary.json', summary)
print(json.dumps(dict(status='passed', records=len(entries), raw_bytes=manifest['raw_bytes'],
    compressed_bytes=manifest['compressed_bytes'], products=len(products),
    torch_all=summary['torch_all_matched'], torch_classification=summary['torch_classification_matched'], reference_gaps=len(torch['reference_gaps']))))
