"""Source-bound class-last CrossEntropy learning; owned GPU work is serial."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
TARGET = ROOT.parent/'spiraltorch-spiralk-golden-blackcat-contract-v1/target'
LOG = Path(__file__).parent
BASE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-inline-guard-20260912/verified-a')
P = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH = '/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
BINDGEN = '/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen'
LOADER = '/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py'
if len(sys.argv) == 3 and sys.argv[1] == '--launch':
    name = sys.argv[2]
    if name.startswith('-') or Path(name).name != name or (LOG/name).exists(): raise ValueError('fresh output name required')
    with (LOG/(name+'.log')).open('xb') as out:
        child = subprocess.Popen([P, '-S', str(Path(__file__).resolve()), name], cwd=ROOT,
            stdin=subprocess.DEVNULL, stdout=out, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps(dict(pid=child.pid, log=str(LOG/(name+'.log'))))); raise SystemExit(0)
if len(sys.argv) != 2 or sys.argv[1].startswith('-') or Path(sys.argv[1]).name != sys.argv[1]: raise ValueError('OUTPUT_NAME or --launch OUTPUT_NAME')
OUT = LOG/sys.argv[1]; OUT.mkdir()
env = dict(os.environ, CARGO_BUILD_JOBS='4', CARGO_TARGET_DIR=str(TARGET), PYO3_PYTHON=P,
    SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1', PYTORCH_ENABLE_MPS_FALLBACK='0',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''): h.update(block)
    return h.hexdigest()

source = dict(commit=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'))
if git('status', '--porcelain'): raise ValueError('dirty runtime source')
report = dict(status='running', pid=os.getpid(), source=source, steps=[], products={},
    harness_sha256=digest(Path(__file__)), loader_sha256=digest(Path(LOADER)),
    contention='UNKNOWN; owned GPU work serial, not host exclusivity',
    boundary='Ordinary CrossEntropyWithLogits evaluates class-last GPU value and prediction cotangent through shared Rust label/configuration contracts. Six 64-update cases and 43 numerical probes on each native/browser route; six public-client update/reject/recover cases per Python/WASM. Tiny-tail PyTorch precision gaps are recorded separately; extreme probes use explicit CPU-f64 reference, not fallback. No generic ModuleTrainer policy substitution or throughput claim.')

def save():
    path = OUT/'receipt.json.tmp'; path.write_text(json.dumps(report, indent=2)+'\n'); path.replace(OUT/'receipt.json')

def run(name, args, output=None):
    args = [str(value) for value in args]
    print('START', name, flush=True); start = time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        out = (OUT/output).open('xb') if output else log
        try:
            child = subprocess.Popen(args, cwd=ROOT, env=env, stdout=out, stderr=log if output else subprocess.STDOUT)
            report['active'] = dict(name=name, pid=child.pid, command=args); save()
            try: code = child.wait(timeout=1800)
            except subprocess.TimeoutExpired:
                child.kill(); child.wait(); raise
        finally:
            if output: out.close()
    report.pop('active')
    report['steps'].append(dict(name=name, command=args, exit_code=code, seconds=time.monotonic()-start)); save()
    print('END', name, code, flush=True)
    if code: raise RuntimeError(name)

def product(path):
    report['products'][str(path.relative_to(OUT))] = digest(path); save()

def freeze(src, name):
    dest = OUT/name; shutil.copyfile(src, dest); dest.chmod(0o555); product(dest)

def bindgen(src, folder):
    run(folder+'-bindgen', [BINDGEN, src, '--target', 'web', '--out-dir', OUT/folder, '--out-name', 'spiraltorch_wasm'])
    for path in (OUT/folder).rglob('*'):
        if path.is_file(): product(path)

def browser(name, folder, suite):
    run(name, ['node', 'tools/test_resident_browser.cjs', OUT/folder, CHROME, OUT/(name+'.json'), '', '', '', '', suite])

def python(name, file, *args, cpu=False):
    run(name, [P, '-I', LOADER, OUT/('python-cpu.dylib' if cpu else 'python-release.dylib'), ROOT, file, *args])

C = ['cargo', '+1.98.0']
TEST = C+['test', '--locked', '--release']
BUILD = C+['build', '--locked', '--release']
NN = ['-p', 'st-nn', '--no-default-features', '--features', 'wgpu']
SERIAL = ['--', '--test-threads=1']
start = time.monotonic()
try:
    base = json.loads((BASE/'receipt.json').read_bytes())
    assert base['status'] == 'passed'
    for name, sha in base['products'].items(): assert digest(BASE/name) == sha, name
    report.update(baseline_source=base['source'], baseline_receipt_sha256=digest(BASE/'receipt.json')); save()
    run('classification-admission-tests', [TORCH, '-I', 'tools/test_resident_classification_admission.py', '-v'])
    run('terminal-admission-tests', [P, '-I', 'tools/test_module_terminal_paths.py', '-v'])
    run('admission-tests', [P, '-I', 'tools/test_module_direct_io.py', '-v'])
    run('interval-admission-tests', [P, '-I', 'tools/test_module_interval_validation.py', '-v'])
    run('interval-cadence-tests', ['node', '--test', 'tools/test_module_resident_intervals.mjs'])
    run('format', ['cargo', '+nightly-2026-04-15', 'fmt', '--all', '--', '--check'])
    run('contracts', TEST+['-p', 'st-kernel-contracts', '--lib'])
    run('tensor-cpu', TEST+['-p', 'st-tensor', '--no-default-features', '--lib']+SERIAL)
    run('tensor-wgpu', TEST+['-p', 'st-tensor', '--no-default-features', '--features', 'wgpu', '--lib']+SERIAL)
    run('classification-cpu', TEST+['-p', 'st-tensor', '--no-default-features', '--test', 'classification']+SERIAL)
    run('classification-wgpu', TEST+['-p', 'st-tensor', '--no-default-features', '--features', 'wgpu', '--test', 'classification']+SERIAL)
    run('nn-cpu', TEST+['-p', 'st-nn', '--no-default-features', '--lib', '--test', 'parameter_storage_tracking']+SERIAL)
    run('nn-serial', TEST+NN+['--lib', '--test', 'parameter_storage_tracking']+SERIAL)
    run('descriptor-cpu', TEST+['-p', 'st-nn', '--no-default-features', '--test', 'inference_lowering_allocations', '--', '--test-threads=1', '--nocapture'])
    run('descriptor-wgpu', TEST+NN+['--test', 'inference_lowering_allocations', '--', '--test-threads=1', '--nocapture'])
    run('backend-serial', TEST+['-p', 'st-backend-wgpu', '--lib']+SERIAL)
    run('integration', TEST+NN+['--test', 'resident_graph_forward', '--test', 'resident_graph_training', '--test', 'resident_nd_tensor', '--test', 'resident_training']+SERIAL)
    run('python-build', BUILD+['-p', 'spiraltorch-py'])
    freeze(TARGET/'release/libspiraltorch.dylib', 'python-release.dylib')
    python('python-tests', 'tests', OUT/'python-tests.json')
    for name in ['graph_autograd', 'graph_learner', 'module_update']:
        python('python-'+name, 'bindings/st-py/tests/test_nn_resident_'+name+'.py', '-v')
    python('python-module-forward', 'bindings/st-py/tests/test_nn_module_resident_forward.py', '-v')
    python('python-pointwise', 'bindings/st-py/tests/test_wgpu_pointwise.py', '-v')
    python('python-resident-loss', 'bindings/st-py/tests/test_nn_resident_loss.py', '-v')
    python('python-classification', 'bindings/st-py/tests/test_nn_resident_classification.py', '-v')
    run('wasm-client-build', BUILD+['-p', 'spiraltorch-wasm', '--features', 'webgpu', '--target', 'wasm32-unknown-unknown'])
    bindgen(TARGET/'wasm32-unknown-unknown/release/spiraltorch_wasm.wasm', 'client')
    python('handoff-fixture', 'tools/resident_module_handoff_fixture.py', 'export', OUT/'client/handoff-fixture.json')
    product(OUT/'client/handoff-fixture.json')
    browser('browser-handoff', 'client', 'nn-module-handoff')
    browser('browser-module-forward', 'client', 'nn-module-forward')
    browser('browser-resident-loss', 'client', 'nn-loss-clients')
    browser('browser-classification', 'client', 'nn-classification-clients')
    python('browser-to-python', 'tools/resident_module_handoff_fixture.py', 'apply', OUT/'browser-handoff.json', OUT/'browser-to-python.json')
    for name, suite in [('pointwise', 'pointwise-clients'), ('learner', 'nn-learner-clients'), ('autograd', 'nn-autograd-clients'), ('fusion', 'nn-fusion-clients')]:
        browser('wasm-'+name, 'client', suite)
    run('client-types', ['node', 'bindings/st-wasm/tests/resident_types.cjs', OUT/'client/spiraltorch_wasm.d.ts', ROOT/'bindings/st-wasm/types/spiraltorch-wasm.d.ts'])
    examples = ['resident_graph_forward', 'resident_graph_training', 'resident_graph_forward_bench', 'resident_nd_tensor']
    run('native-build', BUILD+NN+[word for name in examples for word in ('--example', name)])
    for name in examples: freeze(TARGET/'release/examples'/name, name)
    run('native-nd', [OUT/'resident_nd_tensor'], output='native-nd.json')
    run('forward-fixture', [OUT/'resident_graph_forward'], output='client/forward-fixture.json')
    product(OUT/'client/forward-fixture.json')
    browser('wasm-forward', 'client', 'nn-forward-clients')
    run('wasm-example-build', BUILD+NN+['--target', 'wasm32-unknown-unknown', '--example', 'resident_graph_training_browser', '--example', 'resident_nd_tensor_browser'])
    bindgen(TARGET/'wasm32-unknown-unknown/release/examples/resident_graph_training_browser.wasm', 'correctness')
    bindgen(TARGET/'wasm32-unknown-unknown/release/examples/resident_nd_tensor_browser.wasm', 'nd')
    browser('browser-nd', 'nd', 'nd-tensor')
    run('native-correctness', [OUT/'resident_graph_training'], output='native-correctness.json')
    browser('browser-correctness', 'correctness', 'nn-graph-training')
    run('torch-correctness', [TORCH, '-I', 'tools/validate_resident_graph_training_vs_torch.py', OUT/'native-correctness.json', OUT/'browser-correctness.json', '--devices', 'cpu', 'mps', '--require-resident-loss', '--require-classification', '--output', OUT/'torch-correctness.json'])
    run('native-forward-bench', [OUT/'resident_graph_forward_bench'], output='native-forward-bench.json')
    run('torch-reference-shapes', [TORCH, '-I', 'tools/test_module_forward_reference.py', '-v'])
    for name, library in [('baseline-module-bench', BASE/'python-release.dylib'), ('module-forward-bench', OUT/'python-release.dylib')]:
        run(name, [TORCH, '-I', 'tools/bench_graph_forward_paths.py', '--fixture', OUT/'native-forward-bench.json', '--native-library', library, '--include-module', '--output', OUT/(name+'.json')])
    run('module-forward-validation', [TORCH, '-I', 'tools/validate_module_forward_paths.py', '--native', OUT/'native-forward-bench.json', '--python', OUT/'module-forward-bench.json', '--browser', OUT/'browser-module-forward.json', '--output', OUT/'module-forward-validation.json'])
    freeze(OUT/'native-forward-bench.json', 'client/forward-bench-fixture.json')
    run('browser-module-matched', ['node', 'tools/test_resident_browser.cjs', OUT/'client', CHROME, OUT/'browser-module-matched.json', '', '', '', '', 'nn-module-matched', BASE/'client'])
    run('direct-io-validation', [P, '-I', 'tools/validate_module_direct_io.py', '--fixture', OUT/'native-forward-bench.json',
        '--baseline-python', OUT/'baseline-module-bench.json', '--candidate-python', OUT/'module-forward-bench.json',
        '--browser', OUT/'browser-module-matched.json', '--baseline-receipt', BASE/'receipt.json',
        '--candidate-library', OUT/'python-release.dylib', '--candidate-wasm', OUT/'client/spiraltorch_wasm_bg.wasm',
        '--output', OUT/'direct-io-validation.json'])
    run('python-cpu-build', BUILD+['-p', 'spiraltorch-py', '--no-default-features', '--features', 'python-default'])
    freeze(TARGET/'release/libspiraltorch.dylib', 'python-cpu.dylib')
    python('python-cpu-probe', '/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-parameter-handoff-20260912/cpu_probe.py', OUT/'python-cpu-probe.json', cpu=True)
    python('python-cpu-module-forward', 'bindings/st-py/tests/test_nn_module_resident_forward.py', 'Surface', '-v', cpu=True)
    python('python-cpu-resident-loss', 'bindings/st-py/tests/test_nn_resident_loss.py', 'Surface', '-v', cpu=True)
    python('python-cpu-classification', 'bindings/st-py/tests/test_nn_resident_classification.py', 'Surface', '-v', cpu=True)
    python('python-cpu-handoff', 'bindings/st-py/tests/test_nn_resident_module_update.py', 'Surface', '-v', cpu=True)
    python('browser-to-cpu-python', 'tools/resident_module_handoff_fixture.py', 'apply', OUT/'browser-handoff.json', OUT/'browser-to-cpu-python.json', cpu=True)
    run('wasm-cpu-check', C+['check', '--locked', '-p', 'spiraltorch-wasm', '--no-default-features', '--features', 'nn', '--target', 'wasm32-unknown-unknown'])
    for name, sha in report['products'].items(): assert digest(OUT/name) == sha, name
    for name, sha in base['products'].items(): assert digest(BASE/name) == sha, name
    module = json.loads((OUT/'browser-module-forward.json').read_bytes())
    for name in ['direct_io_guards', 'output_reuse_guards', 'shared_stage_guards', 'terminal_guard_ordering', 'tensor_readback_ownership', 'terminal_forward_capture']:
        assert module[name] is True, name
    assert json.loads((OUT/'browser-nd.json').read_bytes())['tensor_snapshots']['cancelled_pending_maps'] == 4
    assert json.loads((OUT/'native-nd.json').read_bytes())['tensor_snapshots']['held_snapshots'] == 24
    assert json.loads((OUT/'browser-nd.json').read_bytes())['tensor_snapshots']['terminal_cancelled_pending_maps'] == 4
    assert git('rev-parse', 'HEAD') == source['commit'] and not git('status', '--porcelain')
    assert json.loads((OUT/'browser-resident-loss.json').read_bytes())['views_empty_lifetimes_whole_loss_guards'] is True
    classification = json.loads((OUT/'browser-classification.json').read_bytes())
    assert classification['exact_ignore_transport'] is True and len(classification['cases']) == 6
    report['status'] = 'passed'
except BaseException as error:
    report.update(status='error', error=repr(error)); raise
finally:
    report['seconds'] = time.monotonic()-start; save()
