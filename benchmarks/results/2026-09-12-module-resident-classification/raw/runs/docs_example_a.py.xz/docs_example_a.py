"""Run the exact guide block against the frozen GPU product after serial verification."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

import spiraltorch as st

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
RUN = LOG / 'verified-b'
receipt = json.loads((RUN / 'receipt.json').read_bytes())
assert receipt['status'] == 'passed' and 'active' not in receipt
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == receipt['source']['commit']
library = Path(st._rs.__file__).resolve()
assert library == RUN / 'python-release.dylib'
digest = lambda data: hashlib.sha256(data).hexdigest()
assert digest(library.read_bytes()) == receipt['products']['python-release.dylib']
blocks = re.findall(r'```python\n(.*?)\n```', (ROOT / 'docs/module_resident_classification.md').read_text(), re.S)
assert len(blocks) == 1
scope = {}
exec(compile(blocks[0], 'docs/module_resident_classification.md', 'exec'), scope)
assert [value.read() for value in scope['receipts']] == list(range(1, 33))
adapter = scope['device'].adapter_info()
assert adapter['device_type'].lower() != 'cpu', adapter
output = scope['model'](scope['x'])
assert tuple(output.shape) == (2, 8, 7)
predicted = scope['learner'].forward().prediction_tensor().snapshot().read_values()
actual = output.snapshot().read_values()
assert len(actual) == len(predicted) == 112
assert all(abs(a-b) <= 2e-5+2e-4*abs(b) for a, b in zip(actual, predicted))
report = dict(status='passed', source=receipt['source'], library=str(library),
    library_sha256=receipt['products']['python-release.dylib'], code_sha256=digest(blocks[0].encode()),
    adapter=adapter, updates=32, output_shape=list(output.shape),
    handoff_max_abs_error=max(abs(a-b) for a,b in zip(actual,predicted)),
    boundary='Exact documentation code, small API-composition fixture, not accuracy or performance evidence; separate from the 65-stage run.')
with (LOG / 'docs-example.json').open('x') as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps(report, allow_nan=False))
