# NOTE: This stub lives next to the runtime package as `spiraltorch/__init__.pyi`,
# so it is shipped in the published wheel (PEP 561).
from __future__ import annotations

from os import PathLike
from typing import Any, Callable, ContextManager, Dict, Iterable, Iterator, List, Literal, Mapping, Optional, Sequence, Tuple, overload
from types import ModuleType

from .optim import Amegagrad, amegagrad

export: ModuleType
hf_ft: ModuleType
hf_peft: ModuleType
hf_input_identity: ModuleType
hf_execution_identity: ModuleType
hf_training_identity: ModuleType
hf_replay_identity: ModuleType
hf_runtime_identity: ModuleType
hf_dataset_identity: ModuleType
hf_adapter: ModuleType
hf_adapter_executor: ModuleType
hf_adapter_executor_launch: ModuleType
hf_adapter_executor_recovery: ModuleType
hf_adapter_executor_runtime: ModuleType
hf_adapter_executor_status: ModuleType
hf_adapter_executor_supervisor: ModuleType
hf_adapter_executor_supervisor_launch: ModuleType
hf_ft_status: ModuleType
hf_generation: ModuleType
hpo: ModuleType
inference: ModuleType
optim: ModuleType
spiralk: ModuleType

AUTOGRAD_CONTRACT_VERSION: Literal["spiraltorch.autograd.v1"]
AUTOGRAD_SEMANTIC_OWNER: Literal["st-tensor"]

def init_backend(backend: str) -> bool: ...

def load_zspace_trace_events(path: str, *, event_type: str = ...) -> List[Dict[str, Any]]: ...

def write_zspace_trace_html(
    trace_jsonl: str,
    html_path: str | None = ...,
    *,
    title: str = ...,
    event_type: str = ...,
    related_links: Mapping[str, str] | None = ...,
) -> str: ...

def load_trainer_trace_events(path: str, *, event_type: str = ...) -> List[Dict[str, Any]]: ...

def summarize_trainer_trace_events(
    path: str,
    *,
    event_type: str = ...,
    keys: Iterable[str] | None = ...,
) -> Dict[str, Any]: ...

def load_hf_gpt2_finetune_status_history(
    path: str | PathLike[str],
) -> List[Dict[str, Any]]: ...

def summarize_hf_gpt2_finetune_status_history(
    rows: List[Dict[str, Any]],
    *,
    label: str | None = ...,
    history_jsonl: str | PathLike[str],
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_status_history_lines(
    summary: Dict[str, Any],
    rows: List[Dict[str, Any]],
    *,
    tail: int,
    tail_evals: int = ...,
) -> List[str]: ...

def hf_gpt2_finetune_monitor_report(
    *,
    direct: Any = ...,
    eval_watch: Any = ...,
    checkpoint_watch: Any = ...,
    final_watch: Any = ...,
    wait_launch: Any = ...,
    milestone_step: int | None = ...,
    label: str | None = ...,
    run_dir: str | PathLike[str] | None = ...,
    next_run_dir: str | PathLike[str] | None = ...,
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_monitor_lines(
    snapshot: Dict[str, Any],
) -> List[str]: ...

def hf_gpt2_finetune_milestone_capture_report(
    monitor_or_status: Any,
    *,
    milestone_step: int | None = ...,
    label: str | None = ...,
    iteration: int | None = ...,
    commands: Sequence[Mapping[str, Any]] | None = ...,
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_milestone_capture_lines(
    report_or_monitor: Mapping[str, Any],
    *,
    milestone_step: int | None = ...,
    label: str | None = ...,
) -> List[str]: ...

def hf_gpt2_finetune_milestone_handoff_report(
    capture_or_monitor: Mapping[str, Any],
    *,
    run_dir: str | PathLike[str] | None = ...,
    checkpoint: str | None = ...,
    label_prefix: str | None = ...,
    python: str = ...,
    script: str | PathLike[str] = ...,
    compare_with_sweep: Sequence[str | PathLike[str]] | str | PathLike[str] | None = ...,
    compare_with_label: Sequence[str] | str | None = ...,
    curve_out: str | PathLike[str] | None = ...,
    curve_lines_out: str | PathLike[str] | None = ...,
    trainer_trace_jsonl: str | PathLike[str] | None = ...,
    run_card: str | PathLike[str] | None = ...,
    top_n: int = ...,
    wait: bool = ...,
    dry_run: bool = ...,
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_milestone_handoff_lines(
    report_or_capture: Mapping[str, Any],
    **kwargs: Any,
) -> List[str]: ...

def hf_gpt2_finetune_milestone_handoff_execution_report(
    report_or_capture: Mapping[str, Any],
    *,
    run: bool = ...,
    use_package_api: bool = ...,
    cwd: str | PathLike[str] | None = ...,
    env: Mapping[str, Any] | None = ...,
    timeout: float | None = ...,
    capture_output: bool = ...,
    check: bool = ...,
    runner: Callable[..., Any] | None = ...,
    package_runner: Callable[..., Mapping[str, Any]] | None = ...,
    out: str | PathLike[str] | None = ...,
    lines_out: str | PathLike[str] | None = ...,
    max_output_chars: int | None = ...,
    **handoff_kwargs: Any,
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_milestone_handoff_execution_lines(
    report_or_handoff: Mapping[str, Any],
    **kwargs: Any,
) -> List[str]: ...

def hf_gpt2_finetune_milestone_runtime_report(
    *,
    direct: Any = ...,
    eval_watch: Any = ...,
    checkpoint_watch: Any = ...,
    final_watch: Any = ...,
    wait_launch: Any = ...,
    milestone_step: int | None = ...,
    label: str | None = ...,
    run_dir: str | PathLike[str] | None = ...,
    next_run_dir: str | PathLike[str] | None = ...,
    capture_iteration: int | None = ...,
    capture_commands: Sequence[Mapping[str, Any]] | None = ...,
    checkpoint: str | None = ...,
    label_prefix: str | None = ...,
    python: str = ...,
    script: str | PathLike[str] = ...,
    compare_with_sweep: Sequence[str | PathLike[str]] | str | PathLike[str] | None = ...,
    compare_with_label: Sequence[str] | str | None = ...,
    curve_out: str | PathLike[str] | None = ...,
    curve_lines_out: str | PathLike[str] | None = ...,
    trainer_trace_jsonl: str | PathLike[str] | None = ...,
    run_card: str | PathLike[str] | None = ...,
    top_n: int = ...,
    wait: bool = ...,
    dry_run: bool = ...,
    execute: bool = ...,
    use_package_api: bool = ...,
    cwd: str | PathLike[str] | None = ...,
    env: Mapping[str, Any] | None = ...,
    timeout: float | None = ...,
    capture_output: bool = ...,
    check: bool = ...,
    runner: Callable[..., Any] | None = ...,
    package_runner: Callable[..., Mapping[str, Any]] | None = ...,
    out: str | PathLike[str] | None = ...,
    lines_out: str | PathLike[str] | None = ...,
    max_output_chars: int | None = ...,
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_milestone_runtime_lines(
    report: Mapping[str, Any],
) -> List[str]: ...

def hf_gpt2_finetune_milestone_runtime_sources(
    run_dir: str | PathLike[str],
    *,
    next_run_dir: str | PathLike[str] | None = ...,
    direct: str | PathLike[str] | None = ...,
    eval_watch: str | PathLike[str] | None = ...,
    checkpoint_watch: str | PathLike[str] | None = ...,
    final_watch: str | PathLike[str] | None = ...,
    wait_launch: str | PathLike[str] | None = ...,
) -> Dict[str, str | None]: ...

def hf_gpt2_finetune_milestone_runtime_artifact_paths(
    run_dir: str | PathLike[str],
    *,
    milestone_step: int | str | None = ...,
    report: Mapping[str, Any] | None = ...,
) -> Dict[str, str]: ...

def write_hf_gpt2_finetune_milestone_runtime_report(
    report: Mapping[str, Any],
    *,
    run_dir: str | PathLike[str] | None = ...,
    out: str | PathLike[str] | None = ...,
    lines_out: str | PathLike[str] | None = ...,
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_milestone_runtime_from_run_dir_report(
    run_dir: str | PathLike[str],
    *,
    next_run_dir: str | PathLike[str] | None = ...,
    direct: Any = ...,
    eval_watch: Any = ...,
    checkpoint_watch: Any = ...,
    final_watch: Any = ...,
    wait_launch: Any = ...,
    out: str | PathLike[str] | None = ...,
    lines_out: str | PathLike[str] | None = ...,
    **runtime_kwargs: Any,
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_milestone_runtime_from_run_dir_archive(
    run_dir: str | PathLike[str],
    *,
    next_run_dir: str | PathLike[str] | None = ...,
    direct: Any = ...,
    eval_watch: Any = ...,
    checkpoint_watch: Any = ...,
    final_watch: Any = ...,
    wait_launch: Any = ...,
    out: str | PathLike[str] | None = ...,
    lines_out: str | PathLike[str] | None = ...,
    **runtime_kwargs: Any,
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_run_artifact_manifest(
    run_dir: str | PathLike[str],
    *,
    next_run_dir: str | PathLike[str] | None = ...,
    generation_limit: int = ...,
    checkpoint_limit: int = ...,
    out: str | PathLike[str] | None = ...,
    lines_out: str | PathLike[str] | None = ...,
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_run_artifact_manifest_lines(
    report: Mapping[str, Any],
    *,
    top_n: int = ...,
) -> List[str]: ...

def hf_gpt2_finetune_run_artifact_manifest_paths(
    run_dir: str | PathLike[str],
) -> Dict[str, str]: ...

def write_hf_gpt2_finetune_run_artifact_manifest(
    report: Mapping[str, Any],
    *,
    run_dir: str | PathLike[str] | None = ...,
    out: str | PathLike[str] | None = ...,
    lines_out: str | PathLike[str] | None = ...,
    top_n: int = ...,
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_run_ops_snapshot_report(
    run_dir: str | PathLike[str],
    *,
    next_run_dir: str | PathLike[str] | None = ...,
    generation_limit: int = ...,
    checkpoint_limit: int = ...,
    milestone_step: int | None = ...,
    label: str | None = ...,
    execute: bool = ...,
    dry_run: bool = ...,
    use_package_api: bool = ...,
    package_runner: Callable[..., Mapping[str, Any]] | None = ...,
    runner: Callable[..., Any] | None = ...,
    out: str | PathLike[str] | None = ...,
    lines_out: str | PathLike[str] | None = ...,
    **runtime_kwargs: Any,
) -> Dict[str, Any]: ...

def hf_gpt2_finetune_run_ops_snapshot_lines(
    report: Mapping[str, Any],
) -> List[str]: ...

def hf_gpt2_finetune_run_ops_snapshot_paths(
    run_dir: str | PathLike[str],
) -> Dict[str, str]: ...

def write_hf_gpt2_finetune_run_ops_snapshot(
    report: Mapping[str, Any],
    *,
    run_dir: str | PathLike[str] | None = ...,
    out: str | PathLike[str] | None = ...,
    lines_out: str | PathLike[str] | None = ...,
) -> Dict[str, Any]: ...

load_hf_finetune_status_history: Callable[..., List[Dict[str, Any]]]
summarize_hf_finetune_status_history: Callable[..., Dict[str, Any]]
hf_finetune_status_history_lines: Callable[..., List[str]]
hf_finetune_monitor_report: Callable[..., Dict[str, Any]]
hf_finetune_monitor_lines: Callable[..., List[str]]
hf_finetune_milestone_capture_report: Callable[..., Dict[str, Any]]
hf_finetune_milestone_capture_lines: Callable[..., List[str]]
hf_finetune_milestone_handoff_report: Callable[..., Dict[str, Any]]
hf_finetune_milestone_handoff_lines: Callable[..., List[str]]
hf_finetune_milestone_handoff_execution_report: Callable[..., Dict[str, Any]]
hf_finetune_milestone_handoff_execution_lines: Callable[..., List[str]]
hf_finetune_milestone_runtime_report: Callable[..., Dict[str, Any]]
hf_finetune_milestone_runtime_lines: Callable[..., List[str]]
hf_finetune_milestone_runtime_sources: Callable[..., Dict[str, str | None]]
hf_finetune_milestone_runtime_artifact_paths: Callable[..., Dict[str, str]]
write_hf_finetune_milestone_runtime_report: Callable[..., Dict[str, Any]]
hf_finetune_milestone_runtime_from_run_dir_report: Callable[..., Dict[str, Any]]
hf_finetune_milestone_runtime_from_run_dir_archive: Callable[..., Dict[str, Any]]
hf_finetune_run_artifact_manifest: Callable[..., Dict[str, Any]]
hf_finetune_run_artifact_manifest_lines: Callable[..., List[str]]
hf_finetune_run_artifact_manifest_paths: Callable[..., Dict[str, str]]
write_hf_finetune_run_artifact_manifest: Callable[..., Dict[str, Any]]
hf_finetune_run_ops_snapshot_report: Callable[..., Dict[str, Any]]
hf_finetune_run_ops_snapshot_lines: Callable[..., List[str]]
hf_finetune_run_ops_snapshot_paths: Callable[..., Dict[str, str]]
write_hf_finetune_run_ops_snapshot: Callable[..., Dict[str, Any]]

def summarize_transformers_trainer_runtime_bridge(
    transformers_trace_jsonl: str,
    trainer_trace_jsonl: str,
    *,
    trainer_event_type: str = ...,
) -> Dict[str, Any]: ...

def compare_amegagrad_topos_training_traces(
    traces: Mapping[str, str | PathLike[str]] | Sequence[str | PathLike[str]],
    *,
    event_type: str = ...,
) -> Dict[str, Any]: ...

def trace_amegagrad_topos_training_sweep(
    trace_dir: str | PathLike[str],
    *,
    profiles: Mapping[str, Mapping[str, Any]] | None = ...,
    steps: int = ...,
    shape: Tuple[int, int] = ...,
    curvature: float = ...,
    hyper_learning_rate: float = ...,
    real_learning_rate: float = ...,
    topos: Mapping[str, Any] | None = ...,
    waves: Sequence[Sequence[float]] | None = ...,
    event_type: str = ...,
) -> Dict[str, Any]: ...

RUNTIME_IMPORT_INSTALL_HINTS: Dict[str, str]
TRANSFORMERS_TRACE_RUNTIME_IMPORT_PRESETS: Dict[str, List[str]]

def required_runtime_import_presets_from_args(args: object) -> List[str]: ...

def required_runtime_import_presets_from_source(
    source: object,
    *,
    required_runtime_import_presets_key: str = ...,
) -> List[str]: ...

def required_runtime_imports_from_args(args: object) -> List[str]: ...

def required_runtime_imports_from_source(
    source: object,
    *,
    required_runtime_imports_key: str = ...,
) -> List[str]: ...

def runtime_import_coimport_status(
    probes: Iterable[Mapping[str, object]],
) -> str: ...

def runtime_import_install_hint(
    name: object,
    *,
    install_hints: Mapping[str, str] | None = ...,
) -> str | None: ...

def runtime_import_install_hints_label(
    names: object,
    *,
    install_hints: Mapping[str, str] | None = ...,
) -> str: ...

def runtime_import_kv_label(
    probes: Iterable[Mapping[str, object]],
    key: str,
) -> str: ...

def runtime_import_names_from_args(
    args: object,
    *,
    preset_modules: Mapping[str, Iterable[str]] | None = ...,
) -> List[str]: ...

def runtime_import_names_from_source(
    source: object,
    *,
    preset_modules: Mapping[str, Iterable[str]] | None = ...,
    runtime_imports_key: str = ...,
    runtime_import_presets_key: str = ...,
    required_runtime_imports_key: str = ...,
    required_runtime_import_presets_key: str = ...,
) -> List[str]: ...

def runtime_import_preflight_report(
    *,
    runtime_imports: object = ...,
    runtime_import_presets: object = ...,
    required_runtime_imports: object = ...,
    required_runtime_import_presets: object = ...,
    runtime_device_backends: object = ...,
    required_runtime_device_backends: object = ...,
    required_runtime_device_ready_backends: object = ...,
    require_all: bool = ...,
    preset_modules: Mapping[str, Iterable[str]] | None = ...,
    describe_runtime_devices: Callable[..., Mapping[str, object]] | None = ...,
) -> Dict[str, Any]: ...

def evaluate_runtime_device_route(
    reports: Iterable[Mapping[str, object]],
    *,
    requested_backends: object = ...,
    required_available_backends: object = ...,
    required_ready_backends: object = ...,
) -> Dict[str, object]: ...

def evaluate_runtime_device_route_from_probes(
    probes: Iterable[Mapping[str, object]],
    *,
    diagnostic_reports: Iterable[Mapping[str, object]] | None = ...,
    requested_backends: object = ...,
    required_available_backends: object = ...,
    required_ready_backends: object = ...,
) -> Dict[str, object]: ...

def evaluate_runtime_execution_plan(
    runtime_probe: Mapping[str, object],
    *,
    accelerator_fallback: Literal["allow", "forbid"] | None = ...,
    tensor_util_wgpu_min_values: int | None = ...,
    component_resolution: Literal["concrete", "deferred"] = ...,
    tensor_util_values: int | None = ...,
    component_workloads: object = ...,
    required_native_components: object = ...,
) -> Dict[str, object]: ...

def resolve_runtime_execution_config(
    *,
    accelerator_fallback: Literal["allow", "forbid"] | None = ...,
    tensor_util_wgpu_min_values: int | None = ...,
) -> Dict[str, object]: ...

def require_executable_runtime_execution_plan(
    payload: Mapping[str, object],
) -> Dict[str, object]: ...

def observe_runtime_execution_plan_capabilities(
    request: Mapping[str, object],
) -> Dict[str, object]: ...

def observe_runtime_device_probe(
    requested_backend: str = ...,
    *,
    lane_width: int | None = ...,
    subgroup: bool | None = ...,
    max_workgroup: int | None = ...,
    shared_mem_per_workgroup: int | None = ...,
    requested_workgroup: int | None = ...,
    cols: int | None = ...,
    tile_hint: int | None = ...,
    compaction_hint: int | None = ...,
) -> Dict[str, object]: ...

def project_runtime_device_probe_contract(
    payload: Mapping[str, object],
) -> Dict[str, object]: ...

def validate_runtime_execution_plan_contract(
    payload: Mapping[str, object],
    *,
    request: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...

def validate_tensor_execution_receipt(
    receipt: Mapping[str, object],
) -> Dict[str, object]: ...

def validate_tensor_execution_receipt_against_runtime_plan(
    receipt: Mapping[str, object],
    runtime_execution_plan: Mapping[str, object],
) -> Dict[str, object]: ...

def validate_runtime_device_probe_contract(
    payload: Mapping[str, object],
    *,
    request: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...

def validate_runtime_device_route_contract(
    payload: Mapping[str, object],
    *,
    request: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...

def runtime_import_preflight_summary_lines(
    report: Mapping[str, object],
) -> List[str]: ...

def runtime_import_preset_missing_modules_label(
    rows: Iterable[Mapping[str, object]],
) -> str: ...

def runtime_import_preset_module_map(value: object) -> Dict[str, str]: ...

def runtime_import_preset_module_rows(
    value: object,
    presets: object,
) -> List[str]: ...

def runtime_import_preset_modules(
    presets: object,
    *,
    preset_modules: Mapping[str, Iterable[str]] | None = ...,
) -> List[str]: ...

def runtime_import_preset_modules_label(
    rows: Iterable[Mapping[str, object]],
) -> str: ...

def runtime_import_preset_status_rows(
    presets: object,
    probes: Iterable[Mapping[str, object]],
    *,
    preset_modules: Mapping[str, Iterable[str]] | None = ...,
) -> List[Dict[str, Any]]: ...

def runtime_import_presets_from_args(args: object) -> List[str]: ...

def runtime_import_presets_from_source(
    source: object,
    *,
    runtime_import_presets_key: str = ...,
    required_runtime_import_presets_key: str = ...,
) -> List[str]: ...

def runtime_import_probe(name: object) -> Dict[str, object]: ...

def runtime_import_probe_fields(
    source: object,
    *,
    preset_modules: Mapping[str, Iterable[str]] | None = ...,
    field_prefix: str = ...,
    runtime_imports_key: str = ...,
    runtime_import_presets_key: str = ...,
    required_runtime_imports_key: str = ...,
    required_runtime_import_presets_key: str = ...,
) -> Dict[str, object]: ...

def runtime_import_probe_rows(names: object) -> List[Dict[str, object]]: ...

def runtime_import_required_gate_fields(
    required_imports: object,
    required_presets: object,
    *,
    imported_modules: object | None = ...,
    observed_presets: object | None = ...,
    satisfied_presets: object | None = ...,
    failed_presets: object | None = ...,
    probes: Iterable[Mapping[str, object]] | None = ...,
    preset_status: Iterable[Mapping[str, object]] | None = ...,
    field_prefix: str = ...,
    include_failed_presets: bool = ...,
) -> Dict[str, object]: ...

def runtime_import_requirement_failures(
    row: Mapping[str, object],
    *,
    field_prefix: str = ...,
    failure_prefix: str = ...,
) -> List[str]: ...

def runtime_device_backends_from_source(
    source: object,
    *,
    runtime_device_backends_key: str = ...,
    required_runtime_device_backends_key: str = ...,
    required_runtime_device_ready_backends_key: str = ...,
) -> List[str]: ...

def runtime_device_report_fields(
    source: object,
    *,
    describe_runtime_devices: Callable[..., Mapping[str, object]] | None = ...,
    field_prefix: str = ...,
    runtime_device_backends_key: str = ...,
    required_runtime_device_backends_key: str = ...,
    required_runtime_device_ready_backends_key: str = ...,
) -> Dict[str, object]: ...

def runtime_device_requirement_failures(
    row: Mapping[str, object],
    *,
    field_prefix: str = ...,
    failure_prefix: str = ...,
) -> List[str]: ...

def runtime_imports_from_args(args: object) -> List[str]: ...

def runtime_imports_from_source(
    source: object,
    *,
    runtime_imports_key: str = ...,
) -> List[str]: ...

def write_runtime_import_preflight_report(
    report: Mapping[str, object],
    path: str | PathLike[str],
) -> str: ...

HF_GPT2_FT_DEFAULT_DEVICE_BACKENDS: List[str]
HF_GPT2_FT_RUN_CARD_FILENAME: str
HF_GPT2_FT_TRAINER_TRACE_FILENAME: str
HF_GPT2_FT_REQUIRED_PYTHON_PACKAGES: List[str]
HF_GPT2_FT_REQUIRED_RUST_SURFACES: List[Dict[str, str]]
HF_FINETUNE_DEFAULT_DEVICE_BACKENDS: List[str]
HF_FINETUNE_DEFAULT_MODEL_CONFIGS: Dict[str, Any]
HF_FINETUNE_DEFAULT_MODEL_PROFILE: str
HF_FINETUNE_MODEL_CONFIG_SCHEMA: str
HF_FINETUNE_RUN_CARD_FILENAME: str
HF_ZSPACE_MATCHED_ABLATION_SCHEMA: str
HF_ZSPACE_FACTORIZED_ABLATION_SCHEMA: str
HF_ZSPACE_FEEDBACK_ABLATION_SCHEMA: str
HF_ZSPACE_POLARITY_ABLATION_SCHEMA: str
HF_ZSPACE_OPTIMIZER_CONTROL_SCHEMA: str
HF_ZSPACE_OPTIMIZER_FEEDBACK_MODES: Tuple[str, ...]
HF_ZSPACE_OPTIMIZER_MODES: Tuple[str, ...]
HF_ZSPACE_OPTIMIZER_RECEIPT_SCHEMA: str
HF_ZSPACE_OPTIMIZER_STATE_FILENAME: str
HF_ZSPACE_OPTIMIZER_STATE_SCHEMA: str
HF_ZSPACE_OPTIMIZER_TRACE_FILENAME: str
HF_ZSPACE_OPTIMIZER_TRACE_SCHEMA: str
HF_ZSPACE_OPTIMIZER_TRAJECTORY_ARMS: Tuple[str, ...]
HF_ZSPACE_OPTIMIZER_TRAJECTORY_FILENAME: str
HF_ZSPACE_OPTIMIZER_TRAJECTORY_POLICY_FILENAME: str

def hf_zspace_optimizer_recipe_contract(
    *,
    mode: str = ...,
    z_dim: int = ...,
    curvature: float = ...,
    control_gain: float = ...,
    volume_per_step: int = ...,
    trajectory_arm: str = ...,
    trajectory_id: str | None = ...,
    trajectory_policy_id: str | None = ...,
    feedback_mode: str = ...,
    feedback_config: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...
def hf_zspace_optimizer_control_callback(
    *,
    mode: str = ...,
    z_dim: int = ...,
    curvature: float = ...,
    control_gain: float = ...,
    volume_per_step: int = ...,
    trajectory_arm: str = ...,
    trajectory: str | PathLike[str] | Mapping[str, object] | None = ...,
    feedback_mode: str = ...,
    feedback_config: Mapping[str, object] | None = ...,
    trajectory_output_path: str | PathLike[str] | None = ...,
    trace_path: str | PathLike[str] | None = ...,
    reset_trace: bool = ...,
    resume_from_checkpoint: str | PathLike[str] | None = ...,
) -> object: ...
def compare_hf_zspace_optimizer_run_cards(
    run_cards: Sequence[str | PathLike[str] | Mapping[str, object]],
) -> Dict[str, object]: ...
def compare_hf_zspace_optimizer_factorized_run_cards(
    run_cards: Sequence[str | PathLike[str] | Mapping[str, object]],
) -> Dict[str, object]: ...
def compare_hf_zspace_optimizer_feedback_run_cards(
    run_cards: Sequence[str | PathLike[str] | Mapping[str, object]],
) -> Dict[str, object]: ...
def compare_hf_zspace_optimizer_polarity_run_cards(
    run_cards: Sequence[str | PathLike[str] | Mapping[str, object]],
) -> Dict[str, object]: ...
def write_hf_zspace_optimizer_matched_ablation_report(
    report: Mapping[str, object],
    path: str | PathLike[str],
) -> str: ...
def write_hf_zspace_optimizer_factorized_ablation_report(
    report: Mapping[str, object],
    path: str | PathLike[str],
) -> str: ...
def write_hf_zspace_optimizer_feedback_ablation_report(
    report: Mapping[str, object],
    path: str | PathLike[str],
) -> str: ...
def write_hf_zspace_optimizer_polarity_ablation_report(
    report: Mapping[str, object],
    path: str | PathLike[str],
) -> str: ...
HF_ZSPACE_FACTORIZED_GAIN_RESPONSE_FILENAME: str
HF_ZSPACE_FACTORIZED_GAIN_RESPONSE_SCHEMA: str
HF_ZSPACE_FACTORIZED_STUDY_ARMS: Tuple[str, ...]
HF_ZSPACE_FACTORIZED_STUDY_EVENT_SCHEMA: str
HF_ZSPACE_FACTORIZED_STUDY_REPORT_FILENAME: str
HF_ZSPACE_FACTORIZED_STUDY_SCHEMA: str
HF_ZSPACE_FACTORIZED_STUDY_SUMMARY_SCHEMA: str
HF_ZSPACE_FEEDBACK_STUDY_ARMS: Tuple[str, ...]
HF_ZSPACE_FEEDBACK_STUDY_EVENT_SCHEMA: str
HF_ZSPACE_FEEDBACK_STUDY_REPORT_FILENAME: str
HF_ZSPACE_FEEDBACK_STUDY_SCHEMA: str
HF_ZSPACE_FEEDBACK_STUDY_SUMMARY_SCHEMA: str
HF_ZSPACE_POLARITY_STUDY_ARMS: Tuple[str, ...]
HF_ZSPACE_POLARITY_CORPUS_REPORT_FILENAME: str
HF_ZSPACE_POLARITY_CORPUS_REPORT_SCHEMA: str
HF_ZSPACE_POLARITY_CORPUS_STUDY_PLAN_FILENAME: str
HF_ZSPACE_POLARITY_CORPUS_STUDY_SCHEMA: str
HF_ZSPACE_POLARITY_CORPUS_STUDY_SUMMARY_FILENAME: str
HF_ZSPACE_POLARITY_CORPUS_STUDY_SUMMARY_SCHEMA: str
HF_ZSPACE_POLARITY_STUDY_EVENT_SCHEMA: str
HF_ZSPACE_POLARITY_STUDY_REPORT_FILENAME: str
HF_ZSPACE_POLARITY_STUDY_SCHEMA: str
HF_ZSPACE_POLARITY_STUDY_SUMMARY_SCHEMA: str
class HFZSpaceFactorizedStudyError(ValueError): ...
def build_hf_zspace_optimizer_factorized_study_plan(
    *,
    study_dir: str | PathLike[str],
    seeds: Sequence[int],
    bridge_args: Sequence[str],
    bridge_script: str | PathLike[str] | None = ...,
    python_executable: str | PathLike[str] | None = ...,
    launch_cwd: str | PathLike[str] | None = ...,
    min_free_disk_gb: float = ...,
) -> Dict[str, object]: ...
def build_hf_zspace_optimizer_feedback_study_plan(
    *,
    study_dir: str | PathLike[str],
    seeds: Sequence[int],
    bridge_args: Sequence[str],
    feedback_config: Mapping[str, object] | None = ...,
    bridge_script: str | PathLike[str] | None = ...,
    python_executable: str | PathLike[str] | None = ...,
    launch_cwd: str | PathLike[str] | None = ...,
    min_free_disk_gb: float = ...,
) -> Dict[str, object]: ...
def build_hf_zspace_optimizer_polarity_study_plan(
    *,
    study_dir: str | PathLike[str],
    seeds: Sequence[int],
    bridge_args: Sequence[str],
    bridge_script: str | PathLike[str] | None = ...,
    python_executable: str | PathLike[str] | None = ...,
    launch_cwd: str | PathLike[str] | None = ...,
    min_free_disk_gb: float = ...,
) -> Dict[str, object]: ...
def build_hf_zspace_optimizer_polarity_corpus_study_plan(
    *,
    study_dir: str | PathLike[str],
    corpora: Mapping[str, str | PathLike[str]],
    seeds: Sequence[int],
    bridge_args: Sequence[str],
    bridge_script: str | PathLike[str] | None = ...,
    python_executable: str | PathLike[str] | None = ...,
    launch_cwd: str | PathLike[str] | None = ...,
    min_free_disk_gb: float = ...,
) -> Dict[str, object]: ...
def compare_hf_zspace_optimizer_factorized_gain_studies(
    study_dirs: Sequence[str | PathLike[str]],
) -> Dict[str, object]: ...
def compare_hf_zspace_optimizer_polarity_studies(
    studies: Mapping[str, str | PathLike[str]],
) -> Dict[str, object]: ...
def run_hf_zspace_optimizer_factorized_study(
    *,
    study_dir: str | PathLike[str],
    seeds: Sequence[int],
    bridge_args: Sequence[str],
    bridge_script: str | PathLike[str] | None = ...,
    python_executable: str | PathLike[str] | None = ...,
    launch_cwd: str | PathLike[str] | None = ...,
    min_free_disk_gb: float = ...,
    execute: bool = ...,
    retry_failed: bool = ...,
) -> Dict[str, object]: ...
def run_hf_zspace_optimizer_feedback_study(
    *,
    study_dir: str | PathLike[str],
    seeds: Sequence[int],
    bridge_args: Sequence[str],
    feedback_config: Mapping[str, object] | None = ...,
    bridge_script: str | PathLike[str] | None = ...,
    python_executable: str | PathLike[str] | None = ...,
    launch_cwd: str | PathLike[str] | None = ...,
    min_free_disk_gb: float = ...,
    execute: bool = ...,
    retry_failed: bool = ...,
) -> Dict[str, object]: ...
def run_hf_zspace_optimizer_polarity_study(
    *,
    study_dir: str | PathLike[str],
    seeds: Sequence[int],
    bridge_args: Sequence[str],
    bridge_script: str | PathLike[str] | None = ...,
    python_executable: str | PathLike[str] | None = ...,
    launch_cwd: str | PathLike[str] | None = ...,
    min_free_disk_gb: float = ...,
    execute: bool = ...,
    retry_failed: bool = ...,
) -> Dict[str, object]: ...
def run_hf_zspace_optimizer_polarity_corpus_study(
    *,
    study_dir: str | PathLike[str],
    corpora: Mapping[str, str | PathLike[str]],
    seeds: Sequence[int],
    bridge_args: Sequence[str],
    bridge_script: str | PathLike[str] | None = ...,
    python_executable: str | PathLike[str] | None = ...,
    launch_cwd: str | PathLike[str] | None = ...,
    min_free_disk_gb: float = ...,
    execute: bool = ...,
    retry_failed: bool = ...,
) -> Dict[str, object]: ...
def write_hf_zspace_optimizer_factorized_gain_response_report(
    report: Mapping[str, object],
    path: str | PathLike[str],
) -> str: ...
def write_hf_zspace_optimizer_polarity_corpus_report(
    report: Mapping[str, object],
    path: str | PathLike[str],
) -> str: ...
HF_FINETUNE_TRAINER_TRACE_FILENAME: str
HF_FINETUNE_TRAINER_TRACE_LINEAGE_SCHEMA: str
HF_FINETUNE_TRAINER_TRACE_SEGMENT_SCHEMA: str
HF_FINETUNE_REQUIRED_PYTHON_PACKAGES: List[str]
HF_FINETUNE_REQUIRED_RUST_SURFACES: List[Dict[str, str]]
HF_FINETUNE_INPUT_IDENTITY_SCHEMA: str
HF_DATASET_INPUT_IDENTITY_SCHEMA: str
HF_DATASET_MATERIALIZATION_IDENTITY_SCHEMA: str
HF_TOKENIZED_DATASET_IDENTITY_SCHEMA: str
HF_FINETUNE_EXECUTION_IDENTITY_SCHEMA: str
HF_FINETUNE_TRAINING_RECIPE_IDENTITY_SCHEMA: str
HF_FINETUNE_REPLAY_IDENTITY_SCHEMA: str
HF_CAUSAL_LM_ARTIFACT_KINDS: Tuple[str, ...]
HF_CAUSAL_LM_RUNTIME_IDENTITY_SCHEMA: str
HF_ADAPTER_LINEAGE_FILENAME: str
HF_ADAPTER_LINEAGE_SCHEMA: str
HF_ADAPTER_PROMOTION_FILENAME: str
HF_ADAPTER_PROMOTION_SCHEMA: str
HF_ADAPTER_PROMOTION_CHAIN_FILENAME: str
HF_ADAPTER_PROMOTION_CHAIN_SCHEMA: str
HF_ADAPTER_CONTINUATION_POLICY_FILENAME: str
HF_ADAPTER_CONTINUATION_POLICY_SCHEMA: str
HF_ADAPTER_INPUT_IDENTITY_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_CONTROL_DIRNAME: str
HF_ADAPTER_CONTINUATION_EXECUTOR_FILENAME: str
HF_ADAPTER_CONTINUATION_EXECUTOR_LOCK_FILENAME: str
HF_ADAPTER_CONTINUATION_EXECUTOR_LOG_DIRNAME: str
HF_ADAPTER_CONTINUATION_EXECUTOR_LAUNCH_FILENAME: str
HF_ADAPTER_CONTINUATION_EXECUTOR_LAUNCH_LOCK_FILENAME: str
HF_ADAPTER_CONTINUATION_EXECUTOR_LAUNCH_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_LAUNCH_STATUS_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_RESUME_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_RUNTIME_RECONCILE_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_RUNTIME_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISION_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_FILENAME: str
HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_LAUNCH_FILENAME: str
HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_LAUNCH_LOCK_FILENAME: str
HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_LAUNCH_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_LAUNCH_STATUS_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_LOCK_FILENAME: str
HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_STATUS_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_STOP_REQUEST_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_INTERRUPTION_CLAIM_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_GENERATION_PLAN_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_OUTPUT_RESOLUTION_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_QUARANTINE_SUFFIX: str
HF_ADAPTER_CONTINUATION_EXECUTOR_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_STATUS_SCHEMA: str
HF_ADAPTER_CONTINUATION_EXECUTOR_STOP_REQUEST_SCHEMA: str
HF_FINETUNE_MODES: Tuple[str, ...]
HF_FINETUNE_LORA_TARGET_MODULES: Dict[str, Tuple[str, ...]]

class HfCausalLmRuntimeIdentityError(ValueError):
    report: Dict[str, object]

def hf_causal_lm_artifact_report(
    model_name_or_path: str | PathLike[str],
    *,
    artifact_kind: str = ...,
    tokenizer_name_or_path: str | PathLike[str] | None = ...,
) -> Dict[str, object]: ...

def hf_causal_lm_artifact_lines(
    report_or_source: Mapping[str, object] | str | PathLike[str],
    *,
    artifact_kind: str = ...,
    tokenizer_name_or_path: str | PathLike[str] | None = ...,
) -> List[str]: ...

def hf_causal_lm_runtime_identity_report(
    *,
    base_model_source: str | PathLike[str],
    base_model_revision: object | None,
    tokenizer_source: str | PathLike[str] | None,
    tokenizer_source_kind: str | None,
    config: object,
    tokenizer: object,
    expected_identity_id: str | None = ...,
    phase: str = ...,
) -> Dict[str, object]: ...
def hf_causal_lm_runtime_identity_lines(
    report: Mapping[str, object],
) -> List[str]: ...

def hf_finetune_input_identity_report(
    *,
    model_configs: str | PathLike[str] | None = ...,
    train_files: Sequence[str | PathLike[str]] = ...,
    validation_files: Sequence[str | PathLike[str]] = ...,
    inference_distortion_sweep_report: str | PathLike[str] | None = ...,
    inference_distortion_probe: str | PathLike[str] | None = ...,
    resume_from_checkpoint: str | PathLike[str] | None = ...,
    expected_input_id: str | None = ...,
    phase: str = ...,
) -> Dict[str, object]: ...
def hf_finetune_input_identity_lines(
    report_or_inputs: Mapping[str, object] | None = ...,
    **kwargs: object,
) -> List[str]: ...
def hf_dataset_input_identity_report(
    *,
    dataset_name: object,
    dataset_config: object | None = ...,
    requested_revision: object | None = ...,
    train_split: object | None = ...,
    eval_split: object | None = ...,
    text_column: object | None = ...,
    local_files: bool = ...,
    expected_identity_id: str | None = ...,
    phase: str = ...,
    hub_api: Any | None = ...,
) -> Dict[str, object]: ...
def hf_dataset_input_identity_lines(
    report: Mapping[str, object],
) -> List[str]: ...
def hf_dataset_materialization_identity_report(
    *,
    train_dataset: object,
    eval_dataset: object | None = ...,
    text_column: object = ...,
    expected_identity_id: str | None = ...,
    phase: str = ...,
) -> Dict[str, object]: ...
def hf_dataset_materialization_identity_lines(
    report: Mapping[str, object],
) -> List[str]: ...
def hf_tokenized_dataset_identity_report(
    *,
    train_dataset: object,
    eval_dataset: object | None = ...,
    expected_identity_id: str | None = ...,
    phase: str = ...,
) -> Dict[str, object]: ...
def hf_tokenized_dataset_identity_lines(
    report: Mapping[str, object],
) -> List[str]: ...
def hf_finetune_execution_identity_report(
    runtime_preflight: Mapping[str, object],
    *,
    spiraltorch_version: object | None = ...,
    spiraltorch_build_fingerprint: object | None = ...,
    spiraltorch_distribution_fingerprint: Mapping[str, object] | None = ...,
    torch_module: Any = ...,
    environment: Mapping[str, str] | None = ...,
    python_runtime: Mapping[str, object] | None = ...,
    torch_capabilities: Mapping[str, object] | None = ...,
    distribution_fingerprints: Mapping[str, object] | None = ...,
    expected_identity_id: str | None = ...,
    phase: str = ...,
) -> Dict[str, object]: ...
def hf_finetune_execution_identity_lines(
    report: Mapping[str, object],
) -> List[str]: ...
def hf_finetune_training_recipe_identity_report(
    training_arguments: object,
    *,
    model_prepare_report: Mapping[str, object],
    model_dtype_report: Mapping[str, object] | None = ...,
    checkpoint_resume_report: Mapping[str, object] | None = ...,
    trainer_contract: Mapping[str, object] | None = ...,
    expected_identity_id: str | None = ...,
    phase: str = ...,
) -> Dict[str, object]: ...
def hf_finetune_training_recipe_identity_lines(
    report: Mapping[str, object],
) -> List[str]: ...
def hf_finetune_replay_identity_report(
    *,
    adapter_input_identity: Mapping[str, object] | None = ...,
    adapter_input_required: bool = ...,
    training_input_identity: Mapping[str, object] | None,
    dataset_input_identity: Mapping[str, object] | None,
    dataset_materialization_identity: Mapping[str, object] | None,
    tokenized_dataset_identity: Mapping[str, object] | None,
    model_runtime_identity: Mapping[str, object] | None,
    execution_identity: Mapping[str, object] | None,
    training_recipe_identity: Mapping[str, object] | None,
    expected_identity_id: str | None = ...,
    phase: str = ...,
) -> Dict[str, object]: ...
def hf_finetune_replay_identity_lines(
    report: Mapping[str, object],
) -> List[str]: ...
HF_ADAPTER_CONFIG_CANONICALIZATION_SCHEMA: str
def canonicalize_hf_adapter_configs(
    adapter_root: str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_fingerprint(adapter: str | PathLike[str]) -> Dict[str, object]: ...
def hf_adapter_input_identity_report(
    adapter: str | PathLike[str],
    *,
    expected_adapter_id: str | None = ...,
    expected_lineage_depth: int | None = ...,
    expected_root_adapter_id: str | None = ...,
    require_lineage: bool = ...,
    phase: str = ...,
) -> Dict[str, object]: ...
def hf_adapter_input_identity_lines(
    report_or_adapter: Mapping[str, object] | str | PathLike[str],
    **kwargs: object,
) -> List[str]: ...
def hf_adapter_lineage_report(
    adapter: str | PathLike[str],
    *,
    parent_adapter: str | PathLike[str] | None = ...,
    run_card: Mapping[str, object] | str | PathLike[str] | None = ...,
    run_card_path: str | PathLike[str] | None = ...,
) -> Dict[str, object]: ...
def write_hf_adapter_lineage(
    adapter_or_report: str | PathLike[str] | Mapping[str, object],
    *,
    parent_adapter: str | PathLike[str] | None = ...,
    run_card: Mapping[str, object] | str | PathLike[str] | None = ...,
    run_card_path: str | PathLike[str] | None = ...,
    out: str | PathLike[str] | None = ...,
) -> Dict[str, object]: ...
def load_hf_adapter_lineage(value: str | PathLike[str]) -> Dict[str, object]: ...
def hf_adapter_lineage_lines(
    report_or_adapter: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def hf_adapter_promotion_report(
    candidate_adapter: str | PathLike[str],
    run_card: Mapping[str, object] | str | PathLike[str],
    *,
    parent_adapter: str | PathLike[str] | None = ...,
    max_eval_loss_regression: float = ...,
    require_eval: bool = ...,
    require_generation_changed: bool = ...,
    require_weight_change: bool = ...,
    require_artifact_probe: bool = ...,
) -> Dict[str, object]: ...
def write_hf_adapter_promotion(
    report_or_candidate: Mapping[str, object] | str | PathLike[str],
    run_card: Mapping[str, object] | str | PathLike[str] | None = ...,
    *,
    parent_adapter: str | PathLike[str] | None = ...,
    max_eval_loss_regression: float = ...,
    require_eval: bool = ...,
    require_generation_changed: bool = ...,
    require_weight_change: bool = ...,
    require_artifact_probe: bool = ...,
    out: str | PathLike[str] | None = ...,
) -> Dict[str, object]: ...
def load_hf_adapter_promotion(value: str | PathLike[str]) -> Dict[str, object]: ...
def hf_adapter_promotion_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def hf_adapter_promotion_chain_report(
    sources: str | PathLike[str] | Sequence[str | PathLike[str]],
    *,
    recursive: bool = ...,
    allow_inferred_roots: bool = ...,
    select_adapter_id: str | None = ...,
    command_artifacts: Sequence[
        Mapping[str, object] | str | PathLike[str]
    ] | None = ...,
    max_lineage_depth: int | None = ...,
    target_eval_loss: float | None = ...,
    min_eval_improvement: float | None = ...,
    max_distortion_pressure_index: float | None = ...,
    min_desire_stability: float | None = ...,
    max_psi_total: float | None = ...,
    plateau_patience: int = ...,
) -> Dict[str, object]: ...
def write_hf_adapter_promotion_chain(
    report_or_sources: Mapping[str, object]
    | str
    | PathLike[str]
    | Sequence[str | PathLike[str]],
    out: str | PathLike[str],
    *,
    recursive: bool = ...,
    allow_inferred_roots: bool = ...,
    select_adapter_id: str | None = ...,
    command_artifacts: Sequence[
        Mapping[str, object] | str | PathLike[str]
    ] | None = ...,
    max_lineage_depth: int | None = ...,
    target_eval_loss: float | None = ...,
    min_eval_improvement: float | None = ...,
    max_distortion_pressure_index: float | None = ...,
    min_desire_stability: float | None = ...,
    max_psi_total: float | None = ...,
    plateau_patience: int = ...,
) -> Dict[str, object]: ...
def hf_adapter_promotion_chain_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def load_hf_adapter_promotion_chain(
    value: str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_policy_report(
    chain_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    max_lineage_depth: int | None = ...,
    target_eval_loss: float | None = ...,
    min_eval_improvement: float | None = ...,
    max_distortion_pressure_index: float | None = ...,
    min_desire_stability: float | None = ...,
    max_psi_total: float | None = ...,
    plateau_patience: int = ...,
) -> Dict[str, object]: ...
def write_hf_adapter_continuation_policy(
    report_or_chain: Mapping[str, object] | str | PathLike[str],
    out: str | PathLike[str],
    *,
    max_lineage_depth: int | None = ...,
    target_eval_loss: float | None = ...,
    min_eval_improvement: float | None = ...,
    max_distortion_pressure_index: float | None = ...,
    min_desire_stability: float | None = ...,
    max_psi_total: float | None = ...,
    plateau_patience: int = ...,
) -> Dict[str, object]: ...
def load_hf_adapter_continuation_policy(
    value: str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_policy_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def run_hf_adapter_continuation_executor(
    sources: str | PathLike[str] | Sequence[str | PathLike[str]],
    *,
    output_root: str | PathLike[str],
    state_path: str | PathLike[str] | None = ...,
    run: bool = ...,
    max_generations: int = ...,
    expected_plan_id: str | None = ...,
    require_pending_plan: bool = ...,
    retry_interrupted: bool = ...,
    recursive: bool = ...,
    allow_inferred_roots: bool = ...,
    select_adapter_id: str | None = ...,
    command_artifacts: Sequence[
        Mapping[str, object] | str | PathLike[str]
    ] | None = ...,
    max_lineage_depth: int | None = ...,
    target_eval_loss: float | None = ...,
    min_eval_improvement: float | None = ...,
    max_distortion_pressure_index: float | None = ...,
    min_desire_stability: float | None = ...,
    max_psi_total: float | None = ...,
    plateau_patience: int = ...,
    output_prefix: str = ...,
    max_steps: int | None = ...,
    max_steps_multiplier: float | None = ...,
    max_train_samples: int | None = ...,
    max_train_samples_multiplier: float | None = ...,
    max_eval_samples: int | None = ...,
    max_eval_blocks: int | None = ...,
    streaming_validation_samples: int | None = ...,
    command_runner: Callable[[Sequence[str]], object] | None = ...,
    command_cwd: str | PathLike[str] | None = ...,
    command_env: Mapping[str, str] | None = ...,
    tee_output: bool = ...,
) -> Dict[str, object]: ...
def load_hf_adapter_continuation_executor(
    value: str | PathLike[str],
) -> Dict[str, object]: ...
def request_hf_adapter_continuation_executor_stop(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    reason: str = ...,
) -> Dict[str, object]: ...
def load_hf_adapter_continuation_executor_stop_request(
    value: str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_stop_request_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def hf_adapter_continuation_executor_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def hf_adapter_continuation_executor_generation_plan_report(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    candidate: bool = ...,
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_generation_plan_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    candidate: bool = ...,
) -> List[str]: ...
def hf_adapter_continuation_executor_status_report(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_status_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def launch_hf_adapter_continuation_executor(
    executor_argv: Sequence[str],
    *,
    output_root: str | PathLike[str],
    executor_state_path: str | PathLike[str],
    launch_state_path: str | PathLike[str] | None = ...,
    command_cwd: str | PathLike[str] | None = ...,
    handoff_timeout_seconds: float = ...,
) -> Dict[str, object]: ...
def load_hf_adapter_continuation_executor_launch(
    value: str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_launch_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def hf_adapter_continuation_executor_launch_status_report(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_launch_status_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def hf_adapter_continuation_executor_resume_report(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> Dict[str, object]: ...
def resume_hf_adapter_continuation_executor(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    handoff_timeout_seconds: float = ...,
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_resume_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def hf_adapter_continuation_executor_runtime_report(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    supervisor_state_path: str | PathLike[str] | None = ...,
    supervisor_launch_state_path: str | PathLike[str] | None = ...,
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_runtime_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    supervisor_state_path: str | PathLike[str] | None = ...,
    supervisor_launch_state_path: str | PathLike[str] | None = ...,
) -> List[str]: ...
def reconcile_hf_adapter_continuation_executor_runtime(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    restart_supervisor: bool = ...,
    max_resumes: int = ...,
    poll_interval_seconds: float = ...,
    timeout_seconds: float = ...,
    handoff_timeout_seconds: float = ...,
    launch_handoff_timeout_seconds: float = ...,
    supervisor_state_path: str | PathLike[str] | None = ...,
    supervisor_launch_state_path: str | PathLike[str] | None = ...,
    command_cwd: str | PathLike[str] | None = ...,
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_runtime_reconcile_lines(
    report: Mapping[str, object],
) -> List[str]: ...
def hf_adapter_continuation_executor_supervision_report(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_supervision_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def supervise_hf_adapter_continuation_executor(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    max_resumes: int = ...,
    poll_interval_seconds: float = ...,
    timeout_seconds: float = ...,
    handoff_timeout_seconds: float = ...,
    supervisor_state_path: str | PathLike[str] | None = ...,
) -> Dict[str, object]: ...
def load_hf_adapter_continuation_executor_supervisor(
    value: str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_supervisor_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def hf_adapter_continuation_executor_supervisor_status_report(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_supervisor_status_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def request_hf_adapter_continuation_executor_supervisor_stop(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    reason: str = ...,
) -> Dict[str, object]: ...
def load_hf_adapter_continuation_executor_supervisor_stop_request(
    value: str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_supervisor_stop_request_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def launch_hf_adapter_continuation_executor_supervisor(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    max_resumes: int = ...,
    poll_interval_seconds: float = ...,
    timeout_seconds: float = ...,
    handoff_timeout_seconds: float = ...,
    launch_handoff_timeout_seconds: float = ...,
    supervisor_state_path: str | PathLike[str] | None = ...,
    supervisor_launch_state_path: str | PathLike[str] | None = ...,
    command_cwd: str | PathLike[str] | None = ...,
) -> Dict[str, object]: ...
def load_hf_adapter_continuation_executor_supervisor_launch(
    value: str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_supervisor_launch_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def hf_adapter_continuation_executor_supervisor_launch_status_report(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_supervisor_launch_status_lines(
    report_or_path: Mapping[str, object] | str | PathLike[str],
) -> List[str]: ...
def hf_adapter_continuation_executor_output_quarantine_report(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    attempt_id: str,
) -> Dict[str, object]: ...
def quarantine_hf_adapter_continuation_executor_output(
    report_or_path: Mapping[str, object] | str | PathLike[str],
    *,
    attempt_id: str,
    reason: str = ...,
) -> Dict[str, object]: ...
def hf_adapter_continuation_executor_output_resolution_lines(
    report: Mapping[str, object],
) -> List[str]: ...

def load_hf_causal_lm_artifact(
    model_name_or_path: str | PathLike[str],
    *,
    tokenizer_name_or_path: str | PathLike[str] | None = ...,
    artifact_kind: str = ...,
    load_model: bool = ...,
    load_tokenizer: bool = ...,
    is_trainable: bool = ...,
    merge_adapter: bool = ...,
    safe_merge: bool = ...,
    transformers_module: Any = ...,
    peft_module: Any = ...,
    loader_kwargs: Mapping[str, object] | None = ...,
    config_kwargs: Mapping[str, object] | None = ...,
    tokenizer_kwargs: Mapping[str, object] | None = ...,
    model_kwargs: Mapping[str, object] | None = ...,
    adapter_kwargs: Mapping[str, object] | None = ...,
    expected_runtime_identity_id: str | None = ...,
) -> Tuple[Any, Any, Any, Dict[str, object]]: ...

def export_hf_merged_causal_lm(
    adapter_name_or_path: str | PathLike[str],
    output_dir: str | PathLike[str],
    *,
    tokenizer_name_or_path: str | PathLike[str] | None = ...,
    safe_merge: bool = ...,
    safe_serialization: bool = ...,
    transformers_module: Any = ...,
    peft_module: Any = ...,
    loader_kwargs: Mapping[str, object] | None = ...,
    config_kwargs: Mapping[str, object] | None = ...,
    tokenizer_kwargs: Mapping[str, object] | None = ...,
    model_kwargs: Mapping[str, object] | None = ...,
    adapter_kwargs: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...

def hf_merged_causal_lm_export_lines(
    report: Mapping[str, object],
) -> List[str]: ...

def summarize_hf_causal_lm_artifact(
    report: Mapping[str, object],
) -> Dict[str, object]: ...

def hf_finetune_adapter_config(
    *,
    mode: str = ...,
    model_family: str | None = ...,
    rank: int = ...,
    alpha: float = ...,
    dropout: float = ...,
    bias: str = ...,
    target_modules: object = ...,
    modules_to_save: object = ...,
    use_rslora: bool = ...,
    gradient_checkpointing: bool = ...,
) -> Dict[str, object]: ...

def hf_finetune_lora_target_report(
    model: Any,
    *,
    model_family: str | None = ...,
    target_modules: object = ...,
) -> Dict[str, object]: ...

def hf_finetune_parameter_report(model: Any) -> Dict[str, object]: ...

def prepare_hf_finetune_model(
    model: Any,
    *,
    mode: str = ...,
    model_family: str | None = ...,
    rank: int = ...,
    alpha: float = ...,
    dropout: float = ...,
    bias: str = ...,
    target_modules: object = ...,
    modules_to_save: object = ...,
    use_rslora: bool = ...,
    gradient_checkpointing: bool = ...,
    preloaded_adapter: bool = ...,
    peft_module: Any = ...,
) -> Tuple[Any, Dict[str, object]]: ...

load_hf_finetune_model_configs: Callable[..., Dict[str, Any]]
hf_finetune_model_profiles: Callable[..., Dict[str, Dict[str, Any]]]
resolve_hf_finetune_model_profile: Callable[..., Dict[str, Any]]
hf_finetune_model_profile_catalog: Callable[..., Dict[str, Any]]
hf_finetune_model_profile_catalog_lines: Callable[..., List[str]]
hf_finetune_model_profile_cli_args: Callable[..., List[str]]
hf_finetune_model_profile_launch_bundle_lines: Callable[..., List[str]]
hf_finetune_model_profile_launch_bundle_report: Callable[..., Dict[str, Any]]
hf_finetune_model_profile_launch_bundle_report_lines: Callable[..., List[str]]
hf_finetune_model_profile_launch_plan: Callable[..., Dict[str, Any]]
hf_finetune_model_profile_launch_plan_lines: Callable[..., List[str]]
hf_finetune_model_profile_launch_script: Callable[..., str]
hf_finetune_model_profile_lines: Callable[..., List[str]]
hf_finetune_model_profile_preflight_report: Callable[..., Dict[str, Any]]
hf_finetune_model_profile_preflight_lines: Callable[..., List[str]]
hf_finetune_model_profile_runtime_contract_from_artifact: Callable[..., Dict[str, Any]]
hf_finetune_model_profile_runtime_contract: Callable[..., Dict[str, Any]]
hf_finetune_model_profile_runtime_contract_lines: Callable[..., List[str]]
load_hf_finetune_model_profile_launch_plan: Callable[..., Dict[str, Any]]
write_hf_finetune_model_profile_launch_bundle: Callable[..., Dict[str, Any]]
write_hf_finetune_model_profile_launch_plan: Callable[..., Dict[str, Any]]
write_hf_finetune_model_profile_launch_script: Callable[..., Dict[str, Any]]
hf_finetune_rust_dependency_report: Callable[..., Dict[str, Any]]
hf_finetune_corpus_file_report: Callable[..., Dict[str, Any]]
hf_finetune_corpus_scan_report: Callable[..., Dict[str, Any]]
hf_finetune_checkpoint_resume_report: Callable[..., Dict[str, Any]]
hf_finetune_checkpoint_resume_lines: Callable[..., List[str]]
hf_finetune_dataset_fit_report: Callable[..., Dict[str, Any]]
hf_finetune_generation_report: Callable[..., Dict[str, Any]]
hf_finetune_inference_distortion_handoff_report: Callable[..., Dict[str, Any]]
hf_finetune_inference_distortion_runtime_plan: Callable[..., Dict[str, Any]]
hf_finetune_inference_distortion_runtime_adapter: Callable[..., Callable[..., Any]]
hf_finetune_inference_distortion_request_kwargs: Callable[..., Dict[str, Any]]
hf_finetune_inference_distortion_handoff_lines: Callable[..., List[str]]
hf_finetune_milestone_report: Callable[..., Dict[str, Any]]
hf_finetune_milestone_lines: Callable[..., List[str]]
hf_finetune_preflight_report: Callable[..., Dict[str, Any]]
hf_finetune_summary_lines: Callable[..., List[str]]
hf_finetune_zspace_probe: Callable[..., Dict[str, Any]]
hf_finetune_training_telemetry_frame: Callable[..., Dict[str, Any]]
hf_finetune_eval_report: Callable[..., Dict[str, Any]]
hf_finetune_trainer_trace_event: Callable[..., Dict[str, Any]]
write_hf_finetune_trainer_trace_event: Callable[..., None]
load_hf_finetune_trainer_trace: Callable[..., List[Dict[str, Any]]]
summarize_hf_finetune_trainer_trace: Callable[..., Dict[str, Any]]
load_hf_finetune_run_card: Callable[..., Dict[str, Any]]
load_hf_finetune_sweep_report: Callable[..., Dict[str, Any]]
hf_finetune_disk_headroom_plan: Callable[..., Dict[str, Any]]
hf_gpt2_finetune_disk_headroom_plan: Callable[..., Dict[str, Any]]
hf_gpt2_finetune_checkpoint_resume_report: Callable[..., Dict[str, Any]]
hf_gpt2_finetune_checkpoint_resume_lines: Callable[..., List[str]]
hf_finetune_scale_up_command: Callable[..., Dict[str, Any]]
hf_finetune_scale_up_preflight_report: Callable[..., Dict[str, Any]]
hf_finetune_scale_up_preflight_lines: Callable[..., List[str]]
summarize_hf_finetune_run_card: Callable[..., Dict[str, Any]]
summarize_hf_finetune_sweep_report: Callable[..., Dict[str, Any]]
summarize_hf_finetune_sweep_report_lines: Callable[..., List[str]]
hf_finetune_generation_curve_report: Callable[..., Dict[str, Any]]
hf_finetune_generation_curve_lines: Callable[..., List[str]]
compare_hf_finetune_run_cards: Callable[..., Dict[str, Any]]
hf_finetune_trainer_trace_callback: Callable[..., Any]
write_hf_finetune_run_card: Callable[..., str]

def hf_gpt2_finetune_rust_dependency_report() -> Dict[str, Any]: ...

def hf_gpt2_finetune_corpus_file_report(
    *,
    train_files: object = ...,
    validation_files: object = ...,
    dataset_format: str = ...,
    text_column: str = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_corpus_scan_report(
    *,
    train_files: object = ...,
    validation_files: object = ...,
    dataset_format: str = ...,
    text_column: str = ...,
    sample_line_limit: int = ...,
    sample_preview_chars: int = ...,
    max_bytes_per_file: int | None = ...,
    encoding: str = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_dataset_fit_report(
    *,
    raw_train_rows: object = ...,
    raw_eval_rows: object = ...,
    tokenized_train_rows: object = ...,
    tokenized_eval_rows: object = ...,
    block_size: int = ...,
    min_train_blocks: int = ...,
    min_eval_blocks: int = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_eval_report(
    *,
    stage: str,
    metrics: Mapping[str, object] | None = ...,
    loss_key: str = ...,
    error: object = ...,
    skipped_reason: object = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_generation_report(
    *,
    stage: str,
    prompt: object = ...,
    generated_text: object = ...,
    generated_continuation_text: object = ...,
    input_token_count: object = ...,
    output_token_count: object = ...,
    max_new_tokens: int = ...,
    generation_method: object = ...,
    fallback_error: object = ...,
    generation_control: Mapping[str, object] | None = ...,
    error: object = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_generation_curve_report(
    card_or_path: str | PathLike[str] | Mapping[str, object],
    sweeps_or_paths: Mapping[str, object] | Sequence[object],
    *,
    labels: Sequence[str] | None = ...,
    step_by_model: Mapping[str, object] | None = ...,
    top_n: int = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_generation_curve_lines(
    report_or_card: str | PathLike[str] | Mapping[str, object],
    sweeps_or_paths: Mapping[str, object] | Sequence[object] | None = ...,
    *,
    labels: Sequence[str] | None = ...,
    step_by_model: Mapping[str, object] | None = ...,
    top_n: int = ...,
) -> List[str]: ...

def hf_gpt2_finetune_inference_distortion_handoff_report(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    top_n: int = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_inference_distortion_handoff_lines(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    top_n: int = ...,
    replay_arg_limit: int = ...,
) -> List[str]: ...

def hf_gpt2_finetune_inference_distortion_runtime_plan(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    top_n: int = ...,
    request: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_inference_distortion_runtime_adapter(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    top_n: int = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_inference_distortion_request_kwargs(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    top_n: int = ...,
    request: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_milestone_report(
    status_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    milestone_step: int,
    label: str | None = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_milestone_lines(
    report_or_status: str | PathLike[str] | Mapping[str, object],
    *,
    milestone_step: int | None = ...,
    label: str | None = ...,
) -> List[str]: ...

class ZSpaceActivationProbeHook:
    def __init__(
        self,
        *,
        module_names: Sequence[str] | None = ...,
        name_contains: Sequence[str] | None = ...,
        max_modules: int = ...,
        record_limit: int = ...,
        intervention_scale: float = ...,
        intervention_bias: float = ...,
        origin: str = ...,
    ) -> None: ...
    def attach(self, model: Any) -> ZSpaceActivationProbeHook: ...
    def close(self) -> None: ...
    def reset_report(self) -> None: ...
    def report(self, *, limit: int | None = ...) -> Dict[str, object]: ...

class ZSpaceRepressionLogitsProcessor:
    def __init__(
        self,
        *,
        top_k: int = ...,
        curvature: float = ...,
        temperature: float = ...,
        entropy_target: float | None = ...,
        entropy_tolerance: float = ...,
        entropy_gain: float = ...,
        min_temperature: float | None = ...,
        max_temperature: float | None = ...,
        repression_window: int = ...,
        repression_strength: float = ...,
        last_token_repression: float = ...,
        ngram_size: int = ...,
        ngram_window: int = ...,
        ngram_repression_strength: float = ...,
        ngram_decay: float = ...,
        mask_non_top_k: bool = ...,
        use_native_zspace: bool = ...,
    ) -> None: ...
    def __call__(self, input_ids: Any, scores: Any) -> Any: ...
    def report(self, *, limit: int | None = ...) -> Dict[str, object]: ...
    def reset_report(self) -> None: ...

def build_zspace_repression_logits_processor(
    **kwargs: object,
) -> ZSpaceRepressionLogitsProcessor: ...

def build_zspace_softmax_logits_processor(
    **kwargs: object,
) -> ZSpaceRepressionLogitsProcessor: ...

def build_zspace_activation_probe_hook(
    **kwargs: object,
) -> ZSpaceActivationProbeHook: ...

def hf_causal_lm_artifact_probe_report(
    model_name_or_path: str | PathLike[str],
    *,
    tokenizer_name_or_path: str | PathLike[str] | None = ...,
    artifact_kind: str = ...,
    prompt: str = ...,
    max_new_tokens: int = ...,
    do_sample: bool = ...,
    temperature: float = ...,
    top_k: int | None = ...,
    device: str | None = ...,
    merge_adapter: bool = ...,
    local_files_only: bool = ...,
    trust_remote_code: bool = ...,
    transformers_module: Any = ...,
    peft_module: Any = ...,
    torch_module: Any = ...,
    loader_kwargs: Mapping[str, object] | None = ...,
    config_kwargs: Mapping[str, object] | None = ...,
    tokenizer_kwargs: Mapping[str, object] | None = ...,
    model_kwargs: Mapping[str, object] | None = ...,
    adapter_kwargs: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...

def hf_causal_lm_artifact_subprocess_probe_report(
    model_name_or_path: str | PathLike[str],
    *,
    tokenizer_name_or_path: str | PathLike[str] | None = ...,
    artifact_kind: str = ...,
    prompt: str = ...,
    max_new_tokens: int = ...,
    do_sample: bool = ...,
    temperature: float = ...,
    top_k: int | None = ...,
    device: str | None = ...,
    merge_adapter: bool = ...,
    local_files_only: bool = ...,
    trust_remote_code: bool = ...,
    revision: str | None = ...,
    timeout_seconds: float = ...,
    python_executable: str | PathLike[str] | None = ...,
    report_path: str | PathLike[str] | None = ...,
    environment: Mapping[str, str] | None = ...,
) -> Dict[str, object]: ...

def hf_causal_lm_artifact_probe_lines(
    report: Mapping[str, object],
) -> List[str]: ...

def hf_generation_batch_size_compat(model: Any) -> ContextManager[bool]: ...

def compare_zspace_inference_distortion_probes(
    probes: (
        Mapping[str, str | PathLike[str] | Mapping[str, object]]
        | Sequence[str | PathLike[str] | Mapping[str, object]]
        | str
        | PathLike[str]
        | Mapping[str, object]
    ),
    *,
    labels: Sequence[str] | None = ...,
    top_n: int = ...,
    preview_chars: int = ...,
) -> Dict[str, object]: ...

def zspace_inference_distortion_sweep_report_from_probes(
    probes: (
        Mapping[str, str | PathLike[str] | Mapping[str, object]]
        | Sequence[str | PathLike[str] | Mapping[str, object]]
        | str
        | PathLike[str]
        | Mapping[str, object]
    ),
    *,
    labels: Sequence[str] | None = ...,
    prompt: object | None = ...,
    runtime: Mapping[str, object] | None = ...,
    report_path: str | PathLike[str] | None = ...,
    top_n: int = ...,
    preview_chars: int = ...,
) -> Dict[str, object]: ...

def zspace_inference_distortion_processor_kwargs(
    adapter_or_config: Mapping[str, object] | None = ...,
    **overrides: object,
) -> Dict[str, object]: ...

def zspace_inference_distortion_probe_cli_args(
    config: Mapping[str, object] | None,
) -> List[str]: ...

def zspace_inference_distortion_geometry_probe(
    adapter_or_config: Mapping[str, object] | None,
    *,
    zspace_eval_with_derivative_stable: object | None = ...,
) -> Dict[str, object]: ...

def zspace_inference_distortion_probe_report(
    *,
    prompt: object,
    config: Mapping[str, object] | None = ...,
    runtime: Mapping[str, object] | None = ...,
    adapter: Mapping[str, object] | None = ...,
    local_hf: Mapping[str, object] | None = ...,
    api: Mapping[str, object] | None = ...,
    handoff: Mapping[str, object] | None = ...,
    name: object | None = ...,
    probe_path: str | PathLike[str] | None = ...,
    runtime_preflight: Mapping[str, object] | None = ...,
    geometry_probe: Mapping[str, object] | None = ...,
    include_summary: bool = ...,
) -> Dict[str, object]: ...

def zspace_inference_distortion_runtime_plan(
    *,
    model_configs: Mapping[str, object] | str | PathLike[str] | None = ...,
    model_profile: str | None = ...,
    local_model: str | PathLike[str] | None = ...,
    tokenizer_name: str | PathLike[str] | None = ...,
    allow_remote: bool = ...,
    trust_remote_code: bool = ...,
    max_new_tokens: int | None = ...,
    activation_module_name: Sequence[object] | object | None = ...,
    activation_name_contains: Sequence[object] | object | None = ...,
    api_provider: str | None = ...,
    api_model: str | None = ...,
    api_max_tokens: int = ...,
    api_reasoning_effort: str | None = ...,
    api_text_verbosity: str | None = ...,
) -> Dict[str, object]: ...

def zspace_inference_distortion_runtime_cli_args(
    runtime: Mapping[str, object] | None,
    *,
    sweep: bool = ...,
) -> List[str]: ...

def zspace_inference_distortion_runtime_preflight(
    runtime: Mapping[str, object] | None = ...,
    *,
    backends: Sequence[object] | object | None = ...,
    required_ready_backends: Sequence[object] | object | None = ...,
    describe_runtime_devices: object | None = ...,
    device_kwargs: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...

def zspace_inference_distortion_sweep_cli_args(
    config: Mapping[str, object] | None,
) -> List[str]: ...

def zspace_generation_control_processor_kwargs(
    config: Mapping[str, object] | None,
) -> Dict[str, object]: ...

def zspace_generation_control_profile_config(
    model_configs: Mapping[str, object] | str | PathLike[str] | None = ...,
    *,
    model_profile: str | None = ...,
) -> Dict[str, object]: ...

def zspace_generation_control_sweep_cli_args(
    config: Mapping[str, object] | None,
) -> List[str]: ...

def zspace_generation_control_bridge_cli_args(
    config: Mapping[str, object] | None,
    *,
    include_enable_flag: bool = ...,
) -> List[str]: ...

class ZSpaceCheckpointPromptSpec:
    label: str
    prompt: str
    filename_prefix: str
    def __init__(
        self,
        label: str,
        prompt: str,
        filename_prefix: str,
    ) -> None: ...

class ZSpaceCheckpointSweepJob:
    checkpoint: str
    prompt: ZSpaceCheckpointPromptSpec
    model_dir: PathLike[str]
    out: PathLike[str]
    label: str
    def __init__(
        self,
        checkpoint: str,
        prompt: ZSpaceCheckpointPromptSpec,
        model_dir: str | PathLike[str],
        out: str | PathLike[str],
        label: str,
    ) -> None: ...

def default_zspace_checkpoint_generation_prompts() -> List[ZSpaceCheckpointPromptSpec]: ...

def zspace_checkpoint_generation_control_jobs(
    *,
    run_dir: str | PathLike[str],
    checkpoint: Sequence[str] | str,
    prompt: Sequence[Any] | Any | None = ...,
    label_prefix: str = ...,
) -> List[ZSpaceCheckpointSweepJob]: ...

def zspace_checkpoint_generation_control_sweep_command(
    job: ZSpaceCheckpointSweepJob,
    *,
    python: str | None = ...,
    sweep_script: str | PathLike[str] | None = ...,
    allow_remote: bool = ...,
    trust_remote_code: bool = ...,
    max_new_tokens: int | None = ...,
    do_sample: bool = ...,
    sample_temperature: float | None = ...,
    sample_top_k: int | None = ...,
) -> List[str]: ...

def zspace_checkpoint_generation_control_compare_output_paths(
    *,
    run_dir: str | PathLike[str],
    checkpoint: Sequence[str] | str,
    compare_out: str | PathLike[str] | None = ...,
    compare_lines_out: str | PathLike[str] | None = ...,
) -> Tuple[PathLike[str], PathLike[str]]: ...

def zspace_checkpoint_generation_control_compare_command(
    jobs: Sequence[ZSpaceCheckpointSweepJob],
    *,
    run_dir: str | PathLike[str],
    checkpoint: Sequence[str] | str,
    python: str | None = ...,
    compare_script: str | PathLike[str] | None = ...,
    compare_with_sweep: Sequence[str | PathLike[str]] | str | PathLike[str] | None = ...,
    compare_with_label: Sequence[str] | str | None = ...,
    compare_out: str | PathLike[str] | None = ...,
    compare_lines_out: str | PathLike[str] | None = ...,
    top_n: int = ...,
) -> List[str]: ...

def zspace_checkpoint_generation_control_curve_command(
    jobs: Sequence[ZSpaceCheckpointSweepJob],
    *,
    run_dir: str | PathLike[str],
    checkpoint: Sequence[str] | str,
    python: str | None = ...,
    curve_script: str | PathLike[str] | None = ...,
    curve_out: str | PathLike[str] | None = ...,
    curve_lines_out: str | PathLike[str] | None = ...,
    curve_run_card: str | PathLike[str] | None = ...,
    curve_trainer_trace_jsonl: str | PathLike[str] | None = ...,
    curve_model_name: str | None = ...,
    curve_dataset_name: str | None = ...,
    curve_dataset_config: str | None = ...,
    compare_with_sweep: Sequence[str | PathLike[str]] | str | PathLike[str] | None = ...,
    compare_with_label: Sequence[str] | str | None = ...,
    top_n: int = ...,
) -> List[str]: ...

def zspace_checkpoint_generation_control_report(
    *,
    run_dir: str | PathLike[str],
    checkpoint: Sequence[str] | str,
    prompt: Sequence[Any] | Any | None = ...,
    label_prefix: str = ...,
    python: str | None = ...,
    sweep_script: str | PathLike[str] | None = ...,
    compare_script: str | PathLike[str] | None = ...,
    curve_script: str | PathLike[str] | None = ...,
    allow_remote: bool = ...,
    trust_remote_code: bool = ...,
    max_new_tokens: int | None = ...,
    do_sample: bool = ...,
    sample_temperature: float | None = ...,
    sample_top_k: int | None = ...,
    overwrite: bool = ...,
    no_compare: bool = ...,
    top_n: int = ...,
    compare_out: str | PathLike[str] | None = ...,
    compare_lines_out: str | PathLike[str] | None = ...,
    curve_out: str | PathLike[str] | None = ...,
    curve_lines_out: str | PathLike[str] | None = ...,
    curve_run_card: str | PathLike[str] | None = ...,
    curve_trainer_trace_jsonl: str | PathLike[str] | None = ...,
    curve_model_name: str | None = ...,
    curve_dataset_name: str | None = ...,
    curve_dataset_config: str | None = ...,
    compare_with_sweep: Sequence[str | PathLike[str]] | str | PathLike[str] | None = ...,
    compare_with_label: Sequence[str] | str | None = ...,
    run_card: str | PathLike[str] | None = ...,
    dry_run: bool = ...,
    wait_for_process_pid_file: str | PathLike[str] | None = ...,
    wait: bool = ...,
    ready_file: Sequence[str] | str | None = ...,
    no_ready_file_check: bool = ...,
    poll_seconds: float = ...,
    process_poll_seconds: float | None = ...,
    timeout_seconds: float = ...,
    process_timeout_seconds: float = ...,
    runner: Callable[[Sequence[str]], Any] | None = ...,
) -> Dict[str, Any]: ...

def load_zspace_inference_distortion_probe(
    path: str | PathLike[str],
) -> Dict[str, object]: ...

def load_zspace_inference_distortion_sweep(
    path: str | PathLike[str],
) -> Dict[str, object]: ...

def summarize_zspace_inference_distortion_probe(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    preview_chars: int = ...,
) -> Dict[str, object]: ...

def summarize_zspace_inference_distortion_probe_lines(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    preview_chars: int = ...,
) -> List[str]: ...

def summarize_zspace_inference_distortion_probe_comparison_lines(
    comparison_or_probes: (
        Mapping[str, object]
        | Mapping[str, str | PathLike[str] | Mapping[str, object]]
        | Sequence[str | PathLike[str] | Mapping[str, object]]
        | str
        | PathLike[str]
    ),
    *,
    top_n: int = ...,
    preview_chars: int = ...,
) -> List[str]: ...

def summarize_zspace_inference_distortion_sweep(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    top_n: int = ...,
    preview_chars: int = ...,
) -> Dict[str, object]: ...

def summarize_zspace_inference_distortion_sweep_lines(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    top_n: int = ...,
    preview_chars: int = ...,
) -> List[str]: ...

def load_zspace_generation_control_sweep(
    path: str | PathLike[str],
) -> Dict[str, object]: ...

def summarize_zspace_generation_control_run(
    row: Mapping[str, object],
    *,
    baseline_continuation_sha256: object = ...,
    baseline_loop_score: object = ...,
) -> Dict[str, object]: ...

def summarize_zspace_generation_control_sweep(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    top_n: int = ...,
) -> Dict[str, object]: ...

def compare_zspace_generation_control_sweeps(
    sweeps_or_paths: Mapping[str, object] | Sequence[object],
    *,
    labels: Sequence[str] | None = ...,
    top_n: int = ...,
) -> Dict[str, object]: ...

def summarize_zspace_generation_control_sweep_comparison_lines(
    comparison_or_sweeps: Mapping[str, object] | Sequence[object],
    *,
    top_n: int = ...,
) -> List[str]: ...

def summarize_zspace_generation_control_sweep_lines(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    top_n: int = ...,
) -> List[str]: ...

def hf_gpt2_finetune_preflight_report(
    *,
    model_name: str = ...,
    dataset_name: str | None = ...,
    dataset_config: str | None = ...,
    train_split: str = ...,
    eval_split: str | None = ...,
    text_column: str = ...,
    runtime_device_backends: object = ...,
    required_runtime_device_ready_backends: object = ...,
    require_hf_gpt2_ft: bool = ...,
    finetune_mode: str = ...,
    describe_runtime_devices: Callable[..., Mapping[str, object]] | None = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_summary_lines(
    report: Mapping[str, object],
) -> List[str]: ...

def hf_gpt2_finetune_training_telemetry_frame(
    event: str,
    *,
    logs: Mapping[str, object] | None = ...,
    metrics: Mapping[str, object] | None = ...,
    state: object = ...,
    previous_loss: object = ...,
    telemetry_prefix: str = ...,
    desire_gain: float = ...,
    psi_gain: float = ...,
    inference_distortion_handoff: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_geometry_guard_horizon_report(
    *,
    max_steps: object,
    logging_steps: object,
    initial_step: object = ...,
    min_desire_stability_guard: object = ...,
    max_psi_total_guard: object = ...,
    minimum_observations: object = ...,
    patience: object = ...,
) -> Dict[str, object]: ...

def hf_finetune_geometry_guard_horizon_report(
    *,
    max_steps: object,
    logging_steps: object,
    initial_step: object = ...,
    min_desire_stability_guard: object = ...,
    max_psi_total_guard: object = ...,
    minimum_observations: object = ...,
    patience: object = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_geometry_guard_runtime_evidence_report(
    *,
    active: object,
    minimum_observations: object = ...,
    required_axes: object = ...,
    expected_axes: object = ...,
    armed_axes: object = ...,
    pending_axes: object = ...,
    armed: object = ...,
    armed_transition_count: object = ...,
    armed_at_step: object = ...,
    arming_progress: object = ...,
    desire_observation_count: object = ...,
    psi_observation_count: object = ...,
    trigger_count: object = ...,
    status: object = ...,
    reason_codes: object = ...,
    trigger_step: object = ...,
) -> Dict[str, object]: ...

def hf_finetune_geometry_guard_runtime_evidence_report(
    *,
    active: object,
    minimum_observations: object = ...,
    required_axes: object = ...,
    expected_axes: object = ...,
    armed_axes: object = ...,
    pending_axes: object = ...,
    armed: object = ...,
    armed_transition_count: object = ...,
    armed_at_step: object = ...,
    arming_progress: object = ...,
    desire_observation_count: object = ...,
    psi_observation_count: object = ...,
    trigger_count: object = ...,
    status: object = ...,
    reason_codes: object = ...,
    trigger_step: object = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_trainer_trace_event(
    event: str,
    *,
    args: object = ...,
    state: object = ...,
    control: object = ...,
    logs: Mapping[str, object] | None = ...,
    metrics: Mapping[str, object] | None = ...,
    run_id: str | None = ...,
    extra: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_trainer_trace_segment_plan(
    trace_path: str | PathLike[str],
    *,
    resume_from_checkpoint: str | PathLike[str] | None = ...,
    initial_step: object = ...,
    previous_segment: Mapping[str, object] | None = ...,
    previous_trace_path: str | PathLike[str] | None = ...,
) -> Dict[str, object]: ...

def hf_finetune_trainer_trace_segment_plan(
    trace_path: str | PathLike[str],
    *,
    resume_from_checkpoint: str | PathLike[str] | None = ...,
    initial_step: object = ...,
    previous_segment: Mapping[str, object] | None = ...,
    previous_trace_path: str | PathLike[str] | None = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_trainer_trace_segment_receipt(
    plan: Mapping[str, object],
) -> Dict[str, object]: ...

def hf_finetune_trainer_trace_segment_receipt(
    plan: Mapping[str, object],
) -> Dict[str, object]: ...

def hf_gpt2_finetune_trainer_trace_segment_lines(
    report: Mapping[str, object],
) -> list[str]: ...

def hf_finetune_trainer_trace_segment_lines(
    report: Mapping[str, object],
) -> list[str]: ...

def hf_gpt2_finetune_trainer_trace_lineage_report(
    receipt_or_card: str | PathLike[str] | Mapping[str, object],
    *,
    max_segments: int = ...,
) -> Dict[str, object]: ...

def hf_finetune_trainer_trace_lineage_report(
    receipt_or_card: str | PathLike[str] | Mapping[str, object],
    *,
    max_segments: int = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_trainer_trace_lineage_lines(
    report: Mapping[str, object],
) -> list[str]: ...

def hf_finetune_trainer_trace_lineage_lines(
    report: Mapping[str, object],
) -> list[str]: ...

def load_hf_gpt2_finetune_trainer_trace_lineage(
    receipt_card_or_report: str | PathLike[str] | Mapping[str, object],
    *,
    require_ready: bool = ...,
) -> List[Dict[str, object]]: ...

def load_hf_finetune_trainer_trace_lineage(
    receipt_card_or_report: str | PathLike[str] | Mapping[str, object],
    *,
    require_ready: bool = ...,
) -> List[Dict[str, object]]: ...

def summarize_hf_gpt2_finetune_trainer_trace_lineage(
    receipt_card_or_report: str | PathLike[str] | Mapping[str, object],
    *,
    max_steps: object = ...,
) -> Dict[str, object]: ...

def summarize_hf_finetune_trainer_trace_lineage(
    receipt_card_or_report: str | PathLike[str] | Mapping[str, object],
    *,
    max_steps: object = ...,
) -> Dict[str, object]: ...

def write_hf_gpt2_finetune_trainer_trace_event(
    row: Mapping[str, object],
    path: str | PathLike[str],
) -> str: ...

def load_hf_gpt2_finetune_trainer_trace(
    path: str | PathLike[str],
) -> List[Dict[str, object]]: ...

def summarize_hf_gpt2_finetune_trainer_trace(
    path_or_rows: str | PathLike[str] | Sequence[Mapping[str, object]],
    *,
    max_steps: object = ...,
) -> Dict[str, object]: ...

def load_hf_gpt2_finetune_run_card(
    path: str | PathLike[str],
) -> Dict[str, object]: ...

def load_hf_gpt2_finetune_sweep_report(
    path: str | PathLike[str],
) -> Dict[str, object]: ...

def summarize_hf_gpt2_finetune_run_card(
    card_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    run_label: str | None = ...,
) -> Dict[str, object]: ...

def summarize_hf_gpt2_finetune_sweep_report(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    top_n: int = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_scale_up_command(
    report_or_summary: str | PathLike[str] | Mapping[str, object],
    *,
    model_name: str | PathLike[str] | None = ...,
    resume_from_checkpoint: str | PathLike[str] | None = ...,
    max_steps: int | None = ...,
    max_steps_multiplier: float | None = ...,
    max_train_samples: int | None = ...,
    max_train_samples_multiplier: float | None = ...,
    max_eval_samples: int | None = ...,
    max_eval_blocks: int | None = ...,
    streaming_validation_samples: int | None = ...,
    output_dir: str | PathLike[str] | None = ...,
    output_suffix: str = ...,
    run_card: str | PathLike[str] | None = ...,
    trainer_trace_jsonl: str | PathLike[str] | None = ...,
    trainer_trace_run_id: str | None = ...,
    require_trainer_telemetry: bool = ...,
    trainer_min_desire_stability_guard: float | None = ...,
    trainer_max_psi_total_guard: float | None = ...,
    trainer_geometry_guard_min_events: int = ...,
    trainer_geometry_guard_patience: int = ...,
    adapter_continuation: str = ...,
    source_cwd: str | PathLike[str] | None = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_scale_up_preflight_report(
    command_or_artifact: str | PathLike[str] | Mapping[str, object] | Sequence[object],
) -> Dict[str, object]: ...

def hf_gpt2_finetune_scale_up_preflight_lines(
    report_or_command: str | PathLike[str] | Mapping[str, object] | Sequence[object],
) -> list[str]: ...

def summarize_hf_gpt2_finetune_sweep_report_lines(
    report_or_path: str | PathLike[str] | Mapping[str, object],
    *,
    top_n: int = ...,
) -> list[str]: ...

def compare_hf_gpt2_finetune_run_cards(
    cards_or_paths: Sequence[str | PathLike[str] | Mapping[str, object]],
    *,
    run_labels: Sequence[str] | None = ...,
) -> Dict[str, object]: ...

def hf_gpt2_finetune_trainer_trace_callback(
    path: str | PathLike[str],
    *,
    run_id: str | None = ...,
    reset: bool = ...,
    zspace_probe_tokens: Sequence[int | float] | None = ...,
    zspace_probe_kwargs: Mapping[str, object] | None = ...,
    inference_distortion_handoff: Mapping[str, object] | None = ...,
    training_telemetry: bool = ...,
    telemetry_prefix: str = ...,
    desire_gain: float = ...,
    psi_gain: float = ...,
    stop_on_nonfinite_loss: bool = ...,
    loss_guard_threshold: float | None = ...,
    min_desire_stability_guard: float | None = ...,
    max_psi_total_guard: float | None = ...,
    geometry_guard_min_events: int = ...,
    geometry_guard_patience: int = ...,
    geometry_guard_initial_step: int = ...,
) -> object: ...

def hf_gpt2_finetune_zspace_probe(
    token_ids: Sequence[int | float],
    *,
    dim: int = ...,
    vocab_size: int | None = ...,
    curvature: float = ...,
    frequency: float = ...,
    strength: float = ...,
    require: bool = ...,
) -> Dict[str, object]: ...

def write_hf_gpt2_finetune_run_card(
    report: Mapping[str, object],
    path: str | PathLike[str],
) -> str: ...

def write_trainer_trace_html(
    trace_jsonl: str,
    html_path: str | None = ...,
    *,
    title: str = ...,
    event_type: str = ...,
    marker_event_type: str | None = ...,
) -> str: ...

def load_gnn_band_replay_trace(path: str | PathLike[str]) -> Dict[str, Any]: ...

def flatten_gnn_band_replay_rows(
    trace: str | PathLike[str] | Mapping[str, Any],
) -> List[Dict[str, Any]]: ...

def summarize_gnn_band_replays(
    trace: str | PathLike[str] | Mapping[str, Any],
) -> Dict[str, Any]: ...

def compare_gnn_band_replay_runs(
    traces: Iterable[str | PathLike[str] | Mapping[str, Any]],
) -> Dict[str, Any]: ...

def write_gnn_band_replay_html(
    trace: str | PathLike[str] | Mapping[str, Any],
    html_path: str | PathLike[str] | None = ...,
    *,
    title: str = ...,
) -> str: ...

def load_wasm_report(path: str | PathLike[str]) -> Dict[str, Any]: ...

def summarize_wasm_report(
    report: str | PathLike[str] | Mapping[str, Any],
) -> Dict[str, Any]: ...

def audit_wasm_report(
    report: str | PathLike[str] | Mapping[str, Any],
) -> Dict[str, Any]: ...

def collect_wasm_report_paths(
    reports: Sequence[str | PathLike[str]] | str | PathLike[str] | None = ...,
    *,
    globs: Sequence[str] | None = ...,
    dirs: Sequence[str | PathLike[str]] | None = ...,
    recursive: bool = ...,
) -> List[str]: ...

def compare_wasm_reports(
    reports: (
        Mapping[str, str | PathLike[str] | Mapping[str, Any]]
        | Sequence[str | PathLike[str] | Mapping[str, Any]]
        | str
        | PathLike[str]
    ),
    *,
    labels: Sequence[str] | None = ...,
) -> Dict[str, Any]: ...

def audit_wasm_report_context(
    reports: (
        Mapping[str, str | PathLike[str] | Mapping[str, Any]]
        | Sequence[str | PathLike[str] | Mapping[str, Any]]
        | str
        | PathLike[str]
    ),
    *,
    labels: Sequence[str] | None = ...,
) -> Dict[str, Any]: ...

def wasm_report_to_zspace_partial(
    report: str | PathLike[str] | Mapping[str, Any],
    *,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> ZSpacePartialBundle: ...

def build_wasm_report_context(
    reports: Any = ...,
    *,
    report_globs: Sequence[str] | None = ...,
    report_dirs: Sequence[str | PathLike[str]] | None = ...,
    max_reports: int | None = ...,
    recursive: bool = ...,
    bundle_weight: float = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> Tuple[List[ZSpacePartialBundle], Dict[str, Any]]: ...

def build_wasm_report_context_artifact(
    reports: Any = ...,
    *,
    report_globs: Sequence[str] | None = ...,
    report_dirs: Sequence[str | PathLike[str]] | None = ...,
    max_reports: int | None = ...,
    recursive: bool = ...,
    bundle_weight: float = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> Dict[str, Any]: ...

def write_wasm_report_context_artifact(
    path: str | PathLike[str],
    reports: Any = ...,
    *,
    report_globs: Sequence[str] | None = ...,
    report_dirs: Sequence[str | PathLike[str]] | None = ...,
    max_reports: int | None = ...,
    recursive: bool = ...,
    bundle_weight: float = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> str: ...

def load_wasm_report_context_artifact(
    path: str | PathLike[str],
) -> Tuple[List[ZSpacePartialBundle], Dict[str, Any]]: ...

def load_kdsl_trace_events(path: str) -> List[Dict[str, Any]]: ...

def write_kdsl_trace_jsonl(
    trace: Mapping[str, Any] | Sequence[Mapping[str, Any]],
    path: str,
) -> str: ...

def write_kdsl_trace_html(
    trace: Mapping[str, Any] | Sequence[Mapping[str, Any]],
    html_path: str | None = ...,
    *,
    title: str = ...,
) -> str: ...

def zspace_trace_event_to_atlas_frame(
    event: Mapping[str, Any],
    *,
    district: str = ...,
    timestamp_base: float | None = ...,
    step_seconds: float = ...,
) -> "telemetry.AtlasFrame" | None: ...

def zspace_trace_to_atlas_route(
    trace: str | Iterable[Mapping[str, Any]],
    *,
    district: str = ...,
    bound: int = ...,
    event_type: str = ...,
    timestamp_base: float | None = ...,
    step_seconds: float = ...,
) -> "telemetry.AtlasRoute": ...

def trainer_step_event_to_atlas_frame(
    event: Mapping[str, Any],
    *,
    district: str = ...,
    timestamp_base: float | None = ...,
    step_seconds: float = ...,
) -> "telemetry.AtlasFrame" | None: ...

def trainer_events_to_atlas_route(
    trace: str | PathLike[str] | Iterable[Mapping[str, Any]],
    *,
    district: str = ...,
    bound: int = ...,
    event_type: str = ...,
    timestamp_base: float | None = ...,
    step_seconds: float = ...,
) -> "telemetry.AtlasRoute": ...

def write_zspace_atlas_noncollapse_html(
    trace_or_route: str | Iterable[Mapping[str, Any]] | "telemetry.AtlasRoute",
    html_path: str | None = ...,
    *,
    title: str = ...,
    district: str = ...,
    bound: int = ...,
    event_type: str = ...,
    timestamp_base: float | None = ...,
    step_seconds: float = ...,
    top_k: int = ...,
    related_links: Mapping[str, str] | None = ...,
) -> str: ...

def load_zspace_artifact_manifest(path: str) -> Dict[str, Any]: ...

def build_zspace_planner_snapshot(
    *,
    backend: str | None = ...,
    rows: int | None = ...,
    cols: int | None = ...,
    k: int | None = ...,
    describe_device: Any | None = ...,
    plan_topk: Any | None = ...,
    device_report: Mapping[str, Any] | None = ...,
    rank_plan: Any | None = ...,
    runtime_matrix: Mapping[str, Any] | None = ...,
    capture_runtime_matrix: bool = ...,
    trace_runtime_matrix: Any | None = ...,
    runtime_matrix_backends: Any | None = ...,
) -> Dict[str, Any]: ...

def write_zspace_experiment_artifacts(
    trace_jsonl: str | PathLike[str],
    *,
    trace_html: str | PathLike[str] | None = ...,
    atlas_html: str | PathLike[str] | None = ...,
    manifest: str | PathLike[str] | None = ...,
    title: str = ...,
    district: str = ...,
    event_type: str = ...,
    bound: int = ...,
    top_k: int = ...,
    metadata: Mapping[str, Any] | None = ...,
    capture_planner: bool = ...,
    planner_backend: str | None = ...,
    planner_rows: int | None = ...,
    planner_cols: int | None = ...,
    planner_k: int | None = ...,
    planner_snapshot: Mapping[str, Any] | None = ...,
    describe_device: Any | None = ...,
    plan_topk: Any | None = ...,
    device_report: Mapping[str, Any] | None = ...,
    rank_plan: Any | None = ...,
    runtime_matrix: Mapping[str, Any] | None = ...,
    capture_runtime_matrix: bool = ...,
    trace_runtime_matrix: Any | None = ...,
    runtime_matrix_backends: Any | None = ...,
) -> Dict[str, Any]: ...

def summarize_zspace_experiment_manifest(
    manifest_or_path: Mapping[str, Any] | str | PathLike[str],
    *,
    top_k: int = ...,
) -> Dict[str, Any]: ...

def write_zspace_experiment_cockpit_html(
    manifest_or_path: Mapping[str, Any] | str | PathLike[str],
    html_path: str | PathLike[str] | None = ...,
    *,
    title: str | None = ...,
    top_k: int = ...,
) -> str: ...

def summarize_zspace_experiment_index(
    manifests: Sequence[Mapping[str, Any] | str | PathLike[str]],
    *,
    top_k: int = ...,
    title: str = ...,
) -> Dict[str, Any]: ...

def write_zspace_experiment_index_html(
    manifests: Sequence[Mapping[str, Any] | str | PathLike[str]],
    html_path: str | PathLike[str] | None = ...,
    *,
    title: str = ...,
    top_k: int = ...,
) -> str: ...

def compare_zspace_experiment_manifests(
    baseline: Mapping[str, Any] | str | PathLike[str],
    candidate: Mapping[str, Any] | str | PathLike[str],
    *,
    top_k: int = ...,
    title: str | None = ...,
    warn_stability_drop: float = ...,
    fail_stability_drop: float = ...,
    min_frame_ratio: float = ...,
    warn_on_planner_change: bool = ...,
    warn_on_focus_change: bool = ...,
) -> Dict[str, Any]: ...

def write_zspace_experiment_comparison_html(
    baseline: Mapping[str, Any] | str | PathLike[str],
    candidate: Mapping[str, Any] | str | PathLike[str],
    html_path: str | PathLike[str] | None = ...,
    *,
    title: str | None = ...,
    top_k: int = ...,
    warn_stability_drop: float = ...,
    fail_stability_drop: float = ...,
    min_frame_ratio: float = ...,
    warn_on_planner_change: bool = ...,
    warn_on_focus_change: bool = ...,
) -> str: ...

def build_zspace_downstream_hook(
    manifest_or_path: Mapping[str, Any] | str,
    *,
    top_k: int = ...,
) -> Dict[str, Any]: ...

def build_desire_adapter_from_downstream_hook(
    hook_or_manifest: Mapping[str, Any] | str,
    *,
    base_gain: float = ...,
    min_gain: float = ...,
    max_gain: float = ...,
    stability_weight: float = ...,
    momentum_weight: float = ...,
    delta_weight: float = ...,
    phase_bias: Mapping[str, float] | None = ...,
) -> Dict[str, Any]: ...

def desire_step_from_downstream_hook(
    pipeline: Any,
    logits: Sequence[float],
    previous_token: int,
    hook_or_manifest: Mapping[str, Any] | str,
    *,
    concept: Sequence[float] | None = ...,
    window: Sequence[Tuple[int, float]] | None = ...,
    base_gain: float = ...,
    min_gain: float = ...,
    max_gain: float = ...,
    stability_weight: float = ...,
    momentum_weight: float = ...,
    delta_weight: float = ...,
    phase_bias: Mapping[str, float] | None = ...,
) -> Dict[str, Any]: ...

def run_desire_geometry_bias_validation(
    pipeline_factory: Callable[[], Any],
    logits: Sequence[float],
    previous_token: int,
    hook_or_manifest: Mapping[str, Any] | str,
    *,
    concept: Sequence[float] | None = ...,
    window: Sequence[Tuple[int, float]] | None = ...,
    modes: Sequence[str] = ...,
    base_gain: float = ...,
    min_gain: float = ...,
    max_gain: float = ...,
    stability_weight: float = ...,
    momentum_weight: float = ...,
    delta_weight: float = ...,
    phase_bias: Mapping[str, float] | None = ...,
) -> Dict[str, Any]: ...

class ZSpaceTraceLiveServer:
    url: str
    event_type: str
    record_jsonl: str | None
    def close(self) -> None: ...
    def join(self, timeout: float | None = ...) -> None: ...

def serve_zspace_trace(
    *,
    event_type: str = ...,
    host: str = ...,
    port: int = ...,
    title: str = ...,
    maxlen: int = ...,
    poll_interval: float = ...,
    max_batch: int = ...,
    buffer: int = ...,
    record_jsonl: str | None = ...,
    open_browser: bool = ...,
    background: bool = ...,
) -> ZSpaceTraceLiveServer: ...

class Axis:
    name: str
    size: int | None

    def __init__(self, name: str, size: int | None = ...) -> None: ...
    def with_size(self, size: int) -> Axis: ...


class LabeledTensor:
    tensor: Tensor
    axes: tuple[Axis, Axis]

    def __init__(self, data: Tensor | Sequence[Sequence[float]] | Sequence[float], axes: Sequence[Axis | str]) -> None: ...
    @property
    def shape(self) -> tuple[int, int]: ...
    @property
    def rows(self) -> int: ...
    @property
    def cols(self) -> int: ...
    def to_tensor(self) -> Tensor: ...
    def tolist(self) -> List[List[float]]: ...
    def rename(self, axes: Sequence[Axis | str]) -> LabeledTensor: ...
    def with_axes(self, axes: Sequence[Axis | str]) -> LabeledTensor: ...
    def transpose(self) -> LabeledTensor: ...
    def row_softmax(self, *, backend: str | None = ...) -> LabeledTensor: ...
    def describe(self) -> Dict[str, object]: ...
    def axis_names(self) -> tuple[str, str]: ...
    def __matmul__(self, other: LabeledTensor) -> LabeledTensor: ...


@overload
def tensor(data: Sequence[Sequence[float]] | Sequence[float]) -> Tensor: ...


@overload
def tensor(data: Sequence[Sequence[float]] | Sequence[float] | Tensor, *, axes: Sequence[Axis | str]) -> LabeledTensor: ...


def label_tensor(tensor_obj: Tensor | Sequence[Sequence[float]] | Sequence[float], axes: Sequence[Axis | str]) -> LabeledTensor: ...


class ScaleStack:
    @property
    def threshold(self) -> float: ...
    @property
    def mode(self) -> str: ...
    def samples(self) -> List[Tuple[float, float]]: ...
    def persistence(self) -> List[Tuple[float, float, float]]: ...
    def interface_density(self) -> Optional[float]: ...
    def moment(self, order: int) -> float: ...
    def boundary_dimension(self, ambient_dim: float, window: int) -> Optional[float]: ...
    def coherence_break_scale(self, level: float) -> Optional[float]: ...
    def coherence_profile(self, levels: Sequence[float]) -> List[Optional[float]]: ...

def scalar_scale_stack(
    field: Sequence[float],
    shape: Sequence[int],
    scales: Sequence[float],
    threshold: float,
) -> ScaleStack: ...

def semantic_scale_stack(
    embeddings: Sequence[Sequence[float]],
    scales: Sequence[float],
    threshold: float,
    metric: str = ...,
) -> ScaleStack: ...

def scale_stack_probe(
    stack: Any,
    *,
    ambient_dim: float,
    dimension_window: int = ...,
    levels: Sequence[float] = ...,
) -> Dict[str, Any]: ...

def scale_stack_probe_to_zspace_partial(
    probe: Mapping[str, Any],
    *,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> ZSpacePartialBundle: ...

def scalar_scale_stack_probe(
    field: Iterable[float],
    shape: Sequence[int],
    scales: Sequence[float],
    threshold: float,
    *,
    ambient_dim: float | None = ...,
    dimension_window: int = ...,
    levels: Sequence[float] = ...,
) -> Dict[str, Any]: ...

def scalar_scale_stack_partial(
    field: Iterable[float],
    shape: Sequence[int],
    scales: Sequence[float],
    threshold: float,
    *,
    ambient_dim: float | None = ...,
    dimension_window: int = ...,
    levels: Sequence[float] = ...,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> ZSpacePartialBundle: ...

def semantic_scale_stack_probe(
    embeddings: Sequence[Sequence[float]],
    scales: Sequence[float],
    threshold: float,
    *,
    metric: str = ...,
    ambient_dim: float = ...,
    dimension_window: int = ...,
    levels: Sequence[float] = ...,
) -> Dict[str, Any]: ...

def semantic_scale_stack_partial(
    embeddings: Sequence[Sequence[float]],
    scales: Sequence[float],
    threshold: float,
    *,
    metric: str = ...,
    ambient_dim: float = ...,
    dimension_window: int = ...,
    levels: Sequence[float] = ...,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> ZSpacePartialBundle: ...

class Tensor:
    def __init__(self, *args: object, **kwargs: object) -> None: ...
    def snapshot(self) -> Tensor: ...
    def is_snapshot(self) -> bool: ...
    @staticmethod
    def zeros(rows: int, cols: int) -> Tensor: ...
    @staticmethod
    def randn(
        rows: int,
        cols: int,
        mean: float = ...,
        std: float = ...,
        seed: int | None = ...,
    ) -> Tensor: ...
    @staticmethod
    def rand(
        rows: int,
        cols: int,
        min: float = ...,
        max: float = ...,
        seed: int | None = ...,
    ) -> Tensor: ...
    @staticmethod
    def from_dlpack(capsule: object) -> Tensor: ...
    def to_dlpack(self) -> object: ...
    def __dlpack__(
        self,
        *,
        stream: object | None = ...,
        max_version: tuple[int, int] | None = ...,
        dl_device: tuple[int, int] | None = ...,
        copy: bool | None = ...,
    ) -> object: ...
    def __dlpack_device__(self) -> tuple[int, int]: ...
    @property
    def rows(self) -> int: ...
    @property
    def cols(self) -> int: ...
    def shape(self) -> tuple[int, int]: ...
    def tolist(self) -> List[List[float]]: ...
    def matmul(self, other: Tensor, *, backend: str | None = ...) -> Tensor: ...
    def row_softmax(self, *, backend: str | None = ...) -> Tensor: ...
    def row_log_softmax(self) -> Tensor: ...
    def row_log_softmax_backward(self, seed: Tensor) -> Tensor: ...
    def cross_entropy_with_logits(
        self, labels: Sequence[int], *, reduction: Literal["none", "sum", "mean"] = ...,
        ignore_index: int = ..., label_smoothing: float = ...,
    ) -> Tensor: ...
    def cross_entropy_with_logits_backward(
        self, labels: Sequence[int], seed: Tensor, *, reduction: Literal["none", "sum", "mean"] = ...,
        ignore_index: int = ..., label_smoothing: float = ...,
    ) -> Tensor: ...
    def scaled_dot_attention(
        self,
        keys: Tensor,
        values: Tensor,
        *,
        contexts: int,
        sequence: int,
        scale: float,
        z_bias: Tensor | None = ...,
        attn_bias: Tensor | None = ...,
        backend: str | None = ...,
    ) -> Tensor: ...
    def layer_norm_stats(self, *, epsilon: float = ...) -> tuple[Tensor, Tensor]: ...
    def gather_rows(self, indices: Sequence[int], *, backend: str = ...) -> Tensor: ...
    def scatter_add_rows(self, indices: Sequence[int], output_rows: int, *, backend: str = ...) -> Tensor: ...
    def layer_norm_affine_backward(self, gamma: Tensor, upstream: Tensor, *, epsilon: float = ...) -> tuple[Tensor, Tensor, Tensor]: ...
    def layer_norm_affine(
        self,
        gamma: Tensor,
        beta: Tensor,
        *,
        epsilon: float = ...,
    ) -> Tensor: ...
    def layer_norm_affine_add(
        self,
        residual: Tensor,
        gamma: Tensor,
        beta: Tensor,
        *,
        epsilon: float = ...,
    ) -> Tensor: ...
    def add(self, other: Tensor) -> Tensor: ...
    def sub(self, other: Tensor) -> Tensor: ...
    def scale(self, value: float) -> Tensor: ...
    def hadamard(self, other: Tensor) -> Tensor: ...
    def add_scaled_(self, other: Tensor, scale: float) -> None: ...
    def add_row_inplace(self, bias: Sequence[float]) -> None: ...
    def transpose(self) -> Tensor: ...
    def reshape(self, rows: int, cols: int) -> Tensor: ...
    def sum_axis0(self) -> List[float]: ...
    def sum_axis1(self) -> List[float]: ...
    def squared_l2_norm(self) -> float: ...
    def project_to_poincare(self, curvature: float) -> Tensor: ...
    def hyperbolic_distance(self, other: Tensor, curvature: float) -> float: ...
    @staticmethod
    def cat_rows(tensors: Sequence[Tensor]) -> Tensor: ...

class AutogradPackedRhs:
    """Frozen packed source from AutogradTensor.prepack_rhs(); retains its graph."""
    def source_id(self) -> int: ...
    def shape(self) -> Tuple[int, int]: ...
    def requires_grad(self) -> bool: ...

class AutogradTensor:
    def __init__(self, value: Tensor, requires_grad: bool = ...) -> None: ...
    @staticmethod
    def variable(value: Tensor) -> AutogradTensor: ...
    @staticmethod
    def constant(value: Tensor) -> AutogradTensor: ...
    def id(self) -> int: ...
    def shape(self) -> tuple[int, int]: ...
    def requires_grad(self) -> bool: ...
    def operation_name(self) -> str: ...
    def value(self) -> Tensor: ...
    def grad(self) -> Tensor | None: ...
    def detach(self) -> AutogradTensor: ...
    def zero_grad(self) -> None: ...
    def zero_grad_graph(self) -> None: ...
    def add(self, rhs: AutogradTensor) -> AutogradTensor: ...
    def add_row(self, bias: AutogradTensor) -> AutogradTensor: ...
    def relu(self) -> AutogradTensor: ...
    def gelu(self) -> AutogradTensor: ...
    def row_softmax(self) -> AutogradTensor: ...
    def row_log_softmax(self) -> AutogradTensor: ...
    def gather_rows(self, indices: Sequence[int]) -> AutogradTensor: ...
    def scatter_add_rows(self, indices: Sequence[int], output_rows: int) -> AutogradTensor: ...
    def layer_norm_affine(self, gamma: AutogradTensor, beta: AutogradTensor, *, epsilon: float = ...) -> AutogradTensor: ...
    def cross_entropy_with_logits(
        self, labels: Sequence[int], *, reduction: Literal["none", "sum", "mean"] = ...,
        ignore_index: int = ..., label_smoothing: float = ...,
    ) -> AutogradTensor: ...
    def sub(self, rhs: AutogradTensor) -> AutogradTensor: ...
    def hadamard(self, rhs: AutogradTensor) -> AutogradTensor: ...
    def matmul(self, rhs: AutogradTensor) -> AutogradTensor: ...
    def prepack_rhs(self) -> AutogradPackedRhs: ...
    def matmul_prepacked(self, rhs: AutogradPackedRhs) -> AutogradTensor: ...
    def scale(self, factor: float) -> AutogradTensor: ...
    def transpose(self) -> AutogradTensor: ...
    def sum(self) -> AutogradTensor: ...
    def mean(self) -> AutogradTensor: ...
    def dot(self, rhs: AutogradTensor) -> AutogradTensor: ...
    def vector_jacobian_product(self, input: AutogradTensor, seed: Tensor) -> Tensor: ...
    def mean_squared_error(self, target: AutogradTensor) -> AutogradTensor: ...
    def item(self) -> float: ...
    def backward(self, seed: Tensor | None = ...) -> Dict[str, Any]: ...
    def graph_summary(self) -> Dict[str, Any]: ...
    def __add__(self, rhs: AutogradTensor) -> AutogradTensor: ...
    def __sub__(self, rhs: AutogradTensor) -> AutogradTensor: ...
    def __matmul__(self, rhs: AutogradTensor) -> AutogradTensor: ...

class AutogradSgd:
    """Plain CPU SGD; fetch fresh parameter handles for each forward pass."""
    def __init__(self, parameters: Sequence[AutogradTensor], learning_rate: float) -> None: ...
    def add_parameter(self, parameter: AutogradTensor) -> int: ...
    def parameters(self) -> List[AutogradTensor]: ...
    def parameter(self, index: int) -> AutogradTensor: ...
    def learning_rate(self) -> float: ...
    def set_learning_rate(self, learning_rate: float) -> None: ...
    def zero_grad(self) -> None: ...
    def step(self) -> None: ...

class CpuSimdPackedRhs:
    cols: int
    inner: int

    def tolist(self) -> List[float]: ...

def cpu_simd_prepack_rhs(rhs: Tensor) -> CpuSimdPackedRhs: ...

def capture(value: object) -> Tensor: ...

def share(value: object, target: object) -> object: ...

def lorentzian_metric_scaled(
    components: Sequence[Sequence[float]],
    scale: float,
) -> Dict[str, object]: ...

def assemble_zrelativity_model(
    base_metric: Sequence[Sequence[float]],
    internal_metric: Sequence[Sequence[float]],
    *,
    mixed: Sequence[Sequence[float]] | None = ...,
    warp: float | None = ...,
    first_derivatives: Sequence[Sequence[Sequence[float]]] | None = ...,
    second_derivatives: Sequence[Sequence[Sequence[Sequence[float]]]] | None = ...,
    gravitational_constant: float,
    speed_of_light: float,
    internal_volume: float,
    cosmological_constant: float = ...,
    symmetry: str | None = ...,
    topology: str | None = ...,
    boundary_conditions: Sequence[str] | None = ...,
) -> ZRelativityModel: ...

class EllipticTelemetry:
    curvature_radius: float
    sheet_count: int
    sheet_index: int
    sheet_position: float
    normalized_radius: float
    geodesic_radius: float
    spin_alignment: float
    resonance_heat: float
    noise_density: float
    topological_sector: int
    normal_bias: Tuple[float, ...]
    flow_vector: Tuple[float, ...]
    rotor_field: Tuple[float, ...]
    rotor_transport: Tuple[float, ...]
    lie_quaternion: Tuple[float, ...]
    lie_rotation: Tuple[float, ...]
    lie_log: Tuple[float, ...]
    homology_index: Tuple[int, ...]
    event_tags: Tuple[str, ...]
    curvature_tensor: Tuple[float, ...]

    def as_dict(self) -> Dict[str, object]: ...

class EllipticWarp:
    curvature_radius: float
    sheet_count: int
    spin_harmonics: int

    def __init__(
        self,
        curvature_radius: float,
        sheet_count: int | None = ...,
        spin_harmonics: int | None = ...,
    ) -> None: ...
    def configure(
        self,
        sheet_count: int | None = ...,
        spin_harmonics: int | None = ...,
    ) -> None: ...
    def map_orientation(self, orientation: Sequence[float]) -> Tuple[float, ...]: ...
    def map_orientation_differential(
        self,
        orientation: Sequence[float],
    ) -> Tuple[float, ...]: ...

class ResonanceProfile:
    def __init__(self, grid: MellinLogGrid, pole: complex, residue: complex) -> None: ...
    def evaluate(self, log_scale: float) -> complex: ...

def gaussian_resonance(
    log_start: float,
    log_step: float,
    len: int,
    center: float,
    bandwidth: float,
    amplitude: float,
) -> ResonanceProfile: ...

def breathing_resonance(
    grid: MellinLogGrid,
    pole: complex,
    phase: float,
    strength: float,
) -> ResonanceProfile: ...

class RGOperator:
    def __init__(
        self,
        name: str,
        scaling_dimension: float,
        initial_coupling: float,
        nonlinear_feedback: float = ...,
        resonance: ResonanceProfile | None = ...,
    ) -> None: ...

    @property
    def name(self) -> str: ...

    @property
    def scaling_dimension(self) -> float: ...

    @property
    def initial_coupling(self) -> float: ...

    @property
    def nonlinear_feedback(self) -> float: ...

    def with_resonance(self, resonance: ResonanceProfile) -> RGOperator: ...

class RGFlowTrajectory:
    @property
    def name(self) -> str: ...

    @property
    def values(self) -> List[float]: ...

    def at(self, index: int) -> float | None: ...

class RGFlowSolution:
    @property
    def lattice(self) -> List[float]: ...

    @property
    def trajectories(self) -> List[RGFlowTrajectory]: ...

    def trajectory(self, name: str) -> RGFlowTrajectory | None: ...

class RGFlowModel:
    def __init__(self, log_start: float, log_step: float, depth: int) -> None: ...

    @staticmethod
    def from_lattice(lattice: Sequence[float]) -> RGFlowModel: ...

    @staticmethod
    def narrative_depth(depth: int, start: float) -> RGFlowModel: ...

    @property
    def lattice(self) -> List[float]: ...

    @property
    def damping(self) -> float: ...

    @damping.setter
    def damping(self, value: float) -> None: ...

    def register_operator(self, operator: RGOperator) -> None: ...
    def operators(self) -> List[RGOperator]: ...
    def propagate(self) -> RGFlowSolution: ...
    def sample_beta(self, coupling: float, operator_index: int, log_scale: float) -> float: ...

class RgFlowNode:
    @property
    def log_scale(self) -> float: ...

    @property
    def scale(self) -> float: ...

    @property
    def narrative_depth(self) -> float: ...

    @property
    def couplings(self) -> List[float]: ...

    @property
    def beta(self) -> List[float]: ...

    def beta_norm(self) -> float: ...

class ScaleFixedPoint:
    @property
    def log_scale(self) -> float: ...

    @property
    def scale(self) -> float: ...

    @property
    def narrative_depth(self) -> float: ...

    @property
    def couplings(self) -> List[float]: ...

class RgFlowLattice:
    @staticmethod
    def new_with_beta(
        log_start: float,
        log_step: float,
        steps: int,
        root_couplings: Sequence[float],
        beta: Callable[[float, Sequence[float]], Sequence[float]],
    ) -> RgFlowLattice: ...

    @staticmethod
    def from_mellin_grid(
        grid: MellinLogGrid,
        root_couplings: Sequence[float],
        beta: Callable[[float, Sequence[float]], Sequence[float]],
    ) -> RgFlowLattice: ...

    def nodes(self) -> List[RgFlowNode]: ...
    def mellin_series(self) -> List[complex] | None: ...
    def evaluate_mellin(self, s: complex) -> complex: ...
    def evaluate_mellin_many(self, s_values: Sequence[complex]) -> List[complex]: ...
    def fixed_points(self, tolerance: float) -> List[ScaleFixedPoint]: ...

    @property
    def log_step(self) -> float: ...

    @property
    def log_start(self) -> float: ...

    def len(self) -> int: ...
    def __len__(self) -> int: ...
    def is_empty(self) -> bool: ...

class ZRelativityModel:
    def as_tensor(self) -> Tensor: ...
    def to_dlpack(self) -> object: ...
    def effective_metric(self) -> Tensor: ...
    def gauge_tensor(self) -> Tensor: ...
    def scalar_moduli(self) -> Tensor: ...
    def field_equations(self) -> Tensor: ...
    def tensor_bundle(self) -> Dict[str, object]: ...
    def torch_bundle(self) -> Dict[str, object]: ...
    def reduction_summary(self) -> Dict[str, object]: ...
    def curvature_diagnostics(self) -> Dict[
        str,
        float | complex | List[List[complex]] | List[complex],
    ]: ...
    def learnable_flags(self) -> Tuple[bool, bool, bool]: ...
    def warp_scale(self) -> float | None: ...
    def internal_volume_density(self) -> float: ...
    def field_prefactor(self) -> float: ...
    def total_dimension(self) -> int: ...

class ZRelativityModule:
    def __init__(self, model: ZRelativityModel) -> None: ...
    def forward(self, input: Tensor) -> Tensor: ...
    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...
    def parameter_tensor(self) -> Tensor: ...
    def torch_parameters(self) -> object: ...
    def parameter_dimension(self) -> int: ...
    def model(self) -> ZRelativityModel: ...

class ComplexTensor:
    def __init__(self, rows: int, cols: int, data: Optional[Sequence[complex]] = ...) -> None: ...
    @staticmethod
    def zeros(rows: int, cols: int) -> ComplexTensor: ...
    def shape(self) -> tuple[int, int]: ...
    def to_tensor(self) -> Tensor: ...
    def data(self) -> List[complex]: ...
    def matmul(self, other: ComplexTensor) -> ComplexTensor: ...

class OpenCartesianTopos:
    def __init__(
        self,
        curvature: float,
        tolerance: float,
        saturation: float,
        max_depth: int,
        max_volume: int,
    ) -> None: ...
    def curvature(self) -> float: ...
    def tolerance(self) -> float: ...
    def saturation(self) -> float: ...
    def porosity(self) -> float: ...
    def with_porosity(self, porosity: float) -> OpenCartesianTopos: ...
    def max_depth(self) -> int: ...
    def max_volume(self) -> int: ...
    def ensure_loop_free(self, depth: int) -> None: ...
    def saturate(self, value: float) -> float: ...
    def control_signal(
        self,
        observed_depth: int = ...,
        visited_volume: int = ...,
    ) -> Dict[str, object]: ...
    def training_hints(
        self,
        observed_depth: int = ...,
        visited_volume: int = ...,
    ) -> Dict[str, object]: ...
    def training_plan(
        self,
        observed_depth: int = ...,
        visited_volume: int = ...,
        gain: float = ...,
    ) -> Dict[str, object]: ...
    def inference_hints(
        self,
        observed_depth: int = ...,
        visited_volume: int = ...,
    ) -> Dict[str, object]: ...
    def inference_plan(
        self,
        observed_depth: int = ...,
        visited_volume: int = ...,
        gain: float = ...,
        base_temperature: float = ...,
        base_top_p: float = ...,
        base_frequency_penalty: float = ...,
        base_presence_penalty: float = ...,
    ) -> Dict[str, object]: ...
    def runtime_profile(
        self,
        observed_depth: int = ...,
        visited_volume: int = ...,
        training_gain: float = ...,
        inference_gain: float = ...,
        base_temperature: float = ...,
        base_top_p: float = ...,
        base_frequency_penalty: float = ...,
        base_presence_penalty: float = ...,
    ) -> Dict[str, object]: ...
    def runtime_route(
        self,
        observed_depth: int = ...,
        visited_volume: int = ...,
        training_gain: float = ...,
        inference_gain: float = ...,
        base_temperature: float = ...,
        base_top_p: float = ...,
        base_frequency_penalty: float = ...,
        base_presence_penalty: float = ...,
    ) -> Dict[str, object]: ...
    def site(self) -> ZBoxSite: ...
    def guard_zbox(self, zbox: ZBox) -> None: ...
    def guard_cover(self, cover: Sequence[ZBox]) -> None: ...

OpenTopos = OpenCartesianTopos

class ZBox:
    def __init__(
        self,
        centers: Sequence[Sequence[float]],
        radii: Sequence[float],
        density: float = ...,
    ) -> None: ...

    @property
    def centers(self) -> List[List[float]]: ...

    @property
    def radii(self) -> List[float]: ...

    def arity(self) -> int: ...
    def density(self) -> float: ...
    def factor_dimension(self, index: int) -> int: ...
    def hyperbolic_volume(self, curvature: float) -> float: ...
    def probability_mass(self, curvature: float) -> float: ...

class ZBoxSite:
    @staticmethod
    def default_for(curvature: float) -> ZBoxSite: ...

    def with_radius_window(self, min: float, max: float) -> ZBoxSite: ...
    def curvature(self) -> float: ...
    def guard_box(self, zbox: ZBox) -> None: ...
    def guard_cover(self, cover: Sequence[ZBox]) -> None: ...

class LanguageWaveEncoder:
    def __init__(self, curvature: float, temperature: float) -> None: ...
    def curvature(self) -> float: ...
    def temperature(self) -> float: ...
    def encode_wave(self, text: str) -> ComplexTensor: ...
    def encode_z_space(self, text: str) -> Tensor: ...

class GradientSummary:
    @staticmethod
    def from_values(values: Sequence[float]) -> GradientSummary: ...
    def l1(self) -> float: ...
    def l2(self) -> float: ...
    def linf(self) -> float: ...
    def count(self) -> int: ...
    def sum(self) -> float: ...
    def mean_abs(self) -> float: ...
    def rms(self) -> float: ...
    def sum_squares(self) -> float: ...
    def sum_cubes(self) -> float: ...
    def sum_quartic(self) -> float: ...
    def mean(self) -> float: ...
    def min(self) -> float: ...
    def max(self) -> float: ...
    def support_width(self) -> float: ...
    def positive_count(self) -> int: ...
    def negative_count(self) -> int: ...
    def zero_count(self) -> int: ...
    def near_zero_count(self) -> int: ...
    def positive_fraction(self) -> float: ...
    def negative_fraction(self) -> float: ...
    def zero_fraction(self) -> float: ...
    def near_zero_fraction(self) -> float: ...
    def activation(self) -> float: ...
    def sign_lean(self) -> float: ...
    def sign_entropy(self) -> float: ...
    def variance(self) -> float: ...
    def std(self) -> float: ...
    def skewness(self) -> float: ...
    def kurtosis(self) -> float: ...

class HypergradTelemetry:
    def summary(self) -> GradientSummary: ...
    def curvature(self) -> float: ...
    def learning_rate(self) -> float: ...
    def saturation(self) -> float: ...
    def porosity(self) -> float: ...
    def tolerance(self) -> float: ...
    def max_depth(self) -> int: ...
    def max_volume(self) -> int: ...
    def shape(self) -> tuple[int, int]: ...
    def volume(self) -> int: ...
    def finite_count(self) -> int: ...
    def non_finite_count(self) -> int: ...
    def non_finite_ratio(self) -> float: ...
    def noncollapse_snapshot(self) -> NonCollapseSnapshot: ...

class NonCollapseSnapshot:
    coherence_entropy: float | None
    preserved_channels: int | None
    discarded_channels: int | None
    z_bias: float | None
    hypergrad_penalty: float | None
    phase: str | None
    band_energy: tuple[float, float, float] | None
    dominant_channel: int | None
    energy_ratio: float | None
    mean_coherence: float | None
    hypergrad_l2: float | None
    hypergrad_linf: float | None
    hypergrad_non_finite_ratio: float | None
    pre_discard_preserved_ratio: float | None
    pre_discard_survivor_energy_ratio: float | None

    def is_empty(self) -> bool: ...
    def to_dict(self) -> Dict[str, object]: ...

class DesireGradientInterpretation:
    def hyper_pressure(self) -> float: ...
    def real_pressure(self) -> float: ...
    def balance(self) -> float: ...
    def stability(self) -> float: ...
    def saturation(self) -> float: ...
    def hyper_std(self) -> float: ...
    def real_std(self) -> float: ...
    def sharpness(self) -> float: ...
    def penalty_gain(self) -> float: ...
    def activation(self) -> float: ...
    def sign_alignment(self) -> float: ...
    def sign_entropy(self) -> float: ...

class DesireGradientControl:
    def penalty_gain(self) -> float: ...
    def bias_mix(self) -> float: ...
    def observation_gain(self) -> float: ...
    def damping(self) -> float: ...
    def hyper_rate_scale(self) -> float: ...
    def real_rate_scale(self) -> float: ...
    def operator_mix(self) -> float: ...
    def operator_gain(self) -> float: ...
    def tuning_gain(self) -> float: ...
    def target_entropy(self) -> float: ...
    def learning_rate_eta(self) -> float: ...
    def learning_rate_min(self) -> float: ...
    def learning_rate_max(self) -> float: ...
    def learning_rate_slew(self) -> float: ...
    def clip_norm(self) -> float: ...
    def clip_floor(self) -> float: ...
    def clip_ceiling(self) -> float: ...
    def clip_ema(self) -> float: ...
    def temperature_kappa(self) -> float: ...
    def temperature_slew(self) -> float: ...
    def quality_gain(self) -> float: ...
    def quality_bias(self) -> float: ...
    def events(self) -> List[str]: ...

class Hypergrad:
    def __init__(
        self,
        curvature: float,
        learning_rate: float,
        rows: int,
        cols: int,
        topos: OpenCartesianTopos | None = None,
    ) -> None: ...
    def curvature(self) -> float: ...
    def learning_rate(self) -> float: ...
    def shape(self) -> tuple[int, int]: ...
    def gradient(self) -> List[float]: ...
    def optimizer_state_control(self) -> Dict[str, Any]: ...
    def optimizer_momentum(self) -> List[float]: ...
    def configure_optimizer_state(self, control: Mapping[str, Any]) -> Dict[str, Any]: ...
    def disable_optimizer_state_control(self) -> None: ...
    def reset_optimizer_state(self) -> None: ...
    def summary(self) -> GradientSummary: ...
    def finite_count(self) -> int: ...
    def non_finite_count(self) -> int: ...
    def non_finite_ratio(self) -> float: ...
    def has_non_finite(self) -> bool: ...
    def telemetry(self) -> HypergradTelemetry: ...
    def noncollapse_snapshot(self) -> NonCollapseSnapshot: ...
    def scale_learning_rate(self, factor: float) -> None: ...
    def scale_gradient(self, factor: float) -> None: ...
    def rescale_rms(self, target_rms: float) -> float: ...
    def reset(self) -> None: ...
    def retune(self, curvature: float, learning_rate: float) -> None: ...
    def accumulate_wave(self, tensor: Tensor) -> None: ...
    def accumulate_complex_wave(self, wave: ComplexTensor) -> None: ...
    def absorb_text(self, encoder: LanguageWaveEncoder, text: str) -> None: ...
    def accumulate_pair(self, prediction: Tensor, target: Tensor) -> None: ...
    def apply(self, weights: Tensor) -> None: ...
    def accumulate_barycenter_path(self, intermediates: Sequence[BarycenterIntermediate]) -> None: ...
    def topos(self) -> OpenCartesianTopos: ...
    def desire_control(
        self, real: GradientSummary, gain: float | None = ...
    ) -> DesireGradientControl: ...
    def desire_interpretation(
        self, real: GradientSummary
    ) -> DesireGradientInterpretation: ...


class Realgrad:
    def __init__(self, learning_rate: float, rows: int, cols: int) -> None: ...
    def learning_rate(self) -> float: ...
    def shape(self) -> tuple[int, int]: ...
    def gradient(self) -> List[float]: ...
    def optimizer_state_control(self) -> Dict[str, Any]: ...
    def optimizer_momentum(self) -> List[float]: ...
    def configure_optimizer_state(self, control: Mapping[str, Any]) -> Dict[str, Any]: ...
    def disable_optimizer_state_control(self) -> None: ...
    def reset_optimizer_state(self) -> None: ...
    def summary(self) -> GradientSummary: ...
    def scale_learning_rate(self, factor: float) -> None: ...
    def reset(self) -> None: ...
    def accumulate_wave(self, tensor: Tensor) -> None: ...
    def accumulate_complex_wave(self, wave: ComplexTensor) -> None: ...
    def absorb_text(self, encoder: LanguageWaveEncoder, text: str) -> None: ...
    def accumulate_pair(self, prediction: Tensor, target: Tensor) -> None: ...
    def apply(self, weights: Tensor) -> None: ...

class LinearModel:
    def __init__(self, input_dim: int, output_dim: int) -> None: ...

    def forward(
        self,
        inputs: Tensor | Sequence[Sequence[float]],
    ) -> Tensor: ...

    def train_batch(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
        learning_rate: float = ...,
    ) -> float: ...

    def train_batch_tensor(
        self,
        inputs: Tensor,
        targets: Tensor,
        learning_rate: float = ...,
    ) -> float: ...

    def weights(self) -> Tensor: ...

    def bias(self) -> List[float]: ...

    def input_dim(self) -> int: ...

    def output_dim(self) -> int: ...

    def state_dict(self) -> Dict[str, object]: ...

class ModuleTrainer:
    def __init__(self, input_dim: int, output_dim: int) -> None: ...

    def train_epoch(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
        learning_rate: float = ..., 
        batch_size: int = ...,
    ) -> float: ...

    def evaluate(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
    ) -> float: ...

    def train_zrelativity_step(
        self,
        module: ZRelativityModule,
        targets: Tensor,
        learning_rate: float,
    ) -> float: ...

class SpiralKFftPlan:
    def __init__(self, radix: int, tile_cols: int, segments: int, subgroup: bool) -> None: ...
    @classmethod
    def from_rank_plan(cls, plan: RankPlan) -> SpiralKFftPlan: ...
    @property
    def radix(self) -> int: ...
    @property
    def tile_cols(self) -> int: ...
    @property
    def segments(self) -> int: ...
    @property
    def subgroup(self) -> bool: ...
    def workgroup_size(self) -> int: ...
    def emit_wgsl(self) -> str: ...
    def emit_spiralk_hint(self) -> str: ...
    def dispatch_manifest_json(self) -> str: ...

class MaxwellSpiralKHint:
    @property
    def channel(self) -> str: ...
    @property
    def blocks(self) -> int: ...
    @property
    def z_score(self) -> float: ...
    @property
    def z_bias(self) -> float: ...
    @property
    def weight(self) -> float: ...
    def script_line(self) -> str: ...

class MaxwellSpiralKBridge:
    def __init__(self) -> None: ...
    def set_base_program(self, program: str | None) -> None: ...
    def set_weight_bounds(self, min_weight: float, max_weight: float) -> None: ...
    def is_empty(self) -> bool: ...
    def len(self) -> int: ...
    def push_pulse(
        self,
        channel: str,
        blocks: int,
        mean: float,
        standard_error: float,
        z_score: float,
        band_energy: tuple[float, float, float],
        z_bias: float,
    ) -> MaxwellSpiralKHint: ...
    def hints(self) -> List[MaxwellSpiralKHint]: ...
    def script(self) -> str | None: ...
    def reset(self) -> None: ...

class MaxwellFingerprint:
    def __init__(
        self,
        gamma: float,
        modulation_depth: float,
        tissue_response: float,
        shielding_db: float,
        transmit_gain: float,
        polarization_angle: float,
        distance_m: float,
    ) -> None: ...

    @property
    def gamma(self) -> float: ...
    @property
    def modulation_depth(self) -> float: ...
    @property
    def tissue_response(self) -> float: ...
    @property
    def shielding_db(self) -> float: ...
    @property
    def transmit_gain(self) -> float: ...
    @property
    def polarization_angle(self) -> float: ...
    @property
    def distance_m(self) -> float: ...

    def shielding_factor(self) -> float: ...
    def polarization_alignment(self) -> float: ...
    def lambda_(self) -> float: ...
    def expected_block_mean(self, kappa: float) -> float: ...

    def expected_z_curve(self, blocks: int, sigma: float, kappa: float) -> List[float]: ...
    def polarisation_slope(self, samples: int) -> float: ...
    def envelope_series(
        self,
        semantic_gain: float,
        rho_values: Sequence[float],
        code_values: Sequence[float],
    ) -> List[float]: ...


class MeaningGate:
    def __init__(self, physical_gain: float, semantic_gain: float) -> None: ...
    @property
    def physical_gain(self) -> float: ...
    @physical_gain.setter
    def physical_gain(self, value: float) -> None: ...
    @property
    def semantic_gain(self) -> float: ...
    @semantic_gain.setter
    def semantic_gain(self, value: float) -> None: ...
    def envelope(self, rho: float) -> float: ...
    def envelope_series(
        self,
        rho_values: Sequence[float],
        code_values: Sequence[float],
    ) -> List[float]: ...


class SequentialZ:
    def __init__(self) -> None: ...
    def push(self, sample: float) -> float | None: ...
    def extend(self, samples: Sequence[float]) -> float | None: ...
    def len(self) -> int: ...
    def is_empty(self) -> bool: ...
    def mean(self) -> float: ...
    def variance(self) -> float | None: ...
    def standard_error(self) -> float | None: ...
    def z_stat(self) -> float | None: ...
    def reset(self) -> None: ...


class MaxwellPulse:
    def __init__(
        self,
        blocks: int,
        mean: float,
        standard_error: float,
        z_score: float,
        band_energy: tuple[float, float, float],
        z_bias: float,
    ) -> None: ...
    @property
    def blocks(self) -> int: ...
    @property
    def mean(self) -> float: ...
    @property
    def standard_error(self) -> float: ...
    @property
    def z_score(self) -> float: ...
    @property
    def band_energy(self) -> tuple[float, float, float]: ...
    @property
    def z_bias(self) -> float: ...
    def magnitude(self) -> float: ...


class MaxwellProjector:
    def __init__(
        self,
        rank: int,
        weight: float,
        bias_gain: float = ...,
        min_blocks: int = ...,
        min_z: float = ...,
    ) -> None: ...
    def project(self, tracker: SequentialZ) -> MaxwellPulse | None: ...
    def last_pulse(self) -> MaxwellPulse | None: ...
    def bias_gain(self) -> float: ...
    def set_bias_gain(self, bias_gain: float) -> None: ...
    def min_blocks(self) -> int: ...
    def set_min_blocks(self, min_blocks: int) -> None: ...
    def min_z(self) -> float: ...
    def set_min_z(self, min_z: float) -> None: ...
    def rank(self) -> int: ...
    def weight(self) -> float: ...


def required_blocks(target_z: float, sigma: float, kappa: float, lambda_: float) -> float | None: ...

def expected_z_curve(blocks: int, sigma: float, kappa: float, lambda_: float) -> List[float]: ...

def polarisation_slope(fingerprint: MaxwellFingerprint, samples: int = ...) -> float: ...

class SpiralKContext:
    def __init__(
        self,
        rows: int,
        cols: int,
        k: int,
        subgroup: bool,
        subgroup_capacity: int,
        kernel_capacity: int,
        tile_cols: int,
        radix: int,
        segments: int,
    ) -> None: ...
    @property
    def rows(self) -> int: ...
    @property
    def cols(self) -> int: ...
    @property
    def k(self) -> int: ...
    @property
    def subgroup(self) -> bool: ...
    @property
    def subgroup_capacity(self) -> int: ...
    @property
    def kernel_capacity(self) -> int: ...
    @property
    def tile_cols(self) -> int: ...
    @property
    def radix(self) -> int: ...
    @property
    def segments(self) -> int: ...
    def eval(self, program: str) -> Dict[str, object]: ...
    def eval_with_trace(
        self,
        program: str,
        max_events: int = ...,
    ) -> tuple[Dict[str, object], Dict[str, Any]]: ...

class SpiralKWilsonMetrics:
    def __init__(
        self,
        baseline_latency: float,
        candidate_latency: float,
        wins: int,
        trials: int,
    ) -> None: ...
    @property
    def baseline_latency(self) -> float: ...
    @property
    def candidate_latency(self) -> float: ...
    @property
    def wins(self) -> int: ...
    @property
    def trials(self) -> int: ...
    def gain(self) -> float: ...

class SpiralKHeuristicHint:
    def __init__(self, field: str, value_expr: str, weight: float, condition_expr: str) -> None: ...
    @property
    def field(self) -> str: ...
    @property
    def value_expr(self) -> str: ...
    @property
    def weight_expr(self) -> str: ...
    @property
    def condition_expr(self) -> str: ...

class SpiralKAiRewriteConfig:
    def __init__(
        self,
        model: str,
        max_hints: int | None = ...,
        default_weight: float | None = ...,
        eta_floor: float | None = ...,
    ) -> None: ...
    @property
    def model(self) -> str: ...
    @property
    def max_hints(self) -> int: ...
    @property
    def default_weight(self) -> float: ...
    @property
    def eta_floor(self) -> float: ...

class SpiralKAiRewritePrompt:
    def __init__(
        self,
        base_program: str,
        ctx: SpiralKContext,
        eta_bar: float = ...,
        device_guard: str | None = ...,
    ) -> None: ...
    def set_metrics(self, metrics: SpiralKWilsonMetrics) -> None: ...
    def clear_metrics(self) -> None: ...
    def add_note(self, note: str) -> None: ...
    @property
    def base_program(self) -> str: ...
    @property
    def eta_bar(self) -> float: ...
    @property
    def device_guard(self) -> str | None: ...

def wilson_lower_bound(wins: int, trials: int, z: float) -> float: ...

def should_rewrite(
    metrics: SpiralKWilsonMetrics,
    min_gain: float = ...,
    min_confidence: float = ...,
) -> bool: ...

def synthesize_program(
    base_src: str,
    hints: Sequence[SpiralKHeuristicHint],
) -> str: ...

def rewrite_with_wilson(
    base_src: str,
    ctx: SpiralKContext,
    metrics: SpiralKWilsonMetrics,
    hints: Sequence[SpiralKHeuristicHint],
    min_gain: float = ...,
    min_confidence: float = ...,
) -> tuple[Dict[str, object], str]: ...

def rewrite_with_ai(
    base_src: str,
    ctx: SpiralKContext,
    config: SpiralKAiRewriteConfig,
    prompt: SpiralKAiRewritePrompt,
    generator: Callable[
        [SpiralKAiRewriteConfig, SpiralKAiRewritePrompt],
        Sequence[SpiralKHeuristicHint],
    ]
    | None = ...,
) -> tuple[Dict[str, object], str, Sequence[SpiralKHeuristicHint]]: ...

class LinearModel:
    def __init__(self, input_dim: int, output_dim: int) -> None: ...

    def forward(
        self,
        inputs: Tensor | Sequence[Sequence[float]],
    ) -> Tensor: ...

    def train_batch(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
        learning_rate: float = ...,
    ) -> float: ...

    def train_batch_tensor(
        self,
        inputs: Tensor,
        targets: Tensor,
        learning_rate: float = ...,
    ) -> float: ...

    def weights(self) -> Tensor: ...

    def bias(self) -> List[float]: ...

    def input_dim(self) -> int: ...

    def output_dim(self) -> int: ...

    def state_dict(self) -> Dict[str, object]: ...

class ModuleTrainer:
    def __init__(self, input_dim: int, output_dim: int) -> None: ...

    def train_epoch(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
        learning_rate: float = ...,
        batch_size: int = ...,
    ) -> float: ...

    def evaluate(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
    ) -> float: ...

    def predict(self, inputs: Sequence[Sequence[float]]) -> Tensor: ...

    def predict_tensor(self, inputs: Tensor) -> Tensor: ...

    def weights(self) -> Tensor: ...

    def bias(self) -> List[float]: ...

    def input_dim(self) -> int: ...

    def output_dim(self) -> int: ...

class LinearModel:
    def __init__(self, input_dim: int, output_dim: int) -> None: ...

    def forward(
        self,
        inputs: Tensor | Sequence[Sequence[float]],
    ) -> Tensor: ...

    def train_batch(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
        learning_rate: float = ...,
    ) -> float: ...

    def train_batch_tensor(
        self,
        inputs: Tensor,
        targets: Tensor,
        learning_rate: float = ...,
    ) -> float: ...

    def weights(self) -> Tensor: ...

    def bias(self) -> List[float]: ...

    def input_dim(self) -> int: ...

    def output_dim(self) -> int: ...

    def state_dict(self) -> Dict[str, object]: ...

class ModuleTrainer:
    def __init__(self, input_dim: int, output_dim: int) -> None: ...

    def train_epoch(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
        learning_rate: float = ...,
        batch_size: int = ...,
    ) -> float: ...

    def evaluate(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
    ) -> float: ...

    def predict(self, inputs: Sequence[Sequence[float]]) -> Tensor: ...

    def predict_tensor(self, inputs: Tensor) -> Tensor: ...

    def weights(self) -> Tensor: ...

    def bias(self) -> List[float]: ...

    def input_dim(self) -> int: ...

    def output_dim(self) -> int: ...

class LinearModel:
    def __init__(self, input_dim: int, output_dim: int) -> None: ...

    def forward(
        self,
        inputs: Tensor | Sequence[Sequence[float]],
    ) -> Tensor: ...

    def train_batch(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
        learning_rate: float = ...,
    ) -> float: ...

    def train_batch_tensor(
        self,
        inputs: Tensor,
        targets: Tensor,
        learning_rate: float = ...,
    ) -> float: ...

    def weights(self) -> Tensor: ...

    def bias(self) -> List[float]: ...

    def input_dim(self) -> int: ...

    def output_dim(self) -> int: ...

    def state_dict(self) -> Dict[str, object]: ...

class ModuleTrainer:
    def __init__(self, input_dim: int, output_dim: int) -> None: ...

    def train_epoch(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
        learning_rate: float = ...,
        batch_size: int = ...,
    ) -> float: ...

    def evaluate(
        self,
        inputs: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
    ) -> float: ...

    def predict(self, inputs: Sequence[Sequence[float]]) -> Tensor: ...

    def predict_tensor(self, inputs: Tensor) -> Tensor: ...

    def weights(self) -> Tensor: ...

    def bias(self) -> List[float]: ...

    def input_dim(self) -> int: ...

    def output_dim(self) -> int: ...

class TensorBiome:
    def __init__(self, topos: OpenCartesianTopos) -> None: ...
    def topos(self) -> OpenCartesianTopos: ...
    def len(self) -> int: ...
    def __len__(self) -> int: ...
    def is_empty(self) -> bool: ...
    def total_weight(self) -> float: ...
    def control_signal(self) -> Dict[str, object]: ...
    def weights(self) -> List[float]: ...
    def absorb(self, tensor: Tensor) -> None: ...
    def absorb_weighted(self, tensor: Tensor, weight: float) -> None: ...
    def clear(self) -> None: ...
    def canopy(self) -> Tensor: ...

class BarycenterIntermediate:
    @property
    def interpolation(self) -> float: ...
    @property
    def density(self) -> Tensor: ...
    @property
    def kl_energy(self) -> float: ...
    @property
    def entropy(self) -> float: ...
    @property
    def objective(self) -> float: ...

class ZSpaceBarycenter:
    @property
    def density(self) -> Tensor: ...
    @property
    def kl_energy(self) -> float: ...
    @property
    def entropy(self) -> float: ...
    @property
    def coupling_energy(self) -> float: ...
    @property
    def objective(self) -> float: ...
    @property
    def effective_weight(self) -> float: ...
    def intermediates(self) -> List[BarycenterIntermediate]: ...

class ZMetrics:
    speed: float
    memory: float
    stability: float
    gradient: Optional[Sequence[float]]
    drs: float
    telemetry: Optional[Mapping[str, float]]
    gradient_basis: Optional[str]

def z_metrics(
    *,
    speed: float | None = ...,
    memory: float | None = ...,
    stability: float | None = ...,
    drs: float | None = ...,
    gradient: object | None = ...,
    gradient_basis: str | None = ...,
    telemetry: object | None = ...,
    **aliases: object,
) -> ZMetrics: ...

class ZSpaceControlGradient:
    source: str
    basis: str
    values: Tuple[float, ...]
    dimension: int
    l2: float
    linf: float

    def as_dict(self) -> Dict[str, object]: ...


class ZSpaceDecoded:
    z_state: Tuple[float, ...]
    metrics: Mapping[str, float]
    gradient: Tuple[float, ...]
    gradient_basis: str
    barycentric: Tuple[float, float, float]
    energy: float
    spectral_energy: float
    parseval_relative_error: float
    frac_energy: float
    fractional_energy_ratio: float
    spectral_centroid: float
    spectral_bins: int

    def as_dict(self) -> Dict[str, object]: ...


class ZSpaceTelemetryFrame:
    payload: Mapping[str, float]
    mean: float
    variance: float
    amplitude: float
    energy: float
    balance: float
    focus: float

    def as_dict(self) -> Dict[str, object]: ...


class ZSpacePartialBundle:
    metrics: Mapping[str, Any]
    weight: float
    origin: Optional[str]
    telemetry: Optional[Mapping[str, Any]]
    gradient_basis: Optional[str]

    def __init__(
        self,
        metrics: Mapping[str, Any],
        weight: float = ...,
        origin: str | None = ...,
        telemetry: Mapping[str, Any] | None = ...,
        gradient_basis: str | None = ...,
    ) -> None: ...
    def resolved(self) -> Dict[str, Any]: ...
    def telemetry_payload(self) -> Mapping[str, Any] | None: ...


class ZSpaceInference:
    metrics: Mapping[str, float]
    gradient: Sequence[float]
    gradient_basis: str
    control_gradient: Optional[ZSpaceControlGradient]
    barycentric: Tuple[float, float, float]
    residual: float
    residual_metric_count: int
    confidence: float
    telemetry_reliability: float
    prior: ZSpaceDecoded
    applied: Mapping[str, object]
    telemetry: Optional[ZSpaceTelemetryFrame]
    fusion: Optional[Mapping[str, Any]]

    def as_dict(self) -> Dict[str, object]: ...


class ZSpacePosterior:
    def __init__(self, z_state: Sequence[float], *, alpha: float = ...) -> None: ...

    @classmethod
    def from_state(
        cls,
        source: object,
        *,
        alpha: float | None = ...,
    ) -> ZSpacePosterior: ...

    @property
    def z_state(self) -> List[float]: ...

    @property
    def alpha(self) -> float: ...

    def decode(self) -> ZSpaceDecoded: ...

    def project(
        self,
        partial: Mapping[str, object] | None,
        *,
        smoothing: float = ...,
        gradient_basis: str | None = ...,
        telemetry: Mapping[str, Any] | ZSpaceTelemetryFrame | None = ...,
    ) -> ZSpaceInference: ...


class ZSpaceInferenceRuntime:
    def __init__(
        self,
        z_state: Sequence[float],
        *,
        alpha: float = ...,
        smoothing: float = ...,
        accumulate: bool = ...,
        telemetry: Mapping[str, Any] | None = ...,
    ) -> None: ...

    @property
    def posterior(self) -> ZSpacePosterior: ...
    @property
    def smoothing(self) -> float: ...
    @property
    def accumulate(self) -> bool: ...
    @property
    def telemetry(self) -> Mapping[str, float]: ...
    @property
    def cached_observations(self) -> Mapping[str, Any]: ...
    @property
    def gradient_basis(self) -> str | None: ...

    def clear(self) -> None: ...
    def set_telemetry(
        self,
        telemetry: Mapping[str, Any] | ZSpaceTelemetryFrame | None,
    ) -> None: ...
    def update(
        self,
        partial: Mapping[str, Any] | None = ...,
        *,
        gradient_basis: str | None = ...,
        telemetry: Mapping[str, Any] | ZSpaceTelemetryFrame | None = ...,
    ) -> ZSpaceInference: ...
    def infer(
        self,
        partial: Mapping[str, Any] | None = ...,
        *,
        gradient_basis: str | None = ...,
        telemetry: Mapping[str, Any] | ZSpaceTelemetryFrame | None = ...,
    ) -> ZSpaceInference: ...


class ZSpaceInferencePipeline:
    def __init__(
        self,
        z_state: Sequence[float],
        *,
        alpha: float = ...,
        smoothing: float = ...,
        strategy: str = ...,
        gradient_alignment: str = ...,
        metric_gradient_dimension: int | None = ...,
        telemetry: Mapping[str, Any] | None = ...,
    ) -> None: ...

    @property
    def strategy(self) -> str: ...
    @property
    def gradient_alignment(self) -> str: ...
    @property
    def metric_gradient_dimension(self) -> int | None: ...
    @property
    def posterior(self) -> ZSpacePosterior: ...
    @property
    def smoothing(self) -> float: ...

    def add_partial(
        self,
        partial: Mapping[str, Any] | ZSpacePartialBundle,
        *,
        weight: float | None = ...,
        origin: str | None = ...,
        telemetry: Mapping[str, Any] | None = ...,
        gradient_basis: str | None = ...,
    ) -> ZSpacePartialBundle: ...
    def add_elliptic_telemetry(
        self,
        telemetry: Any,
        *,
        bundle_weight: float = ...,
        origin: str | None = ...,
        telemetry_prefix: str = ...,
        aggregate: str = ...,
        gradient_alignment: str | None = ...,
        gradient_source: str = ...,
        gradient_basis: str | None = ...,
        extra_telemetry: Mapping[str, Any] | None = ...,
    ) -> ZSpacePartialBundle: ...
    def add_elliptic_autograd(
        self,
        warp: Any,
        orientation: Any,
        *,
        bundle_weight: float = ...,
        origin: str | None = ...,
        telemetry_prefix: str = ...,
        aggregate: str = ...,
        gradient_alignment: str | None = ...,
        gradient_source: str = ...,
        gradient_basis: str | None = ...,
        extra_telemetry: Mapping[str, Any] | None = ...,
        return_features: bool = ...,
    ) -> ZSpacePartialBundle | Tuple[Any, ZSpacePartialBundle]: ...
    def add_canvas_snapshot(self, snapshot: Any, **kwargs: Any) -> ZSpacePartialBundle: ...
    def add_coherence_diagnostics(
        self,
        diagnostics: Any,
        **kwargs: Any,
    ) -> ZSpacePartialBundle: ...
    def add_dlpack_weights(self, weights: Any, **kwargs: Any) -> ZSpacePartialBundle: ...
    def add_compat_weights(
        self,
        weights: Any,
        *,
        adapter: str | None = ...,
        **kwargs: Any,
    ) -> ZSpacePartialBundle: ...
    def add_topos_control(
        self,
        topos: Any | None = ...,
        *,
        bundle_weight: float = ...,
        origin: str | None = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
        **signal_options: Any,
    ) -> ZSpacePartialBundle: ...
    def add_geometry_probes(
        self,
        probes: Any,
        *,
        max_probes: int | None = ...,
        bundle_weight: float = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
        include_consensus: bool = ...,
        consensus_only: bool = ...,
        consensus_weight: float | None = ...,
        consensus_strategy: str = ...,
        consensus_origin: str = ...,
        return_metadata: bool = ...,
    ) -> List[ZSpacePartialBundle] | Tuple[List[ZSpacePartialBundle], Dict[str, Any]]: ...
    def clear(self) -> None: ...
    def set_telemetry(
        self,
        telemetry: Mapping[str, Any] | ZSpaceTelemetryFrame | None,
    ) -> None: ...
    def infer(
        self,
        *,
        strategy: str | None = ...,
        gradient_alignment: str | None = ...,
        weights: Sequence[float] | None = ...,
        clear: bool = ...,
        telemetry: Mapping[str, Any] | ZSpaceTelemetryFrame | None = ...,
    ) -> ZSpaceInference: ...


def zspace_posterior_decode(
    z_state: Sequence[float],
    *,
    alpha: float = ...,
) -> Dict[str, Any]: ...


def zspace_posterior_project(
    z_state: Sequence[float],
    partial: Mapping[str, Any] | None = ...,
    *,
    alpha: float = ...,
    smoothing: float = ...,
    gradient_basis: str | None = ...,
    telemetry: Mapping[str, Any] | ZSpaceTelemetryFrame | None = ...,
) -> Dict[str, Any]: ...


def zspace_coherence_distribution_witness(
    normalized_weights: Any,
) -> Dict[str, Any]: ...


def validate_zspace_coherence_distribution_witness(
    witness: Mapping[str, Any],
) -> Dict[str, Any]: ...


def elliptic_partial_from_telemetry(
    telemetry: Any,
    *,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    aggregate: str = ...,
    gradient_alignment: str = ...,
    gradient_source: str = ...,
    gradient_basis: str | None = ...,
    extra_telemetry: Mapping[str, Any] | None = ...,
) -> ZSpacePartialBundle: ...


def elliptic_warp_partial(
    warp: Any,
    orientation: Any,
    *,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    aggregate: str = ...,
    gradient_alignment: str = ...,
    gradient_source: str = ...,
    gradient_basis: str | None = ...,
    extra_telemetry: Mapping[str, Any] | None = ...,
    return_features: bool = ...,
) -> ZSpacePartialBundle | Tuple[Any, ZSpacePartialBundle]: ...


def zspace_coherence_project(
    diagnostics: Any,
    *,
    coherence: Any = ...,
    contour: Any = ...,
    speed_gain: float = ...,
    stability_gain: float = ...,
    frac_gain: float = ...,
    drs_gain: float = ...,
    background_energy_ratio_max: float = ...,
    cascade_energy_ratio_min: float = ...,
) -> Dict[str, Any]: ...


def coherence_partial_from_diagnostics(
    diagnostics: Any,
    *,
    coherence: Any = ...,
    contour: Any = ...,
    speed_gain: float = ...,
    stability_gain: float = ...,
    frac_gain: float = ...,
    drs_gain: float = ...,
) -> Dict[str, float]: ...


def decode_zspace_embedding(
    z_state: Sequence[float] | ZSpacePosterior | object,
    *,
    alpha: float = ...,
) -> ZSpaceDecoded: ...


def infer_from_partial(
    z_state: Sequence[float] | ZSpacePosterior | object,
    partial: Mapping[str, object] | None,
    *,
    alpha: float = ...,
    smoothing: float = ...,
    gradient_basis: str | None = ...,
    telemetry: Mapping[str, Any] | ZSpaceTelemetryFrame | None = ...,
) -> ZSpaceInference: ...


def blend_zspace_partials(
    partials: Sequence[Mapping[str, Any] | ZSpacePartialBundle | None],
    *,
    weights: Sequence[float] | None = ...,
    strategy: str = ...,
    gradient_alignment: str = ...,
    metric_gradient_dimension: int | None = ...,
) -> Dict[str, Any]: ...


ZSPACE_CANONICAL_METRIC_GRADIENT_BASIS: Literal[
    "spiraltorch.zspace.canonical_metric_cycle.v1"
]
ZSPACE_POSTERIOR_LATENT_GRADIENT_BASIS: Literal[
    "spiraltorch.zspace.latent.central_difference.zero_boundary.v1"
]


def zspace_metric_gradient_projection(
    metrics: Mapping[str, Any],
    *,
    gradient_dim: int,
) -> Dict[str, Any]: ...


def zspace_partial_fusion(
    partials: Sequence[Mapping[str, Any] | ZSpacePartialBundle | None],
    *,
    weights: Sequence[float] | None = ...,
    strategy: str = ...,
    gradient_alignment: str = ...,
    metric_gradient_dimension: int | None = ...,
    telemetry: Mapping[str, Any]
    | ZSpaceTelemetryFrame
    | Sequence[Mapping[str, Any] | ZSpaceTelemetryFrame | None]
    | None = ...,
) -> Dict[str, Any]: ...


@overload
def zspace_telemetry_fusion(
    payloads: Sequence[Mapping[str, Any] | ZSpaceTelemetryFrame | None],
    /,
) -> Dict[str, Any]: ...


@overload
def zspace_telemetry_fusion(
    *payloads: Mapping[str, Any] | ZSpaceTelemetryFrame | None,
) -> Dict[str, Any]: ...


def training_telemetry_projection(
    *,
    step: float | int | None = ...,
    max_steps: float | int | None = ...,
    epoch: float | int | None = ...,
    loss: float | int | None = ...,
    previous_loss: float | int | None = ...,
    grad_norm: float | int | None = ...,
    learning_rate: float | int | None = ...,
    desire_gain: float = ...,
    psi_gain: float = ...,
    learning_rate_scale: float = ...,
) -> Dict[str, Any]: ...


def zspace_free_energy(
    *,
    reference_loss: float = ...,
    candidate_loss: float = ...,
    step_time_ms: float = ...,
    memory_mb: float = ...,
    retry_rate: float = ...,
    observation_entropy: float = ...,
    external_penalty: float = ...,
    band: Mapping[str, float] | None = ...,
    config: Mapping[str, object] | None = ...,
) -> Dict[str, Any]: ...


def zspace_generation_control(
    logits: Sequence[float | int],
    token_ids: Sequence[int],
    recent_tokens: Sequence[int] = ...,
    *,
    curvature: float = ...,
    temperature: float = ...,
    entropy_target: float | None = ...,
    entropy_tolerance: float = ...,
    entropy_gain: float = ...,
    min_temperature: float | None = ...,
    max_temperature: float | None = ...,
    repression_window: int = ...,
    repression_strength: float = ...,
    last_token_repression: float = ...,
    ngram_size: int = ...,
    ngram_window: int = ...,
    ngram_repression_strength: float = ...,
    ngram_decay: float = ...,
) -> Dict[str, Any]: ...


def zspace_temperature_control(
    probabilities: Sequence[float | int],
    *,
    config: Mapping[str, object],
    state: Mapping[str, object],
    feedback: Mapping[str, object] | None = ...,
    gradient_heat: float | None = ...,
) -> Dict[str, Any]: ...


def zspace_concept_diffusion(
    tags: Sequence[str],
    state: Sequence[float | int],
    affinity: Sequence[Sequence[float | int]],
    *,
    diffusion_tensor: Sequence[Sequence[float | int]] | None = ...,
    z_bias: Sequence[float | int] = ...,
    observation: Mapping[str, object] | None = ...,
    config: Mapping[str, object] | None = ...,
) -> Dict[str, Any]: ...


def zspace_imaginary_time_schrodinger(
    tags: Sequence[str],
    potential: Sequence[float | int],
    edges: Sequence[Mapping[str, object]],
    *,
    initial_amplitude: Sequence[float | int] = ...,
    config: Mapping[str, object] | None = ...,
) -> Dict[str, Any]: ...


def infer_with_partials(
    z_state: Sequence[float] | ZSpacePosterior | object,
    *partials: Mapping[str, Any] | ZSpacePartialBundle | None,
    alpha: float = ...,
    smoothing: float = ...,
    strategy: str = ...,
    gradient_alignment: str = ...,
    metric_gradient_dimension: int | None = ...,
    weights: Sequence[float] | None = ...,
    telemetry: Mapping[str, Any] | ZSpaceTelemetryFrame | None = ...,
) -> ZSpaceInference: ...


def compile_inference(
    fn: Callable[..., Mapping[str, Any] | None] | None = ...,
    *,
    alpha: float = ...,
    smoothing: float = ...,
    gradient_basis: str | None = ...,
) -> Callable[..., ZSpaceInference]: ...


def inference_to_mapping(
    inference: ZSpaceInference | Mapping[str, object] | ZMetrics,
    *,
    prefer_applied: bool = ...,
    canonical: bool = ...,
    include_gradient: bool = ...,
) -> Dict[str, object]: ...


def inference_to_zmetrics(
    inference: ZSpaceInference | Mapping[str, object] | ZMetrics,
    *,
    prefer_applied: bool = ...,
    include_telemetry: bool = ...,
) -> ZMetrics: ...


def prepare_trainer_step_payload(
    trainer: object,
    inference: ZSpaceInference,
    *,
    payload: None | str | Callable[[ZSpaceInference], object] = ...,
    prefer_applied: bool = ...,
    canonical_mapping: bool = ...,
) -> object: ...

def ensure_zmetrics(
    payload: ZSpaceInference | ZMetrics | Mapping[str, Any],
    *,
    prefer_applied: bool = ...,
) -> ZMetrics: ...


class ApiLLMTrace:
    provider: Optional[str]
    model: Optional[str]
    prompt: Optional[str]
    text: str
    finish_reason: Optional[str]
    latency_ms: Optional[float]
    usage: Mapping[str, float]
    metrics: Mapping[str, Any]
    telemetry: Mapping[str, Any]
    inference: Any | None
    device_preflight: Mapping[str, Any] | None
    response_metadata: Mapping[str, Any] | None

    def as_dict(self) -> Dict[str, Any]: ...


class ApiLLMZSpaceRuntime:
    provider: Optional[str]
    model: Optional[str]
    requested_backend: Optional[str]
    gradient_dim: int
    gradient_alignment: str
    pipeline: ZSpaceInferencePipeline
    session_error: Optional[str]
    session: Any | None
    device_preflight: Optional[Dict[str, Any]]
    traces: List[ApiLLMTrace]

    def __init__(
        self,
        z_state: Sequence[float],
        *,
        backend: str | None = ...,
        provider: str | None = ...,
        model: str | None = ...,
        session: Any | None = ...,
        session_factory: Callable[..., Any] | None = ...,
        create_session: bool = ...,
        alpha: float = ...,
        smoothing: float = ...,
        strategy: str = ...,
        gradient_dim: int | None = ...,
        gradient_alignment: str = ...,
    ) -> None: ...
    def record_response(
        self,
        response: Any,
        *,
        prompt: str | None = ...,
        provider: str | None = ...,
        model: str | None = ...,
        latency_ms: float | None = ...,
        bundle_weight: float = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int | None = ...,
        context_partials: Any = ...,
        clear: bool = ...,
    ) -> ApiLLMTrace: ...
    def call(
        self,
        invoke: Callable[..., Any],
        prompt: str,
        *args: Any,
        provider: str | None = ...,
        model: str | None = ...,
        context_partials: Any = ...,
        runtime_adapter: Any = ...,
        context_prompt: bool = ...,
        context_prompt_options: Mapping[str, Any] | None = ...,
        **kwargs: Any,
    ) -> ApiLLMTrace: ...
    def run_prompts(
        self,
        prompts: Iterable[str],
        invoke: Callable[..., Any],
        *args: Any,
        provider: str | None = ...,
        model: str | None = ...,
        jsonl_out: str | PathLike[str] | None = ...,
        context_partials: Any = ...,
        runtime_adapter: Any = ...,
        context_prompt: bool = ...,
        context_prompt_options: Mapping[str, Any] | None = ...,
        clear: bool = ...,
        **kwargs: Any,
    ) -> Dict[str, Any]: ...
    def call_openai_responses(
        self,
        prompt: str,
        *,
        client: Any | None = ...,
        client_factory: Callable[..., Any] | None = ...,
        client_kwargs: Mapping[str, Any] | None = ...,
        model: str | None = ...,
        input_key: str = ...,
        provider: str | None = ...,
        context_partials: Any = ...,
        runtime_adapter: Any = ...,
        context_prompt: bool = ...,
        context_prompt_options: Mapping[str, Any] | None = ...,
        **request: Any,
    ) -> ApiLLMTrace: ...
    def call_openai_chat(
        self,
        prompt: str,
        *,
        client: Any | None = ...,
        client_factory: Callable[..., Any] | None = ...,
        client_kwargs: Mapping[str, Any] | None = ...,
        model: str | None = ...,
        system: str | None = ...,
        messages: Sequence[Mapping[str, Any]] | None = ...,
        provider: str | None = ...,
        context_partials: Any = ...,
        runtime_adapter: Any = ...,
        context_prompt: bool = ...,
        context_prompt_options: Mapping[str, Any] | None = ...,
        **request: Any,
    ) -> ApiLLMTrace: ...
    def call_anthropic_messages(
        self,
        prompt: str,
        *,
        client: Any | None = ...,
        client_factory: Callable[..., Any] | None = ...,
        client_kwargs: Mapping[str, Any] | None = ...,
        model: str | None = ...,
        system: str | None = ...,
        messages: Sequence[Mapping[str, Any]] | None = ...,
        provider: str | None = ...,
        context_partials: Any = ...,
        runtime_adapter: Any = ...,
        context_prompt: bool = ...,
        context_prompt_options: Mapping[str, Any] | None = ...,
        **request: Any,
    ) -> ApiLLMTrace: ...
    def summary(self) -> Dict[str, Any]: ...
    def write_jsonl(
        self,
        path: str | PathLike[str],
        *,
        event_type: str = ...,
    ) -> str: ...
    def as_dict(self) -> Dict[str, Any]: ...


def api_llm_text_from_response(response: Any) -> str: ...


def api_llm_usage_from_response(response: Any) -> Dict[str, float]: ...


def api_llm_partial_from_response(
    response: Any,
    *,
    prompt: str | None = ...,
    provider: str | None = ...,
    model: str | None = ...,
    latency_ms: float | None = ...,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> ZSpacePartialBundle: ...

def api_llm_wasm_context_partials(
    reports: Any,
    *,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> List[ZSpacePartialBundle]: ...

def api_llm_geometry_context_partials(
    probes: Any,
    *,
    max_probes: int | None = ...,
    bundle_weight: float = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
    include_consensus: bool = ...,
    consensus_only: bool = ...,
    consensus_weight: float | None = ...,
    consensus_strategy: str = ...,
    consensus_origin: str = ...,
) -> List[ZSpacePartialBundle]: ...

def api_llm_zspace_inference_distortion_adapter(
    *,
    desire_pressure: float | None = ...,
    desire_stability: float | None = ...,
    psi_total: float | None = ...,
    coherence: float | None = ...,
    distortion_strength: float = ...,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
    base_temperature: float = ...,
    base_top_p: float = ...,
    min_temperature: float = ...,
    max_temperature: float = ...,
    min_top_p: float = ...,
    max_top_p: float = ...,
    include_temperature: bool = ...,
    include_top_p: bool = ...,
    include_penalties: bool = ...,
    base_frequency_penalty: float = ...,
    base_presence_penalty: float = ...,
    top_k: int = ...,
    curvature: float = ...,
    entropy_target: float | None = ...,
    entropy_gain: float = ...,
    repression_window: int = ...,
    base_repression_strength: float = ...,
    base_last_token_repression: float = ...,
    ngram_size: int = ...,
    ngram_window: int = ...,
    base_ngram_repression_strength: float = ...,
    ngram_decay: float = ...,
    use_native_zspace: bool = ...,
    activation_name_contains: Sequence[str] | None = ...,
    activation_module_names: Sequence[str] | None = ...,
) -> Dict[str, Any]: ...


def api_llm_trace_from_response(
    response: Any,
    *,
    prompt: str | None = ...,
    provider: str | None = ...,
    model: str | None = ...,
    latency_ms: float | None = ...,
    bundle_weight: float = ...,
    telemetry_prefix: str = ...,
    inference: Any | None = ...,
    device_preflight: Mapping[str, Any] | None = ...,
    gradient_dim: int = ...,
) -> ApiLLMTrace: ...


def write_api_llm_trace_jsonl(
    traces: Iterable[ApiLLMTrace | Mapping[str, Any]],
    path: str | PathLike[str],
    *,
    event_type: str = ...,
) -> str: ...


def load_api_llm_trace_events(
    path: str | PathLike[str],
    *,
    event_type: str = ...,
) -> List[Dict[str, Any]]: ...


def summarize_api_llm_trace_events(
    path: str | PathLike[str],
    *,
    event_type: str = ...,
) -> Dict[str, Any]: ...


def compare_api_llm_trace_runs(
    traces: (
        Mapping[str, str | PathLike[str]]
        | Sequence[str | PathLike[str]]
        | str
        | PathLike[str]
    ),
    *,
    labels: Sequence[str] | None = ...,
    event_type: str = ...,
    near_best_tolerance: float = ...,
) -> Dict[str, Any]: ...


def compare_api_llm_matrix_reports(
    reports: (
        Mapping[str, str | PathLike[str]]
        | Sequence[str | PathLike[str]]
        | str
        | PathLike[str]
    ),
    *,
    labels: Sequence[str] | None = ...,
) -> Dict[str, Any]: ...


def compare_api_llm_topos_sweep_reports(
    reports: (
        Mapping[str, str | PathLike[str]]
        | Sequence[str | PathLike[str]]
        | str
        | PathLike[str]
    ),
    *,
    labels: Sequence[str] | None = ...,
) -> Dict[str, Any]: ...

def api_llm_topos_sweep_route_rewards(
    report: Mapping[str, Any],
    *,
    profile: str = ...,
) -> List[Dict[str, Any]]: ...

def api_llm_topos_route_policy_selection(
    policy: Mapping[str, Any],
    *,
    report: Mapping[str, Any] | None = ...,
    topos_profiles: Any = ...,
    request_options: Mapping[str, Any] | None = ...,
    signal_options: Mapping[str, Any] | None = ...,
    adapter_options: Mapping[str, Any] | None = ...,
) -> Dict[str, Any]: ...

def train_stagent_topos_route_policy(
    report: Mapping[str, Any],
    agent: Any,
    *,
    profile: str = ...,
    episodes: int = ...,
    state: int = ...,
    selection_epsilon: float | None = ...,
    max_update_events: int = ...,
) -> Dict[str, Any]: ...


def format_api_llm_context_prompt(
    prompt: str,
    context_partials: Any,
    *,
    header: str = ...,
    max_partials: int = ...,
    max_metrics: int = ...,
    max_telemetry: int = ...,
    precision: int = ...,
) -> str: ...

def topos_runtime_request(
    topos: Any | None = ...,
    *,
    gain: float = ...,
    base_temperature: float = ...,
    base_top_p: float = ...,
    min_temperature: float = ...,
    max_temperature: float = ...,
    min_top_p: float = ...,
    max_top_p: float = ...,
    include_temperature: bool = ...,
    include_top_p: bool = ...,
    include_penalties: bool = ...,
    base_frequency_penalty: float = ...,
    base_presence_penalty: float = ...,
    **signal_options: Any,
) -> Dict[str, float]: ...

def topos_runtime_adapter(
    topos: Any | None = ...,
    *,
    bundle_weight: float = ...,
    training_gain: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
    request_options: Mapping[str, Any] | None = ...,
    **signal_options: Any,
) -> Dict[str, Any]: ...

def topos_api_llm_request_plan(
    topos: Any | None = ...,
    *,
    request: Mapping[str, Any] | None = ...,
    request_options: Mapping[str, Any] | None = ...,
    bundle_weight: float = ...,
    training_gain: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
    **signal_options: Any,
) -> Dict[str, Any]: ...

def topos_api_llm_request_kwargs(
    topos: Any | None = ...,
    *,
    request: Mapping[str, Any] | None = ...,
    request_options: Mapping[str, Any] | None = ...,
    bundle_weight: float = ...,
    training_gain: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
    **signal_options: Any,
) -> Dict[str, Any]: ...


def make_anthropic_messages_invoke(
    *,
    client: Any | None = ...,
    client_factory: Callable[..., Any] | None = ...,
    client_kwargs: Mapping[str, Any] | None = ...,
    model: str | None = ...,
    system: str | None = ...,
    messages: Sequence[Mapping[str, Any]] | None = ...,
    **request_defaults: Any,
) -> Callable[..., Any]: ...


def run_api_llm_prompt_suite(
    prompts: Iterable[str],
    invoke: Callable[..., Any],
    *args: Any,
    z_state: Sequence[float],
    backend: str | None = ...,
    provider: str | None = ...,
    model: str | None = ...,
    session: Any | None = ...,
    session_factory: Callable[..., Any] | None = ...,
    create_session: bool = ...,
    alpha: float = ...,
    smoothing: float = ...,
    strategy: str = ...,
    gradient_dim: int | None = ...,
    gradient_alignment: str = ...,
    jsonl_out: str | PathLike[str] | None = ...,
    context_partials: Any = ...,
    runtime_adapter: Any = ...,
    context_prompt: bool = ...,
    context_prompt_options: Mapping[str, Any] | None = ...,
    clear: bool = ...,
    **kwargs: Any,
) -> Dict[str, Any]: ...


def run_api_llm_prompt_suite_matrix(
    prompts: Iterable[str],
    invokes: Mapping[str, Callable[..., Any]],
    *args: Any,
    z_state: Sequence[float],
    backend: str | None = ...,
    providers: Mapping[str, str | None] | None = ...,
    models: Mapping[str, str | None] | None = ...,
    session: Any | None = ...,
    session_factory: Callable[..., Any] | None = ...,
    create_session: bool = ...,
    alpha: float = ...,
    smoothing: float = ...,
    strategy: str = ...,
    gradient_dim: int | None = ...,
    gradient_alignment: str = ...,
    jsonl_dir: str | PathLike[str] | None = ...,
    context_partials: Any = ...,
    runtime_adapter: Any = ...,
    context_prompt: bool = ...,
    context_prompt_options: Mapping[str, Any] | None = ...,
    request_kwargs: Mapping[str, Mapping[str, Any]] | None = ...,
    near_best_tolerance: float = ...,
    clear: bool = ...,
    **kwargs: Any,
) -> Dict[str, Any]: ...


def run_api_llm_topos_sweep(
    prompts: Iterable[str],
    invoke: Callable[..., Any],
    *args: Any,
    z_state: Sequence[float],
    topos_profiles: Any,
    backend: str | None = ...,
    provider: str | None = ...,
    model: str | None = ...,
    session: Any | None = ...,
    session_factory: Callable[..., Any] | None = ...,
    create_session: bool = ...,
    alpha: float = ...,
    smoothing: float = ...,
    strategy: str = ...,
    gradient_dim: int | None = ...,
    gradient_alignment: str = ...,
    jsonl_dir: str | PathLike[str] | None = ...,
    context_partials: Any = ...,
    context_prompt: bool = ...,
    context_prompt_options: Mapping[str, Any] | None = ...,
    request_options: Mapping[str, Any] | None = ...,
    signal_options: Mapping[str, Any] | None = ...,
    adapter_options: Mapping[str, Any] | None = ...,
    request_kwargs: Mapping[str, Mapping[str, Any]] | None = ...,
    labels: Sequence[str] | None = ...,
    near_best_tolerance: float = ...,
    report_out: str | PathLike[str] | None = ...,
    report_options: Mapping[str, Any] | None = ...,
    clear: bool = ...,
    **kwargs: Any,
) -> Dict[str, Any]: ...


def api_llm_topos_sweep_report(
    sweep: Mapping[str, Any],
    *,
    created_at: str | None = ...,
    max_samples_per_route: int = ...,
    max_text_chars: int = ...,
    max_pair_rows: int = ...,
) -> Dict[str, Any]: ...


def make_openai_responses_invoke(
    *,
    client: Any | None = ...,
    client_factory: Callable[..., Any] | None = ...,
    client_kwargs: Mapping[str, Any] | None = ...,
    model: str | None = ...,
    input_key: str = ...,
    **request_defaults: Any,
) -> Callable[..., Any]: ...


def make_openai_chat_invoke(
    *,
    client: Any | None = ...,
    client_factory: Callable[..., Any] | None = ...,
    client_kwargs: Mapping[str, Any] | None = ...,
    model: str | None = ...,
    system: str | None = ...,
    messages: Sequence[Mapping[str, Any]] | None = ...,
    **request_defaults: Any,
) -> Callable[..., Any]: ...

class SafetyViolation:
    category: str
    message: str
    offending_term: str
    risk: str
    score: float

class SafetyVerdict:
    allowed: bool
    channel: str
    dominant_risk: str
    score: float
    violations: List[SafetyViolation]

class AuditEvent:
    channel: str
    content_preview: str
    timestamp: float
    verdict: SafetyVerdict

class AuditLog:
    def entries(self) -> List[AuditEvent]: ...
    def clear(self) -> None: ...

class InferenceResult:
    accepted: bool
    prompt_verdict: SafetyVerdict
    refusal_message: str | None
    response: str
    response_verdict: SafetyVerdict

class InferenceRuntime:
    audit_log: AuditLog

    def __init__(self, refusal_threshold: float | None = ...) -> None: ...
    def generate(
        self,
        prompt: str,
        metadata: Mapping[str, object] | None = ...,
    ) -> InferenceResult: ...


class ZSpaceTrainer:
    def __init__(
        self,
        z_dim: int = ...,
        *,
        alpha: float = ...,
        lam_speed: float = ...,
        lam_mem: float = ...,
        lam_stab: float = ...,
        lam_frac: float = ...,
        lam_drs: float = ...,
        lr: float = ...,
        beta1: float = ...,
        beta2: float = ...,
        eps: float = ...,
        topos_control_gain: float = ...,
        gradient_projection: str = ...,
    ) -> None: ...
    @property
    def state(self) -> List[float]: ...
    @property
    def last_inference(self) -> ZSpaceInference | None: ...
    @property
    def last_telemetry(self) -> Mapping[str, float]: ...
    @property
    def last_topos_control(self) -> Mapping[str, float]: ...
    @property
    def last_optimizer_report(self) -> Mapping[str, object] | None: ...
    def step(
        self,
        metrics: Mapping[str, object] | ZMetrics | ZSpaceInference,
        *,
        prefer_applied: bool = ...,
    ) -> float: ...
    def reset(self) -> None: ...
    def state_dict(self) -> Dict[str, object]: ...
    def load_state_dict(self, state: Mapping[str, object], *, strict: bool = ...) -> None: ...
    def step_batch(
        self,
        metrics: Iterable[Mapping[str, object] | ZMetrics | ZSpaceInference],
    ) -> List[float]: ...
    def infer_partial(
        self,
        partial: Mapping[str, object] | ZSpacePartialBundle | None,
        *,
        alpha: float | None = ...,
        smoothing: float = ...,
        gradient_basis: str | None = ...,
        telemetry: Mapping[str, object] | ZSpaceTelemetryFrame | None = ...,
    ) -> ZSpaceInference: ...
    def step_partial(
        self,
        partial: Mapping[str, object] | ZSpacePartialBundle | None,
        *,
        alpha: float | None = ...,
        smoothing: float = ...,
        gradient_basis: str | None = ...,
        telemetry: Mapping[str, object] | ZSpaceTelemetryFrame | None = ...,
        prefer_applied: bool = ...,
    ) -> float: ...

ZSPACE_META_OBJECTIVE_FORMULA: str
ZSPACE_META_OPTIMIZER_CONTRACT_VERSION: str
ZSPACE_META_OPTIMIZER_KIND: str
ZSPACE_META_OPTIMIZER_SEMANTIC_BACKEND: str
ZSPACE_META_OPTIMIZER_SEMANTIC_OWNER: str
ZSPACE_OPTIMIZER_FEEDBACK_CONTRACT_VERSION: str
ZSPACE_OPTIMIZER_FEEDBACK_CONTROL_RULE: str
ZSPACE_OPTIMIZER_FEEDBACK_KIND: str
ZSPACE_OPTIMIZER_FEEDBACK_SEMANTIC_BACKEND: str
ZSPACE_OPTIMIZER_FEEDBACK_SEMANTIC_OWNER: str
ZSPACE_PARAMETER_CONTROL_CONTRACT_VERSION: str
ZSPACE_PARAMETER_CONTROL_KIND: str
ZSPACE_PARAMETER_CONTROL_MAX_LEARNING_RATE_SCALE: float
ZSPACE_PARAMETER_CONTROL_MIN_LEARNING_RATE_SCALE: float
ZSPACE_PARAMETER_CONTROL_SEMANTIC_BACKEND: str
ZSPACE_PARAMETER_CONTROL_SEMANTIC_OWNER: str
ZSPACE_PARAMETER_TRAJECTORY_CONTRACT_VERSION: str
ZSPACE_PARAMETER_TRAJECTORY_DOSE_PRESERVING_COMPLEMENT_RULE: str
ZSPACE_PARAMETER_TRAJECTORY_KIND: str
ZSPACE_PARAMETER_TRAJECTORY_POLICIES: tuple[str, ...]
ZSPACE_PARAMETER_TRAJECTORY_POLICY_CONTRACT_VERSION: str
ZSPACE_PARAMETER_TRAJECTORY_POLICY_KIND: str
ZSPACE_PARAMETER_TRAJECTORY_POLICY_SEMANTIC_BACKEND: str
ZSPACE_PARAMETER_TRAJECTORY_POLICY_SEMANTIC_OWNER: str
ZSPACE_PARAMETER_TRAJECTORY_SEMANTIC_BACKEND: str
ZSPACE_PARAMETER_TRAJECTORY_SEMANTIC_OWNER: str
ZSPACE_POLARITY_EVIDENCE_AGGREGATION_RULE: str
ZSPACE_POLARITY_EVIDENCE_CONTRACT_VERSION: str
ZSPACE_POLARITY_EVIDENCE_CONTRAST_RULE: str
ZSPACE_POLARITY_EVIDENCE_KIND: str
ZSPACE_POLARITY_EVIDENCE_MAX_SAFE_SEED: int
ZSPACE_POLARITY_EVIDENCE_SEMANTIC_BACKEND: str
ZSPACE_POLARITY_EVIDENCE_SEMANTIC_OWNER: str
ZSPACE_GENERATION_EVIDENCE_CONTRACT_VERSION: str
ZSPACE_GENERATION_EVIDENCE_KIND: str
ZSPACE_GENERATION_EVIDENCE_LOOP_SCORE_RULE: str
ZSPACE_GENERATION_EVIDENCE_MAX_SAFE_INTEGER: int
ZSPACE_GENERATION_EVIDENCE_MAX_SAMPLES: int
ZSPACE_GENERATION_EVIDENCE_MAX_TOKENS_PER_SAMPLE: int
ZSPACE_GENERATION_EVIDENCE_MAX_TOTAL_TOKENS: int
ZSPACE_GENERATION_EVIDENCE_METRIC_RULE: str
ZSPACE_GENERATION_EVIDENCE_NGRAM_ORDERS: tuple[int, int, int, int]
ZSPACE_GENERATION_EVIDENCE_PERIODIC_SUFFIX_MAX_PERIOD: int
ZSPACE_GENERATION_EVIDENCE_PERIODIC_SUFFIX_MIN_REPETITIONS: int
ZSPACE_GENERATION_EVIDENCE_SEMANTIC_BACKEND: str
ZSPACE_GENERATION_EVIDENCE_SEMANTIC_OWNER: str
ZSPACE_RUNTIME_PROTOCOL_CATALOG_CONTRACT_VERSION: str
ZSPACE_RUNTIME_PROTOCOL_CATALOG_ID_RULE: str
ZSPACE_RUNTIME_PROTOCOL_CATALOG_KIND: str
ZSPACE_RUNTIME_PROTOCOL_CATALOG_SEMANTIC_BACKEND: str
ZSPACE_RUNTIME_PROTOCOL_CATALOG_SEMANTIC_OWNER: str
ZSPACE_RUNTIME_PROTOCOL_CATALOG_STATUS: str
ZSPACE_PERIODICITY_ANALYSIS_ID_RULE: str
ZSPACE_PERIODICITY_CONTRACT_VERSION: str
ZSPACE_PERIODICITY_EVIDENCE_BOUNDARY: str
ZSPACE_PERIODICITY_KIND: str
ZSPACE_PERIODICITY_MAX_COMPARISON_WORK: int
ZSPACE_PERIODICITY_MAX_MINIMUM_REPETITIONS: int
ZSPACE_PERIODICITY_MAX_PERIOD: int
ZSPACE_PERIODICITY_MAX_SAFE_INTEGER: int
ZSPACE_PERIODICITY_MAX_TOKENS: int
ZSPACE_PERIODICITY_RULE: str
ZSPACE_PERIODICITY_SEMANTIC_BACKEND: str
ZSPACE_PERIODICITY_SEMANTIC_OWNER: str
ZSPACE_PERIODIC_SUFFIX_MAX_PERIOD: int
ZSPACE_PERIODIC_SUFFIX_MIN_REPETITIONS: int
ZSPACE_SEMANTIC_REVIEW_CANDIDATE_LABELS: tuple[str, str, str]
ZSPACE_SEMANTIC_REVIEW_DRAFT_CONTRACT_VERSION: str
ZSPACE_SEMANTIC_REVIEW_DRAFT_KIND: str
ZSPACE_SEMANTIC_REVIEW_DRAFT_SCHEMA: str
ZSPACE_SEMANTIC_REVIEW_EVIDENCE_BOUNDARY: str
ZSPACE_SEMANTIC_REVIEW_MAP_COMMITMENT_VERSION: str
ZSPACE_SEMANTIC_REVIEW_MAP_ID_RULE: str
ZSPACE_SEMANTIC_REVIEW_MAP_SCHEMA: str
ZSPACE_SEMANTIC_REVIEW_MAP_STATUS: str
ZSPACE_SEMANTIC_REVIEW_MAX_ARM_NAME_BYTES: int
ZSPACE_SEMANTIC_REVIEW_MAX_CONTINUATION_BYTES: int
ZSPACE_SEMANTIC_REVIEW_MAX_GROUPS: int
ZSPACE_SEMANTIC_REVIEW_MAX_INSTRUCTIONS_BYTES: int
ZSPACE_SEMANTIC_REVIEW_MAX_MAP_ENTRIES: int
ZSPACE_SEMANTIC_REVIEW_MAX_PACKET_TEXT_BYTES: int
ZSPACE_SEMANTIC_REVIEW_MAX_PROMPT_BYTES: int
ZSPACE_SEMANTIC_REVIEW_MAX_SAFE_INTEGER: int
ZSPACE_SEMANTIC_REVIEW_PACKET_CONTRACT_VERSION: str
ZSPACE_SEMANTIC_REVIEW_PACKET_ID_RULE: str
ZSPACE_SEMANTIC_REVIEW_PACKET_KIND: str
ZSPACE_SEMANTIC_REVIEW_PACKET_SCHEMA: str
ZSPACE_SEMANTIC_REVIEW_PACKET_STATUS: str
ZSPACE_SEMANTIC_REVIEW_PACKET_TEXT_BYTE_RULE: str
ZSPACE_SEMANTIC_REVIEW_PREFERENCE_VALUES: tuple[str, str, str, str]
ZSPACE_SEMANTIC_REVIEW_RESPONSE_CONTRACT_VERSION: str
ZSPACE_SEMANTIC_REVIEW_SCORE_DIMENSIONS: tuple[str, str, str, str]
ZSPACE_SEMANTIC_REVIEW_SCORE_MAXIMUM: int
ZSPACE_SEMANTIC_REVIEW_SCORE_MINIMUM: int
ZSPACE_SEMANTIC_REVIEW_SEMANTIC_BACKEND: str
ZSPACE_SEMANTIC_REVIEW_SEMANTIC_OWNER: str
ZSPACE_SEMANTIC_REVIEW_UNBLIND_CONTRACT_VERSION: str
ZSPACE_SEMANTIC_REVIEW_UNBLIND_KIND: str
ZSPACE_REPETITION_UNLIKELIHOOD_CANDIDATE_RULE: str
ZSPACE_REPETITION_UNLIKELIHOOD_CONTRACT_VERSION: str
ZSPACE_REPETITION_UNLIKELIHOOD_DIFFERENTIATION_OWNER: str
ZSPACE_REPETITION_UNLIKELIHOOD_KIND: str
ZSPACE_REPETITION_UNLIKELIHOOD_MATERIALIZED_PLAN_BYTE_RULE: str
ZSPACE_REPETITION_UNLIKELIHOOD_MAX_CANDIDATES_PER_POSITION: int
ZSPACE_REPETITION_UNLIKELIHOOD_MAX_CONTEXT_WINDOW: int
ZSPACE_REPETITION_UNLIKELIHOOD_MAX_MATERIALIZED_PLAN_BYTES: int
ZSPACE_REPETITION_UNLIKELIHOOD_MAX_NGRAM_ORDER: int
ZSPACE_REPETITION_UNLIKELIHOOD_MAX_PROPOSAL_TOP_K: int
ZSPACE_REPETITION_UNLIKELIHOOD_MAX_SAFE_INTEGER: int
ZSPACE_REPETITION_UNLIKELIHOOD_MAX_SEQUENCES: int
ZSPACE_REPETITION_UNLIKELIHOOD_MAX_STRENGTH: float
ZSPACE_REPETITION_UNLIKELIHOOD_MAX_TOKENS_PER_SEQUENCE: int
ZSPACE_REPETITION_UNLIKELIHOOD_MAX_TOTAL_TOKENS: int
ZSPACE_REPETITION_UNLIKELIHOOD_MAX_WORK_UNITS: int
ZSPACE_REPETITION_UNLIKELIHOOD_MIN_NGRAM_ORDER: int
ZSPACE_REPETITION_UNLIKELIHOOD_OBJECTIVE_RULE: str
ZSPACE_REPETITION_UNLIKELIHOOD_PERIODIC_SUFFIX_MAX_PERIOD: int
ZSPACE_REPETITION_UNLIKELIHOOD_PERIODIC_SUFFIX_MIN_REPETITIONS: int
ZSPACE_REPETITION_UNLIKELIHOOD_PROBABILITY_EPSILON: float
ZSPACE_REPETITION_UNLIKELIHOOD_PROPOSAL_OWNER: str
ZSPACE_REPETITION_UNLIKELIHOOD_PROPOSAL_RULE: str
ZSPACE_REPETITION_UNLIKELIHOOD_SEMANTIC_BACKEND: str
ZSPACE_REPETITION_UNLIKELIHOOD_SEMANTIC_OWNER: str
ZSPACE_REPETITION_UNLIKELIHOOD_WORK_UNIT_RULE: str
HF_REPETITION_UNLIKELIHOOD_BATCH_PLAN_KEY: str
HF_REPETITION_UNLIKELIHOOD_RECEIPT_SCHEMA: str

class HfRepetitionUnlikelihoodBatchPlan:
    report: Mapping[str, object] | None
    sequences: tuple[Mapping[str, object], ...] | None

class HfRepetitionUnlikelihoodCollator:
    config: Dict[str, object]
    def __init__(
        self,
        base_collator: Callable[..., Mapping[str, object]],
        *,
        strength: float,
        ngram_order: int,
        context_window: int,
        max_candidates_per_position: int,
        candidate_source: str | Mapping[str, object] = ...,
        proposal_top_k: int = ...,
        planner: Callable[..., Dict[str, object]] = ...,
    ) -> None: ...
    def __call__(
        self, features: List[Dict[str, object]]
    ) -> Dict[str, object]: ...

def hf_repetition_unlikelihood_recipe_contract(
    *,
    strength: float,
    ngram_order: int,
    context_window: int,
    max_candidates_per_position: int,
    candidate_source: str | Mapping[str, object] = ...,
    proposal_top_k: int = ...,
) -> Dict[str, object]: ...
def hf_repetition_unlikelihood_trainer_class(
    base_trainer_class: type[Any],
) -> type[Any]: ...

def zspace_meta_optimizer_init(
    config: Mapping[str, object],
) -> Dict[str, object]: ...
def zspace_meta_optimizer_restore(
    *,
    config: Mapping[str, object],
    state: Mapping[str, object],
    strict: bool = ...,
) -> Dict[str, object]: ...
def zspace_meta_optimizer_step(
    *,
    config: Mapping[str, object],
    state: Mapping[str, object],
    observation: Mapping[str, object],
) -> Dict[str, object]: ...
def zspace_optimizer_feedback_init(
    config: Mapping[str, object] | None = ...,
) -> Dict[str, object]: ...
def zspace_optimizer_feedback_restore(
    *,
    config: Mapping[str, object],
    state: Mapping[str, object],
) -> Dict[str, object]: ...
def zspace_optimizer_feedback_observe(
    *,
    config: Mapping[str, object],
    state: Mapping[str, object],
    observation: Mapping[str, object],
) -> Dict[str, object]: ...
def zspace_optimizer_feedback_control(
    *,
    config: Mapping[str, object],
    state: Mapping[str, object],
    target_step: int,
    proposed_learning_rate_scale: float,
) -> Dict[str, object]: ...
def zspace_parameter_control(
    report: Mapping[str, object],
) -> Dict[str, object]: ...
def zspace_parameter_trajectory(
    *,
    raw_learning_rate_scales: Sequence[float],
    nominal_learning_rates: Sequence[Sequence[float]],
) -> Dict[str, object]: ...
def validate_zspace_parameter_trajectory(
    report: Mapping[str, object],
) -> Dict[str, object]: ...
def zspace_parameter_trajectory_policy(
    source_trajectory: Mapping[str, object],
    *,
    policy: str = ...,
) -> Dict[str, object]: ...
def validate_zspace_parameter_trajectory_policy(
    report: Mapping[str, object],
) -> Dict[str, object]: ...
def zspace_polarity_evidence(
    *,
    protocol_id: str,
    runtime_identity_id: str,
    trajectory_id: str,
    trajectory_policy_id: str,
    control_sequence_id: str,
    nominal_schedule_sequence_id: str,
    rows: Sequence[Mapping[str, object]],
) -> Dict[str, object]: ...
def validate_zspace_polarity_evidence(
    report: Mapping[str, object],
) -> Dict[str, object]: ...
def zspace_generation_evidence(
    *,
    protocol_id: str,
    runtime_identity_id: str,
    model_artifact_id: str,
    prompt_set_id: str,
    decoding_config_id: str,
    samples: List[Dict[str, object]] | Tuple[Dict[str, object], ...],
) -> Dict[str, object]: ...
def validate_zspace_generation_evidence(
    report: Dict[str, object],
) -> Dict[str, object]: ...
def zspace_runtime_protocol_catalog() -> Dict[str, object]: ...
def validate_zspace_runtime_protocol_catalog(
    catalog: Dict[str, object],
) -> Dict[str, object]: ...
def zspace_periodicity(
    token_ids: List[int] | Tuple[int, ...],
    *,
    appended_token_id: Optional[int] = ...,
    maximum_period: int = ...,
    minimum_repetitions: int = ...,
) -> Dict[str, object]: ...
def validate_zspace_periodicity(
    report: Dict[str, object],
) -> Dict[str, object]: ...
ZSPACE_STOCHASTIC_SCHRODINGER_FORWARD_CONTRACT_VERSION: Literal["spiraltorch.zspace_stochastic_schrodinger_forward.v1"]
ZSPACE_STOCHASTIC_SCHRODINGER_FORWARD_KIND: Literal["spiraltorch.zspace_stochastic_schrodinger_forward"]
ZSPACE_STOCHASTIC_SCHRODINGER_VJP_CONTRACT_VERSION: Literal["spiraltorch.zspace_stochastic_schrodinger_vjp.v1"]
ZSPACE_STOCHASTIC_SCHRODINGER_VJP_KIND: Literal["spiraltorch.zspace_stochastic_schrodinger_vjp"]
ZSPACE_STOCHASTIC_SCHRODINGER_PROTOCOL_OWNER: Literal["st-core::runtime::zspace_stochastic_schrodinger"]
ZSPACE_STOCHASTIC_SCHRODINGER_SEMANTIC_OWNER: Literal["st-core::dynamics::stochastic_schrodinger"]
ZSPACE_STOCHASTIC_SCHRODINGER_SEMANTIC_BACKEND: Literal["rust"]
ZSPACE_STOCHASTIC_SCHRODINGER_ID_RULE: str
ZSPACE_STOCHASTIC_SCHRODINGER_VJP_SEMANTICS: str
ZSPACE_STOCHASTIC_SCHRODINGER_EVIDENCE_BOUNDARY: str
ZSPACE_STOCHASTIC_SCHRODINGER_MAX_VALUES: int
ZSPACE_STOCHASTIC_SCHRODINGER_MAX_ROWS: int
ZSPACE_STOCHASTIC_SCHRODINGER_MAX_FEATURES: int
def zspace_stochastic_schrodinger_complex_step(request: dict[str, object]) -> dict[str, Any]: ...
def validate_zspace_stochastic_schrodinger_complex(receipt: dict[str, object]) -> dict[str, Any]: ...
def zspace_stochastic_schrodinger_forward(
    input_values: List[float] | Tuple[float, ...],
    potential: List[float] | Tuple[float, ...],
    *,
    rows: Optional[int] = ...,
    features: Optional[int] = ...,
    standard_normal: Optional[List[float] | Tuple[float, ...]] = ...,
    config: Optional[Dict[str, object]] = ...,
) -> Dict[str, object]: ...
def validate_zspace_stochastic_schrodinger_forward(
    receipt: Dict[str, object],
) -> Dict[str, object]: ...
def zspace_stochastic_schrodinger_vjp(
    forward_receipt: Dict[str, object],
    grad_output_real: List[float] | Tuple[float, ...],
) -> Dict[str, object]: ...
def validate_zspace_stochastic_schrodinger_vjp(
    receipt: Dict[str, object],
) -> Dict[str, object]: ...
def validate_zspace_semantic_review_packet(
    packet: Dict[str, object],
) -> Dict[str, object]: ...
def validate_zspace_semantic_review_packet_trusted_legacy_replay(
    packet: Dict[str, object],
) -> Dict[str, object]: ...
def seal_zspace_semantic_review_packet(
    *,
    protocol_id: str,
    prompt_set_id: str,
    blinding_key_sha256: str,
    blinding_map_id: str,
    instructions: str,
    rubric: Dict[str, str],
    groups: List[Dict[str, object]] | Tuple[Dict[str, object], ...],
) -> Dict[str, object]: ...
def zspace_semantic_review_map_id(
    entries: List[Dict[str, object]] | Tuple[Dict[str, object], ...],
) -> str: ...
def zspace_semantic_review_map_id_trusted_legacy_replay(
    entries: List[Dict[str, object]] | Tuple[Dict[str, object], ...],
) -> str: ...
def validate_zspace_semantic_review_packet_receipt(
    receipt: Dict[str, object],
) -> Dict[str, object]: ...
def validate_zspace_semantic_review_packet_receipt_trusted_legacy_replay(
    receipt: Dict[str, object],
) -> Dict[str, object]: ...
def new_zspace_semantic_review_draft(
    *,
    packet_id: str,
    reviewer_id: str,
    review_session_id: str,
    responses: List[Dict[str, object]] | Tuple[Dict[str, object], ...] = ...,
) -> Dict[str, object]: ...
def summarize_zspace_semantic_review_draft(
    *,
    packet: Dict[str, object],
    draft: Dict[str, object],
) -> Dict[str, object]: ...
def validate_zspace_semantic_review_draft_receipt(
    receipt: Dict[str, object],
) -> Dict[str, object]: ...
def validate_zspace_semantic_review_draft_receipt_trusted_legacy_replay(
    receipt: Dict[str, object],
) -> Dict[str, object]: ...
def unblind_zspace_semantic_review(
    *,
    packet: Dict[str, object],
    draft: Dict[str, object],
    blinding_map: Dict[str, object],
) -> Dict[str, object]: ...
def validate_zspace_semantic_review_unblind(
    report: Dict[str, object],
) -> Dict[str, object]: ...
def validate_zspace_semantic_review_unblind_trusted_legacy_replay(
    report: Dict[str, object],
) -> Dict[str, object]: ...
def zspace_repetition_unlikelihood_plan(
    *,
    sequences: List[Dict[str, object]] | Tuple[Dict[str, object], ...],
    strength: float = ...,
    candidate_source: str | Dict[str, object] = ...,
    ngram_order: int = ...,
    proposal_top_k: int = ...,
    context_window: int = ...,
    max_candidates_per_position: int = ...,
) -> Dict[str, object]: ...
def validate_zspace_repetition_unlikelihood_plan(
    plan: Dict[str, object],
) -> Dict[str, object]: ...
def validate_zspace_repetition_unlikelihood_plan_trusted_legacy_replay(
    plan: Dict[str, object],
) -> Dict[str, object]: ...

def step_many(
    trainer: ZSpaceTrainer,
    samples: Iterable[Mapping[str, object] | ZMetrics | ZSpaceInference],
) -> List[float]: ...

def stream_zspace_training(
    trainer: ZSpaceTrainer,
    samples: Iterable[Mapping[str, object] | ZMetrics | ZSpaceInference],
    *,
    on_step: Optional[Callable[[int, List[float], float], None]] = ...,
) -> List[float]: ...

def vision_online_step(
    vision: SpiralTorchVision,
    payload: object,
    *,
    aggregator: object | None = ...,
    trainer: ZSpaceTrainer | None = ...,
    weight: float = ...,
    metrics_builder: Callable[[SpiralTorchVision, Mapping[str, object]], Mapping[str, object] | ZMetrics] | None = ...,
    step_index: int | None = ...,
) -> Dict[str, object]: ...

def stream_vision_training(
    vision: SpiralTorchVision,
    frames: Iterable[object],
    *,
    aggregator: object | None = ...,
    trainer: ZSpaceTrainer | None = ...,
    weight: float = ...,
    flush_every: int = ...,
    keep_depth: int | None = ...,
    metrics_builder: Callable[[SpiralTorchVision, Mapping[str, object]], Mapping[str, object] | ZMetrics] | None = ...,
    on_step: Callable[[int, Dict[str, object]], None] | None = ...,
    final_flush: bool = ...,
) -> List[Dict[str, object]]: ...

class RankPlan:
    kind: str
    requested_backend: Optional[str]
    effective_backend: Optional[str]
    accelerator_fallback: Literal["allow", "forbid"]
    tensor_util_wgpu_min_values: int
    runtime_execution_plan_output_sha256: str | None
    rows: int
    cols: int
    k: int
    workgroup: int
    lanes: int
    channel_stride: int
    merge_strategy: str
    merge_detail: str
    use_two_stage: bool
    subgroup: bool
    tile: int
    compaction_tile: int
    fft_tile: int
    fft_radix: int
    fft_segments: int

    def latency_window(self) -> Optional[Tuple[int, int, int, int, int, int, int]]: ...
    def to_unison_script(self) -> str: ...
    def fft_wgsl(self) -> str: ...
    def fft_spiralk_hint(self) -> str: ...
    def fft_dispatch_manifest_json(self) -> str: ...
    def contract(self) -> Dict[str, Any]: ...
    def spiralk_context(self) -> SpiralKContext: ...
    def rewrite_with_spiralk(self, script: str) -> RankPlan: ...
    def rewrite_with_spiralk_explain(
        self,
        script: str,
        *,
        max_events: int = ...,
    ) -> tuple[RankPlan, Dict[str, object], Dict[str, Any]]: ...

RANK_ADAPTATION_CONTRACT_VERSION: Literal["spiraltorch.rank_adaptation.v1"]
RANK_ADAPTATION_SEMANTIC_OWNER: Literal["st-core::runtime::rank_adaptation"]

class RankAdaptationSelection:
    selection_id: int
    candidate_index: int
    spiralk_source_sha256: str
    execution_signature: str
    plan: RankPlan

    def receipt(self) -> Dict[str, Any]: ...

class RankAdaptationSession:
    pending_selection_id: int | None

    def __init__(
        self,
        base_plan: RankPlan,
        scripts: Sequence[str],
        *,
        policy: Literal[
            "ucb", "upper_confidence_bound", "ts", "thompson_sampling"
        ] = ...,
        seed: int = ...,
    ) -> None: ...
    def choose(self) -> RankAdaptationSelection: ...
    def observe(
        self,
        selection_id: int,
        elapsed_ms: float,
        correctness_passed: bool,
    ) -> Dict[str, Any]: ...
    def abandon(self, selection_id: int) -> Dict[str, Any]: ...
    def snapshot(self) -> Dict[str, Any]: ...

def from_dlpack(capsule: object) -> Tensor: ...

def to_dlpack(tensor: Tensor) -> object: ...

def mean_tensors_scaled(partials: Sequence[Tensor], scale: float = 1.0) -> Tensor:
    """Finite signed-vector mean, summed in input order in Rust f64 on CPU."""
    ...

def z_space_barycenter(
    weights: Sequence[float],
    densities: Sequence[Tensor],
    entropy_weight: float,
    beta_j: float,
    coupling: Tensor | None = ...,
) -> ZSpaceBarycenter: ...

def zspace_eval(
    real: Sequence[float],
    imag: Sequence[float],
    z_re: Sequence[float],
    z_im: Sequence[float],
) -> List[Tuple[float, float]]: ...

def plan(
    kind: Literal["topk", "midk", "bottomk", "fft"],
    rows: int,
    cols: int,
    k: int,
    *,
    backend: Optional[str] = ...,
    lane_width: Optional[int] = ...,
    subgroup: Optional[bool] = ...,
    max_workgroup: Optional[int] = ...,
    shared_mem_per_workgroup: Optional[int] = ...,
    strict_accelerator: Optional[bool] = ...,
    runtime_execution_plan: Mapping[str, Any] | None = ...,
) -> RankPlan: ...

def plan_topk(
    rows: int,
    cols: int,
    k: int,
    *,
    backend: Optional[str] = ...,
    lane_width: Optional[int] = ...,
    subgroup: Optional[bool] = ...,
    max_workgroup: Optional[int] = ...,
    shared_mem_per_workgroup: Optional[int] = ...,
    strict_accelerator: Optional[bool] = ...,
    runtime_execution_plan: Mapping[str, Any] | None = ...,
) -> RankPlan: ...

class SpiralSession:
    backend: str
    requested_backend: str
    effective_backend: str
    seed: int | None
    device: str
    device_preflight: Dict[str, object]
    runtime_execution_plan_output_sha256: str

    def __init__(
        self,
        backend: str = ...,
        seed: int | None = ...,
        *,
        runtime_execution_plan: Mapping[str, Any] | None = ...,
        accelerator_fallback: Literal["allow", "forbid"] | None = ...,
        tensor_util_wgpu_min_values: int | None = ...,
    ) -> None: ...

    @property
    def runtime_execution_plan(self) -> Dict[str, Any]: ...

    @classmethod
    def from_runtime_execution_plan(
        cls,
        runtime_execution_plan: Mapping[str, Any],
        *,
        seed: int | None = ...,
    ) -> "SpiralSession": ...

    def dataset(
        self,
        samples: Optional[Iterable[Tuple[object, object]]] = ...,
    ) -> "dataset.Dataset": ...

    def dataloader(
        self,
        samples: object,
        *,
        batch_size: Optional[int] = ...,
        shuffle: bool | int = ...,
        seed: Optional[int] = ...,
        prefetch: Optional[int] = ...,
        max_rows: Optional[int] = ...,
    ) -> "dataset.DataLoader": ...

    def plan(
        self,
        kind: Literal["topk", "midk", "bottomk", "fft"],
        rows: int,
        cols: int,
        k: int,
    ) -> RankPlan: ...

    def plan_topk(self, rows: int, cols: int, k: int) -> RankPlan: ...

    def trainer(
        self,
        *,
        curvature: float = ...,
        hyper_learning_rate: float = ...,
        fallback_learning_rate: float = ...,
    ) -> "_NnModuleTrainer": ...

    def module_trainer(
        self,
        *,
        curvature: float = ...,
        hyper_learning_rate: float = ...,
        fallback_learning_rate: float = ...,
    ) -> "_NnModuleTrainer": ...

    def close(self) -> None: ...

def trace_wgpu_first_runtime(
    backend: str = ...,
    *,
    rows: int = ...,
    cols: int = ...,
    k: int = ...,
) -> Dict[str, object]: ...

def trace_wgpu_first_runtime_matrix(
    backends: str | Iterable[str] = ...,
    *,
    rows: int = ...,
    cols: int = ...,
    k: int = ...,
    continue_on_error: bool = ...,
) -> Dict[str, object]: ...

def write_wgpu_first_runtime_matrix(
    path: str | PathLike[str],
    backends: str | Iterable[str] = ...,
    *,
    rows: int = ...,
    cols: int = ...,
    k: int = ...,
    continue_on_error: bool = ...,
    indent: int = ...,
) -> Dict[str, object]: ...

def hypergrad(
    *shape_args: Any,
    curvature: float = ...,
    learning_rate: float = ...,
    shape: Any | None = ...,
    rows: Any | None = ...,
    cols: Any | None = ...,
    topos: Any | None = ...,
) -> Hypergrad: ...

def realgrad(
    *shape_args: Any,
    learning_rate: float = ...,
    shape: Any | None = ...,
    rows: Any | None = ...,
    cols: Any | None = ...,
) -> Realgrad: ...

def hypergrad_topos(
    *,
    curvature: float = ...,
    tolerance: float = ...,
    saturation: float = ...,
    max_depth: int = ...,
    max_volume: int = ...,
) -> OpenCartesianTopos: ...

def topos_control_signal(
    topos: Any | None = ...,
    *,
    training_gain: float = ...,
    curvature: float = ...,
    tolerance: float = ...,
    saturation: float = ...,
    max_depth: int = ...,
    max_volume: int = ...,
    porosity: float | None = ...,
    observed_depth: int = ...,
    visited_volume: int = ...,
) -> Dict[str, object]: ...

def topos_optimizer_snapshot(
    topos: Any | None = ...,
    *,
    sequence: int = ...,
    hyper_learning_rate: float,
    real_learning_rate: float,
    gain: float = ...,
    training_hints: Mapping[str, Any] | None = ...,
    inference_hints: Mapping[str, Any] | None = ...,
    curvature: float = ...,
    tolerance: float = ...,
    saturation: float = ...,
    max_depth: int = ...,
    max_volume: int = ...,
    porosity: float | None = ...,
    observed_depth: int = ...,
    visited_volume: int = ...,
) -> Dict[str, object]: ...

def topos_training_hints(
    topos: Any | None = ...,
    **signal_options: Any,
) -> Dict[str, object]: ...

def topos_training_plan(
    topos: Any | None = ...,
    *,
    gain: float = ...,
    **signal_options: Any,
) -> Dict[str, object]: ...

def topos_inference_hints(
    topos: Any | None = ...,
    **signal_options: Any,
) -> Dict[str, object]: ...

def topos_inference_plan(
    topos: Any | None = ...,
    *,
    gain: float = ...,
    base_temperature: float = ...,
    base_top_p: float = ...,
    min_temperature: float = ...,
    max_temperature: float = ...,
    min_top_p: float = ...,
    max_top_p: float = ...,
    base_frequency_penalty: float = ...,
    base_presence_penalty: float = ...,
    **signal_options: Any,
) -> Dict[str, object]: ...

def topos_runtime_profile(
    topos: Any | None = ...,
    *,
    training_gain: float = ...,
    inference_gain: float = ...,
    base_temperature: float = ...,
    base_top_p: float = ...,
    min_temperature: float = ...,
    max_temperature: float = ...,
    min_top_p: float = ...,
    max_top_p: float = ...,
    base_frequency_penalty: float = ...,
    base_presence_penalty: float = ...,
    **signal_options: Any,
) -> Dict[str, object]: ...

def topos_runtime_route(
    topos: Any | None = ...,
    *,
    runtime_profile: Mapping[str, Any] | None = ...,
    training_gain: float = ...,
    inference_gain: float = ...,
    base_temperature: float = ...,
    base_top_p: float = ...,
    min_temperature: float = ...,
    max_temperature: float = ...,
    min_top_p: float = ...,
    max_top_p: float = ...,
    base_frequency_penalty: float = ...,
    base_presence_penalty: float = ...,
    **signal_options: Any,
) -> Dict[str, object]: ...

def topos_zspace_projection(
    topos: Any | None = ...,
    *,
    gradient_dim: int = ...,
    curvature: float = ...,
    tolerance: float = ...,
    saturation: float = ...,
    max_depth: int = ...,
    max_volume: int = ...,
    porosity: float | None = ...,
    observed_depth: int = ...,
    visited_volume: int = ...,
) -> Dict[str, object]: ...

def topos_control_partial(
    topos: Any | None = ...,
    *,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
    **signal_options: Any,
) -> ZSpacePartialBundle: ...

def encode_zspace(
    text: str,
    *,
    curvature: float = ...,
    temperature: float = ...,
    encoder: LanguageWaveEncoder | None = ...,
) -> Tensor: ...

class HypergradSession(SpiralSession):
    hyper: Hypergrad
    weights: Tensor
    route: AtlasRoute | None

    def __init__(
        self,
        *shape_args: Any,
        curvature: float = ...,
        learning_rate: float = ...,
        backend: str = ...,
        seed: int | None = ...,
        shape: Any | None = ...,
        rows: Any | None = ...,
        cols: Any | None = ...,
        topos: Any | None = ...,
        weights: Any | None = ...,
        telemetry: bool = ...,
        telemetry_bound: int = ...,
    ) -> None: ...

    def shape(self) -> tuple[int, int]: ...
    def zero_grad(self) -> None: ...
    def reset(self) -> None: ...
    def accumulate_wave(self, wave: Any) -> None: ...
    def accumulate_pair(self, prediction: Any, target: Any) -> None: ...
    def summary(self) -> Any: ...
    def step(self, weights: Tensor | None = ..., *, note: str | None = ...) -> Tensor: ...

class AmegagradSession(SpiralSession):
    opt: Amegagrad
    hyper: Hypergrad
    real: Realgrad
    weights: Tensor
    ztrainer: ZSpaceTrainer | None
    route: AtlasRoute | None

    def __init__(
        self,
        *shape_args: Any,
        curvature: float = ...,
        hyper_learning_rate: float = ...,
        real_learning_rate: float = ...,
        backend: str = ...,
        seed: int | None = ...,
        shape: Any | None = ...,
        rows: Any | None = ...,
        cols: Any | None = ...,
        topos: Any | None = ...,
        gain: float = ...,
        weights: Any | None = ...,
        z_dim: int = ...,
        z_lr: float = ...,
        z_lam_frac: float = ...,
        telemetry: bool = ...,
        telemetry_bound: int = ...,
    ) -> None: ...

    def shape(self) -> tuple[int, int]: ...
    def zero_grad(self) -> None: ...
    def reset(self) -> None: ...
    def step_wave(
        self,
        wave: Any,
        *,
        tune: bool = ...,
        gain: float | None = ...,
        control: Any | None = ...,
        note: str | None = ...,
    ) -> Tensor: ...

    def step_pair(
        self,
        prediction: Any,
        target: Any,
        *,
        tune: bool = ...,
        gain: float | None = ...,
        control: Any | None = ...,
        note: str | None = ...,
    ) -> Tensor: ...

    def step_text(
        self,
        encoder: Any,
        text: str,
        *,
        tune: bool = ...,
        gain: float | None = ...,
        control: Any | None = ...,
        note: str | None = ...,
    ) -> Tensor: ...

def hypergrad_session(*shape_args: Any, **kwargs: Any) -> HypergradSession: ...

def amegagrad_session(*shape_args: Any, **kwargs: Any) -> AmegagradSession: ...

hg: Any
rg: Any
z: Any

def describe_device(
    backend: str = ...,
    *,
    lane_width: Optional[int] = ...,
    subgroup: Optional[bool] = ...,
    max_workgroup: Optional[int] = ...,
    shared_mem_per_workgroup: Optional[int] = ...,
    workgroup: Optional[int] = ...,
    cols: Optional[int] = ...,
    tile_hint: Optional[int] = ...,
    compaction_hint: Optional[int] = ...,
) -> Dict[str, object]: ...

def describe_runtime_devices(
    backends: str | Iterable[str] = ...,
    *,
    continue_on_error: bool = ...,
    required_available_backends: object = ...,
    required_ready_backends: object = ...,
    lane_width: Optional[int] = ...,
    subgroup: Optional[bool] = ...,
    max_workgroup: Optional[int] = ...,
    shared_mem_per_workgroup: Optional[int] = ...,
    workgroup: Optional[int] = ...,
    cols: Optional[int] = ...,
    tile_hint: Optional[int] = ...,
    compaction_hint: Optional[int] = ...,
) -> Dict[str, object]: ...

def describe_wgpu_softmax_variants() -> None: ...

def hip_probe() -> Dict[str, object]: ...
def mps_probe() -> Dict[str, object]: ...

def probe_gpu_path(
    kind: Literal["topk", "midk", "bottomk"] = ...,
    *,
    backend: Literal["cuda", "hip"] = ...,
    rows: int = ...,
    cols: int = ...,
    k: int = ...,
) -> Dict[str, object]: ...

def gl_coeffs_adaptive(alpha: float, tol: float = ..., max_len: int = ...) -> List[float]: ...

def fracdiff_gl_1d(
    xs: Sequence[float],
    alpha: float,
    kernel_len: int,
    pad: str = ...,
    pad_constant: Optional[float] = ...,
) -> List[float]: ...

def fft_radix2(
    a: Tuple[float, float],
    b: Tuple[float, float],
    twiddle: Tuple[float, float],
) -> Tuple[Tuple[float, float], Tuple[float, float]]: ...

def fft_radix4(
    values: Sequence[Tuple[float, float]],
    twiddles: Sequence[Tuple[float, float]],
) -> List[Tuple[float, float]]: ...

def fft_complex32(
    signal: Sequence[Tuple[float, float]],
    inverse: bool = ...,
) -> List[Tuple[float, float]]: ...

def fft_real(signal: Sequence[float], inverse: bool = ...) -> List[Tuple[float, float]]: ...

def drl_default_thresholds() -> Dict[str, Dict[str, float]]: ...

def drl_analyse_word(
    word: Mapping[str, Any],
    thresholds: Mapping[str, Mapping[str, float]] | None = ...,
    *,
    hazard_cut: float | None = ...,
    min_radius: float = ...,
    direction_queries: Mapping[str, Sequence[Mapping[str, Any]]] | None = ...,
) -> Dict[str, Any]: ...

def drl_analyze_word(
    word: Mapping[str, Any],
    thresholds: Mapping[str, Mapping[str, float]] | None = ...,
    *,
    hazard_cut: float | None = ...,
    min_radius: float = ...,
    direction_queries: Mapping[str, Sequence[Mapping[str, Any]]] | None = ...,
) -> Dict[str, Any]: ...

def drl_existence_load(word: Mapping[str, Any]) -> float: ...

def drl_safe_radii(
    word: Mapping[str, Any],
    thresholds: Mapping[str, Mapping[str, float]] | None = ...,
) -> Dict[str, float]: ...

def drl_frame_hazard(
    word: Mapping[str, Any],
    frame: str | Mapping[str, Any],
) -> float: ...

def drl_trainer_penalty(metrics: Mapping[str, Any], min_radius: float = ...) -> float: ...

def drl_aggregate_penalty(
    metrics: Sequence[Mapping[str, Any]],
    min_radius: float = ...,
) -> float: ...

def drl_frame_summary(metrics: Mapping[str, Any]) -> Dict[str, float]: ...

def kv_redis_available() -> bool: ...

def kv_choice_schema_fields() -> List[str]: ...

def kv_rank_choice_key(
    rows: int,
    cols: int,
    k: int,
    subgroup: bool = ...,
    namespace: str = ...,
) -> str: ...

def kv_choice_key_from_rank_plan(plan: RankPlan, namespace: str = ...) -> str: ...

def kv_choice_from_rank_plan(plan: RankPlan) -> Dict[str, Any]: ...

def kv_json_set_options(
    *,
    expiry_seconds: int | None = ...,
    expiry_milliseconds: int | None = ...,
    expiry_at_seconds: int | None = ...,
    expiry_at_milliseconds: int | None = ...,
    keep_ttl: bool = ...,
    persist: bool = ...,
    condition: Literal["always", "nx", "xx"] = ...,
) -> Dict[str, Any]: ...

def kv_redis_set_json(
    url: str,
    key: str,
    value: Any,
    options: Mapping[str, Any] | None = ...,
) -> bool: ...

def kv_redis_get_json(url: str, key: str) -> Any: ...

def kv_redis_set_choice(
    url: str,
    key: str,
    choice: Mapping[str, Any],
    options: Mapping[str, Any] | None = ...,
) -> bool: ...

def kv_redis_get_choice(url: str, key: str) -> Dict[str, Any] | None: ...

def kv_redis_push_choice(
    url: str,
    key: str,
    choice: Mapping[str, Any],
    max_len: int | None = ...,
) -> int: ...

def kv_redis_lrange_choice(
    url: str,
    key: str,
    start: int = ...,
    stop: int = ...,
) -> List[Dict[str, Any]]: ...

class WgpuRank:
    def __init__(self, kind: Literal["topk", "midk", "bottomk"], rows: int, cols: int, k: int, *, tile_cols: int = 256, timestamp_queries: bool = False) -> None: ...
    @staticmethod
    def from_adaptation(session: RankAdaptationSession, candidate_index: int, *, timestamp_queries: bool = False) -> WgpuRank: ...
    @property
    def shape(self) -> Tuple[int, int, int]: ...
    @property
    def kind(self) -> str: ...
    @property
    def tile_cols(self) -> int: ...
    @property
    def generation(self) -> int: ...
    @property
    def output_is_current(self) -> bool: ...
    @property
    def timestamp_queries_enabled(self) -> bool: ...
    def profile(self, repetitions: int = 1) -> Dict[str, Any]: ...
    def adapter_info(self) -> Dict[str, Any]: ...
    def upload(self, input: Tensor) -> None: ...
    def set_input_from_matmul(self, source: WgpuMatmul) -> None: ...
    def dispatch_from_matmul(self, source: WgpuMatmul, repetitions: int = 1) -> int: ...
    def dispatch(self, repetitions: int = 1) -> int: ...
    def synchronize(self) -> None: ...
    def readback(self) -> Dict[str, Any]: ...

class WgpuTensorDevice:
    @staticmethod
    def create() -> WgpuTensorDevice: ...
    def upload(self, shape: Sequence[int], values: Sequence[float]) -> WgpuTensor: ...
    def adapter_info(self) -> Dict[str, Any]: ...


class WgpuTensor:
    @property
    def shape(self) -> Tuple[int, ...]: ...
    @property
    def strides(self) -> Tuple[int, ...]: ...
    @property
    def offset(self) -> int: ...
    @property
    def numel(self) -> int: ...
    @property
    def is_contiguous(self) -> bool: ...
    def device(self) -> WgpuTensorDevice: ...
    def shares_storage_with(self, other: WgpuTensor) -> bool: ...
    def reshape(self, shape: Sequence[int]) -> WgpuTensor: ...
    def permute(self, axes: Sequence[int]) -> WgpuTensor: ...
    def narrow(self, axis: int, start: int, length: int) -> WgpuTensor: ...
    def broadcast_to(self, shape: Sequence[int]) -> WgpuTensor: ...
    def contiguous(self) -> WgpuTensor: ...
    def add(self, rhs: WgpuTensor) -> WgpuTensor: ...
    def mul(self, rhs: WgpuTensor) -> WgpuTensor: ...
    def relu(self) -> WgpuTensor: ...
    def gelu(self) -> WgpuTensor: ...
    def snapshot(self) -> WgpuTensorSnapshot: ...


class WgpuTensorSnapshot:
    @property
    def shape(self) -> Tuple[int, ...]: ...
    def read_values(self) -> List[float]: ...


class WgpuMatmul:
    def __init__(self, rows: int, inner: int, cols: int, *, tile_mnk: Optional[Tuple[int, int, int]] = None, kernel: Optional[Literal["scalar", "register_2x2"]] = None, accumulation: Optional[Literal["sequential", "tiled", "compensated"]] = None) -> None: ...
    @property
    def shape(self) -> Tuple[int, int, int]: ...
    @property
    def tile_mnk(self) -> Tuple[int, int, int]: ...
    @property
    def workgroup_size(self) -> Tuple[int, int, int]: ...
    @property
    def outputs_per_thread(self) -> Tuple[int, int]: ...
    @property
    def kernel(self) -> str: ...
    @property
    def accumulation(self) -> str: ...
    @property
    def generation(self) -> int: ...
    @property
    def output_is_current(self) -> bool: ...
    def adapter_info(self) -> Dict[str, Any]: ...
    def upload(self, lhs: Tensor, rhs: Tensor) -> None: ...
    def upload_rhs(self, rhs: Tensor) -> None: ...
    def set_lhs_from(self, source: WgpuMatmul) -> None: ...
    def dispatch(self, repetitions: int = 1) -> int: ...
    def synchronize(self) -> None: ...
    def readback(self) -> Tensor: ...

def wgpu_kernel_reports_available() -> bool: ...

def wgpu_kernel_catalog() -> List[Dict[str, Any]]: ...

def wgpu_kernel_descriptor(name: str) -> Dict[str, Any] | None: ...

def wgpu_rank_kernel_report(
    kind: Literal["topk", "midk", "bottomk"],
    rows: int,
    cols: int,
    k: int,
    *,
    subgroup: bool = ...,
    use_two_stage: bool = ...,
    fft_tile: int = ...,
    fft_radix: int = ...,
    fft_segments: int = ...,
    rank_tile: int = ...,
    compaction_tile: int = ...,
) -> Dict[str, Any]: ...

def wgpu_kernel_report_from_rank_plan(plan: RankPlan) -> Dict[str, Any]: ...

def wgpu_softmax_kernel_report(
    rows: int,
    cols: int,
    *,
    subgroup: bool = ...,
    hardmax: bool = ...,
    mask: bool = ...,
) -> Dict[str, Any]: ...

def mean_squared_error(predictions: Tensor, targets: Tensor) -> float: ...

def info_nce(
    anchors: Sequence[Sequence[float]],
    positives: Sequence[Sequence[float]],
    temperature: float = ...,
    normalize: bool = ...,
) -> Dict[str, object]: ...

def masked_mse(
    predictions: Sequence[Sequence[float]],
    targets: Sequence[Sequence[float]],
    mask_indices: Sequence[Sequence[int]],
) -> Dict[str, object]: ...

class _CompatTorch(ModuleType):
    def to_torch(
        tensor: Tensor,
        *,
        dtype: object | None = ...,
        device: object | None = ...,
        requires_grad: bool | None = ...,
        copy: bool | None = ...,
        memory_format: object | None = ...,
    ) -> object: ...

    def from_torch(
        tensor: object,
        *,
        dtype: object | None = ...,
        device: object | None = ...,
        ensure_cpu: bool | None = ...,
        copy: bool | None = ...,
        require_contiguous: bool | None = ...,
    ) -> Tensor: ...

class _CompatJax(ModuleType):
    def to_jax(tensor: Tensor) -> object: ...
    def from_jax(array: object) -> Tensor: ...

class _CompatTensorFlow(ModuleType):
    def to_tensorflow(tensor: Tensor) -> object: ...
    def from_tensorflow(value: object) -> Tensor: ...

class _CompatNamespace(ModuleType):
    torch: _CompatTorch
    jax: _CompatJax
    tensorflow: _CompatTensorFlow

compat: _CompatNamespace

class TemporalResonanceBuffer:
    def __init__(self, capacity: int = ..., alpha: float = ...) -> None: ...
    @property
    def alpha(self) -> float: ...
    @property
    def capacity(self) -> int: ...
    def update(self, volume: Sequence[Sequence[Sequence[float]]]) -> List[List[List[float]]]: ...
    def state(self) -> Optional[List[List[List[float]]]]: ...
    def history(self) -> List[List[List[List[float]]]]: ...
    def state_dict(self) -> Dict[str, object]: ...
    def load_state_dict(self, state: Mapping[str, object]) -> None: ...

class SliceProfile:
    mean: float
    std: float
    energy: float

class SpiralTorchVision:
    def __init__(
        self,
        depth: int,
        height: int,
        width: int,
        *,
        alpha: float = ...,
        window: Optional[str] = ...,
        temporal: int = ...,
    ) -> None: ...
    @property
    def volume(self) -> List[List[List[float]]]: ...
    @property
    def alpha(self) -> float: ...
    @property
    def temporal_capacity(self) -> int: ...
    @property
    def temporal_state(self) -> Optional[List[List[List[float]]]]: ...
    @property
    def window(self) -> List[float]: ...
    @property
    def last_stream_metadata(self) -> Dict[str, object] | None: ...
    def reset(self) -> None: ...
    def update_window(self, window: Optional[str] | Sequence[float]) -> None: ...
    def accumulate(
        self,
        volume: (
            Sequence[Sequence[Sequence[float]]]
            | ZSpaceStreamFrame
            | StreamedVolume
            | ZSpaceStreamFrameAggregator
        ),
        weight: float = ...,
    ) -> None: ...
    def accumulate_slices(self, slices: Sequence[Sequence[Sequence[float]]]) -> None: ...
    def accumulate_sequence(
        self,
        frames: Iterable[Sequence[Sequence[Sequence[float]]]],
        weights: Optional[Sequence[float]] = ...,
    ) -> None: ...
    def project(self, *, normalise: bool = ...) -> List[List[float]]: ...
    def volume_energy(self) -> float: ...
    def slice_profile(self) -> List[SliceProfile]: ...
    def snapshot(self) -> Dict[str, object]: ...
    def state_dict(self) -> Dict[str, object]: ...
    def load_state_dict(self, state: Mapping[str, object], *, strict: bool = ...) -> None: ...

class ImageTensor:
    def __init__(self, channels: int, height: int, width: int, data: Sequence[float]) -> None: ...
    @staticmethod
    def zeros(channels: int, height: int, width: int) -> ImageTensor: ...
    @staticmethod
    def from_tensor(tensor: Tensor, channels: int, height: int, width: int) -> ImageTensor: ...
    @property
    def channels(self) -> int: ...
    @property
    def height(self) -> int: ...
    @property
    def width(self) -> int: ...
    def shape(self) -> Tuple[int, int, int]: ...
    def data(self) -> List[float]: ...
    def pixel(self, channel: int, y: int, x: int) -> float: ...
    def set_pixel(self, channel: int, y: int, x: int, value: float) -> None: ...
    def relu_inplace(self) -> None: ...
    def flatten(self) -> List[float]: ...
    def to_tensor(self) -> Tensor: ...
    def to_dict(self) -> Dict[str, object]: ...

class TransformPipeline:
    def __init__(self, *, seed: int | None = ...) -> None: ...
    @staticmethod
    def standard_classification(
        image_size: int = ...,
        *,
        seed: int | None = ...,
    ) -> TransformPipeline: ...
    def add_normalize(self, means: Sequence[float], stds: Sequence[float]) -> None: ...
    def add_resize(self, height: int, width: int) -> None: ...
    def add_center_crop(self, height: int, width: int) -> None: ...
    def add_horizontal_flip(self, probability: float = ...) -> None: ...
    def add_color_jitter(
        self,
        *,
        brightness: float = ...,
        contrast: float = ...,
        saturation: float = ...,
        hue: float = ...,
    ) -> None: ...
    def operations(self) -> List[str]: ...
    def __len__(self) -> int: ...
    def len(self) -> int: ...
    def is_empty(self) -> bool: ...
    def has_gpu_dispatcher(self) -> bool: ...
    def apply(self, image: ImageTensor) -> ImageTensor: ...
    def apply_inplace(self, image: ImageTensor) -> None: ...
    def audit(self) -> Dict[str, object]: ...

class VisionSample:
    def __init__(
        self,
        image: ImageTensor,
        *,
        target: Tensor | None = ...,
        label: str | None = ...,
        boxes: Sequence[Tuple[float, float, float, float]] | None = ...,
        masks: Sequence[ImageTensor] | None = ...,
    ) -> None: ...
    @property
    def image(self) -> ImageTensor: ...
    @property
    def target(self) -> Tensor | None: ...
    @property
    def label(self) -> str | None: ...
    @property
    def boxes(self) -> List[Tuple[float, float, float, float]] | None: ...
    @property
    def masks(self) -> List[ImageTensor] | None: ...
    def to_dict(self) -> Dict[str, object]: ...

class TensorVisionDataset:
    def __init__(self, descriptor: str = ...) -> None: ...
    def descriptor(self) -> Dict[str, object]: ...
    def push_sample(self, sample: VisionSample) -> None: ...
    def push(
        self,
        image: ImageTensor,
        *,
        target: Tensor | None = ...,
        label: str | None = ...,
        boxes: Sequence[Tuple[float, float, float, float]] | None = ...,
        masks: Sequence[ImageTensor] | None = ...,
    ) -> None: ...
    def get(self, index: int) -> VisionSample: ...
    def __len__(self) -> int: ...
    def len(self) -> int: ...
    def is_empty(self) -> bool: ...
    def dataloader(
        self,
        batch_size: int,
        *,
        seed: int | None = ...,
        pipeline: TransformPipeline | None = ...,
        shuffle: bool = ...,
    ) -> VisionDataLoader: ...

class VisionBatch:
    def __len__(self) -> int: ...
    def len(self) -> int: ...
    def is_empty(self) -> bool: ...
    def images(self) -> List[ImageTensor]: ...
    def targets(self) -> List[Tensor | None]: ...
    def labels(self) -> List[str | None]: ...
    def boxes(self) -> List[List[Tuple[float, float, float, float]] | None]: ...
    def stack(self) -> Tensor: ...
    def to_dict(self) -> Dict[str, object]: ...

class VisionDataLoader:
    def reset(self) -> None: ...
    def enable_shuffle(self, shuffle: bool) -> None: ...
    def next_batch(self) -> VisionBatch | None: ...

class VisionModel:
    def metadata(self) -> Dict[str, object]: ...
    def forward(self, images: Sequence[ImageTensor]) -> Tensor: ...
    def extract_features(self, stage: str, image: ImageTensor) -> Tensor: ...

class CanvasTransformer:
    def __init__(self, width: int, height: int, *, smoothing: float = ...) -> None: ...
    @property
    def smoothing(self) -> float: ...
    def refresh(self, projection: Sequence[Sequence[float]]) -> List[List[float]]: ...
    def accumulate_hypergrad(self, gradient: Sequence[Sequence[float]]) -> None: ...
    def accumulate_realgrad(self, gradient: Sequence[Sequence[float]]) -> None: ...
    def reset(self) -> None: ...
    def gradient_summary(self) -> Dict[str, Dict[str, float]]: ...
    def emit_zspace_patch(self, vision: SpiralTorchVision, weight: float = ...) -> List[List[float]]: ...
    def canvas(self) -> List[List[float]]: ...
    def hypergrad(self) -> List[List[float]]: ...
    def realgrad(self) -> List[List[float]]: ...
    def state_dict(self) -> Dict[str, object]: ...
    def load_state_dict(self, state: Mapping[str, object], *, strict: bool = ...) -> None: ...
    def snapshot(self) -> CanvasSnapshot: ...

class CanvasSnapshot:
    canvas: List[List[float]]
    hypergrad: List[List[float]]
    realgrad: List[List[float]]
    summary: Dict[str, Dict[str, float]]
    patch: Optional[List[List[float]]]

class ChronoSnapshot:
    def __init__(
        self,
        summary: Mapping[str, object] | object,
        *,
        dt: float = ...,
    ) -> None: ...
    @staticmethod
    def from_values(
        *,
        frames: int,
        duration: float,
        latest_timestamp: float,
        mean_drift: float,
        mean_abs_drift: float,
        drift_std: float,
        mean_energy: float,
        energy_std: float,
        mean_decay: float,
        min_energy: float,
        max_energy: float,
        dt: float = ...,
    ) -> ChronoSnapshot: ...
    @property
    def timestamp(self) -> float: ...
    @property
    def dt(self) -> float: ...
    def summary(self) -> Dict[str, object]: ...
    def to_dict(self) -> Dict[str, object]: ...

class ZSpaceStreamFrame:
    def __init__(
        self,
        slices: Sequence[Tensor],
        *,
        atlas_frame: AtlasFrame | None = ...,
        chrono_snapshot: ChronoSnapshot | None = ...,
    ) -> None: ...
    @property
    def depth(self) -> int: ...
    @property
    def slice_shape(self) -> Tuple[int, int]: ...
    def slices(self) -> List[Tensor]: ...
    def with_atlas(self, frame: AtlasFrame) -> None: ...
    def with_snapshot(self, snapshot: ChronoSnapshot) -> None: ...
    @property
    def atlas_frame(self) -> AtlasFrame | None: ...
    @property
    def chrono_snapshot(self) -> ChronoSnapshot | None: ...
    def profile(self) -> Dict[str, object]: ...
    def telemetry_report(self) -> Dict[str, object]: ...
    def to_streamed_volume(self) -> StreamedVolume: ...
    def into_streamed_volume(self) -> StreamedVolume: ...
    def to_dict(self) -> Dict[str, object]: ...

class StreamedVolume:
    @staticmethod
    def from_frame(frame: ZSpaceStreamFrame) -> StreamedVolume: ...
    @property
    def depth(self) -> int: ...
    @property
    def slice_shape(self) -> Tuple[int, int]: ...
    def slices(self) -> List[Tensor]: ...
    @property
    def atlas_frame(self) -> AtlasFrame | None: ...
    @property
    def chrono_snapshot(self) -> ChronoSnapshot | None: ...
    def profile(self) -> Dict[str, object]: ...
    def telemetry_report(self) -> Dict[str, object]: ...
    def ingest_frame(
        self,
        frame: ZSpaceStreamFrame,
        *,
        alpha: float = ...,
    ) -> StreamedVolume: ...
    def to_dict(self) -> Dict[str, object]: ...

class ZSpaceStreamFrameAggregator:
    def __init__(self, *, max_depth: int | None = ...) -> None: ...
    @staticmethod
    def with_max_depth(max_depth: int) -> ZSpaceStreamFrameAggregator: ...
    @property
    def max_depth(self) -> int | None: ...
    def set_max_depth(self, max_depth: int | None) -> None: ...
    def __len__(self) -> int: ...
    def len(self) -> int: ...
    def is_empty(self) -> bool: ...
    @property
    def slice_shape(self) -> Tuple[int, int] | None: ...
    @property
    def atlas_frame(self) -> AtlasFrame | None: ...
    @property
    def chrono_snapshot(self) -> ChronoSnapshot | None: ...
    def extend(self, frame: ZSpaceStreamFrame) -> None: ...
    def clear(self) -> None: ...
    def prune_oldest(self, keep: int) -> None: ...
    def as_frame(self) -> ZSpaceStreamFrame | None: ...
    def drain_frame(self) -> ZSpaceStreamFrame | None: ...
    def to_streamed_volume(self) -> StreamedVolume | None: ...
    def telemetry_report(self) -> Dict[str, object] | None: ...
    def profile(self) -> Dict[str, object] | None: ...

class InfiniteZSpacePatch:
    @property
    def dimension(self) -> float: ...
    @property
    def zoom(self) -> float: ...
    @property
    def support(self) -> Tuple[float, float]: ...
    @property
    def mellin_weights(self) -> List[float]: ...
    @property
    def density(self) -> List[float]: ...
    def eta_bar(self) -> float: ...

class FractalCanvas:
    def __init__(
        self,
        dimension: float = ...,
        capacity: int = ...,
        width: int = ...,
        height: int = ...,
    ) -> None: ...
    @property
    def dimension(self) -> float: ...
    def set_dimension(self, dimension: float) -> None: ...
    def emit_zspace_patch(
        self,
        dimension: Optional[float] = ...,
        zoom: Optional[float] = ...,
        steps: Optional[int] = ...,
    ) -> InfiniteZSpacePatch: ...
    def emit_zspace_infinite(
        self,
        dimension: Optional[float] = ...,
    ) -> InfiniteZSpacePatch: ...
    def emit_infinite_z(
        self,
        zoom: Optional[float] = ...,
        steps: Optional[int] = ...,
        dimension: Optional[float] = ...,
    ) -> InfiniteZSpacePatch: ...

class CanvasProjector:
    def __init__(
        self,
        width: int = ...,
        height: int = ...,
        *,
        capacity: int = ...,
        palette: str = ...,
    ) -> None: ...

    @property
    def width(self) -> int: ...

    @property
    def height(self) -> int: ...

    def queue_len(self) -> int: ...
    def total_weight(self) -> float: ...

    def palette(self) -> str: ...
    def set_palette(self, name: str) -> None: ...
    def reset_normalizer(self) -> None: ...

    def push_patch(
        self,
        relation: Tensor | Sequence[Sequence[float]],
        *,
        coherence: float = ...,
        tension: float = ...,
        depth: int = ...,
    ) -> None: ...

    def emit_zspace_patch(
        self,
        *,
        coherence: float = ...,
        tension: float = ...,
        depth: int = ...,
    ) -> Dict[str, object]: ...

    def emit_wasm_trail(self, curvature: float = ...) -> Dict[str, object]: ...

    def emit_atlas_frame(
        self,
        *,
        prefix: str = ...,
        refresh: bool = ...,
        timestamp: float | None = ...,
    ) -> AtlasFrame: ...

    def clear_queue(self) -> None: ...

    def rgba(self) -> bytes: ...
    def refresh_rgba(self) -> bytes: ...

    def tensor(self) -> Tensor: ...
    def refresh_tensor(self) -> Tensor: ...

    def refresh_vector_fft_tensor(self, *, inverse: bool = ...) -> Tensor: ...
    def refresh_vector_fft_power_db_tensor(self, *, inverse: bool = ...) -> Tensor: ...

class CanvasZSpacePatch:
    relation: Tensor
    coherence: float
    tension: float
    depth: int
    weight: float

    def to_dict(self) -> Dict[str, object]: ...

class CanvasWasmTrail:
    curvature: float
    width: int
    height: int
    samples: Tensor

    def to_dict(self) -> Dict[str, object]: ...

class QuantumOverlayConfig:
    def __init__(
        self,
        curvature: float = ...,
        qubits: int = ...,
        packing_bias: float = ...,
        leech_shells: int = ...,
    ) -> None: ...
    @property
    def curvature(self) -> float: ...
    def set_curvature(self, curvature: float) -> None: ...
    @property
    def qubits(self) -> int: ...
    def set_qubits(self, qubits: int) -> None: ...
    @property
    def packing_bias(self) -> float: ...
    def set_packing_bias(self, packing_bias: float) -> None: ...
    @property
    def leech_shells(self) -> int: ...
    def set_leech_shells(self, leech_shells: int) -> None: ...

class ZResonance:
    def __init__(
        self,
        spectrum: Optional[Sequence[float]] = ...,
        eta_hint: float = ...,
        shell_weights: Optional[Sequence[float]] = ...,
    ) -> None: ...
    @staticmethod
    def from_spectrum(
        spectrum: Sequence[float],
        eta_hint: Optional[float] = ...,
    ) -> ZResonance: ...
    @staticmethod
    def from_pulses(pulses: Sequence[MaxwellPulse]) -> ZResonance: ...
    @property
    def spectrum(self) -> List[float]: ...
    @property
    def eta_hint(self) -> float: ...
    @property
    def shell_weights(self) -> List[float]: ...

class QuantumMeasurement:
    @property
    def active_qubits(self) -> List[int]: ...
    @property
    def eta_bar(self) -> float: ...
    @property
    def policy_logits(self) -> List[float]: ...
    @property
    def packing_pressure(self) -> float: ...
    def top_qubits(self, count: Optional[int] = ...) -> List[Tuple[int, float]]: ...
    def activation_density(self) -> float: ...
    def to_policy_update(self, base_rate: float = ...) -> Dict[str, float]: ...

class ZOverlayCircuit:
    def weights(self) -> List[float]: ...
    def eta_bar(self) -> float: ...
    def packing_pressure(self) -> float: ...
    def measure(self, threshold: float = ...) -> QuantumMeasurement: ...

class QuantumRealityStudio:
    def __init__(
        self,
        curvature: float = ...,
        qubits: int = ...,
        packing_bias: float = ...,
        leech_shells: int = ...,
    ) -> None: ...
    @property
    def config(self) -> QuantumOverlayConfig: ...
    def configure(
        self,
        *,
        curvature: Optional[float] = ...,
        qubits: Optional[int] = ...,
        packing_bias: Optional[float] = ...,
        leech_shells: Optional[int] = ...,
    ) -> None: ...
    def overlay_zspace(self, resonance: ZResonance) -> ZOverlayCircuit: ...
    def overlay(self, resonance: ZResonance) -> ZOverlayCircuit: ...
    def record_quantum_policy(
        self,
        pulses: Sequence[MaxwellPulse],
        *,
        threshold: float = ...,
    ) -> QuantumMeasurement: ...

class FractalQuantumSession:
    def __init__(
        self,
        studio: QuantumRealityStudio,
        *,
        threshold: float = ...,
        eta_scale: float = ...,
    ) -> None: ...
    @property
    def threshold(self) -> float: ...
    @property
    def eta_scale(self) -> float: ...
    @property
    def ingested(self) -> int: ...
    def ingest(
        self,
        patch: InfiniteZSpacePatch,
        *,
        weight: float = ...,
    ) -> ZResonance: ...
    def resonance(self) -> ZResonance: ...
    def measure(self, *, threshold: Optional[float] = ...) -> QuantumMeasurement: ...
    def clear(self) -> None: ...

def resonance_from_fractal_patch(
    patch: InfiniteZSpacePatch,
    eta_scale: float = ...,
) -> ZResonance: ...

def quantum_measurement_from_fractal(
    studio: QuantumRealityStudio,
    patch: InfiniteZSpacePatch,
    threshold: float = ...,
    eta_scale: float = ...,
) -> QuantumMeasurement: ...

def quantum_measurement_from_fractal_sequence(
    studio: QuantumRealityStudio,
    patches: Sequence[InfiniteZSpacePatch],
    *,
    weights: Optional[Sequence[float]] = ...,
    threshold: float = ...,
    eta_scale: float = ...,
) -> QuantumMeasurement: ...

class ZTigerOptim:
    def __init__(self, curvature: float = ...) -> None: ...
    @property
    def curvature(self) -> float: ...
    @property
    def gain(self) -> float: ...
    def update(self, lora_pid: float, resonance: Sequence[float]) -> float: ...

def tempo_latency_score(tile: int, slack: int) -> float: ...

def apply_vision_update(
    vision: SpiralTorchVision,
    canvas: CanvasTransformer,
    *,
    hypergrad: Optional[Sequence[Sequence[float]]] = ...,
    realgrad: Optional[Sequence[Sequence[float]]] = ...,
    weight: float = ...,
    include_patch: bool = ...,
) -> CanvasSnapshot: ...

def vision_dataset_catalog() -> List[Dict[str, object]]: ...

def vision_dataset_descriptor(name: str) -> Dict[str, object] | None: ...

def vision_model_catalog() -> List[Dict[str, object]]: ...

def vision_model_descriptor(name: str) -> Dict[str, object] | None: ...

def vision_transform_audit_catalog() -> List[Dict[str, object]]: ...

def vision_standard_classification_pipeline(
    image_size: int = ...,
    *,
    seed: int | None = ...,
) -> TransformPipeline: ...

def vision_create_classification_model(
    kind: str,
    num_classes: int = ...,
    *,
    seed: int | None = ...,
) -> VisionModel: ...

def zrelativity_heatmap(
    model: ZRelativityModel,
    field: str,
) -> List[List[float]]: ...

def set_global_seed(seed: int) -> None: ...

def golden_ratio() -> float: ...

def golden_angle() -> float: ...

def fibonacci_pacing(total_steps: int) -> List[int]: ...

def pack_nacci_chunks(order: int, total_steps: int) -> List[int]: ...

def pack_tribonacci_chunks(total_steps: int) -> List[int]: ...

def pack_tetranacci_chunks(total_steps: int) -> List[int]: ...

def build_info() -> Dict[str, object]: ...

def generate_plan_batch_ex(
    n: int,
    total_steps: int,
    base_radius: float,
    radial_growth: float,
    base_height: float,
    meso_gain: float,
    micro_gain: float,
    seed: Optional[int] = ...,
) -> List[SoT3DPlan]: ...


class SoT3DStep:
    @property
    def index(self) -> int: ...

    @property
    def x(self) -> float: ...

    @property
    def y(self) -> float: ...

    @property
    def height(self) -> float: ...

    @property
    def macro_index(self) -> int: ...

    @property
    def meso_role(self) -> str: ...

    @property
    def micro_role(self) -> str: ...

    def as_dict(self) -> Dict[str, object]: ...


class MacroSummary:
    @property
    def index(self) -> int: ...

    @property
    def start(self) -> int: ...

    @property
    def length(self) -> int: ...

    def as_dict(self) -> Dict[str, object]: ...


class SoT3DPlan:
    @property
    def total_steps(self) -> int: ...

    @property
    def base_radius(self) -> float: ...

    @property
    def radial_growth(self) -> float: ...

    def steps(self) -> List[SoT3DStep]: ...

    def as_dicts(self) -> List[Dict[str, object]]: ...

    def as_tensor(self) -> Tensor: ...

    def feature_tensor(self) -> Tensor: ...

    def role_tensor(self) -> Tensor: ...

    def reflection_tensor(self) -> Tensor: ...

    def macro_summary_tensor(self) -> Tensor: ...

    def macro_summaries(self) -> List[MacroSummary]: ...

    def polyline(self) -> List[Tuple[float, float, float]]: ...

    def reflection_points(self) -> List[Tuple[int, str]]: ...

    def grow_biome(
        self,
        topos: OpenCartesianTopos,
        label_prefix: str | None = ...,
        include_reflections: bool = ...,
        include_roles: bool = ...,
    ) -> TensorBiome: ...

    def infuse_biome(
        self,
        biome: TensorBiome,
        label_prefix: str | None = ...,
        include_reflections: bool = ...,
        include_roles: bool = ...,
    ) -> None: ...


class _NnNonLiner:
    def __init__(
        self,
        name: str,
        features: int,
        *,
        activation: str = ...,
        slope: float = ...,
        gain: float = ...,
        bias: float = ...,
        curvature: float | None = ...,
        z_scale: float | None = ...,
        retention: float = ...,
    ) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def __call__(self, x: Tensor) -> Tensor: ...

    def reset_metrics(self) -> None: ...

    def configure_geometry(
        self,
        *,
        curvature: float | None = ...,
        z_scale: float | None = ...,
        retention: float | None = ...,
    ) -> None: ...

    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def attach_realgrad(self, learning_rate: float) -> None: ...

    def zero_accumulators(self) -> None: ...

    def apply_step(self, fallback_lr: float) -> None: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    @property
    def activation(self) -> str: ...

    @property
    def curvature(self) -> float | None: ...

    @property
    def z_scale(self) -> float | None: ...

    @property
    def retention(self) -> float | None: ...

    @property
    def psi_drift(self) -> float | None: ...

    @property
    def last_hyperbolic_radius(self) -> float | None: ...

    @property
    def gain(self) -> Tensor: ...

    @property
    def slope(self) -> Tensor: ...

    @property
    def bias(self) -> Tensor: ...

    def gradients(self) -> Tuple[Tensor | None, Tensor | None, Tensor | None]: ...


class _NnDropout:
    def __init__(
        self,
        probability: float,
        *,
        seed: int | None = ...,
        training: bool = ...,
    ) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def __call__(self, x: Tensor) -> Tensor: ...

    def set_training(self, training: bool) -> None: ...

    def train(self) -> None: ...

    def eval(self) -> None: ...

    @property
    def probability(self) -> float: ...

    @property
    def training(self) -> bool: ...


class _NnDataset:
    def __init__(self) -> None: ...

    @staticmethod
    def from_pairs(samples: Sequence[Tuple[Tensor, Tensor]]) -> _NnDataset: ...

    def push(self, input: Tensor, target: Tensor) -> None: ...

    def len(self) -> int: ...

    def is_empty(self) -> bool: ...

    def loader(self) -> _NnDataLoader: ...

    def __len__(self) -> int: ...


class _NnDataLoader:
    def len(self) -> int: ...

    def __len__(self) -> int: ...

    def is_empty(self) -> bool: ...

    def batch_size(self) -> int: ...

    def prefetch_depth(self) -> int: ...

    def shuffle(self, seed: int) -> _NnDataLoader: ...

    def batched(self, batch_size: int) -> _NnDataLoader: ...

    def dynamic_batch_by_rows(self, max_rows: int) -> _NnDataLoader: ...

    def prefetch(self, depth: int) -> _NnDataLoader: ...

    def iter(self) -> _NnDataLoaderIter: ...

    def __iter__(self) -> _NnDataLoaderIter: ...


class _NnDataLoaderIter(Iterable[Tuple[Tensor, Tensor]]):
    def __iter__(self) -> _NnDataLoaderIter: ...

    def __next__(self) -> Tuple[Tensor, Tensor]: ...

class CoherenceChannelReport:
    channel: int
    weight: float
    backend: str
    dominant_concept: str | None
    emphasis: float
    descriptor: str | None


class CoherenceSignature:
    dominant_channel: int | None
    energy_ratio: float
    entropy: float
    normalized_entropy: float
    concentration: float
    effective_channels: float
    channels: int
    mean_coherence: float
    swap_invariant: bool
    label: str
    classification_kind: str
    classification_contract_version: str
    classification_semantic_owner: str
    classification_semantic_backend: str
    classification_formula: str
    classification_reason: str
    background_energy_ratio_max: float
    cascade_energy_ratio_min: float


class CoherenceObservation:
    is_signature: bool
    label: str
    signature: CoherenceSignature | None


class CoherenceDiagnostics:
    channel_weights: List[float]
    normalized_weights: List[float]
    normalization: float
    fractional_order: float
    repaired_non_finite_weights: int
    repaired_negative_weights: int
    repaired_weights_total: int
    dominant_channel: int | None
    mean_coherence: float
    z_bias: float
    energy_ratio: float
    coherence_entropy: float
    aggregated: Tensor
    coherence: List[float]
    channel_reports: List[CoherenceChannelReport]
    preserved_channels: int
    discarded_channels: int
    pre_discard: PreDiscardTelemetry | None
    observation: CoherenceObservation
    classification: Dict[str, object]
    control: Dict[str, object]
    noncollapse_snapshot: NonCollapseSnapshot
    def classify(
        self,
        *,
        background_energy_ratio_max: float = ...,
        cascade_energy_ratio_min: float = ...,
    ) -> Dict[str, object]: ...


class LinguisticContour:
    coherence_strength: float
    articulation_bias: float
    prosody_index: float
    timbre_spread: float


class PreDiscardTelemetry:
    dominance_ratio: float
    energy_floor: float
    discarded: int
    preserved: int
    used_fallback: bool
    total: int
    preserved_ratio: float
    discarded_ratio: float
    survivor_energy: float
    discarded_energy: float
    total_energy: float
    survivor_energy_ratio: float
    discarded_energy_ratio: float
    dominant_weight: float


class PreDiscardSnapshot:
    step: int
    telemetry: PreDiscardTelemetry
    survivors: List[int]
    discarded: List[int]
    filtered: List[float]


class PreDiscardPolicy:
    def __init__(
        self,
        dominance_ratio: float,
        *,
        energy_floor: float | None = ...,
        min_channels: int | None = ...,
    ) -> None: ...

    dominance_ratio: float
    energy_floor: float
    min_channels: int


class MellinBasis:
    def __init__(self, exponents: Sequence[float]) -> None: ...

    @staticmethod
    def constant(dimension: int, exponent: float) -> MellinBasis: ...

    @staticmethod
    def ramp(dimension: int, start: float, end: float) -> MellinBasis: ...

    def project(self, input: Sequence[float]) -> List[float]: ...

    @property
    def dimension(self) -> int: ...


class ZSpaceVaeStats:
    recon_loss: float
    kl_loss: float
    evidence_lower_bound: float
    target: List[float]


class ZSpaceVaeBatchStats:
    batch_size: int
    recon_loss: float
    kl_loss: float
    evidence_lower_bound: float
    weighted_loss: float
    kl_weight: float
    learning_rate: float
    gradient_l2: float
    clipped_gradient_l2: float
    update_l2: float
    optimizer_step: int
    optimizer: str


class ZSpaceVaeState:
    latent: List[float]
    reconstruction: List[float]
    mu: List[float]
    logvar: List[float]
    stats: ZSpaceVaeStats


class ZSpaceVae:
    def __init__(self, input_dim: int, latent_dim: int, seed: int = ...) -> None: ...

    @staticmethod
    def load(path: str) -> ZSpaceVae: ...

    def save(self, path: str) -> None: ...

    def configure_optimizer(
        self,
        *,
        optimizer: str = ...,
        beta1: float = ...,
        beta2: float = ...,
        epsilon: float = ...,
        rms_decay: float = ...,
        grad_clip: Optional[float] = ...,
    ) -> None: ...
    def reset_optimizer(self) -> None: ...
    def forward(self, input: Sequence[float]) -> ZSpaceVaeState: ...
    def forward_mean(self, input: Sequence[float]) -> ZSpaceVaeState: ...
    def train_step(
        self,
        input: Sequence[float],
        learning_rate: float,
        kl_weight: float = ...,
    ) -> ZSpaceVaeState: ...
    def train_batch(
        self,
        batch: Sequence[Sequence[float]],
        learning_rate: float,
        kl_weight: float = ...,
    ) -> ZSpaceVaeBatchStats: ...
    def evaluate_batch(
        self,
        batch: Sequence[Sequence[float]],
        kl_weight: float = ...,
    ) -> ZSpaceVaeBatchStats: ...

    def encode(self, input: Sequence[float]) -> Tuple[List[float], List[float]]: ...

    def encode_with_mellin(
        self,
        input: Sequence[float],
        basis: MellinBasis,
    ) -> Tuple[List[float], List[float]]: ...

    def sample_latent(self, mu: Sequence[float], logvar: Sequence[float]) -> List[float]: ...

    def mean_latent(self, mu: Sequence[float]) -> List[float]: ...

    def decode(self, latent: Sequence[float]) -> List[float]: ...

    def decode_with_mellin(self, latent: Sequence[float], basis: MellinBasis) -> List[float]: ...

    def refine_decoder(self, state: ZSpaceVaeState, learning_rate: float) -> None: ...

    @property
    def input_dim(self) -> int: ...

    @property
    def latent_dim(self) -> int: ...
    @property
    def optimizer(self) -> str: ...
    @property
    def optimizer_step(self) -> int: ...


class ZSpaceTextVae:
    def __init__(
        self,
        window_chars: int,
        latent_dim: int,
        *,
        curvature: float = ...,
        temperature: float = ...,
        seed: int = ...,
    ) -> None: ...

    @staticmethod
    def load(path: str) -> ZSpaceTextVae: ...

    def save(self, path: str) -> None: ...
    def configure_optimizer(
        self,
        *,
        optimizer: str = ...,
        beta1: float = ...,
        beta2: float = ...,
        epsilon: float = ...,
        rms_decay: float = ...,
        grad_clip: Optional[float] = ...,
    ) -> None: ...
    def reset_optimizer(self) -> None: ...

    def encode_text(self, text: str) -> List[float]: ...
    def encode_text_with_mellin(self, text: str, basis: MellinBasis) -> List[float]: ...
    def forward_text(self, text: str) -> ZSpaceVaeState: ...
    def forward_mean_text(self, text: str) -> ZSpaceVaeState: ...
    def forward_text_with_mellin(self, text: str, basis: MellinBasis) -> ZSpaceVaeState: ...
    def forward_mean_text_with_mellin(
        self,
        text: str,
        basis: MellinBasis,
    ) -> ZSpaceVaeState: ...
    def forward_encoded(self, encoded: Sequence[float]) -> ZSpaceVaeState: ...
    def forward_mean_encoded(self, encoded: Sequence[float]) -> ZSpaceVaeState: ...
    def train_encoded(
        self,
        encoded: Sequence[float],
        learning_rate: float,
        kl_weight: float = ...,
    ) -> ZSpaceVaeState: ...
    def train_encoded_batch(
        self,
        encoded: Sequence[Sequence[float]],
        learning_rate: float,
        kl_weight: float = ...,
    ) -> ZSpaceVaeBatchStats: ...
    def evaluate_encoded_batch(
        self,
        encoded: Sequence[Sequence[float]],
        kl_weight: float = ...,
    ) -> ZSpaceVaeBatchStats: ...
    def train_text(
        self,
        text: str,
        learning_rate: float,
        kl_weight: float = ...,
    ) -> ZSpaceVaeState: ...
    def train_text_with_mellin(
        self,
        text: str,
        basis: MellinBasis,
        learning_rate: float,
        kl_weight: float = ...,
    ) -> ZSpaceVaeState: ...
    def train_text_batch(
        self,
        texts: Sequence[str],
        learning_rate: float,
        kl_weight: float = ...,
    ) -> ZSpaceVaeBatchStats: ...
    def train_text_batch_with_mellin(
        self,
        texts: Sequence[str],
        basis: MellinBasis,
        learning_rate: float,
        kl_weight: float = ...,
    ) -> ZSpaceVaeBatchStats: ...
    def evaluate_text_batch(
        self,
        texts: Sequence[str],
        kl_weight: float = ...,
    ) -> ZSpaceVaeBatchStats: ...
    def evaluate_text_batch_with_mellin(
        self,
        texts: Sequence[str],
        basis: MellinBasis,
        kl_weight: float = ...,
    ) -> ZSpaceVaeBatchStats: ...
    def refine_decoder(self, state: ZSpaceVaeState, learning_rate: float) -> None: ...

    @property
    def window_chars(self) -> int: ...

    @property
    def input_dim(self) -> int: ...

    @property
    def latent_dim(self) -> int: ...

    @property
    def curvature(self) -> float: ...

    @property
    def temperature(self) -> float: ...
    @property
    def optimizer(self) -> str: ...


class ZConv:
    def __init__(
        self,
        name: str,
        in_channels: int,
        out_channels: int,
        kernel: Tuple[int, int],
        *,
        stride: Tuple[int, int] = ...,
        padding: Tuple[int, int] = ...,
        dilation: Tuple[int, int] = ...,
        input_hw: Tuple[int, int],
        layout: Literal["NCHW", "NHWC"] = ...,
    ) -> None: ...

    def forward(self, x: Tensor) -> Tensor: ...
    def backward(self, x: Tensor, grad_output: Tensor) -> Tensor: ...
    def __call__(self, x: Tensor) -> Tensor: ...
    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...
    def attach_realgrad(self, learning_rate: float) -> None: ...
    def zero_accumulators(self) -> None: ...
    def apply_step(self, fallback_lr: float) -> None: ...
    def state_dict(self) -> List[Tuple[str, Tensor]]: ...
    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    @property
    def layout(self) -> Literal["NCHW", "NHWC"]: ...

    @property
    def in_channels(self) -> int: ...

    @property
    def out_channels(self) -> int: ...

    @property
    def input_hw(self) -> Tuple[int, int]: ...

    @property
    def output_hw(self) -> Tuple[int, int]: ...

    @property
    def output_shape(self) -> Tuple[int, int, int]: ...

    @property
    def kernel(self) -> Tuple[int, int]: ...

    @property
    def stride(self) -> Tuple[int, int]: ...

    @property
    def padding(self) -> Tuple[int, int]: ...

    @property
    def dilation(self) -> Tuple[int, int]: ...

    @property
    def psi_drift(self) -> float | None: ...


class ZConv6DA:
    def __init__(
        self,
        name: str,
        in_channels: int,
        out_channels: int,
        grid: Tuple[int, int, int],
        *,
        leech_rank: int = ...,
        leech_weight: float = ...,
        layout: Literal["NCDHW", "NDHWC"] = ...,
        neighbors: Sequence[Tuple[int, int, int]] | None = ...,
    ) -> None: ...

    def forward(self, x: Tensor) -> Tensor: ...
    def backward(self, x: Tensor, grad_output: Tensor) -> Tensor: ...
    def __call__(self, x: Tensor) -> Tensor: ...
    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...
    def attach_realgrad(self, learning_rate: float) -> None: ...
    def zero_accumulators(self) -> None: ...
    def apply_step(self, fallback_lr: float) -> None: ...
    def state_dict(self) -> List[Tuple[str, Tensor]]: ...
    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...
    def leech_enrich(self, geodesic: float) -> float: ...

    @staticmethod
    def ramanujan_pi_boost() -> float: ...

    @property
    def layout(self) -> Literal["NCDHW", "NDHWC"]: ...

    @property
    def grid(self) -> Tuple[int, int, int]: ...

    @property
    def in_channels(self) -> int: ...

    @property
    def out_channels(self) -> int: ...

    @property
    def neighbor_count(self) -> int: ...

    @property
    def neighbor_offsets(self) -> List[Tuple[int, int, int]]: ...

    @property
    def leech_rank(self) -> int: ...

    @property
    def leech_weight(self) -> float: ...

    @property
    def input_shape(self) -> Tuple[int, int, int, int]: ...

    @property
    def output_shape(self) -> Tuple[int, int, int, int]: ...

    @property
    def ramanujan_pi_delta(self) -> float: ...


class Pool2d:
    def __init__(
        self,
        mode: Literal["max", "avg"],
        channels: int,
        height: int,
        width: int,
        kernel: Tuple[int, int],
        *,
        stride: Tuple[int, int] | None = ...,
        padding: Tuple[int, int] | None = ...,
        layout: Literal["NCHW", "NHWC"] = ...,
    ) -> None: ...

    def forward(self, x: Tensor) -> Tensor: ...
    def backward(self, x: Tensor, grad_output: Tensor) -> Tensor: ...
    def __call__(self, x: Tensor) -> Tensor: ...

    @property
    def mode(self) -> Literal["max", "avg"]: ...

    @property
    def layout(self) -> Literal["NCHW", "NHWC"]: ...

    @property
    def kernel(self) -> Tuple[int, int]: ...

    @property
    def stride(self) -> Tuple[int, int]: ...

    @property
    def padding(self) -> Tuple[int, int]: ...

    @property
    def input_shape(self) -> Tuple[int, int, int]: ...

    @property
    def output_shape(self) -> Tuple[int, int, int]: ...

    def set_layout(self, layout: Literal["NCHW", "NHWC"]) -> None: ...


class ZPooling:
    def __init__(
        self,
        channels: int,
        kernel: Tuple[int, int],
        input_hw: Tuple[int, int],
        *,
        stride: Tuple[int, int] | None = ...,
        padding: Tuple[int, int] = ...,
        layout: Literal["NCHW", "NHWC"] = ...,
        mode: Literal["max", "avg"] = ...,
    ) -> None: ...

    def forward(self, x: Tensor) -> Tensor: ...
    def backward(self, x: Tensor, grad_output: Tensor) -> Tensor: ...
    def __call__(self, x: Tensor) -> Tensor: ...

    @property
    def mode(self) -> Literal["max", "avg"]: ...

    @property
    def layout(self) -> Literal["NCHW", "NHWC"]: ...

    @property
    def channels(self) -> int: ...

    @property
    def input_hw(self) -> Tuple[int, int]: ...

    @property
    def output_hw(self) -> Tuple[int, int]: ...

    @property
    def kernel(self) -> Tuple[int, int]: ...

    @property
    def stride(self) -> Tuple[int, int]: ...

    @property
    def padding(self) -> Tuple[int, int]: ...


class _ZSpaceCoherenceSequencer:
    def __init__(
        self,
        dim: int,
        num_heads: int,
        curvature: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def forward(self, x: Tensor) -> Tensor: ...

    def forward_with_coherence(self, x: Tensor) -> Tuple[Tensor, List[float]]: ...

    def forward_with_diagnostics(
        self, x: Tensor
    ) -> Tuple[Tensor, List[float], CoherenceDiagnostics]: ...

    def emit_linguistic_contour(self, x: Tensor) -> LinguisticContour: ...

    def project_to_zspace(self, x: Tensor) -> Tensor: ...

    def configure_pre_discard(
        self,
        dominance_ratio: float,
        *,
        energy_floor: float | None = ..., 
        min_channels: int | None = ...,
    ) -> None: ...

    def disable_pre_discard(self) -> None: ...

    def configure_pre_discard_memory(self, limit: int) -> None: ...

    def clear_pre_discard_snapshots(self) -> None: ...

    def __call__(self, x: Tensor) -> Tensor: ...

    def dim(self) -> int: ...

    def num_heads(self) -> int: ...

    def pre_discard_policy(self) -> PreDiscardPolicy | None: ...

    def pre_discard_snapshots(self) -> List[PreDiscardSnapshot]: ...

    def curvature(self) -> float: ...

    def maxwell_channels(self) -> int: ...

    def topos(self) -> OpenCartesianTopos: ...

    def install_trace_recorder(
        self,
        *,
        capacity: int = ...,
        max_vector_len: int = ...,
        publish_plugin_events: bool = ...,
    ) -> ZSpaceTraceRecorder: ...

    def trace_recorder(self) -> ZSpaceTraceRecorder | None: ...


class _ZSpaceTraceRecorder:
    def snapshot(self) -> Dict[str, Any]: ...
    def records(self) -> List[Dict[str, Any]]: ...
    def clear(self) -> None: ...
    def write_jsonl(self, path: str) -> None: ...


def is_swap_invariant(arrangement: Sequence[float]) -> bool: ...


class _NnIdentity:
    def __init__(self) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def __call__(self, x: Tensor) -> Tensor: ...


class _NnLinear:
    def forward_snapshot(self, input: WgpuTensor) -> WgpuTensorSnapshot: ...

    def inference_plan(self, input_shape: Sequence[int]) -> _NnInferencePlan: ...
    @overload
    def __init__(self, name: str, input_dim: int, output_dim: int) -> None: ...

    @overload
    def __init__(self, input_dim: int, output_dim: int, *, name: str = ...) -> None: ...

    @overload
    def __init__(self, input_dim: int, output_dim: int, name: str) -> None: ...

    @overload
    def forward(self, input: Tensor) -> Tensor: ...

    @overload
    def forward(self, input: WgpuTensor) -> WgpuTensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    @overload
    def __call__(self, x: Tensor) -> Tensor: ...

    @overload
    def __call__(self, x: WgpuTensor) -> WgpuTensor: ...

    def resident_cache_info(self) -> Dict[str, int]: ...

    def clear_resident_cache(self) -> None: ...

    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def attach_realgrad(self, learning_rate: float) -> None: ...

    def zero_accumulators(self) -> None: ...

    def apply_step(self, fallback_lr: float) -> None: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    def load_state_dict_checked(
        self,
        state: Mapping[str, object] | Sequence[Tuple[str, object]],
    ) -> Dict[str, Any]: ...

    def state_dict_compatibility_with_key_map(
        self,
        state: Mapping[str, object] | Sequence[Tuple[str, object]],
        key_map: object,
    ) -> Dict[str, Any]: ...

    def load_state_dict_subset_mapped_checked(
        self,
        state: Mapping[str, object] | Sequence[Tuple[str, object]],
        key_map: object,
    ) -> Dict[str, Any]: ...


class _NnLoraLinear:
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        rank: int,
        *,
        alpha: float = ...,
        name: str = ...,
    ) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def __call__(self, x: Tensor) -> Tensor: ...

    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def attach_realgrad(self, learning_rate: float) -> None: ...

    def zero_accumulators(self) -> None: ...

    def apply_step(self, fallback_lr: float) -> None: ...

    def set_trainable(self, trainable: bool) -> None: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    def base_state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_base_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    def load_state_dict_checked(self, state: Sequence[Tuple[str, Tensor]]) -> Dict[str, Any]: ...

    def state_dict_compatibility_with_key_map(
        self,
        state: Mapping[str, object] | Sequence[Tuple[str, object]],
        key_map: object,
    ) -> Dict[str, Any]: ...

    def load_state_dict_subset_mapped_checked(
        self,
        state: Mapping[str, object] | Sequence[Tuple[str, object]],
        key_map: object,
    ) -> Dict[str, Any]: ...

    def base_state_dict_compatibility_with_key_map(
        self,
        state: Mapping[str, object] | Sequence[Tuple[str, object]],
        key_map: object,
    ) -> Dict[str, Any]: ...

    def load_base_from_state_dict_mapped(
        self,
        state: Mapping[str, object] | Sequence[Tuple[str, object]],
        key_map: object,
    ) -> Dict[str, Any]: ...

    @property
    def rank(self) -> int: ...

    @property
    def alpha(self) -> float: ...

    @property
    def scale(self) -> float: ...


class _NnZSpaceProjector:
    def __init__(
        self,
        topos: object,
        encoder: object,
        *,
        strength: float = ...,
    ) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def __call__(self, x: Tensor) -> Tensor: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    @property
    def curvature(self) -> float: ...

    @property
    def strength(self) -> float: ...


class _NnEmbedding:
    @overload
    def __init__(self, name: str, vocab_size: int, embed_dim: int) -> None: ...

    @overload
    def __init__(self, vocab_size: int, embed_dim: int, *, name: str = ...) -> None: ...

    @overload
    def __init__(self, vocab_size: int, embed_dim: int, name: str) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def __call__(self, x: Tensor) -> Tensor: ...

    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def attach_realgrad(self, learning_rate: float) -> None: ...

    def zero_accumulators(self) -> None: ...

    def apply_step(self, fallback_lr: float) -> None: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    def load_state_dict_checked(
        self,
        state: Mapping[str, object] | Sequence[Tuple[str, object]],
    ) -> Dict[str, Any]: ...

    def state_dict_compatibility_with_key_map(
        self,
        state: Mapping[str, object] | Sequence[Tuple[str, object]],
        key_map: object,
    ) -> Dict[str, Any]: ...

    def load_state_dict_subset_mapped_checked(
        self,
        state: Mapping[str, object] | Sequence[Tuple[str, object]],
        key_map: object,
    ) -> Dict[str, Any]: ...


class _NnSpiralRnn:
    def __init__(self, name: str, input_dim: int, hidden_dim: int, steps: int) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def __call__(self, x: Tensor) -> Tensor: ...

    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def attach_realgrad(self, learning_rate: float) -> None: ...

    def zero_accumulators(self) -> None: ...

    def apply_step(self, fallback_lr: float) -> None: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...


class _NnZSpaceSoftmax:
    def __init__(
        self,
        curvature: float,
        temperature: float,
        *,
        entropy_target: float | None = ...,
        entropy_tolerance: float = ...,
        entropy_gain: float = ...,
        min_temperature: float | None = ...,
        max_temperature: float | None = ...,
    ) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def reset_metrics(self) -> None: ...

    def last_entropies(self) -> List[float]: ...

    def last_temperatures(self) -> List[float]: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    def __call__(self, x: Tensor) -> Tensor: ...


class _NnZSpaceCoherenceScan:
    def __init__(
        self,
        dim: int,
        steps: int,
        memory: int,
        curvature: float,
        temperature: float,
    ) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    @property
    def dim(self) -> int: ...

    @property
    def steps(self) -> int: ...

    @property
    def memory(self) -> int: ...

    @property
    def curvature(self) -> float: ...

    @property
    def temperature(self) -> float: ...

    def __call__(self, x: Tensor) -> Tensor: ...


class _NnZSpaceCoherenceWaveBlock:
    def __init__(
        self,
        dim: int,
        steps: int,
        memory: int,
        curvature: float,
        temperature: float,
        *,
        kernel_size: int = ...,
        dilations: Sequence[int] | None = ...,
    ) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def infuse_text(self, text: str) -> None: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    @property
    def dim(self) -> int: ...

    @property
    def steps(self) -> int: ...

    @property
    def memory(self) -> int: ...

    def __call__(self, x: Tensor) -> Tensor: ...


class _NnRelu:
    def forward_snapshot(self, input: WgpuTensor) -> WgpuTensorSnapshot: ...

    def __init__(self) -> None: ...

    @overload
    def forward(self, input: Tensor) -> Tensor: ...

    @overload
    def forward(self, input: WgpuTensor) -> WgpuTensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    @overload
    def __call__(self, x: Tensor) -> Tensor: ...

    @overload
    def __call__(self, x: WgpuTensor) -> WgpuTensor: ...


class _NnGelu:
    def forward_snapshot(self, input: WgpuTensor) -> WgpuTensorSnapshot: ...

    def __init__(self) -> None: ...

    @overload
    def forward(self, input: Tensor) -> Tensor: ...

    @overload
    def forward(self, input: WgpuTensor) -> WgpuTensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    @overload
    def __call__(self, x: Tensor) -> Tensor: ...

    @overload
    def __call__(self, x: WgpuTensor) -> WgpuTensor: ...


class _NnLayerNorm:
    def __init__(self, name: str, features: int, curvature: float, epsilon: float) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def attach_realgrad(self, learning_rate: float) -> None: ...

    def zero_accumulators(self) -> None: ...

    def apply_step(self, fallback_lr: float) -> None: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    @property
    def features(self) -> int: ...

    @property
    def curvature(self) -> float: ...

    @property
    def epsilon(self) -> float: ...

    def __call__(self, x: Tensor) -> Tensor: ...


class _NnZSpaceLayerNorm:
    def __init__(
        self,
        name: str,
        features: int,
        curvature: float,
        epsilon: float,
        *,
        projector_gain: float = ...,
    ) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def attach_realgrad(self, learning_rate: float) -> None: ...

    def zero_accumulators(self) -> None: ...

    def apply_step(self, fallback_lr: float) -> None: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    @property
    def features(self) -> int: ...

    @property
    def curvature(self) -> float: ...

    @property
    def epsilon(self) -> float: ...

    @property
    def projector_gain(self) -> float: ...

    def set_projector_gain(self, gain: float) -> None: ...

    def adapt_projector_gain(self, target_radius: float, smoothing: float) -> float: ...

    def telemetry(self, *, full: bool = ...) -> Dict[str, Any] | None: ...

    def __call__(self, x: Tensor) -> Tensor: ...


class _NnBatchNorm1d:
    def __init__(
        self,
        name: str,
        features: int,
        momentum: float,
        epsilon: float,
        *,
        training: bool = ...,
    ) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def set_training(self, training: bool) -> None: ...

    def train(self) -> None: ...

    def eval(self) -> None: ...

    @property
    def training(self) -> bool: ...

    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def attach_realgrad(self, learning_rate: float) -> None: ...

    def zero_accumulators(self) -> None: ...

    def apply_step(self, fallback_lr: float) -> None: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    @property
    def features(self) -> int: ...

    @property
    def momentum(self) -> float: ...

    @property
    def epsilon(self) -> float: ...

    def __call__(self, x: Tensor) -> Tensor: ...


class _NnZSpaceBatchNorm1d:
    def __init__(
        self,
        name: str,
        features: int,
        curvature: float,
        momentum: float,
        epsilon: float,
        *,
        projector_gain: float = ...,
        training: bool = ...,
    ) -> None: ...

    def forward(self, input: Tensor) -> Tensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    def set_training(self, training: bool) -> None: ...

    def train(self) -> None: ...

    def eval(self) -> None: ...

    @property
    def training(self) -> bool: ...

    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def attach_realgrad(self, learning_rate: float) -> None: ...

    def zero_accumulators(self) -> None: ...

    def apply_step(self, fallback_lr: float) -> None: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    @property
    def features(self) -> int: ...

    @property
    def curvature(self) -> float: ...

    @property
    def momentum(self) -> float: ...

    @property
    def epsilon(self) -> float: ...

    @property
    def projector_gain(self) -> float: ...

    def set_projector_gain(self, gain: float) -> None: ...

    def adapt_projector_gain(self, target_radius: float, smoothing: float) -> float: ...

    def telemetry(self, *, full: bool = ...) -> Dict[str, Any] | None: ...

    def __call__(self, x: Tensor) -> Tensor: ...


class _NnInferencePlan:
    def apply_parameters_to(
        self,
        module: _NnLinear | _NnGelu | _NnRelu | _NnScaler | _NnSequential,
        updated: _NnInferencePlan,
        *,
        optimizer_state: Literal["reject", "reset"] = "reject",
    ) -> int: ...
    @staticmethod
    def from_json(payload: str, *, max_bytes: int = ...) -> _NnInferencePlan: ...
    def to_json(self) -> str: ...
    def fuse_pointwise(self) -> _NnInferencePlan: ...
    @property
    def input_shape(self) -> Tuple[int, ...]: ...
    @property
    def output_shape(self) -> Tuple[int, ...]: ...
    @property
    def stage_count(self) -> int: ...
    @property
    def source_operation_count(self) -> int: ...
    @property
    def is_dense(self) -> bool: ...
    def compile_wgpu(self, *, tile_mnk: Tuple[int, int, int] | None = ...,
                     kernel: str = ..., accumulation: str = ...) -> _NnResidentInference: ...
    def compile_graph_wgpu(self, *, tile_mnk: Tuple[int, int, int] | None = ...,
                           kernel: str = ..., accumulation: str = ...) -> _NnResidentGraphInference: ...
    def compile_graph_autograd_wgpu(self, *, tile_mnk: Tuple[int, int, int] | None = ...,
                                    kernel: str = ..., accumulation: str = ...) -> _NnResidentGraphAutograd: ...
    def compile_graph_learner_wgpu(self, *, gradient_policy: Literal["exact", "module_compatible"],
                                   tile_mnk: Tuple[int, int, int] | None = ...,
                                   kernel: str = ..., accumulation: str = ...) -> _NnResidentGraphLearner: ...
    def compile_training_wgpu(self, *, tile_mnk: Tuple[int, int, int] | None = ...,
                              kernel: str = ..., accumulation: str = ...) -> _NnResidentTraining: ...
    def compile_graph_training_wgpu(self, *, gradient_policy: Literal["exact", "module_compatible"],
                                    tile_mnk: Tuple[int, int, int] | None = ...,
                                    kernel: str = ..., accumulation: str = ...) -> _NnResidentGraphTraining: ...


class _NnResidentGraphAutograd:
    @property
    def input_shape(self) -> Tuple[int, ...]: ...
    @property
    def output_shape(self) -> Tuple[int, ...]: ...
    @property
    def stage_count(self) -> int: ...
    @property
    def parameter_count(self) -> int: ...
    @property
    def input_generation(self) -> int: ...
    @property
    def submitted_forwards(self) -> int: ...
    @property
    def submitted_backwards(self) -> int: ...
    def tensor_device(self) -> WgpuTensorDevice: ...
    def adapter_info(self) -> Dict[str, Any]: ...
    def upload_values(self, values: Sequence[float]) -> None: ...
    def set_input_tensor(self, input: WgpuTensor) -> None: ...
    def forward(self) -> _NnGraphForward: ...
    def backward(self, forward: _NnGraphForward, cotangent: WgpuTensor) -> _NnGraphGradients: ...


class _NnResidentGraphLearner:
    @property
    def input_shape(self) -> Tuple[int, ...]: ...
    @property
    def output_shape(self) -> Tuple[int, ...]: ...
    @property
    def stage_count(self) -> int: ...
    @property
    def parameter_count(self) -> int: ...
    @property
    def gradient_policy(self) -> str: ...
    @property
    def input_generation(self) -> int: ...
    @property
    def submitted_forwards(self) -> int: ...
    @property
    def submitted_backwards(self) -> int: ...
    @property
    def submitted_updates(self) -> int: ...
    def tensor_device(self) -> WgpuTensorDevice: ...
    def adapter_info(self) -> Dict[str, Any]: ...
    def upload_values(self, values: Sequence[float]) -> None: ...
    def set_input_tensor(self, input: WgpuTensor) -> None: ...
    def forward(self) -> _NnGraphForward: ...
    def backward(self, forward: _NnGraphForward, cotangent: WgpuTensor) -> _NnGraphGradients: ...
    def sgd(self, gradients: _NnGraphGradients, rate: float) -> int: ...
    def sgd_weighted(self, batch: _NnGraphGradientBatch, rate: float) -> int: ...
    def parameter_snapshot(self) -> _NnGraphTrainingParametersSnapshot: ...
    def update_snapshot(self) -> _NnGraphUpdateSnapshot: ...


class _NnGraphGradientBatch:
    def __init__(self) -> None: ...
    def __len__(self) -> int: ...
    def add(self, gradients: _NnGraphGradients, weight: float) -> None: ...


class _NnGraphUpdateSnapshot:
    @property
    def input_generation(self) -> int: ...
    @property
    def submitted_forward(self) -> int: ...
    @property
    def submitted_update(self) -> int: ...
    def read(self) -> int: ...


class _NnGraphForward:
    @property
    def input_generation(self) -> int: ...
    @property
    def submitted_forward(self) -> int: ...
    def prediction_tensor(self) -> WgpuTensor: ...


class _NnGraphGradients:
    @property
    def input_generation(self) -> int: ...
    @property
    def submitted_forward(self) -> int: ...
    @property
    def submitted_backward(self) -> int: ...
    @property
    def parameter_count(self) -> int: ...
    def input_gradient_tensor(self) -> WgpuTensor: ...
    def parameter_gradient_tensor(self, index: int) -> WgpuTensor: ...


class _NnResidentGraphInference:
    @property
    def input_shape(self) -> Tuple[int, ...]: ...
    @property
    def output_shape(self) -> Tuple[int, ...]: ...
    @property
    def stage_count(self) -> int: ...
    @property
    def parameter_count(self) -> int: ...
    @property
    def generation(self) -> int: ...
    @property
    def submitted_dispatches(self) -> int: ...
    def tensor_device(self) -> WgpuTensorDevice: ...
    def adapter_info(self) -> Dict[str, Any]: ...
    def upload_values(self, values: Sequence[float]) -> None: ...
    def set_input_tensor(self, input: WgpuTensor) -> None: ...
    def forward_tensor(self, input: WgpuTensor) -> WgpuTensor: ...

    def forward_tensor_snapshot(self, input: WgpuTensor) -> WgpuTensorSnapshot: ...
    def dispatch(self) -> int: ...
    def output_tensor(self) -> WgpuTensor: ...
    def snapshot(self) -> _NnGraphInferenceSnapshot: ...


class _NnGraphInferenceSnapshot:
    @property
    def shape(self) -> Tuple[int, ...]: ...
    @property
    def generation(self) -> int: ...
    @property
    def submitted_dispatch(self) -> int: ...
    def read_values(self) -> List[float]: ...


class _NnResidentGraphTraining:
    def upload_batch_tensors(self, input: WgpuTensor, target: WgpuTensor) -> None: ...
    def prediction_tensor(self) -> WgpuTensor: ...
    def input_gradient_tensor(self) -> WgpuTensor: ...
    @property
    def input_shape(self) -> Tuple[int, ...]: ...
    @property
    def output_shape(self) -> Tuple[int, ...]: ...
    @property
    def stage_count(self) -> int: ...
    @property
    def parameter_count(self) -> int: ...
    @property
    def gradient_policy(self) -> Literal["exact", "module_compatible"]: ...
    @property
    def submitted_steps(self) -> int: ...
    @property
    def batch_generation(self) -> int: ...
    def adapter_info(self) -> Dict[str, Any]: ...
    def upload_batch_values(self, input: Sequence[float], target: Sequence[float]) -> None: ...
    def upload_batch(self, input: Tensor, target: Tensor) -> None: ...
    def step(self, learning_rate: float) -> int: ...
    def loss_snapshot(self) -> _NnTrainingLossSnapshot: ...
    def state_snapshot(self) -> _NnGraphTrainingSnapshot: ...
    def parameter_snapshot(self) -> _NnGraphTrainingParametersSnapshot: ...


class _NnGraphTrainingSnapshot:
    @property
    def submitted_step(self) -> int: ...
    @property
    def batch_generation(self) -> int: ...
    @property
    def gradient_policy(self) -> Literal["exact", "module_compatible"]: ...
    @property
    def input_shape(self) -> Tuple[int, ...]: ...
    @property
    def output_shape(self) -> Tuple[int, ...]: ...
    def read_state(self) -> _NnGraphTrainingState: ...


class _NnGraphTrainingParametersSnapshot:
    def read_plan(self) -> _NnInferencePlan: ...


class _NnGraphTrainingState:
    @property
    def loss(self) -> float: ...
    @property
    def submitted_step(self) -> int: ...
    @property
    def batch_generation(self) -> int: ...
    @property
    def gradient_policy(self) -> Literal["exact", "module_compatible"]: ...
    @property
    def stage_count(self) -> int: ...
    @property
    def parameter_count(self) -> int: ...
    @property
    def input_shape(self) -> Tuple[int, ...]: ...
    @property
    def output_shape(self) -> Tuple[int, ...]: ...
    def prediction_values(self) -> List[float]: ...
    def input_gradient_values(self) -> List[float]: ...
    def parameter_role(self, parameter: int) -> Literal["weight", "bias", "gain"]: ...
    def parameter_shape(self, parameter: int) -> Tuple[int, ...]: ...
    def parameter_values(self, parameter: int) -> List[float]: ...
    def parameter_gradient_values(self, parameter: int) -> List[float]: ...
    def effective_gradient_values(self, parameter: int) -> List[float]: ...
    def to_plan(self) -> _NnInferencePlan: ...


class _NnResidentTraining:
    @property
    def input_shape(self) -> Tuple[int, ...]: ...
    @property
    def output_shape(self) -> Tuple[int, ...]: ...
    @property
    def stage_count(self) -> int: ...
    @property
    def submitted_steps(self) -> int: ...
    @property
    def batch_generation(self) -> int: ...
    def adapter_info(self) -> Dict[str, Any]: ...
    def upload_batch_values(self, input: Sequence[float], target: Sequence[float]) -> None: ...
    def upload_batch(self, input: Tensor, target: Tensor) -> None: ...
    def step(self, learning_rate: float) -> int: ...
    def loss_snapshot(self) -> _NnTrainingLossSnapshot: ...
    def state_snapshot(self) -> _NnTrainingSnapshot: ...
    def parameter_snapshot(self) -> _NnTrainingParametersSnapshot: ...


class _NnTrainingLossSnapshot:
    @property
    def submitted_step(self) -> int: ...
    @property
    def batch_generation(self) -> int: ...
    def read(self) -> float: ...


class _NnTrainingSnapshot:
    @property
    def submitted_step(self) -> int: ...
    @property
    def batch_generation(self) -> int: ...
    @property
    def input_shape(self) -> Tuple[int, ...]: ...
    @property
    def output_shape(self) -> Tuple[int, ...]: ...
    def read_state(self) -> _NnTrainingState: ...


class _NnTrainingParametersSnapshot:
    def read_plan(self) -> _NnInferencePlan: ...


class _NnTrainingState:
    @property
    def loss(self) -> float: ...
    @property
    def submitted_step(self) -> int: ...
    @property
    def batch_generation(self) -> int: ...
    @property
    def stage_count(self) -> int: ...
    @property
    def input_shape(self) -> Tuple[int, ...]: ...
    @property
    def output_shape(self) -> Tuple[int, ...]: ...
    def prediction_values(self) -> List[float]: ...
    def input_gradient_values(self) -> List[float]: ...
    def weight(self, stage: int) -> Tensor: ...
    def bias(self, stage: int) -> Tensor: ...
    def weight_gradient(self, stage: int) -> Tensor: ...
    def bias_gradient(self, stage: int) -> Tensor: ...
    def to_plan(self) -> _NnInferencePlan: ...


class _NnResidentInference:
    def set_input_tensor(self, input: WgpuTensor) -> None: ...
    def tensor_snapshot(self, device: WgpuTensorDevice) -> WgpuTensor: ...
    @property
    def input_shape(self) -> Tuple[int, ...]: ...
    @property
    def output_shape(self) -> Tuple[int, ...]: ...
    @property
    def generation(self) -> int: ...
    @property
    def stage_count(self) -> int: ...
    def adapter_info(self) -> Dict[str, Any]: ...
    def upload_values(self, values: Sequence[float]) -> None: ...
    def upload(self, input: Tensor) -> None: ...
    def dispatch(self) -> int: ...
    def snapshot(self) -> _NnInferenceSnapshot: ...
    def forward(self, input: Tensor) -> Tensor: ...
    def __call__(self, input: Tensor) -> Tensor: ...


class _NnInferenceSnapshot:
    @property
    def shape(self) -> Tuple[int, ...]: ...
    @property
    def generation(self) -> int: ...
    def read_values(self) -> List[float]: ...
    def read_tensor(self) -> Tensor: ...


class _NnSequential:
    def forward_snapshot(self, input: WgpuTensor) -> WgpuTensorSnapshot: ...

    def __init__(self) -> None: ...

    def add(self, layer: object) -> None: ...

    def inference_plan(self, input_shape: Sequence[int]) -> _NnInferencePlan: ...

    @overload
    def forward(self, input: Tensor) -> Tensor: ...

    @overload
    def forward(self, input: WgpuTensor) -> WgpuTensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    @overload
    def __call__(self, x: Tensor) -> Tensor: ...

    @overload
    def __call__(self, x: WgpuTensor) -> WgpuTensor: ...

    def resident_cache_info(self) -> Dict[str, int]: ...

    def clear_resident_cache(self) -> None: ...

    def attach_hypergrad(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def attach_realgrad(self, learning_rate: float) -> None: ...

    def zero_accumulators(self) -> None: ...

    def apply_step(self, fallback_lr: float) -> None: ...

    def infuse_text(self, text: str) -> None: ...

    def set_training(self, training: bool) -> None: ...

    def train(self) -> None: ...

    def eval(self) -> None: ...

    @property
    def training(self) -> bool: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    def len(self) -> int: ...

    def is_empty(self) -> bool: ...

    def __len__(self) -> int: ...


class _NnMeanSquaredError:
    def __init__(self) -> None: ...

    def evaluate_resident(self, prediction: WgpuTensor, target: WgpuTensor) -> _NnResidentLoss: ...

    def forward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def backward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def __call__(self, prediction: Tensor, target: Tensor) -> Tensor: ...


class _NnResidentLoss:
    def loss_tensor(self) -> WgpuTensor: ...
    def prediction_gradient_tensor(self) -> WgpuTensor: ...


class _NnCategoricalCrossEntropy:
    def __init__(self, *, epsilon: float | None = ...) -> None: ...

    @property
    def epsilon(self) -> float: ...

    def forward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def backward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def __call__(self, prediction: Tensor, target: Tensor) -> Tensor: ...


class _NnCrossEntropyWithLogits:
    def __init__(
        self, *, reduction: Literal["none", "sum", "mean"] = ...,
        ignore_index: int = ..., label_smoothing: float = ...,
    ) -> None: ...
    @property
    def reduction(self) -> str: ...
    @property
    def ignore_index(self) -> int: ...
    @property
    def label_smoothing(self) -> float: ...
    def evaluate_resident(self, prediction: WgpuTensor, target: WgpuTensor) -> _NnResidentLoss: ...
    def forward(self, prediction: Tensor, target: Tensor) -> Tensor: ...
    def backward(self, prediction: Tensor, target: Tensor) -> Tensor: ...
    def __call__(self, prediction: Tensor, target: Tensor) -> Tensor: ...


class _NnHyperbolicCrossEntropy:
    def __init__(self, curvature: float, *, epsilon: float | None = ...) -> None: ...

    @property
    def curvature(self) -> float: ...

    @property
    def epsilon(self) -> float: ...

    def forward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def backward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def __call__(self, prediction: Tensor, target: Tensor) -> Tensor: ...

class _NnFocalLoss:
    def __init__(self, alpha: float = ..., gamma: float = ..., *, epsilon: float | None = ...) -> None: ...

    @property
    def alpha(self) -> float: ...

    @property
    def gamma(self) -> float: ...

    def forward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def backward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def __call__(self, prediction: Tensor, target: Tensor) -> Tensor: ...

class _NnContrastiveLoss:
    def __init__(self, margin: float = ...) -> None: ...

    @property
    def margin(self) -> float: ...

    def forward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def backward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def __call__(self, prediction: Tensor, target: Tensor) -> Tensor: ...

class _NnTripletLoss:
    def __init__(self, margin: float = ...) -> None: ...

    @property
    def margin(self) -> float: ...

    def forward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def backward(self, prediction: Tensor, target: Tensor) -> Tensor: ...

    def __call__(self, prediction: Tensor, target: Tensor) -> Tensor: ...

class _NnRoundtableConfig:
    def __init__(
        self,
        *,
        top_k: int = ...,
        mid_k: int = ...,
        bottom_k: int = ...,
        here_tolerance: float = ...,
        psi_enabled: bool = ...,
    ) -> None: ...

    @property
    def top_k(self) -> int: ...

    @property
    def mid_k(self) -> int: ...

    @property
    def bottom_k(self) -> int: ...

    @property
    def here_tolerance(self) -> float: ...

    @property
    def psi_enabled(self) -> bool: ...


class _NnSoftLogicConfig:
    def __init__(
        self,
        *,
        inertia: float = ...,
        inertia_min: float = ...,
        inertia_drift_k: float = ...,
        inertia_z_k: float = ...,
        drift_gain: float = ...,
        psi_gain: float = ...,
        loss_gain: float = ...,
        floor: float = ...,
        scale_gain: float = ...,
        region_gain: float = ...,
        region_factor_gain: float = ...,
        energy_equalize_gain: float = ...,
        mean_normalize_gain: float = ...,
        energy_equalize_auto: float = ...,
        mean_normalize_auto: float = ...,
    ) -> None: ...

    @staticmethod
    def from_env() -> _NnSoftLogicConfig: ...

    @property
    def inertia(self) -> float: ...

    @property
    def inertia_min(self) -> float: ...

    @property
    def inertia_drift_k(self) -> float: ...

    @property
    def inertia_z_k(self) -> float: ...

    @property
    def drift_gain(self) -> float: ...

    @property
    def psi_gain(self) -> float: ...

    @property
    def loss_gain(self) -> float: ...

    @property
    def floor(self) -> float: ...

    @property
    def scale_gain(self) -> float: ...

    @property
    def region_gain(self) -> float: ...

    @property
    def region_factor_gain(self) -> float: ...

    @property
    def energy_equalize_gain(self) -> float: ...

    @property
    def mean_normalize_gain(self) -> float: ...

    @property
    def energy_equalize_auto(self) -> float: ...

    @property
    def mean_normalize_auto(self) -> float: ...


class _NnRoundtableSchedule:
    def above(self) -> RankPlan: ...
    def here(self) -> RankPlan: ...
    def beneath(self) -> RankPlan: ...
    def band_energy(self, gradient: Tensor) -> Tuple[float, float, float]: ...
    def band_energy_detail(self, gradient: Tensor) -> Dict[str, object]: ...


class _NnEpochStats:
    @property
    def batches(self) -> int: ...

    @property
    def total_loss(self) -> float: ...

    @property
    def average_loss(self) -> float: ...


class _NnNarrativeSummary:
    @property
    def channel(self) -> str: ...

    @property
    def dominant_tag(self) -> str | None: ...

    @property
    def tags(self) -> List[str]: ...

    @property
    def intensity(self) -> float: ...

    @property
    def amplitude(self) -> float: ...

    @property
    def phase(self) -> float: ...

    @property
    def coherence(self) -> float: ...

    @property
    def decoherence(self) -> float: ...

    @property
    def emphasis(self) -> float: ...

    def describe(self) -> str: ...


class _NnNarrativeHint:
    @property
    def channel(self) -> str: ...

    @property
    def tags(self) -> List[str]: ...

    def dominant_tag(self) -> str | None: ...

    @property
    def intensity(self) -> float: ...

    @property
    def amplitude(self) -> float: ...

    @property
    def phase(self) -> float: ...

    @property
    def coherence(self) -> float: ...

    @property
    def decoherence(self) -> float: ...

    def collapsed_tag(self) -> str | None: ...

    def quantum_emphasis(self) -> float: ...

    def summary(self) -> _NnNarrativeSummary: ...

    def describe(self) -> str: ...


class _NnMaxwellDesireBridge:
    def __init__(self, *, smoothing: float = ..., magnitude_floor: float = ...) -> None: ...

    @property
    def smoothing(self) -> float: ...

    @property
    def magnitude_floor(self) -> float: ...

    def set_smoothing(self, smoothing: float) -> None: ...

    def set_magnitude_floor(self, floor: float) -> None: ...

    def len(self) -> int: ...

    def is_empty(self) -> bool: ...

    def contains(self, channel: str) -> bool: ...

    def channel_names(self) -> List[str]: ...

    def register_channel(self, channel: str, window: Sequence[Tuple[int, float]]) -> None: ...

    def register_channel_with_narrative(
        self,
        channel: str,
        window: Sequence[Tuple[int, float]],
        tags: Sequence[str],
    ) -> None: ...

    def set_narrative_tags(self, channel: str, tags: Sequence[str]) -> None: ...

    def narrative_tags(self, channel: str) -> List[str] | None: ...

    def set_narrative_gain(self, channel: str, gain: float) -> None: ...

    def narrative_gain(self, channel: str) -> float | None: ...

    def hint_for(self, channel: str, pulse: Any) -> List[Tuple[int, float]] | None: ...

    def narrative_for(self, channel: str, pulse: Any) -> _NnNarrativeHint | None: ...

    def emit(self, channel: str, pulse: Any) -> Mapping[str, Any] | None: ...


class _NnRoundtableGnnBridge:
    def __init__(self, *, history_limit: int = ...) -> None: ...

    @property
    def history_limit(self) -> int: ...

    def len(self) -> int: ...

    def is_empty(self) -> bool: ...

    def latest(self) -> Dict[str, Any] | None: ...

    def drain(self) -> List[Dict[str, Any]]: ...


class _NnDesireRoundtableBridge:
    def __init__(self, *, blend: float = ..., drift_gain: float = ...) -> None: ...

    def len(self) -> int: ...

    def is_empty(self) -> bool: ...

    @property
    def blend(self) -> float: ...

    @blend.setter
    def blend(self, blend: float) -> None: ...

    @property
    def drift_gain(self) -> float: ...

    @drift_gain.setter
    def drift_gain(self, drift_gain: float) -> None: ...

    def impulse(self) -> Dict[str, Any] | None: ...

    def drain_summary(self) -> Dict[str, Any] | None: ...


class _NnDesireTelemetryBundle:
    def __init__(
        self,
        *,
        trainer: bool = ...,
        roundtable: bool = ...,
        blend: float = ...,
        drift_gain: float = ...,
    ) -> None: ...

    def has_trainer(self) -> bool: ...

    def has_roundtable(self) -> bool: ...

    def trainer_bridge(self) -> Any | None: ...

    def roundtable_bridge(self) -> _NnDesireRoundtableBridge | None: ...

    def drain_trainer_summary(self) -> Dict[str, Any] | None: ...

    def drain_roundtable_summary(self) -> Dict[str, Any] | None: ...


class _NnModuleTrainer:
    def __init__(
        self,
        *,
        backend: str = ...,
        curvature: float = ...,
        hyper_learning_rate: float = ...,
        fallback_learning_rate: float = ...,
        lane_width: int | None = ...,
        subgroup: bool | None = ...,
        max_workgroup: int | None = ...,
        shared_mem_per_workgroup: int | None = ...,
    ) -> None: ...

    @property
    def backend(self) -> str: ...

    @property
    def requested_backend(self) -> str: ...

    @property
    def effective_backend(self) -> str: ...

    def bind_runtime_execution_plan(self, plan: Mapping[str, Any]) -> None: ...

    @property
    def runtime_execution_plan_output_sha256(self) -> str | None: ...

    @property
    def runtime_execution_plan(self) -> Dict[str, Any] | None: ...

    def roundtable(
        self,
        rows: int,
        cols: int,
        config: _NnRoundtableConfig | None = ...,
    ) -> _NnRoundtableSchedule: ...

    def set_text_infusion(self, text: str, *, every: str = ..., mode: str = ...) -> None: ...

    def clear_text_infusion(self) -> None: ...

    def softlogic_config(self) -> _NnSoftLogicConfig: ...

    def set_softlogic_config(self, config: _NnSoftLogicConfig | None = ...) -> None: ...

    def reset_softlogic(self) -> None: ...

    def train_epoch(
        self,
        module: object,
        loss: object,
        batches: Iterable[Tuple[Tensor, Tensor]],
        schedule: _NnRoundtableSchedule,
    ) -> _NnEpochStats: ...

    def evaluate_epoch(
        self,
        module: object,
        loss: object,
        batches: Iterable[Tuple[Tensor, Tensor]],
    ) -> _NnEpochStats: ...

    def train_epochs(
        self,
        module: object,
        loss: object,
        batches: Iterable[Tuple[Tensor, Tensor]],
        schedule: _NnRoundtableSchedule,
        *,
        epochs: int = ...,
        validation_batches: Iterable[Tuple[Tensor, Tensor]] | None = ...,
        patience: int | None = ...,
        min_delta: float = ...,
        shuffle_seed: int | None = ...,
        restore_best: bool = ...,
    ) -> Dict[str, Any]: ...

    @property
    def curvature(self) -> float: ...

    @property
    def hyper_learning_rate(self) -> float: ...

    @property
    def fallback_learning_rate(self) -> float: ...

    @property
    def real_learning_rate(self) -> float | None: ...

    @property
    def meta_learning_rate_scale(self) -> float: ...

    @property
    def meta_optimizer_step(self) -> int | None: ...

    def enable_realgrad(self, learning_rate: float) -> None: ...

    def disable_realgrad(self) -> None: ...

    def optimizer_config_contract(self) -> Dict[str, Any]: ...

    def optimizer_checkpoint(self, module: object) -> Dict[str, Any]: ...

    def restore_optimizer_checkpoint(
        self,
        module: object,
        checkpoint: Mapping[str, Any],
    ) -> Dict[str, Any]: ...

    def external_state_checkpoint(self) -> Dict[str, Any]: ...

    def restore_external_state_checkpoint(
        self,
        checkpoint: Mapping[str, Any],
    ) -> Dict[str, Any]: ...

    def runtime_checkpoint_bundle(self, module: object) -> Dict[str, Any]: ...

    def restore_runtime_checkpoint_bundle(
        self,
        module: object,
        bundle: Mapping[str, Any],
    ) -> Dict[str, Any]: ...

    def prepare(self, module: object, *, topos: OpenCartesianTopos | None = ...) -> None: ...

    def zero(self, module: object) -> None: ...

    def step(self, module: object) -> None: ...

    def enable_curvature_scheduler(self, scheduler: CurvatureScheduler) -> None: ...

    def disable_curvature_scheduler(self) -> None: ...

    def curvature_metrics(self) -> Dict[str, float] | None: ...

    def enable_spectral_learning_rate(
        self,
        policy: SpectralLearningRatePolicy | None = ...,
    ) -> None: ...

    def disable_spectral_learning_rate(self) -> None: ...

    def push_coherence_diagnostics(self, diagnostics: CoherenceDiagnostics) -> bool: ...

    def spectral_metrics(self) -> Dict[str, object] | None: ...

    def enable_zspace_trace_coherence_bridge(self) -> None: ...

    def disable_zspace_trace_coherence_bridge(self) -> None: ...

    def enable_gnn_roundtable_bridge(self, bridge: _NnRoundtableGnnBridge) -> None: ...

    def disable_gnn_roundtable_bridge(self) -> None: ...

    def gnn_roundtable_signal(self) -> Dict[str, Any] | None: ...

    @property
    def grad_clip_max_norm(self) -> float | None: ...

    def set_grad_clip_max_norm(self, max_norm: float) -> None: ...

    def clear_grad_clip_max_norm(self) -> None: ...

    def mul_learning_rate(self, module: object, factor: float) -> None: ...

    def apply_zspace_meta_optimizer_report(
        self,
        module: object,
        report: Mapping[str, Any],
    ) -> Dict[str, Any]: ...


class _NnScaler:
    def forward_snapshot(self, input: WgpuTensor) -> WgpuTensorSnapshot: ...

    def __init__(self, name: str, features: int) -> None: ...

    @staticmethod
    def from_gain(name: str, gain: Tensor) -> _NnScaler: ...

    @overload
    def forward(self, input: Tensor) -> Tensor: ...

    @overload
    def forward(self, input: WgpuTensor) -> WgpuTensor: ...

    def backward(self, input: Tensor, grad_output: Tensor) -> Tensor: ...

    @overload
    def __call__(self, x: Tensor) -> Tensor: ...

    @overload
    def __call__(self, x: WgpuTensor) -> WgpuTensor: ...

    def resident_cache_info(self) -> Dict[str, int]: ...

    def clear_resident_cache(self) -> None: ...

    def calibrate(self, samples: Tensor, epsilon: float) -> None: ...

    def attach_hypergrad(self, curvature: float, learning_rate: float) -> None: ...

    def attach_hypergrad_with_topos(
        self,
        curvature: float,
        learning_rate: float,
        *,
        topos: OpenCartesianTopos | None = ...,
    ) -> None: ...

    def attach_realgrad(self, learning_rate: float) -> None: ...

    def zero_accumulators(self) -> None: ...

    def apply_step(self, fallback_lr: float) -> None: ...

    def state_dict(self) -> List[Tuple[str, Tensor]]: ...

    def load_state_dict(self, state: Sequence[Tuple[str, Tensor]]) -> None: ...

    @property
    def gain(self) -> Tensor: ...

    @property
    def baseline(self) -> Tensor: ...

    def gradient(self) -> Tensor | None: ...

    def psi_probe(self) -> float | None: ...

    def psi_components(self) -> Tensor | None: ...


class _NnModule(ModuleType):
    InferencePlan: type[_NnInferencePlan]
    ResidentInference: type[_NnResidentInference]
    InferenceSnapshot: type[_NnInferenceSnapshot]
    ResidentTraining: type[_NnResidentTraining]
    ResidentGraphTraining: type[_NnResidentGraphTraining]
    ResidentGraphInference: type[_NnResidentGraphInference]
    ResidentGraphAutograd: type[_NnResidentGraphAutograd]
    ResidentGraphLearner: type[_NnResidentGraphLearner]
    GraphGradientBatch: type[_NnGraphGradientBatch]
    GraphUpdateSnapshot: type[_NnGraphUpdateSnapshot]
    GraphForward: type[_NnGraphForward]
    GraphGradients: type[_NnGraphGradients]
    GraphInferenceSnapshot: type[_NnGraphInferenceSnapshot]
    GraphTrainingSnapshot: type[_NnGraphTrainingSnapshot]
    GraphTrainingParametersSnapshot: type[_NnGraphTrainingParametersSnapshot]
    GraphTrainingState: type[_NnGraphTrainingState]
    TrainingLossSnapshot: type[_NnTrainingLossSnapshot]
    TrainingSnapshot: type[_NnTrainingSnapshot]
    TrainingParametersSnapshot: type[_NnTrainingParametersSnapshot]
    TrainingState: type[_NnTrainingState]
    Identity: type[_NnIdentity]
    Linear: type[_NnLinear]
    Embedding: type[_NnEmbedding]
    SpiralRnn: type[_NnSpiralRnn]
    ZSpaceSoftmax: type[_NnZSpaceSoftmax]
    ZSpaceCoherenceScan: type[_NnZSpaceCoherenceScan]
    ZSpaceCoherenceWaveBlock: type[_NnZSpaceCoherenceWaveBlock]
    Relu: type[_NnRelu]
    Gelu: type[_NnGelu]
    LayerNorm: type[_NnLayerNorm]
    ZSpaceLayerNorm: type[_NnZSpaceLayerNorm]
    BatchNorm1d: type[_NnBatchNorm1d]
    ZSpaceBatchNorm1d: type[_NnZSpaceBatchNorm1d]
    Sequential: type[_NnSequential]
    MeanSquaredError: type[_NnMeanSquaredError]
    ResidentLoss: type[_NnResidentLoss]
    CategoricalCrossEntropy: type[_NnCategoricalCrossEntropy]
    CrossEntropyWithLogits: type[_NnCrossEntropyWithLogits]
    SoftmaxCrossEntropy: type[_NnCategoricalCrossEntropy]
    HyperbolicCrossEntropy: type[_NnHyperbolicCrossEntropy]
    CrossEntropy: type[_NnHyperbolicCrossEntropy]
    FocalLoss: type[_NnFocalLoss]
    ContrastiveLoss: type[_NnContrastiveLoss]
    TripletLoss: type[_NnTripletLoss]
    RoundtableConfig: type[_NnRoundtableConfig]
    SoftLogicConfig: type[_NnSoftLogicConfig]
    RoundtableSchedule: type[_NnRoundtableSchedule]
    EpochStats: type[_NnEpochStats]
    ModuleTrainer: type[_NnModuleTrainer]
    RoundtableGnnBridge: type[_NnRoundtableGnnBridge]
    SpectralLearningRatePolicy: type[SpectralLearningRatePolicy]
    MaxwellDesireBridge: type[_NnMaxwellDesireBridge]
    DesireRoundtableBridge: type[_NnDesireRoundtableBridge]
    DesireTelemetryBundle: type[_NnDesireTelemetryBundle]
    NarrativeHint: type[_NnNarrativeHint]
    NarrativeSummary: type[_NnNarrativeSummary]
    Scaler: type[_NnScaler]
    NonLiner: type[_NnNonLiner]
    Dropout: type[_NnDropout]
    LoraLinear: type[_NnLoraLinear]
    ZSpaceProjector: type[_NnZSpaceProjector]
    Dataset: type[_NnDataset]
    DataLoader: type[_NnDataLoader]
    DataLoaderIter: type[_NnDataLoaderIter]
    CoherenceDiagnostics: type[CoherenceDiagnostics]
    LinguisticContour: type[LinguisticContour]
    ZSpaceCoherenceSequencer: type[_ZSpaceCoherenceSequencer]
    PreDiscardTelemetry: type[PreDiscardTelemetry]
    PreDiscardPolicy: type[PreDiscardPolicy]
    PreDiscardSnapshot: type[PreDiscardSnapshot]
    MellinBasis: type[MellinBasis]
    ZSpaceVae: type[ZSpaceVae]
    ZSpaceVaeState: type[ZSpaceVaeState]
    ZSpaceVaeStats: type[ZSpaceVaeStats]
    ZSpaceVaeBatchStats: type[ZSpaceVaeBatchStats]
    ZSpaceTextVae: type[ZSpaceTextVae]
    ZRelativityModule: type[ZRelativityModule]
    ZConv: type[ZConv]
    ZPooling: type[ZPooling]
    Pool2d: type[Pool2d]

    def from_samples(samples: Sequence[Tuple[Tensor, Tensor]]) -> _NnDataLoader: ...
    def save_json(
        target: object | Mapping[str, Tensor] | Sequence[Tuple[str, Tensor]],
        path: str,
    ) -> None: ...
    def load_json(
        target: object | None,
        path: str,
    ) -> List[Tuple[str, Tensor]] | None: ...
    def save(
        path: Any,
        target: object | Mapping[str, Tensor] | Sequence[Tuple[str, Tensor]],
    ) -> None: ...
    def load(
        path: Any,
        target: object | None = ...,
    ) -> List[Tuple[str, Tensor]] | None: ...
    def sparse_classification_delta(
        before: Mapping[str, object] | object,
        after: Mapping[str, object] | object,
    ) -> Dict[str, float | None]: ...
    def save_bincode(
        target: object | Mapping[str, Tensor] | Sequence[Tuple[str, Tensor]],
        path: str,
    ) -> None: ...
    def load_bincode(
        target: object | None,
        path: str,
    ) -> List[Tuple[str, Tensor]] | None: ...
    def eval_mode(module: object) -> ContextManager[None]: ...
    def compare_sparse_finetune_summaries(
        current: Mapping[str, Any],
        baseline: Mapping[str, Any],
        *,
        max_target_loss_regression: float | None = ...,
        max_retention_loss_regression: float | None = ...,
        require_status_match: bool = ...,
        require_accepted_match: bool = ...,
        require_guard_match: bool = ...,
        require_movement_tolerance_match: bool = ...,
        require_resume_match: bool = ...,
        **extra: Any,
    ) -> Dict[str, Any]: ...


nn: _NnModule


class Identity(_NnIdentity):
    ...


class Linear(_NnLinear):
    ...


class LoraLinear(_NnLoraLinear):
    ...


class ZSpaceProjector(_NnZSpaceProjector):
    ...


class Embedding(_NnEmbedding):
    ...


class SpiralRnn(_NnSpiralRnn):
    ...


class ZSpaceSoftmax(_NnZSpaceSoftmax):
    ...


class ZSpaceCoherenceScan(_NnZSpaceCoherenceScan):
    ...


class ZSpaceCoherenceWaveBlock(_NnZSpaceCoherenceWaveBlock):
    ...


class Relu(_NnRelu):
    ...


class Gelu(_NnGelu):
    ...


class LayerNorm(_NnLayerNorm):
    ...


class ZSpaceLayerNorm(_NnZSpaceLayerNorm):
    ...


class BatchNorm1d(_NnBatchNorm1d):
    ...


class ZSpaceBatchNorm1d(_NnZSpaceBatchNorm1d):
    ...


class Sequential(_NnSequential):
    ...


class MeanSquaredError(_NnMeanSquaredError):
    ...


class CategoricalCrossEntropy(_NnCategoricalCrossEntropy):
    ...


class SoftmaxCrossEntropy(_NnCategoricalCrossEntropy):
    ...


class CrossEntropyWithLogits(_NnCrossEntropyWithLogits): ...

class HyperbolicCrossEntropy(_NnHyperbolicCrossEntropy):
    ...

class CrossEntropy(_NnHyperbolicCrossEntropy):
    ...

class FocalLoss(_NnFocalLoss):
    ...

class ContrastiveLoss(_NnContrastiveLoss):
    ...

class TripletLoss(_NnTripletLoss):
    ...

class Scaler(_NnScaler):
    ...


class NonLiner(_NnNonLiner):
    ...


class Dropout(_NnDropout):
    ...


class ZSpaceCoherenceSequencer(_ZSpaceCoherenceSequencer):
    ...


class ZSpaceTraceRecorder(_ZSpaceTraceRecorder):
    ...


class MetaMembConfig:
    def __init__(
        self,
        *,
        delta: Sequence[float] | None = ...,
        omega: Sequence[float] | None = ...,
        theta: Sequence[float] | None = ...,
    ) -> None: ...

    @staticmethod
    def default() -> MetaMembConfig: ...

    @property
    def delta(self) -> Tuple[float, float, float]: ...

    @property
    def omega(self) -> Tuple[float, float, float]: ...

    @property
    def theta(self) -> Tuple[float, float, float]: ...


class CircleLockMapConfig:
    def __init__(
        self,
        *,
        lam_min: float = ...,
        lam_max: float = ...,
        lam_bins: int = ...,
        wd_min: float = ...,
        wd_max: float = ...,
        wd_bins: int = ...,
        burn_in: int = ...,
        samples: int = ...,
        qmax: int = ...,
    ) -> None: ...

    @staticmethod
    def default() -> CircleLockMapConfig: ...

    @property
    def lam_min(self) -> float: ...

    @property
    def lam_max(self) -> float: ...

    @property
    def lam_bins(self) -> int: ...

    @property
    def wd_min(self) -> float: ...

    @property
    def wd_max(self) -> float: ...

    @property
    def wd_bins(self) -> int: ...

    @property
    def burn_in(self) -> int: ...

    @property
    def samples(self) -> int: ...

    @property
    def qmax(self) -> int: ...


class PsiTelemetryConfig:
    def __init__(
        self,
        *,
        emit_atlas: bool = ...,
        atlas_timestamp: float | None = ...,
        emit_psi: bool = ...,
        psi_step_base: int = ...,
        emit_golden: bool = ...,
        golden_baseline_interval: float = ...,
        golden_baseline_window: int = ...,
    ) -> None: ...

    @property
    def emit_atlas(self) -> bool: ...

    @property
    def atlas_timestamp(self) -> float | None: ...

    @property
    def emit_psi(self) -> bool: ...

    @property
    def psi_step_base(self) -> int: ...

    @property
    def emit_golden(self) -> bool: ...

    @property
    def golden_baseline_interval(self) -> float: ...

    @property
    def golden_baseline_window(self) -> int: ...


class PsiSynchroConfig:
    def __init__(
        self,
        *,
        step: float = ...,
        samples: int = ...,
        ticker_interval: float | None = ...,
        min_ident_points: int = ...,
        max_ident_points: int = ...,
        metamemb: MetaMembConfig | None = ...,
        circle_map: CircleLockMapConfig | None = ...,
        telemetry: PsiTelemetryConfig | None = ...,
    ) -> None: ...

    @staticmethod
    def default() -> PsiSynchroConfig: ...

    @property
    def step(self) -> float: ...

    @property
    def samples(self) -> int: ...

    @property
    def ticker_interval(self) -> float | None: ...

    @property
    def min_ident_points(self) -> int: ...

    @property
    def max_ident_points(self) -> int: ...

    @property
    def metamemb(self) -> MetaMembConfig: ...

    @property
    def circle_map(self) -> CircleLockMapConfig: ...

    @property
    def telemetry(self) -> PsiTelemetryConfig | None: ...


class PsiBranchState:
    def __init__(
        self,
        branch_id: str,
        *,
        gamma: float = ...,
        lambda_: float = ...,
        wd: float = ...,
        omega0: float = ...,
        drift_coupled: float = ...,
        phase0: float = ...,
    ) -> None: ...

    @property
    def branch_id(self) -> str: ...

    @property
    def gamma(self) -> float: ...

    @property
    def lambda_(self) -> float: ...

    @property
    def wd(self) -> float: ...

    @property
    def omega0(self) -> float: ...

    @property
    def drift_coupled(self) -> float: ...

    @property
    def phase0(self) -> float: ...

    def poincare_period(self) -> float: ...


class ZPulseSnapshot:
    @property
    def source(self) -> str: ...

    @property
    def ts(self) -> int: ...

    @property
    def tempo(self) -> float: ...

    @property
    def band_energy(self) -> Tuple[float, float, float]: ...

    @property
    def drift(self) -> float: ...

    @property
    def z_bias(self) -> float: ...

    @property
    def density_fluctuation(self) -> float: ...

    @property
    def support(self) -> Tuple[float, float, float]: ...

    @property
    def scale(self) -> Tuple[float, float] | None: ...

    @property
    def quality(self) -> float: ...

    @property
    def stderr(self) -> float: ...

    @property
    def latency_ms(self) -> float: ...


class ContextualPulseFrame:
    @property
    def summary(self) -> str: ...

    @property
    def highlights(self) -> List[str]: ...

    @property
    def label(self) -> str | None: ...

    @property
    def lexical_weight(self) -> float: ...

    @property
    def signature(self) -> Tuple[int, int, int] | None: ...

    @property
    def support(self) -> int: ...

    @property
    def pulse(self) -> ZPulseSnapshot: ...


class ContextualLagrangianGate:
    def __init__(
        self,
        curvature: float,
        temperature: float,
        *,
        gauge: str = ...,
        tempo_normaliser: float | None = ...,
        energy_gain: float = ...,
        drift_gain: float = ...,
        bias_gain: float = ...,
        support_gain: float = ...,
        scale: Tuple[float, float] | None = ...,
        quality_floor: float = ...,
        stderr_gain: float = ...,
    ) -> None: ...

    def project(
        self,
        placements: Sequence[int],
        edges: Optional[Sequence[Tuple[int, int]]] = ...,
        *,
        gauge: str | None = ...,
        ts: int = ...,
    ) -> ContextualPulseFrame: ...

    @property
    def gauge(self) -> str: ...

def token_scale_stack(
    embeddings: Tensor | Sequence[Sequence[float]],
    scales: Sequence[float],
    threshold: float,
    metric: str = ...,
) -> ScaleStack: ...

def token_coherence_levels(
    embeddings: Tensor | Sequence[Sequence[float]],
    scales: Sequence[float],
    threshold: float,
    levels: Sequence[float],
    metric: str = ...,
) -> List[Optional[float]]: ...


class ArnoldTonguePeak:
    @property
    def ratio_p(self) -> int: ...

    @property
    def ratio_q(self) -> int: ...

    @property
    def rotation(self) -> float: ...

    @property
    def lam(self) -> float: ...

    @property
    def wd(self) -> float: ...

    @property
    def strength(self) -> float: ...

    @property
    def peak_strength(self) -> float: ...

    @property
    def error(self) -> float: ...

    @property
    def ratio(self) -> float: ...


class HeatmapAnalytics:
    @property
    def total_energy(self) -> float: ...

    @property
    def leading_sum(self) -> float: ...

    @property
    def central_sum(self) -> float: ...

    @property
    def trailing_sum(self) -> float: ...

    @property
    def leading_norm(self) -> float: ...

    @property
    def central_norm(self) -> float: ...

    @property
    def trailing_norm(self) -> float: ...

    @property
    def dominant_lam(self) -> float: ...

    @property
    def dominant_wd(self) -> float: ...

    @property
    def peak_value(self) -> float: ...

    @property
    def peak_ratio(self) -> float: ...

    @property
    def radius(self) -> float: ...

    @property
    def log_radius(self) -> float: ...

    @property
    def bias(self) -> float: ...

    @property
    def drift(self) -> float: ...

    @property
    def quality(self) -> float: ...

    @property
    def stderr(self) -> float: ...

    @property
    def entropy(self) -> float: ...

    def band_energy(self) -> Tuple[float, float, float]: ...


class HeatmapResult:
    @property
    def branch_id(self) -> str: ...

    @property
    def gamma(self) -> float: ...

    @property
    def kappa_hat(self) -> float: ...

    @property
    def lam_grid(self) -> List[float]: ...

    @property
    def wd_grid(self) -> List[float]: ...

    @property
    def matrix(self) -> List[List[float]]: ...

    @property
    def tongues(self) -> List[ArnoldTonguePeak]: ...

    def dominant_tongue(self) -> ArnoldTonguePeak | None: ...

    def analyse(self) -> HeatmapAnalytics | None: ...

    def to_atlas_fragment(
        self,
        timestamp: float | None = ...,
    ) -> Dict[str, Any] | None: ...

    def to_psi_reading(self, step: int) -> Dict[str, Any] | None: ...

    def to_zpulse(self, ts: int) -> ZPulseSnapshot: ...


class PsiSynchroPulse:
    @property
    def branch_id(self) -> str: ...

    @property
    def pulse(self) -> ZPulseSnapshot: ...


class PsiSynchroResult:
    @property
    def heatmaps(self) -> List[HeatmapResult]: ...

    @property
    def pulses(self) -> List[PsiSynchroPulse]: ...

    def atlas_fragments(self) -> List[Tuple[str, Dict[str, object]]]: ...

    def psi_readings(self) -> List[Tuple[str, Dict[str, object]]]: ...

    def by_branch(self) -> List[Tuple[str, ZPulseSnapshot]]: ...


class _PsiModule(ModuleType):
    MetaMembConfig: type[MetaMembConfig]
    CircleLockMapConfig: type[CircleLockMapConfig]
    PsiTelemetryConfig: type[PsiTelemetryConfig]
    PsiSynchroConfig: type[PsiSynchroConfig]
    PsiBranchState: type[PsiBranchState]
    ArnoldTonguePeak: type[ArnoldTonguePeak]
    HeatmapAnalytics: type[HeatmapAnalytics]
    HeatmapResult: type[HeatmapResult]
    ZPulseSnapshot: type[ZPulseSnapshot]
    PsiSynchroPulse: type[PsiSynchroPulse]
    PsiSynchroResult: type[PsiSynchroResult]

    def run_multibranch_demo(
        branches: Sequence[PsiBranchState],
        config: PsiSynchroConfig | None = ...,
    ) -> PsiSynchroResult: ...

    def run_zspace_learning(
        branches: Sequence[PsiBranchState],
        config: PsiSynchroConfig | None = ...,
    ) -> PsiSynchroResult: ...


psi: _PsiModule


class MellinLogGrid:
    def __init__(self, log_start: float, log_step: float, samples: Sequence[complex]) -> None: ...

    @staticmethod
    def exp_decay(log_start: float, log_step: float, len: int) -> MellinLogGrid: ...

    def len(self) -> int: ...
    def __len__(self) -> int: ...
    def is_empty(self) -> bool: ...

    @property
    def log_start(self) -> float: ...

    @property
    def log_step(self) -> float: ...

    @property
    def samples(self) -> List[complex]: ...

    @property
    def weights(self) -> List[float]: ...

    @property
    def support(self) -> Tuple[float, float]: ...

    def weighted_series(self) -> List[complex]: ...

    def evaluate(self, s: complex) -> complex: ...
    def evaluate_many(self, s_values: Sequence[complex]) -> List[complex]: ...
    def evaluate_mesh(
        self,
        real_values: Sequence[float],
        imag_values: Sequence[float],
    ) -> List[List[complex]]: ...

    def evaluate_with_series(self, s: complex, weighted: Sequence[complex]) -> complex: ...
    def evaluate_many_with_series(
        self,
        s_values: Sequence[complex],
        weighted: Sequence[complex],
    ) -> List[complex]: ...

    def evaluate_vertical_line(self, real: float, imag_values: Sequence[float]) -> List[complex]: ...

    def hilbert_inner_product(self, other: MellinLogGrid) -> complex: ...
    def hilbert_norm(self) -> float: ...


class FractalFieldGenerator:
    def __init__(
        self,
        octaves: int,
        lacunarity: float = ...,
        gain: float = ...,
        iterations: int = ...,
    ) -> None: ...

    @property
    def octaves(self) -> int: ...

    @property
    def lacunarity(self) -> float: ...

    @property
    def gain(self) -> float: ...

    @property
    def iterations(self) -> int: ...

    def branching_field(self, log_start: float, log_step: float, len: int) -> List[complex]: ...
    def spawn_grid(self, log_start: float, log_step: float, len: int) -> MellinLogGrid: ...
    def weave_with_grid(self, base: MellinLogGrid) -> MellinLogGrid: ...

def fractal_field_probe(
    generator: Any,
    log_start: float,
    log_step: float,
    length: int,
    *,
    preview_len: int = ...,
) -> Dict[str, Any]: ...

def fractal_field_probe_to_zspace_partial(
    probe: Mapping[str, Any],
    *,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> ZSpacePartialBundle: ...

def fractal_field_partial(
    octaves: int,
    log_start: float,
    log_step: float,
    length: int,
    *,
    lacunarity: float = ...,
    gain: float = ...,
    iterations: int = ...,
    preview_len: int = ...,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> ZSpacePartialBundle: ...


class LogZSeries:
    def __init__(
        self,
        log_start: float,
        log_step: float,
        samples: Sequence[float],
        window: str = ...,
        normalisation: str = ...,
    ) -> None: ...

    def len(self) -> int: ...
    def __len__(self) -> int: ...
    def is_empty(self) -> bool: ...

    @property
    def log_start(self) -> float: ...

    @property
    def log_step(self) -> float: ...

    @property
    def samples(self) -> List[float]: ...

    @property
    def weights(self) -> List[float]: ...

    @property
    def window(self) -> str: ...

    @property
    def normalisation(self) -> str: ...

    def evaluate_z(self, z: complex) -> complex: ...
    def evaluate_many_z(self, z_values: Sequence[complex]) -> List[complex]: ...
    def ensure_compatible(self, other: LogZSeries) -> None: ...

def log_z_series_probe(
    series: Any,
    z_values: Sequence[complex],
    *,
    preview_len: int = ...,
) -> Dict[str, Any]: ...

def log_z_series_probe_to_zspace_partial(
    probe: Mapping[str, Any],
    *,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> ZSpacePartialBundle: ...

def log_z_series_partial(
    samples: Sequence[float],
    log_start: float,
    log_step: float,
    z_values: Sequence[complex],
    *,
    window: str = ...,
    normalisation: str = ...,
    preview_len: int = ...,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> ZSpacePartialBundle: ...

def geometry_probe_summary(
    probe: Mapping[str, Any],
    *,
    label: str | None = ...,
) -> Dict[str, Any]: ...

def geometry_probe_to_zspace_partial(
    probe: Mapping[str, Any],
    *,
    bundle_weight: float = ...,
    origin: str | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> ZSpacePartialBundle: ...

def geometry_probes_to_zspace_partials(
    probes: Any,
    *,
    bundle_weight: float = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
) -> List[ZSpacePartialBundle]: ...

def geometry_probe_consensus_partial(
    probes: Any,
    *,
    max_probes: int | None = ...,
    bundle_weight: float = ...,
    consensus_weight: float | None = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
    strategy: str = ...,
    origin: str = ...,
) -> Tuple[ZSpacePartialBundle, Dict[str, Any]]: ...

def build_geometry_probe_context(
    probes: Any,
    *,
    max_probes: int | None = ...,
    bundle_weight: float = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
    include_consensus: bool = ...,
    consensus_only: bool = ...,
    consensus_weight: float | None = ...,
    consensus_strategy: str = ...,
    consensus_origin: str = ...,
) -> Tuple[List[ZSpacePartialBundle], Dict[str, Any]]: ...

def build_geometry_probe_context_artifact(
    probes: Any,
    *,
    max_probes: int | None = ...,
    bundle_weight: float = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
    include_consensus: bool = ...,
    consensus_only: bool = ...,
    consensus_weight: float | None = ...,
    consensus_strategy: str = ...,
    consensus_origin: str = ...,
) -> Dict[str, Any]: ...

def write_geometry_probe_context_artifact(
    path: str | PathLike[str],
    probes: Any,
    *,
    max_probes: int | None = ...,
    bundle_weight: float = ...,
    telemetry_prefix: str = ...,
    gradient_dim: int = ...,
    include_consensus: bool = ...,
    consensus_only: bool = ...,
    consensus_weight: float | None = ...,
    consensus_strategy: str = ...,
    consensus_origin: str = ...,
) -> str: ...

def load_geometry_probe_context_artifact(
    path: str | PathLike[str],
) -> Tuple[List[ZSpacePartialBundle], Dict[str, Any]]: ...


class _FracModule(ModuleType):
    MellinLogGrid: type[MellinLogGrid]
    FractalFieldGenerator: type[FractalFieldGenerator]
    LogZSeries: type[LogZSeries]

    def gl_coeffs_adaptive(alpha: float, tol: float = ..., max_len: int = ...) -> List[float]: ...

    def mellin_exp_decay_samples(log_start: float, log_step: float, len: int) -> List[complex]: ...

    def log_lattice_z_points(log_step: float, s_values: Sequence[complex]) -> List[complex]: ...

    def assemble_pzeta(
        z_points: Sequence[complex],
        h_series: LogZSeries,
        epsilon_series: LogZSeries,
        planck_mass: float,
    ) -> List[float]: ...

    def fracdiff_gl_1d(
        xs: Sequence[float],
        alpha: float,
        kernel_len: int,
        pad: str = ...,
        pad_constant: Optional[float] = ...,
    ) -> List[float]: ...

    def fft_radix2(
        a: Tuple[float, float],
        b: Tuple[float, float],
        twiddle: Tuple[float, float],
    ) -> Tuple[Tuple[float, float], Tuple[float, float]]: ...

    def fft_radix4(
        values: Sequence[Tuple[float, float]],
        twiddles: Sequence[Tuple[float, float]],
    ) -> List[Tuple[float, float]]: ...

    def fft_complex32(
        signal: Sequence[Tuple[float, float]],
        inverse: bool = ...,
    ) -> List[Tuple[float, float]]: ...

    def fft_real(
        signal: Sequence[float],
        inverse: bool = ...,
    ) -> List[Tuple[float, float]]: ...

    def fractal_field_probe(
        generator: Any,
        log_start: float,
        log_step: float,
        length: int,
        *,
        preview_len: int = ...,
    ) -> Dict[str, Any]: ...

    def fractal_field_probe_to_zspace_partial(
        probe: Mapping[str, Any],
        *,
        bundle_weight: float = ...,
        origin: str | None = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
    ) -> ZSpacePartialBundle: ...

    def fractal_field_partial(
        octaves: int,
        log_start: float,
        log_step: float,
        length: int,
        *,
        lacunarity: float = ...,
        gain: float = ...,
        iterations: int = ...,
        preview_len: int = ...,
        bundle_weight: float = ...,
        origin: str | None = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
    ) -> ZSpacePartialBundle: ...

    def log_z_series_probe(
        series: Any,
        z_values: Sequence[complex],
        *,
        preview_len: int = ...,
    ) -> Dict[str, Any]: ...

    def log_z_series_probe_to_zspace_partial(
        probe: Mapping[str, Any],
        *,
        bundle_weight: float = ...,
        origin: str | None = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
    ) -> ZSpacePartialBundle: ...

    def log_z_series_partial(
        samples: Sequence[float],
        log_start: float,
        log_step: float,
        z_values: Sequence[complex],
        *,
        window: str = ...,
        normalisation: str = ...,
        preview_len: int = ...,
        bundle_weight: float = ...,
        origin: str | None = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
    ) -> ZSpacePartialBundle: ...


frac: _FracModule

class _GeometryModule(ModuleType):
    def geometry_probe_summary(
        probe: Mapping[str, Any],
        *,
        label: str | None = ...,
    ) -> Dict[str, Any]: ...

    def geometry_probe_to_zspace_partial(
        probe: Mapping[str, Any],
        *,
        bundle_weight: float = ...,
        origin: str | None = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
    ) -> ZSpacePartialBundle: ...

    def geometry_probes_to_zspace_partials(
        probes: Any,
        *,
        bundle_weight: float = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
    ) -> List[ZSpacePartialBundle]: ...

    def geometry_probe_consensus_partial(
        probes: Any,
        *,
        max_probes: int | None = ...,
        bundle_weight: float = ...,
        consensus_weight: float | None = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
        strategy: str = ...,
        origin: str = ...,
    ) -> Tuple[ZSpacePartialBundle, Dict[str, Any]]: ...

    def build_geometry_probe_context(
        probes: Any,
        *,
        max_probes: int | None = ...,
        bundle_weight: float = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
        include_consensus: bool = ...,
        consensus_only: bool = ...,
        consensus_weight: float | None = ...,
        consensus_strategy: str = ...,
        consensus_origin: str = ...,
    ) -> Tuple[List[ZSpacePartialBundle], Dict[str, Any]]: ...

    def build_geometry_probe_context_artifact(
        probes: Any,
        *,
        max_probes: int | None = ...,
        bundle_weight: float = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
        include_consensus: bool = ...,
        consensus_only: bool = ...,
        consensus_weight: float | None = ...,
        consensus_strategy: str = ...,
        consensus_origin: str = ...,
    ) -> Dict[str, Any]: ...

    def write_geometry_probe_context_artifact(
        path: str | PathLike[str],
        probes: Any,
        *,
        max_probes: int | None = ...,
        bundle_weight: float = ...,
        telemetry_prefix: str = ...,
        gradient_dim: int = ...,
        include_consensus: bool = ...,
        consensus_only: bool = ...,
        consensus_weight: float | None = ...,
        consensus_strategy: str = ...,
        consensus_origin: str = ...,
    ) -> str: ...

    def load_geometry_probe_context_artifact(
        path: str | PathLike[str],
    ) -> Tuple[List[ZSpacePartialBundle], Dict[str, Any]]: ...


geometry: _GeometryModule

class _DatasetModule(ModuleType):
    BYTE_LM_VOCAB: int

    class Dataset:
        def __init__(self) -> None: ...

        @staticmethod
        def from_samples(
            samples: Optional[Sequence[Tuple[Tensor, Tensor]]] = ...,
        ) -> "_DatasetModule.Dataset": ...

        def push(self, input: Tensor, target: Tensor) -> None: ...

        def len(self) -> int: ...

        def __len__(self) -> int: ...

        def is_empty(self) -> bool: ...

        def samples(self) -> List[Tuple[Tensor, Tensor]]: ...

        def iter(self) -> "_DatasetModule.DataLoaderIterator": ...

        def __iter__(self) -> Iterator[Tuple[Tensor, Tensor]]: ...

        def loader(self) -> "_DatasetModule.DataLoader": ...

    class DataLoader:
        @staticmethod
        def from_samples(
            samples: Optional[Sequence[Tuple[Tensor, Tensor]]] = ...,
        ) -> "_DatasetModule.DataLoader": ...

        def len(self) -> int: ...

        def __len__(self) -> int: ...

        def is_empty(self) -> bool: ...

        def batch_size(self) -> int: ...

        def prefetch_depth(self) -> int: ...

        def shuffle(self, seed: int) -> "_DatasetModule.DataLoader": ...

        def batched(self, batch_size: int) -> "_DatasetModule.DataLoader": ...

        def dynamic_batch_by_rows(self, max_rows: int) -> "_DatasetModule.DataLoader": ...

        def prefetch(self, depth: int) -> "_DatasetModule.DataLoader": ...

        def iter(self) -> "_DatasetModule.DataLoaderIterator": ...

        def __iter__(self) -> Iterator[Tuple[Tensor, Tensor]]: ...

    class DataLoaderIterator(Iterator[Tuple[Tensor, Tensor]]):
        def __iter__(self) -> "_DatasetModule.DataLoaderIterator": ...

        def __next__(self) -> Tuple[Tensor, Tensor]: ...

    def from_vec(
        self,
        samples: Iterable[Tuple[Tensor, Tensor]],
    ) -> "_DatasetModule.DataLoader": ...

    def byte_lm_windows(
        self,
        text: str | bytes,
        context: int,
    ) -> List[Tuple[Tensor, Tensor]]: ...

    def byte_lm_corpus_windows(
        self,
        docs: Iterable[str | bytes],
        context: int,
    ) -> List[Tuple[Tensor, Tensor]]: ...

    def byte_lm_sample_stats(
        self,
        samples: Iterable[Tuple[Tensor, Tensor]],
    ) -> Dict[str, int]: ...

    def interleave_replay_samples(
        self,
        target_samples: Iterable[Tuple[Tensor, Tensor]],
        replay_samples: Iterable[Tuple[Tensor, Tensor]],
        *,
        target_per_replay: int = ...,
    ) -> List[Tuple[Tensor, Tensor]]: ...


dataset: _DatasetModule

linalg: ModuleType

class _ModelZooModule(ModuleType):
    class ModelZooEntry:
        key: str
        script_name: str
        task: str
        family: str
        description: str
        tags: Tuple[str, ...]
        script_path: Any

        def to_dict(self) -> Dict[str, Any]: ...

    def focus_presets(self) -> Dict[str, Dict[str, Any]]: ...

    def list_models(
        self,
        *,
        root: str | None = ...,
        include_internal: bool = ...,
        available_only: bool = ...,
        family: str | None = ...,
        task: str | None = ...,
        tags: Sequence[str] | None = ...,
        focus: str | None = ...,
    ) -> List["_ModelZooModule.ModelZooEntry"]: ...

    def find_model(
        self,
        name: str,
        *,
        root: str | None = ...,
        include_internal: bool = ...,
        available_only: bool = ...,
    ) -> "_ModelZooModule.ModelZooEntry": ...

    def suggest_models(
        self,
        query: str | None = ...,
        *,
        root: str | None = ...,
        include_internal: bool = ...,
        available_only: bool = ...,
        task: str | None = ...,
        family: str | None = ...,
        required_tags: Sequence[str] | None = ...,
        prefer_tags: Sequence[str] | None = ...,
        avoid_tags: Sequence[str] | None = ...,
        focus: str | None = ...,
        limit: int | None = ...,
    ) -> List["_ModelZooModule.ModelZooEntry"]: ...

    def recommend_model(
        self,
        query: str | None = ...,
        *,
        root: str | None = ...,
        include_internal: bool = ...,
        available_only: bool = ...,
        task: str | None = ...,
        family: str | None = ...,
        required_tags: Sequence[str] | None = ...,
        prefer_tags: Sequence[str] | None = ...,
        avoid_tags: Sequence[str] | None = ...,
        focus: str | None = ...,
    ) -> "_ModelZooModule.ModelZooEntry": ...

    def resolve_model_script(
        self,
        name: str,
        *,
        root: str | None = ...,
        include_internal: bool = ...,
    ) -> Any: ...

    def build_model_command(
        self,
        name: str,
        *script_args: str,
        root: str | None = ...,
        python_executable: str | None = ...,
    ) -> List[str]: ...

    def run_model(
        self,
        name: str,
        *script_args: str,
        root: str | None = ...,
        python_executable: str | None = ...,
        dry_run: bool = ...,
        check: bool = ...,
        capture_output: bool = ...,
        text: bool = ...,
        env: Mapping[str, str] | None = ...,
        cwd: str | None = ...,
    ) -> Any: ...

    def model_zoo_summary(
        self,
        *,
        root: str | None = ...,
        include_internal: bool = ...,
        available_only: bool = ...,
    ) -> Dict[str, Any]: ...

    def main(self, argv: Sequence[str] | None = ...) -> int: ...

model_zoo: _ModelZooModule

spiral_rl: ModuleType

rec: ModuleType

class _TextModule(ModuleType):
    ContextualLagrangianGate: type[ContextualLagrangianGate]
    ContextualPulseFrame: type[ContextualPulseFrame]

    def token_scale_stack(
        self,
        embeddings: Tensor | Sequence[Sequence[float]],
        scales: Sequence[float],
        threshold: float,
        metric: str = ...,
    ) -> ScaleStack: ...

    def token_coherence_levels(
        self,
        embeddings: Tensor | Sequence[Sequence[float]],
        scales: Sequence[float],
        threshold: float,
        levels: Sequence[float],
        metric: str = ...,
    ) -> List[Optional[float]]: ...

text: _TextModule

class _SafetyModule(ModuleType):
    def drl_default_thresholds() -> Dict[str, Dict[str, float]]: ...

    def drl_analyse_word(
        word: Mapping[str, Any],
        thresholds: Mapping[str, Mapping[str, float]] | None = ...,
        *,
        hazard_cut: float | None = ...,
        min_radius: float = ...,
        direction_queries: Mapping[str, Sequence[Mapping[str, Any]]] | None = ...,
    ) -> Dict[str, Any]: ...

    def drl_analyze_word(
        word: Mapping[str, Any],
        thresholds: Mapping[str, Mapping[str, float]] | None = ...,
        *,
        hazard_cut: float | None = ...,
        min_radius: float = ...,
        direction_queries: Mapping[str, Sequence[Mapping[str, Any]]] | None = ...,
    ) -> Dict[str, Any]: ...

    def drl_existence_load(word: Mapping[str, Any]) -> float: ...

    def drl_safe_radii(
        word: Mapping[str, Any],
        thresholds: Mapping[str, Mapping[str, float]] | None = ...,
    ) -> Dict[str, float]: ...

    def drl_frame_hazard(
        word: Mapping[str, Any],
        frame: str | Mapping[str, Any],
    ) -> float: ...

    def drl_trainer_penalty(metrics: Mapping[str, Any], min_radius: float = ...) -> float: ...

    def drl_aggregate_penalty(
        metrics: Sequence[Mapping[str, Any]],
        min_radius: float = ...,
    ) -> float: ...

    def drl_frame_summary(metrics: Mapping[str, Any]) -> Dict[str, float]: ...

safety: _SafetyModule

class _KvModule(ModuleType):
    def kv_redis_available() -> bool: ...

    def kv_choice_schema_fields() -> List[str]: ...

    def kv_rank_choice_key(
        rows: int,
        cols: int,
        k: int,
        subgroup: bool = ...,
        namespace: str = ...,
    ) -> str: ...

    def kv_choice_key_from_rank_plan(plan: RankPlan, namespace: str = ...) -> str: ...

    def kv_choice_from_rank_plan(plan: RankPlan) -> Dict[str, Any]: ...

    def kv_json_set_options(
        *,
        expiry_seconds: int | None = ...,
        expiry_milliseconds: int | None = ...,
        expiry_at_seconds: int | None = ...,
        expiry_at_milliseconds: int | None = ...,
        keep_ttl: bool = ...,
        persist: bool = ...,
        condition: Literal["always", "nx", "xx"] = ...,
    ) -> Dict[str, Any]: ...

    def kv_redis_set_json(
        url: str,
        key: str,
        value: Any,
        options: Mapping[str, Any] | None = ...,
    ) -> bool: ...

    def kv_redis_get_json(url: str, key: str) -> Any: ...

    def kv_redis_set_choice(
        url: str,
        key: str,
        choice: Mapping[str, Any],
        options: Mapping[str, Any] | None = ...,
    ) -> bool: ...

    def kv_redis_get_choice(url: str, key: str) -> Dict[str, Any] | None: ...

    def kv_redis_push_choice(
        url: str,
        key: str,
        choice: Mapping[str, Any],
        max_len: int | None = ...,
    ) -> int: ...

    def kv_redis_lrange_choice(
        url: str,
        key: str,
        start: int = ...,
        stop: int = ...,
    ) -> List[Dict[str, Any]]: ...

kv: _KvModule

class _WgpuModule(ModuleType):
    WgpuMatmul: type[WgpuMatmul]
    WgpuTensorDevice: type[WgpuTensorDevice]
    WgpuTensor: type[WgpuTensor]
    WgpuTensorSnapshot: type[WgpuTensorSnapshot]
    WgpuRank: type[WgpuRank]
    def wgpu_kernel_reports_available() -> bool: ...

    def wgpu_kernel_catalog() -> List[Dict[str, Any]]: ...

    def wgpu_kernel_descriptor(name: str) -> Dict[str, Any] | None: ...

    def wgpu_rank_kernel_report(
        kind: Literal["topk", "midk", "bottomk"],
        rows: int,
        cols: int,
        k: int,
        *,
        subgroup: bool = ...,
        use_two_stage: bool = ...,
        fft_tile: int = ...,
        fft_radix: int = ...,
        fft_segments: int = ...,
        rank_tile: int = ...,
        compaction_tile: int = ...,
    ) -> Dict[str, Any]: ...

    def wgpu_kernel_report_from_rank_plan(plan: RankPlan) -> Dict[str, Any]: ...

    def wgpu_softmax_kernel_report(
        rows: int,
        cols: int,
        *,
        subgroup: bool = ...,
        hardmax: bool = ...,
        mask: bool = ...,
    ) -> Dict[str, Any]: ...

wgpu: _WgpuModule

class _TelemetryModule(ModuleType):
    DashboardMetric: type[DashboardMetric]
    DashboardEvent: type[DashboardEvent]
    DashboardFrame: type[DashboardFrame]
    DashboardRing: type[DashboardRing]
    AtlasMetric: type[AtlasMetric]
    AtlasFragment: type[AtlasFragment]
    AtlasFrame: type[AtlasFrame]
    AtlasRoute: type[AtlasRoute]
    AtlasMetricFocus: type[AtlasMetricFocus]
    AtlasPerspective: type[AtlasPerspective]

    def current() -> SoftlogicZFeedback | None: ...
    def metric_root_token(name: str) -> str: ...
    def infer_district(name: str) -> str: ...
    def perspective_for_dict(
        route: AtlasRoute,
        district: str,
        focus_prefixes: Optional[Sequence[str]] = ...,
    ) -> Optional[Dict[str, object]]: ...
    def perspective_for_packet(
        route: AtlasRoute,
        district: str,
        focus_prefixes: Optional[Sequence[str]] = ...,
    ) -> Optional[AtlasPerspective]: ...

telemetry: _TelemetryModule

class _PluginModule(ModuleType):
    class PluginQueue:
        @property
        def event_type(self) -> str: ...

        @property
        def subscription_id(self) -> int: ...

        @property
        def maxlen(self) -> int: ...

        def poll(self) -> Optional[Dict[str, object]]: ...
        def drain(self, max_items: int | None = ...) -> List[Dict[str, object]]: ...
        def close(self) -> bool: ...
        def __len__(self) -> int: ...
        def __iter__(self) -> "_PluginModule.PluginQueue": ...
        def __next__(self) -> Dict[str, object]: ...

    class PluginEventRecorder:
        def __init__(self, capacity: int = ...) -> None: ...
        def close(self) -> bool: ...
        def elapsed_ms(self) -> int: ...
        def clear(self) -> None: ...
        def snapshot_json(self) -> str: ...
        def snapshot(self) -> Dict[str, object]: ...
        def write_jsonl(self, path: str) -> None: ...
        def to_mermaid(self, max_nodes: int = ...) -> str: ...
        def __enter__(self) -> "_PluginModule.PluginEventRecorder": ...
        def __exit__(self, exc_type: object, exc: object, tb: object) -> None: ...

    class PluginEventJsonlWriter:
        def __init__(self, path: str, *, capture_tensor_ops: bool = ...) -> None: ...
        def close(self) -> bool: ...
        def elapsed_ms(self) -> int: ...
        def flush(self) -> None: ...
        def __enter__(self) -> "_PluginModule.PluginEventJsonlWriter": ...
        def __exit__(self, exc_type: object, exc: object, tb: object) -> None: ...

    class PluginRecorder:
        path: str
        event_types: List[str]
        closed: bool

        def close(self) -> bool: ...
        def __enter__(self) -> "_PluginModule.PluginRecorder": ...
        def __exit__(self, exc_type: object, exc: object, tb: object) -> None: ...

    def subscribe(self, event_type: str, callback: Callable[[Dict[str, object]], None]) -> int: ...
    def subscribe_many(
        self,
        event_types: Iterable[str],
        callback: Callable[[Dict[str, object]], None],
    ) -> List[Tuple[str, int]]: ...
    def unsubscribe(self, event_type: str, subscription_id: int) -> bool: ...
    def unsubscribe_many(self, subscriptions: Iterable[Tuple[str, int]]) -> int: ...
    def listen(self, event_type: str = ..., *, maxlen: int = ...) -> "_PluginModule.PluginQueue": ...
    def listen_stream(
        self,
        event_type: str = ...,
        *,
        maxlen: int = ...,
        poll_interval: float = ...,
        max_batch: int = ...,
    ) -> Iterator[Dict[str, object]]: ...
    def record(
        self,
        path: Any,
        event_types: str | Iterable[str] = ...,
        *,
        mode: str = ...,
        flush: bool = ...,
    ) -> "_PluginModule.PluginRecorder": ...
    def event_types(self) -> Dict[str, str]: ...
    def list_plugins(self) -> List[str]: ...
    def publish(self, event_type: str, payload: object | None = ...) -> None: ...
    def publish_report(
        self,
        event_type: str,
        payload: object | None = ...,
    ) -> Dict[str, object]: ...
    def has_listeners(self, event_type: str) -> bool: ...
    def clear_listeners(
        self,
        event_type: str | None = ...,
        *,
        strict: bool = ...,
    ) -> int: ...

    def register_python_plugin(self, plugin: Any, *, replace: bool = ...) -> str: ...
    def unregister_plugin(self, plugin_id: str) -> None: ...
    def unregister_safe(
        self,
        plugin_id: str,
        *,
        strict: bool = ...,
    ) -> List[str]: ...
    def dependency_graph(self, *, internal_only: bool = ...) -> Dict[str, List[str]]: ...
    def explain(self, plugin_id: str) -> Dict[str, object]: ...
    def dependency_dot(
        self,
        *,
        internal_only: bool = ...,
        show_missing: bool = ...,
        rankdir: str = ...,
    ) -> str: ...
    def validate_dependencies(self, *, internal_only: bool = ..., strict: bool = ...) -> Dict[str, object]: ...
    def plugin_metadata(self, plugin_id: str) -> Optional[Dict[str, object]]: ...
    def find_by_capability(self, capability: str) -> List[str]: ...

    def get_config(self, key: str) -> Optional[str]: ...
    def set_config(self, key: str, value: str) -> None: ...
    def unset_config(self, key: str) -> bool: ...
    def list_config(self, prefix: str | None = ...) -> Dict[str, str]: ...
    def clear_config(self, prefix: str | None = ..., *, strict: bool = ...) -> List[str]: ...
    def register_service(self, name: str, service: object) -> None: ...
    def get_service(self, name: str) -> Optional[object]: ...
    def list_services(self) -> List[str]: ...
    def unregister_service(self, name: str) -> bool: ...
    def clear_services(
        self,
        prefix: str | None = ...,
        *,
        strict: bool = ...,
    ) -> List[str]: ...
    def initialize_all(self) -> None: ...
    def shutdown(self) -> None: ...
    def reset(self, *, strict: bool = ...) -> Dict[str, List[str]]: ...

    def load_entrypoints(
        self,
        group: str = ...,
        *,
        instantiate: bool = ...,
        replace: bool = ...,
    ) -> List[str]: ...
    def reload_entrypoints(
        self,
        group: str = ...,
        *,
        instantiate: bool = ...,
        strict: bool = ...,
    ) -> List[str]: ...
    def load_path(
        self,
        path: str,
        *,
        recursive: bool = ...,
        instantiate: bool = ...,
        strict: bool = ...,
        reload: bool = ...,
        replace: bool = ...,
        module_prefix: str = ...,
        add_sys_path: bool = ...,
    ) -> List[str]: ...
    def reload_path(
        self,
        path: str,
        *,
        recursive: bool = ...,
        instantiate: bool = ...,
        strict: bool = ...,
        module_prefix: str = ...,
        add_sys_path: bool = ...,
    ) -> List[str]: ...

    class PluginPathWatcher:
        def stop(self, timeout: float | None = ...) -> None: ...
        def is_running(self) -> bool: ...
        def __enter__(self) -> "_PluginModule.PluginPathWatcher": ...
        def __exit__(self, exc_type: object, exc: object, tb: object) -> None: ...

    def watch_path(
        self,
        path: Any,
        *,
        recursive: bool = ...,
        instantiate: bool = ...,
        strict: bool = ...,
        poll_interval: float = ...,
        debounce: float = ...,
        missing_grace: float = ...,
        unload_on_stop: bool = ...,
        module_prefix: str = ...,
        add_sys_path: bool = ...,
        on_error: Callable[[BaseException, str], None] | None = ...,
    ) -> "_PluginModule.PluginPathWatcher": ...

    def unload_path(
        self,
        path: Any,
        *,
        recursive: bool = ...,
        strict: bool = ...,
    ) -> List[str]: ...

    def unload_entrypoints(
        self,
        group: str = ...,
        *,
        strict: bool = ...,
    ) -> List[str]: ...

    def unload_all(self, *, strict: bool = ...) -> List[str]: ...

plugin: _PluginModule

ecosystem: ModuleType

class _OpsModule(ModuleType):
    @overload
    def register(
        self,
        name: str,
        num_inputs: int,
        num_outputs: int,
        forward: Callable[[Sequence[Tensor]], Tensor | Sequence[Tensor]],
        *,
        backward: Callable[[Sequence[Tensor], Sequence[Tensor], Sequence[Tensor]], Tensor | Sequence[Tensor]] | None = ...,
        description: str | None = ...,
        backends: Sequence[str] | None = ...,
        attributes: Mapping[str, object] | None = ...,
        supports_inplace: bool = ...,
        differentiable: bool | None = ...,
    ) -> None: ...

    @overload
    def register(
        self,
        name: str,
        forward: Callable[[Sequence[Tensor]], Tensor | Sequence[Tensor]],
        backward: Callable[[Sequence[Tensor], Sequence[Tensor], Sequence[Tensor]], Tensor | Sequence[Tensor]] | None = ...,
        *,
        num_inputs: int | None = ...,
        num_outputs: int | None = ...,
        description: str | None = ...,
        backends: Sequence[str] | None = ...,
        attributes: Mapping[str, object] | None = ...,
        supports_inplace: bool = ...,
        differentiable: bool | None = ...,
    ) -> None: ...

    def signature(
        self,
        num_inputs: int,
        num_outputs: int,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]: ...

    @overload
    def execute(
        self,
        name: str,
        inputs: Sequence[Tensor],
        *,
        return_single: bool = ...,
    ) -> Tensor | List[Tensor]: ...

    @overload
    def execute(
        self,
        name: str,
        *inputs: Tensor,
        return_single: bool = ...,
    ) -> Tensor | List[Tensor]: ...

    def backward(
        self,
        name: str,
        inputs: Sequence[Tensor],
        outputs: Sequence[Tensor],
        grad_outputs: Sequence[Tensor],
        *,
        return_single: bool = ...,
    ) -> Tensor | List[Tensor]: ...

    def list_operators(self) -> List[str]: ...
    def unregister(self, name: str) -> bool: ...
    def metadata(self, name: str) -> Dict[str, object]: ...
    def describe(self, name: str) -> str: ...

ops: _OpsModule

text: ModuleType

theory: ModuleType

scale_stack: ModuleType

rl: ModuleType

robotics: ModuleType

class _SotModule(ModuleType):
    SoT3DPlan: type[SoT3DPlan]
    SoT3DStep: type[SoT3DStep]
    MacroSummary: type[MacroSummary]

    def generate_plan(
        total_steps: int,
        base_radius: float = ...,
        radial_growth: float = ...,
        base_height: float = ...,
        meso_gain: float = ...,
        micro_gain: float = ...,
    ) -> SoT3DPlan: ...

    def pack_tribonacci_chunks(length: int) -> List[int]: ...
    def pack_tetranacci_chunks(length: int) -> List[int]: ...
    def fibonacci_pacing(total_steps: int) -> List[int]: ...
    def golden_angle() -> float: ...
    def golden_ratio() -> float: ...

sot: _SotModule

class _ZSpaceModule(ModuleType):
    ZMetrics: type[ZMetrics]
    ZSpaceTrainer: type[ZSpaceTrainer]
    step_many: staticmethod
    stream_zspace_training: staticmethod

zspace: _ZSpaceModule

class _VisionModule(ModuleType):
    ImageTensor: type[ImageTensor]
    TransformPipeline: type[TransformPipeline]
    VisionSample: type[VisionSample]
    TensorVisionDataset: type[TensorVisionDataset]
    VisionBatch: type[VisionBatch]
    VisionDataLoader: type[VisionDataLoader]
    VisionModel: type[VisionModel]
    ChronoSnapshot: type[ChronoSnapshot]
    ZSpaceStreamFrame: type[ZSpaceStreamFrame]
    StreamedVolume: type[StreamedVolume]
    ZSpaceStreamFrameAggregator: type[ZSpaceStreamFrameAggregator]
    SpiralTorchVision: type[SpiralTorchVision]
    TemporalResonanceBuffer: type[TemporalResonanceBuffer]
    SliceProfile: type[SliceProfile]
    FractalCanvas: type[FractalCanvas]
    InfiniteZSpacePatch: type[InfiniteZSpacePatch]

    def vision_dataset_catalog(self) -> List[Dict[str, object]]: ...

    def vision_dataset_descriptor(self, name: str) -> Dict[str, object] | None: ...

    def vision_model_catalog(self) -> List[Dict[str, object]]: ...

    def vision_model_descriptor(self, name: str) -> Dict[str, object] | None: ...

    def vision_transform_audit_catalog(self) -> List[Dict[str, object]]: ...

    def vision_standard_classification_pipeline(
        self,
        image_size: int = ...,
        *,
        seed: int | None = ...,
    ) -> TransformPipeline: ...

    def vision_create_classification_model(
        self,
        kind: str,
        num_classes: int = ...,
        *,
        seed: int | None = ...,
    ) -> VisionModel: ...

    def vision_online_step(
        self,
        vision: SpiralTorchVision,
        payload: object,
        *,
        aggregator: object | None = ...,
        trainer: ZSpaceTrainer | None = ...,
        weight: float = ...,
        metrics_builder: Callable[[SpiralTorchVision, Mapping[str, object]], Mapping[str, object] | ZMetrics] | None = ...,
        step_index: int | None = ...,
    ) -> Dict[str, object]: ...

    def stream_vision_training(
        self,
        vision: SpiralTorchVision,
        frames: Iterable[object],
        *,
        aggregator: object | None = ...,
        trainer: ZSpaceTrainer | None = ...,
        weight: float = ...,
        flush_every: int = ...,
        keep_depth: int | None = ...,
        metrics_builder: Callable[[SpiralTorchVision, Mapping[str, object]], Mapping[str, object] | ZMetrics] | None = ...,
        on_step: Callable[[int, Dict[str, object]], None] | None = ...,
        final_flush: bool = ...,
    ) -> List[Dict[str, object]]: ...

vision: _VisionModule

class _CanvasModule(ModuleType):
    CanvasTransformer: type[CanvasTransformer]
    CanvasSnapshot: type[CanvasSnapshot]
    CanvasProjector: type[CanvasProjector]
    CanvasZSpacePatch: type[CanvasZSpacePatch]
    CanvasWasmTrail: type[CanvasWasmTrail]

    def apply_vision_update(
        vision: SpiralTorchVision,
        canvas: CanvasTransformer,
        *,
        hypergrad: Sequence[Sequence[float]] | None = ...,
        realgrad: Sequence[Sequence[float]] | None = ...,
        weight: float = ...,
        include_patch: bool = ...,
    ) -> CanvasSnapshot: ...

    def available_palettes() -> List[str]: ...
    def canonical_palette(name: str) -> str: ...
    def emit_zspace_patch_dict(
        projector: CanvasProjector,
        *,
        coherence: float = ...,
        tension: float = ...,
        depth: int = ...,
    ) -> Dict[str, object]: ...
    def emit_zspace_patch_packet(
        projector: CanvasProjector,
        *,
        coherence: float = ...,
        tension: float = ...,
        depth: int = ...,
    ) -> CanvasZSpacePatch: ...
    def emit_wasm_trail_dict(
        projector: CanvasProjector,
        curvature: float = ...,
    ) -> Dict[str, object]: ...
    def emit_wasm_trail_packet(
        projector: CanvasProjector,
        curvature: float = ...,
    ) -> CanvasWasmTrail: ...

canvas: _CanvasModule

class _QrModule(ModuleType):
    QuantumOverlayConfig: type[QuantumOverlayConfig]
    ZResonance: type[ZResonance]
    ZOverlayCircuit: type[ZOverlayCircuit]
    QuantumMeasurement: type[QuantumMeasurement]
    QuantumRealityStudio: type[QuantumRealityStudio]

qr: _QrModule

class _JuliaModule(ModuleType):
    ZTigerOptim: type[ZTigerOptim]

    def tempo_latency_score(self, tile: int, slack: int) -> float: ...

julia: _JuliaModule

class _SelfSupModule(ModuleType):
    def info_nce(
        anchors: Sequence[Sequence[float]],
        positives: Sequence[Sequence[float]],
        temperature: float = ...,
        normalize: bool = ...,
    ) -> Dict[str, object]: ...

    def masked_mse(
        predictions: Sequence[Sequence[float]],
        targets: Sequence[Sequence[float]],
        mask_indices: Sequence[Sequence[int]],
    ) -> Dict[str, object]: ...

selfsup: _SelfSupModule

class _PlannerModule(ModuleType):
    RankPlan: type[RankPlan]
    RankAdaptationSelection: type[RankAdaptationSelection]
    RankAdaptationSession: type[RankAdaptationSession]
    RANK_ADAPTATION_CONTRACT_VERSION: Literal["spiraltorch.rank_adaptation.v1"]
    RANK_ADAPTATION_SEMANTIC_OWNER: Literal["st-core::runtime::rank_adaptation"]

    def plan(
        kind: Literal["topk", "midk", "bottomk", "fft"],
        rows: int,
        cols: int,
        k: int,
        *,
        backend: Optional[str] = ...,
        lane_width: Optional[int] = ...,
        subgroup: Optional[bool] = ...,
        max_workgroup: Optional[int] = ...,
        shared_mem_per_workgroup: Optional[int] = ...,
        strict_accelerator: Optional[bool] = ...,
    ) -> RankPlan: ...

    def plan_topk(
        rows: int,
        cols: int,
        k: int,
        *,
        backend: Optional[str] = ...,
        lane_width: Optional[int] = ...,
        subgroup: Optional[bool] = ...,
        max_workgroup: Optional[int] = ...,
        shared_mem_per_workgroup: Optional[int] = ...,
        strict_accelerator: Optional[bool] = ...,
    ) -> RankPlan: ...

    def describe_device(
        backend: str = ...,
        *,
        lane_width: Optional[int] = ...,
        subgroup: Optional[bool] = ...,
        max_workgroup: Optional[int] = ...,
        shared_mem_per_workgroup: Optional[int] = ...,
        workgroup: Optional[int] = ...,
        cols: Optional[int] = ...,
        tile_hint: Optional[int] = ...,
        compaction_hint: Optional[int] = ...,
    ) -> Dict[str, object]: ...

    def hip_probe() -> Dict[str, object]: ...
    def mps_probe() -> Dict[str, object]: ...
    def probe_gpu_path(
        kind: Literal["topk", "midk", "bottomk"] = ...,
        *,
        backend: Literal["cuda", "hip"] = ...,
        rows: int = ...,
        cols: int = ...,
        k: int = ...,
    ) -> Dict[str, object]: ...
    def generate_plan_batch_ex(
        n: int,
        total_steps: int,
        base_radius: float,
        radial_growth: float,
        base_height: float,
        meso_gain: float,
        micro_gain: float,
        seed: Optional[int] = ...,
    ) -> List[SoT3DPlan]: ...

planner: _PlannerModule

class QueryPlan:
    def __init__(self, query: str) -> None: ...
    @property
    def query(self) -> str: ...
    def selects(self) -> List[str]: ...
    def limit(self) -> Optional[int]: ...
    def order(self) -> Optional[Tuple[str, str]]: ...
    def filters(self) -> List[Tuple[str, str, float]]: ...

class RecEpochReport:
    rmse: float
    samples: int
    regularization_penalty: float

class Recommender:
    def __init__(
        self,
        users: int,
        items: int,
        factors: int,
        learning_rate: float = ...,
        regularization: float = ...,
        curvature: float | None = ...,
    ) -> None: ...
    def predict(self, user: int, item: int) -> float: ...
    def train_epoch(self, ratings: Sequence[Tuple[int, int, float]]) -> RecEpochReport: ...
    def recommend_top_k(self, user: int, k: int, exclude: Optional[Sequence[int]] = ...) -> List[Tuple[int, float]]: ...
    def recommend_query(
        self, user: int, query: QueryPlan, exclude: Optional[Sequence[int]] = ...
    ) -> List[Dict[str, float]]: ...
    def user_embedding(self, user: int) -> Tensor: ...
    def item_embedding(self, item: int) -> Tensor: ...
    @property
    def users(self) -> int: ...
    @property
    def items(self) -> int: ...
    @property
    def factors(self) -> int: ...

class EpsilonGreedy:
    def __init__(self, start: float, end: float, decay_steps: int) -> None: ...
    @property
    def start(self) -> float: ...
    @property
    def end(self) -> float: ...
    @property
    def decay_steps(self) -> int: ...
    @property
    def step(self) -> int: ...
    def value(self) -> float: ...
    def advance(self) -> float: ...

class Replay:
    def __init__(
        self,
        capacity: int,
        batch_size: int,
        prioritized: bool = ...,
        alpha: float = ...,
        beta0: float = ...,
    ) -> None: ...
    @property
    def capacity(self) -> int: ...
    @property
    def batch_size(self) -> int: ...
    @property
    def prioritized(self) -> bool: ...
    @property
    def alpha(self) -> float: ...
    @property
    def beta0(self) -> float: ...

class AgentConfig:
    def __init__(
        self,
        algo: str,
        state_dim: int,
        action_dim: int,
        gamma: float,
        lr: float,
        exploration: EpsilonGreedy | None = ...,
        optimizer: str = ...,
        clip_grad: float | None = ...,
        replay: Replay | None = ...,
        target_sync: int | None = ...,
        n_step: int | None = ...,
        seed: int | None = ...,
    ) -> None: ...
    @property
    def algo(self) -> str: ...
    @property
    def state_dim(self) -> int: ...
    @property
    def action_dim(self) -> int: ...
    @property
    def gamma(self) -> float: ...
    @property
    def lr(self) -> float: ...
    @property
    def optimizer(self) -> str: ...
    @property
    def clip_grad(self) -> float | None: ...
    @property
    def replay(self) -> Replay | None: ...
    @property
    def target_sync(self) -> int | None: ...
    @property
    def n_step(self) -> int | None: ...
    @property
    def seed(self) -> int | None: ...
    @property
    def exploration(self) -> EpsilonGreedy | None: ...

class Agent:
    def __init__(self, config: AgentConfig) -> None: ...
    @property
    def config(self) -> AgentConfig: ...
    @property
    def algo(self) -> str: ...
    def select_action(self, state: int) -> int: ...
    def select_actions(self, states: Sequence[int]) -> List[int]: ...
    def q_values(self, state: int) -> List[float]: ...
    def greedy_action(self, state: int) -> int: ...
    def policy_report(self, state: int) -> Dict[str, object]: ...
    def select_action_trace(self, state: int) -> Dict[str, object]: ...
    def update(self, state: int, action: int, reward: float, next_state: int) -> None: ...
    def update_batch(
        self,
        states: Sequence[int],
        actions: Sequence[int],
        rewards: Sequence[float],
        next_states: Sequence[int],
        dones: Optional[Sequence[bool]] = ...,
    ) -> None: ...
    @property
    def epsilon(self) -> float: ...
    def epsilon(self) -> float: ...
    def set_epsilon(self, epsilon: float) -> None: ...
    def set_exploration(self, schedule: EpsilonGreedy) -> None: ...
    def state_dict(self) -> Dict[str, object]: ...
    def load_state_dict(self, state: Mapping[str, object]) -> None: ...

class stAgent:
    def __init__(self, state_dim: int, action_dim: int, discount: float, learning_rate: float) -> None: ...
    def select_action(self, state: int) -> int: ...
    def select_actions(self, states: Sequence[int]) -> List[int]: ...
    def q_values(self, state: int) -> List[float]: ...
    def greedy_action(self, state: int) -> int: ...
    def policy_report(self, state: int) -> Dict[str, object]: ...
    def select_action_trace(self, state: int) -> Dict[str, object]: ...
    def update(self, state: int, action: int, reward: float, next_state: int) -> None: ...
    def update_batch(
        self,
        states: Sequence[int],
        actions: Sequence[int],
        rewards: Sequence[float],
        next_states: Sequence[int],
        dones: Optional[Sequence[bool]] = ...,
    ) -> None: ...
    @property
    def epsilon(self) -> float: ...
    def epsilon(self) -> float: ...
    def set_epsilon(self, epsilon: float) -> None: ...
    def set_exploration(self, schedule: EpsilonGreedy) -> None: ...
    def state_dict(self) -> Dict[str, object]: ...
    def load_state_dict(self, state: Mapping[str, object]) -> None: ...

DqnAgent = stAgent

class PpoAgent:
    def __init__(self, state_dim: int, action_dim: int, learning_rate: float, clip_range: float) -> None: ...
    def score_actions(self, state: Sequence[float]) -> List[float]: ...
    def value(self, state: Sequence[float]) -> float: ...
    def update(self, state: Sequence[float], action: int, advantage: float, old_log_prob: float) -> None: ...

class SacAgent:
    def __init__(self, state_dim: int, action_dim: int, temperature: float) -> None: ...
    def sample_action(self, state: Sequence[float]) -> int: ...
    def jitter(self, entropy_target: float) -> None: ...

class AtlasMetric:
    name: str
    value: float
    district: Optional[str]

class AtlasFragment:
    def __init__(self, timestamp: float | None = ...) -> None: ...
    @property
    def timestamp(self) -> float | None: ...
    def set_timestamp(self, timestamp: float) -> None: ...
    def is_empty(self) -> bool: ...
    def push_metric(self, name: str, value: float, district: str | None = ...) -> None: ...
    def push_note(self, note: str) -> None: ...
    def metrics(self) -> List[AtlasMetric]: ...
    def notes(self) -> List[str]: ...
    def to_frame(self) -> AtlasFrame | None: ...

class AtlasFrame:
    @staticmethod
    def from_metrics(
        metrics: Mapping[str, float],
        *,
        timestamp: float | None = ...,
    ) -> AtlasFrame: ...
    @property
    def timestamp(self) -> float: ...
    def metric_value(self, name: str) -> float | None: ...
    def metrics_with_prefix(self, prefix: str) -> List[AtlasMetric]: ...
    def metrics(self) -> List[AtlasMetric]: ...
    def notes(self) -> List[str]: ...
    def districts(self) -> List[Dict[str, object]]: ...

class AtlasRoute:
    def __init__(self) -> None: ...
    def is_empty(self) -> bool: ...
    def len(self) -> int: ...
    def __len__(self) -> int: ...
    def latest_timestamp(self) -> float | None: ...
    def push_bounded(self, frame: AtlasFrame, bound: int) -> None: ...
    def summary(self) -> Dict[str, object]: ...
    def perspective_for(
        self, district: str, focus_prefixes: Optional[Sequence[str]] = ...
    ) -> Optional[Dict[str, object]]: ...
    def beacons(self, limit: int = ...) -> List[Dict[str, object]]: ...

class AtlasMetricFocus:
    name: str
    coverage: int
    mean: float
    latest: float
    delta: float
    momentum: float
    std_dev: float

class AtlasPerspective:
    district: str
    coverage: int
    mean: float
    latest: float
    delta: float
    momentum: float
    volatility: float
    stability: float
    guidance: str
    focus: List[AtlasMetricFocus]

    def to_dict(self) -> Dict[str, object]: ...

class DashboardMetric:
    name: str
    value: float
    unit: Optional[str]
    trend: Optional[float]

class DashboardEvent:
    message: str
    severity: str

class DashboardFrame:
    timestamp: float
    metrics: List[DashboardMetric]
    events: List[DashboardEvent]

class DashboardRing:
    def __init__(self, capacity: int) -> None: ...
    def push(self, frame: DashboardFrame) -> None: ...
    def latest(self) -> Optional[DashboardFrame]: ...
    def __iter__(self) -> Iterable[DashboardFrame]: ...

class ZSpaceSpinBand:
    name: str
    label: str

class ZSpaceRadiusBand:
    name: str
    label: str

class ZSpaceRegionKey:
    spin: ZSpaceSpinBand
    radius: ZSpaceRadiusBand
    label: str

class ZSpaceRegionDescriptor:
    spin_alignment: float
    normalized_radius: float
    curvature_radius: float
    geodesic_radius: float
    sheet_index: int
    sheet_count: int
    topological_sector: int
    @property
    def key(self) -> ZSpaceRegionKey: ...
    @property
    def spin_band(self) -> ZSpaceSpinBand: ...
    @property
    def radius_band(self) -> ZSpaceRadiusBand: ...
    @property
    def label(self) -> str: ...

class SoftlogicEllipticSample:
    curvature_radius: float
    geodesic_radius: float
    normalized_radius: float
    spin_alignment: float
    sheet_index: int
    sheet_position: float
    normal_bias: float
    sheet_count: int
    topological_sector: int
    homology_index: int
    rotor_field: tuple[float, float, float]
    flow_vector: tuple[float, float, float]
    curvature_tensor: tuple[tuple[float, float, float], tuple[float, float, float], tuple[float, float, float]]
    resonance_heat: float
    noise_density: float
    quaternion: tuple[float, float, float, float]
    rotation: tuple[tuple[float, float, float], tuple[float, float, float], tuple[float, float, float]]
    def region_descriptor(self) -> ZSpaceRegionDescriptor: ...

class SoftlogicZFeedback:
    psi_total: float
    weighted_loss: float
    band_energy: tuple[float, float, float]
    drift: float
    z_signal: float
    scale: tuple[float, float] | None
    events: List[str]
    attributions: List[tuple[str, float]]
    elliptic: SoftlogicEllipticSample | None
    region: ZSpaceRegionDescriptor | None
    def band_energy_detail(self) -> Dict[str, object]: ...
    def has_event(self, tag: str) -> bool: ...
    def spin_band(self) -> ZSpaceSpinBand | None: ...
    def radius_band(self) -> ZSpaceRadiusBand | None: ...
    def label(self) -> str | None: ...

class CurvatureDecision:
    raw_pressure: float
    smoothed_pressure: float
    curvature: float
    changed: bool

class CurvatureScheduler:
    def __init__(
        self,
        *,
        initial: float | None = ...,
        min_curvature: float | None = ...,
        max_curvature: float | None = ...,
        min: float | None = ...,
        max: float | None = ...,
        target_pressure: float = ...,
        step: float | None = ...,
        tolerance: float | None = ...,
        smoothing: float | None = ...,
    ) -> None: ...
    @property
    def current(self) -> float: ...
    @property
    def min_curvature(self) -> float: ...
    @property
    def max_curvature(self) -> float: ...
    @property
    def target_pressure(self) -> float: ...
    @property
    def step(self) -> float: ...
    @property
    def proportional_gain(self) -> float: ...
    @property
    def tolerance(self) -> float: ...
    @property
    def smoothing(self) -> float: ...
    @property
    def last_pressure(self) -> float | None: ...
    @property
    def last_pressure_variance(self) -> float | None: ...
    @property
    def last_pressure_rel_variance(self) -> float | None: ...
    @property
    def stability_threshold(self) -> float: ...
    @property
    def stability_boost(self) -> float: ...
    @property
    def dither_strength(self) -> float: ...
    @property
    def dither_period(self) -> int: ...
    def set_bounds(self, min_curvature: float, max_curvature: float) -> None: ...
    def set_target_pressure(self, target: float) -> None: ...
    def set_step(self, step: float) -> None: ...
    def set_proportional_gain(self, gain: float) -> None: ...
    def set_tolerance(self, tolerance: float) -> None: ...
    def set_stability_threshold(self, threshold: float) -> None: ...
    def set_stability_boost(self, boost: float) -> None: ...
    def set_dither(self, strength: float, period: int) -> None: ...
    def set_smoothing(self, smoothing: float) -> None: ...
    def apply_env_overrides(self) -> None: ...
    def sync(self, curvature: float) -> None: ...
    def observe(self, summary: GradientSummary) -> CurvatureDecision: ...
    def observe_pressure(self, raw_pressure: float) -> CurvatureDecision: ...

class SpectralLearningRatePolicy:
    def __init__(
        self,
        *,
        smoothing: float | None = ...,
        event_smoothing: float | None = ...,
        turnover_smoothing: float | None = ...,
        phase_gain: float | None = ...,
        stuck_phase_gain: float | None = ...,
        stuck_turnover_threshold: float | None = ...,
        coherence_gain: float | None = ...,
        sheet_gain: float | None = ...,
        spin_gain: float | None = ...,
        radius_gain: float | None = ...,
        energy_gain: float | None = ...,
        lr_bounds: tuple[float, float] | None = ...,
        band_bounds: tuple[float, float] | None = ...,
        max_lr_step: float | None = ...,
        env_overrides: bool = ...,
    ) -> None: ...
    @property
    def dominant_turnover(self) -> float: ...
    @property
    def last_coherence_label(self) -> str | None: ...
    def apply_env_overrides(self) -> None: ...
    def set_smoothing(self, smoothing: float) -> None: ...
    def set_event_smoothing(self, smoothing: float) -> None: ...
    def set_turnover_smoothing(self, smoothing: float) -> None: ...
    def set_phase_gain(self, gain: float) -> None: ...
    def set_stuck_phase_gain(self, gain: float) -> None: ...
    def set_stuck_turnover_threshold(self, threshold: float) -> None: ...
    def set_coherence_gain(self, gain: float) -> None: ...
    def set_sheet_gain(self, gain: float) -> None: ...
    def set_spin_gain(self, gain: float) -> None: ...
    def set_radius_gain(self, gain: float) -> None: ...
    def set_energy_gain(self, gain: float) -> None: ...
    def set_lr_bounds(self, min: float, max: float) -> None: ...
    def set_band_bounds(self, min: float, max: float) -> None: ...
    def set_max_lr_step(self, max_step: float) -> None: ...

def zspace_snapshot() -> Optional[ZSpaceRegionDescriptor]: ...
def softlogic_feedback() -> Optional[SoftlogicZFeedback]: ...
def clear_zspace_feedback() -> bool: ...
def describe_zspace(*, latest: bool = ..., feedback: bool = ...) -> Optional[object]: ...
def softlogic_signal() -> Optional[dict[str, object]]: ...

__all__ = [
    "Tensor",
    "AutogradTensor",
    "AutogradPackedRhs",
    "AutogradSgd",
    "AUTOGRAD_CONTRACT_VERSION",
    "AUTOGRAD_SEMANTIC_OWNER",
    "ModuleTrainer",
    "SpiralSession",
    "describe_runtime_devices",
    "trace_wgpu_first_runtime",
    "trace_wgpu_first_runtime_matrix",
    "write_wgpu_first_runtime_matrix",
    "hf_ft",
    "hf_peft",
    "hf_input_identity",
    "hf_execution_identity",
    "hf_runtime_identity",
    "hf_adapter",
    "hf_adapter_executor",
    "hf_adapter_executor_launch",
    "hf_adapter_executor_recovery",
    "hf_adapter_executor_runtime",
    "hf_adapter_executor_status",
    "hf_adapter_executor_supervisor",
    "hf_adapter_executor_supervisor_launch",
    "hf_generation",
    "hf_ft_status",
    "HF_FINETUNE_DEFAULT_DEVICE_BACKENDS",
    "HF_FINETUNE_DEFAULT_MODEL_CONFIGS",
    "HF_FINETUNE_MODEL_CONFIG_SCHEMA",
    "HF_FINETUNE_RUN_CARD_FILENAME",
    "HF_ZSPACE_MATCHED_ABLATION_SCHEMA",
    "HF_ZSPACE_FACTORIZED_ABLATION_SCHEMA",
    "HF_ZSPACE_FEEDBACK_ABLATION_SCHEMA",
    "HF_ZSPACE_POLARITY_ABLATION_SCHEMA",
    "HF_ZSPACE_OPTIMIZER_CONTROL_SCHEMA",
    "HF_ZSPACE_OPTIMIZER_FEEDBACK_MODES",
    "HF_ZSPACE_OPTIMIZER_MODES",
    "HF_ZSPACE_OPTIMIZER_RECEIPT_SCHEMA",
    "HF_ZSPACE_OPTIMIZER_STATE_FILENAME",
    "HF_ZSPACE_OPTIMIZER_STATE_SCHEMA",
    "HF_ZSPACE_OPTIMIZER_TRACE_FILENAME",
    "HF_ZSPACE_OPTIMIZER_TRACE_SCHEMA",
    "HF_ZSPACE_OPTIMIZER_TRAJECTORY_ARMS",
    "HF_ZSPACE_OPTIMIZER_TRAJECTORY_FILENAME",
    "HF_ZSPACE_OPTIMIZER_TRAJECTORY_POLICY_FILENAME",
    "compare_hf_zspace_optimizer_factorized_run_cards",
    "compare_hf_zspace_optimizer_feedback_run_cards",
    "compare_hf_zspace_optimizer_polarity_run_cards",
    "compare_hf_zspace_optimizer_run_cards",
    "hf_zspace_optimizer_control_callback",
    "hf_zspace_optimizer_recipe_contract",
    "write_hf_zspace_optimizer_factorized_ablation_report",
    "write_hf_zspace_optimizer_feedback_ablation_report",
    "write_hf_zspace_optimizer_polarity_ablation_report",
    "write_hf_zspace_optimizer_matched_ablation_report",
    "HF_ZSPACE_FACTORIZED_GAIN_RESPONSE_FILENAME",
    "HF_ZSPACE_FACTORIZED_GAIN_RESPONSE_SCHEMA",
    "HF_ZSPACE_FACTORIZED_STUDY_ARMS",
    "HF_ZSPACE_FACTORIZED_STUDY_EVENT_SCHEMA",
    "HF_ZSPACE_FACTORIZED_STUDY_REPORT_FILENAME",
    "HF_ZSPACE_FACTORIZED_STUDY_SCHEMA",
    "HF_ZSPACE_FACTORIZED_STUDY_SUMMARY_SCHEMA",
    "HF_ZSPACE_FEEDBACK_STUDY_ARMS",
    "HF_ZSPACE_FEEDBACK_STUDY_EVENT_SCHEMA",
    "HF_ZSPACE_FEEDBACK_STUDY_REPORT_FILENAME",
    "HF_ZSPACE_FEEDBACK_STUDY_SCHEMA",
    "HF_ZSPACE_FEEDBACK_STUDY_SUMMARY_SCHEMA",
    "HF_ZSPACE_POLARITY_STUDY_ARMS",
    "HF_ZSPACE_POLARITY_CORPUS_REPORT_FILENAME",
    "HF_ZSPACE_POLARITY_CORPUS_REPORT_SCHEMA",
    "HF_ZSPACE_POLARITY_CORPUS_STUDY_PLAN_FILENAME",
    "HF_ZSPACE_POLARITY_CORPUS_STUDY_SCHEMA",
    "HF_ZSPACE_POLARITY_CORPUS_STUDY_SUMMARY_FILENAME",
    "HF_ZSPACE_POLARITY_CORPUS_STUDY_SUMMARY_SCHEMA",
    "HF_ZSPACE_POLARITY_STUDY_EVENT_SCHEMA",
    "HF_ZSPACE_POLARITY_STUDY_REPORT_FILENAME",
    "HF_ZSPACE_POLARITY_STUDY_SCHEMA",
    "HF_ZSPACE_POLARITY_STUDY_SUMMARY_SCHEMA",
    "HFZSpaceFactorizedStudyError",
    "build_hf_zspace_optimizer_factorized_study_plan",
    "build_hf_zspace_optimizer_feedback_study_plan",
    "build_hf_zspace_optimizer_polarity_study_plan",
    "build_hf_zspace_optimizer_polarity_corpus_study_plan",
    "compare_hf_zspace_optimizer_factorized_gain_studies",
    "compare_hf_zspace_optimizer_polarity_studies",
    "run_hf_zspace_optimizer_factorized_study",
    "run_hf_zspace_optimizer_feedback_study",
    "run_hf_zspace_optimizer_polarity_study",
    "run_hf_zspace_optimizer_polarity_corpus_study",
    "write_hf_zspace_optimizer_factorized_gain_response_report",
    "write_hf_zspace_optimizer_polarity_corpus_report",
    "HF_FINETUNE_TRAINER_TRACE_FILENAME",
    "HF_FINETUNE_TRAINER_TRACE_LINEAGE_SCHEMA",
    "HF_FINETUNE_TRAINER_TRACE_SEGMENT_SCHEMA",
    "HF_FINETUNE_REQUIRED_PYTHON_PACKAGES",
    "HF_FINETUNE_REQUIRED_RUST_SURFACES",
    "HF_FINETUNE_INPUT_IDENTITY_SCHEMA",
    "HF_FINETUNE_EXECUTION_IDENTITY_SCHEMA",
    "HF_CAUSAL_LM_ARTIFACT_KINDS",
    "HF_CAUSAL_LM_RUNTIME_IDENTITY_SCHEMA",
    "HF_ADAPTER_LINEAGE_FILENAME",
    "HF_ADAPTER_LINEAGE_SCHEMA",
    "HF_ADAPTER_PROMOTION_FILENAME",
    "HF_ADAPTER_PROMOTION_SCHEMA",
    "HF_ADAPTER_PROMOTION_CHAIN_FILENAME",
    "HF_ADAPTER_PROMOTION_CHAIN_SCHEMA",
    "HF_ADAPTER_CONTINUATION_POLICY_FILENAME",
    "HF_ADAPTER_CONTINUATION_POLICY_SCHEMA",
    "HF_ADAPTER_INPUT_IDENTITY_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_CONTROL_DIRNAME",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_FILENAME",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_LOCK_FILENAME",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_LOG_DIRNAME",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_LAUNCH_FILENAME",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_LAUNCH_LOCK_FILENAME",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_LAUNCH_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_LAUNCH_STATUS_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_RESUME_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_RUNTIME_RECONCILE_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_RUNTIME_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISION_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_FILENAME",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_LAUNCH_FILENAME",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_LAUNCH_LOCK_FILENAME",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_LAUNCH_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_LAUNCH_STATUS_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_LOCK_FILENAME",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_STATUS_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_SUPERVISOR_STOP_REQUEST_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_INTERRUPTION_CLAIM_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_GENERATION_PLAN_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_OUTPUT_RESOLUTION_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_QUARANTINE_SUFFIX",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_STATUS_SCHEMA",
    "HF_ADAPTER_CONTINUATION_EXECUTOR_STOP_REQUEST_SCHEMA",
    "HF_FINETUNE_MODES",
    "HF_FINETUNE_LORA_TARGET_MODULES",
    "HfCausalLmRuntimeIdentityError",
    "HF_GPT2_FT_DEFAULT_DEVICE_BACKENDS",
    "HF_GPT2_FT_RUN_CARD_FILENAME",
    "HF_GPT2_FT_TRAINER_TRACE_FILENAME",
    "HF_GPT2_FT_REQUIRED_PYTHON_PACKAGES",
    "HF_GPT2_FT_REQUIRED_RUST_SURFACES",
    "export_hf_merged_causal_lm",
    "hf_causal_lm_artifact_lines",
    "hf_causal_lm_artifact_report",
    "hf_causal_lm_runtime_identity_lines",
    "hf_causal_lm_runtime_identity_report",
    "hf_finetune_execution_identity_lines",
    "hf_finetune_execution_identity_report",
    "hf_finetune_input_identity_lines",
    "hf_finetune_input_identity_report",
    "HF_ADAPTER_CONFIG_CANONICALIZATION_SCHEMA",
    "canonicalize_hf_adapter_configs",
    "hf_adapter_fingerprint",
    "hf_adapter_input_identity_lines",
    "hf_adapter_input_identity_report",
    "hf_adapter_continuation_executor_lines",
    "hf_adapter_continuation_executor_generation_plan_lines",
    "hf_adapter_continuation_executor_generation_plan_report",
    "hf_adapter_continuation_executor_launch_lines",
    "hf_adapter_continuation_executor_launch_status_lines",
    "hf_adapter_continuation_executor_launch_status_report",
    "hf_adapter_continuation_executor_resume_lines",
    "hf_adapter_continuation_executor_resume_report",
    "hf_adapter_continuation_executor_runtime_lines",
    "hf_adapter_continuation_executor_runtime_reconcile_lines",
    "hf_adapter_continuation_executor_runtime_report",
    "hf_adapter_continuation_executor_supervision_lines",
    "hf_adapter_continuation_executor_supervision_report",
    "hf_adapter_continuation_executor_supervisor_lines",
    "hf_adapter_continuation_executor_supervisor_launch_lines",
    "hf_adapter_continuation_executor_supervisor_launch_status_lines",
    "hf_adapter_continuation_executor_supervisor_launch_status_report",
    "hf_adapter_continuation_executor_supervisor_status_lines",
    "hf_adapter_continuation_executor_supervisor_status_report",
    "hf_adapter_continuation_executor_supervisor_stop_request_lines",
    "hf_adapter_continuation_executor_output_quarantine_report",
    "hf_adapter_continuation_executor_output_resolution_lines",
    "hf_adapter_continuation_executor_stop_request_lines",
    "hf_adapter_continuation_executor_status_lines",
    "hf_adapter_continuation_executor_status_report",
    "hf_adapter_continuation_policy_lines",
    "hf_adapter_continuation_policy_report",
    "hf_adapter_lineage_lines",
    "hf_adapter_lineage_report",
    "hf_adapter_promotion_chain_lines",
    "hf_adapter_promotion_chain_report",
    "hf_adapter_promotion_lines",
    "hf_adapter_promotion_report",
    "load_hf_adapter_promotion_chain",
    "load_hf_adapter_continuation_policy",
    "load_hf_adapter_continuation_executor_stop_request",
    "load_hf_adapter_continuation_executor_launch",
    "load_hf_adapter_continuation_executor_supervisor",
    "load_hf_adapter_continuation_executor_supervisor_launch",
    "load_hf_adapter_continuation_executor_supervisor_stop_request",
    "request_hf_adapter_continuation_executor_stop",
    "reconcile_hf_adapter_continuation_executor_runtime",
    "quarantine_hf_adapter_continuation_executor_output",
    "resume_hf_adapter_continuation_executor",
    "request_hf_adapter_continuation_executor_supervisor_stop",
    "launch_hf_adapter_continuation_executor_supervisor",
    "supervise_hf_adapter_continuation_executor",
    "load_hf_adapter_continuation_executor",
    "hf_finetune_corpus_file_report",
    "hf_finetune_adapter_config",
    "hf_finetune_lora_target_report",
    "hf_finetune_parameter_report",
    "hf_merged_causal_lm_export_lines",
    "hf_causal_lm_artifact_probe_lines",
    "hf_causal_lm_artifact_probe_report",
    "hf_causal_lm_artifact_subprocess_probe_report",
    "load_hf_causal_lm_artifact",
    "load_hf_adapter_lineage",
    "load_hf_adapter_promotion",
    "summarize_hf_causal_lm_artifact",
    "prepare_hf_finetune_model",
    "run_hf_adapter_continuation_executor",
    "launch_hf_adapter_continuation_executor",
    "write_hf_adapter_lineage",
    "write_hf_adapter_continuation_policy",
    "write_hf_adapter_promotion_chain",
    "write_hf_adapter_promotion",
    "hf_finetune_corpus_scan_report",
    "hf_finetune_dataset_fit_report",
    "hf_finetune_disk_headroom_plan",
    "hf_finetune_checkpoint_resume_lines",
    "hf_finetune_checkpoint_resume_report",
    "hf_finetune_eval_report",
    "hf_finetune_generation_curve_lines",
    "hf_finetune_generation_curve_report",
    "hf_finetune_generation_report",
    "hf_finetune_inference_distortion_handoff_report",
    "hf_finetune_inference_distortion_handoff_lines",
    "hf_finetune_inference_distortion_request_kwargs",
    "hf_finetune_inference_distortion_runtime_adapter",
    "hf_finetune_inference_distortion_runtime_plan",
    "hf_finetune_milestone_lines",
    "hf_finetune_milestone_report",
    "hf_finetune_model_profile_catalog",
    "hf_finetune_model_profile_catalog_lines",
    "hf_finetune_model_profile_cli_args",
    "hf_finetune_model_profile_launch_bundle_lines",
    "hf_finetune_model_profile_launch_bundle_report",
    "hf_finetune_model_profile_launch_bundle_report_lines",
    "hf_finetune_model_profile_launch_plan",
    "hf_finetune_model_profile_launch_plan_lines",
    "hf_finetune_model_profile_launch_script",
    "hf_finetune_model_profile_lines",
    "hf_finetune_model_profile_preflight_lines",
    "hf_finetune_model_profile_preflight_report",
    "hf_finetune_model_profile_runtime_contract_from_artifact",
    "hf_finetune_model_profile_runtime_contract",
    "hf_finetune_model_profile_runtime_contract_lines",
    "hf_finetune_model_profiles",
    "load_hf_finetune_model_profile_launch_plan",
    "write_hf_finetune_model_profile_launch_bundle",
    "write_hf_finetune_model_profile_launch_plan",
    "write_hf_finetune_model_profile_launch_script",
    "hf_finetune_preflight_report",
    "hf_finetune_rust_dependency_report",
    "hf_finetune_monitor_lines",
    "hf_finetune_monitor_report",
    "hf_finetune_milestone_capture_lines",
    "hf_finetune_milestone_capture_report",
    "hf_finetune_milestone_handoff_execution_lines",
    "hf_finetune_milestone_handoff_execution_report",
    "hf_finetune_milestone_handoff_lines",
    "hf_finetune_milestone_handoff_report",
    "hf_finetune_milestone_runtime_artifact_paths",
    "hf_finetune_milestone_runtime_from_run_dir_archive",
    "hf_finetune_milestone_runtime_from_run_dir_report",
    "hf_finetune_milestone_runtime_lines",
    "hf_finetune_milestone_runtime_report",
    "hf_finetune_milestone_runtime_sources",
    "hf_finetune_run_artifact_manifest",
    "hf_finetune_run_artifact_manifest_lines",
    "hf_finetune_run_artifact_manifest_paths",
    "hf_finetune_run_ops_snapshot_lines",
    "hf_finetune_run_ops_snapshot_paths",
    "hf_finetune_run_ops_snapshot_report",
    "hf_finetune_status_history_lines",
    "hf_finetune_scale_up_command",
    "hf_finetune_scale_up_preflight_lines",
    "hf_finetune_scale_up_preflight_report",
    "hf_finetune_summary_lines",
    "hf_finetune_training_telemetry_frame",
    "hf_finetune_trainer_trace_callback",
    "hf_finetune_trainer_trace_event",
    "hf_finetune_trainer_trace_lineage_lines",
    "hf_finetune_trainer_trace_lineage_report",
    "hf_finetune_trainer_trace_segment_lines",
    "hf_finetune_trainer_trace_segment_plan",
    "hf_finetune_trainer_trace_segment_receipt",
    "hf_finetune_zspace_probe",
    "compare_hf_finetune_run_cards",
    "load_hf_finetune_model_configs",
    "load_hf_finetune_run_card",
    "load_hf_finetune_sweep_report",
    "load_hf_finetune_status_history",
    "load_hf_finetune_trainer_trace",
    "load_hf_finetune_trainer_trace_lineage",
    "summarize_hf_finetune_run_card",
    "summarize_hf_finetune_sweep_report",
    "summarize_hf_finetune_sweep_report_lines",
    "summarize_hf_finetune_status_history",
    "summarize_hf_finetune_trainer_trace",
    "summarize_hf_finetune_trainer_trace_lineage",
    "resolve_hf_finetune_model_profile",
    "write_hf_finetune_run_artifact_manifest",
    "write_hf_finetune_run_ops_snapshot",
    "write_hf_finetune_milestone_runtime_report",
    "write_hf_finetune_run_card",
    "write_hf_finetune_trainer_trace_event",
    "hf_gpt2_finetune_corpus_file_report",
    "hf_gpt2_finetune_corpus_scan_report",
    "hf_gpt2_finetune_dataset_fit_report",
    "hf_gpt2_finetune_eval_report",
    "hf_gpt2_finetune_generation_curve_lines",
    "hf_gpt2_finetune_generation_curve_report",
    "hf_gpt2_finetune_generation_report",
    "hf_gpt2_finetune_inference_distortion_handoff_report",
    "hf_gpt2_finetune_inference_distortion_handoff_lines",
    "hf_gpt2_finetune_inference_distortion_request_kwargs",
    "hf_gpt2_finetune_inference_distortion_runtime_adapter",
    "hf_gpt2_finetune_inference_distortion_runtime_plan",
    "hf_gpt2_finetune_milestone_lines",
    "hf_gpt2_finetune_milestone_report",
    "hf_gpt2_finetune_preflight_report",
    "hf_gpt2_finetune_rust_dependency_report",
    "hf_gpt2_finetune_monitor_lines",
    "hf_gpt2_finetune_monitor_report",
    "hf_gpt2_finetune_milestone_capture_lines",
    "hf_gpt2_finetune_milestone_capture_report",
    "hf_gpt2_finetune_milestone_handoff_execution_lines",
    "hf_gpt2_finetune_milestone_handoff_execution_report",
    "hf_gpt2_finetune_milestone_handoff_lines",
    "hf_gpt2_finetune_milestone_handoff_report",
    "hf_gpt2_finetune_milestone_runtime_artifact_paths",
    "hf_gpt2_finetune_milestone_runtime_from_run_dir_archive",
    "hf_gpt2_finetune_milestone_runtime_from_run_dir_report",
    "hf_gpt2_finetune_milestone_runtime_lines",
    "hf_gpt2_finetune_milestone_runtime_report",
    "hf_gpt2_finetune_milestone_runtime_sources",
    "hf_gpt2_finetune_run_artifact_manifest",
    "hf_gpt2_finetune_run_artifact_manifest_lines",
    "hf_gpt2_finetune_run_artifact_manifest_paths",
    "hf_gpt2_finetune_run_ops_snapshot_lines",
    "hf_gpt2_finetune_run_ops_snapshot_paths",
    "hf_gpt2_finetune_run_ops_snapshot_report",
    "hf_gpt2_finetune_status_history_lines",
    "hf_gpt2_finetune_scale_up_command",
    "hf_gpt2_finetune_scale_up_preflight_lines",
    "hf_gpt2_finetune_scale_up_preflight_report",
    "hf_gpt2_finetune_summary_lines",
    "hf_gpt2_finetune_training_telemetry_frame",
    "hf_gpt2_finetune_trainer_trace_callback",
    "hf_gpt2_finetune_trainer_trace_event",
    "hf_gpt2_finetune_trainer_trace_lineage_lines",
    "hf_gpt2_finetune_trainer_trace_lineage_report",
    "hf_gpt2_finetune_trainer_trace_segment_lines",
    "hf_gpt2_finetune_trainer_trace_segment_plan",
    "hf_gpt2_finetune_trainer_trace_segment_receipt",
    "hf_gpt2_finetune_zspace_probe",
    "compare_hf_gpt2_finetune_run_cards",
    "load_hf_gpt2_finetune_run_card",
    "load_hf_gpt2_finetune_sweep_report",
    "load_hf_gpt2_finetune_status_history",
    "load_hf_gpt2_finetune_trainer_trace",
    "load_hf_gpt2_finetune_trainer_trace_lineage",
    "summarize_hf_gpt2_finetune_run_card",
    "summarize_hf_gpt2_finetune_sweep_report",
    "summarize_hf_gpt2_finetune_sweep_report_lines",
    "summarize_hf_gpt2_finetune_status_history",
    "summarize_hf_gpt2_finetune_trainer_trace",
    "summarize_hf_gpt2_finetune_trainer_trace_lineage",
    "write_hf_gpt2_finetune_run_artifact_manifest",
    "write_hf_gpt2_finetune_run_ops_snapshot",
    "write_hf_gpt2_finetune_milestone_runtime_report",
    "write_hf_gpt2_finetune_run_card",
    "write_hf_gpt2_finetune_trainer_trace_event",
    "ZSpaceActivationProbeHook",
    "ZSpaceCheckpointPromptSpec",
    "ZSpaceCheckpointSweepJob",
    "ZSpaceRepressionLogitsProcessor",
    "build_zspace_activation_probe_hook",
    "build_zspace_repression_logits_processor",
    "build_zspace_softmax_logits_processor",
    "compare_zspace_inference_distortion_probes",
    "default_zspace_checkpoint_generation_prompts",
    "hf_generation_batch_size_compat",
    "zspace_inference_distortion_sweep_report_from_probes",
    "zspace_inference_distortion_geometry_probe",
    "zspace_inference_distortion_probe_cli_args",
    "zspace_inference_distortion_probe_report",
    "zspace_inference_distortion_runtime_cli_args",
    "zspace_inference_distortion_runtime_plan",
    "zspace_inference_distortion_runtime_preflight",
    "zspace_inference_distortion_sweep_cli_args",
    "zspace_generation_control_bridge_cli_args",
    "zspace_generation_control_profile_config",
    "zspace_generation_control_processor_kwargs",
    "zspace_generation_control_sweep_cli_args",
    "zspace_checkpoint_generation_control_compare_command",
    "zspace_checkpoint_generation_control_compare_output_paths",
    "zspace_checkpoint_generation_control_curve_command",
    "zspace_checkpoint_generation_control_jobs",
    "zspace_checkpoint_generation_control_report",
    "zspace_checkpoint_generation_control_sweep_command",
    "load_zspace_inference_distortion_probe",
    "load_zspace_inference_distortion_sweep",
    "load_zspace_generation_control_sweep",
    "summarize_zspace_inference_distortion_probe",
    "summarize_zspace_inference_distortion_probe_comparison_lines",
    "summarize_zspace_inference_distortion_probe_lines",
    "summarize_zspace_inference_distortion_sweep",
    "summarize_zspace_inference_distortion_sweep_lines",
    "summarize_zspace_generation_control_run",
    "summarize_zspace_generation_control_sweep",
    "compare_zspace_generation_control_sweeps",
    "summarize_zspace_generation_control_sweep_comparison_lines",
    "summarize_zspace_generation_control_sweep_lines",
    "zspace_inference_distortion_processor_kwargs",
    "from_dlpack",
    "to_dlpack",
    "ZSpaceBarycenter",
    "BarycenterIntermediate",
    "z_space_barycenter",
    "mean_tensors_scaled",
    "ZMetrics",
    "ZSpaceControlGradient",
    "ZSpaceDecoded",
    "ZSpaceInference",
    "ZSpacePosterior",
    "ZSpacePartialBundle",
    "ZSpaceTelemetryFrame",
    "ZSpaceInferenceRuntime",
    "ZSpaceInferencePipeline",
    "ZSPACE_CANONICAL_METRIC_GRADIENT_BASIS",
    "ZSPACE_POSTERIOR_LATENT_GRADIENT_BASIS",
    "zspace_posterior_decode",
    "zspace_posterior_project",
    "zspace_coherence_distribution_witness",
    "validate_zspace_coherence_distribution_witness",
    "zspace_coherence_project",
    "decode_zspace_embedding",
    "infer_from_partial",
    "infer_with_partials",
    "compile_inference",
    "blend_zspace_partials",
    "zspace_partial_fusion",
    "zspace_metric_gradient_projection",
    "zspace_telemetry_fusion",
    "training_telemetry_projection",
    "zspace_concept_diffusion",
    "zspace_free_energy",
    "ZSPACE_META_OBJECTIVE_FORMULA",
    "ZSPACE_META_OPTIMIZER_CONTRACT_VERSION",
    "ZSPACE_META_OPTIMIZER_KIND",
    "ZSPACE_META_OPTIMIZER_SEMANTIC_BACKEND",
    "ZSPACE_META_OPTIMIZER_SEMANTIC_OWNER",
    "ZSPACE_OPTIMIZER_FEEDBACK_CONTRACT_VERSION",
    "ZSPACE_OPTIMIZER_FEEDBACK_CONTROL_RULE",
    "ZSPACE_OPTIMIZER_FEEDBACK_KIND",
    "ZSPACE_OPTIMIZER_FEEDBACK_SEMANTIC_BACKEND",
    "ZSPACE_OPTIMIZER_FEEDBACK_SEMANTIC_OWNER",
    "ZSPACE_PARAMETER_CONTROL_CONTRACT_VERSION",
    "ZSPACE_PARAMETER_CONTROL_KIND",
    "ZSPACE_PARAMETER_CONTROL_MAX_LEARNING_RATE_SCALE",
    "ZSPACE_PARAMETER_CONTROL_MIN_LEARNING_RATE_SCALE",
    "ZSPACE_PARAMETER_CONTROL_SEMANTIC_BACKEND",
    "ZSPACE_PARAMETER_CONTROL_SEMANTIC_OWNER",
    "ZSPACE_PARAMETER_TRAJECTORY_CONTRACT_VERSION",
    "ZSPACE_PARAMETER_TRAJECTORY_DOSE_PRESERVING_COMPLEMENT_RULE",
    "ZSPACE_PARAMETER_TRAJECTORY_KIND",
    "ZSPACE_PARAMETER_TRAJECTORY_POLICIES",
    "ZSPACE_PARAMETER_TRAJECTORY_POLICY_CONTRACT_VERSION",
    "ZSPACE_PARAMETER_TRAJECTORY_POLICY_KIND",
    "ZSPACE_PARAMETER_TRAJECTORY_POLICY_SEMANTIC_BACKEND",
    "ZSPACE_PARAMETER_TRAJECTORY_POLICY_SEMANTIC_OWNER",
    "ZSPACE_PARAMETER_TRAJECTORY_SEMANTIC_BACKEND",
    "ZSPACE_PARAMETER_TRAJECTORY_SEMANTIC_OWNER",
    "ZSPACE_POLARITY_EVIDENCE_AGGREGATION_RULE",
    "ZSPACE_POLARITY_EVIDENCE_CONTRACT_VERSION",
    "ZSPACE_POLARITY_EVIDENCE_CONTRAST_RULE",
    "ZSPACE_POLARITY_EVIDENCE_KIND",
    "ZSPACE_POLARITY_EVIDENCE_MAX_SAFE_SEED",
    "ZSPACE_POLARITY_EVIDENCE_SEMANTIC_BACKEND",
    "ZSPACE_POLARITY_EVIDENCE_SEMANTIC_OWNER",
    "ZSPACE_GENERATION_EVIDENCE_CONTRACT_VERSION",
    "ZSPACE_GENERATION_EVIDENCE_KIND",
    "ZSPACE_GENERATION_EVIDENCE_LOOP_SCORE_RULE",
    "ZSPACE_GENERATION_EVIDENCE_MAX_SAFE_INTEGER",
    "ZSPACE_GENERATION_EVIDENCE_MAX_SAMPLES",
    "ZSPACE_GENERATION_EVIDENCE_MAX_TOKENS_PER_SAMPLE",
    "ZSPACE_GENERATION_EVIDENCE_MAX_TOTAL_TOKENS",
    "ZSPACE_GENERATION_EVIDENCE_METRIC_RULE",
    "ZSPACE_GENERATION_EVIDENCE_NGRAM_ORDERS",
    "ZSPACE_GENERATION_EVIDENCE_PERIODIC_SUFFIX_MAX_PERIOD",
    "ZSPACE_GENERATION_EVIDENCE_PERIODIC_SUFFIX_MIN_REPETITIONS",
    "ZSPACE_GENERATION_EVIDENCE_SEMANTIC_BACKEND",
    "ZSPACE_GENERATION_EVIDENCE_SEMANTIC_OWNER",
    "ZSPACE_RUNTIME_PROTOCOL_CATALOG_CONTRACT_VERSION",
    "ZSPACE_RUNTIME_PROTOCOL_CATALOG_ID_RULE",
    "ZSPACE_RUNTIME_PROTOCOL_CATALOG_KIND",
    "ZSPACE_RUNTIME_PROTOCOL_CATALOG_SEMANTIC_BACKEND",
    "ZSPACE_RUNTIME_PROTOCOL_CATALOG_SEMANTIC_OWNER",
    "ZSPACE_RUNTIME_PROTOCOL_CATALOG_STATUS",
    "ZSPACE_PERIODICITY_ANALYSIS_ID_RULE",
    "ZSPACE_PERIODICITY_CONTRACT_VERSION",
    "ZSPACE_PERIODICITY_EVIDENCE_BOUNDARY",
    "ZSPACE_PERIODICITY_KIND",
    "ZSPACE_PERIODICITY_MAX_COMPARISON_WORK",
    "ZSPACE_PERIODICITY_MAX_MINIMUM_REPETITIONS",
    "ZSPACE_PERIODICITY_MAX_PERIOD",
    "ZSPACE_PERIODICITY_MAX_SAFE_INTEGER",
    "ZSPACE_PERIODICITY_MAX_TOKENS",
    "ZSPACE_PERIODICITY_RULE",
    "ZSPACE_PERIODICITY_SEMANTIC_BACKEND",
    "ZSPACE_PERIODICITY_SEMANTIC_OWNER",
    "ZSPACE_PERIODIC_SUFFIX_MAX_PERIOD",
    "ZSPACE_PERIODIC_SUFFIX_MIN_REPETITIONS",
    "ZSPACE_STOCHASTIC_SCHRODINGER_EVIDENCE_BOUNDARY",
    "ZSPACE_STOCHASTIC_SCHRODINGER_FORWARD_CONTRACT_VERSION",
    "ZSPACE_STOCHASTIC_SCHRODINGER_FORWARD_KIND",
    "ZSPACE_STOCHASTIC_SCHRODINGER_ID_RULE",
    "ZSPACE_STOCHASTIC_SCHRODINGER_MAX_FEATURES",
    "ZSPACE_STOCHASTIC_SCHRODINGER_MAX_ROWS",
    "ZSPACE_STOCHASTIC_SCHRODINGER_MAX_VALUES",
    "ZSPACE_STOCHASTIC_SCHRODINGER_PROTOCOL_OWNER",
    "ZSPACE_STOCHASTIC_SCHRODINGER_SEMANTIC_BACKEND",
    "ZSPACE_STOCHASTIC_SCHRODINGER_SEMANTIC_OWNER",
    "ZSPACE_STOCHASTIC_SCHRODINGER_VJP_CONTRACT_VERSION",
    "ZSPACE_STOCHASTIC_SCHRODINGER_VJP_KIND",
    "ZSPACE_STOCHASTIC_SCHRODINGER_VJP_SEMANTICS",
    "ZSPACE_REPETITION_UNLIKELIHOOD_CANDIDATE_RULE",
    "ZSPACE_REPETITION_UNLIKELIHOOD_CONTRACT_VERSION",
    "ZSPACE_REPETITION_UNLIKELIHOOD_DIFFERENTIATION_OWNER",
    "ZSPACE_REPETITION_UNLIKELIHOOD_KIND",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MATERIALIZED_PLAN_BYTE_RULE",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MAX_CANDIDATES_PER_POSITION",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MAX_CONTEXT_WINDOW",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MAX_MATERIALIZED_PLAN_BYTES",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MAX_NGRAM_ORDER",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MAX_PROPOSAL_TOP_K",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MAX_SAFE_INTEGER",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MAX_SEQUENCES",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MAX_STRENGTH",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MAX_TOKENS_PER_SEQUENCE",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MAX_TOTAL_TOKENS",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MAX_WORK_UNITS",
    "ZSPACE_REPETITION_UNLIKELIHOOD_MIN_NGRAM_ORDER",
    "ZSPACE_REPETITION_UNLIKELIHOOD_OBJECTIVE_RULE",
    "ZSPACE_REPETITION_UNLIKELIHOOD_PERIODIC_SUFFIX_MAX_PERIOD",
    "ZSPACE_REPETITION_UNLIKELIHOOD_PERIODIC_SUFFIX_MIN_REPETITIONS",
    "ZSPACE_REPETITION_UNLIKELIHOOD_PROBABILITY_EPSILON",
    "ZSPACE_REPETITION_UNLIKELIHOOD_PROPOSAL_OWNER",
    "ZSPACE_REPETITION_UNLIKELIHOOD_PROPOSAL_RULE",
    "ZSPACE_REPETITION_UNLIKELIHOOD_SEMANTIC_BACKEND",
    "ZSPACE_REPETITION_UNLIKELIHOOD_SEMANTIC_OWNER",
    "ZSPACE_REPETITION_UNLIKELIHOOD_WORK_UNIT_RULE",
    "HF_REPETITION_UNLIKELIHOOD_BATCH_PLAN_KEY",
    "HF_REPETITION_UNLIKELIHOOD_RECEIPT_SCHEMA",
    "HfRepetitionUnlikelihoodBatchPlan",
    "HfRepetitionUnlikelihoodCollator",
    "hf_repetition_unlikelihood_recipe_contract",
    "hf_repetition_unlikelihood_trainer_class",
    "validate_zspace_parameter_trajectory",
    "validate_zspace_parameter_trajectory_policy",
    "validate_zspace_polarity_evidence",
    "validate_zspace_generation_evidence",
    "validate_zspace_runtime_protocol_catalog",
    "zspace_runtime_protocol_catalog",
    "validate_zspace_periodicity",
    "ZSPACE_SEMANTIC_REVIEW_CANDIDATE_LABELS",
    "ZSPACE_SEMANTIC_REVIEW_DRAFT_CONTRACT_VERSION",
    "ZSPACE_SEMANTIC_REVIEW_DRAFT_KIND",
    "ZSPACE_SEMANTIC_REVIEW_DRAFT_SCHEMA",
    "ZSPACE_SEMANTIC_REVIEW_EVIDENCE_BOUNDARY",
    "ZSPACE_SEMANTIC_REVIEW_MAP_COMMITMENT_VERSION",
    "ZSPACE_SEMANTIC_REVIEW_MAP_ID_RULE",
    "ZSPACE_SEMANTIC_REVIEW_MAP_SCHEMA",
    "ZSPACE_SEMANTIC_REVIEW_MAP_STATUS",
    "ZSPACE_SEMANTIC_REVIEW_MAX_ARM_NAME_BYTES",
    "ZSPACE_SEMANTIC_REVIEW_MAX_CONTINUATION_BYTES",
    "ZSPACE_SEMANTIC_REVIEW_MAX_GROUPS",
    "ZSPACE_SEMANTIC_REVIEW_MAX_INSTRUCTIONS_BYTES",
    "ZSPACE_SEMANTIC_REVIEW_MAX_MAP_ENTRIES",
    "ZSPACE_SEMANTIC_REVIEW_MAX_PACKET_TEXT_BYTES",
    "ZSPACE_SEMANTIC_REVIEW_MAX_PROMPT_BYTES",
    "ZSPACE_SEMANTIC_REVIEW_MAX_SAFE_INTEGER",
    "ZSPACE_SEMANTIC_REVIEW_PACKET_CONTRACT_VERSION",
    "ZSPACE_SEMANTIC_REVIEW_PACKET_ID_RULE",
    "ZSPACE_SEMANTIC_REVIEW_PACKET_KIND",
    "ZSPACE_SEMANTIC_REVIEW_PACKET_SCHEMA",
    "ZSPACE_SEMANTIC_REVIEW_PACKET_STATUS",
    "ZSPACE_SEMANTIC_REVIEW_PACKET_TEXT_BYTE_RULE",
    "ZSPACE_SEMANTIC_REVIEW_PREFERENCE_VALUES",
    "ZSPACE_SEMANTIC_REVIEW_RESPONSE_CONTRACT_VERSION",
    "ZSPACE_SEMANTIC_REVIEW_SCORE_DIMENSIONS",
    "ZSPACE_SEMANTIC_REVIEW_SCORE_MAXIMUM",
    "ZSPACE_SEMANTIC_REVIEW_SCORE_MINIMUM",
    "ZSPACE_SEMANTIC_REVIEW_SEMANTIC_BACKEND",
    "ZSPACE_SEMANTIC_REVIEW_SEMANTIC_OWNER",
    "ZSPACE_SEMANTIC_REVIEW_UNBLIND_CONTRACT_VERSION",
    "ZSPACE_SEMANTIC_REVIEW_UNBLIND_KIND",
    "new_zspace_semantic_review_draft",
    "seal_zspace_semantic_review_packet",
    "summarize_zspace_semantic_review_draft",
    "unblind_zspace_semantic_review",
    "validate_zspace_semantic_review_draft_receipt",
    "validate_zspace_semantic_review_draft_receipt_trusted_legacy_replay",
    "validate_zspace_semantic_review_packet",
    "validate_zspace_semantic_review_packet_trusted_legacy_replay",
    "validate_zspace_semantic_review_packet_receipt",
    "validate_zspace_semantic_review_packet_receipt_trusted_legacy_replay",
    "validate_zspace_semantic_review_unblind",
    "validate_zspace_semantic_review_unblind_trusted_legacy_replay",
    "zspace_semantic_review_map_id",
    "zspace_semantic_review_map_id_trusted_legacy_replay",
    "validate_zspace_repetition_unlikelihood_plan",
    "validate_zspace_repetition_unlikelihood_plan_trusted_legacy_replay",
    "zspace_meta_optimizer_init",
    "zspace_meta_optimizer_restore",
    "zspace_meta_optimizer_step",
    "zspace_optimizer_feedback_control",
    "zspace_optimizer_feedback_init",
    "zspace_optimizer_feedback_observe",
    "zspace_optimizer_feedback_restore",
    "zspace_parameter_control",
    "zspace_parameter_trajectory",
    "zspace_parameter_trajectory_policy",
    "zspace_polarity_evidence",
    "zspace_generation_control",
    "zspace_generation_evidence",
    "zspace_periodicity",
    "validate_zspace_stochastic_schrodinger_forward",
    "validate_zspace_stochastic_schrodinger_vjp",
    "zspace_stochastic_schrodinger_forward",
    "zspace_stochastic_schrodinger_vjp",
    "zspace_stochastic_schrodinger_complex_step",
    "validate_zspace_stochastic_schrodinger_complex",
    "zspace_repetition_unlikelihood_plan",
    "zspace_imaginary_time_schrodinger",
    "zspace_temperature_control",
    "inference_to_mapping",
    "inference_to_zmetrics",
    "prepare_trainer_step_payload",
    "ensure_zmetrics",
    "ApiLLMTrace",
    "ApiLLMZSpaceRuntime",
    "api_llm_geometry_context_partials",
    "api_llm_zspace_inference_distortion_adapter",
    "api_llm_partial_from_response",
    "api_llm_text_from_response",
    "api_llm_trace_from_response",
    "api_llm_usage_from_response",
    "api_llm_wasm_context_partials",
    "api_llm_topos_route_policy_selection",
    "api_llm_topos_sweep_route_rewards",
    "compare_api_llm_matrix_reports",
    "compare_api_llm_trace_runs",
    "compare_api_llm_topos_sweep_reports",
    "format_api_llm_context_prompt",
    "load_api_llm_trace_events",
    "make_anthropic_messages_invoke",
    "make_openai_chat_invoke",
    "make_openai_responses_invoke",
    "run_api_llm_prompt_suite",
    "run_api_llm_prompt_suite_matrix",
    "run_api_llm_topos_sweep",
    "summarize_api_llm_trace_events",
    "api_llm_topos_sweep_report",
    "train_stagent_topos_route_policy",
    "topos_api_llm_request_kwargs",
    "topos_api_llm_request_plan",
    "topos_runtime_adapter",
    "topos_runtime_request",
    "write_api_llm_trace_jsonl",
    "audit_wasm_report",
    "audit_wasm_report_context",
    "build_wasm_report_context",
    "build_wasm_report_context_artifact",
    "compare_wasm_reports",
    "collect_wasm_report_paths",
    "load_wasm_report_context_artifact",
    "load_wasm_report",
    "summarize_wasm_report",
    "wasm_report_to_zspace_partial",
    "write_wasm_report_context_artifact",
    "fractal_field_partial",
    "fractal_field_probe",
    "fractal_field_probe_to_zspace_partial",
    "log_z_series_partial",
    "log_z_series_probe",
    "log_z_series_probe_to_zspace_partial",
    "build_geometry_probe_context",
    "build_geometry_probe_context_artifact",
    "geometry_probe_consensus_partial",
    "geometry_probe_summary",
    "geometry_probe_to_zspace_partial",
    "geometry_probes_to_zspace_partials",
    "load_geometry_probe_context_artifact",
    "write_geometry_probe_context_artifact",
    "scale_stack_probe",
    "scale_stack_probe_to_zspace_partial",
    "scalar_scale_stack_partial",
    "scalar_scale_stack_probe",
    "semantic_scale_stack_partial",
    "semantic_scale_stack_probe",
    "ZSpaceTrainer",
    "ZSpaceCoherenceSequencer",
    "LinguisticContour",
    "step_many",
    "stream_zspace_training",
    "ImageTensor",
    "TransformPipeline",
    "VisionSample",
    "TensorVisionDataset",
    "VisionBatch",
    "VisionDataLoader",
    "VisionModel",
    "vision_dataset_catalog",
    "vision_dataset_descriptor",
    "vision_model_catalog",
    "vision_model_descriptor",
    "vision_transform_audit_catalog",
    "vision_standard_classification_pipeline",
    "vision_create_classification_model",
    "vision_online_step",
    "stream_vision_training",
    "ZConv",
    "ZConv6DA",
    "ZPooling",
    "Pool2d",
    "compat",
    "capture",
    "share",
    "from_dlpack",
    "to_dlpack",
    "nn",
    "frac",
    "geometry",
    "dataset",
    "linalg",
    "psi",
    "text",
    "theory",
    "scale_stack",
    "rl",
    "robotics",
    "spiral_rl",
    "rec",
    "safety",
    "kv",
    "wgpu",
    "telemetry",
    "ecosystem",
    "selfsup",
    "planner",
    "model_zoo",
    "sot",
    "zspace",
    "vision",
    "canvas",
    "qr",
    "julia",
    "compat",
    "set_global_seed",
    "golden_ratio",
    "golden_angle",
    "fibonacci_pacing",
    "pack_nacci_chunks",
    "pack_tribonacci_chunks",
    "pack_tetranacci_chunks",
    "generate_plan_batch_ex",
    "mps_probe",
    "probe_gpu_path",
    "SoT3DPlan",
    "SoT3DStep",
    "MacroSummary",
    "info_nce",
    "masked_mse",
    "gl_coeffs_adaptive",
    "fracdiff_gl_1d",
    "fft_radix2",
    "fft_radix4",
    "fft_complex32",
    "fft_real",
    "drl_default_thresholds",
    "drl_analyse_word",
    "drl_analyze_word",
    "drl_existence_load",
    "drl_safe_radii",
    "drl_frame_hazard",
    "drl_trainer_penalty",
    "drl_aggregate_penalty",
    "drl_frame_summary",
    "kv_redis_available",
    "kv_choice_schema_fields",
    "kv_rank_choice_key",
    "kv_choice_key_from_rank_plan",
    "kv_choice_from_rank_plan",
    "kv_json_set_options",
    "kv_redis_set_json",
    "kv_redis_get_json",
    "kv_redis_set_choice",
    "kv_redis_get_choice",
    "kv_redis_push_choice",
    "kv_redis_lrange_choice",
    "WgpuMatmul",
    "WgpuTensorDevice",
    "WgpuTensor",
    "WgpuTensorSnapshot",
    "WgpuRank",
    "wgpu_kernel_reports_available",
    "wgpu_kernel_catalog",
    "wgpu_kernel_descriptor",
    "wgpu_rank_kernel_report",
    "wgpu_kernel_report_from_rank_plan",
    "wgpu_softmax_kernel_report",
    "zspace_eval",
    "zspace_snapshot",
    "softlogic_feedback",
    "clear_zspace_feedback",
    "describe_zspace",
    "softlogic_signal",
    "QueryPlan",
    "RecEpochReport",
    "ContextualLagrangianGate",
    "ContextualPulseFrame",
    "token_scale_stack",
    "token_coherence_levels",
    "Recommender",
    "Agent",
    "AgentConfig",
    "EpsilonGreedy",
    "Replay",
    "stAgent",
    "DqnAgent",
    "CurvatureScheduler",
    "SpectralLearningRatePolicy",
    "CurvatureDecision",
    "ZSpaceSpinBand",
    "ZSpaceRadiusBand",
    "ZSpaceRegionKey",
    "ZSpaceRegionDescriptor",
    "SoftlogicEllipticSample",
    "SoftlogicZFeedback",
    "PpoAgent",
    "SacAgent",
    "TemporalResonanceBuffer",
    "ChronoSnapshot",
    "ZSpaceStreamFrame",
    "StreamedVolume",
    "ZSpaceStreamFrameAggregator",
    "SpiralTorchVision",
    "SliceProfile",
    "CanvasTransformer",
    "CanvasSnapshot",
    "FractalCanvas",
    "InfiniteZSpacePatch",
    "QuantumOverlayConfig",
    "ZResonance",
    "ZOverlayCircuit",
    "QuantumMeasurement",
    "QuantumRealityStudio",
    "FractalQuantumSession",
    "resonance_from_fractal_patch",
    "quantum_measurement_from_fractal",
    "quantum_measurement_from_fractal_sequence",
    "ZTigerOptim",
    "tempo_latency_score",
    "apply_vision_update",
    "DashboardMetric",
    "DashboardEvent",
    "DashboardFrame",
    "DashboardRing",
]
