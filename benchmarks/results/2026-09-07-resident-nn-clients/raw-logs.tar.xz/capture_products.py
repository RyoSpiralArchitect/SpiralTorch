"""Match installed native images to wheels built from the frozen source."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = Path(sys.argv[1]).resolve()
SOURCE = sys.argv[2]
assert not subprocess.check_output(["git", "-C", str(REPO), "diff", SOURCE, "--",
    "crates", "bindings", "Cargo.toml", "Cargo.lock"])
TREE = subprocess.check_output(["git", "-C", str(REPO), "rev-parse", SOURCE + "^{tree}"], text=True).strip()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def installed(venv, wheel_dir, gpu):
    python = ROOT / venv / "bin/python"
    payload = subprocess.check_output([str(python), "-I", "-c",
        "import json,sys,spiraltorch as st,spiraltorch.spiraltorch as n;"
        "print(json.dumps(dict(extension=n.__file__,prefix=sys.prefix,build_info=st.build_info(),"
        "wgpu=st.wgpu_kernel_reports_available(),plan=st.nn.InferencePlan.__module__)))"], text=True)
    observed = json.loads(payload)
    assert observed["wgpu"] is gpu
    assert observed["plan"] == "spiraltorch.nn"
    extension = Path(observed["extension"]).resolve()
    assert extension.is_relative_to(Path(observed["prefix"]).resolve())
    wheels = list((ROOT / wheel_dir).glob("*.whl"))
    assert len(wheels) == 1
    wheel = wheels[0]
    with zipfile.ZipFile(wheel) as archive:
        entries = [name for name in archive.namelist() if name.endswith("/" + extension.name)]
        assert len(entries) == 1
        assert archive.read(entries[0]) == extension.read_bytes()
    return dict(**observed, wheel=str(wheel), wheel_sha256=digest(wheel),
        extension_sha256=digest(extension))

fixture = json.loads((ROOT / "nn-fixture.json").read_text())
assert fixture["status"] == "passed" and len(fixture["cases"]) == 3
browsers = {}
for name, cpu_only in [("browser-clients-final.json", False), ("browser-clients-cpu-final.json", True)]:
    report = json.loads((ROOT / name).read_text())
    assert report["status"] == "passed" and report["cpu_only"] is cpu_only
    assert not report["page_errors"]
    assert len(report["cases"]) == 3
    if not cpu_only:
        assert report["intermediate_guard_cases"] == 4
    for case, expected in zip(report["cases"], fixture["cases"]):
        assert case["shape"] == expected["shape"]
        assert case["plan_sha256"] == expected["plan_sha256"]
        assert hashlib.sha256(expected["plan_json"].encode()).hexdigest() == expected["plan_sha256"]
    assert report["asset_sha256"]["/fixture.json"] == digest(ROOT / "nn-fixture.json")
    browsers[name] = report

short = SOURCE[:8]
products = dict(
    gpu=installed("venv", "wheels-" + short, True),
    cpu=installed("venv-cpu", "wheels-cpu-" + short, False),
)
report = dict(status="passed", source_commit=SOURCE, source_tree=TREE,
    attribution="Frozen source/build logs; installed extension bytes match wheels. Not embedded Git attestation or reproducible-build proof.",
    products=products, browser_reports=browsers, fixture_sha256=digest(ROOT / "nn-fixture.json"),
    boundary="Public-client correctness, not timing. Browser adapter is anonymous. No CUDA or resident training claim.")
with (ROOT / "python-products.json").open("x") as stream:
    json.dump(report, stream, sort_keys=True, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps(dict(status="passed", source_commit=SOURCE,
    gpu_extension_sha256=products["gpu"]["extension_sha256"],
    cpu_extension_sha256=products["cpu"]["extension_sha256"])))
