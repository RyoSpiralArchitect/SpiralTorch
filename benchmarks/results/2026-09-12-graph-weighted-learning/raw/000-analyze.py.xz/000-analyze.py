"""Hash-bound weighted learner correctness and ordinary-route comparisons."""
import hashlib
import json
import lzma
import math
from pathlib import Path
import re

LOG = Path(__file__).parent
ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
OUT = ROOT / 'benchmarks/results/2026-09-12-graph-weighted-learning'


def read(path):
    return json.loads(path.read_text())


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def gm(values):
    return math.exp(sum(map(math.log, values)) / len(values))


verified = read(LOG / 'verified/receipt.json')
assert verified['status'] == 'passed'
for name, sha in verified['products'].items():
    assert digest(LOG / 'verified' / name) == sha
report = dict(
    schema='spiraltorch.graph_weighted_learning_evidence.v1', status='passed',
    source=verified['source'], adopted='verified', correctness={}, rounds=[],
    scope='Opt-in custom-objective resident learning: same-forward exact VJPs, ordered weighted composition, explicit gain policy and atomic SGD. Rust owns semantics; Python/WASM expose handles.',
    performance_scope='Regression comparison of the existing ordinary MSE/SGD route, NOT throughput of the new learner. Fusion disabled in both timing lanes.',
    boundaries=[
        'No ModuleTrainer, generic autograd or pure::Tensor migration. No Adam, momentum, cross-forward accumulation or mixed precision.',
        'Learning fixture uses three seed/shape pairs, not an independent crossed seed-by-shape sweep. Bounded numerical learning, not model quality.',
        'Submitted updates are attempts; only their individual captured receipts establish acceptance.',
        'Owned GPU work serial; host contention UNKNOWN. Prior parallel GPU VJP one-off remains UNKNOWN.',
        'Native Apple M4 Metal/MPS; Chrome WebGPU does not attest an exact physical browser adapter.',
        'Eager Torch only, not torch.compile or the fastest possible Torch. No CUDA/Furnace, push, merge or wheel release.'
    ],
    exploratory_failures=[
        dict(artifact='python-exploratory.log', status='failed', scope='unfrozen draft test',
             reason='Two assertions expected ValueError instead of RuntimeError for a consumed snapshot, and omitted were in the existing rejection message. Assertions corrected, not core semantics.'),
        dict(artifact='types-initial.log', status='failed', scope='unfrozen draft type checker',
             reason='The previous type checker required private constructors for every NN class. Only the new owning GraphGradientBatch builder is explicitly constructible; other constructor checks retained.')
    ])
for origin in ['native', 'browser']:
    item = read(LOG / 'verified' / (origin + '-correctness.json'))
    assert item['status'] == 'passed'
    learning = item['learning']
    assert len(learning['cases']) == 12 and len(learning['guards']) == 5
    assert all(g['passed'] for g in learning['guards'])
    assert all(c['steps'] == c['accepted_updates'] == 64 and c['resume'] == 'bit_identical' for c in learning['cases'])
    report['correctness'][origin] = dict(
        adapter=item['adapter'], learner_cases=12, learner_guards=5, learning_updates=768,
        retained_checkpoints=sum(len(c['captures']) for c in learning['cases']),
        max_abs_error_vs_rust_module=max(c['max_abs_error'] for c in learning['cases']),
        cases=[{k: c[k] for k in ['seed', 'shape', 'policy', 'fused', 'initial_loss', 'final_loss', 'resume']} for c in learning['cases']],
        prior_autograd_cases=len(item['autograd']['cases']),
        prior_fusion_cases=len(item['pointwise_fusion']['cases']))
torch = read(LOG / 'verified/torch-correctness.json')
assert torch['status'] == 'passed'
report['correctness']['torch'] = dict(version=torch['torch'], cases=len(torch['cases']),
    comparisons=sum(c['comparisons'] for c in torch['cases']), max_abs=max(c['max_abs_error'] for c in torch['cases']))
weighted = [c for c in torch['cases'] if c['weighted_learning']]
assert len(weighted) == 48 and {c['device'] for c in weighted} == {'cpu', 'mps'}
report['correctness']['torch']['weighted_learning'] = dict(cases=len(weighted),
    updates=sum(c['updates'] for c in weighted), comparisons=sum(c['comparisons'] for c in weighted),
    max_abs=max(c['max_abs_error'] for c in weighted))
report['correctness']['python_existing'] = read(LOG / 'verified/python-tests.json')
for name in ['python-autograd', 'python-learner']:
    text = (LOG / 'verified' / (name + '.log')).read_text()
    assert 'Ran 3 tests' in text and '\nOK\n' in text
    report['correctness'][name] = dict(tests=3, status='passed')
for name in ['wasm-learner', 'wasm-autograd', 'wasm-fusion', 'wasm-forward']:
    item = read(LOG / 'verified' / (name + '.json'))
    assert item['status'] == 'passed'
    report['correctness'][name] = {k: item[k] for k in ('status', 'assertions', 'adapter') if k in item}
    if 'cases' in item:
        report['correctness'][name]['case_count'] = len(item['cases'])
    if name == 'wasm-learner':
        report['correctness'][name]['cases'] = item['cases']
report['test_counts'] = {name: sum(map(int, re.findall(r'test result: ok\. (\d+) passed',
    (LOG / 'verified' / (name + '.log')).read_text()))) for name in ['contracts', 'nn-serial', 'backend-serial', 'integration']}
raw_intervals = retained_intervals = updates = 0
for name in ['timing', 'timing-b']:
    receipt = read(LOG / name / 'receipt.json')
    assert receipt['status'] == 'passed' and receipt['source'] == verified['source']
    value = read(LOG / name / 'validation.json')
    assert value['status'] == 'passed' and len(value['cases']) == 9
    row = dict(name=name, baseline=receipt['baseline']['source'], candidate=receipt['candidate']['source'],
        max_abs=max(e for c in value['cases'] for e in c['max_abs_errors'].values()), native={}, browser={})
    for origin in ['native', 'browser']:
        for cadence in ['immediate', 'deferred']:
            ratios = [c[origin][cadence]['baseline_over_candidate'] for c in value['cases']]
            worst = min(range(len(ratios)), key=lambda i: ratios[i])
            stats = dict(baseline_over_candidate_geomean=gm(ratios), min_ratio=min(ratios), max_ratio=max(ratios),
                         worst_config=value['cases'][worst]['config'])
            if origin == 'native':
                stats['torch_over_candidate_geomean'] = gm([c[origin][cadence]['torch_over_candidate'] for c in value['cases']])
            row[origin][cadence] = stats
        original = read(LOG / name / (origin + '.json'))
        for case in original['cases']:
            for s in case['samples']:
                lanes = len(s['times_ms'])
                raw_intervals += lanes
                retained_intervals += 0 if s['warmup'] else lanes
                updates += lanes * case['config']['steps']
    report['rounds'].append(row)
report['measurement_counts'] = dict(raw_intervals=raw_intervals, retained_intervals=retained_intervals, nonzero_sgd_updates=updates)

OUT.mkdir(exist_ok=True)
(OUT / 'raw').mkdir(exist_ok=True)
files = sorted(p for p in LOG.rglob('*') if p.is_file() and p.suffix in ('.py', '.json', '.jsonl', '.log', '.stderr'))
manifest = dict(schema='spiraltorch.compressed_evidence_manifest.v1', artifacts=[])
for i, source in enumerate(files):
    destination = OUT / 'raw' / f'{i:03d}-{source.name}.xz'
    with source.open('rb') as src, lzma.open(destination, 'wb', filters=[dict(id=lzma.FILTER_LZMA2, preset=1, dict_size=64*1024*1024)]) as dst:
        for block in iter(lambda: src.read(1024*1024), b''):
            dst.write(block)
    raw_sha = digest(source)
    h, size = hashlib.sha256(), 0
    with lzma.open(destination, 'rb') as restored:
        for block in iter(lambda: restored.read(1024*1024), b''):
            h.update(block)
            size += len(block)
    assert h.hexdigest() == raw_sha and size == source.stat().st_size
    assert destination.stat().st_size < 95*1024*1024
    manifest['artifacts'].append(dict(source=str(source.relative_to(LOG)), path=str(destination.relative_to(OUT)),
        raw_sha256=raw_sha, raw_bytes=size, compressed_sha256=digest(destination), compressed_bytes=destination.stat().st_size))
report['artifacts'] = len(manifest['artifacts'])
report['compressed_bytes'] = sum(a['compressed_bytes'] for a in manifest['artifacts'])
report['raw_bytes'] = sum(a['raw_bytes'] for a in manifest['artifacts'])
for name, value in [('summary', report), ('manifest', manifest)]:
    (OUT / (name + '.json')).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
print(json.dumps({k: report[k] for k in ['status', 'source', 'artifacts', 'compressed_bytes', 'raw_bytes']}))
