"""Retain source-bound verification, matched timings, and exploratory negatives."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import sys

LOG = Path(__file__).parent
ROOT = Path("/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1")
RUN = LOG/sys.argv[1]
OUT = ROOT/"benchmarks/results/2026-09-12-module-resident-forward"
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
receipt = read(RUN/"receipt.json")
assert receipt["status"] == "passed" and all(s["exit_code"] == 0 for s in receipt["steps"])
assert receipt["source"]["commit"] == subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(["git","status","--porcelain"],cwd=ROOT,text=True).strip()
assert sha(LOG/"run.py") == receipt["harness_sha256"]
for name,digest in receipt["products"].items(): assert sha(RUN/name) == digest, name
validation = read(RUN/"module-forward-validation.json")
assert validation["status"] == "passed"
report = dict(schema="spiraltorch.module_resident_forward_evidence.v1",status="passed",
    source=receipt["source"],adopted=RUN.name,steps=len(receipt["steps"]),products=receipt["products"],
    capabilities=[
        "Original Rust Module forwarding with GPU-resident N-D inputs/outputs and a bounded exact-match graph cache.",
        "Same Python model.forward(x)/model(x) chooses host Tensor or WgpuTensor by explicit input type.",
        "Browser Sequential owns the same Rust Module; checked training parameter handoff rebuilds its graph.",
        "Mutable/foreign parameter changes, device identity, layouts, shape/program changes, output ownership, inherited invalid values and active tensor plan bindings are checked."
    ],boundaries=[
        "GPU input/output bridge copies and O(parameter values) host comparison remain; not zero-copy.",
        "No implicit host transfer, unsupported-layer fallback, generic autograd or ModuleTrainer GPU migration.",
        "Cache counters are host compilation/selection/submission counts, not GPU completion receipts.",
        "Native WGPU Metal/MPS identify Apple M4; browser physical adapter and host contention UNKNOWN.",
        "Bounded eager Torch controls, not fastest-PyTorch, torch.compile, universal speedup or training-quality evidence.",
        "No CUDA/Furnace, release, push or merge in this slice."
    ],negatives=[
        dict(path="browser-preflight.json",kind="exploratory_unscaled_feedback",
            explanation="Unscaled initialized dense models were fed their outputs twenty times. The second width produced non-finite output and failed validation; this is not throughput or stability success. Retained unchanged. Adopted correctness fixture uses explicit bounded diagonal weights and is independently replayed in Torch."),
        dict(path="verified-a/receipt.json",kind="interrupted_for_guard_fix",
            explanation="Stopped the owned process group after source review found the guard checked only the upper NN policy. Now it reads the active st-tensor binding and tests direct binding plus nested uncommitted policy. Interrupted receipt is not a completed test result."),
        dict(path="verified-b/receipt.json",kind="reference_shape_error",
            explanation="The full benchmark completed but browser replay used an old square-only Torch helper that reshaped rectangular output back to input width. Fixed the reference, added CPU/MPS shape tests and reran the complete pipeline. Production kernel math and tolerances were unchanged; all earlier timings retained.")
    ],verification={})
for name in ["contracts","tensor-cpu","tensor-wgpu","nn-cpu-handoff","nn-serial","backend-serial","integration"]:
    matches=re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;",(RUN/(name+".log")).read_text())
    assert matches and all(int(m[1])==0 for m in matches),name
    report["verification"][name]=dict(passed=sum(int(m[0]) for m in matches),ignored=sum(int(m[2]) for m in matches))
report["verification"]["ignored_boundary"]="Existing fractional GL live-adapter test remains ignored."
report["verification"]["python_existing"]=read(RUN/"python-tests.json")
for name in ["python-graph_autograd","python-graph_learner","python-module_update","python-pointwise",
             "python-module-forward","python-cpu-handoff","python-cpu-module-forward"]:
    log=(RUN/(name+".log")).read_text()
    match=re.search(r"Ran (\d+) tests",log)
    assert match and "\nOK\n" in log and "skipped=" not in log,name
    report["verification"][name]=dict(tests=int(match[1]),status="passed")
report["verification"]["cpu_build"]=read(RUN/"python-cpu-probe.json")
assert report["verification"]["cpu_build"]["status"]=="passed"
for name in ["browser-handoff","browser-module-forward","browser-to-python","browser-to-cpu-python",
             "wasm-pointwise","wasm-learner","wasm-autograd","wasm-fusion","wasm-forward","torch-correctness"]:
    item=read(RUN/(name+".json"))
    assert item["status"]=="passed",name
    report["verification"][name]={k:v for k,v in item.items() if k in ["status","schema","adapter","assertions","comparisons","max_abs_error"]}
    if isinstance(item.get("cases"),list):report["verification"][name]["cases"]=len(item["cases"])
    if name=="torch-correctness":
        report["verification"][name].update(comparisons=sum(c["comparisons"] for c in item["cases"]),
            max_abs_error=max(c["max_abs_error"] for c in item["cases"]))
report["browser_replay"]=validation["browser_replay"]
report["timing"]=validation["timing"]
OUT.mkdir()
assert sha(LOG/"preflight-unscaled.html")==read(LOG/"browser-preflight.json")["page_sha256"]
paths=sorted(set(LOG.rglob("*.log"))|set(LOG.rglob("*.json"))|{LOG/"run.py",LOG/"archive.py",LOG/"preflight-unscaled.html"})
paths.append(LOG/"run-before-reference-fix.py")
manifest=[]
for path in paths:
    relative=path.relative_to(LOG)
    destination=OUT/"raw"/(str(relative)+".xz")
    destination.parent.mkdir(parents=True,exist_ok=True)
    raw=path.read_bytes()
    compressed=lzma.compress(raw,preset=6)
    assert lzma.decompress(compressed)==raw
    destination.write_bytes(compressed)
    manifest.append(dict(path=str(destination.relative_to(OUT)),original=str(relative),bytes=len(raw),
        sha256=hashlib.sha256(raw).hexdigest(),compressed_bytes=len(compressed),compressed_sha256=sha(destination)))
report["archive"]=dict(files=len(manifest),raw_bytes=sum(p["bytes"] for p in manifest),compressed_bytes=sum(p["compressed_bytes"] for p in manifest))
(OUT/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
(OUT/"summary.json").write_text(json.dumps(report,indent=2,allow_nan=False)+"\n")
assert {str(p.relative_to(OUT)) for p in (OUT/"raw").rglob("*.xz")}=={p["path"] for p in manifest}
print(json.dumps(dict(output=str(OUT),source=report["source"],steps=report["steps"],archive=report["archive"]),indent=2))
