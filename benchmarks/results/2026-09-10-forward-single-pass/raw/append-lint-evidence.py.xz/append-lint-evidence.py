"""Append the broader lint result without altering prior raw evidence."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess

ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
L=Path(__file__).parent
DEST=ROOT/'benchmarks/results/2026-09-10-forward-single-pass'
digest=lambda data:hashlib.sha256(data).hexdigest()
summary=json.loads((DEST/'summary.json').read_bytes())
strict=(L/'nn-target-clippy.log').read_text()
advisory=(L/'nn-target-clippy-advisory.log').read_text()
blocks=re.split(r'^error: ',strict,flags=re.M)[1:]
findings=[]
for block in blocks:
    match=re.search(r'--> (crates/st-nn/src/[^:]+):(\d+):(\d+)',block)
    if match:
        findings.append(dict(message=block.splitlines()[0],file=match[1],line=int(match[2])))
assert len(findings)==22
paths={item['file'] for item in findings}
paths.add('crates/st-nn/examples/support/resident_graph_forward.rs')
unchanged={}
for path in sorted(paths):
    base=subprocess.check_output(['git','show',summary['base']+':'+path],cwd=ROOT)
    actual=(ROOT/path).read_bytes()
    assert base==actual,path
    unchanged[path]=dict(base_sha256=digest(base),current_sha256=digest(actual))
assert 'generated 22 warnings' in advisory and 'generated 1 warning' in advisory
assert 'chunks_exact' in advisory
result=dict(status='strict_st_nn_failed_on_unchanged_sources',strict_exit_code=101,advisory_exit_code=0,
    strict_findings=findings,unchanged_files=unchanged,
    scope='The strict st-nn command did not pass. Advisory compilation completed with the same library lints and one unchanged shared-fixture warning. This is separate from the successful strict backend library check.')
with (L/'nn-lint-followup.json').open('x') as output:
    json.dump(result,output,indent=2);output.write('\n')
manifest=json.loads((DEST/'manifest.json').read_bytes())
for name in ['nn-target-clippy.log','nn-target-clippy-advisory.log','nn-lint-followup.json','append-lint-evidence.py']:
    data=(L/name).read_bytes(); packed=lzma.compress(data)
    path='raw/'+name+'.xz'
    with (DEST/path).open('xb') as output: output.write(packed)
    manifest['entries'].append(dict(path=path,original_name=name,bytes=len(data),sha256=digest(data),compressed_sha256=digest(packed)))
summary['additional_nn_lint']=result
for name,doc in [('manifest.json',manifest),('summary.json',summary)]:
    (DEST/name).write_text(json.dumps(doc,indent=2)+'\n')
print(json.dumps(dict(unchanged_files=len(unchanged),strict_library_lints=len(findings),artifacts=len(manifest['entries']))))
