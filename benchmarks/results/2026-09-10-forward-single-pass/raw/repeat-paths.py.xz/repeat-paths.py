"""AB then BA repeats of frozen executables/modules; no compilation during timing."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
L=Path(__file__).parent
OUT=L/'repeats'
OUT.mkdir()
sys.path.insert(0,str(ROOT/'tools'))
from bench_graph_forward_paths import admit_native, close, digest, summarize
from validate_graph_forward_paths import admit_client
P='/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_TARGET_DIR=str(ROOT.parent/'spiraltorch-spiralk-golden-blackcat-contract-v1/target'),
         SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1',PYTORCH_ENABLE_MPS_FALLBACK='0',
         NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
names=subprocess.check_output(['git','ls-files','-mo','--exclude-standard'],cwd=ROOT,text=True).splitlines()
source={name:digest(ROOT/name) for name in names}
fixture=json.loads((L/'native.json').read_bytes())
admit_native(fixture)
products={str(path):digest(path) for path in [L/'native-bench',L/'python-release.dylib',
    L/'webgpu-baseline/spiraltorch_wasm_bg.wasm',L/'candidate/native-bench',L/'candidate/python-release.dylib',
    L/'candidate/webgpu/spiraltorch_wasm_bg.wasm']}
report=dict(status='error',source_files=source,products=products,steps=[],rounds=[],
            boundary='AB then BA complete-process repeats; original frozen fixture and immutable binaries. No owned compilation overlaps timings. Ratios of medians, lower is better; not independent physical GPU attestation.')


def run(name,args,stdout=None):
    print('START',name,flush=True)
    start=time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        if stdout:
            with stdout.open('xb') as output: p=subprocess.run(args,cwd=ROOT,env=env,stdout=output,stderr=log)
        else: p=subprocess.run(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    report['steps'].append(dict(name=name,command=args,exit_code=p.returncode,seconds=time.monotonic()-start))
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print('END',name,p.returncode,flush=True)
    if p.returncode: raise RuntimeError(name)


try:
    # The added regression asserts all eight logical failure indices after reuse.
    run('stage-guards',['cargo','+1.98.0','test','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu','--test','resident_graph_forward','--','--test-threads=1'])
    run('fmt',['cargo','+nightly-2026-04-15','fmt','--all','--','--check'])
    for round_index,order in enumerate([['baseline','candidate'],['candidate','baseline']]):
        docs={}
        for version in order:
            root=L if version=='baseline' else L/'candidate'
            module=L/'webgpu-baseline' if version=='baseline' else root/'webgpu'
            prefix=f'{round_index}-{version}'
            run(prefix+'-native',[str(root/'native-bench')],stdout=OUT/(prefix+'-native.json'))
            run(prefix+'-python',[TORCH,'-I','tools/bench_graph_forward_paths.py','--fixture',str(L/'native.json'),
                '--native-library',str(root/'python-release.dylib'),'--output',str(OUT/(prefix+'-python.json'))])
            run(prefix+'-browser',['node','tools/test_resident_browser.cjs',str(module),CHROME,str(OUT/(prefix+'-browser.json')),'','','','','nn-forward-bench'])
            docs[version]={family:json.loads((OUT/(prefix+'-'+family+'.json')).read_bytes()) for family in ['native','python','browser']}
            native=docs[version]['native']
            admit_native(native)
            for case,frozen in zip(native['cases'],fixture['cases']):
                for name in ['seed','shape','depth','input','plan']: assert case[name]==frozen[name],name
                close(case['reference'],frozen['reference'])
                for values in case['last_outputs']: close(values,frozen['reference'])
            for family in ['python','browser']: admit_client(docs[version][family],fixture,L/'native.json',family=='browser')
        results=[]
        assert docs['baseline']['native']['adapter']==docs['candidate']['native']['adapter']
        assert docs['baseline']['python']['device_admission']==docs['candidate']['python']['device_admission']
        assert docs['baseline']['python']['torch']==docs['candidate']['python']['torch']
        assert docs['baseline']['browser']['browser_version']==docs['candidate']['browser']['browser_version']
        assert docs['baseline']['browser']['adapter']==docs['candidate']['browser']['adapter']
        for index,frozen in enumerate(fixture['cases']):
            result={key:frozen[key] for key in ['shape','seed','depth']}
            for family in ['native','python','browser']:
                b,a=[summarize(docs[v][family]['cases'][index]['samples']) for v in ['baseline','candidate']]
                result[family]=dict(baseline=b,candidate=a,candidate_over_baseline={
                    route:a[route]['median_ms_per_forward']/b[route]['median_ms_per_forward'] for route in b})
            results.append(result)
        report['rounds'].append(dict(order=order,cases=results))
    for name,expected in source.items(): assert digest(ROOT/name)==expected,name
    for name,expected in products.items(): assert digest(Path(name))==expected,name
    report['artifacts']={path.name:digest(path) for path in OUT.glob('*.json') if path.name!='receipt.json'}
    report['status']='passed'
except Exception as error:
    report['error']=repr(error)
    raise
finally:
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
