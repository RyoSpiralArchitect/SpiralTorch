"""Pack raw timings and failures, checking source/products and deriving all summaries."""
import hashlib
import json
import lzma
from pathlib import Path
import statistics
import subprocess

ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
L=Path(__file__).parent
DEST=ROOT/'benchmarks/results/2026-09-10-forward-single-pass'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
candidate=read(L/'candidate/receipt.json')
repeats=read(L/'repeats/receipt.json')
initial=read(L/'native-receipt.json')
assert candidate['status']==repeats['status']==initial['status']=='passed'
assert len(candidate['steps'])==19 and len(repeats['steps'])==14
assert all(s['exit_code']==0 for d in [candidate,repeats] for s in d['steps'])
for receipt in [candidate,repeats,initial]:
    for name,sha in receipt['source_files'].items(): assert digest(ROOT/name)==sha,name
for name,sha in candidate['products'].items(): assert digest(L/'candidate'/name)==sha,name
for name,sha in repeats['products'].items(): assert digest(Path(name))==sha,name
for name,sha in repeats['artifacts'].items(): assert digest(L/'repeats'/name)==sha,name
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==candidate['base']
assert read(L/'candidate/browser-correctness.json')['assertions']==536
assert read(L/'candidate/python-tests.json')['tests']==30
assert read(L/'candidate/python-tests.json')['skipped']==0

table=[]
for width in [7,64,128]:
    rows=[c for r in repeats['rounds'] for c in r['cases'] if c['shape'][-1]==width]
    assert len(rows)==6
    item=dict(shape=rows[0]['shape'],depth=rows[0]['depth'],paired_observations=len(rows),measurements={})
    for family,route in [('native','1'),('python','python_scalar_h2h'),('browser','scalar_h2h'),
                         ('python','python_scalar_burst'),('python','torch_mps_h2h'),('python','torch_cpu_h2h')]:
        ratios=[c[family]['candidate_over_baseline'][route] for c in rows]
        item['measurements'][family+':'+route]=dict(
            baseline_ms_per_forward=statistics.median(c[family]['baseline'][route]['median_ms_per_forward'] for c in rows),
            candidate_ms_per_forward=statistics.median(c[family]['candidate'][route]['median_ms_per_forward'] for c in rows),
            candidate_over_baseline_range=[min(ratios),max(ratios)])
    table.append(item)
perf=[L/'native.json',L/'python-torch-v2.json',L/'browser-baseline.json',L/'candidate/native.json',
      L/'candidate/python-torch.json',L/'candidate/browser.json']+sorted((L/'repeats').glob('[01]-*.json'))
docs=[read(p) for p in perf]
assert len(docs)==18 and all(d['status']=='passed' and len(d['cases'])==9 for d in docs)
timings=[s for d in docs for c in d['cases'] for s in c['samples']]
assert len(timings)==8262
summary=dict(schema='spiraltorch.forward_single_pass.evidence.v1',status='bounded_forward_optimization_validated',
    base=candidate['base'],source_files=repeats['source_files'],source_form='working-tree patch bound by SHA-256',
    change='Same shaders and stage semantics; private pointwise flags cleared before and captured after one mixed-graph compute pass.',
    native_adapter=docs[0]['adapter'],browser_adapter=docs[2]['adapter'],browser_physical_gpu='UNKNOWN',
    macos_gpu_contention='UNKNOWN',torch=docs[1]['torch'],torch_devices=['cpu','mps'],mps_fallback='explicitly disabled',
    initial_comparison='candidate/comparison.json',primary_repeat_orders=[r['order'] for r in repeats['rounds']],
    primary_table_definition='Median of six per-case medians: three seeds times two AB/BA repeat rounds. H2H and burst kept separate.',
    primary_table=table,recipes=9,retained_timing_rows=8262,primary_repeat_timing_rows=5508,
    max_abs_error=max(s['max_abs_error'] for s in timings),
    validation=dict(candidate_steps=19,repeat_steps=14,backend_serial_tests=111,nn_serial_tests=733,
                    initial_native_integration_tests=6,targeted_graph_tests=2,targeted_fault_positions=8,
                    python_gpu_tests=30,python_gpu_skips=0,browser_assertions=536,admission_tests=6),
    initial_admission_failure=dict(path='raw/python-torch.json.xz',cause='Comparing shortest f32 JSON decimals as exact f64 values.',
                                  fix='Bitwise f32 admission; no tolerance relaxation; one-ULP mutation rejection tested.'),
    unresolved_parallel_failure=dict(status='UNKNOWN',prior_archive='../2026-09-10-resident-graph-forward/README.md',
                                    note='The earlier one-off default-parallel training test failure is not fixed or proven pre-existing by these serial checks.'),
    boundaries=[
        'Forward-only microbenchmarks, not training throughput, model quality or autoregressive decode.',
        'Scalar/sequential and register-2x2/compensated results retained separately; no global fastest-kernel selection.',
        'Torch eager addmm/tanh-GELU, single CPU thread, no torch.compile or fastest-PyTorch claim.',
        'All measured models remain faster on the tested Torch CPU path than on these GPU paths.',
        'Native legacy Module retains its ordinary host caches and behavior; its difference is not transfer cost alone.',
        'Host representations differ: native Vec<f32>, Python lists, WASM Float32Array. Python/Torch both include list conversion.',
        'No automatic Module::forward/autograd routing, CUDA execution, push, merge or PyPI release.',
    ])
rawdir=DEST/'raw'
rawdir.mkdir(parents=True)
paths=sorted(path for directory in [L,L/'candidate',L/'repeats'] for path in directory.iterdir()
             if path.is_file() and path.suffix in ('.json','.log','.py'))
entries=[]
for path in paths:
    original=str(path.relative_to(L))
    data=path.read_bytes(); packed=lzma.compress(data,preset=6)
    target=rawdir/(original+'.xz');target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as output: output.write(packed)
    assert lzma.decompress(target.read_bytes())==data
    entries.append(dict(path=str(target.relative_to(DEST)),original_name=original,bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest(),compressed_sha256=hashlib.sha256(packed).hexdigest()))
for name,doc in [('manifest.json',dict(schema='spiraltorch.hash_archive.v1',entries=entries)),('summary.json',summary)]:
    with (DEST/name).open('x') as output:
        json.dump(doc,output,indent=2,allow_nan=False);output.write('\n')
print(json.dumps(dict(artifacts=len(entries),compressed_bytes=sum((DEST/e['path']).stat().st_size for e in entries),
                      source_files=len(repeats['source_files']),max_abs_error=summary['max_abs_error'])))
