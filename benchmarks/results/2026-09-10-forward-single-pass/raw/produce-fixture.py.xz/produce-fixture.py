import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

L = Path(__file__).parent
W = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
T = W.parent/'spiraltorch-spiralk-golden-blackcat-contract-v1/target/release'
files = ['crates/st-nn/Cargo.toml', 'crates/st-nn/examples/resident_graph_forward_bench.rs']
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = dict(status='error', base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),
              source_files={name:digest(W/name) for name in files}, products={})
for name, source in [('native-bench', T/'examples/resident_graph_forward_bench'),
                     ('python-release.dylib', T/'libspiraltorch.dylib')]:
    with (L/name).open('xb') as output: output.write(source.read_bytes())
    (L/name).chmod(0o555)
    report['products'][name]=digest(L/name)
start = time.monotonic()
with (L/'native.json').open('xb') as output, (L/'native.log').open('xb') as log:
    p = subprocess.run([str(L/'native-bench')], cwd=W, stdout=output, stderr=log)
report.update(exit_code=p.returncode, seconds=time.monotonic()-start)
for name, expected in report['source_files'].items(): assert digest(W/name)==expected
for name, expected in report['products'].items(): assert digest(L/name)==expected
report['status']='passed' if p.returncode==0 else 'error'
with (L/'native-receipt.json').open('x') as output: json.dump(report,output,indent=2)
print(json.dumps(report),flush=True)
raise SystemExit(p.returncode)
