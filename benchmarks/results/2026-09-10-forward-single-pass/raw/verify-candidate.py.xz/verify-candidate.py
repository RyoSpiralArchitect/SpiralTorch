"""Build before timing, freeze products, validate real clients and preserve raw evidence."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
T = ROOT.parent/'spiraltorch-spiralk-golden-blackcat-contract-v1/target'
L = Path(__file__).parent
OUT = L/'candidate'
OUT.mkdir()
P='/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
BINDGEN='/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen'
CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
PREVIOUS=Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910')
env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_TARGET_DIR=str(T),PYO3_PYTHON=P,
         SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1',PYTORCH_ENABLE_MPS_FALLBACK='0',
         NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=subprocess.check_output(['git','ls-files','-mo','--exclude-standard'],cwd=ROOT,text=True).splitlines()
report=dict(status='error',base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
            source_files={name:digest(ROOT/name) for name in names},steps=[],products={},
            baseline_products={name:digest(L/name) for name in ['native-bench','python-release.dylib','webgpu-baseline/spiraltorch_wasm_bg.wasm']})


def run(name,args,stdout=None):
    print('START',name,flush=True)
    start=time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        if stdout:
            with Path(stdout).open('xb') as output:
                p=subprocess.run(args,cwd=ROOT,env=env,stdout=output,stderr=log)
        else:
            p=subprocess.run(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    report['steps'].append(dict(name=name,command=args,exit_code=p.returncode,seconds=time.monotonic()-start))
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print('END',name,p.returncode,flush=True)
    if p.returncode: raise RuntimeError(name)


def freeze(source,target):
    with target.open('xb') as output: output.write(source.read_bytes())
    target.chmod(0o555)
    report['products'][str(target.relative_to(OUT))]=digest(target)


try:
    run('fmt',['cargo','+nightly-2026-04-15','fmt','--all','--','--check'])
    run('admission',[P,'-I','tests/test_graph_forward_paths.py','-v'])
    run('existing-admission',[P,'-I','tests/test_resident_graph_forward_validation.py'])
    run('native-build',['cargo','+1.98.0','build','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu','--example','resident_graph_forward_bench'])
    freeze(T/'release/examples/resident_graph_forward_bench',OUT/'native-bench')
    run('python-build',['cargo','+1.98.0','build','--locked','--release','-p','spiraltorch-py'])
    freeze(T/'release/libspiraltorch.dylib',OUT/'python-release.dylib')
    run('wasm-build',['cargo','+1.98.0','build','--locked','--release','-p','spiraltorch-wasm','--target','wasm32-unknown-unknown','--no-default-features','--features','webgpu'])
    run('wasm-bindgen',[BINDGEN,str(T/'wasm32-unknown-unknown/release/spiraltorch_wasm.wasm'),'--target','web','--out-dir',str(OUT/'webgpu'),'--out-name','spiraltorch_wasm'])
    for path in (OUT/'webgpu').rglob('*'):
        if path.is_file():
            path.chmod(0o444);report['products'][str(path.relative_to(OUT))]=digest(path)
    shutil.copyfile(L/'native.json',OUT/'webgpu/forward-bench-fixture.json')
    shutil.copyfile(PREVIOUS/'final/core-fixture.json',OUT/'webgpu/forward-fixture.json')
    run('backend-serial',['cargo','+1.98.0','test','--locked','--release','-p','st-backend-wgpu','--lib','--','--test-threads=1'])
    run('nn-serial',['cargo','+1.98.0','test','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu','--lib','--','--test-threads=1'])
    run('native-integration',['cargo','+1.98.0','test','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu','--test','resident_graph_forward','--test','resident_inference','--test','resident_graph_training','--test','resident_nd_tensor','--','--test-threads=1'])
    run('clippy',['cargo','+1.98.0','clippy','--locked','--release','-p','st-backend-wgpu','--lib','--','-D','warnings'])
    run('cpu-check',['cargo','+1.98.0','check','--locked','-p','st-nn','--no-default-features'])
    run('python-tests',[P,'-I',str(PREVIOUS/'python-client.py'),str(OUT/'python-release.dylib'),str(ROOT),'tests',str(OUT/'python-tests.json')])
    run('browser-correctness',['node','tools/test_resident_browser.cjs',str(OUT/'webgpu'),CHROME,str(OUT/'browser-correctness.json'),'','','','','nn-forward-clients'])
    # No owned compilation/test process overlaps the timing phase.
    run('native-bench',[str(OUT/'native-bench')],stdout=OUT/'native.json')
    run('python-torch',[TORCH,'-I','tools/bench_graph_forward_paths.py','--fixture',str(L/'native.json'),'--native-library',str(OUT/'python-release.dylib'),'--output',str(OUT/'python-torch.json')])
    run('browser-bench',['node','tools/test_resident_browser.cjs',str(OUT/'webgpu'),CHROME,str(OUT/'browser.json'),'','','','','nn-forward-bench'])
    run('compare',[P,'-I','tools/validate_graph_forward_paths.py','--baseline-native',str(L/'native.json'),'--candidate-native',str(OUT/'native.json'),
        '--baseline-python',str(L/'python-torch-v2.json'),'--candidate-python',str(OUT/'python-torch.json'),
        '--baseline-browser',str(L/'browser-baseline.json'),'--candidate-browser',str(OUT/'browser.json'),'--output',str(OUT/'comparison.json')])
    run('diff-check',['git','diff','--check'])
    for name,expected in report['source_files'].items(): assert digest(ROOT/name)==expected,name
    for name,expected in report['products'].items(): assert digest(OUT/name)==expected,name
    for name,expected in report['baseline_products'].items(): assert digest(L/name)==expected,name
    report['status']='passed'
except Exception as error:
    report['error']=repr(error)
    raise
finally:
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
