"""Independently compare compressed records to originals/Git and frozen products."""
from collections import Counter
import hashlib
import json
import lzma
from pathlib import Path
import subprocess

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
OUT = ROOT / 'benchmarks/results/2026-09-12-resident-vjp-capture-pool'
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest_bytes = (OUT / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
summary = json.loads((OUT / 'summary.json').read_bytes())
assert summary['status'] == manifest['status'] == 'passed'
assert summary['manifest_sha256'] == sha(manifest_bytes)
names = set()
origins = Counter()
raw_total = packed_total = 0
for entry in manifest['records']:
    name = entry['archive']
    path = OUT / name
    assert name not in names and path.resolve().is_relative_to((OUT / 'raw').resolve())
    names.add(name)
    packed = path.read_bytes()
    data = lzma.decompress(packed)
    assert len(packed) == entry['compressed_bytes'] and sha(packed) == entry['compressed_sha256'], name
    assert len(data) == entry['bytes'] and sha(data) == entry['sha256'], name
    origin = entry['origin']
    if 'git_commit' in origin:
        original = subprocess.check_output(['git', 'show', origin['git_commit'] + ':' + origin['git_path']], cwd=ROOT)
        origins['git'] += 1
    else:
        original = Path(origin['path']).read_bytes()
        origins['local'] += 1
    assert data == original, name
    raw_total += len(data)
    packed_total += len(packed)
assert names == {str(path.relative_to(OUT)) for path in (OUT / 'raw').rglob('*') if path.is_file()}
assert raw_total == manifest['raw_bytes'] and packed_total == manifest['compressed_bytes']
assert len(names) == summary['raw_records']
for item in summary['products']:
    assert sha(Path(item['path']).read_bytes()) == item['sha256'], item['path']
assert len(summary['products']) == summary['frozen_products_checked']
source = summary['candidate_source']
assert subprocess.check_output(['git', 'rev-parse', source['commit'] + '^{tree}'], cwd=ROOT, text=True).strip() == source['tree']
subprocess.run(['git', 'merge-base', '--is-ancestor', source['commit'], 'HEAD'], cwd=ROOT, check=True)
run_path = OUT / 'raw/runs/verified-a/receipt.json.xz'
run = json.loads(lzma.decompress(run_path.read_bytes()))
assert run['status'] == 'passed' and 'active' not in run and run['source'] == source
assert len(run['steps']) == summary['verification_steps'] == 69
assert all(step['exit_code'] == 0 for step in run['steps'])
torch = json.loads(lzma.decompress((OUT / 'raw/runs/verified-a/torch-correctness.json.xz').read_bytes()))
for item in torch['inputs']:
    assert sha(Path(item['path']).read_bytes()) == item['sha256']
microbatch = [case for case in torch['cases'] if case.get('topos_momentum')]
assert len(microbatch) == summary['torch_momentum_matched']['cases'] == 24
assert len(torch['reference_gaps']) == len(summary['existing_torch_reference_gaps']) == 4
assert all('NOT a matched' in gap['scope'] for gap in torch['reference_gaps'])
measured = json.loads(lzma.decompress((OUT/'raw/runs/measurement-a/receipt.json.xz').read_bytes()))
assert measured['status'] == 'passed' and 'active' not in measured
assert measured['source'] == source and len(measured['steps']) == summary['measurement_stages'] == 12
assert all(s['exit_code'] == 0 for s in measured['steps'])
repeat = json.loads(lzma.decompress((OUT/'raw/runs/measurement-b/receipt.json.xz').read_bytes()))
assert repeat['status'] == 'passed' and 'active' not in repeat and repeat['source'] == source
assert len(repeat['steps']) == summary['repeat_stages'] == 9 and all(s['exit_code'] == 0 for s in repeat['steps'])
timings = []
intervals = 0
for execution in ['measurement-a', 'measurement-b']:
    for mode in ['plain', 'topos_ema', 'clipped_topos_ema']:
        value = json.loads(lzma.decompress((OUT/('raw/runs/'+execution+'/'+mode+'-validation.json.xz')).read_bytes()))
        assert value['status'] == 'passed' and len(value['cases']) == 9
        assert value['browser_intervals_revalidated'] == 360
        intervals += value['browser_intervals_revalidated']
        for item in value['inputs']:
            assert sha(Path(item['path']).read_bytes()) == item['sha256']
        for row in value['cases']:
            timings.append(dict(run=execution, mode=mode, config=row['config'], native=row['native'], browser=row['browser'],
                max_abs_error=max(row['max_abs_errors'].values())))
assert timings == summary['timings'] and len(timings) == 54
for path, digest in summary['unchanged_benchmark_sha256'].items():
    for source in [summary['baseline_source'], summary['candidate_source']]:
        assert sha(subprocess.check_output(['git', 'show', source['commit']+':'+path], cwd=ROOT)) == digest
host = json.loads(lzma.decompress((OUT/'raw/runs/host-validation.json.xz').read_bytes()))
assert host == summary['host_diagnosis'] and host['status'] == 'passed'
assert host['native_diagnostic_intervals'] == host['native_controls'] == 1080
assert host['browser_diagnostic_intervals'] == host['browser_controls'] == 54
assert host['compared_states'] == 324
for item in host['inputs']: assert sha(Path(item['path']).read_bytes()) == item['sha256']
for name in ['native-correctness.json', 'browser-correctness.json']:
    fixture = json.loads(lzma.decompress((OUT/('raw/runs/verified-a/'+name+'.xz')).read_bytes()))
    pool = [g for g in fixture['autograd']['guards'] if g['case'] == 'whole_vjp_pool_pending_reads_views_and_spill']
    assert len(pool) == 1 and pool[0]['passed'] and pool[0]['held_versions'] == 7
    assert pool[0]['captured_vjps'] == 9 and pool[0]['observation'] == 'after_workspace_drop'
source = summary['candidate_source']
verification = dict(status='passed', scope='Independent archive and source/product integrity check; not a second runtime run',
    source=source, records=len(names), origins=dict(origins), products=len(summary['products']),
    manifest_sha256=sha(manifest_bytes), raw_bytes=raw_total, compressed_bytes=packed_total,
    runtime_steps=len(run['steps']), torch_cases=len(torch['cases']),
    torch_comparisons=sum(case['comparisons'] for case in torch['cases']),
    momentum_cases=len(microbatch),
    momentum_comparisons=sum(case['comparisons'] for case in microbatch),
    paired_optimizer_recipes=len(timings), browser_intervals=intervals,
    separate_reference_gaps=len(torch['reference_gaps']), host_compared_states=host['compared_states'],
    host_max_abs_error=host['max_abs_error'])
with (OUT / 'verification.json').open('x') as stream:
    json.dump(verification, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps(verification))
