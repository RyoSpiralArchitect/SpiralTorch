// Isolated browser validation of the diagnostic entry point, not throughput data.
const fs=require("node:fs"), path=require("node:path"), crypto=require("node:crypto"), http=require("node:http");
const {chromium}=require("playwright");
const sha=file=>crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
const html=`<!doctype html><meta charset="utf-8"><pre id="result" data-status="running"></pre>
<script type="module">
import init,{TrainingBenchmark} from "/wasm/spiraltorch_wasm.js";
const result=document.querySelector("#result");
try {
  await init();
  let completed=0;
  const phases=["forward_enqueue","quadratic_seed_enqueue","quadratic_vjp_enqueue","quartic_seed_enqueue","quartic_vjp_enqueue","update_enqueue","receipt_capture_enqueue","receipt_wait"];
  for(const mode of [null,"topos_ema","clipped_topos_ema"]) for(const seed of [17,29,43])
    for(const [shape,depth] of [[[2,16,32],2],[[2,129,32],4],[[4,32,64],8]]) {
      const config={shape,depth,seed,steps:8,graph:true,...(mode?{learner_optimizer:mode}:{})};
      const workspace=await TrainingBenchmark.create(JSON.stringify(config));
      try {
        const fixture=JSON.parse(workspace.fixture()), samples=[];
        if(fixture.adapter.backend!=="BrowserWebGpu"||fixture.adapter.device_type==="Cpu") throw Error("WebGPU required");
        for(const cadence of ["immediate","deferred"]) {
          const pair={};
          for(const kind of completed%2?["profile","control"]:["control","profile"]) {
            const text=kind==="profile"?await workspace.learnHostProfile(JSON.stringify(cadence),true):await workspace.learn(JSON.stringify(cadence),true);
            const value=JSON.parse(text);
            if(value.status!=="passed"||value.steps!==8||value.completed_updates!==8||value.cadence!==cadence||value.acceptance!=="guarded_receipts"||
              JSON.stringify(value.accepted_updates)!=="[2,3,4,5,6,7,8,9]"||!value.state||!Number.isFinite(value.elapsed_ms)||value.elapsed_ms<=0) throw Error("incomplete learner interval");
            if(kind==="control") {if("host_profile" in value) throw Error("ordinary interval was instrumented");}
            else {
              const p=value.host_profile;
              if(p?.schema!=="spiraltorch.learner_host_phases.v1"||p.instrumented!==true||p.clock_domain!=="host_wall"||p.gpu_phase_attribution!==false||p.phases.length!==8) throw Error("clock contract");
              if(!Number.isFinite(p.unattributed_ms)||p.unattributed_ms<0||p.phases.some((v,i)=>v.name!==phases[i]||v.count!==8||!Number.isFinite(v.ms)||v.ms<0)) throw Error("phase contract");
              const total=p.unattributed_ms+p.phases.reduce((s,v)=>s+v.ms,0);
              if(Math.abs(total-value.elapsed_ms)>1e-6) throw Error("duration partition");
            }
            pair[kind]=value;
            samples.push({kind,cadence,value});
          }
          if(pair.control.state_sha256!==pair.profile.state_sha256||JSON.stringify(pair.control.state)!==JSON.stringify(pair.profile.state)) throw Error("instrumentation changed state");
        }
        await recordHostCase(JSON.stringify({config,fixture,samples}));
        completed++;
      } finally { workspace.free(); }
    }
  result.textContent=JSON.stringify({status:"passed",completed});result.dataset.status="passed";
} catch(error) {result.textContent=JSON.stringify({status:"error",error:String(error.stack||error)});result.dataset.status="error";}
</script>`;

async function main(){
  const output=process.argv[2]; if(!output||process.argv.length!==3) throw Error("NEW_OUTPUT required");
  const base=__dirname, build=JSON.parse(fs.readFileSync(path.join(base,"candidate-a/receipt.json")));
  if(build.status!=="passed") throw Error("unverified build receipt");
  const root=path.join(base,"candidate-a/wasm"), files=new Map();
  function assets(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){
    const file=path.join(dir,e.name);if(e.isDirectory())assets(file);
    else if(e.isFile()&&/\.(js|wasm)$/.test(file))files.set("/wasm/"+path.relative(root,file).split(path.sep).join("/"),file);
  }} assets(root);
  for(const [url,file] of files) if(sha(file)!==build.products["wasm/"+url.slice(6)]) throw Error("build asset changed");
  const fd=fs.openSync(output,"wx"), rows=fs.openSync(output+".cases.jsonl","wx");
  let browser,server,report={status:"error",source:build.source,cases:[],physical_gpu:"UNKNOWN",
    boundary:"One paired profile/control per recipe/cadence; diagnostic API/state validation, not performance medians or GPU phase attribution",
    build_receipt_sha256:sha(path.join(base,"candidate-a/receipt.json")),harness_sha256:sha(__filename),
    asset_sha256:Object.fromEntries([...files].map(([url,file])=>[url,sha(file)])),errors:[]};
  try {
    server=http.createServer((request,response)=>{
      const url=new URL(request.url,"http://127.0.0.1").pathname;
      if(url==="/"){response.setHeader("Content-Type","text/html");response.end(html);return;}
      const file=files.get(url);if(!file){response.writeHead(404);response.end();return;}
      response.setHeader("Content-Type",file.endsWith(".wasm")?"application/wasm":"text/javascript");response.end(fs.readFileSync(file));
    });
    await new Promise(resolve=>server.listen(0,"127.0.0.1",resolve));
    browser=await chromium.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",headless:true,args:["--enable-unsafe-webgpu"]});
    report.browser_version=browser.version();
    const page=await browser.newPage();
    let fail;const fatal=new Promise((_,reject)=>{fail=reject;});fatal.catch(()=>{});
    page.on("pageerror",e=>{report.errors.push(String(e));fail(e);});
    await page.exposeFunction("recordHostCase",text=>{
      const row=JSON.parse(text), git=row.fixture.build_manifest.git;
      if(git.commit!==build.source.commit||git.tree!==build.source.tree||git.dirty!==false||row.samples.length!==4||report.cases.length>=27) throw Error("source or case mismatch");
      fs.writeSync(rows,text+"\n");report.cases.push({config:row.config,adapter:row.fixture.adapter});
      console.log(JSON.stringify({completed:report.cases.length,config:row.config}));
    });
    await page.goto("http://127.0.0.1:"+server.address().port+"/");
    await Promise.race([fatal,page.locator("#result:not([data-status='running'])").waitFor({timeout:600000})]);
    const result=JSON.parse(await page.locator("#result").textContent());
    if(result.status!=="passed"||result.completed!==27||report.cases.length!==27||report.errors.length) throw Error(JSON.stringify(result));
    for(const [url,file] of files)if(sha(file)!==report.asset_sha256[url])throw Error("served asset changed");
    report.status="passed";
  }catch(error){report.error=String(error.stack||error);}
  finally{
    try{if(browser)await browser.close();}finally{if(server)await new Promise(resolve=>server.close(resolve));}
    fs.writeFileSync(fd,JSON.stringify(report)+"\n");fs.closeSync(fd);fs.closeSync(rows);
  }
  if(report.status!=="passed")throw Error(report.error);
}
main().catch(error=>{console.error(error);process.exitCode=1;});
