"""Independently admit diagnostic records and compare them to the ordinary Torch oracle."""
import hashlib
import json
from pathlib import Path
import statistics
import sys

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
sys.path.insert(0, str(ROOT/'tools'))
import profile_resident_learner_host as host
bench = host.bench
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_bytes())
key = lambda value: json.dumps(value, sort_keys=True)
expected = {key(config) for mode in (None, 'topos_ema', 'clipped_topos_ema') for config in bench.recipes(True, 'standard', mode)}
oracle = {}
inputs = []
for mode in ('plain', 'topos_ema', 'clipped_topos_ema'):
    # Independent eager Torch state was captured by the uninstrumented benchmark.
    report = read(LOG/'measurement-a'/(mode+'-native.json'))
    assert report['status'] == 'passed'
    inputs.append(dict(path=str(LOG/'measurement-a'/(mode+'-native.json')), sha256=sha(LOG/'measurement-a'/(mode+'-native.json'))))
    for case in report['cases']:
        oracle[key(case['config'])] = case
profiles = {}
maximum = 0.
compared = 0
for role in ('baseline', 'candidate'):
    path = LOG/(role+'-host.json')
    value = read(path)
    assert value['status'] == 'passed' and len(value['cases']) == 27
    assert value['retained_blocks'] == 8 and value['warmup_blocks'] == 2
    receipt = read(LOG/(role+'-a')/'receipt.json')
    inputs.append(dict(path=str(LOG/(role+'-a')/'receipt.json'), sha256=sha(LOG/(role+'-a')/'receipt.json')))
    assert value['source'] == dict(receipt['source'], tracked_dirty=False)
    seen, summaries = set(), []
    for case in value['cases']:
        config = case['config']; identity = key(config)
        assert identity in expected and identity not in seen
        seen.add(identity)
        assert len(case['samples']) == 40
        observations, fingerprint, states = set(), None, []
        for sample in case['samples']:
            result = sample['result']; cadence = result['cadence']
            assert cadence in ('immediate', 'deferred') and type(sample['block']) is int and 0 <= sample['block'] < 10
            assert sample['warmup'] == (sample['block'] < 2)
            assert sample['op'] in ('learn', 'learn_host_profile')
            obs = (cadence, sample['block'], sample['op'])
            assert obs not in observations; observations.add(obs)
            if sample['op'] == 'learn_host_profile': host.validate(result, cadence, config)
            else: bench.validate_sample(result, cadence, 8, learner=True, learner_optimizer=config.get('learner_optimizer'))
            fingerprint = fingerprint or result['state_sha256']
            assert result['state_sha256'] == fingerprint
            if sample['block'] == 0:
                assert result['state'] is not None
                states.append(result['state'])
            else: assert result['state'] is None
        assert len(states) == 4 and all(state == states[0] for state in states)
        # compare() rejects missing gradients/history and nonfinite values.
        torch_state = oracle[identity]['captures']['immediate_torch']['state']
        for state in states:
            maximum = max(maximum, bench.learner_reference.compare(state, torch_state)); compared += 1
        for cadence in ('immediate', 'deferred'):
            selected = [s['result'] for s in case['samples'] if not s['warmup'] and s['op'] == 'learn_host_profile' and s['result']['cadence'] == cadence]
            medians = {name: statistics.median(v['host_profile']['phases'][i]['ms'] for v in selected) for i,name in enumerate(host.PHASES)}
            assert medians == case['medians'][cadence]
        summaries.append(dict(config=config, medians=case['medians']))
    assert seen == expected
    inputs.append(dict(path=str(path), sha256=sha(path)))
    profiles[role] = summaries
browser = LOG/'browser-host.json'
report = read(browser)
assert report['status'] == 'passed' and len(report['cases']) == 27 and not report['errors']
seen = set()
with Path(str(browser)+'.cases.jsonl').open() as stream:
    for line in stream:
        case = json.loads(line); config = case['config']; identity = key(config)
        assert identity in expected and identity not in seen; seen.add(identity)
        assert len(case['samples']) == 4 and case['fixture']['adapter']['backend'] == 'BrowserWebGpu'
        observations, states, fingerprint = set(), [], None
        for sample in case['samples']:
            result = sample['value']; cadence = sample['cadence']
            obs = (cadence, sample['kind'])
            assert cadence in ('immediate','deferred') and sample['kind'] in ('profile','control') and obs not in observations
            observations.add(obs)
            if sample['kind'] == 'profile': host.validate(result, cadence, config)
            else: bench.validate_sample(result, cadence, 8, learner=True, learner_optimizer=config.get('learner_optimizer'))
            fingerprint = fingerprint or result['state_sha256']
            assert result['state_sha256'] == fingerprint
            states.append(result['state'])
            maximum = max(maximum, bench.learner_reference.compare(result['state'], oracle[identity]['captures']['immediate_torch']['state'])); compared += 1
        assert all(state == states[0] for state in states)
assert seen == expected
for path in [browser, Path(str(browser)+'.cases.jsonl')]: inputs.append(dict(path=str(path), sha256=sha(path)))
result = dict(status='passed', boundary='Independent record/phase validation and comparison with recorded eager Torch states; not another GPU run or a timing speedup claim. Baseline and candidate host diagnoses were separate runs, not paired A/B throughput.',
              inputs=inputs, native_diagnostic_intervals=1080, native_controls=1080,
              browser_diagnostic_intervals=54, browser_controls=54,
              compared_states=compared, max_abs_error=maximum, profiles=profiles)
with (LOG/'host-validation.json').open('x') as stream: json.dump(result, stream, indent=2, allow_nan=False)
print(json.dumps({k:v for k,v in result.items() if k not in ('profiles','inputs')}))
