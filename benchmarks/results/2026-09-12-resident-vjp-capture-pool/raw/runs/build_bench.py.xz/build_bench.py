"""Freeze native and browser benchmark products without running GPU workloads."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
TARGET = ROOT.parent/'spiraltorch-spiralk-golden-blackcat-contract-v1/target'
LOG = Path(__file__).parent
P = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
BINDGEN = '/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen'
if len(sys.argv) == 3 and sys.argv[1] == '--launch':
    name = sys.argv[2]
    assert Path(name).name == name and not (LOG/name).exists()
    with (LOG/(name+'.log')).open('xb') as output:
        child = subprocess.Popen([P, '-S', str(Path(__file__).resolve()), name], cwd=ROOT,
            stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps(dict(pid=child.pid, log=str(LOG/(name+'.log')))))
    raise SystemExit(0)
assert len(sys.argv) == 2 and Path(sys.argv[1]).name == sys.argv[1]
OUT = LOG/sys.argv[1]
OUT.mkdir()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
assert not git('status', '--porcelain')
source = dict(commit=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'))
env = dict(os.environ, CARGO_BUILD_JOBS='4', CARGO_TARGET_DIR=str(TARGET), PYO3_PYTHON=P,
    SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1', PYTORCH_ENABLE_MPS_FALLBACK='0')
report = dict(status='running', pid=os.getpid(), source=source, steps=[], products={})
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
report['harness_sha256'] = sha(Path(__file__))

def save():
    path = OUT/'receipt.json.tmp'
    path.write_text(json.dumps(report, indent=2)+'\n')
    path.replace(OUT/'receipt.json')

def run(name, args):
    args = list(map(str, args))
    started = time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        child = subprocess.Popen(args, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        report['active'] = dict(name=name, pid=child.pid, command=args)
        save()
        code = child.wait()
    report.pop('active')
    report['steps'].append(dict(name=name, command=args, exit_code=code, seconds=time.monotonic()-started))
    save()
    if code: raise RuntimeError(name)

start = time.monotonic()
try:
    run('admission', [P, '-I', ROOT/'tests/test_resident_training_bench.py'])
    common = ['cargo', '+1.98.0', 'build', '--locked', '--release', '-p', 'st-nn', '--no-default-features', '--features', 'wgpu']
    run('native-build', common+['--example', 'resident_training_bench'])
    binary = OUT/'resident_training_bench'
    shutil.copyfile(TARGET/'release/examples/resident_training_bench', binary)
    binary.chmod(0o555)
    report['products'][binary.name] = sha(binary)
    run('wasm-build', common+['--example', 'resident_training_bench_browser', '--target', 'wasm32-unknown-unknown'])
    run('bindgen', [BINDGEN, TARGET/'wasm32-unknown-unknown/release/examples/resident_training_bench_browser.wasm',
        '--target', 'web', '--out-dir', OUT/'wasm', '--out-name', 'spiraltorch_wasm'])
    for path in (OUT/'wasm').rglob('*'):
        if path.is_file(): report['products'][str(path.relative_to(OUT))] = sha(path)
    assert not git('status', '--porcelain') and git('rev-parse', 'HEAD') == source['commit']
    identity = json.loads(subprocess.check_output([binary, '--build-info'], cwd=ROOT))
    assert identity['manifest']['git']['commit'] == source['commit']
    assert identity['manifest']['git']['tree'] == source['tree'] and not identity['manifest']['git']['dirty']
    report['native_identity'] = identity
    report['status'] = 'passed'
except BaseException as error:
    report.update(status='error', error=repr(error))
    raise
finally:
    report['seconds'] = time.monotonic()-start
    save()
    print(json.dumps(report))
