"""Preliminary numerical admission of the optimizer benchmark, not timing evidence."""
import json
from pathlib import Path
import sys
import torch

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
sys.path.insert(0, str(ROOT/'tools'))
import bench_resident_training_vs_torch as bench
role = sys.argv[1]
receipt = json.loads((LOG/role/'receipt.json').read_bytes())
assert receipt['status'] == 'passed'
torch.set_num_threads(1)
assert torch.backends.mps.is_available()
rows = []
with (LOG/(role+'-smoke.stderr')).open('xb') as stderr:
    worker = bench.Native(LOG/role/'resident_training_bench', receipt['source']['commit'], stderr)
    try:
        for optimizer in (None, 'topos_ema', 'clipped_topos_ema'):
            config = bench.recipes(True, 'standard', optimizer)[0]
            fixture = worker.request(dict(op='init', config=config))
            assert fixture['adapter']['device_type'] != 'Cpu'
            actual = worker.request(dict(op='learn', cadence='deferred', capture=True))
            bench.validate_sample(actual, 'deferred', 8, learner=True, learner_optimizer=optimizer)
            for device in ('cpu', 'mps'):
                sync = torch.mps.synchronize if device == 'mps' else lambda: None
                expected = bench.learner_reference.torch_sample(torch, fixture, device, 'deferred', sync)
                bench.validate_sample(expected, 'deferred', 8, learner=True, lane='torch', learner_optimizer=optimizer)
                error = bench.learner_reference.compare(actual['state'], expected['state'])
                rows.append(dict(config=config, device=device, max_abs_error=error, fixture=fixture,
                    actual=actual, expected=expected))
    finally:
        worker.close()
report = dict(status='passed', source=receipt['source'], torch=torch.__version__, cases=rows,
    boundary='Three optimizer settings, one small recipe, CPU/MPS independent state replay; not retained performance measurements.')
with (LOG/(role+'-smoke.json')).open('x') as stream:
    json.dump(report, stream, allow_nan=False)
    stream.write('\n')
print(json.dumps(dict(status='passed', cases=len(rows), max_abs_error=max(r['max_abs_error'] for r in rows))))
