"""Repeat every frozen mode, not selected cells; retain the first run unchanged."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
P = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH = '/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
if len(sys.argv) == 3 and sys.argv[1] == '--launch':
    name = sys.argv[2]
    assert Path(name).name == name and not (LOG/name).exists()
    with (LOG/(name+'.log')).open('xb') as output:
        child = subprocess.Popen([P, '-S', str(Path(__file__).resolve()), name], cwd=ROOT,
            stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps(dict(pid=child.pid, log=str(LOG/(name+'.log')))))
    raise SystemExit(0)
assert len(sys.argv) == 2 and Path(sys.argv[1]).name == sys.argv[1]
OUT = LOG/sys.argv[1]
OUT.mkdir()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
first = json.loads((LOG/'measurement-a/receipt.json').read_bytes())
assert first['status'] == 'passed' and 'active' not in first
source, baseline = first['source'], first['baseline_source']
assert not git('status', '--porcelain') and git('rev-parse', 'HEAD') == source['commit']
products = {}
for role in ['baseline-a', 'candidate-a']:
    receipt = json.loads((LOG/role/'receipt.json').read_bytes())
    assert receipt['status'] == 'passed'
    for name, expected in receipt['products'].items():
        path = LOG/role/name
        assert sha(path) == expected
        products[str(path.relative_to(LOG))] = expected
env = dict(os.environ, SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1', PYTORCH_ENABLE_MPS_FALLBACK='0',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
report = dict(status='running', pid=os.getpid(), source=source, baseline_source=baseline, steps=[], products=products,
    first_receipt_sha256=sha(LOG/'measurement-a/receipt.json'), harness_sha256=sha(Path(__file__)),
    mode_order=['clipped_topos_ema', 'topos_ema', 'plain'],
    reason='Preregistered full-matrix repeat for VJP capture pooling, which affects all three optimizer modes. Reverse only mode order; retain identical per-case rotation, shapes/seeds, cadence, warmups and sample counts. No selected-cell retry or unchanged-SGD claim. Do not pool away the first run.',
    boundary=first['boundary'])

def save():
    path = OUT/'receipt.json.tmp'
    path.write_text(json.dumps(report, indent=2)+'\n')
    path.replace(OUT/'receipt.json')

def run(name, args):
    args = list(map(str, args))
    started = time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        child = subprocess.Popen(args, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        report['active'] = dict(name=name, pid=child.pid, command=args)
        save()
        code = child.wait()
    report.pop('active')
    report['steps'].append(dict(name=name, command=args, exit_code=code, seconds=time.monotonic()-started))
    save()
    if code: raise RuntimeError(name)
    assert not git('status', '--porcelain') and git('rev-parse', 'HEAD') == source['commit']

start = time.monotonic()
try:
    for mode in report['mode_order']:
        optimizer = [] if mode == 'plain' else ['--learner-optimizer', mode]
        native, browser = OUT/(mode+'-native.json'), OUT/(mode+'-browser.json')
        run('native-'+mode, [TORCH, '-I', ROOT/'tools/bench_resident_training_vs_torch.py',
            '--baseline', LOG/'baseline-a/resident_training_bench', '--baseline-source', baseline['commit'],
            '--candidate', LOG/'candidate-a/resident_training_bench', '--candidate-source', source['commit'],
            '--device', 'mps', '--graph', '--learner', *optimizer, '--output', native])
        run('browser-'+mode, ['node', ROOT/'tools/bench_resident_training_browser.cjs',
            LOG/'baseline-a/wasm', LOG/'candidate-a/wasm', CHROME, browser,
            'learner', 'standard', 'none', 'none' if mode == 'plain' else mode])
        run('validate-'+mode, [P, '-I', ROOT/'tools/validate_resident_training_bench.py',
            '--native', native, '--browser', browser, '--browser-progress', str(browser)+'.progress.jsonl',
            '--baseline-source', baseline['commit'], '--candidate-source', source['commit'],
            '--browser-harness-source', source['commit'], '--output', OUT/(mode+'-validation.json')])
    for path, expected in products.items(): assert sha(LOG/path) == expected
    for path in OUT.glob('*.json'):
        if path.name != 'receipt.json': report['products'][str(path.relative_to(LOG))] = sha(path)
    report['status'] = 'passed'
except BaseException as error:
    report.update(status='error', error=repr(error))
    raise
finally:
    report['seconds'] = time.monotonic()-start
    save()
    print(json.dumps(report))
