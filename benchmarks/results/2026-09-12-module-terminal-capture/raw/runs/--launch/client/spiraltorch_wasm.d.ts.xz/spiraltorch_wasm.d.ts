/* tslint:disable */
/* eslint-disable */
export function zspaceStochasticSchrodingerForwardJson(request_json: string): string;
export function validateZspaceStochasticSchrodingerForwardJson(receipt_json: string): string;
export function zspaceStochasticSchrodingerVjpJson(request_json: string): string;
export function validateZspaceStochasticSchrodingerVjpJson(receipt_json: string): string;
export function fractalFieldProbeObject(octaves: number, lacunarity: number, gain: number, iterations: number, log_start: number, log_step: number, len: number, preview_len: number): any;
export function fractalFieldProbeJson(octaves: number, lacunarity: number, gain: number, iterations: number, log_start: number, log_step: number, len: number, preview_len: number): string;
export function runtimeDeviceProbeJson(request_json: string): string;
export function runtimeDeviceProbeObject(request: any): any;
export function runtimeDeviceProbeObserveJson(request_json: string): string;
export function runtimeDeviceProbeObserveObject(request: any): any;
export function runtimeDeviceProbeValidateJson(payload_json: string): string;
export function runtimeDeviceProbeValidateObject(payload: any): any;
export function runtimeDeviceProbeValidateAgainstJson(payload_json: string, request_json: string): string;
export function runtimeDeviceProbeValidateAgainstObject(payload: any, request: any): any;
export function toposControlSignalJson(input_json: string): string;
export function toposControlSignalObject(input: any): any;
export function toposOptimizerSnapshotJson(input_json: string): string;
export function toposOptimizerSnapshotObject(input: any): any;
export function toposZSpaceProjectionJson(input_json: string, gradient_dim: number): string;
export function toposZSpaceProjectionObject(input: any, gradient_dim: number): any;
export function runtimeExecutionPlanJson(request_json: string): string;
export function runtimeExecutionPlanObject(request: any): any;
export function runtimeExecutionPlanObserveCapabilitiesJson(request_json: string): string;
export function runtimeExecutionPlanObserveCapabilitiesObject(request: any): any;
export function runtimeExecutionPlanValidateJson(payload_json: string): string;
export function runtimeExecutionPlanValidateObject(payload: any): any;
export function runtimeExecutionPlanValidateAgainstJson(payload_json: string, request_json: string): string;
export function runtimeExecutionPlanValidateAgainstObject(payload: any, request: any): any;
export function auditWasmReportJson(report_json: string): string;
export function auditWasmReportObject(report: any): any;
export function compareWasmReportsJson(reports_json: string): string;
export function compareWasmReportsObject(reports: any): any;
export function logZSeriesProbeObject(log_start: number, log_step: number, samples: Float32Array, window: string, normalisation: string, z_values: Float32Array, preview_len: number): any;
export function logZSeriesProbeJson(log_start: number, log_step: number, samples: Float32Array, window: string, normalisation: string, z_values: Float32Array, preview_len: number): string;
/**
 * Returns the native semantic contract version exposed by the browser client.
 */
export function autogradContractVersion(): string;
/**
 * Returns the crate that owns reverse-mode semantics.
 */
export function autogradSemanticOwner(): string;
export function zspacePeriodicityJson(request_json: string): string;
export function zspacePeriodicityObject(request: any): any;
export function validateZspacePeriodicityJson(report_json: string): string;
export function validateZspacePeriodicityObject(report: any): any;
export function toposRuntimeRouteJson(profile_json: string): string;
export function toposRuntimeRouteObject(profile: any): any;
export function tensorExecutionReceiptValidateJson(receipt_json: string): string;
export function tensorExecutionReceiptValidateObject(receipt: any): any;
export function tensorExecutionReceiptValidateAgainstRuntimePlanJson(receipt_json: string, runtime_plan_json: string): string;
export function tensorExecutionReceiptValidateAgainstRuntimePlanObject(receipt: any, runtime_plan: any): any;
export function zspaceStochasticSchrodingerComplexStepJson(request_json: string): string;
export function validateZspaceStochasticSchrodingerComplexJson(receipt_json: string): string;
export function rankPlanJson(request_json: string): string;
export function rankPlanObject(request: any): any;
export function zspaceFreeEnergyJson(request_json: string): string;
export function zspaceFreeEnergyObject(request: any): any;
export function auto_plan_fft(rows: number, cols: number, k: number, subgroup: boolean): WasmFftPlan | undefined;
export function auto_fft_wgsl(rows: number, cols: number, k: number, subgroup: boolean): string | undefined;
export function auto_fft_spiralk(rows: number, cols: number, k: number, subgroup: boolean): string | undefined;
export function auto_fft_plan_json(rows: number, cols: number, k: number, subgroup: boolean): string | undefined;
export function auto_fft_plan_object(rows: number, cols: number, k: number, subgroup: boolean): any;
export function fft_forward(buffer: Float32Array): Float32Array;
export function fft_inverse(buffer: Float32Array): Float32Array;
export function fft_forward_in_place(buffer: Float32Array): void;
export function fft_inverse_in_place(buffer: Float32Array): void;
/**
 * Compute the baseline WGPU choice without consulting an override table.
 */
export function baseChoice(rows: number, cols: number, k: number, subgroup: boolean): any;
export function available_palettes(): Array<any>;
export function mellin_exp_decay_samples(log_start: number, log_step: number, len: number): Float32Array;
export function mellin_exp_decay_samples_scaled(log_start: number, log_step: number, len: number, rate: number): Float32Array;
export function toposRoutePolicyEvaluateJson(request_json: string): string;
export function toposRoutePolicyEvaluateObject(request: any): any;
export function toposRoutePolicyRewardsJson(request_json: string): string;
export function toposRoutePolicyRewardsObject(request: any): any;
export function toposRoutePolicyResolveJson(request_json: string): string;
export function toposRoutePolicyResolveObject(request: any): any;
export function runtimeDeviceRouteJson(request_json: string): string;
export function runtimeDeviceRouteObject(request: any): any;
export function runtimeDeviceRouteFromProbesJson(request_json: string): string;
export function runtimeDeviceRouteFromProbesObject(request: any): any;
export function runtimeDeviceRouteValidateJson(payload_json: string): string;
export function runtimeDeviceRouteValidateObject(payload: any): any;
export function runtimeDeviceRouteValidateAgainstJson(payload_json: string, request_json: string): string;
export function runtimeDeviceRouteValidateAgainstObject(payload: any, request: any): any;
export function zspaceTelemetryFusionJson(payloads_json: string): string;
export function zspaceTelemetryFusionObject(payloads: any): any;
export function zspacePartialFusionJson(request_json: string): string;
export function zspacePartialFusionObject(request: any): any;
export function zspaceMetricGradientProjectionJson(request_json: string): string;
export function zspaceMetricGradientProjectionObject(request: any): any;
export function sealZspaceSemanticReviewPacketJson(request_json: string): string;
export function sealZspaceSemanticReviewPacketObject(request: any): any;
export function zspaceSemanticReviewMapIdJson(request_json: string): string;
export function zspaceSemanticReviewMapIdObject(request: any): string;
export function unblindZspaceSemanticReviewJson(request_json: string): string;
export function unblindZspaceSemanticReviewObject(request: any): any;
export function validateZspaceSemanticReviewUnblindJson(report_json: string): string;
export function validateZspaceSemanticReviewUnblindObject(report: any): any;
export function validateZspaceSemanticReviewPacketJson(packet_json: string): string;
export function validateZspaceSemanticReviewPacketObject(packet: any): any;
export function validateZspaceSemanticReviewPacketReceiptJson(receipt_json: string): string;
export function validateZspaceSemanticReviewPacketReceiptObject(receipt: any): any;
export function summarizeZspaceSemanticReviewDraftJson(request_json: string): string;
export function summarizeZspaceSemanticReviewDraftObject(request: any): any;
export function validateZspaceSemanticReviewDraftReceiptJson(receipt_json: string): string;
export function validateZspaceSemanticReviewDraftReceiptObject(receipt: any): any;
export function zspaceMetaOptimizerInitJson(config_json: string): string;
export function zspaceOptimizerFeedbackInitObject(config: any): any;
export function zspaceOptimizerFeedbackRestoreJson(request_json: string): string;
export function zspaceOptimizerFeedbackRestoreObject(request: any): any;
export function zspaceOptimizerFeedbackObserveJson(request_json: string): string;
export function zspaceOptimizerFeedbackObserveObject(request: any): any;
export function zspaceOptimizerFeedbackControlJson(request_json: string): string;
export function zspaceOptimizerFeedbackControlObject(request: any): any;
export function zspaceMetaOptimizerInitObject(config: any): any;
export function zspaceMetaOptimizerRestoreJson(request_json: string): string;
export function zspaceMetaOptimizerRestoreObject(request: any): any;
export function zspaceParameterTrajectoryPolicyJson(source_report_json: string, policy: string): string;
export function zspaceParameterTrajectoryPolicyObject(source_report: any, policy: string): any;
export function zspaceParameterTrajectoryPolicyValidateJson(report_json: string): string;
export function zspaceParameterTrajectoryPolicyValidateObject(report: any): any;
export function zspacePolarityEvidenceJson(request_json: string): string;
export function zspacePolarityEvidenceObject(request: any): any;
export function zspacePolarityEvidenceValidateJson(report_json: string): string;
export function zspacePolarityEvidenceValidateObject(report: any): any;
export function zspaceOptimizerFeedbackInitJson(config_json: string): string;
export function zspaceMetaOptimizerStepJson(request_json: string): string;
export function zspaceMetaOptimizerStepObject(request: any): any;
export function zspaceMetaOptimizerParameterControlJson(report_json: string): string;
export function zspaceMetaOptimizerParameterControlObject(report: any): any;
export function zspaceParameterTrajectoryJson(request_json: string): string;
export function zspaceParameterTrajectoryObject(request: any): any;
export function zspaceParameterTrajectoryValidateJson(report_json: string): string;
export function zspaceParameterTrajectoryValidateObject(report: any): any;
export function zspacePosteriorDecodeJson(request_json: string): string;
export function zspacePosteriorDecodeObject(request: any): any;
export function zspacePosteriorProjectJson(request_json: string): string;
export function zspacePosteriorProjectObject(request: any): any;
export function zspaceConceptDiffusionJson(request_json: string): string;
export function zspaceConceptDiffusionObject(request: any): any;
export function zspaceGenerationControlJson(request_json: string): string;
export function zspaceGenerationControlObject(request: any): any;
export function zspaceTemperatureControlJson(request_json: string): string;
export function zspaceTemperatureControlObject(request: any): any;
export function trainingTelemetryProjectionJson(request_json: string): string;
export function trainingTelemetryProjectionObject(request: any): any;
export function zspaceRuntimeProtocolCatalogJson(): string;
export function zspaceRuntimeProtocolCatalogObject(): any;
export function validateZspaceRuntimeProtocolCatalogJson(catalog_json: string): string;
export function zspaceImaginaryTimeSchrodingerJson(request_json: string): string;
export function zspaceImaginaryTimeSchrodingerObject(request: any): any;
export function scalarScaleStackProbeObject(field: Float32Array, shape: Uint32Array, scales: Float32Array, threshold: number, ambient_dim: number, dimension_window: number, levels: Float32Array): any;
export function scalarScaleStackProbeJson(field: Float32Array, shape: Uint32Array, scales: Float32Array, threshold: number, ambient_dim: number, dimension_window: number, levels: Float32Array): string;
export function semanticScaleStackProbeObject(embeddings: Float32Array, rows: number, dims: number, scales: Float32Array, threshold: number, metric: string, ambient_dim: number, dimension_window: number, levels: Float32Array): any;
export function semanticScaleStackProbeJson(embeddings: Float32Array, rows: number, dims: number, scales: Float32Array, threshold: number, metric: string, ambient_dim: number, dimension_window: number, levels: Float32Array): string;
export function trainerExternalStateCheckpointJson(checkpoint_json: string): string;
export function trainerExternalStateCheckpointObject(checkpoint: any): any;
export function zspaceCoherenceProjectJson(request_json: string): string;
export function zspaceCoherenceProjectObject(request: any): any;
export function zspaceCoherenceDistributionWitnessJson(normalized_weights_json: string): string;
export function zspaceCoherenceDistributionWitnessObject(normalized_weights: any): any;
export function zspaceCoherenceDistributionValidateJson(witness_json: string): string;
export function zspaceCoherenceDistributionValidateObject(witness: any): any;
export function trainerOptimizerConfigJson(config_json: string): string;
export function trainerOptimizerConfigObject(config: any): any;
export function trainerOptimizerCheckpointJson(checkpoint_json: string): string;
export function trainerOptimizerCheckpointObject(checkpoint: any): any;
export function trainerRuntimeCheckpointBundleJson(bundle_json: string): string;
export function trainerRuntimeCheckpointBundleObject(bundle: any): any;
export function zspaceRepetitionUnlikelihoodPlanJson(request_json: string): string;
export function zspaceRepetitionUnlikelihoodPlanObject(request: any): any;
export function validateZspaceRepetitionUnlikelihoodPlanJson(plan_json: string): string;
export function validateZspaceRepetitionUnlikelihoodPlanObject(plan: any): any;
export function apiLlmRoutePolicyEvaluateJson(request_json: string): string;
export function apiLlmRoutePolicyEvaluateObject(request: any): any;
export function zspaceGenerationEvidenceJson(request_json: string): string;
export function zspaceGenerationEvidenceObject(request: any): any;
export function validateZspaceGenerationEvidenceJson(report_json: string): string;
export function validateZspaceGenerationEvidenceObject(report: any): any;
export enum WasmFftPlanSource {
  Override = 0,
  Heuristic = 1,
  Fallback = 2,
}
/**
 * Frozen RHS whose source graph and packed storage are both owned by Rust.
 */
export class AutogradPackedRhs {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  requiresGrad(): boolean;
  cols(): number;
  rows(): number;
  sourceId(): string;
}
/**
 * Plain CPU SGD with fresh immutable parameter handles after every step.
 */
export class AutogradSgd {
  free(): void;
  [Symbol.dispose](): void;
  addParameter(parameter: AutogradTensor): number;
  learningRate(): number;
  parameterCount(): number;
  setLearningRate(learning_rate: number): void;
  constructor(learning_rate: number);
  step(): void;
  parameter(index: number): AutogradTensor;
  zeroGrad(): void;
}
/**
 * Browser handle over the same immutable graph used by native Rust and Python.
 */
export class AutogradTensor {
  free(): void;
  [Symbol.dispose](): void;
  gatherRows(indices: any): AutogradTensor;
  prepackRhs(): AutogradPackedRhs;
  rowSoftmax(): AutogradTensor;
  hasGradient(): boolean;
  graphSummary(): any;
  requiresGrad(): boolean;
  operationName(): string;
  gradientValues(): Float32Array;
  rowLogSoftmax(): AutogradTensor;
  zeroGradGraph(): void;
  matmulPrepacked(rhs: AutogradPackedRhs): AutogradTensor;
  scatterAddRows(indices: any, output_rows: number): AutogradTensor;
  /**
   * Affine row LayerNorm; omitted epsilon defaults to 1e-5.
   */
  layerNormAffine(gamma: AutogradTensor, beta: AutogradTensor, epsilon?: number | null): AutogradTensor;
  backwardWithGrad(values: Float32Array): any;
  meanSquaredError(target: AutogradTensor): AutogradTensor;
  vectorJacobianProduct(input: AutogradTensor, values: Float32Array): Float32Array;
  /**
   * Integer-label logits loss. Optional arguments default to mean, -100 and zero smoothing.
   */
  crossEntropyWithLogits(labels: Int32Array, reduction?: string | null, ignore_index?: number | null, label_smoothing?: number | null): AutogradTensor;
  add(rhs: AutogradTensor): AutogradTensor;
  dot(rhs: AutogradTensor): AutogradTensor;
  constructor(rows: number, cols: number, values: Float32Array, requires_grad: boolean);
  sub(rhs: AutogradTensor): AutogradTensor;
  sum(): AutogradTensor;
  cols(): number;
  gelu(): AutogradTensor;
  item(): number;
  mean(): AutogradTensor;
  relu(): AutogradTensor;
  rows(): number;
  scale(factor: number): AutogradTensor;
  detach(): AutogradTensor;
  matmul(rhs: AutogradTensor): AutogradTensor;
  values(): Float32Array;
  addRow(bias: AutogradTensor): AutogradTensor;
  backward(): any;
  hadamard(rhs: AutogradTensor): AutogradTensor;
  id(): string;
  transpose(): AutogradTensor;
  zeroGrad(): void;
}
export class CanvasDesireControl {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  eventsMask(): number;
  eventLabels(): Array<any>;
  readonly clipFloor: number;
  readonly tuningGain: number;
  readonly clipCeiling: number;
  readonly operatorMix: number;
  readonly penaltyGain: number;
  readonly qualityBias: number;
  readonly qualityGain: number;
  readonly operatorGain: number;
  readonly targetEntropy: number;
  readonly observationGain: number;
  readonly temperatureSlew: number;
  readonly learningRateEta: number;
  readonly learningRateMax: number;
  readonly learningRateMin: number;
  readonly temperatureKappa: number;
  readonly learningRateSlew: number;
  readonly realLearningRateScale: number;
  readonly hyperLearningRateScale: number;
  readonly damping: number;
  readonly biasMix: number;
  readonly clipEma: number;
  readonly clipNorm: number;
}
export class CanvasDesireInterpretation {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly saturation: number;
  readonly penaltyGain: number;
  readonly realPressure: number;
  readonly hyperPressure: number;
  readonly observationGain: number;
  readonly balance: number;
  readonly biasMix: number;
  readonly stability: number;
}
export class CanvasFftLayout {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Total byte length required for the `FieldSample` storage buffer.
   */
  readonly fieldBytes: number;
  /**
   * Size in bytes of each vector field sample.
   */
  readonly fieldStride: number;
  /**
   * Byte length of the `CanvasFftParams` uniform buffer.
   */
  readonly uniformBytes: number;
  /**
   * Total byte length required for the FFT spectrum storage buffer.
   */
  readonly spectrumBytes: number;
  /**
   * Size in bytes of each FFT spectrum sample.
   */
  readonly spectrumStride: number;
}
export class CanvasFramePacket {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly saturation: number;
  readonly eventsMask: number;
  readonly operatorMix: number;
  readonly realgradRms: number;
  readonly hypergradRms: number;
  readonly operatorGain: number;
  readonly realgradCount: number;
  readonly hypergradCount: number;
  readonly realLearningRateScale: number;
  readonly hyperLearningRateScale: number;
  readonly field: Float32Array;
  readonly trail: Float32Array;
  readonly width: number;
  readonly height: number;
  readonly pixels: Uint8Array;
  readonly balance: number;
  readonly relation: Float32Array;
  readonly stability: number;
}
export class CanvasGradientSummary {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly realgradL1: number;
  readonly realgradL2: number;
  readonly hypergradL1: number;
  readonly hypergradL2: number;
  readonly realgradRms: number;
  readonly hypergradRms: number;
  readonly realgradLInf: number;
  readonly hypergradLInf: number;
  readonly realgradCount: number;
  readonly hypergradCount: number;
  readonly realgradMeanAbs: number;
  readonly hypergradMeanAbs: number;
}
export class CobolDispatchPlanner {
  free(): void;
  [Symbol.dispose](): void;
  cicsRoute(): any;
  clearRoute(): void;
  static fromObject(value: any): CobolDispatchPlanner;
  loadObject(value: any): void;
  setDataset(dataset?: string | null): void;
  setMqRoute(manager: string, queue: string, commit?: string | null): void;
  clearDataset(): void;
  toCobolStub(): string;
  addAnnotation(annotation: string): void;
  clearMetadata(): void;
  clearMqRoute(): void;
  mergeMetadata(metadata: any): void;
  setCicsRoute(transaction: string, program?: string | null, channel?: string | null): void;
  setCreatedAt(timestamp: string): void;
  toUint8Array(): Uint8Array;
  setDatasetLog(log?: boolean | null): void;
  clearCicsRoute(): void;
  clearInitiators(): void;
  resetCreatedAt(): void;
  setCoefficients(coefficients: Float32Array): void;
  setDatasetLike(like_dataset?: string | null): void;
  setDatasetType(dataset_type?: string | null): void;
  setDatasetUnit(unit?: string | null): void;
  toCobolPreview(): any;
  setDatasetReuse(reuse?: boolean | null): void;
  validationIssues(): Array<any>;
  setDatasetMember(member?: string | null): void;
  setDatasetVolume(volume?: string | null): void;
  addHumanInitiator(name: string, persona?: string | null, contact?: string | null, note?: string | null): void;
  addModelInitiator(name: string, revision?: string | null, persona?: string | null, note?: string | null): void;
  setNarratorConfig(curvature: number, temperature: number, encoder: string, locale?: string | null): void;
  setReleaseChannel(channel: string): void;
  coefficientsAsBytes(): Uint8Array;
  setDatasetBlockSize(block_size?: number | null): void;
  setDatasetDataClass(data_class?: string | null): void;
  setDatasetKeyLength(key_length?: number | null): void;
  setDatasetKeyOffset(key_offset?: number | null): void;
  setDatasetSpaceUnit(space_unit?: string | null): void;
  setDatasetUnitCount(unit_count?: number | null): void;
  setDatasetDisposition(disposition?: string | null): void;
  addAutomationInitiator(name: string, persona?: string | null, note?: string | null): void;
  setDatasetOrganization(organization?: string | null): void;
  setDatasetRecordFormat(record_format?: string | null): void;
  setDatasetRecordLength(record_length?: number | null): void;
  setDatasetReleaseSpace(release_space?: boolean | null): void;
  setDatasetSpacePrimary(space_primary?: number | null): void;
  setDatasetStorageClass(storage_class?: string | null): void;
  setDatasetEraseOnDelete(erase_on_delete?: boolean | null): void;
  setDatasetExpirationDate(expiration_date?: string | null): void;
  setDatasetSpaceSecondary(space_secondary?: number | null): void;
  setDatasetCatalogBehavior(catalog_behavior?: string | null): void;
  setDatasetDirectoryBlocks(directory_blocks?: number | null): void;
  setDatasetManagementClass(management_class?: string | null): void;
  setDatasetRetentionPeriod(retention_period?: number | null): void;
  setDatasetAverageRecordUnit(average_record_unit?: string | null): void;
  setDatasetControlIntervalSize(control_interval_size?: number | null): void;
  setDatasetShareOptionsCrossRegion(share_options_cross_region?: number | null): void;
  setDatasetShareOptionsCrossSystem(share_options_cross_system?: number | null): void;
  constructor(job_id: string, release_channel?: string | null);
  addTag(tag: string): void;
  toJson(): string;
  isValid(): boolean;
  mqRoute(): any;
  static fromJson(json: string): CobolDispatchPlanner;
  loadJson(json: string): void;
  toObject(): any;
  readonly createdAt: string;
}
export class FractalCanvas {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Push a new fractal relation patch into the scheduler.
   *
   * The input buffer must contain `width * height` values laid out in row-major
   * order.
   */
  push_patch(relation: Float32Array, coherence: number, tension: number, depth: number): void;
  /**
   * Switch the active colour palette.
   */
  set_palette(name: string): void;
  /**
   * Refresh the canvas once and return a compact packet with the current
   * RGBA pixels, relation tensor, colour field, hyperbolic trail, and
   * gradient-derived Desire signals. Use this when you want to drive
   * multiple visualisations (2D canvas, WebGPU trails, telemetry) without
   * re-rendering the canvas for each query.
   */
  framePacket(curvature: number): CanvasFramePacket;
  /**
   * Refresh the projector and expose the colour vector field as a `Float32Array`.
   */
  vector_field(): Float32Array;
  /**
   * Refresh the projector and emit the Euclidean gradient update for the
   * current canvas relation.
   */
  realgradWave(): Float32Array;
  /**
   * Refresh the projector and collapse the gradient summaries into Desire's
   * control packet, exposing precomputed gains and learning-rate scales.
   */
  desireControl(curvature: number): CanvasDesireControl;
  /**
   * Refresh the projector and emit the hypergradient-aligned update for the
   * current canvas relation.
   */
  hypergradWave(curvature: number): Float32Array;
  /**
   * Refresh the projector and emit the AR particle trail for the current
   * vector field. Each particle contributes `(x, y, z, energy, r, g, b)` so
   * WebGPU/WebXR callers can upload the buffer without additional packing.
   */
  emitWasmTrail(curvature: number): Float32Array;
  /**
   * Summarise the current canvas relation across both the hypergradient and
   * Euclidean tapes. The returned object exposes the common norms so callers
   * can monitor gradient stability without materialising the full buffers.
   */
  gradientSummary(curvature: number): CanvasGradientSummary;
  /**
   * Render the current scheduler state onto the provided HTML canvas.
   */
  render_to_canvas(canvas: HTMLCanvasElement): void;
  /**
   * Reset the internal normaliser so the next frame recomputes brightness ranges.
   */
  reset_normalizer(): void;
  /**
   * Refresh the projector and return the interleaved FFT spectrum for each
   * canvas row. Each frequency sample contributes eight floats (real/imag
   * pairs for energy + RGB chroma).
   */
  vectorFieldFft(inverse: boolean): Float32Array;
  /**
   * Refresh the projector and interpret the gradient health into Desire's
   * feedback coordinates.
   */
  desireInterpretation(curvature: number): CanvasDesireInterpretation;
  /**
   * Compute the Euclidean wave update against the current relation tensor
   * without refreshing the canvas first.
   */
  realgradWaveCurrent(): Float32Array;
  /**
   * Refresh the projector, derive Desire's control packet, and pack it into
   * a WGSL-friendly uniform layout. The returned `Uint32Array` holds the raw
   * IEEE-754 bits so callers can reinterpret the underlying buffer as a
   * `Float32Array` when uploading to WebGPU.
   */
  desireControlUniform(curvature: number): Uint32Array;
  /**
   * Compute the hypergradient wave update against the current relation
   * tensor without refreshing the canvas first. Use `framePacket()` or
   * `render_to_canvas()` to refresh the internal state before calling this.
   */
  hypergradWaveCurrent(curvature: number): Float32Array;
  /**
   * Emit the WGSL kernel that mirrors [`vector_field_fft`] so WebGPU
   * consumers can reproduce the spectral pass directly on the GPU.
   */
  vectorFieldFftKernel(subgroup: boolean): string;
  /**
   * Byte layout metadata mirroring the WGSL `FieldSample`, `SpectrumSample`
   * and uniform structs so WebGPU callers can size buffers without manual
   * calculations.
   */
  vectorFieldFftLayout(): CanvasFftLayout;
  /**
   * Generate the uniform parameters expected by [`vector_field_fft_kernel`].
   *
   * The returned array packs the canvas `width`, `height`, the `inverse`
   * flag (1 = inverse, 0 = forward) and a padding slot so the buffer aligns
   * to 16 bytes as required by WGSL uniform layout rules.
   */
  vectorFieldFftUniform(inverse: boolean): Uint32Array;
  /**
   * Emit the WGSL kernel that accumulates the relation tensor directly into
   * a hypergradient buffer without leaving the GPU.
   */
  hypergradOperatorKernel(subgroup: boolean): string;
  /**
   * Compute the workgroup dispatch dimensions that pair with
   * [`vector_field_fft_kernel`]. The returned `[x, y, z]` triplet already
   * accounts for the workgroup size when toggling subgroup execution.
   */
  vectorFieldFftDispatch(subgroup: boolean): Uint32Array;
  /**
   * Uniform parameters (width, height, blend, gain) consumed by the
   * hypergradient WGSL operator.
   */
  hypergradOperatorUniform(mix: number, gain: number): Float32Array;
  /**
   * Workgroup dispatch dimensions matching `hypergradOperatorKernel`.
   */
  hypergradOperatorDispatch(subgroup: boolean): Uint32Array;
  /**
   * Refresh the canvas, derive the Desire control packet, and emit the
   * matching hypergradient operator uniform in a single step.
   */
  hypergradOperatorUniformAuto(curvature: number): Float32Array;
  /**
   * Compute the hypergradient operator uniform directly from the current
   * Desire control packet. Useful when the control data is computed once on
   * the Rust side and then cached in JavaScript.
   */
  hypergradOperatorUniformFromControl(control: CanvasDesireControl): Float32Array;
  /**
   * Construct a projector-backed canvas with the requested queue capacity.
   */
  constructor(capacity: number, width: number, height: number);
  /**
   * Refresh the projector and return a view of the RGBA buffer as a typed array.
   */
  pixels(): Uint8Array;
  /**
   * Current palette name.
   */
  palette(): string;
  /**
   * Refresh the projector and expose the raw relation tensor feeding the canvas.
   */
  relation(): Float32Array;
  /**
   * Canvas width in pixels.
   */
  readonly width: number;
  /**
   * Canvas height in pixels.
   */
  readonly height: number;
}
export class GraphForward {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  predictionTensor(): WgpuTensor;
  readonly inputGeneration: bigint;
  readonly submittedForward: bigint;
}
export class GraphGradientBatch {
  free(): void;
  [Symbol.dispose](): void;
  add(gradients: GraphGradients, weight: number): void;
  constructor();
  readonly length: number;
}
export class GraphGradients {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  inputGradientTensor(): WgpuTensor;
  parameterGradientTensor(index: number): WgpuTensor;
  readonly parameterCount: number;
  readonly inputGeneration: bigint;
  readonly submittedForward: bigint;
  readonly submittedBackward: bigint;
}
export class GraphInferenceSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readValues(): Promise<Float32Array>;
  readonly generation: bigint;
  readonly submittedDispatch: bigint;
  readonly shape: Uint32Array;
}
export class GraphTrainingParametersSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readPlan(): Promise<InferencePlan>;
}
export class GraphTrainingSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readState(): Promise<GraphTrainingState>;
  readonly inputShape: Uint32Array;
  readonly outputShape: Uint32Array;
  readonly submittedStep: bigint;
  readonly gradientPolicy: string;
  readonly batchGeneration: bigint;
}
export class GraphTrainingState {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  parameterRole(parameter: number): string;
  parameterShape(parameter: number): Uint32Array;
  parameterValues(parameter: number): Float32Array;
  predictionValues(): Float32Array;
  inputGradientValues(): Float32Array;
  effectiveGradientValues(parameter: number): Float32Array;
  parameterGradientValues(parameter: number): Float32Array;
  /**
   * Weight-only v2 plan; runtime counters, batch and policy are not serialized.
   */
  toPlan(): InferencePlan;
  readonly inputShape: Uint32Array;
  readonly stageCount: number;
  readonly outputShape: Uint32Array;
  readonly submittedStep: bigint;
  readonly gradientPolicy: string;
  readonly parameterCount: number;
  readonly batchGeneration: bigint;
  readonly loss: number;
}
export class GraphUpdateSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  read(): Promise<bigint>;
  readonly inputGeneration: bigint;
  readonly submittedUpdate: bigint;
  readonly submittedForward: bigint;
}
export class InferencePlan {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  compileWebGpu(tile_mnk?: Array<any> | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentInference>;
  /**
   * Return a new Rust-fused plan; parameter IDs stay fixed, stage IDs may change.
   */
  fusePointwise(): InferencePlan;
  /**
   * Checked handoff to the original browser-owned Rust Module.
   */
  applyParametersTo(module: Sequential, updated: InferencePlan, optimizer_state?: string | null): number;
  compileGraphWebGpu(tile_mnk?: Array<any> | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentGraphInference>;
  compileTrainingWebGpu(tile_mnk?: Array<any> | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentTraining>;
  compileGraphLearnerWebGpu(gradient_policy: string, tile_mnk?: Array<any> | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentGraphLearner>;
  compileGraphAutogradWebGpu(tile_mnk?: Array<any> | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentGraphAutograd>;
  compileGraphTrainingWebGpu(gradient_policy: string, tile_mnk?: Array<any> | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentGraphTraining>;
  toJson(): string;
  static fromJson(payload: string, max_bytes?: number | null): InferencePlan;
  readonly inputShape: Uint32Array;
  readonly stageCount: number;
  readonly outputShape: Uint32Array;
  readonly sourceOperationCount: number;
  readonly isDense: boolean;
}
export class InferenceSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readValues(): Promise<Float32Array>;
  readonly generation: bigint;
  readonly shape: Uint32Array;
}
export class RankAdaptationSession {
  free(): void;
  [Symbol.dispose](): void;
  pendingSelectionId(): number | undefined;
  constructor(request: any);
  choose(): any;
  abandon(selection_id: number): any;
  observe(selection_id: number, elapsed_ms: number, correctness_passed: boolean): any;
  snapshot(): any;
}
export class ResidentForwardStats {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readonly compilations: bigint;
  readonly cacheHits: bigint;
  readonly submittedForwards: bigint;
}
export class ResidentGraphAutograd {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  adapterInfo(): { name: string; backend: string; device_type: string };
  tensorDevice(): WgpuTensorDevice;
  setInputTensor(input: WgpuTensor): void;
  upload(data: Float32Array): void;
  forward(): GraphForward;
  backward(forward: GraphForward, cotangent: WgpuTensor): GraphGradients;
  readonly inputShape: Uint32Array;
  readonly stageCount: number;
  readonly outputShape: Uint32Array;
  readonly parameterCount: number;
  readonly inputGeneration: bigint;
  readonly submittedForwards: bigint;
  readonly submittedBackwards: bigint;
}
export class ResidentGraphInference {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  adapterInfo(): { name: string; backend: string; device_type: string };
  outputTensor(): WgpuTensor;
  tensorDevice(): WgpuTensorDevice;
  forwardTensor(input: WgpuTensor): WgpuTensor;
  setInputTensor(input: WgpuTensor): void;
  forwardTensorSnapshot(input: WgpuTensor): WgpuTensorSnapshot;
  upload(data: Float32Array): void;
  dispatch(): bigint;
  snapshot(): GraphInferenceSnapshot;
  readonly generation: bigint;
  readonly inputShape: Uint32Array;
  readonly stageCount: number;
  readonly outputShape: Uint32Array;
  readonly parameterCount: number;
  readonly submittedDispatches: bigint;
}
export class ResidentGraphLearner {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  adapterInfo(): { name: string; backend: string; device_type: string };
  sgdWeighted(batch: GraphGradientBatch, rate: number): bigint;
  tensorDevice(): WgpuTensorDevice;
  updateSnapshot(): GraphUpdateSnapshot;
  setInputTensor(input: WgpuTensor): void;
  parameterSnapshot(): GraphTrainingParametersSnapshot;
  sgd(gradients: GraphGradients, rate: number): bigint;
  upload(input: Float32Array): void;
  forward(): GraphForward;
  backward(forward: GraphForward, cotangent: WgpuTensor): GraphGradients;
  readonly inputShape: Uint32Array;
  readonly stageCount: number;
  readonly outputShape: Uint32Array;
  readonly gradientPolicy: string;
  readonly parameterCount: number;
  readonly inputGeneration: bigint;
  readonly submittedUpdates: bigint;
  readonly submittedForwards: bigint;
  readonly submittedBackwards: bigint;
}
export class ResidentGraphTraining {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  adapterInfo(): { name: string; backend: string; device_type: string };
  uploadBatch(input: Float32Array, target: Float32Array): void;
  lossSnapshot(): TrainingLossSnapshot;
  stateSnapshot(): GraphTrainingSnapshot;
  predictionTensor(): WgpuTensor;
  parameterSnapshot(): GraphTrainingParametersSnapshot;
  uploadBatchTensors(input: WgpuTensor, target: WgpuTensor): void;
  inputGradientTensor(): WgpuTensor;
  /**
   * Enqueued attempt, not proof of acceptance. Read an owning loss/state snapshot.
   */
  step(learning_rate: number): bigint;
  readonly inputShape: Uint32Array;
  readonly stageCount: number;
  readonly outputShape: Uint32Array;
  readonly gradientPolicy: string;
  readonly parameterCount: number;
  readonly submittedSteps: bigint;
  readonly batchGeneration: bigint;
}
export class ResidentInference {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  adapterInfo(): { name: string; backend: string; device_type: string };
  tensorSnapshot(device: WgpuTensorDevice): WgpuTensor;
  setInputTensor(input: WgpuTensor): void;
  upload(values: Float32Array): void;
  dispatch(): bigint;
  snapshot(): InferenceSnapshot;
  readonly generation: bigint;
  readonly inputShape: Uint32Array;
  readonly stageCount: number;
  readonly outputShape: Uint32Array;
}
export class ResidentTraining {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  adapterInfo(): { name: string; backend: string; device_type: string };
  uploadBatch(input: Float32Array, target: Float32Array): void;
  lossSnapshot(): TrainingLossSnapshot;
  stateSnapshot(): TrainingSnapshot;
  parameterSnapshot(): TrainingParametersSnapshot;
  /**
   * Enqueued attempt, not proof of acceptance. Read the owning snapshot.
   */
  step(learning_rate: number): bigint;
  readonly inputShape: Uint32Array;
  readonly stageCount: number;
  readonly outputShape: Uint32Array;
  readonly submittedSteps: bigint;
  readonly batchGeneration: bigint;
}
export class ResolvedWasmFftPlan {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  static fromObject(value: any): ResolvedWasmFftPlan;
  toJson(): string;
  static fromJson(json: string): ResolvedWasmFftPlan;
  toObject(): any;
  readonly heuristicUsed: boolean;
  readonly overrideApplied: boolean;
  readonly plan: WasmFftPlan;
  readonly source: WasmFftPlanSource;
}
export class Sequential {
  free(): void;
  [Symbol.dispose](): void;
  addLinear(name: string, input_dim: number, output_dim: number): void;
  addScaler(name: string, gain: Float32Array): void;
  inferencePlan(shape: number[]): InferencePlan;
  /**
   * Submit the forward and terminal capture together; reading remains explicit.
   */
  forwardSnapshot(input: WgpuTensor): WgpuTensorSnapshot;
  residentCacheInfo(): ResidentForwardStats;
  clearResidentCache(): void;
  constructor();
  /**
   * GPU submission only. The output owns its capture; readback is explicit.
   */
  forward(input: WgpuTensor): WgpuTensor;
  addGelu(): void;
  addRelu(): void;
}
/**
 * A reusable batch in WASM linear memory, not GPU-resident storage.
 * Construction copies partial-major row-major f32 data once. Repeated means
 * execute the same ordered-f64 Rust reducer used by GoldenRetriever.
 */
export class TensorMeanBatch {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Returns a new Float32Array. No input buffer or earlier result is mutated.
   */
  meanScaled(scale: number): Float32Array;
  constructor(rows: number, cols: number, partial_count: number, data: Float32Array);
}
export class TrainingLossSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  read(): Promise<number>;
  readonly submittedStep: bigint;
  readonly batchGeneration: bigint;
}
export class TrainingParametersSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readPlan(): Promise<InferencePlan>;
}
export class TrainingSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readState(): Promise<TrainingState>;
  readonly inputShape: Uint32Array;
  readonly outputShape: Uint32Array;
  readonly submittedStep: bigint;
  readonly batchGeneration: bigint;
}
export class TrainingState {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  biasValues(stage: number): Float32Array;
  layerShape(stage: number): Uint32Array;
  weightValues(stage: number): Float32Array;
  predictionValues(): Float32Array;
  biasGradientValues(stage: number): Float32Array;
  inputGradientValues(): Float32Array;
  weightGradientValues(stage: number): Float32Array;
  toPlan(): InferencePlan;
  readonly inputShape: Uint32Array;
  readonly stageCount: number;
  readonly outputShape: Uint32Array;
  readonly submittedStep: bigint;
  readonly batchGeneration: bigint;
  readonly loss: number;
}
export class WasmFftPlan {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Rebuild a plan from a plain JavaScript object with the same fields as [`toObject`].
   */
  static fromObject(value: any): WasmFftPlan;
  spiralkHint(): string;
  workgroupSize(): number;
  dispatchManifestJson(): string;
  dispatchManifestObject(): any;
  constructor(radix: number, tile_cols: number, segments: number, subgroup: boolean);
  wgsl(): string;
  /**
   * Serialise the plan into a JSON string so it can be persisted or sent over the network.
   */
  toJson(): string;
  /**
   * Rebuild a plan from a JSON string produced by [`toJson`].
   */
  static fromJson(json: string): WasmFftPlan;
  /**
   * Convert the plan into a plain JavaScript object with the same fields as [`toJson`].
   */
  toObject(): any;
  readonly radix: number;
  readonly segments: number;
  readonly subgroup: boolean;
  readonly tileCols: number;
}
export class WasmFractalFieldGenerator {
  free(): void;
  [Symbol.dispose](): void;
  probeJson(log_start: number, log_step: number, len: number, preview_len: number): string;
  probeObject(log_start: number, log_step: number, len: number, preview_len: number): any;
  branchingField(log_start: number, log_step: number, len: number): Float32Array;
  constructor(octaves: number, lacunarity: number, gain: number, iterations: number);
  readonly iterations: number;
  readonly lacunarity: number;
  readonly gain: number;
  readonly octaves: number;
}
export class WasmLogZSeries {
  free(): void;
  [Symbol.dispose](): void;
  evaluateZ(z: Float32Array): Float32Array;
  probeJson(z_values: Float32Array, preview_len: number): string;
  probeObject(z_values: Float32Array, preview_len: number): any;
  evaluateManyZ(z_values: Float32Array): Float32Array;
  len(): number;
  constructor(log_start: number, log_step: number, samples: Float32Array, window: string, normalisation: string);
  samples(): Float32Array;
  weights(): Float32Array;
  isEmpty(): boolean;
  readonly normalisation: string;
  readonly window: string;
  readonly logStep: number;
  readonly logStart: number;
}
export class WasmMellinEvalPlan {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  static verticalLine(log_start: number, log_step: number, real: number, imag_values: Float32Array): WasmMellinEvalPlan;
  len(): number;
  static many(log_start: number, log_step: number, s_values: Float32Array): WasmMellinEvalPlan;
  static mesh(log_start: number, log_step: number, real_values: Float32Array, imag_values: Float32Array): WasmMellinEvalPlan;
  shape(): Uint32Array;
  readonly logStep: number;
  readonly logStart: number;
}
export class WasmMellinLogGrid {
  free(): void;
  [Symbol.dispose](): void;
  hilbertNorm(): number;
  evaluateMany(s_values: Float32Array): Float32Array;
  evaluateMesh(real_values: Float32Array, imag_values: Float32Array): Float32Array;
  evaluatePlan(plan: WasmMellinEvalPlan): Float32Array;
  evaluateStable(s: Float32Array): Float32Array;
  static newWithWindow(log_start: number, log_step: number, samples: Float32Array, window: string, preserve_sum: boolean): WasmMellinLogGrid;
  weightedSeries(): Float32Array;
  static expDecayScaled(log_start: number, log_step: number, len: number, rate: number, window: string, preserve_sum: boolean): WasmMellinLogGrid;
  planVerticalLine(real: number, imag_values: Float32Array): WasmMellinEvalPlan;
  evaluateManyStable(s_values: Float32Array): Float32Array;
  evaluatePlanStable(plan: WasmMellinEvalPlan): Float32Array;
  hilbertInnerProduct(other: WasmMellinLogGrid): Float32Array;
  evaluateVerticalLine(real: number, imag_values: Float32Array): Float32Array;
  evaluateMeshMagnitude(real_values: Float32Array, imag_values: Float32Array): Float32Array;
  evaluatePlanMagnitude(plan: WasmMellinEvalPlan): Float32Array;
  evaluateWithDerivative(s: Float32Array): Array<any>;
  trainStepMatchGridPlan(plan: WasmMellinEvalPlan, target: WasmMellinLogGrid, lr: number): number;
  evaluateMeshLogMagnitude(real_values: Float32Array, imag_values: Float32Array, epsilon: number): Float32Array;
  evaluatePlanLogMagnitude(plan: WasmMellinEvalPlan, epsilon: number): Float32Array;
  evaluateManyWithDerivative(s_values: Float32Array): Array<any>;
  evaluatePlanWithDerivative(plan: WasmMellinEvalPlan): Array<any>;
  evaluateWithDerivativeStable(s: Float32Array): Array<any>;
  evaluateManyWithDerivativeStable(s_values: Float32Array): Array<any>;
  evaluatePlanWithDerivativeStable(plan: WasmMellinEvalPlan): Array<any>;
  len(): number;
  constructor(log_start: number, log_step: number, samples: Float32Array);
  samples(): Float32Array;
  support(): Float32Array;
  weights(): Float32Array;
  evaluate(s: Float32Array): Float32Array;
  isEmpty(): boolean;
  static expDecay(log_start: number, log_step: number, len: number, window: string, preserve_sum: boolean): WasmMellinLogGrid;
  planMany(s_values: Float32Array): WasmMellinEvalPlan;
  planMesh(real_values: Float32Array, imag_values: Float32Array): WasmMellinEvalPlan;
  readonly logStep: number;
  readonly logStart: number;
}
export class WasmScaleStack {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  persistence(): Float32Array;
  coherenceProfile(levels: Float32Array): Float32Array;
  interfaceDensity(): number | undefined;
  boundaryDimension(ambient_dim: number, window: number): number | undefined;
  coherenceBreakScale(level: number): number | undefined;
  moment(order: number): number;
  static scalar(field: Float32Array, shape: Uint32Array, scales: Float32Array, threshold: number): WasmScaleStack;
  samples(): Float32Array;
  toJson(ambient_dim: number, dimension_window: number, levels: Float32Array): string;
  static semantic(embeddings: Float32Array, rows: number, dims: number, scales: Float32Array, threshold: number, metric: string): WasmScaleStack;
  toObject(ambient_dim: number, dimension_window: number, levels: Float32Array): any;
  readonly sampleCount: number;
  readonly mode: string;
  readonly threshold: number;
}
export class WasmTuner {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Merge additional overrides from a JSON blob, keeping the ordering stable.
   */
  mergeJson(json: string): void;
  /**
   * Locate the first record matching the provided workload. Returns `undefined` when nothing matches.
   */
  findRecord(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Construct a tuner from a JavaScript array of records.
   */
  static fromObject(value: any): WasmTuner;
  /**
   * Replace the table contents with the provided array of records.
   */
  loadObject(value: any): void;
  /**
   * Merge additional overrides from a JavaScript array of records.
   */
  mergeObject(value: any): void;
  /**
   * Remove a record by index. Returns `undefined` for an out-of-bounds integer index.
   */
  removeIndex(index: number): any;
  /**
   * Produce a tuned FFT plan encoded as JSON when an override exists.
   */
  planFftJson(rows: number, cols: number, k: number, subgroup: boolean): string | undefined;
  /**
   * Remove the first record matching the workload. Returns `undefined` when nothing matched.
   */
  removeRecord(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Replace the record at the provided index. Returns `true` when the index existed.
   */
  replaceIndex(index: number, record: any): boolean;
  /**
   * Produce a tuned FFT plan encoded as a plain JavaScript object when an override exists.
   */
  planFftObject(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Resolve a tuned FFT plan and return a JSON-ready report describing how the plan was
   * assembled (override vs. heuristic vs. fallback).
   */
  planFftReport(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Resolve a tuned FFT plan and return metadata describing how the plan was
   * assembled (override vs. heuristic vs. fallback).
   */
  planFftResolution(rows: number, cols: number, k: number, subgroup: boolean): ResolvedWasmFftPlan;
  /**
   * Resolve a tuned FFT plan. Falls back to heuristics (or base device caps)
   * when no explicit override matches.
   */
  planFftWithFallback(rows: number, cols: number, k: number, subgroup: boolean): WasmFftPlan;
  /**
   * Resolve a tuned FFT plan and encode the metadata report as JSON.
   */
  planFftResolutionJson(rows: number, cols: number, k: number, subgroup: boolean): string;
  /**
   * Resolve a tuned FFT plan and encode the metadata report as a plain JavaScript object.
   */
  planFftResolutionObject(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Resolve a tuned FFT plan and encode it as JSON.
   */
  planFftWithFallbackJson(rows: number, cols: number, k: number, subgroup: boolean): string;
  /**
   * Resolve a tuned FFT plan and encode it as a plain JavaScript object.
   */
  planFftWithFallbackObject(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Number of records available in the table.
   */
  len(): number;
  /**
   * Construct a tuner table. Pass `None` to start from an empty dataset or a JSON string to seed it.
   */
  constructor(json?: string | null);
  /**
   * Append a new record represented as a JavaScript object.
   */
  push(record: any): void;
  /**
   * Clear every record from the table.
   */
  clear(): void;
  /**
   * Query the tuner for a given workload. Returns `undefined` when no override matches.
   */
  choose(rows: number, cols: number, k: number, subgroup: boolean): any;
  /**
   * Return the dataset as an array of JavaScript objects.
   */
  records(): any;
  /**
   * Return the internal dataset as a JSON string.
   */
  to_json(): string;
  /**
   * Returns `true` when no overrides are stored.
   */
  isEmpty(): boolean;
  /**
   * Produce a tuned FFT plan for the provided workload if an override exists.
   */
  planFft(rows: number, cols: number, k: number, subgroup: boolean): WasmFftPlan | undefined;
  /**
   * Replace the table contents with the provided JSON blob.
   */
  loadJson(json: string): void;
  /**
   * Retrieve a record by index. Returns `undefined` when the index is out of bounds.
   */
  recordAt(index: number): any;
  /**
   * Export the dataset into a JavaScript array of records.
   */
  toObject(): any;
}
/**
 * An explicit WebGPU workspace. It never falls back to WASM CPU tensor math.
 */
export class WgpuMatmul {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  static createWithTile(rows: number, inner: number, cols: number, tile_m: number, tile_n: number, tile_k: number): Promise<WgpuMatmul>;
  static createWithKernel(rows: number, inner: number, cols: number, tile_m: number, tile_n: number, tile_k: number, kernel: string): Promise<WgpuMatmul>;
  static createWithOptions(rows: number, inner: number, cols: number, tile_m: number, tile_n: number, tile_k: number, kernel: string, accumulation: string): Promise<WgpuMatmul>;
  static create(rows: number, inner: number, cols: number): Promise<WgpuMatmul>;
  uploadRhs(rhs: Float32Array): void;
  synchronize(): Promise<void>;
  adapterInfo(): any;
  setLhsFrom(source: WgpuMatmul): void;
  workgroupSize(): Uint32Array;
  outputsPerThread(): Uint32Array;
  shape(): Uint32Array;
  upload(lhs: Float32Array, rhs: Float32Array): void;
  /**
   * Repetitions are validated before any JS-to-u32 narrowing.
   */
  dispatch(repetitions?: number | null): bigint;
  /**
   * Snapshot synchronously, then await mapping without holding a JS object borrow.
   */
  readback(): Promise<Float32Array>;
  tileMNK(): Uint32Array;
  readonly generation: bigint;
  readonly accumulation: string;
  readonly outputIsCurrent: boolean;
  readonly kernel: string;
}
export class WgpuPointwiseInputs {
  free(): void;
  [Symbol.dispose](): void;
  add(tensor: WgpuTensor): void;
  constructor();
  set(slot: number, tensor: WgpuTensor): void;
  /**
   * JSON array of [operation, original-input-slot-or-null] pairs.
   */
  compile(steps: string): WgpuPointwisePlan;
  readonly length: number;
}
export class WgpuPointwisePlan {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  run(inputs: WgpuPointwiseInputs, execution: string): WgpuTensor;
}
/**
 * Exact rank workspace sharing Rust kernels, with no WASM CPU fallback.
 */
export class WgpuRank {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Construct from Rust-owned candidate geometry, without rebuilding the plan in JS.
   */
  static createFromAdaptation(session: RankAdaptationSession, candidate_index: number, timestamp_queries?: boolean | null): Promise<WgpuRank>;
  static create(kind: string, rows: number, cols: number, k: number, tile_cols?: number | null, timestamp_queries?: boolean | null): Promise<WgpuRank>;
  synchronize(): Promise<void>;
  adapterInfo(): any;
  dispatchFromMatmul(source: WgpuMatmul, repetitions?: number | null): bigint;
  setInputFromMatmul(source: WgpuMatmul): void;
  shape(): Uint32Array;
  upload(input: Float32Array): void;
  /**
   * The promise owns query storage; later uploads or freeing the workspace are safe.
   */
  profile(repetitions?: number | null): Promise<Record<string, unknown>>;
  dispatch(repetitions?: number | null): bigint;
  readback(): Promise<{values: Float32Array; indices: Int32Array; generation: bigint}>;
  readonly generation: bigint;
  readonly outputIsCurrent: boolean;
  readonly timestampQueriesEnabled: boolean;
  readonly kind: string;
  readonly tileCols: number;
}
export class WgpuTensor {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  contiguous(): WgpuTensor;
  broadcastTo(shape: number[]): WgpuTensor;
  sharesStorageWith(other: WgpuTensor): boolean;
  add(rhs: WgpuTensor): WgpuTensor;
  mul(rhs: WgpuTensor): WgpuTensor;
  gelu(): WgpuTensor;
  relu(): WgpuTensor;
  device(): WgpuTensorDevice;
  narrow(axis: number, start: number, length: number): WgpuTensor;
  permute(axes: number[]): WgpuTensor;
  reshape(shape: number[]): WgpuTensor;
  snapshot(): WgpuTensorSnapshot;
  readonly isContiguous: boolean;
  readonly numel: number;
  readonly shape: Uint32Array;
  readonly offset: number;
  readonly strides: Uint32Array;
}
export class WgpuTensorDevice {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  static create(): Promise<WgpuTensorDevice>;
  adapterInfo(): { name: string; backend: string; device_type: string };
  upload(shape: number[], data: Float32Array): WgpuTensor;
}
export class WgpuTensorSnapshot {
  private constructor();
  free(): void;
  [Symbol.dispose](): void;
  readValues(): Promise<Float32Array>;
  readonly shape: Uint32Array;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_inferenceplan_free: (a: number, b: number) => void;
  readonly __wbg_inferencesnapshot_free: (a: number, b: number) => void;
  readonly __wbg_residentinference_free: (a: number, b: number) => void;
  readonly __wbg_tensormeanbatch_free: (a: number, b: number) => void;
  readonly inferenceplan_applyParametersTo: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly inferenceplan_compileGraphAutogradWebGpu: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly inferenceplan_compileGraphLearnerWebGpu: (a: number, b: any, c: number, d: number, e: number) => [number, number, number];
  readonly inferenceplan_compileGraphTrainingWebGpu: (a: number, b: any, c: number, d: number, e: number) => [number, number, number];
  readonly inferenceplan_compileGraphWebGpu: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly inferenceplan_compileTrainingWebGpu: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly inferenceplan_compileWebGpu: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly inferenceplan_fromJson: (a: any, b: number) => [number, number, number];
  readonly inferenceplan_fusePointwise: (a: number) => [number, number, number];
  readonly inferenceplan_inputShape: (a: number) => [number, number];
  readonly inferenceplan_isDense: (a: number) => number;
  readonly inferenceplan_outputShape: (a: number) => [number, number];
  readonly inferenceplan_sourceOperationCount: (a: number) => number;
  readonly inferenceplan_stageCount: (a: number) => number;
  readonly inferenceplan_toJson: (a: number) => [number, number, number, number];
  readonly inferencesnapshot_generation: (a: number) => bigint;
  readonly inferencesnapshot_readValues: (a: number) => [number, number, number];
  readonly inferencesnapshot_shape: (a: number) => [number, number];
  readonly residentinference_adapterInfo: (a: number) => [number, number, number];
  readonly residentinference_dispatch: (a: number) => [bigint, number, number];
  readonly residentinference_generation: (a: number) => bigint;
  readonly residentinference_inputShape: (a: number) => [number, number];
  readonly residentinference_outputShape: (a: number) => [number, number];
  readonly residentinference_setInputTensor: (a: number, b: number) => [number, number];
  readonly residentinference_snapshot: (a: number) => [number, number, number];
  readonly residentinference_stageCount: (a: number) => number;
  readonly residentinference_tensorSnapshot: (a: number, b: number) => [number, number, number];
  readonly residentinference_upload: (a: number, b: any) => [number, number];
  readonly tensormeanbatch_meanScaled: (a: number, b: number) => [number, number, number, number];
  readonly tensormeanbatch_new: (a: any, b: any, c: any, d: number, e: number) => [number, number, number];
  readonly validateZspaceStochasticSchrodingerForwardJson: (a: any) => [number, number, number, number];
  readonly validateZspaceStochasticSchrodingerVjpJson: (a: any) => [number, number, number, number];
  readonly zspaceStochasticSchrodingerForwardJson: (a: any) => [number, number, number, number];
  readonly zspaceStochasticSchrodingerVjpJson: (a: any) => [number, number, number, number];
  readonly __wbg_wasmfractalfieldgenerator_free: (a: number, b: number) => void;
  readonly __wbg_wasmlogzseries_free: (a: number, b: number) => void;
  readonly auditWasmReportJson: (a: number, b: number) => [number, number, number, number];
  readonly auditWasmReportObject: (a: any) => [number, number, number];
  readonly compareWasmReportsJson: (a: number, b: number) => [number, number, number, number];
  readonly compareWasmReportsObject: (a: any) => [number, number, number];
  readonly fractalFieldProbeJson: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
  readonly fractalFieldProbeObject: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
  readonly logZSeriesProbeJson: (a: number, b: number, c: any, d: number, e: number, f: number, g: number, h: any, i: number) => [number, number, number, number];
  readonly logZSeriesProbeObject: (a: number, b: number, c: any, d: number, e: number, f: number, g: number, h: any, i: number) => [number, number, number];
  readonly runtimeDeviceProbeJson: (a: number, b: number) => [number, number, number, number];
  readonly runtimeDeviceProbeObject: (a: any) => [number, number, number];
  readonly runtimeDeviceProbeObserveJson: (a: number, b: number) => [number, number, number, number];
  readonly runtimeDeviceProbeObserveObject: (a: any) => [number, number, number];
  readonly runtimeDeviceProbeValidateAgainstJson: (a: number, b: number, c: number, d: number) => [number, number, number, number];
  readonly runtimeDeviceProbeValidateAgainstObject: (a: any, b: any) => [number, number, number];
  readonly runtimeDeviceProbeValidateJson: (a: number, b: number) => [number, number, number, number];
  readonly runtimeDeviceProbeValidateObject: (a: any) => [number, number, number];
  readonly runtimeExecutionPlanJson: (a: number, b: number) => [number, number, number, number];
  readonly runtimeExecutionPlanObject: (a: any) => [number, number, number];
  readonly runtimeExecutionPlanObserveCapabilitiesJson: (a: number, b: number) => [number, number, number, number];
  readonly runtimeExecutionPlanObserveCapabilitiesObject: (a: any) => [number, number, number];
  readonly runtimeExecutionPlanValidateAgainstJson: (a: number, b: number, c: number, d: number) => [number, number, number, number];
  readonly runtimeExecutionPlanValidateAgainstObject: (a: any, b: any) => [number, number, number];
  readonly runtimeExecutionPlanValidateJson: (a: number, b: number) => [number, number, number, number];
  readonly runtimeExecutionPlanValidateObject: (a: any) => [number, number, number];
  readonly toposControlSignalJson: (a: number, b: number) => [number, number, number, number];
  readonly toposControlSignalObject: (a: any) => [number, number, number];
  readonly toposOptimizerSnapshotJson: (a: number, b: number) => [number, number, number, number];
  readonly toposOptimizerSnapshotObject: (a: any) => [number, number, number];
  readonly toposZSpaceProjectionJson: (a: number, b: number, c: number) => [number, number, number, number];
  readonly toposZSpaceProjectionObject: (a: any, b: number) => [number, number, number];
  readonly wasmfractalfieldgenerator_branchingField: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly wasmfractalfieldgenerator_gain: (a: number) => number;
  readonly wasmfractalfieldgenerator_iterations: (a: number) => number;
  readonly wasmfractalfieldgenerator_lacunarity: (a: number) => number;
  readonly wasmfractalfieldgenerator_new: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly wasmfractalfieldgenerator_octaves: (a: number) => number;
  readonly wasmfractalfieldgenerator_probeJson: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
  readonly wasmfractalfieldgenerator_probeObject: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
  readonly wasmlogzseries_evaluateManyZ: (a: number, b: any) => [number, number, number];
  readonly wasmlogzseries_evaluateZ: (a: number, b: any) => [number, number, number];
  readonly wasmlogzseries_isEmpty: (a: number) => number;
  readonly wasmlogzseries_len: (a: number) => number;
  readonly wasmlogzseries_logStart: (a: number) => number;
  readonly wasmlogzseries_logStep: (a: number) => number;
  readonly wasmlogzseries_new: (a: number, b: number, c: any, d: number, e: number, f: number, g: number) => [number, number, number];
  readonly wasmlogzseries_normalisation: (a: number) => [number, number];
  readonly wasmlogzseries_probeJson: (a: number, b: any, c: number) => [number, number, number, number];
  readonly wasmlogzseries_probeObject: (a: number, b: any, c: number) => [number, number, number];
  readonly wasmlogzseries_samples: (a: number) => any;
  readonly wasmlogzseries_weights: (a: number) => any;
  readonly wasmlogzseries_window: (a: number) => [number, number];
  readonly __wbg_wgputensor_free: (a: number, b: number) => void;
  readonly __wbg_wgputensordevice_free: (a: number, b: number) => void;
  readonly __wbg_wgputensorsnapshot_free: (a: number, b: number) => void;
  readonly wgputensor_add: (a: number, b: number) => [number, number, number];
  readonly wgputensor_broadcastTo: (a: number, b: any) => [number, number, number];
  readonly wgputensor_contiguous: (a: number) => [number, number, number];
  readonly wgputensor_device: (a: number) => number;
  readonly wgputensor_gelu: (a: number) => [number, number, number];
  readonly wgputensor_isContiguous: (a: number) => number;
  readonly wgputensor_mul: (a: number, b: number) => [number, number, number];
  readonly wgputensor_narrow: (a: number, b: any, c: any, d: any) => [number, number, number];
  readonly wgputensor_numel: (a: number) => number;
  readonly wgputensor_offset: (a: number) => number;
  readonly wgputensor_permute: (a: number, b: any) => [number, number, number];
  readonly wgputensor_relu: (a: number) => [number, number, number];
  readonly wgputensor_reshape: (a: number, b: any) => [number, number, number];
  readonly wgputensor_shape: (a: number) => [number, number];
  readonly wgputensor_sharesStorageWith: (a: number, b: number) => number;
  readonly wgputensor_snapshot: (a: number) => [number, number, number];
  readonly wgputensor_strides: (a: number) => [number, number];
  readonly wgputensordevice_adapterInfo: (a: number) => [number, number, number];
  readonly wgputensordevice_create: () => any;
  readonly wgputensordevice_upload: (a: number, b: any, c: any) => [number, number, number];
  readonly wgputensorsnapshot_readValues: (a: number) => [number, number, number];
  readonly wgputensorsnapshot_shape: (a: number) => [number, number];
  readonly __wbg_autogradpackedrhs_free: (a: number, b: number) => void;
  readonly __wbg_autogradsgd_free: (a: number, b: number) => void;
  readonly __wbg_autogradtensor_free: (a: number, b: number) => void;
  readonly __wbg_graphforward_free: (a: number, b: number) => void;
  readonly __wbg_graphgradients_free: (a: number, b: number) => void;
  readonly __wbg_graphtrainingparameterssnapshot_free: (a: number, b: number) => void;
  readonly __wbg_graphtrainingsnapshot_free: (a: number, b: number) => void;
  readonly __wbg_graphtrainingstate_free: (a: number, b: number) => void;
  readonly __wbg_residentgraphautograd_free: (a: number, b: number) => void;
  readonly __wbg_residentgraphtraining_free: (a: number, b: number) => void;
  readonly autogradContractVersion: () => [number, number];
  readonly autogradSemanticOwner: () => [number, number];
  readonly autogradpackedrhs_cols: (a: number) => number;
  readonly autogradpackedrhs_requiresGrad: (a: number) => number;
  readonly autogradpackedrhs_rows: (a: number) => number;
  readonly autogradpackedrhs_sourceId: (a: number) => [number, number];
  readonly autogradsgd_addParameter: (a: number, b: number) => [number, number, number];
  readonly autogradsgd_learningRate: (a: number) => number;
  readonly autogradsgd_new: (a: number) => [number, number, number];
  readonly autogradsgd_parameter: (a: number, b: any) => [number, number, number];
  readonly autogradsgd_parameterCount: (a: number) => number;
  readonly autogradsgd_setLearningRate: (a: number, b: number) => [number, number];
  readonly autogradsgd_step: (a: number) => [number, number];
  readonly autogradsgd_zeroGrad: (a: number) => void;
  readonly autogradtensor_add: (a: number, b: number) => [number, number, number];
  readonly autogradtensor_addRow: (a: number, b: number) => [number, number, number];
  readonly autogradtensor_backward: (a: number) => [number, number, number];
  readonly autogradtensor_backwardWithGrad: (a: number, b: number, c: number) => [number, number, number];
  readonly autogradtensor_cols: (a: number) => number;
  readonly autogradtensor_crossEntropyWithLogits: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
  readonly autogradtensor_detach: (a: number) => [number, number, number];
  readonly autogradtensor_dot: (a: number, b: number) => [number, number, number];
  readonly autogradtensor_gatherRows: (a: number, b: any) => [number, number, number];
  readonly autogradtensor_gelu: (a: number) => [number, number, number];
  readonly autogradtensor_gradientValues: (a: number) => [number, number, number, number];
  readonly autogradtensor_graphSummary: (a: number) => [number, number, number];
  readonly autogradtensor_hadamard: (a: number, b: number) => [number, number, number];
  readonly autogradtensor_hasGradient: (a: number) => number;
  readonly autogradtensor_id: (a: number) => [number, number];
  readonly autogradtensor_item: (a: number) => [number, number, number];
  readonly autogradtensor_layerNormAffine: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly autogradtensor_matmul: (a: number, b: number) => [number, number, number];
  readonly autogradtensor_matmulPrepacked: (a: number, b: number) => [number, number, number];
  readonly autogradtensor_mean: (a: number) => [number, number, number];
  readonly autogradtensor_meanSquaredError: (a: number, b: number) => [number, number, number];
  readonly autogradtensor_new: (a: any, b: any, c: number, d: number, e: number) => [number, number, number];
  readonly autogradtensor_operationName: (a: number) => [number, number];
  readonly autogradtensor_prepackRhs: (a: number) => [number, number, number];
  readonly autogradtensor_relu: (a: number) => [number, number, number];
  readonly autogradtensor_requiresGrad: (a: number) => number;
  readonly autogradtensor_rowLogSoftmax: (a: number) => [number, number, number];
  readonly autogradtensor_rowSoftmax: (a: number) => [number, number, number];
  readonly autogradtensor_rows: (a: number) => number;
  readonly autogradtensor_scale: (a: number, b: number) => [number, number, number];
  readonly autogradtensor_scatterAddRows: (a: number, b: any, c: any) => [number, number, number];
  readonly autogradtensor_sub: (a: number, b: number) => [number, number, number];
  readonly autogradtensor_sum: (a: number) => [number, number, number];
  readonly autogradtensor_transpose: (a: number) => [number, number, number];
  readonly autogradtensor_values: (a: number) => [number, number];
  readonly autogradtensor_vectorJacobianProduct: (a: number, b: number, c: number, d: number) => [number, number, number, number];
  readonly autogradtensor_zeroGrad: (a: number) => void;
  readonly autogradtensor_zeroGradGraph: (a: number) => void;
  readonly graphforward_inputGeneration: (a: number) => bigint;
  readonly graphforward_predictionTensor: (a: number) => number;
  readonly graphforward_submittedForward: (a: number) => bigint;
  readonly graphgradients_inputGeneration: (a: number) => bigint;
  readonly graphgradients_inputGradientTensor: (a: number) => number;
  readonly graphgradients_parameterCount: (a: number) => number;
  readonly graphgradients_parameterGradientTensor: (a: number, b: any) => [number, number, number];
  readonly graphgradients_submittedBackward: (a: number) => bigint;
  readonly graphgradients_submittedForward: (a: number) => bigint;
  readonly graphtrainingparameterssnapshot_readPlan: (a: number) => [number, number, number];
  readonly graphtrainingsnapshot_batchGeneration: (a: number) => bigint;
  readonly graphtrainingsnapshot_gradientPolicy: (a: number) => [number, number];
  readonly graphtrainingsnapshot_inputShape: (a: number) => [number, number];
  readonly graphtrainingsnapshot_outputShape: (a: number) => [number, number];
  readonly graphtrainingsnapshot_readState: (a: number) => [number, number, number];
  readonly graphtrainingsnapshot_submittedStep: (a: number) => bigint;
  readonly graphtrainingstate_batchGeneration: (a: number) => bigint;
  readonly graphtrainingstate_effectiveGradientValues: (a: number, b: any) => [number, number, number];
  readonly graphtrainingstate_gradientPolicy: (a: number) => [number, number];
  readonly graphtrainingstate_inputGradientValues: (a: number) => any;
  readonly graphtrainingstate_inputShape: (a: number) => [number, number];
  readonly graphtrainingstate_loss: (a: number) => number;
  readonly graphtrainingstate_outputShape: (a: number) => [number, number];
  readonly graphtrainingstate_parameterCount: (a: number) => number;
  readonly graphtrainingstate_parameterGradientValues: (a: number, b: any) => [number, number, number];
  readonly graphtrainingstate_parameterRole: (a: number, b: any) => [number, number, number, number];
  readonly graphtrainingstate_parameterShape: (a: number, b: any) => [number, number, number, number];
  readonly graphtrainingstate_parameterValues: (a: number, b: any) => [number, number, number];
  readonly graphtrainingstate_predictionValues: (a: number) => any;
  readonly graphtrainingstate_stageCount: (a: number) => number;
  readonly graphtrainingstate_submittedStep: (a: number) => bigint;
  readonly graphtrainingstate_toPlan: (a: number) => [number, number, number];
  readonly residentgraphautograd_adapterInfo: (a: number) => [number, number, number];
  readonly residentgraphautograd_backward: (a: number, b: number, c: number) => [number, number, number];
  readonly residentgraphautograd_forward: (a: number) => [number, number, number];
  readonly residentgraphautograd_inputGeneration: (a: number) => bigint;
  readonly residentgraphautograd_inputShape: (a: number) => [number, number];
  readonly residentgraphautograd_outputShape: (a: number) => [number, number];
  readonly residentgraphautograd_parameterCount: (a: number) => number;
  readonly residentgraphautograd_setInputTensor: (a: number, b: number) => [number, number];
  readonly residentgraphautograd_stageCount: (a: number) => number;
  readonly residentgraphautograd_submittedBackwards: (a: number) => bigint;
  readonly residentgraphautograd_submittedForwards: (a: number) => bigint;
  readonly residentgraphautograd_tensorDevice: (a: number) => number;
  readonly residentgraphautograd_upload: (a: number, b: any) => [number, number];
  readonly residentgraphtraining_adapterInfo: (a: number) => [number, number, number];
  readonly residentgraphtraining_gradientPolicy: (a: number) => [number, number];
  readonly residentgraphtraining_inputGradientTensor: (a: number) => [number, number, number];
  readonly residentgraphtraining_inputShape: (a: number) => [number, number];
  readonly residentgraphtraining_lossSnapshot: (a: number) => [number, number, number];
  readonly residentgraphtraining_outputShape: (a: number) => [number, number];
  readonly residentgraphtraining_parameterSnapshot: (a: number) => [number, number, number];
  readonly residentgraphtraining_predictionTensor: (a: number) => [number, number, number];
  readonly residentgraphtraining_stateSnapshot: (a: number) => [number, number, number];
  readonly residentgraphtraining_step: (a: number, b: any) => [bigint, number, number];
  readonly residentgraphtraining_submittedSteps: (a: number) => bigint;
  readonly residentgraphtraining_uploadBatch: (a: number, b: any, c: any) => [number, number];
  readonly residentgraphtraining_uploadBatchTensors: (a: number, b: number, c: number) => [number, number];
  readonly residentgraphtraining_batchGeneration: (a: number) => bigint;
  readonly residentgraphtraining_parameterCount: (a: number) => number;
  readonly residentgraphtraining_stageCount: (a: number) => number;
  readonly __wbg_coboldispatchplanner_free: (a: number, b: number) => void;
  readonly coboldispatchplanner_addAnnotation: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_addAutomationInitiator: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
  readonly coboldispatchplanner_addHumanInitiator: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => void;
  readonly coboldispatchplanner_addModelInitiator: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => void;
  readonly coboldispatchplanner_addTag: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_cicsRoute: (a: number) => [number, number, number];
  readonly coboldispatchplanner_clearCicsRoute: (a: number) => void;
  readonly coboldispatchplanner_clearDataset: (a: number) => void;
  readonly coboldispatchplanner_clearInitiators: (a: number) => void;
  readonly coboldispatchplanner_clearMetadata: (a: number) => void;
  readonly coboldispatchplanner_clearMqRoute: (a: number) => void;
  readonly coboldispatchplanner_clearRoute: (a: number) => void;
  readonly coboldispatchplanner_coefficientsAsBytes: (a: number) => any;
  readonly coboldispatchplanner_createdAt: (a: number) => [number, number];
  readonly coboldispatchplanner_fromJson: (a: number, b: number) => [number, number, number];
  readonly coboldispatchplanner_fromObject: (a: any) => [number, number, number];
  readonly coboldispatchplanner_isValid: (a: number) => number;
  readonly coboldispatchplanner_loadJson: (a: number, b: number, c: number) => [number, number];
  readonly coboldispatchplanner_loadObject: (a: number, b: any) => [number, number];
  readonly coboldispatchplanner_mergeMetadata: (a: number, b: any) => [number, number];
  readonly coboldispatchplanner_mqRoute: (a: number) => [number, number, number];
  readonly coboldispatchplanner_new: (a: number, b: number, c: number, d: number) => number;
  readonly coboldispatchplanner_resetCreatedAt: (a: number) => void;
  readonly coboldispatchplanner_setCicsRoute: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
  readonly coboldispatchplanner_setCoefficients: (a: number, b: any) => void;
  readonly coboldispatchplanner_setCreatedAt: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDataset: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetAverageRecordUnit: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetBlockSize: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetCatalogBehavior: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetControlIntervalSize: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetDataClass: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetDirectoryBlocks: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetDisposition: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetEraseOnDelete: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetExpirationDate: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetKeyLength: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetKeyOffset: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetLike: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetLog: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetManagementClass: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetMember: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetOrganization: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetRecordFormat: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetRecordLength: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetReleaseSpace: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetRetentionPeriod: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetReuse: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetShareOptionsCrossRegion: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetShareOptionsCrossSystem: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetSpacePrimary: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetSpaceSecondary: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetSpaceUnit: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetStorageClass: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetType: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetUnit: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setDatasetUnitCount: (a: number, b: number) => void;
  readonly coboldispatchplanner_setDatasetVolume: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_setMqRoute: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
  readonly coboldispatchplanner_setNarratorConfig: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
  readonly coboldispatchplanner_setReleaseChannel: (a: number, b: number, c: number) => void;
  readonly coboldispatchplanner_toCobolPreview: (a: number) => [number, number, number];
  readonly coboldispatchplanner_toCobolStub: (a: number) => [number, number];
  readonly coboldispatchplanner_toJson: (a: number) => [number, number, number, number];
  readonly coboldispatchplanner_toObject: (a: number) => [number, number, number];
  readonly coboldispatchplanner_toUint8Array: (a: number) => [number, number, number];
  readonly coboldispatchplanner_validationIssues: (a: number) => any;
  readonly rankPlanJson: (a: number, b: number) => [number, number, number, number];
  readonly rankPlanObject: (a: any) => [number, number, number];
  readonly tensorExecutionReceiptValidateAgainstRuntimePlanJson: (a: number, b: number, c: number, d: number) => [number, number, number, number];
  readonly tensorExecutionReceiptValidateAgainstRuntimePlanObject: (a: any, b: any) => [number, number, number];
  readonly tensorExecutionReceiptValidateJson: (a: number, b: number) => [number, number, number, number];
  readonly tensorExecutionReceiptValidateObject: (a: any) => [number, number, number];
  readonly toposRuntimeRouteJson: (a: number, b: number) => [number, number, number, number];
  readonly toposRuntimeRouteObject: (a: any) => [number, number, number];
  readonly validateZspacePeriodicityJson: (a: any) => [number, number, number, number];
  readonly validateZspacePeriodicityObject: (a: any) => [number, number, number];
  readonly validateZspaceStochasticSchrodingerComplexJson: (a: any) => [number, number, number, number];
  readonly zspacePeriodicityJson: (a: any) => [number, number, number, number];
  readonly zspacePeriodicityObject: (a: any) => [number, number, number];
  readonly zspaceStochasticSchrodingerComplexStepJson: (a: any) => [number, number, number, number];
  readonly __wbg_canvasdesirecontrol_free: (a: number, b: number) => void;
  readonly __wbg_canvasdesireinterpretation_free: (a: number, b: number) => void;
  readonly __wbg_canvasfftlayout_free: (a: number, b: number) => void;
  readonly __wbg_canvasframepacket_free: (a: number, b: number) => void;
  readonly __wbg_canvasgradientsummary_free: (a: number, b: number) => void;
  readonly __wbg_fractalcanvas_free: (a: number, b: number) => void;
  readonly __wbg_resolvedwasmfftplan_free: (a: number, b: number) => void;
  readonly __wbg_wasmfftplan_free: (a: number, b: number) => void;
  readonly __wbg_wasmmellinevalplan_free: (a: number, b: number) => void;
  readonly __wbg_wasmmellinloggrid_free: (a: number, b: number) => void;
  readonly __wbg_wasmtuner_free: (a: number, b: number) => void;
  readonly auto_fft_plan_json: (a: number, b: number, c: number, d: number) => [number, number, number, number];
  readonly auto_fft_plan_object: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly auto_fft_spiralk: (a: number, b: number, c: number, d: number) => [number, number];
  readonly auto_fft_wgsl: (a: number, b: number, c: number, d: number) => [number, number];
  readonly auto_plan_fft: (a: number, b: number, c: number, d: number) => number;
  readonly available_palettes: () => any;
  readonly baseChoice: (a: any, b: any, c: any, d: number) => [number, number, number];
  readonly canvasdesirecontrol_biasMix: (a: number) => number;
  readonly canvasdesirecontrol_clipCeiling: (a: number) => number;
  readonly canvasdesirecontrol_clipEma: (a: number) => number;
  readonly canvasdesirecontrol_clipFloor: (a: number) => number;
  readonly canvasdesirecontrol_clipNorm: (a: number) => number;
  readonly canvasdesirecontrol_damping: (a: number) => number;
  readonly canvasdesirecontrol_eventLabels: (a: number) => any;
  readonly canvasdesirecontrol_eventsMask: (a: number) => number;
  readonly canvasdesirecontrol_hyperLearningRateScale: (a: number) => number;
  readonly canvasdesirecontrol_learningRateEta: (a: number) => number;
  readonly canvasdesirecontrol_learningRateMax: (a: number) => number;
  readonly canvasdesirecontrol_learningRateMin: (a: number) => number;
  readonly canvasdesirecontrol_learningRateSlew: (a: number) => number;
  readonly canvasdesirecontrol_observationGain: (a: number) => number;
  readonly canvasdesirecontrol_operatorGain: (a: number) => number;
  readonly canvasdesirecontrol_operatorMix: (a: number) => number;
  readonly canvasdesirecontrol_penaltyGain: (a: number) => number;
  readonly canvasdesirecontrol_qualityBias: (a: number) => number;
  readonly canvasdesirecontrol_qualityGain: (a: number) => number;
  readonly canvasdesirecontrol_realLearningRateScale: (a: number) => number;
  readonly canvasdesirecontrol_targetEntropy: (a: number) => number;
  readonly canvasdesirecontrol_temperatureKappa: (a: number) => number;
  readonly canvasdesirecontrol_temperatureSlew: (a: number) => number;
  readonly canvasdesirecontrol_tuningGain: (a: number) => number;
  readonly canvasfftlayout_fieldBytes: (a: number) => number;
  readonly canvasfftlayout_fieldStride: (a: number) => number;
  readonly canvasfftlayout_spectrumBytes: (a: number) => number;
  readonly canvasfftlayout_spectrumStride: (a: number) => number;
  readonly canvasfftlayout_uniformBytes: (a: number) => number;
  readonly canvasframepacket_eventsMask: (a: number) => number;
  readonly canvasframepacket_field: (a: number) => any;
  readonly canvasframepacket_hypergradCount: (a: number) => number;
  readonly canvasframepacket_pixels: (a: number) => any;
  readonly canvasframepacket_realgradCount: (a: number) => number;
  readonly canvasframepacket_relation: (a: number) => any;
  readonly canvasframepacket_trail: (a: number) => any;
  readonly canvasgradientsummary_hypergradCount: (a: number) => number;
  readonly canvasgradientsummary_realgradCount: (a: number) => number;
  readonly fft_forward: (a: any) => [number, number, number];
  readonly fft_forward_in_place: (a: any) => [number, number];
  readonly fft_inverse: (a: any) => [number, number, number];
  readonly fft_inverse_in_place: (a: any) => [number, number];
  readonly fractalcanvas_desireControl: (a: number, b: number) => [number, number, number];
  readonly fractalcanvas_desireControlUniform: (a: number, b: number) => [number, number, number];
  readonly fractalcanvas_desireInterpretation: (a: number, b: number) => [number, number, number];
  readonly fractalcanvas_emitWasmTrail: (a: number, b: number) => [number, number, number];
  readonly fractalcanvas_framePacket: (a: number, b: number) => [number, number, number];
  readonly fractalcanvas_gradientSummary: (a: number, b: number) => [number, number, number];
  readonly fractalcanvas_height: (a: number) => number;
  readonly fractalcanvas_hypergradOperatorDispatch: (a: number, b: number) => any;
  readonly fractalcanvas_hypergradOperatorKernel: (a: number, b: number) => [number, number];
  readonly fractalcanvas_hypergradOperatorUniform: (a: number, b: number, c: number) => any;
  readonly fractalcanvas_hypergradOperatorUniformAuto: (a: number, b: number) => [number, number, number];
  readonly fractalcanvas_hypergradOperatorUniformFromControl: (a: number, b: number) => any;
  readonly fractalcanvas_hypergradWave: (a: number, b: number) => [number, number, number];
  readonly fractalcanvas_hypergradWaveCurrent: (a: number, b: number) => [number, number, number];
  readonly fractalcanvas_new: (a: number, b: number, c: number) => [number, number, number];
  readonly fractalcanvas_palette: (a: number) => [number, number];
  readonly fractalcanvas_pixels: (a: number) => [number, number, number];
  readonly fractalcanvas_push_patch: (a: number, b: any, c: number, d: number, e: number) => [number, number];
  readonly fractalcanvas_realgradWave: (a: number) => [number, number, number];
  readonly fractalcanvas_realgradWaveCurrent: (a: number) => [number, number, number];
  readonly fractalcanvas_relation: (a: number) => [number, number, number];
  readonly fractalcanvas_render_to_canvas: (a: number, b: any) => [number, number];
  readonly fractalcanvas_reset_normalizer: (a: number) => void;
  readonly fractalcanvas_set_palette: (a: number, b: number, c: number) => [number, number];
  readonly fractalcanvas_vectorFieldFft: (a: number, b: number) => [number, number, number];
  readonly fractalcanvas_vectorFieldFftKernel: (a: number, b: number) => [number, number];
  readonly fractalcanvas_vectorFieldFftLayout: (a: number) => number;
  readonly fractalcanvas_vectorFieldFftUniform: (a: number, b: number) => any;
  readonly fractalcanvas_vector_field: (a: number) => [number, number, number];
  readonly fractalcanvas_width: (a: number) => number;
  readonly mellin_exp_decay_samples: (a: number, b: number, c: number) => [number, number, number];
  readonly mellin_exp_decay_samples_scaled: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly resolvedwasmfftplan_fromJson: (a: number, b: number) => [number, number, number];
  readonly resolvedwasmfftplan_fromObject: (a: any) => [number, number, number];
  readonly resolvedwasmfftplan_heuristicUsed: (a: number) => number;
  readonly resolvedwasmfftplan_overrideApplied: (a: number) => number;
  readonly resolvedwasmfftplan_plan: (a: number) => number;
  readonly resolvedwasmfftplan_source: (a: number) => number;
  readonly resolvedwasmfftplan_toJson: (a: number) => [number, number, number, number];
  readonly resolvedwasmfftplan_toObject: (a: number) => [number, number, number];
  readonly wasmfftplan_dispatchManifestJson: (a: number) => [number, number, number, number];
  readonly wasmfftplan_dispatchManifestObject: (a: number) => [number, number, number];
  readonly wasmfftplan_fromJson: (a: number, b: number) => [number, number, number];
  readonly wasmfftplan_fromObject: (a: any) => [number, number, number];
  readonly wasmfftplan_new: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly wasmfftplan_spiralkHint: (a: number) => [number, number];
  readonly wasmfftplan_subgroup: (a: number) => number;
  readonly wasmfftplan_toJson: (a: number) => [number, number, number, number];
  readonly wasmfftplan_toObject: (a: number) => [number, number, number];
  readonly wasmfftplan_wgsl: (a: number) => [number, number];
  readonly wasmfftplan_workgroupSize: (a: number) => number;
  readonly wasmmellinevalplan_len: (a: number) => number;
  readonly wasmmellinevalplan_many: (a: number, b: number, c: any) => [number, number, number];
  readonly wasmmellinevalplan_mesh: (a: number, b: number, c: any, d: any) => [number, number, number];
  readonly wasmmellinevalplan_shape: (a: number) => any;
  readonly wasmmellinevalplan_verticalLine: (a: number, b: number, c: number, d: any) => [number, number, number];
  readonly wasmmellinloggrid_evaluate: (a: number, b: any) => [number, number, number];
  readonly wasmmellinloggrid_evaluateMany: (a: number, b: any) => [number, number, number];
  readonly wasmmellinloggrid_evaluateManyStable: (a: number, b: any) => [number, number, number];
  readonly wasmmellinloggrid_evaluateManyWithDerivative: (a: number, b: any) => [number, number, number];
  readonly wasmmellinloggrid_evaluateManyWithDerivativeStable: (a: number, b: any) => [number, number, number];
  readonly wasmmellinloggrid_evaluateMesh: (a: number, b: any, c: any) => [number, number, number];
  readonly wasmmellinloggrid_evaluateMeshLogMagnitude: (a: number, b: any, c: any, d: number) => [number, number, number];
  readonly wasmmellinloggrid_evaluateMeshMagnitude: (a: number, b: any, c: any) => [number, number, number];
  readonly wasmmellinloggrid_evaluatePlan: (a: number, b: number) => [number, number, number];
  readonly wasmmellinloggrid_evaluatePlanLogMagnitude: (a: number, b: number, c: number) => [number, number, number];
  readonly wasmmellinloggrid_evaluatePlanMagnitude: (a: number, b: number) => [number, number, number];
  readonly wasmmellinloggrid_evaluatePlanStable: (a: number, b: number) => [number, number, number];
  readonly wasmmellinloggrid_evaluatePlanWithDerivative: (a: number, b: number) => [number, number, number];
  readonly wasmmellinloggrid_evaluatePlanWithDerivativeStable: (a: number, b: number) => [number, number, number];
  readonly wasmmellinloggrid_evaluateStable: (a: number, b: any) => [number, number, number];
  readonly wasmmellinloggrid_evaluateVerticalLine: (a: number, b: number, c: any) => [number, number, number];
  readonly wasmmellinloggrid_evaluateWithDerivative: (a: number, b: any) => [number, number, number];
  readonly wasmmellinloggrid_evaluateWithDerivativeStable: (a: number, b: any) => [number, number, number];
  readonly wasmmellinloggrid_expDecay: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
  readonly wasmmellinloggrid_expDecayScaled: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
  readonly wasmmellinloggrid_hilbertInnerProduct: (a: number, b: number) => [number, number, number];
  readonly wasmmellinloggrid_hilbertNorm: (a: number) => [number, number, number];
  readonly wasmmellinloggrid_isEmpty: (a: number) => number;
  readonly wasmmellinloggrid_len: (a: number) => number;
  readonly wasmmellinloggrid_new: (a: number, b: number, c: any) => [number, number, number];
  readonly wasmmellinloggrid_newWithWindow: (a: number, b: number, c: any, d: number, e: number, f: number) => [number, number, number];
  readonly wasmmellinloggrid_planMany: (a: number, b: any) => [number, number, number];
  readonly wasmmellinloggrid_planMesh: (a: number, b: any, c: any) => [number, number, number];
  readonly wasmmellinloggrid_planVerticalLine: (a: number, b: number, c: any) => [number, number, number];
  readonly wasmmellinloggrid_samples: (a: number) => any;
  readonly wasmmellinloggrid_support: (a: number) => any;
  readonly wasmmellinloggrid_trainStepMatchGridPlan: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly wasmmellinloggrid_weightedSeries: (a: number) => [number, number, number];
  readonly wasmmellinloggrid_weights: (a: number) => any;
  readonly wasmtuner_choose: (a: number, b: any, c: any, d: any, e: number) => [number, number, number];
  readonly wasmtuner_clear: (a: number) => void;
  readonly wasmtuner_findRecord: (a: number, b: any, c: any, d: any, e: number) => [number, number, number];
  readonly wasmtuner_fromObject: (a: any) => [number, number, number];
  readonly wasmtuner_isEmpty: (a: number) => number;
  readonly wasmtuner_len: (a: number) => number;
  readonly wasmtuner_loadJson: (a: number, b: number, c: number) => [number, number];
  readonly wasmtuner_loadObject: (a: number, b: any) => [number, number];
  readonly wasmtuner_mergeJson: (a: number, b: number, c: number) => [number, number];
  readonly wasmtuner_mergeObject: (a: number, b: any) => [number, number];
  readonly wasmtuner_new: (a: number, b: number) => [number, number, number];
  readonly wasmtuner_planFft: (a: number, b: any, c: any, d: any, e: number) => [number, number, number];
  readonly wasmtuner_planFftJson: (a: number, b: any, c: any, d: any, e: number) => [number, number, number, number];
  readonly wasmtuner_planFftObject: (a: number, b: any, c: any, d: any, e: number) => [number, number, number];
  readonly wasmtuner_planFftReport: (a: number, b: any, c: any, d: any, e: number) => [number, number, number];
  readonly wasmtuner_planFftResolution: (a: number, b: any, c: any, d: any, e: number) => [number, number, number];
  readonly wasmtuner_planFftResolutionJson: (a: number, b: any, c: any, d: any, e: number) => [number, number, number, number];
  readonly wasmtuner_planFftWithFallback: (a: number, b: any, c: any, d: any, e: number) => [number, number, number];
  readonly wasmtuner_planFftWithFallbackJson: (a: number, b: any, c: any, d: any, e: number) => [number, number, number, number];
  readonly wasmtuner_planFftWithFallbackObject: (a: number, b: any, c: any, d: any, e: number) => [number, number, number];
  readonly wasmtuner_push: (a: number, b: any) => [number, number];
  readonly wasmtuner_recordAt: (a: number, b: any) => [number, number, number];
  readonly wasmtuner_records: (a: number) => [number, number, number];
  readonly wasmtuner_removeIndex: (a: number, b: any) => [number, number, number];
  readonly wasmtuner_removeRecord: (a: number, b: any, c: any, d: any, e: number) => [number, number, number];
  readonly wasmtuner_replaceIndex: (a: number, b: any, c: any) => [number, number, number];
  readonly wasmtuner_toObject: (a: number) => [number, number, number];
  readonly wasmtuner_to_json: (a: number) => [number, number, number, number];
  readonly zspaceFreeEnergyJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceFreeEnergyObject: (a: any) => [number, number, number];
  readonly fractalcanvas_vectorFieldFftDispatch: (a: number, b: number) => any;
  readonly wasmtuner_planFftResolutionObject: (a: number, b: any, c: any, d: any, e: number) => [number, number, number];
  readonly canvasdesireinterpretation_balance: (a: number) => number;
  readonly canvasdesireinterpretation_biasMix: (a: number) => number;
  readonly canvasdesireinterpretation_hyperPressure: (a: number) => number;
  readonly canvasdesireinterpretation_observationGain: (a: number) => number;
  readonly canvasdesireinterpretation_penaltyGain: (a: number) => number;
  readonly canvasdesireinterpretation_realPressure: (a: number) => number;
  readonly canvasdesireinterpretation_saturation: (a: number) => number;
  readonly canvasdesireinterpretation_stability: (a: number) => number;
  readonly canvasframepacket_balance: (a: number) => number;
  readonly canvasframepacket_height: (a: number) => number;
  readonly canvasframepacket_hyperLearningRateScale: (a: number) => number;
  readonly canvasframepacket_hypergradRms: (a: number) => number;
  readonly canvasframepacket_operatorGain: (a: number) => number;
  readonly canvasframepacket_operatorMix: (a: number) => number;
  readonly canvasframepacket_realLearningRateScale: (a: number) => number;
  readonly canvasframepacket_realgradRms: (a: number) => number;
  readonly canvasframepacket_saturation: (a: number) => number;
  readonly canvasframepacket_stability: (a: number) => number;
  readonly canvasframepacket_width: (a: number) => number;
  readonly canvasgradientsummary_hypergradL1: (a: number) => number;
  readonly canvasgradientsummary_hypergradL2: (a: number) => number;
  readonly canvasgradientsummary_hypergradLInf: (a: number) => number;
  readonly canvasgradientsummary_hypergradMeanAbs: (a: number) => number;
  readonly canvasgradientsummary_hypergradRms: (a: number) => number;
  readonly canvasgradientsummary_realgradL1: (a: number) => number;
  readonly canvasgradientsummary_realgradL2: (a: number) => number;
  readonly canvasgradientsummary_realgradLInf: (a: number) => number;
  readonly canvasgradientsummary_realgradMeanAbs: (a: number) => number;
  readonly canvasgradientsummary_realgradRms: (a: number) => number;
  readonly wasmfftplan_radix: (a: number) => number;
  readonly wasmfftplan_segments: (a: number) => number;
  readonly wasmfftplan_tileCols: (a: number) => number;
  readonly wasmmellinevalplan_logStart: (a: number) => number;
  readonly wasmmellinevalplan_logStep: (a: number) => number;
  readonly wasmmellinloggrid_logStart: (a: number) => number;
  readonly wasmmellinloggrid_logStep: (a: number) => number;
  readonly runtimeDeviceRouteFromProbesJson: (a: number, b: number) => [number, number, number, number];
  readonly runtimeDeviceRouteFromProbesObject: (a: any) => [number, number, number];
  readonly runtimeDeviceRouteJson: (a: number, b: number) => [number, number, number, number];
  readonly runtimeDeviceRouteObject: (a: any) => [number, number, number];
  readonly runtimeDeviceRouteValidateAgainstJson: (a: number, b: number, c: number, d: number) => [number, number, number, number];
  readonly runtimeDeviceRouteValidateAgainstObject: (a: any, b: any) => [number, number, number];
  readonly runtimeDeviceRouteValidateJson: (a: number, b: number) => [number, number, number, number];
  readonly runtimeDeviceRouteValidateObject: (a: any) => [number, number, number];
  readonly sealZspaceSemanticReviewPacketJson: (a: any) => [number, number, number, number];
  readonly sealZspaceSemanticReviewPacketObject: (a: any) => [number, number, number];
  readonly summarizeZspaceSemanticReviewDraftJson: (a: any) => [number, number, number, number];
  readonly summarizeZspaceSemanticReviewDraftObject: (a: any) => [number, number, number];
  readonly toposRoutePolicyEvaluateJson: (a: number, b: number) => [number, number, number, number];
  readonly toposRoutePolicyEvaluateObject: (a: any) => [number, number, number];
  readonly toposRoutePolicyResolveJson: (a: number, b: number) => [number, number, number, number];
  readonly toposRoutePolicyResolveObject: (a: any) => [number, number, number];
  readonly toposRoutePolicyRewardsJson: (a: number, b: number) => [number, number, number, number];
  readonly toposRoutePolicyRewardsObject: (a: any) => [number, number, number];
  readonly trainingTelemetryProjectionJson: (a: number, b: number) => [number, number, number, number];
  readonly trainingTelemetryProjectionObject: (a: any) => [number, number, number];
  readonly unblindZspaceSemanticReviewJson: (a: any) => [number, number, number, number];
  readonly unblindZspaceSemanticReviewObject: (a: any) => [number, number, number];
  readonly validateZspaceRuntimeProtocolCatalogJson: (a: any) => [number, number, number, number];
  readonly validateZspaceSemanticReviewDraftReceiptJson: (a: any) => [number, number, number, number];
  readonly validateZspaceSemanticReviewDraftReceiptObject: (a: any) => [number, number, number];
  readonly validateZspaceSemanticReviewPacketJson: (a: any) => [number, number, number, number];
  readonly validateZspaceSemanticReviewPacketObject: (a: any) => [number, number, number];
  readonly validateZspaceSemanticReviewPacketReceiptJson: (a: any) => [number, number, number, number];
  readonly validateZspaceSemanticReviewPacketReceiptObject: (a: any) => [number, number, number];
  readonly validateZspaceSemanticReviewUnblindJson: (a: any) => [number, number, number, number];
  readonly validateZspaceSemanticReviewUnblindObject: (a: any) => [number, number, number];
  readonly zspaceConceptDiffusionJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceConceptDiffusionObject: (a: any) => [number, number, number];
  readonly zspaceGenerationControlJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceGenerationControlObject: (a: any) => [number, number, number];
  readonly zspaceImaginaryTimeSchrodingerJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceImaginaryTimeSchrodingerObject: (a: any) => [number, number, number];
  readonly zspaceMetaOptimizerInitJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceMetaOptimizerInitObject: (a: any) => [number, number, number];
  readonly zspaceMetaOptimizerParameterControlJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceMetaOptimizerParameterControlObject: (a: any) => [number, number, number];
  readonly zspaceMetaOptimizerRestoreJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceMetaOptimizerRestoreObject: (a: any) => [number, number, number];
  readonly zspaceMetaOptimizerStepJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceMetaOptimizerStepObject: (a: any) => [number, number, number];
  readonly zspaceMetricGradientProjectionJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceMetricGradientProjectionObject: (a: any) => [number, number, number];
  readonly zspaceOptimizerFeedbackControlJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceOptimizerFeedbackControlObject: (a: any) => [number, number, number];
  readonly zspaceOptimizerFeedbackInitJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceOptimizerFeedbackInitObject: (a: any) => [number, number, number];
  readonly zspaceOptimizerFeedbackObserveJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceOptimizerFeedbackObserveObject: (a: any) => [number, number, number];
  readonly zspaceOptimizerFeedbackRestoreJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceOptimizerFeedbackRestoreObject: (a: any) => [number, number, number];
  readonly zspaceParameterTrajectoryJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceParameterTrajectoryObject: (a: any) => [number, number, number];
  readonly zspaceParameterTrajectoryPolicyJson: (a: number, b: number, c: number, d: number) => [number, number, number, number];
  readonly zspaceParameterTrajectoryPolicyObject: (a: any, b: number, c: number) => [number, number, number];
  readonly zspaceParameterTrajectoryPolicyValidateJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceParameterTrajectoryPolicyValidateObject: (a: any) => [number, number, number];
  readonly zspaceParameterTrajectoryValidateJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceParameterTrajectoryValidateObject: (a: any) => [number, number, number];
  readonly zspacePartialFusionJson: (a: number, b: number) => [number, number, number, number];
  readonly zspacePartialFusionObject: (a: any) => [number, number, number];
  readonly zspacePolarityEvidenceJson: (a: number, b: number) => [number, number, number, number];
  readonly zspacePolarityEvidenceObject: (a: any) => [number, number, number];
  readonly zspacePolarityEvidenceValidateJson: (a: number, b: number) => [number, number, number, number];
  readonly zspacePolarityEvidenceValidateObject: (a: any) => [number, number, number];
  readonly zspacePosteriorDecodeJson: (a: number, b: number) => [number, number, number, number];
  readonly zspacePosteriorDecodeObject: (a: any) => [number, number, number];
  readonly zspacePosteriorProjectJson: (a: number, b: number) => [number, number, number, number];
  readonly zspacePosteriorProjectObject: (a: any) => [number, number, number];
  readonly zspaceRuntimeProtocolCatalogJson: () => [number, number, number, number];
  readonly zspaceRuntimeProtocolCatalogObject: () => [number, number, number];
  readonly zspaceSemanticReviewMapIdJson: (a: any) => [number, number, number, number];
  readonly zspaceSemanticReviewMapIdObject: (a: any) => [number, number, number, number];
  readonly zspaceTelemetryFusionJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceTelemetryFusionObject: (a: any) => [number, number, number];
  readonly zspaceTemperatureControlJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceTemperatureControlObject: (a: any) => [number, number, number];
  readonly __wbg_get_residentforwardstats_cacheHits: (a: number) => bigint;
  readonly __wbg_get_residentforwardstats_compilations: (a: number) => bigint;
  readonly __wbg_get_residentforwardstats_submittedForwards: (a: number) => bigint;
  readonly __wbg_graphgradientbatch_free: (a: number, b: number) => void;
  readonly __wbg_graphinferencesnapshot_free: (a: number, b: number) => void;
  readonly __wbg_graphupdatesnapshot_free: (a: number, b: number) => void;
  readonly __wbg_residentforwardstats_free: (a: number, b: number) => void;
  readonly __wbg_residentgraphinference_free: (a: number, b: number) => void;
  readonly __wbg_residentgraphlearner_free: (a: number, b: number) => void;
  readonly __wbg_residenttraining_free: (a: number, b: number) => void;
  readonly __wbg_sequential_free: (a: number, b: number) => void;
  readonly __wbg_traininglosssnapshot_free: (a: number, b: number) => void;
  readonly __wbg_trainingparameterssnapshot_free: (a: number, b: number) => void;
  readonly __wbg_trainingsnapshot_free: (a: number, b: number) => void;
  readonly __wbg_trainingstate_free: (a: number, b: number) => void;
  readonly __wbg_wgpupointwiseinputs_free: (a: number, b: number) => void;
  readonly __wbg_wgpupointwiseplan_free: (a: number, b: number) => void;
  readonly graphgradientbatch_add: (a: number, b: number, c: number) => [number, number];
  readonly graphgradientbatch_length: (a: number) => number;
  readonly graphgradientbatch_new: () => number;
  readonly graphinferencesnapshot_generation: (a: number) => bigint;
  readonly graphinferencesnapshot_readValues: (a: number) => [number, number, number];
  readonly graphinferencesnapshot_shape: (a: number) => [number, number];
  readonly graphinferencesnapshot_submittedDispatch: (a: number) => bigint;
  readonly graphupdatesnapshot_inputGeneration: (a: number) => bigint;
  readonly graphupdatesnapshot_read: (a: number) => [number, number, number];
  readonly graphupdatesnapshot_submittedForward: (a: number) => bigint;
  readonly graphupdatesnapshot_submittedUpdate: (a: number) => bigint;
  readonly residentgraphinference_adapterInfo: (a: number) => [number, number, number];
  readonly residentgraphinference_dispatch: (a: number) => [bigint, number, number];
  readonly residentgraphinference_forwardTensor: (a: number, b: number) => [number, number, number];
  readonly residentgraphinference_forwardTensorSnapshot: (a: number, b: number) => [number, number, number];
  readonly residentgraphinference_generation: (a: number) => bigint;
  readonly residentgraphinference_inputShape: (a: number) => [number, number];
  readonly residentgraphinference_outputShape: (a: number) => [number, number];
  readonly residentgraphinference_outputTensor: (a: number) => [number, number, number];
  readonly residentgraphinference_parameterCount: (a: number) => number;
  readonly residentgraphinference_setInputTensor: (a: number, b: number) => [number, number];
  readonly residentgraphinference_snapshot: (a: number) => [number, number, number];
  readonly residentgraphinference_stageCount: (a: number) => number;
  readonly residentgraphinference_submittedDispatches: (a: number) => bigint;
  readonly residentgraphinference_tensorDevice: (a: number) => number;
  readonly residentgraphinference_upload: (a: number, b: any) => [number, number];
  readonly residentgraphlearner_adapterInfo: (a: number) => [number, number, number];
  readonly residentgraphlearner_backward: (a: number, b: number, c: number) => [number, number, number];
  readonly residentgraphlearner_forward: (a: number) => [number, number, number];
  readonly residentgraphlearner_gradientPolicy: (a: number) => [number, number];
  readonly residentgraphlearner_inputGeneration: (a: number) => bigint;
  readonly residentgraphlearner_inputShape: (a: number) => [number, number];
  readonly residentgraphlearner_outputShape: (a: number) => [number, number];
  readonly residentgraphlearner_parameterCount: (a: number) => number;
  readonly residentgraphlearner_parameterSnapshot: (a: number) => [number, number, number];
  readonly residentgraphlearner_setInputTensor: (a: number, b: number) => [number, number];
  readonly residentgraphlearner_sgd: (a: number, b: number, c: number) => [bigint, number, number];
  readonly residentgraphlearner_sgdWeighted: (a: number, b: number, c: number) => [bigint, number, number];
  readonly residentgraphlearner_stageCount: (a: number) => number;
  readonly residentgraphlearner_submittedBackwards: (a: number) => bigint;
  readonly residentgraphlearner_submittedForwards: (a: number) => bigint;
  readonly residentgraphlearner_submittedUpdates: (a: number) => bigint;
  readonly residentgraphlearner_tensorDevice: (a: number) => number;
  readonly residentgraphlearner_updateSnapshot: (a: number) => [number, number, number];
  readonly residentgraphlearner_upload: (a: number, b: any) => [number, number];
  readonly residenttraining_adapterInfo: (a: number) => [number, number, number];
  readonly residenttraining_batchGeneration: (a: number) => bigint;
  readonly residenttraining_inputShape: (a: number) => [number, number];
  readonly residenttraining_lossSnapshot: (a: number) => [number, number, number];
  readonly residenttraining_outputShape: (a: number) => [number, number];
  readonly residenttraining_parameterSnapshot: (a: number) => [number, number, number];
  readonly residenttraining_stageCount: (a: number) => number;
  readonly residenttraining_stateSnapshot: (a: number) => [number, number, number];
  readonly residenttraining_step: (a: number, b: any) => [bigint, number, number];
  readonly residenttraining_submittedSteps: (a: number) => bigint;
  readonly residenttraining_uploadBatch: (a: number, b: any, c: any) => [number, number];
  readonly sequential_addGelu: (a: number) => void;
  readonly sequential_addLinear: (a: number, b: any, c: any, d: any) => [number, number];
  readonly sequential_addRelu: (a: number) => void;
  readonly sequential_addScaler: (a: number, b: any, c: any) => [number, number];
  readonly sequential_clearResidentCache: (a: number) => void;
  readonly sequential_forward: (a: number, b: number) => [number, number, number];
  readonly sequential_forwardSnapshot: (a: number, b: number) => [number, number, number];
  readonly sequential_inferencePlan: (a: number, b: any) => [number, number, number];
  readonly sequential_new: () => number;
  readonly sequential_residentCacheInfo: (a: number) => number;
  readonly traininglosssnapshot_read: (a: number) => [number, number, number];
  readonly traininglosssnapshot_submittedStep: (a: number) => bigint;
  readonly trainingparameterssnapshot_readPlan: (a: number) => [number, number, number];
  readonly trainingsnapshot_batchGeneration: (a: number) => bigint;
  readonly trainingsnapshot_inputShape: (a: number) => [number, number];
  readonly trainingsnapshot_outputShape: (a: number) => [number, number];
  readonly trainingsnapshot_readState: (a: number) => [number, number, number];
  readonly trainingsnapshot_submittedStep: (a: number) => bigint;
  readonly trainingstate_batchGeneration: (a: number) => bigint;
  readonly trainingstate_biasGradientValues: (a: number, b: any) => [number, number, number];
  readonly trainingstate_biasValues: (a: number, b: any) => [number, number, number];
  readonly trainingstate_inputGradientValues: (a: number) => any;
  readonly trainingstate_inputShape: (a: number) => [number, number];
  readonly trainingstate_layerShape: (a: number, b: any) => [number, number, number, number];
  readonly trainingstate_loss: (a: number) => number;
  readonly trainingstate_outputShape: (a: number) => [number, number];
  readonly trainingstate_predictionValues: (a: number) => any;
  readonly trainingstate_stageCount: (a: number) => number;
  readonly trainingstate_submittedStep: (a: number) => bigint;
  readonly trainingstate_toPlan: (a: number) => [number, number, number];
  readonly trainingstate_weightGradientValues: (a: number, b: any) => [number, number, number];
  readonly trainingstate_weightValues: (a: number, b: any) => [number, number, number];
  readonly wgpupointwiseinputs_add: (a: number, b: number) => [number, number];
  readonly wgpupointwiseinputs_compile: (a: number, b: number, c: number) => [number, number, number];
  readonly wgpupointwiseinputs_length: (a: number) => number;
  readonly wgpupointwiseinputs_new: () => number;
  readonly wgpupointwiseinputs_set: (a: number, b: any, c: number) => [number, number];
  readonly wgpupointwiseplan_run: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly traininglosssnapshot_batchGeneration: (a: number) => bigint;
  readonly __wbg_wasmscalestack_free: (a: number, b: number) => void;
  readonly scalarScaleStackProbeJson: (a: any, b: any, c: any, d: number, e: number, f: number, g: any) => [number, number, number, number];
  readonly scalarScaleStackProbeObject: (a: any, b: any, c: any, d: number, e: number, f: number, g: any) => [number, number, number];
  readonly semanticScaleStackProbeJson: (a: any, b: number, c: number, d: any, e: number, f: number, g: number, h: number, i: number, j: any) => [number, number, number, number];
  readonly semanticScaleStackProbeObject: (a: any, b: number, c: number, d: any, e: number, f: number, g: number, h: number, i: number, j: any) => [number, number, number];
  readonly trainerExternalStateCheckpointJson: (a: number, b: number) => [number, number, number, number];
  readonly trainerExternalStateCheckpointObject: (a: any) => [number, number, number];
  readonly trainerOptimizerCheckpointJson: (a: number, b: number) => [number, number, number, number];
  readonly trainerOptimizerCheckpointObject: (a: any) => [number, number, number];
  readonly trainerOptimizerConfigJson: (a: number, b: number) => [number, number, number, number];
  readonly trainerOptimizerConfigObject: (a: any) => [number, number, number];
  readonly trainerRuntimeCheckpointBundleJson: (a: number, b: number) => [number, number, number, number];
  readonly trainerRuntimeCheckpointBundleObject: (a: any) => [number, number, number];
  readonly validateZspaceRepetitionUnlikelihoodPlanJson: (a: any) => [number, number, number, number];
  readonly validateZspaceRepetitionUnlikelihoodPlanObject: (a: any) => [number, number, number];
  readonly wasmscalestack_boundaryDimension: (a: number, b: number, c: number) => [number, number];
  readonly wasmscalestack_coherenceBreakScale: (a: number, b: number) => [number, number];
  readonly wasmscalestack_coherenceProfile: (a: number, b: any) => any;
  readonly wasmscalestack_interfaceDensity: (a: number) => [number, number];
  readonly wasmscalestack_mode: (a: number) => [number, number];
  readonly wasmscalestack_moment: (a: number, b: number) => number;
  readonly wasmscalestack_persistence: (a: number) => any;
  readonly wasmscalestack_sampleCount: (a: number) => number;
  readonly wasmscalestack_samples: (a: number) => any;
  readonly wasmscalestack_scalar: (a: any, b: any, c: any, d: number) => [number, number, number];
  readonly wasmscalestack_semantic: (a: any, b: number, c: number, d: any, e: number, f: number, g: number) => [number, number, number];
  readonly wasmscalestack_threshold: (a: number) => number;
  readonly wasmscalestack_toJson: (a: number, b: number, c: number, d: any) => [number, number, number, number];
  readonly wasmscalestack_toObject: (a: number, b: number, c: number, d: any) => [number, number, number];
  readonly zspaceCoherenceDistributionValidateJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceCoherenceDistributionValidateObject: (a: any) => [number, number, number];
  readonly zspaceCoherenceDistributionWitnessJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceCoherenceDistributionWitnessObject: (a: any) => [number, number, number];
  readonly zspaceCoherenceProjectJson: (a: number, b: number) => [number, number, number, number];
  readonly zspaceCoherenceProjectObject: (a: any) => [number, number, number];
  readonly zspaceRepetitionUnlikelihoodPlanJson: (a: any) => [number, number, number, number];
  readonly zspaceRepetitionUnlikelihoodPlanObject: (a: any) => [number, number, number];
  readonly __wbg_rankadaptationsession_free: (a: number, b: number) => void;
  readonly __wbg_wgpumatmul_free: (a: number, b: number) => void;
  readonly __wbg_wgpurank_free: (a: number, b: number) => void;
  readonly apiLlmRoutePolicyEvaluateJson: (a: number, b: number) => [number, number, number, number];
  readonly apiLlmRoutePolicyEvaluateObject: (a: any) => [number, number, number];
  readonly rankadaptationsession_abandon: (a: number, b: number) => [number, number, number];
  readonly rankadaptationsession_choose: (a: number) => [number, number, number];
  readonly rankadaptationsession_new: (a: any) => [number, number, number];
  readonly rankadaptationsession_observe: (a: number, b: number, c: number, d: number) => [number, number, number];
  readonly rankadaptationsession_pendingSelectionId: (a: number) => [number, number];
  readonly rankadaptationsession_snapshot: (a: number) => [number, number, number];
  readonly validateZspaceGenerationEvidenceJson: (a: any) => [number, number, number, number];
  readonly validateZspaceGenerationEvidenceObject: (a: any) => [number, number, number];
  readonly wgpumatmul_accumulation: (a: number) => [number, number];
  readonly wgpumatmul_adapterInfo: (a: number) => [number, number, number];
  readonly wgpumatmul_create: (a: any, b: any, c: any) => any;
  readonly wgpumatmul_createWithKernel: (a: any, b: any, c: any, d: any, e: any, f: any, g: any) => any;
  readonly wgpumatmul_createWithOptions: (a: any, b: any, c: any, d: any, e: any, f: any, g: any, h: any) => any;
  readonly wgpumatmul_createWithTile: (a: any, b: any, c: any, d: any, e: any, f: any) => any;
  readonly wgpumatmul_dispatch: (a: number, b: number) => [bigint, number, number];
  readonly wgpumatmul_generation: (a: number) => bigint;
  readonly wgpumatmul_kernel: (a: number) => [number, number];
  readonly wgpumatmul_outputIsCurrent: (a: number) => number;
  readonly wgpumatmul_outputsPerThread: (a: number) => [number, number];
  readonly wgpumatmul_readback: (a: number) => [number, number, number];
  readonly wgpumatmul_setLhsFrom: (a: number, b: number) => [number, number];
  readonly wgpumatmul_shape: (a: number) => [number, number];
  readonly wgpumatmul_synchronize: (a: number) => [number, number, number];
  readonly wgpumatmul_tileMNK: (a: number) => [number, number];
  readonly wgpumatmul_upload: (a: number, b: any, c: any) => [number, number];
  readonly wgpumatmul_uploadRhs: (a: number, b: any) => [number, number];
  readonly wgpumatmul_workgroupSize: (a: number) => [number, number];
  readonly wgpurank_adapterInfo: (a: number) => [number, number, number];
  readonly wgpurank_create: (a: any, b: any, c: any, d: any, e: number, f: number) => any;
  readonly wgpurank_createFromAdaptation: (a: number, b: any, c: number) => any;
  readonly wgpurank_dispatch: (a: number, b: number) => [bigint, number, number];
  readonly wgpurank_dispatchFromMatmul: (a: number, b: number, c: number) => [bigint, number, number];
  readonly wgpurank_generation: (a: number) => bigint;
  readonly wgpurank_kind: (a: number) => [number, number];
  readonly wgpurank_outputIsCurrent: (a: number) => number;
  readonly wgpurank_profile: (a: number, b: number) => [number, number, number];
  readonly wgpurank_readback: (a: number) => [number, number, number];
  readonly wgpurank_setInputFromMatmul: (a: number, b: number) => [number, number];
  readonly wgpurank_shape: (a: number) => [number, number];
  readonly wgpurank_synchronize: (a: number) => [number, number, number];
  readonly wgpurank_tileCols: (a: number) => number;
  readonly wgpurank_timestampQueriesEnabled: (a: number) => number;
  readonly wgpurank_upload: (a: number, b: any) => [number, number];
  readonly zspaceGenerationEvidenceJson: (a: any) => [number, number, number, number];
  readonly zspaceGenerationEvidenceObject: (a: any) => [number, number, number];
  readonly st_pure_clear_last_error: () => void;
  readonly st_pure_encoder_encode_z_space: (a: number, b: number, c: number, d: number) => number;
  readonly st_pure_encoder_free: (a: number) => void;
  readonly st_pure_encoder_new: (a: number, b: number) => number;
  readonly st_pure_hypergrad_absorb_text: (a: number, b: number, c: number) => number;
  readonly st_pure_hypergrad_accumulate_pair: (a: number, b: number, c: number, d: number, e: number) => number;
  readonly st_pure_hypergrad_apply: (a: number, b: number, c: number) => number;
  readonly st_pure_hypergrad_free: (a: number) => void;
  readonly st_pure_hypergrad_gradient: (a: number, b: number, c: number) => number;
  readonly st_pure_hypergrad_new: (a: number, b: number, c: number, d: number) => number;
  readonly st_pure_hypergrad_shape: (a: number, b: number, c: number) => number;
  readonly st_pure_hypergrad_with_topos: (a: number, b: number, c: number, d: number, e: number) => number;
  readonly st_pure_last_error: () => number;
  readonly st_pure_topos_free: (a: number) => void;
  readonly st_pure_topos_new: (a: number, b: number, c: number, d: number, e: number) => number;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_4: WebAssembly.Table;
  readonly __wbindgen_export_5: WebAssembly.Table;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly closure1324_externref_shim: (a: number, b: number, c: any) => void;
  readonly closure1319_externref_shim: (a: number, b: number, c: any) => void;
  readonly closure1348_externref_shim: (a: number, b: number, c: any, d: any) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
