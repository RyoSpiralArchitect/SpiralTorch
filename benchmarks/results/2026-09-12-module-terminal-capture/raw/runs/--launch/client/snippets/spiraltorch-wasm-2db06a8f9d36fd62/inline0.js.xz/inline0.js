
function utf8StringBytes(value, maximumBytes) {
    let bytes = 0;
    for (let index = 0; index < value.length; index += 1) {
        const unit = value.charCodeAt(index);
        if (unit <= 0x7f) {
            bytes += 1;
        } else if (unit <= 0x7ff) {
            bytes += 2;
        } else if (unit >= 0xd800 && unit <= 0xdbff
            && index + 1 < value.length
            && value.charCodeAt(index + 1) >= 0xdc00
            && value.charCodeAt(index + 1) <= 0xdfff) {
            bytes += 4;
            index += 1;
        } else {
            bytes += 3;
        }
        if (bytes > maximumBytes) {
            return bytes;
        }
    }
    return bytes;
}

function jsonStringBytes(value) {
    let bytes = 0;
    for (let index = 0; index < value.length; index += 1) {
        const unit = value.charCodeAt(index);
        if (unit === 0x22 || unit === 0x5c
            || unit === 0x08 || unit === 0x09 || unit === 0x0a
            || unit === 0x0c || unit === 0x0d) {
            bytes += 2;
        } else if (unit <= 0x1f) {
            bytes += 6;
        } else if (unit <= 0x7f) {
            bytes += 1;
        } else if (unit <= 0x7ff) {
            bytes += 2;
        } else if (unit >= 0xd800 && unit <= 0xdbff
            && index + 1 < value.length
            && value.charCodeAt(index + 1) >= 0xdc00
            && value.charCodeAt(index + 1) <= 0xdfff) {
            bytes += 4;
            index += 1;
        } else if (unit >= 0xd800 && unit <= 0xdfff) {
            bytes += 6;
        } else {
            bytes += 3;
        }
    }
    return bytes;
}

export function spiraltorchPreflightJsonString(value, maximumBytes, context) {
    if (typeof value !== "string") {
        throw new Error(`${context} must be a JSON string`);
    }
    if (value.length > maximumBytes
        || utf8StringBytes(value, maximumBytes) > maximumBytes) {
        throw new Error(`${context} exceeds WASM ingress budget of ${maximumBytes} bytes`);
    }
}

export function spiraltorchSnapshotJsonCompatible(
    value,
    maximumBytes,
    maximumNodes,
    maximumDepth,
    context,
) {
    let bytes = 0;
    let nodes = 0;

    function fail(message) {
        throw new Error(message);
    }

    function charge(nextBytes, nextNodes) {
        bytes += nextBytes;
        nodes += nextNodes;
        if (bytes > maximumBytes) {
            fail(`${context} exceeds WASM ingress budget of ${maximumBytes} bytes`);
        }
        if (nodes > maximumNodes) {
            fail(`${context} exceeds WASM ingress budget of ${maximumNodes} JSON nodes`);
        }
    }

    function visit(current, depth) {
        if (depth > maximumDepth) {
            fail(`${context} exceeds WASM ingress depth limit ${maximumDepth}`);
        }
        charge(0, 1);

        if (current === null) {
            charge(4, 0);
            return null;
        }
        const kind = typeof current;
        if (kind === "boolean") {
            charge(5, 0);
            return current;
        }
        if (kind === "number") {
            if (!Number.isFinite(current)) {
                fail(`${context} must not contain non-finite numbers`);
            }
            charge(24, 0);
            return current;
        }
        if (kind === "string") {
            charge(jsonStringBytes(current) + 2, 0);
            return current;
        }
        if (Array.isArray(current)) {
            const length = current.length;
            if (length > maximumNodes - nodes) {
                fail(`${context} exceeds WASM ingress budget of ${maximumNodes} JSON nodes`);
            }
            charge(Math.max(length - 1, 0) + 2, 0);
            const snapshot = new Array(length);
            for (let index = 0; index < length; index += 1) {
                snapshot[index] = visit(current[index], depth + 1);
            }
            return snapshot;
        }
        if (kind === "object") {
            charge(2, 0);
            const snapshot = Object.create(null);
            let first = true;
            for (const key in current) {
                if (!Object.prototype.hasOwnProperty.call(current, key)) {
                    continue;
                }
                charge((first ? 0 : 1) + jsonStringBytes(key) + 3, 0);
                first = false;
                snapshot[key] = visit(current[key], depth + 1);
            }
            return snapshot;
        }
        fail(`${context} must contain only JSON-compatible values`);
    }

    return visit(value, 0);
}
