/* tslint:disable */
/* eslint-disable */
export function run_resident_graph_training_fixture(): Promise<string>;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly run_resident_graph_training_fixture: () => any;
  readonly st_pure_clear_last_error: () => void;
  readonly st_pure_encoder_encode_z_space: (a: number, b: number, c: number, d: number) => number;
  readonly st_pure_encoder_free: (a: number) => void;
  readonly st_pure_encoder_new: (a: number, b: number) => number;
  readonly st_pure_hypergrad_absorb_text: (a: number, b: number, c: number) => number;
  readonly st_pure_hypergrad_accumulate_pair: (a: number, b: number, c: number, d: number, e: number) => number;
  readonly st_pure_hypergrad_apply: (a: number, b: number, c: number) => number;
  readonly st_pure_hypergrad_free: (a: number) => void;
  readonly st_pure_hypergrad_gradient: (a: number, b: number, c: number) => number;
  readonly st_pure_hypergrad_new: (a: number, b: number, c: number, d: number) => number;
  readonly st_pure_hypergrad_shape: (a: number, b: number, c: number) => number;
  readonly st_pure_hypergrad_with_topos: (a: number, b: number, c: number, d: number, e: number) => number;
  readonly st_pure_last_error: () => number;
  readonly st_pure_topos_free: (a: number) => void;
  readonly st_pure_topos_new: (a: number, b: number, c: number, d: number, e: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_2: WebAssembly.Table;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_export_5: WebAssembly.Table;
  readonly closure716_externref_shim: (a: number, b: number, c: any) => void;
  readonly closure711_externref_shim: (a: number, b: number, c: any) => void;
  readonly closure740_externref_shim: (a: number, b: number, c: any, d: any) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
