"""Source-bound prefix controls using the existing Rust/CUDA harness."""
import argparse
import hashlib
from pathlib import Path
import json
import sys


def requests(bench):
    for seed in (17, 29, 43):
        for kind in ("topk", "midk", "bottomk"):
            for rows, cols in ((2, 8193), (64, 8193)):
                values, _ = bench.fixture(rows * cols, seed)
                if seed == 43:
                    values = [float(int(value * 8)) for value in values]
                tiles = [32, 128, 256, 512, 1024, 2048]
                rotation = seed % len(tiles)
                tiles = tiles[rotation:] + tiles[:rotation]
                scripts = [f"u2: true; rank_tile: {tile}; ctile: {tile};" for tile in tiles]
                yield dict(kind=kind, rows=rows, cols=cols, k=65, scripts=scripts,
                           input=values, seed=seed, policy="ucb", rounds=16), tiles


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--executable", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    import bench_resident_rank_adaptation_vs_torch as adaptation
    adaptation.requests = requests
    report = adaptation.run(args.executable.resolve(strict=True))
    report["probe"] = dict(schema="spiraltorch.rank_prefix_probe.v1",
        runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        boundary="Three seeds, all rank kinds, six fixed controls, 16 real Rust policy observations; compare source-bound arms, not hindsight policy wins.")
    audit.write_report_exclusive(args.output, report)
    print(json.dumps({"status": report["status"], "cases": len(report["cases"]), "error": report.get("error")}))
    raise SystemExit(report["status"] != "passed")


if __name__ == "__main__":
    main()
