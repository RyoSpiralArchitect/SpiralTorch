# Parallel Rank Prefix

Baseline native source: 593c4be79104e74b7638a3602551980b90ab5d32.
Initial broad-k candidate: 5138ec3d67a90662b1c36fd36a280defb3a9890e.
Guarded implementation: 322f831a0c16688862e76b87893af8360456b661.
The source-initial bundle requires 920193b9 and 2e254bb2; source-guarded requires
5138ec3d.
The following are build/validation/replay recipes; individual logs and reports
record outcomes. Abbreviated paths denote dedicated worktrees and new artifacts.

## Local

Rust 1.98.0, formatter nightly-2026-04-15, wasm-bindgen 0.2.104.
Use private Python (-I), private Playwright dependencies and the repository
headless browser runner, never a personal browser profile. Freeze the raw
compiler WASM before bindgen; never process an already processed *_bg.wasm.

```sh
cargo +1.98.0 build --manifest-path bindings/st-wasm/Cargo.toml --target wasm32-unknown-unknown --features webgpu --release
install -m 444 TARGET/wasm32-unknown-unknown/release/spiraltorch_wasm.wasm NEW_RAW_WASM
wasm-bindgen NEW_RAW_WASM --out-name spiraltorch_wasm --target web --out-dir NEW_WEB
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 cargo +1.98.0 test -p st-backend-wgpu --lib --test wgsl_syntax -- --test-threads=1
cargo +1.98.0 clippy -p st-backend-wgpu --all-targets -- -D warnings
cargo +1.98.0 clippy -p st-backend-wgpu --target wasm32-unknown-unknown --all-targets -- -D warnings
node bindings/st-wasm/tests/resident_types.cjs NEW_WEB/spiraltorch_wasm.d.ts
NODE_PATH=PRIVATE_PLAYWRIGHT node tools/test_resident_browser.cjs CANDIDATE_WEB CHROME NEW_JSON '' '' '' '' rank-prefix-matched BASELINE_WEB
maturin build --locked --release --manifest-path bindings/st-py/Cargo.toml --features wgpu-rt --interpreter PRIVATE_PYTHON --out NEW_WHEEL_DIR
PRIVATE_PYTHON -I -m pip install --no-deps NEW_WHEEL
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 PRIVATE_PYTHON -I -m pytest --import-mode=importlib --confcutdir=bindings/st-py -q bindings/st-py/tests/test_wgpu_rank.py bindings/st-py/tests/test_wgpu_resident.py bindings/st-py/tests/test_spiralk_rank_tile.py bindings/st-py/tests/test_resident_rank_adaptation.py bindings/st-py/tests/test_wgpu_rank_reports.py bindings/st-py/tests/test_wgpu_rank_profile.py
PRIVATE_PYTHON -I tests/test_resident_rank_adaptation_bench.py -v
```

The baseline WASM is frozen 920193b9 from the previous pair-lanes study. Its
backend/WASM Rust sources equal native baseline 593c4be7; it is not relabeled as
a new build. Browser order: initial A/B (99 cases), guarded A/B (117), A/A (117),
guarded A/B repeat (117). The initial run has a distinct retained fixture hash.
The identical baseline products serve both A/A arms. Browser adapter identity
may be anonymous; timings include host API and completion fence, not GPU events.

## Furnace

Read `spiral status` before EACH GPU launch and decide whether to proceed.
Never chain status to an unconditional launch. Existing CPU workloads and
system configuration stay untouched. No -I on Furnace: Torch uses its existing
user site. Use isolated clean baseline/candidate worktrees, private Rust 1.98.1,
four build jobs and immutable mode-555 executables with embedded build identity.

```sh
cargo +1.98.1 build -p st-core --no-default-features --features wgpu-rt,kdsl --example resident_rank_adaptation_bench --release
install -m 555 TARGET/release/examples/resident_rank_adaptation_bench NEW_IMAGE
NEW_IMAGE --build-info
sha256sum NEW_IMAGE
python3 run_native_prefix_probe.py --repo MATCHING_WORKTREE --executable NEW_IMAGE --output NEW_JSON
```

Native source order is A-B-B-A; each combined native-WGPU/CUDA process is terminal
before another owned GPU job starts, including on the other host. No same-host
build overlaps benchmark timing. Six fixed controls never seed the policy;
only 16 real, correctness-gated observations per request do. CUDA operation and
exact source-index checks are unchanged. Availability checks are point checks,
not continuous monitoring. Private session listings are excluded from the
archive; GPU-only observations retain the original status hashes.

## Replay

```sh
python -I analyze_prefix.py --repo /path/to/SpiralTorch --output recomputed.json
```

Replay uses unchanged repository validators and standard library only. Large
binaries, wheels and generated modules are excluded from the archive. Negative
candidates and unchanged/slower cases remain. Ratios are descriptive cell
sample-mean ratios, not confidence intervals, policy wins or model quality.

The extra receipt-validator pytest launch collected an unrelated ancestor
package (__init__.py importing .tiger) before reaching the tests. Its failure
log is retained. Running the unchanged file directly through unittest passes
all six cases. Python binding tests use the explicit binding confcutdir and
pass 103 cases; no ancestor package or test source was modified for this.
