"""Replay fixed-control prefix comparisons without a GPU, browser, or Torch."""
import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
from statistics import mean, median
import sys

ROOT = Path(__file__).resolve().parent
BASELINE = "593c4be79104e74b7638a3602551980b90ab5d32"
CANDIDATE = "322f831a0c16688862e76b87893af8360456b661"
INITIAL = "5138ec3d67a90662b1c36fd36a280defb3a9890e"


def read(name):
    return json.loads((ROOT / name).read_text())


def finite(values):
    assert values and all(math.isfinite(x) and x > 0 for x in values)
    return values


def describe(values):
    return dict(cells=len(values), median=median(values), minimum=min(values), maximum=max(values))


def grouped(cells, fields):
    groups = defaultdict(list)
    for cell in cells:
        key = ",".join(f"{field}={cell[field]}" for field in fields)
        groups[key].append(cell["ratio"])
    return {key: describe(values) for key, values in sorted(groups.items())}


def browser(name, aa=False, initial=False):
    report = read(name)
    assert report["status"] == "passed" and not report["page_errors"]
    assert report["fixture_suite"] == "prefix"
    assert len(report["cases"]) == (99 if initial else 117)
    assert (report["repetitions"], report["warmup_batches"], report["retained_batches"]) == (64, 4, 16)
    assets = report["asset_sha256"]
    assert (assets["/module/spiraltorch_wasm_bg.wasm"] == assets["/baseline/spiraltorch_wasm_bg.wasm"]) == aa
    products = read("products.json")
    candidate_assets = products["baseline_assets"] if aa else products[
        "initial_assets" if initial else "candidate_assets"]
    fixture = "browser-initial-fixture.html" if initial else "browser-fixture.html"
    assert report["page_sha256"] == hashlib.sha256((ROOT / fixture).read_bytes()).hexdigest()
    for prefix, expected_assets in (("/module/", candidate_assets), ("/baseline/", products["baseline_assets"])):
        assert {k.removeprefix(prefix): v for k, v in assets.items() if k.startswith(prefix)} == {
            k: v for k, v in expected_assets.items() if k.endswith((".js", ".wasm"))}
    ks = (1, 7, 65, 256, 257) if initial else (7, 63, 64, 65, 256, 257)
    expected = {(seed, kind, rows, cols, tile, k) for seed in (17, 29, 43)
                for kind in ("topk", "bottomk") for rows, cols, tile in
                ((2, 8193, 512), (64, 8193, 512), (2, 8193, 256)) for k in ks}
    expected.update((seed, kind, 2, 1024, 1024, 65)
                    for seed in (17, 29, 43) for kind in ("topk", "bottomk"))
    expected.update((seed, "midk", 2, 8193, 512, 65) for seed in (17, 29, 43))
    seen, cells = set(), []
    for i, case in enumerate(report["cases"]):
        key = tuple(case[k] for k in ("seed", "kind", "rows", "cols", "tile_cols", "k"))
        assert key in expected and key not in seen and case["status"] == "passed"
        seen.add(key)
        samples = case["samples"]
        assert len(samples) == 16
        for batch, sample in enumerate(samples, 4):
            assert sample["order"] == (["baseline", "candidate"] if (i + batch) % 2 == 0 else ["candidate", "baseline"])
        a = finite([s["baseline_ms"] for s in samples])
        b = finite([s["candidate_ms"] for s in samples])
        cells.append(dict(seed=key[0], kind=key[1], family="midk-control" if key[1] == "midk" else "prefix",
                          rows=key[2], cols=key[3], tile=key[4], k=key[5],
                          baseline_mean_ms=mean(a), candidate_mean_ms=mean(b), ratio=mean(b) / mean(a)))
    assert seen == expected
    return dict(cells=cells, by_shape_k=grouped(cells, ("family", "rows", "cols", "tile", "k")),
                adapter=report["adapters"], page_sha256=report["page_sha256"], assets=assets)


def native(name, commit, adaptation, audit):
    report = read(name)
    assert report["status"] == "passed" and len(report["cases"]) == 18
    assert report["source"]["commit"] == commit and not report["source"]["tracked_dirty"]
    assert audit.validate_source_binding(report["native_build_identity"], report["source"])["valid"]
    assert report["provenance"]["valid"] and report["native_returncode"] == 0 and not report["native_stderr"]
    assert report["provenance"]["source_after"] == report["source"]
    assert report["probe"]["runner_sha256"] == hashlib.sha256((ROOT / "run_native_prefix_probe.py").read_bytes()).hexdigest()
    expected = {(seed, kind, rows) for seed in (17, 29, 43)
                for kind in ("topk", "midk", "bottomk") for rows in (2, 64)}
    seen, cells = set(), []
    for case in report["cases"]:
        request, result, tiles = case["request"], case["native"], case["tiles"]
        adaptation.validate_native(result, request, tiles)
        key = tuple(request[k] for k in ("seed", "kind", "rows"))
        assert key in expected and key not in seen
        seen.add(key)
        assert (request["cols"], request["k"], request["rounds"], request["policy"]) == (8193, 65, 16, "ucb")
        assert sorted(tiles) == [32, 128, 256, 512, 1024, 2048]
        assert result["adapter"]["name"] == report["torch_device"]
        torch_samples = finite(case["torch_timing"]["samples_ms"])
        assert len(torch_samples) == 12
        torch_mean = mean(torch_samples)
        for tile, samples in zip(tiles, result["control_samples_per_op_ms"]):
            assert len(samples) == 12
            elapsed = mean(finite(samples))
            cells.append(dict(seed=key[0], kind=key[1], rows=key[2], cols=8193, tile=tile,
                              mean_ms=elapsed, torch_mean_ms=torch_mean, torch_operation=case["torch_operation"],
                              wgpu_over_cuda=elapsed / torch_mean))
    assert seen == expected
    return dict(cells=cells, torch=report["torch"], adapter=report["torch_device"],
                request_sha256=report["request_sha256"], policy_observations=18 * 16)


def native_pair(a, b):
    assert a["request_sha256"] == b["request_sha256"]
    key = lambda c: tuple(c[k] for k in ("seed", "kind", "rows", "cols", "tile"))
    left = {key(c): c for c in a["cells"]}
    cells = [dict(c, baseline_mean_ms=left[key(c)]["mean_ms"], ratio=c["mean_ms"] / left[key(c)]["mean_ms"])
             for c in b["cells"]]
    return dict(cells=cells, by_kind_rows_tile=grouped(cells, ("kind", "rows", "tile")))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    import bench_resident_rank_adaptation_vs_torch as adaptation
    browser_runs = {name: browser(name + ".json", aa=name == "browser-aa")
                    for name in ("browser-ab-first", "browser-aa", "browser-ab-repeat")}
    assert len({v["page_sha256"] for v in browser_runs.values()}) == 1
    runs = {name: native(name + ".json", commit, adaptation, audit) for name, commit in (
        ("native-a1", BASELINE), ("native-b1", CANDIDATE), ("native-b2", CANDIDATE), ("native-a2", BASELINE))}
    initial = browser("browser-initial.json", initial=True)
    products = read("products.json")
    assert products["candidate_source"] == CANDIDATE and products["baseline_backend_wasm_sources_identical"]
    assert read("python-products.json")["status"] == "passed" and read("python-products.json")["compiled_source"] == CANDIDATE
    for name in ("browser-standard.json", "browser-profile.json"):
        assert read(name)["status"] == "passed" and not read(name)["page_errors"]
    result = dict(schema="spiraltorch.rank_prefix_comparison.v1", status="passed",
        baseline=BASELINE, candidate=CANDIDATE, browser=browser_runs,
        superseded=dict(source=INITIAL, browser=initial,
                        reason="Parallel prefixes regressed k=7; retain streaming for k below 64 and measure both sides of that boundary."),
        native={"first": native_pair(runs["native-a1"], runs["native-b1"]),
                "reverse": native_pair(runs["native-a2"], runs["native-b2"]), "runs": runs},
        interpretation="Ratios of fixed-control sample means, summarized over cells; not confidence intervals, online policy wins, model quality, or a SpiralTorch CUDA implementation.")
    result["raw_sha256"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.iterdir())
        if p.is_file() and p.suffix in (".json", ".log", ".py", ".cjs", ".txt", ".sha256", ".md", ".bundle", ".html")
        and not p.name.startswith("private-") and p.name not in ("summary.json", args.output.name)}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"browser": {k: v["by_shape_k"] for k, v in browser_runs.items()},
                      "native": {k: result["native"][k]["by_kind_rows_tile"] for k in ("first", "reverse")}}, indent=2))


if __name__ == "__main__":
    main()
