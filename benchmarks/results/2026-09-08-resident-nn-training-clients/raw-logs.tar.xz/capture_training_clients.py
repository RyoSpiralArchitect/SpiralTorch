"""Bind clean-source builds, installed native images, browser assets and raw evidence."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import zipfile

root = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
source = sys.argv[2]
short = source[:8]
output = Path(sys.argv[3]).resolve()


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def read(name):
    return json.loads((root / name).read_bytes())


require(git("rev-parse", "HEAD") == source and not git("status", "--porcelain=v1"), "not the clean source commit")
commands = [json.loads(line) for line in (root/"final-commands.jsonl").read_text().splitlines()]
require(len(commands) == 25 and len({c["name"] for c in commands}) == 25, "missing final verification command")
for command in commands:
    require(command["source_commit"] == source and command["exit_code"] == 0, "failed/wrong-source command")
    require(sha(Path(command["output"])) == command["output_sha256"], "command log changed")


def installed(cpu):
    venv = root / ("venv-cpu" if cpu else "venv")
    payload = subprocess.check_output([str(venv/"bin/python"), "-I", "-c",
        "import json,sys,spiraltorch as st,spiraltorch.spiraltorch as n;"
        "print(json.dumps(dict(extension=n.__file__,prefix=sys.prefix,build_info=st.build_info(),"
        "wgpu=st.wgpu_kernel_reports_available(),training=st.nn.ResidentTraining.__module__)))"], text=True)
    item = json.loads(payload)
    require(item["wgpu"] is (not cpu) and item["training"] == "spiraltorch.nn", "wrong installed feature/client")
    extension = Path(item["extension"]).resolve()
    require(extension.is_relative_to(venv.resolve()), "extension outside test environment")
    wheels = list((root/(("wheels-cpu-" if cpu else "wheels-")+short)).glob("*.whl"))
    require(len(wheels) == 1, "wheel identity ambiguous")
    wheel = wheels[0]
    with zipfile.ZipFile(wheel) as zipped:
        members = [n for n in zipped.namelist() if n.endswith("/"+extension.name)]
        require(len(members) == 1 and zipped.read(members[0]) == extension.read_bytes(), "installed image differs from wheel")
    return dict(**item, wheel=str(wheel), wheel_sha256=sha(wheel), extension_sha256=sha(extension))


python = read("python-training-final.json")
browser = read("browser-training-final.json")
returned = read("python-return-final.json")
torch = read("torch-clients-final.json")
require(all(r["status"] == "passed" for r in (python,browser,returned,torch)), "unsuccessful final report")
require(len(python["vjps"]) == len(browser["vjps"]) == 18 and len(returned["learning"]) == 3, "missing cases")
require(returned["browser_sha256"] == sha(root/"browser-training-final.json"), "return not bound to browser capture")
require([s["sha256"] for s in torch["sources"]] == [sha(root/"python-training-final.json"),sha(root/"browser-training-final.json")], "reference replay source drift")
for cpu in (False, True):
    directory = root/(("wasm-cpu-" if cpu else "wasm-webgpu-")+short)
    for training in (True, False):
        name = "browser-"+("training" if training else "inference")+("-cpu" if cpu else "")+"-final.json"
        report = read(name)
        require(report["status"] == "passed" and report["cpu_only"] is cpu and not report["page_errors"], "browser failure")
        require(report["wasm_sha256"] == sha(directory/"spiraltorch_wasm_bg.wasm"), "browser package changed")
        fixture = root/("python-training-final.json" if training else "python-inference-final.json")
        require(report["asset_sha256"]["/fixture.json"] == sha(fixture), "browser fixture changed")
        for url, digest in report["asset_sha256"].items():
            if url.startswith("/module/"):
                require(sha(directory/url.removeprefix("/module/")) == digest, "generated browser asset changed")

limits = {}
for label, count in (("python",7),("wasm",19),("nn",22)):
    log = (root/("clippy-"+label+".log")).read_text()
    files = re.findall(r"(?m)^error:[^\n]*\n\s*--> ([^:]+):\d", log)
    require(len(files) == count, "strict-lint count drift")
    require(not git("diff", source+"^", source, "--", *sorted(set(files))), "strict-lint failure touches changed source")
    limits[label] = dict(status="failed", errors=count, files=sorted(set(files)), files_unchanged_vs_parent=True,
                        boundary="diagnostics in unchanged files, not a separate baseline execution")


def test_count(name):
    log = (root/name).read_text()
    if name.startswith("rust-"):
        return dict(passed=sum(map(int, re.findall(r"test result: ok\. (\d+) passed",log))))
    ran = int(re.search(r"Ran (\d+) tests", log)[1])
    skipped = re.search(r"OK \(skipped=(\d+)\)", log)
    skipped = int(skipped[1]) if skipped else 0
    return dict(ran=ran, passed=ran-skipped, skipped=skipped)


errors = []
for device in torch["devices"]:
    for collection in ("vjps", "learning"):
        for case in device[collection]:
            for state in case["states"].values():
                for client in ("python","browser"):
                    errors.extend(state.get(client,{}).values())
summary = dict(schema="spiraltorch.nn.training_clients.study.v1",status="passed",source_commit=source,
    source_tree=git("rev-parse",source+"^{tree}"),
    attribution="Clean source checked before every command; installed extension bytes match frozen-source wheels. Not embedded Git attestation or reproducible-build proof.",
    products=dict(gpu=installed(False),cpu=installed(True)),
    adapters=dict(native=python["adapter"],browser=browser["adapter"],browser_version=browser["browser_version"],
                  identity_boundary="Browser adapter is anonymous; no exact cross-client physical GPU attestation."),
    vjp_cases_per_client=18, independent_torch_devices=[d["device"] for d in torch["devices"]],torch_version=torch["torch"],
    max_abs_error_vs_torch=max(errors),browser_rejections=browser["rejected"],
    learning=[dict(seed=c["seed"],initial_mse=c["initial"]["loss"],final_mse=c["final"]["loss"],updates=128,
        browser_additional_updates=64,browser_max_abs_error=next(b["max_abs_error_vs_uninterrupted_python"] for b in browser["learning"] if b["seed"]==c["seed"])) for c in python["learning"]],
    handoff_return_max_abs_error=max(c["max_abs_error"] for c in returned["learning"]),
    tests={name:test_count(name) for name in ("rust-nn-final.log","rust-backend-final.log","python-gpu-nn-final.log",
        "python-cpu-nn-final.log","python-gpu-smoke-final.log","python-cpu-smoke-final.log","python-matmul-final.log","validator-final.log")},
    final_commands=25,strict_backend_clippy="passed",workspace_fmt="passed",expanded_strict_clippy=limits,
    boundaries=["Correctness only, no throughput or LLM/general-geometry learning claim.",
        "Weight-only handoff with fresh counters, not optimizer checkpoint/resume.",
        "Native and WASM dev packages, not a PyPI release.",
        "Zero-rate signed-zero regression is retained as a development failure before the fix.",
        "No CUDA/Furnace execution in this study; GPU contention unmeasured."])
output.mkdir(parents=True, exist_ok=False)
with (output/"summary.json").open("x") as out:
    json.dump(summary,out,indent=2,sort_keys=True,allow_nan=False)
    out.write("\n")
files = sorted(p for p in root.iterdir() if p.is_file() and p.suffix in {".log",".json",".jsonl",".py"})
with tarfile.open(output/"raw-logs.tar.xz","x:xz") as archive:
    for file in files:
        archive.add(file,arcname=file.name,recursive=False)
print(json.dumps(dict(status="passed",source_commit=source,raw_files=len(files),summary=str(output/"summary.json"))))
