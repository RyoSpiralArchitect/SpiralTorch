"""Serial, source-frozen local verification; no overlapping owned GPU jobs."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo, target, source = sys.argv[1:]
root = Path(__file__).resolve().parent
short = source[:8]
base = dict(os.environ, CARGO_BUILD_JOBS="4", CARGO_TARGET_DIR=target, RUSTUP_TOOLCHAIN="1.98.0",
            PYO3_PYTHON="/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12",
            NODE_PATH="/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules",
            PYTORCH_ENABLE_MPS_FALLBACK="0")
python = str(root / "venv/bin/python")
cpu_python = str(root / "venv-cpu/bin/python")
torch_python = "/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python"
chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
wasm = root / ("wasm-webgpu-" + short)
wasm_cpu = root / ("wasm-cpu-" + short)
wheel_name = "spiraltorch-0.4.27-cp38-abi3-macosx_11_0_arm64.whl"


def frozen():
    current = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
    status = subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=repo, text=True)
    if current != source or status:
        raise RuntimeError("source is not the clean frozen commit")


with (root / "final-commands.jsonl").open("x") as receipts:
    def run(name, args, extra=None):
        frozen()
        output_path = root / (name + ".log")
        env = dict(base, **(extra or {}))
        start = time.time()
        print("starting " + name, flush=True)
        with output_path.open("xb") as output:
            completed = subprocess.run(list(map(str, args)), cwd=repo, env=env, stdout=output, stderr=subprocess.STDOUT)
        entry = dict(name=name, command=list(map(str,args)), environment_overrides=extra or {}, source_commit=source,
                     exit_code=completed.returncode, started_unix=start, elapsed_seconds=time.time()-start,
                     output=str(output_path), output_sha256=hashlib.sha256(output_path.read_bytes()).hexdigest())
        receipts.write(json.dumps(entry) + "\n")
        receipts.flush()
        print(json.dumps(dict(name=name, exit_code=completed.returncode)), flush=True)
        if completed.returncode:
            raise RuntimeError(name + " failed; retained log at " + str(output_path))

    maturin = "/Library/Frameworks/Python.framework/Versions/3.12/bin/maturin"
    for cpu, interpreter in ((False, python), (True, cpu_python)):
        label = "cpu" if cpu else "gpu"
        wheels = root / (("wheels-cpu-" if cpu else "wheels-") + short)
        options = ["--no-default-features", "--features", "python-default"] if cpu else []
        run("wheel-"+label+"-final-build", [maturin, "build", "--manifest-path", "bindings/st-py/Cargo.toml",
            "--interpreter", base["PYO3_PYTHON"], "--out", wheels] + options)
        run("wheel-"+label+"-final-install", [interpreter, "-I", "-m", "pip", "install", "--no-deps", "--force-reinstall", wheels/wheel_name])
    for cpu, directory in ((False, wasm), (True, wasm_cpu)):
        run("wasm-"+("cpu" if cpu else "gpu")+"-final-build", ["bash", "scripts/build_wasm_web.sh", "--dev", "--", "--features", "nn" if cpu else "webgpu"],
            dict(OUT_DIR=str(directory), EXAMPLES_DIR=str(root/"empty-examples")))
    run("rust-nn-final", ["cargo", "+1.98.0", "test", "-p", "st-nn", "--features", "wgpu", "--lib",
        "--test", "resident_training", "--test", "resident_inference", "--test", "training_gradient_reduction", "--", "--test-threads=1"],
        dict(SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS="1"))
    run("rust-backend-final", ["cargo", "+1.98.0", "test", "-p", "st-backend-wgpu", "--all-targets", "--", "--test-threads=1"])
    for cpu, interpreter in ((False, python), (True, cpu_python)):
        label="cpu" if cpu else "gpu"
        extra=dict(SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS="0" if cpu else "1")
        run("python-"+label+"-nn-final", [interpreter, "-I", "-m", "unittest", "discover", "-s", "bindings/st-py/tests", "-p", "test_nn_resident*.py", "-v"], extra)
        run("python-"+label+"-smoke-final", [interpreter, "-I", "bindings/st-py/tests/test_unittest_smoke.py", "-v"], extra)
    run("python-matmul-final", [python, "-I", "bindings/st-py/tests/test_wgpu_resident.py", "-v"], dict(SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS="1"))
    run("validator-final", [python, "-I", "tests/test_resident_training_client_validation.py", "-v"])
    run("types-final", ["node", "bindings/st-wasm/tests/resident_types.cjs", wasm/"spiraltorch_wasm.js"])
    run("python-training-final", [python, "-I", "bindings/st-py/examples/resident_nn_training.py", "--output", root/"python-training-final.json"])
    run("python-inference-final", [python, "-I", "bindings/st-py/examples/resident_nn_roundtrip.py", "--output", root/"python-inference-final.json"])
    for cpu, directory in ((False, wasm), (True, wasm_cpu)):
        for training in (True, False):
            fixture = root / ("python-training-final.json" if training else "python-inference-final.json")
            with (directory/("training-fixture.json" if training else "nn-fixture.json")).open("xb") as copied:
                copied.write(fixture.read_bytes())
            name = "browser-" + ("training" if training else "inference") + ("-cpu" if cpu else "") + "-final"
            mode = ("nn-training-clients" if training else "nn-clients") + ("-cpu" if cpu else "")
            run(name, ["node", "tools/test_resident_browser.cjs", directory, chrome, root/(name+".json"), "", "", "", "", mode])
    run("python-return-final", [python, "-I", "bindings/st-py/examples/resident_nn_training.py", "--browser-report", root/"browser-training-final.json", "--output", root/"python-return-final.json"])
    run("torch-clients-final", [torch_python, "-I", "tools/validate_resident_training_clients_vs_torch.py", "--python-report", root/"python-training-final.json", "--browser-report", root/"browser-training-final.json", "--output", root/"torch-clients-final.json"])
    run("fmt-final", ["cargo", "+nightly-2026-04-15", "fmt", "--all", "--", "--check"])
    run("clippy-backend-final", ["cargo", "+1.98.0", "clippy", "-p", "st-backend-wgpu", "--all-targets", "--", "-D", "warnings"])
    frozen()
    print("all frozen-source verification commands passed", flush=True)
