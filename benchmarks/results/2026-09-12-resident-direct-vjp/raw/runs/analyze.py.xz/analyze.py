"""Describe every retained case median; ranges are not confidence intervals."""
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).parent
rows, regressions, inputs = [], [], []
for run in ['measurement-a', 'measurement-b']:
    receipt = json.loads((ROOT/run/'receipt.json').read_bytes())
    assert receipt['status'] == 'passed' and 'active' not in receipt
    for mode in ['plain', 'topos_ema', 'clipped_topos_ema']:
        path = ROOT/run/(mode+'-validation.json')
        data = path.read_bytes()
        value = json.loads(data)
        assert value['status'] == 'passed' and len(value['cases']) == 9
        inputs.append(dict(path=str(path), sha256=hashlib.sha256(data).hexdigest()))
        for cadence in ['immediate', 'deferred']:
            row = dict(run=run, mode=mode, cadence=cadence)
            for route in ['native', 'browser']:
                cases = [c[route][cadence] for c in value['cases']]
                ratios = [c['baseline_over_candidate'] for c in cases]
                assert all(x > 0 and math.isfinite(x) for x in ratios)
                row[route] = dict(cases=9, min=min(ratios), max=max(ratios),
                    median_case_ratio=statistics.median(ratios),
                    geomean=math.exp(sum(map(math.log, ratios))/len(ratios)),
                    candidate_faster=sum(x > 1 for x in ratios))
                if route == 'native':
                    torch = [c['torch_over_candidate'] for c in cases]
                    row[route]['torch_faster'] = sum(x < 1 for x in torch)
                    row[route]['torch_over_candidate_range'] = [min(torch), max(torch)]
                for config, case in zip(value['cases'], cases):
                    if case['baseline_over_candidate'] < 0.9:
                        regressions.append(dict(run=run, mode=mode, cadence=cadence, route=route,
                            config=config['config'], result=case))
            rows.append(row)
report = dict(status='passed', inputs=inputs, rows=rows, ratios_under_0_9=regressions,
    scope='Descriptive ratios of case medians, baseline/candidate > 1 favors direct destinations. '
    'No confidence intervals, causal phase attribution or universal speedup claim. Both complete runs retained.')
with (ROOT/'analysis.json').open('x') as stream:
    json.dump(report, stream, indent=2, allow_nan=False)
    stream.write('\n')
for row in rows:
    print(row['run'], row['mode'], row['cadence'],
        'native', round(row['native']['min'], 3), round(row['native']['max'], 3),
        'browser', round(row['browser']['min'], 3), round(row['browser']['max'], 3),
        'faster', row['native']['candidate_faster'], row['browser']['candidate_faster'],
        'torch_faster', row['native']['torch_faster'])
