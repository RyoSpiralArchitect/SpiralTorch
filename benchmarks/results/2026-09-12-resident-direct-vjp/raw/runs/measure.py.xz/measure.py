"""Serial source-bound regression plus paired native/browser optimizer intervals."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
BASE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-capture-pool-20260912/candidate-a')
P = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH = '/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
if len(sys.argv) == 3 and sys.argv[1] == '--launch':
    name = sys.argv[2]
    assert Path(name).name == name and not (LOG/name).exists()
    with (LOG/(name+'.log')).open('xb') as output:
        child = subprocess.Popen([P, '-S', str(Path(__file__).resolve()), name], cwd=ROOT,
            stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps(dict(pid=child.pid, log=str(LOG/(name+'.log')))))
    raise SystemExit(0)
assert len(sys.argv) == 2 and Path(sys.argv[1]).name == sys.argv[1]
OUT = LOG/sys.argv[1]
OUT.mkdir()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert not git('status', '--porcelain')
source = dict(commit=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'))
baseline = json.loads((BASE/'receipt.json').read_bytes())
assert baseline['status'] == 'passed'
for name, digest in baseline['products'].items(): assert sha(BASE/name) == digest
env = dict(os.environ, SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1', PYTORCH_ENABLE_MPS_FALLBACK='0',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
report = dict(status='running', pid=os.getpid(), source=source, baseline_source=baseline['source'], steps=[], products={},
    baseline_receipt_sha256=sha(BASE/'receipt.json'),
    harness_sha256={p:sha(LOG/p) for p in ['measure.py', 'build_bench.py', 'smoke_bench.py', 'run.py']},
    boundary='All three fixed optimizer modes, three seeds, three shapes, rotated A/B/Torch and alternating browser A/B; two warmups/eight retained intervals per cadence, eight updates each. No selective retries. Native Metal and browser WebGPU; eager Torch MPS without fallback. Host exclusivity UNKNOWN; owned GPU work serial. Neither fastest Torch nor CUDA/FT-quality evidence.')

def save():
    path = OUT/'receipt.json.tmp'
    path.write_text(json.dumps(report, indent=2)+'\n')
    path.replace(OUT/'receipt.json')

def run(name, args):
    args = list(map(str, args))
    started = time.monotonic()
    print('START', name, flush=True)
    with (OUT/(name+'.log')).open('xb') as log:
        child = subprocess.Popen(args, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
        report['active'] = dict(name=name, pid=child.pid, command=args)
        save()
        code = child.wait()
    report.pop('active')
    report['steps'].append(dict(name=name, command=args, exit_code=code, seconds=time.monotonic()-started))
    save()
    print('END', name, code, flush=True)
    if code: raise RuntimeError(name)
    assert not git('status', '--porcelain') and git('rev-parse', 'HEAD') == source['commit']

start = time.monotonic()
try:
    run('build-candidate', [P, '-S', LOG/'build_bench.py', 'candidate-a'])
    run('smoke-candidate', [TORCH, '-I', LOG/'smoke_bench.py', 'candidate-a'])
    run('regression', [P, '-S', LOG/'run.py', 'verified-a'])
    base_ref, candidate_ref = baseline['source']['commit'], source['commit']
    for mode in ['plain', 'topos_ema', 'clipped_topos_ema']:
        optimizer = [] if mode == 'plain' else ['--learner-optimizer', mode]
        native, browser = OUT/(mode+'-native.json'), OUT/(mode+'-browser.json')
        run('native-'+mode, [TORCH, '-I', ROOT/'tools/bench_resident_training_vs_torch.py',
            '--baseline', BASE/'resident_training_bench', '--baseline-source', base_ref,
            '--candidate', LOG/'candidate-a/resident_training_bench', '--candidate-source', candidate_ref,
            '--device', 'mps', '--graph', '--learner', *optimizer, '--output', native])
        run('browser-'+mode, ['node', ROOT/'tools/bench_resident_training_browser.cjs',
            BASE/'wasm', LOG/'candidate-a/wasm', CHROME, browser,
            'learner', 'standard', 'none', 'none' if mode == 'plain' else mode])
        run('validate-'+mode, [P, '-I', ROOT/'tools/validate_resident_training_bench.py',
            '--native', native, '--browser', browser, '--browser-progress', str(browser)+'.progress.jsonl',
            '--baseline-source', base_ref, '--candidate-source', candidate_ref,
            '--browser-harness-source', candidate_ref, '--output', OUT/(mode+'-validation.json')])
        for path in [native, browser, OUT/(mode+'-validation.json')]:
            value = json.loads(path.read_bytes())
            assert value['status'] == 'passed' and len(value['cases']) == 9
    for role in ['baseline-a', 'candidate-a', 'verified-a']:
        folder = BASE if role == 'baseline-a' else LOG/role
        value = json.loads((folder/'receipt.json').read_bytes())
        assert value['status'] == 'passed'
        if role != 'baseline-a': assert value['source'] == source
        for name, digest in value['products'].items(): assert sha(folder/name) == digest
        report['products'][role+'/receipt.json'] = sha(folder/'receipt.json')
    for path in OUT.iterdir():
        if path.is_file() and path.suffix == '.json' and path.name != 'receipt.json':
            report['products'][str(path.relative_to(LOG))] = sha(path)
    report['status'] = 'passed'
except BaseException as error:
    report.update(status='error', error=repr(error))
    raise
finally:
    report['seconds'] = time.monotonic()-start
    save()
    print(json.dumps(report))
