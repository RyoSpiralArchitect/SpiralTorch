const fs=require("node:fs"),path=require("node:path"),http=require("node:http"),{chromium}=require("playwright");
(async()=>{
const root=path.join(__dirname,"verified/bench"),fd=fs.openSync(path.join(__dirname,"matrix-debug.json"),"wx"),events=[];
const html=fs.readFileSync("/Users/ryospiralarchitect/\u{1f300}SpiralReality\u{1f300}/_wt/spiraltorch-resident-graph-forward-v1/bindings/st-wasm/tests/resident_graph_training_profile.html","utf8")
 .replace("cases.push(report);",'console.log("PROFILE_CASE",JSON.stringify({config,policy,bytes:JSON.stringify(report).length}));cases.push(report);')
 .replace('result.textContent = JSON.stringify({status:"passed",cases,','console.log("PROFILE_ALL",cases.length);result.textContent = JSON.stringify({status:"passed",cases,');
const server=http.createServer((req,res)=>{if(req.url==="/"){res.setHeader("Content-Type","text/html");res.end(html);return;}
const relative=decodeURIComponent(req.url.replace(/^\/module\//,"")),p=path.resolve(root,relative);
if(!p.startsWith(root+"/")||!fs.existsSync(p)){res.writeHead(404);res.end();return;}
res.setHeader("Content-Type",p.endsWith(".wasm")?"application/wasm":"text/javascript");res.end(fs.readFileSync(p));});
await new Promise(r=>server.listen(0,"127.0.0.1",r));let browser,report={status:"error"};
try {browser=await chromium.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",headless:true,args:["--enable-unsafe-webgpu"]});
const page=await browser.newPage();let reject;const fatal=new Promise((_,r)=>reject=r);fatal.catch(()=>{});
page.on("console",m=>{events.push(m.text());console.log(m.text().slice(0,300));});
page.on("crash",()=>{events.push("PAGE_CRASH");reject(Error("page crashed"));});
page.on("pageerror",e=>{events.push(String(e));reject(e);});
await page.goto("http://127.0.0.1:"+server.address().port+"/");
await Promise.race([fatal,page.locator("#result:not([data-status='running'])").waitFor({timeout:60000,state:"attached"})]);
report={status:"completed"};
}catch(e){report.error=String(e.stack||e);}
finally{if(browser)await browser.close();await new Promise(r=>server.close(r));fs.writeFileSync(fd,JSON.stringify({...report,events},null,2));fs.closeSync(fd);}
console.log(report);
})().catch(e=>{console.error(e);process.exitCode=1});
