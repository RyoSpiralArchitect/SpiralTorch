"""Uninstrumented A/B and eager Torch measurements only after verification ends."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG=Path(__file__).parent
CAND=LOG/'adopted'
BASE=LOG.parent/'graph-training-forward-pass-20260910/selected'
OUT=LOG/'regression';OUT.mkdir()
P='/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
env=dict(os.environ,PYTORCH_ENABLE_MPS_FALLBACK='0',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((BASE/'build-receipt.json').read_text())
candidate=json.loads((CAND/'receipt.json').read_text())
assert base['status']==candidate['status']=='passed'
source=git('rev-parse','HEAD')
assert source==candidate['source']['commit'] and not git('status','--porcelain')
assert not git('diff',base['source']['commit'],'336c73db','--','crates/st-backend-wgpu','crates/st-nn','crates/st-tensor','crates/st-kernel-contracts')
report=dict(status='error',source=source,baseline=base['source'],steps=[],products={})
for folder,build in [(BASE,base),(CAND,candidate)]:
    for path,digest in build['products'].items():
        assert sha(folder/path)==digest,path
        report['products'][str(folder/path)]=digest
def save():
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,args):
    print('START',name,flush=True);start=time.monotonic()
    with (OUT/(name+'.log')).open('xb') as f:
        p=subprocess.run(args,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    report['steps'].append(dict(name=name,command=args,exit_code=p.returncode,seconds=time.monotonic()-start))
    save();print('END',name,p.returncode,flush=True)
    if p.returncode:raise RuntimeError(name)
try:
    for matrix in ['standard','wide']:
        folder=OUT/matrix;folder.mkdir()
        run(matrix+'-native',[TORCH,'-I','tools/bench_resident_training_vs_torch.py','--graph','--matrix',matrix,'--device','mps',
            '--baseline',str(BASE/'resident_training_bench'),'--baseline-source',base['source']['commit'],
            '--candidate',str(CAND/'resident_training_bench'),'--candidate-source',candidate['source']['commit'],'--output',str(folder/'native.json')])
        run(matrix+'-browser',['node','tools/bench_resident_training_browser.cjs',str(BASE/'bench'),str(CAND/'bench'),CHROME,str(folder/'browser.json'),'graph',matrix])
        run(matrix+'-validate',[P,'-I','tools/validate_resident_training_bench.py','--native',str(folder/'native.json'),
            '--browser',str(folder/'browser.json'),'--browser-progress',str(folder/'browser.json.progress.jsonl'),
            '--baseline-source',base['source']['commit'],'--candidate-source',candidate['source']['commit'],'--browser-harness-source',source,
            '--output',str(folder/'validation.json')])
    assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
    for path,digest in report['products'].items():assert sha(Path(path))==digest,path
    report['status']='passed'
except BaseException as error:
    report['error']=repr(error);raise
finally:save()
