"""Losslessly archive bounded evidence after all owned measurement jobs terminate."""
import hashlib
import json
import lzma
import math
from pathlib import Path
import statistics
import subprocess

ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG=Path(__file__).parent
OUT=ROOT/'benchmarks/results/2026-09-10-graph-training-gpu-profile';OUT.mkdir()
RAW=OUT/'raw';RAW.mkdir()
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while chunk:=f.read(1024*1024):h.update(chunk)
    return h.hexdigest()
checks=json.loads((LOG/'adopted/receipt.json').read_text())
bench=json.loads((LOG/'regression/receipt.json').read_text())
assert checks['status']==bench['status']=='passed'
assert git('rev-parse','HEAD')==checks['source']['commit']
for p,digest in checks['products'].items():assert sha(LOG/'adopted'/p)==digest
summary=json.loads((LOG/'profile-summary.json').read_text())
summary['regression']={}
summary['comparisons']={}
for matrix in ['standard','wide']:
    value=json.loads((LOG/'regression'/matrix/'validation.json').read_text())
    assert value['status']=='passed'
    groups={}
    for client in ['native','browser']:
        groups[client]={}
        for cadence in ['immediate','deferred']:
            ratios=[r[client][cadence]['baseline_over_candidate'] for r in value['cases']]
            row=dict(geomean_baseline_over_candidate=statistics.geometric_mean(ratios),
                range=[min(ratios),max(ratios)],cases_faster_or_equal=sum(v>=1 for v in ratios),cases=len(ratios))
            if client=='native':
                row['geomean_torch_over_candidate']=statistics.geometric_mean(r[client][cadence]['torch_over_candidate'] for r in value['cases'])
            groups[client][cadence]=row
    summary['regression'][matrix]=groups
    summary['comparisons'][matrix]=dict(max_abs_error=max(e for r in value['cases'] for e in r['max_abs_errors'].values()),
        all_loss_sequences_decreased=all(r['losses'][-1]<r['losses'][0] for r in value['cases']))
summary['regression_boundary']='One fresh paired round per matrix/client; 2 warmups + 8 retained rotated blocks/cadence. Ratios of case medians, then geometric mean. No speedup/parity guarantee from noise-sensitive observations.'
summary['benchmark_counts']=dict(raw_intervals=1800,retained_intervals=1440,sgd_updates_over_reset_trajectories=14400)
summary['profile_counts']=dict(cases_per_client=21,updates_per_trajectory=12,controls_per_case=2,
    profiled_updates_both_clients=504,retained_profiles=378,main_updates_all_three_workspaces=1512)
summary['verification']=dict(backend=114,nn=733,integration=6,python_gpu=30,profile_admission=4,benchmark_admission=10)
torch=json.loads((LOG/'adopted/torch-correctness.json').read_text())
summary['verification']['torch']=dict(cases=len(torch['cases']),comparisons=sum(r['comparisons'] for r in torch['cases']),max_abs_error=max(r['max_abs_error'] for r in torch['cases']))
summary['inference']='Diagnostic timestamps have substantial dispersion and instrumentation effects. Dense backward and mixed/pointwise forward are candidates for bounded follow-up, not proven uninstrumented bottlenecks. No optimization default changed.'
summary['residuals']=['Ordinary Module::forward, ModuleTrainer, pure::Tensor storage and generic autograd routing remain unchanged.',
    'Profiler is public Rust and exercised by the shared WASM benchmark, not yet exposed by production Python/WASM classes.',
    'Prior one-off parallel GPU VJP failure remains UNKNOWN; serial checks here do not establish its cause.',
    'No CUDA/Furnace, push, PR, merge or release in this turn; no fastest-PyTorch/application-quality claim.']
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
paths=[]
for p in (LOG/'adopted').rglob('*'):
    if p.is_file() and (p.suffix in ['.log','.json','.jsonl','.stderr']) and 'bench' not in p.parts and 'correctness' not in p.parts:
        paths.append(p)
for p in (LOG/'regression').rglob('*'):
    if p.is_file() and not p.name.endswith('.cases.jsonl'):paths.append(p)
for relative in ['core-check.log','fixture-check.log','backend-clippy.log','wasm-fixture-check.log','fence-check.log','fence-clippy.log',
    'verified/receipt.json','verified/browser-profile.json','verified/native-profile.json',
    'browser-profile-streamed.json','browser-profile-streamed.json.cases.jsonl','browser-debug.json','matrix-debug.json',
    'final/receipt.json','final/browser-profile.json','final/native-profile.json',
    'verify.py','regression.py','analyze-profile.py','debug-browser.cjs','debug-matrix.cjs','archive.py']:
    paths.append(LOG/relative)
manifest=dict(schema='spiraltorch.lossless_evidence_archive.v1',source=checks['source'],artifacts=[],
    omitted='Redundant regression browser .cases.jsonl objects are fully retained inside browser.json; all original files remain in the local log directory. Native binaries and generated modules are hash-bound by receipts, not committed.')
for src in sorted(set(paths)):
    name=str(src.relative_to(LOG)).replace('/','__')+'.xz'
    dst=RAW/name
    print('ARCHIVE',str(src.relative_to(LOG)),src.stat().st_size,flush=True)
    expected=sha(src)
    compressor=lzma.LZMACompressor(format=lzma.FORMAT_XZ,filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024*1024)])
    with src.open('rb') as source,dst.open('xb') as dest:
        while chunk:=source.read(1024*1024):dest.write(compressor.compress(chunk))
        dest.write(compressor.flush())
    actual=hashlib.sha256()
    with lzma.open(dst,'rb') as f:
        while chunk:=f.read(1024*1024):actual.update(chunk)
    assert actual.hexdigest()==expected and dst.stat().st_size<95*1024*1024
    manifest['artifacts'].append(dict(original=str(src.relative_to(LOG)),bytes=src.stat().st_size,sha256=expected,
        archive=str(dst.relative_to(OUT)),archive_bytes=dst.stat().st_size,archive_sha256=sha(dst)))
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('COMPLETE',len(manifest['artifacts']),sum(r['archive_bytes'] for r in manifest['artifacts']),flush=True)
