// Isolated diagnostic browser with API event traces; never benchmark evidence.
const fs=require("node:fs"), path=require("node:path"), http=require("node:http");
const {chromium}=require("playwright");
(async()=>{
 const root=path.join(__dirname,"verified/bench"), out=path.join(__dirname,"browser-debug.json");
 const fd=fs.openSync(out,"wx"), files=new Map();
 function assets(dir) {for(const e of fs.readdirSync(dir,{withFileTypes:true})) {
   const p=path.join(dir,e.name);
   if(e.isDirectory())assets(p); else files.set("/module/"+path.relative(root,p).split(path.sep).join("/"),p);
 }}
 assets(root);
 const server=http.createServer((req,res)=>{
   if(req.url==="/"){res.setHeader("Content-Type","text/html");res.end("<!doctype html><title>Owned profiling debug</title>");return;}
   const p=files.get(req.url);if(!p){res.writeHead(404);res.end();return;}
   res.setHeader("Content-Type",p.endsWith(".wasm")?"application/wasm":"text/javascript");res.end(fs.readFileSync(p));
 });
 await new Promise(r=>server.listen(0,"127.0.0.1",r));
 let browser,report={status:"error"},errors=[];
 try {
   browser=await chromium.launch({executablePath:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",headless:true,args:["--enable-unsafe-webgpu"]});
   const page=await browser.newPage();
   page.on("pageerror",e=>errors.push(String(e)));
   await page.goto("http://127.0.0.1:"+server.address().port+"/");
   report=await page.evaluate(async()=>{
     const events=[];let count=0;
     function wrap(proto,name,promise=false){
       const original=proto[name];
       proto[name]=function(...args){
         const id=++count;
         events.push({id,name,event:"start",label:this.label,args:args.map(a=>typeof a==="string"?a:typeof a)});
         const value=original.apply(this,args);
         if(promise)value.then(result=>events.push({id,name,event:"resolved",message:result?.message}),
            error=>events.push({id,name,event:"rejected",message:String(error)}));
         else events.push({id,name,event:"returned"});
         return value;
       };
     }
     wrap(GPUAdapter.prototype,"requestDevice",true);
     wrap(GPUDevice.prototype,"pushErrorScope");
     wrap(GPUDevice.prototype,"popErrorScope",true);
     wrap(GPUQueue.prototype,"submit");
     wrap(GPUBuffer.prototype,"mapAsync",true);
     wrap(GPUBuffer.prototype,"unmap");
     const m=await import("/module/spiraltorch_wasm.js");await m.default();
     events.push({stage:"initialized"});
     const benchmark=await m.TrainingBenchmark.create(JSON.stringify({shape:[2,16,32],depth:2,seed:17,steps:8,graph:true}));
     events.push({stage:"created"});
     const value=await Promise.race([
       benchmark.profile("exact").then(v=>({status:"passed",bytes:v.length})).catch(e=>({status:"error",error:String(e)})),
       new Promise(r=>setTimeout(()=>r({status:"timeout"}),30000))
     ]);
     return {...value,events};
   });
 } catch(error) {report.error=String(error.stack||error);}
 finally {if(browser)await browser.close();await new Promise(r=>server.close(r));fs.writeFileSync(fd,JSON.stringify({...report,errors},null,2));fs.closeSync(fd);}
 console.log(JSON.stringify({status:report.status,events:report.events?.length,error:report.error,output:out}));
})().catch(e=>{console.error(e);process.exitCode=1});
