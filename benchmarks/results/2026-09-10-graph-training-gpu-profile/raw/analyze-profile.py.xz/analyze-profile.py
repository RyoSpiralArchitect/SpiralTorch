import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys
ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tools'))
from profile_resident_graph_training import validate
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((LOG/'adopted/receipt.json').read_text())
assert checks['status']=='passed'
assert all(s['exit_code']==0 for s in checks['steps'])
assert not git('status','--porcelain')
assert not git('diff',checks['source']['commit'],'HEAD','--','crates')
for p,digest in checks['products'].items():assert sha(LOG/'adopted'/p)==digest,p
summary=dict(status='passed',implementation_source=checks['source'],harness_source=git('rev-parse','HEAD'),clients={})
def collect(client,rows):
    groups={}
    maximum=0.
    count=0
    for row in rows:
        count+=1;validate(row)
        assert all(p['timing_complete'] and p['gpu_span_ns'] is not None for p in row['profiles'])
        assert row['max_abs_error']==0.
        assert row['final_profile_state']==row['final_private_control_state']==row['final_ordinary_state']
        assert all(math.isfinite(p['loss']) for p in row['profiles'])
        key=json.dumps([row['config']['shape'],row['config']['depth'],row['policy']],separators=(',',':'))
        group=groups.setdefault(key,dict(config=dict(shape=row['config']['shape'],depth=row['config']['depth']),policy=row['policy'],rows=[]))
        group['rows'].append(row['profiles'][3:])
        maximum=max(maximum,row['max_abs_error'])
    assert count==21
    output=[]
    for group in groups.values():
        profiles=[p for row in group.pop('rows') for p in row]
        phases=sorted(profiles[0]['phase_totals_ns'])
        group.update(samples=len(profiles),median_gpu_span_ns=statistics.median(p['gpu_span_ns'] for p in profiles),
            median_compute_sum_ns=statistics.median(sum(p['phase_totals_ns'].values()) for p in profiles),
            zero_intervals=sum(p['zero_intervals'] for p in profiles),
            intervals=sum(len(p['passes']) for p in profiles),
            median_phase_ns={phase:statistics.median(p['phase_totals_ns'][phase] for p in profiles) for phase in phases})
        group['median_compute_share']={phase:statistics.median(p['phase_totals_ns'][phase]/sum(p['phase_totals_ns'].values()) for p in profiles if sum(p['phase_totals_ns'].values())>0) for phase in phases}
        output.append(group)
    return dict(cases=count,max_abs_error=maximum,groups=output)
data=json.loads((LOG/'adopted/native-profile.json').read_text());assert data['status']=='passed'
summary['clients']['native']=collect('native',data['cases']);del data
browser=json.loads((LOG/'adopted/browser-profile.json').read_text())
assert browser['status']=='passed' and not browser['page_errors'] and browser['completion_rejection']
raw=LOG/'adopted'/browser['profile_state_artifacts']['path']
assert sha(raw)==browser['profile_state_artifacts']['sha256']
assert raw.stat().st_size==browser['profile_state_artifacts']['bytes']
def rows():
    with raw.open() as stream:
        for index,line in enumerate(stream):
            data=json.loads(line)
            receipt=browser['cases'][index]['state_artifact']
            assert receipt['line']==index+1 and hashlib.sha256(line[:-1].encode()).hexdigest()==receipt['sha256']
            for k,v in browser['cases'][index].items():
                if k!='state_artifact':assert data[k]==v,k
            yield data
summary['clients']['browser']=collect('browser',rows())
summary['artifacts']={str(p.relative_to(LOG)):sha(p) for p in [
    LOG/'adopted/native-profile.json',LOG/'adopted/browser-profile.json',raw,LOG/'adopted/receipt.json',
    LOG/'verified/browser-profile.json',LOG/'browser-debug.json',LOG/'matrix-debug.json',LOG/'final/browser-profile.json']}
summary['development_failure']='Initial browser collector crashed after all 21 cases while materializing its giant final DOM report; streaming fixed it. Initial native same-submission query resolution produced ambiguous final-pass 0/0 samples; final profiling resolves after queue completion. This exposed pinned WGPU browser queue completion unimplemented; connected the native browser promise and tested deliberate rejection. No normal training pass/math change.'
summary['boundaries']=['No pass splitting or normal schedule change.','These are diagnostic compute-pass timings, not end-to-end speedup.',
    'Compute sums exclude copies and gaps. Dense-backward groups include several dispatches.','Browser physical GPU and background contention UNKNOWN.']
(LOG/'profile-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(LOG/'recovery.json').write_text(json.dumps(dict(status='passed',source=checks['source'],harness_source=summary['harness_source'],
    original_failed_receipt='verified/receipt.json',same_products_verified=True,summary_sha256=sha(LOG/'profile-summary.json')),indent=2)+'\n')
for client,value in summary['clients'].items():
    for g in value['groups']:
        print(client,g['config'],g['policy'], 'compute_us',round(g['median_compute_sum_ns']/1000,2),
            'span_us',round(g['median_gpu_span_ns']/1000,2),'phase_share', {k:round(v,3) for k,v in g['median_compute_share'].items()},
            'zeros',g['zero_intervals'],'/',g['intervals'])
