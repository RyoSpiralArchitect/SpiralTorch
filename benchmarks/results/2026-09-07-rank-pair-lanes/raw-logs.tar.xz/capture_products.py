"""Bind raw compiler input and final served browser assets before publication."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path("/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-rank-pair-lanes-v1")
BASE_WEB = ROOT.parent / "golden-portable-reduction-20260907/web-2928e357"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def assets(root):
    return {p.relative_to(root).as_posix(): digest(p) for p in sorted(root.rglob("*")) if p.is_file()}


def main():
    result = {"schema":"spiraltorch.rank_pair_products.v1",
        "baseline_native_source":"2e254bb25e47da8340f73655b37e1f97f0215520",
        "baseline_wasm_source":"2928e357463ca3909dc87c08d52c4f5d464cf487",
        "candidate_source":"920193b92c9c7bf6cfb481170edab5b2cd102835",
        "superseded_source":"47d88571ceb6f79b2cd2177e5917e0afae50e52a",
        "baseline_assets":assets(BASE_WEB),
        "candidate_assets":assets(ROOT / "web-candidate-920193b9"),
        "superseded_assets":assets(ROOT / "web-candidate-47d88571"),
        "raw_wasm_sha256":{p.name:digest(p) for p in sorted(ROOT.glob("raw-*.wasm"))},
        "attribution":"Native embeds clean Git commit/tree; WASM is source/build logs plus frozen raw compiler input and served product hashes, not embedded Git or a byte-reproducible-build claim."}
    diff = subprocess.check_output(["git","-C",str(REPO),"diff",result["baseline_wasm_source"],result["baseline_native_source"],"--","crates/st-backend-wgpu/src","bindings/st-wasm/src"])
    assert not diff
    result["baseline_backend_wasm_sources_identical"] = True
    (ROOT / "products.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    observations = []
    for path in sorted(ROOT.glob("private-status-*.txt")):
        text = path.read_text()
        gpu = text.split("── gpu ──\n",1)[1].split("── tmux ──",1)[0].strip()
        assert "(no compute processes)" in gpu
        observations.append({"launch":path.stem.removeprefix("private-status-"),
            "gpu_only_observation":gpu,"private_status_sha256":digest(path)})
    (ROOT / "availability.json").write_text(json.dumps({"observations":observations,
        "boundary":"Read-only point checks before each Furnace GPU launch, not continuous monitoring. Unrelated CPU workloads and session contents are not published."},indent=2,sort_keys=True)+"\n")


if __name__ == "__main__":
    main()
