# Rank Pair Lanes

Baseline native source: 2e254bb25e47da8340f73655b37e1f97f0215520.
Superseded broad candidate: 47d88571ceb6f79b2cd2177e5917e0afae50e52a.
Guarded implementation: 920193b92c9c7bf6cfb481170edab5b2cd102835.
The source-candidate bundle requires 2928e357; source-guarded requires 47d88571.

## Local

Rust 1.98.0, formatter nightly-2026-04-15, wasm-bindgen 0.2.104.
Use an isolated worktree, private Python (-I), private Playwright dependencies
and the repository browser runner, never a personal browser profile. Freeze
the raw compiler WASM before bindgen; never feed processed *_bg.wasm to bindgen.

```sh
cargo +1.98.0 build --manifest-path bindings/st-wasm/Cargo.toml --target wasm32-unknown-unknown --features webgpu --release
install -m 444 TARGET/wasm32-unknown-unknown/release/spiraltorch_wasm.wasm NEW_RAW_WASM
wasm-bindgen NEW_RAW_WASM --out-name spiraltorch_wasm --target web --out-dir NEW_WEB
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 cargo +1.98.0 test -p st-backend-wgpu --lib --test wgsl_syntax -- --test-threads=1
cargo +1.98.0 clippy -p st-backend-wgpu --all-targets -- -D warnings
cargo +1.98.0 clippy -p st-backend-wgpu --target wasm32-unknown-unknown --all-targets -- -D warnings
node bindings/st-wasm/tests/resident_types.cjs NEW_WEB/spiraltorch_wasm.d.ts
NODE_PATH=PRIVATE_PLAYWRIGHT node tools/test_resident_browser.cjs CANDIDATE_WEB CHROME NEW_OUTPUT '' '' '' '' rank-pair-lanes-matched BASELINE_WEB
```

The reused baseline WASM is the frozen 2928e357 product from the ordered tensor
mean study. Git comparison confirms its backend and WASM Rust sources equal
2e254bb2. Products retain both attributions, rather than relabeling its build.
The browser order is unguarded A/B, A/A, guarded A/B, guarded A/B. The A/A run
serves the identical baseline assets to both arms. Each process is terminal
before another owned GPU process starts. No same-host build overlaps timing.
Browser adapter identity may be anonymous and host API/fence times are not
GPU event times. The 2048-stride storage-sort path is an unchanged control.

## Furnace

Inspect `spiral status` before EACH GPU launch, then decide whether the GPU is
available. Status is not chained to an unconditional launch. Existing unrelated
CPU workloads and system configuration remain unchanged. No -I on Furnace:
Torch is in its existing user site. Use isolated baseline/candidate worktrees,
the private Rust 1.98.1 toolchain, four build jobs and immutable mode-555 images.

```sh
cargo +1.98.1 build -p st-core --no-default-features --features wgpu-rt,kdsl --example resident_rank_adaptation_bench --release
install -m 555 TARGET/release/examples/resident_rank_adaptation_bench NEW_IMAGE
NEW_IMAGE --build-info
sha256sum NEW_IMAGE
python3 run_native_pair_probe.py --repo MATCHING_WORKTREE --executable NEW_IMAGE --output NEW_JSON
```

The measured native order is A-B-B-A. Each combined native-WGPU/CUDA runner is
terminal before the next begins. Six fixed controls never enter the policy;
only the 16 real, correctness-gated observations per request do. CUDA uses the
unchanged exact-source-index validator and records stable-sort/topk selection.
These are separate process blocks, not interleaved backend timings. The GPU
checks are point observations, not continuous monitoring. Private status
session listings are excluded; only GPU observations and original hashes remain.

## Replay

```sh
python -I analyze_pairs.py --repo /path/to/SpiralTorch --output recomputed.json
```

Replay uses the unchanged benchmark validators and standard library, with no
Torch/GPU/browser requirement. Binaries, wheels and generated modules are not
embedded in the archive. Negative candidates and unchanged/slower cells remain.
