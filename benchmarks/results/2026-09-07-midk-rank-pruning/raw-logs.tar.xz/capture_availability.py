"""Publish GPU-only observations; retain unrelated session listings locally."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
records = []
for path in sorted(root.glob("furnace-*.log")):
    raw = path.read_bytes()
    lines = raw.decode().splitlines()
    start = next(i for i, line in enumerate(lines) if " gpu " in line)
    stop = next(i for i, line in enumerate(lines) if " tmux " in line)
    gpu = lines[start + 1:stop]
    if "(no compute processes)" not in gpu:
        raise ValueError(f"nonempty GPU observation: {path.name}")
    records.append(dict(event=path.stem, original_status_sha256=hashlib.sha256(raw).hexdigest(),
                        remote_uptime=next(line for line in lines if line.startswith("uptime")),
                        gpu=gpu))
if len(records) != 7:
    raise ValueError("missing availability checkpoints")
with (root / "gpu-availability.json").open("x") as stream:
    json.dump(dict(schema="spiraltorch.gpu_availability_observations.v1", observations=records,
                   scope="Point-in-time availability, not continuous monitoring.",
                   privacy="Full status logs remain local; unrelated tmux session listings are not published."),
              stream, indent=2)
    stream.write("\n")
