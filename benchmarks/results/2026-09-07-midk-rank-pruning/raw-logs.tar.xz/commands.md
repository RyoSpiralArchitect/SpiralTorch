# MidK Rank-Bound Pruning

Baseline: 1682ee04951f664677206e176343c4ad9a643d6e.
Candidate: 09c64a7fe2624828b26f8e60b5cd478111f229b8.
The incremental source-candidate.bundle requires the baseline commit.
No measured sources or products were changed during a run. Later repository
commits add evidence and documentation only.

The candidate only adds a partial-rank upper-bound condition to the shared
parallel MidK shader. All remaining predecessor counts are nonnegative. A
candidate whose partial rank is already at least rank_end cannot be retained.
The <=32-tile route, workgroup geometry, allocation, dispatch count, output
ordering, client APIs and policy rewards are unchanged.

## Local Build And Validation

Use the isolated worktree and private Python/browser dependencies. Rust 1.98.0,
formatter nightly-2026-04-15, wasm-bindgen 0.2.104; release WASM and wheel products
were copied to distinct source-named directories before any timing.

```sh
cargo +1.98.0 build --manifest-path bindings/st-wasm/Cargo.toml --target wasm32-unknown-unknown --features webgpu --release
wasm-bindgen TARGET/wasm32-unknown-unknown/release/spiraltorch_wasm.wasm --target web --out-dir FROZEN_WEB
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 cargo +1.98.0 test -p st-backend-wgpu --lib --test wgsl_syntax -- --test-threads=1
cargo +1.98.0 clippy -p st-backend-wgpu --all-targets -- -D warnings
cargo +1.98.0 clippy -p st-backend-wgpu --target wasm32-unknown-unknown --all-targets -- -D warnings
maturin build --locked --release --manifest-path bindings/st-py/Cargo.toml --features wgpu-rt --interpreter PRIVATE_PYTHON --out WHEELS
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 PRIVATE_PYTHON -I -m pytest --import-mode=importlib -q bindings/st-py/tests/test_wgpu_rank.py bindings/st-py/tests/test_wgpu_resident.py bindings/st-py/tests/test_spiralk_rank_tile.py bindings/st-py/tests/test_resident_rank_adaptation.py bindings/st-py/tests/test_wgpu_rank_reports.py bindings/st-py/tests/test_wgpu_rank_profile.py
node bindings/st-wasm/tests/resident_types.cjs FROZEN_WEB/spiraltorch_wasm.d.ts
NODE_PATH=PRIVATE_PLAYWRIGHT node tools/test_resident_browser.cjs CANDIDATE_WEB CHROME NEW_OUTPUT '' '' '' '' rank-pruning-matched BASELINE_WEB
```

The measured browser order is A/B, A/A, A/B. Each separate browser process
finishes before the next starts. A/A passes the baseline directory for both
arms. The unchanged runner also executes the rank and rank-profile fixtures
without a baseline argument. The benchmark uses three fixed seeds (one quantized)
and the old 44-case boundary suite remains available as rank-matched. Hashes
bind served assets and the common fixture; browser adapter names are anonymous.
Normal desktop applications were not stopped. No same-host build overlapped
timing, and no second owned GPU process overlapped any validation or benchmark.

## Furnace Native And CUDA

The peer was rechecked after its earlier training finished: GPU utilization 0%,
no compute processes. Before EACH subsequent GPU launch, inspect spiral status
in a separate step. Do not chain an unconditional launch to that observation.
Existing CPU llama-server and system configuration were left unchanged.

Use separate clean worktrees and the private Rust 1.98.1/Cargo toolchain with
four build jobs. Build each source, then install its executable with mode 555
into the dedicated log directory before building the other source. Never run
the benchmark directly from the shared Cargo target directory.

```sh
cargo +1.98.1 build -p st-core --no-default-features --features wgpu-rt,kdsl --example resident_rank_adaptation_bench --release
install -m 555 TARGET/release/examples/resident_rank_adaptation_bench IMMUTABLE_EXECUTABLE
IMMUTABLE_EXECUTABLE --build-info
sha256sum IMMUTABLE_EXECUTABLE
python3 run_native_pruning_probe.py --repo MATCHING_WORKTREE --executable IMMUTABLE_EXECUTABLE --output NEW_OUTPUT
```

The native order is baseline, candidate, candidate, baseline. Each full native
plus CUDA process ends before the next run. Do not use -I for this launcher:
Furnace PyTorch is installed in its existing user site. The runner uses the
unchanged source/build/receipt/correctness validator, with three seeds and 24
bounded requests. Both hosts subsequently pass the live backend tests above.
Availability and the runner's start/end contention gates are point observations,
not a continuous GPU process monitor. gpu-availability.json preserves GPU-only
observations and original status hashes; full status logs, including unrelated
session listings, remain private on the local host and are not in this archive.

## Replay

After extraction, use a checkout containing the unchanged benchmark helpers
from the candidate source. No GPU, browser or Torch installation is needed:

```sh
python -I analyze_pruning.py --repo /path/to/SpiralTorch --output recomputed.json
```

Large compiled products are excluded. Native artifacts bind clean source/build
identity and executable hashes. Python/WASM attribution is build logs and product
hashes, not embedded Git attestation. Package capture byte-checks the installed
extension against the wheel. The replay retains every measured cell, including
slow controls, and does not reinterpret fixed-control samples as policy feedback.
