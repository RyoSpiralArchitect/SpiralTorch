"""Replay matched browser MidK controls without claiming CUDA or GPU-event time."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

BASELINE = "1682ee04951f664677206e176343c4ad9a643d6e"
CANDIDATE = "09c64a7fe2624828b26f8e60b5cd478111f229b8"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def capture(root):
    products = {}
    for name, source, folder in [
        ("baseline", BASELINE, "web-baseline-1682ee04"),
        ("candidate", CANDIDATE, "web-candidate-09c64a7f"),
    ]:
        require((root / f"{name}-source.txt").read_text().strip() == source, "source")
        require(not (root / f"{name}-dirty.txt").read_text().strip(), "clean source")
        require("profile [optimized] target(s)" in (root / f"{name}-wasm-build.log").read_text(), "completed build")
        directory = root / folder
        assets = {str(p.relative_to(directory)): digest(p) for p in sorted(directory.rglob("*")) if p.is_file()}
        require(all(key in assets for key in ("spiraltorch_wasm.js", "spiraltorch_wasm_bg.wasm")), "WASM products")
        products[name] = dict(source=source, assets=assets)
    require(products["candidate"]["assets"]["spiraltorch_wasm_bg.wasm"] != products["baseline"]["assets"]["spiraltorch_wasm_bg.wasm"], "distinct modules")
    write(root / "products.json", dict(schema="spiraltorch.pruning_products.v1", products=products,
          attribution="clean source snapshot plus build logs and product hashes, not an embedded Git attestation"))


def requests():
    result = []
    for seed in (17, 29, 43):
        for rows, cols, tile in [(2, 1023, 32), (2, 4095, 128), (2, 8191, 256),
                                 (2, 8193, 512), (2, 16383, 512), (64, 8191, 256), (2, 8193, 256)]:
            for k in (7, 65):
                result.append(dict(kind="midk", rows=rows, cols=cols, k=k, tile_cols=tile, seed=seed))
        for k in (7, 1024):
            result.append(dict(kind="midk", rows=2, cols=1024, k=k, tile_cols=1024, seed=seed))
        for kind in ("topk", "bottomk"):
            result.append(dict(kind=kind, rows=2, cols=8191, k=65, tile_cols=256, seed=seed))
    return result


def group(request):
    tiles = math.ceil(request["cols"] / request["tile_cols"])
    if request["kind"] != "midk" or tiles > 32:
        return "unchanged_route"
    if tiles == 1:
        return "single_tile_control"
    return "parallel_midk_64_rows" if request["rows"] == 64 else "parallel_midk_2_rows"


def spread(values):
    return dict(min=min(values), median=statistics.median(values), max=max(values))


def analyze(root):
    products = json.loads((root / "products.json").read_text())["products"]
    require(products["baseline"]["source"] == BASELINE and products["candidate"]["source"] == CANDIDATE, "source attribution")
    summaries = {}
    fixture_digest = None
    for name, filename, candidate in [("ab_first", "browser-ab-first.json", "candidate"),
                                       ("aa_control", "browser-aa.json", "baseline"),
                                       ("ab_repeat", "browser-ab-repeat.json", "candidate")]:
        report = json.loads((root / filename).read_text())
        require(report["status"] == "passed" and not report["page_errors"], "browser completed without error")
        require(report["fixture_request"] == "rank-pruning-matched" and report["fixture_suite"] == "pruning", "suite")
        require((report["repetitions"], report["warmup_batches"], report["retained_batches"]) == (64, 4, 16), "timing boundary")
        require(len(report["cases"]) == 54, "case cardinality")
        require(not any("Invalid CommandBuffer" in m["text"] or "Cannot allocate sample buffer" in m["text"]
                        for m in report["console_messages"]), "no invalid GPU submission")
        if fixture_digest is None:
            fixture_digest = report["page_sha256"]
        require(report["page_sha256"] == fixture_digest, "identical fixture")
        for url, value in report["asset_sha256"].items():
            arm = "baseline" if url.startswith("/baseline/") else candidate if url.startswith("/module/") else None
            if arm:
                require(products[arm]["assets"][url.split("/", 2)[2]] == value, "served asset identity")
        cells, groups = [], {}
        for case_index, (case, request) in enumerate(zip(report["cases"], requests())):
            require(case["status"] == "passed" and {key: case[key] for key in request} == request, "case identity")
            samples = case["samples"]
            require(len(samples) == 16, "retained samples")
            for batch, sample in enumerate(samples):
                expected_order = ["baseline", "candidate"] if (case_index + batch) % 2 == 0 else ["candidate", "baseline"]
                require(sample["order"] == expected_order, "alternating arms")
                require(all(math.isfinite(sample[key]) and sample[key] > 0
                            for key in ("baseline_ms", "candidate_ms")), "finite positive host timings")
            baseline = statistics.mean(sample["baseline_ms"] for sample in samples)
            measured = statistics.mean(sample["candidate_ms"] for sample in samples)
            ratio = measured / baseline
            category = group(request)
            groups.setdefault(category, []).append(ratio)
            cells.append(dict(**request, group=category, baseline_mean_us=baseline * 1000,
                              candidate_mean_us=measured * 1000, candidate_over_baseline=ratio))
        summaries[name] = dict(cases=54, groups={key: spread(values) for key, values in groups.items()},
                               browser=report["browser_version"], adapters=report["adapters"], cells=cells)
    return dict(schema="spiraltorch.midk_pruning_browser.v1", status="passed",
                executable_sources=dict(baseline=BASELINE, candidate=CANDIDATE), fixture_sha256=fixture_digest,
                experiments=summaries,
                limitations=["Host API plus completion-fence timing, not GPU events or model quality.",
                             "Three deterministic seeds, one quantized; repeated arms/batches are not extra seeds.",
                             "A/A spread and unchanged routes remain visible; do not claim all-shape speedups.",
                             "Browser adapter identity may be anonymous; no physical GPU identity or CUDA comparison is inferred.",
                             "Native/CUDA controls are reported separately; do not transfer browser effect sizes between devices.",
                             "No tile-policy or reward change; these fixed controls do not generate policy feedback."],
                raw_sha256={p.name: digest(p) for p in sorted(root.iterdir())
                            if p.is_file() and p.name not in ("summary.json", "recomputed.json")})


def write(path, data):
    with path.open("x") as stream:
        json.dump(data, stream, indent=2, allow_nan=False)
        stream.write("\n")


def verification(root):
    import sys
    sys.path.insert(0, str(root))
    from analyze_review import validate_profile
    availability = json.loads((root / "gpu-availability.json").read_text())
    require(len(availability["observations"]) == 7 and
            all("(no compute processes)" in r["gpu"] for r in availability["observations"]), "availability checkpoints")
    for name in ("backend-frozen-mac.log", "backend-furnace.log"):
        log = (root / name).read_text()
        require("93 passed; 0 failed" in log and "all_backend_shaders_parse ... ok" in log, "live backend tests")
        require("parallel_midk_rank_bounds_preserve_total_order_when_enabled ... ok" in log, "rank-bound regression")
    require("103 passed" in (root / "python.log").read_text(), "packaged Python tests")
    for name in ("clippy-native.log", "clippy-wasm.log"):
        require("Finished" in (root / name).read_text(), "strict Clippy completion")
    require("shipped resident rank/profile TypeScript contract passed" in (root / "typescript.log").read_text(), "type contract")
    products = json.loads((root / "products.json").read_text())["products"]
    python = json.loads((root / "python-products.json").read_text())
    require(python["status"] == "passed" and python["source"] == CANDIDATE, "packaged product source")
    require(python["wasm_assets"] == products["candidate"]["assets"] and
            python["baseline_wasm_assets"] == products["baseline"]["assets"], "product consistency")
    reports = {}
    for name, count in (("standard", 71), ("profile", 12)):
        report = json.loads((root / f"browser-{name}.json").read_text())
        require(report["status"] == "passed" and not report["page_errors"] and len(report["cases"]) == count, "browser validation")
        for url, value in report["asset_sha256"].items():
            if url.startswith("/module/"):
                require(products["candidate"]["assets"][url.removeprefix("/module/")] == value, "validation module")
        reports[name] = report
    profile = reports["profile"]
    require(profile["maximum_repetitions"]["status"] == "passed", "rank-only maximum repetitions")
    require(profile["publication_validation"]["status"] == "passed", "real invalid query rejection")
    for key in ("internal_validation", "scope_rejection"):
        require(profile[key]["status"] == "passed" and profile[key]["output_current_after_read"] is False, "failed publication")
    profiles = [batch["profiled"]["gpu"] for case in profile["cases"] for batch in case["batches"]]
    profiles.append(profile["maximum_repetitions"]["profile"])
    require(len(profiles) == 145, "profile cardinality")
    for value in profiles:
        validate_profile(value)
    return dict(native_tests_per_host=93, packaged_python_tests=103, browser_standard_cases=71,
                browser_profile_cases=12, validated_timestamp_profiles=145,
                rank_bound_regression_geometries=8, rank_bound_regression_patterns=6,
                rank_bound_regression_k_values_per_geometry=3)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--capture-products", action="store_true")
    action.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    if args.capture_products:
        capture(root)
        return
    summary = analyze(root)
    if args.repo is None:
        parser.error("--repo is required for comparison replay")
    import sys
    sys.path.insert(0, str(root))
    from analyze_native_pruning import analyze_native
    summary["schema"] = "spiraltorch.midk_pruning_comparison.v1"
    summary["native"] = analyze_native(root, args.repo)
    summary["verification"] = verification(root)
    write(args.output, summary)
    print(json.dumps({name: value["groups"] for name, value in summary["experiments"].items()}, indent=2))


if __name__ == "__main__":
    main()
