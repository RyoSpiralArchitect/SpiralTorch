"""Revalidate source-bound ABBA controls and real Rust policy feedback."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics as stats
import sys


def require(value, message):
    if not value:
        raise ValueError(message)


def spread(values):
    return dict(min=min(values), median=stats.median(values), max=max(values))


def analyze_native(root, repo):
    sys.path.insert(0, str(repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    import bench_resident_rank_adaptation_vs_torch as adaptation
    path = root / "run_native_pruning_probe.py"
    spec = importlib.util.spec_from_file_location("pruning_probe", path)
    probe = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(probe)
    requests = list(probe.requests(audit.load_bench_module()))
    require(len(requests) == 24, "native fixture cardinality")
    payload = "".join(json.dumps(r, allow_nan=False) + "\n" for r, _ in requests)
    request_digest = hashlib.sha256(payload.encode()).hexdigest()
    source = dict(baseline="1682ee04951f664677206e176343c4ad9a643d6e",
                  candidate="09c64a7fe2624828b26f8e60b5cd478111f229b8")
    arms = {}
    for name, kind in [("a1-baseline", "baseline"), ("b1-candidate", "candidate"),
                       ("b2-candidate", "candidate"), ("a2-baseline", "baseline")]:
        report = json.loads((root / f"native-{name}.json").read_text())
        require(report["status"] == "passed" and report["provenance"]["valid"], "native run validity")
        require(report["source"]["commit"] == source[kind], "native source")
        require(audit.validate_source_binding(report["native_build_identity"], report["source"])["valid"], "build binding")
        require(report["native_build_identity"] == json.loads((root / f"native-{kind}-build-info.json").read_text()), "frozen build")
        executable = report["provenance"]["executable"]
        require(executable["sha256"] == (root / f"native-{kind}-sha256.txt").read_text().split()[0], "frozen executable")
        require(report["provenance"]["execution_image"]["sha256"] == executable["sha256"], "executed bytes")
        require(executable["mode"] & 0o222 == 0, "immutable executable")
        require(report["request_sha256"] == request_digest and len(report["cases"]) == 24, "native requests")
        require(report["exploratory_probe"]["runner_sha256"] == hashlib.sha256(path.read_bytes()).hexdigest(), "runner identity")
        cells = []
        for case, (request, tiles) in zip(report["cases"], requests):
            require(case["request"] == {k: v for k, v in request.items() if k != "input"} and case["tiles"] == tiles, "request identity")
            adaptation.validate_native(case["native"], request, tiles)
            require(case["native"]["adapter"]["name"] == report["torch_device"], "same named GPU")
            require(case["torch_operation"] == "stable_sort", "canonical CUDA ordering")
            values, indices = [], []
            for row in range(request["rows"]):
                data = request["input"][row * request["cols"]:(row + 1) * request["cols"]]
                require(all(math.isfinite(v) for v in data), "finite CUDA fixture")
                start = (len(data) - request["k"]) // 2
                selected = sorted(range(len(data)), key=lambda i: (data[i], i))[start:start + request["k"]]
                values.extend(data[i] for i in selected)
                indices.extend(selected)
            require(case["native"]["values"] == values and case["native"]["indices"] == indices, "canonical native output")
            timings = case["native"]["control_samples_per_op_ms"]
            cuda = case["torch_timing"]["median_ms"]
            require(math.isfinite(cuda) and cuda > 0, "CUDA timing")
            means = {str(tile): stats.mean(samples) for tile, samples in zip(tiles, timings)}
            require(all(value > 0 for value in means.values()), "positive native timings")
            cells.append(dict(rows=request["rows"], cols=request["cols"], k=request["k"], seed=request["seed"],
                              mean_ms_by_tile=means, cuda_median_ms=cuda,
                              hindsight_best_fixed_over_cuda=min(stats.median(samples) for samples in timings) / cuda))
        arms[name] = dict(source=report["source"]["commit"], cases=24, observations=384,
                          torch=report["torch"], device=report["torch_device"], cells=cells)
    comparisons = {}
    for name, base, candidate in [("first_pair", "a1-baseline", "b1-candidate"),
                                  ("reverse_pair", "a2-baseline", "b2-candidate")]:
        cells, groups = [], {}
        for a, b in zip(arms[base]["cells"], arms[candidate]["cells"]):
            request = {k: a[k] for k in ("rows", "cols", "k", "seed")}
            require(all(b[k] == value for k, value in request.items()), "matched native cells")
            for tile, value in a["mean_ms_by_tile"].items():
                ratio = b["mean_ms_by_tile"][tile] / value
                group = f"parallel_rows_{a['rows']}" if math.ceil(a["cols"] / int(tile)) <= 32 else "unchanged_route"
                groups.setdefault(group, []).append(ratio)
                cells.append(dict(**request, tile_cols=int(tile), group=group, candidate_over_baseline=ratio))
        comparisons[name] = dict(groups={k: spread(v) for k, v in groups.items()}, cells=cells)
    return dict(status="passed", cases=96, real_rust_observations=1536, request_sha256=request_digest,
                order=["a1-baseline", "b1-candidate", "b2-candidate", "a2-baseline"], arms=arms,
                comparisons=comparisons, limitations=[
                    "Source ABBA uses separate process blocks, not interleaved framework batches or GPU events.",
                    "Three seeds, one UCB policy, 16 actual observations per case; fixed controls do not seed feedback.",
                    "The native matrix differs from the browser matrix; do not combine their effect sizes.",
                    "Hindsight-best fixed tiles are not guaranteed online policy choices.",
                    "GPU availability was inspected before each launch; runner gates contention before and after the combined run, not continuously.",
                    "An existing CPU llama-server was left unchanged; no system or external workload changes were made."])
