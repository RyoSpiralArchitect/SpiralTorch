"""Matched pruning controls using the unchanged native/CUDA feedback benchmark."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def requests(bench):
    shapes = [(rows, cols) for rows in (2, 4) for cols in (8193, 16385, 32769)]
    shapes += [(64, 8193), (512, 1025)]
    for seed in (17, 29, 43):
        for rows, cols in shapes:
            if rows * cols > 1_048_576:
                raise ValueError("probe exceeds the existing native request bound")
            values, _ = bench.fixture(rows * cols, seed)
            if seed == 43:
                values = [float(int(value * 8)) for value in values]
            tiles = [32, 128, 256, 512]
            rotation = seed % len(tiles)
            tiles = tiles[rotation:] + tiles[:rotation]
            scripts = [f"u2: true; rank_tile: {tile}; ctile: {tile};" for tile in tiles]
            yield dict(kind="midk", rows=rows, cols=cols, k=65, scripts=scripts,
                       input=values, seed=seed, policy="ucb", rounds=16), tiles


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--executable", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    import bench_resident_rank_adaptation_vs_torch as adaptation

    # Only the bounded fixture matrix changes. Native execution, source binding,
    # correctness gates, feedback receipts and sequential CUDA timing are reused.
    adaptation.requests = requests
    report = adaptation.run(args.executable.resolve(strict=True))
    report["exploratory_probe"] = dict(
        schema="spiraltorch.rank_pruning_probe.v1",
        runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        purpose="Compare a frozen early-exit candidate with unchanged merge routing and tile controls.",
        constraints="Native request bound unchanged; three seeds, one policy, 16 observations per case; fixed controls are not policy feedback.",
        interpretation="One source-bound arm; compare matched arms before making a speedup claim, not a model-quality result.")
    audit.write_report_exclusive(args.output, report)
    print(json.dumps({"status": report["status"], "cases": len(report["cases"]), "error": report.get("error")}))
    raise SystemExit(report["status"] != "passed")


if __name__ == "__main__":
    main()
