"""Append selected-source checks/timings; never replace the rejected browser trial."""
import hashlib
import json
import lzma
import math
from pathlib import Path
import statistics
import subprocess

ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG=Path(__file__).parent
OUT=ROOT/'benchmarks/results/2026-09-10-graph-training-forward-pass'
read=lambda path:json.loads(path.read_bytes())
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
receipt=read(LOG/'selected-checks/receipt.json')
assert receipt['status']=='passed' and len(receipt['steps'])==19
assert all(s['exit_code']==0 for s in receipt['steps'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==receipt['source']
for path,sha in receipt['products'].items(): assert digest(Path(path))==sha,path
reports={matrix:read(LOG/f'selected-checks/{matrix}/validation.json') for matrix in ['standard','wide']}
assert all(r['status']=='passed' and len(r['cases'])==9 for r in reports.values())
summary=dict(schema='spiraltorch.graph_training_forward_pass.selected.v1',status='passed',source=receipt['source'],
             policy=receipt['policy'],matrices={},correctness={},raw_intervals=1800,retained_intervals=1440,
             real_sgd_updates_in_timed_intervals=14400,source_files={},
             boundary='Fresh products of the selected revision; one further full round, separate from the two exploratory rounds. No automatic ModuleTrainer route or application-quality claim.')
for matrix,report in reports.items():
    rows=report['cases'];result={}
    for client in ['native','browser']:
        for cadence in ['immediate','deferred']:
            ratios=[row[client][cadence]['baseline_over_candidate'] for row in rows]
            entry=dict(baseline_over_selected_geomean=math.exp(statistics.mean(map(math.log,ratios))),
                       range=[min(ratios),max(ratios)],faster_cases=sum(r>1 for r in ratios),paired_case_medians=len(ratios))
            if client=='native':
                r=[row[client][cadence]['torch_over_candidate'] for row in rows]
                entry['torch_over_selected_geomean']=math.exp(statistics.mean(map(math.log,r)))
            result[client+'_'+cadence]=entry
    result['max_abs_error']=max(value for row in rows for value in row['max_abs_errors'].values())
    result['loss_decreased_cases']=sum(row['losses'][-1]<row['losses'][0] for row in rows)
    summary['matrices'][matrix]=result
torch=read(LOG/'selected-checks/torch-correctness.json');py=read(LOG/'selected-checks/python-tests.json')
assert torch['status']==py['status']=='passed' and len(torch['cases'])==24 and py['tests']==30 and py['skipped']==0
summary['correctness']=dict(backend_serial_tests=112,nn_unit_tests=733,native_integration_tests=6,python_gpu_tests=30,python_skips=0,
    torch_replays=24,torch_comparisons=sum(c['comparisons'] for c in torch['cases']),masked_guard_cases=64,
    max_abs_torch_error=max(c['max_abs_error'] for c in torch['cases']),backend_strict_clippy=['native','wasm32'],admission_tests=10)
for name in ['crates/st-backend-wgpu/src/resident_training/graph.rs','crates/st-nn/examples/support/resident_graph_training.rs',
    'bindings/st-wasm/tests/resident_graph_training.html','tools/bench_resident_training_vs_torch.py',
    'tools/bench_resident_training_browser.cjs','tools/validate_resident_training_bench.py','bindings/st-wasm/tests/resident_training_bench.html',
    'tests/test_resident_training_bench.py']:
    summary['source_files'][name]=digest(ROOT/name)
print('SUMMARY',json.dumps(summary['matrices']),flush=True)
paths=sorted(p for directory in [LOG/'selected',LOG/'selected-checks'] for p in directory.rglob('*')
             if p.is_file() and p.suffix in ['.json','.jsonl','.log'] and not p.name.endswith('.cases.jsonl'))
paths.extend([Path(__file__),LOG/'selected-path-checks.py'])
entries=[]
for path in paths:
    original=str(path.relative_to(LOG));dest=OUT/'raw/selected-final'/(original+'.xz');dest.parent.mkdir(parents=True,exist_ok=True)
    h=hashlib.sha256();size=0
    with path.open('rb') as source, lzma.open(dest,'xb',filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024*1024)]) as target:
        while chunk:=source.read(1024*1024): h.update(chunk);size+=len(chunk);target.write(chunk)
    v=hashlib.sha256()
    with lzma.open(dest,'rb') as stream:
        while chunk:=stream.read(1024*1024): v.update(chunk)
    assert v.hexdigest()==h.hexdigest() and dest.stat().st_size<95*1024*1024
    entries.append(dict(path=str(dest.relative_to(OUT)),original_name=original,bytes=size,sha256=h.hexdigest(),compressed_sha256=digest(dest)))
    print('PACKED',original,dest.stat().st_size,flush=True)
for name,value in [('selected-summary.json',summary),('selected-manifest.json',dict(schema='spiraltorch.hash_archive.v1',entries=entries))]:
    with (OUT/name).open('x') as output: json.dump(value,output,indent=2,allow_nan=False);output.write('\n')
print(json.dumps(dict(artifacts=len(entries),compressed_bytes=sum((OUT/e['path']).stat().st_size for e in entries))),flush=True)
