"""Freeze clean native/browser products before any timing; never overlap builds."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
TARGET = ROOT.parent/'spiraltorch-spiralk-golden-blackcat-contract-v1/target'
LOG = Path(__file__).parent
OUT = LOG/sys.argv[1]
OUT.mkdir()
BINDGEN = '/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen'
env = dict(os.environ, CARGO_BUILD_JOBS='4', CARGO_TARGET_DIR=str(TARGET),
           SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1')
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = dict(commit=git('rev-parse','HEAD'), tree=git('rev-parse','HEAD^{tree}'))
assert not git('status','--porcelain'), 'build source must be clean'
report = dict(status='error', source=source, steps=[], products={})

def run(name, args):
    print('START', name, flush=True)
    start = time.monotonic()
    with (OUT/(name+'.log')).open('xb') as stream:
        p = subprocess.run(args, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    report['steps'].append(dict(name=name, command=args, exit_code=p.returncode, seconds=time.monotonic()-start))
    (OUT/'build-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print('END',name,p.returncode,flush=True)
    if p.returncode: raise RuntimeError(name)

try:
    run('native-build',['cargo','+1.98.0','build','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu',
        '--example','resident_training_bench','--example','resident_graph_training'])
    for name in ['resident_training_bench','resident_graph_training']:
        dest=OUT/name
        shutil.copyfile(TARGET/'release/examples'/name,dest)
        dest.chmod(0o555)
    run('wasm-build',['cargo','+1.98.0','build','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu',
        '--target','wasm32-unknown-unknown','--example','resident_training_bench_browser','--example','resident_graph_training_browser'])
    for name,folder in [('resident_training_bench_browser','bench'),('resident_graph_training_browser','correctness')]:
        run(name+'-bindgen',[BINDGEN,str(TARGET/'wasm32-unknown-unknown/release/examples'/(name+'.wasm')),
            '--target','web','--out-dir',str(OUT/folder),'--out-name','spiraltorch_wasm'])
    for file in OUT.rglob('*'):
        if file.is_file() and file.suffix not in ['.log','.json']:
            report['products'][str(file.relative_to(OUT))]=digest(file)
    assert git('rev-parse','HEAD')==source['commit'] and not git('status','--porcelain'), 'source drift'
    report['status']='passed'
except Exception as error:
    report['error']=repr(error)
    raise
finally:
    (OUT/'build-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
