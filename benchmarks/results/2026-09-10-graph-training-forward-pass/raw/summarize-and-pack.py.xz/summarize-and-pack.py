"""Reaggregate every validated case; losslessly archive raw evidence after timing."""
import hashlib
import json
import lzma
import math
from pathlib import Path
import statistics
import subprocess

ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG=Path(__file__).parent
OUT=ROOT/'benchmarks/results/2026-09-10-graph-training-forward-pass'
read=lambda path:json.loads(path.read_bytes())
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
receipt=read(LOG/'measurement/receipt.json')
prior=read(LOG/'verification/receipt.json')
assert receipt['status']=='passed' and len(receipt['steps'])==14
assert all(step['exit_code']==0 for step in receipt['steps'])
assert prior['status']=='error' and prior['steps'][-1]['name']=='browser-correctness'
assert all(step['exit_code']==0 for step in prior['steps'][:-1])
for path,sha in {**receipt['products'],**receipt['inputs']}.items(): assert digest(Path(path))==sha,path
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==receipt['harness_source']
reports=[(matrix,round_number,read(LOG/f'measurement/{matrix}-{round_number}/validation.json')) for matrix in ['standard','wide'] for round_number in [1,2]]
assert all(r['status']=='passed' and len(r['cases'])==9 for _,_,r in reports)
geomean=lambda values:math.exp(statistics.mean(math.log(value) for value in values))
matrix_results={}
for matrix in ['standard','wide']:
    rows=[row for m,_,r in reports if m==matrix for row in r['cases']]
    result={}
    for client in ['native','browser']:
        for cadence in ['immediate','deferred']:
            ratios=[row[client][cadence]['baseline_over_candidate'] for row in rows]
            entry=dict(baseline_over_candidate_geomean=geomean(ratios),range=[min(ratios),max(ratios)],
                       faster_cases=sum(ratio>1 for ratio in ratios),paired_case_medians=len(ratios))
            if client=='native':
                values=[row[client][cadence]['torch_over_candidate'] for row in rows]
                entry['torch_over_candidate_geomean']=geomean(values)
                entry['torch_over_candidate_range']=[min(values),max(values)]
            result[client+'_'+cadence]=entry
    table=[]
    for shape in sorted({tuple(row['config']['shape']) for row in rows}):
        values=[row for row in rows if tuple(row['config']['shape'])==shape]
        assert len(values)==6
        item=dict(shape=shape,depth=values[0]['config']['depth'],measurements={})
        for client in ['native','browser']:
            for cadence in ['immediate','deferred']:
                item['measurements'][client+'_'+cadence]={lane:statistics.median(row[client][cadence]['lanes'][lane]['median_ms']/8 for row in values)
                    for lane in (['baseline','candidate','torch'] if client=='native' else ['baseline','candidate'])}
        table.append(item)
    result['per_shape_median_ms_per_step']=table
    result['loss_decreased_cases']=sum(row['losses'][-1]<row['losses'][0] for row in rows)
    matrix_results[matrix]=result
torch=read(LOG/'measurement/torch-correctness.json')
python=read(LOG/'verification/python-tests.json')
assert python['status']=='passed' and python['tests']==30 and python['skipped']==0
assert torch['status']=='passed' and len(torch['cases'])==24
summary=dict(schema='spiraltorch.graph_training_forward_pass.evidence.v1',status='bounded_training_optimization_validated',
    baseline=read(LOG/'baseline-isolated/build-receipt.json')['source'],candidate=read(LOG/'candidate/build-receipt.json')['source'],
    harness_source=receipt['harness_source'],matrices=matrix_results,
    change='Batch mixed graph forward on Metal/BrowserWebGpu; unchanged loss, VJP, unbroadcast, validation copy, prepare/vote/commit and specialized dense training.',
    source_files_at_candidate={},
    max_abs_benchmark_error=max(value for _,_,r in reports for row in r['cases'] for value in row['max_abs_errors'].values()),
    native_device=reports[0][2]['device_admission'],browser_physical_gpu='UNKNOWN',gpu_contention='UNKNOWN',
    torch=reports[0][2]['torch'],browser_version=reports[0][2]['browser_version'],
    counts=dict(reports=8,raw_intervals=3600,retained_intervals=2880,real_sgd_updates_in_all_timed_intervals=28800),
    validation=dict(backend_serial_tests=112,nn_serial_tests=733,python_gpu_tests=30,python_gpu_skips=0,
        native_and_browser_masked_fault_cases=64,torch_replays=24,torch_comparisons=sum(c['comparisons'] for c in torch['cases']),
        max_abs_torch_replay_error=max(c['max_abs_error'] for c in torch['cases']),admission_tests=10,
        backend_strict_clippy=['native','wasm32'],cpu_feature_check='passed'),
    failures_preserved=['Test fixture E0502 borrow error before runtime, fixed; summarized in development-notes.md.',
        'Browser admission page expected four guards instead of the new 36; original failed receipt/report retained; no timing had started.',
        'Prior one-off default-parallel GPU VJP failure remains UNKNOWN, not fixed or proven pre-existing.',
        'Prior broad NN strict Clippy failure on 22 unchanged library lints was not re-run or fixed in this slice.'],
    boundaries=['Fixed diagnostic mixed MLPs, not an application learning-quality comparison or automatic ModuleTrainer route.',
        'Each interval resets to the same frozen weights; eight SGD updates, not one continuous long run.',
        'Two warmup and eight retained rotated blocks per cadence, three seeds, two full rounds; samples are correlated.',
        'Immediate reads each loss; deferred reads all owning loss snapshots after enqueue; uploads, setup and final VJP probes excluded.',
        'Torch eager MPS has no equivalent per-stage finite checks or graph-atomic rollback; no fastest-Torch claim or Torch CPU timing.',
        'Native and browser wall times are not a direct cross-client performance comparison.',
        'No CUDA measurement, unmeasured backends changed, push, merge or release.'])
base='9e567e82eb93cfae016001311e994021dd4d402e'
changed=subprocess.check_output(['git','diff','--name-only',base,receipt['candidate_source']],cwd=ROOT,text=True).splitlines()
for name in changed:
    data=subprocess.check_output(['git','show',receipt['candidate_source']+':'+name],cwd=ROOT)
    summary['source_files_at_candidate'][name]=hashlib.sha256(data).hexdigest()
print('SUMMARY',json.dumps(matrix_results),flush=True)
OUT.mkdir()
paths=sorted(p for p in LOG.rglob('*') if p.is_file() and p.suffix in ['.json','.jsonl','.log','.py','.md']
             and not p.name.endswith('.cases.jsonl'))
entries=[]
for path in paths:
    original=str(path.relative_to(LOG))
    dest=OUT/'raw'/(original+'.xz');dest.parent.mkdir(parents=True,exist_ok=True)
    # Stream instead of retaining another large copy of wide-matrix captures.
    h=hashlib.sha256();size=0
    with path.open('rb') as source, lzma.open(dest,'xb',filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024*1024)]) as target:
        while chunk:=source.read(1024*1024):
            h.update(chunk);size+=len(chunk);target.write(chunk)
    verify=hashlib.sha256()
    with lzma.open(dest,'rb') as stream:
        while chunk:=stream.read(1024*1024): verify.update(chunk)
    assert h.hexdigest()==verify.hexdigest(),original
    assert dest.stat().st_size<95*1024*1024, 'split oversized archive before publication'
    entries.append(dict(path=str(dest.relative_to(OUT)),original_name=original,bytes=size,sha256=h.hexdigest(),compressed_sha256=digest(dest)))
    print('PACKED',original,size,dest.stat().st_size,flush=True)
manifest=dict(schema='spiraltorch.hash_archive.v1',entries=entries,
              compression='LZMA2 fast preset with a 64 MiB dictionary; decompressed SHA-256 verified for every file',
              omitted='Executables and generated WASM/JS packages: product hashes retained. Duplicate browser .cases.jsonl streams: same complete case objects retained in browser.json.')
for name,value in [('summary.json',summary),('manifest.json',manifest)]:
    with (OUT/name).open('x') as output: json.dump(value,output,indent=2,allow_nan=False);output.write('\n')
print(json.dumps(dict(artifacts=len(entries),compressed_bytes=sum((OUT/e['path']).stat().st_size for e in entries),matrices=matrix_results)),flush=True)
