"""Resume after the browser admission-page fix, preserving the failed attempt."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
BASE = LOG/'baseline-isolated'
CAND = LOG/'candidate'
PREVIOUS = LOG/'verification'
OUT = LOG/'measurement'
OUT.mkdir()
P = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH = '/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
env = dict(os.environ, SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1', PYTORCH_ENABLE_MPS_FALLBACK='0',
           NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = git('rev-parse','HEAD')
assert not git('status','--porcelain')
builds = {lane:json.loads((folder/'build-receipt.json').read_text()) for lane,folder in [('baseline',BASE),('candidate',CAND)]}
candidate_source=builds['candidate']['source']['commit']
assert git('diff','--name-only',candidate_source,source).splitlines()==['bindings/st-wasm/tests/resident_graph_training.html']
prior=json.loads((PREVIOUS/'receipt.json').read_text())
assert prior['source']==candidate_source and prior['status']=='error'
assert prior['steps'][-1]['name']=='browser-correctness' and prior['steps'][-1]['exit_code']==1
assert all(step['exit_code']==0 for step in prior['steps'][:-1])
products={str(folder/name):expected for lane,folder in [('baseline',BASE),('candidate',CAND)] for name,expected in builds[lane]['products'].items()}
products[str(PREVIOUS/'python-release.dylib')]=prior['products']['python-release.dylib']
inputs={str(PREVIOUS/name):digest(PREVIOUS/name) for name in ['receipt.json','native-correctness.json','python-tests.json','browser-correctness.json']}
report=dict(status='error',harness_source=source,candidate_source=candidate_source,prior_receipt_sha256=digest(PREVIOUS/'receipt.json'),steps=[],products=products,inputs=inputs,
            boundary='Only browser correctness admission page changed after the prior checks; compiled products and Rust/Python sources unchanged. No builds/tests overlap timings.')

def run(name,args):
    print('START',name,flush=True)
    start=time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        p=subprocess.run(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    report['steps'].append(dict(name=name,command=args,exit_code=p.returncode,seconds=time.monotonic()-start))
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print('END',name,p.returncode,flush=True)
    if p.returncode: raise RuntimeError(name)

try:
    for path,expected in {**products,**inputs}.items(): assert digest(Path(path))==expected,path
    run('browser-correctness',['node','tools/test_resident_browser.cjs',str(CAND/'correctness'),CHROME,str(OUT/'browser-correctness.json'),'','','','','nn-graph-training'])
    for path in [PREVIOUS/'native-correctness.json',OUT/'browser-correctness.json']:
        value=json.loads(path.read_text())
        rows=[r for r in value['guards'] if r['case']=='masked_forward_overflow']
        assert value['status']=='passed' and len(rows)==32 and len({(r['fault_stage'],r['policy'],r['rate']) for r in rows})==32
        assert all(r['all_parameter_bits_unchanged'] and r['retained_guard_after_reuse_and_drop'] for r in rows)
    run('torch-correctness',[TORCH,'-I','tools/validate_resident_graph_training_vs_torch.py',str(PREVIOUS/'native-correctness.json'),
        str(OUT/'browser-correctness.json'),'--devices','cpu','mps','--output',str(OUT/'torch-correctness.json')])
    for round_number in [1,2]:
        for matrix in (['standard','wide'] if round_number==1 else ['wide','standard']):
            label=matrix+'-'+str(round_number)
            folder=OUT/label; folder.mkdir()
            base_source=builds['baseline']['source']['commit']
            native=[TORCH,'-I','tools/bench_resident_training_vs_torch.py','--graph','--matrix',matrix,'--device','mps',
                '--baseline',str(BASE/'resident_training_bench'),'--baseline-source',base_source,
                '--candidate',str(CAND/'resident_training_bench'),'--candidate-source',candidate_source,'--output',str(folder/'native.json')]
            browser=['node','tools/bench_resident_training_browser.cjs',str(BASE/'bench'),str(CAND/'bench'),CHROME,str(folder/'browser.json'),'graph',matrix]
            lanes=[('native',native),('browser',browser)]
            if round_number==2: lanes.reverse()
            for name,command in lanes: run(label+'-'+name,command)
            run(label+'-validate',[P,'-I','tools/validate_resident_training_bench.py',
                '--native',str(folder/'native.json'),'--browser',str(folder/'browser.json'),'--browser-progress',str(folder/'browser.json.progress.jsonl'),
                '--baseline-source',base_source,'--candidate-source',candidate_source,'--browser-harness-source',source,'--output',str(folder/'validation.json')])
    assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
    for path,expected in {**products,**inputs}.items(): assert digest(Path(path))==expected,path
    report['status']='passed'
except Exception as error:
    report['error']=repr(error)
    raise
finally:
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
