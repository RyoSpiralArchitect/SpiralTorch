# Development Checks

Before any timing, the first new native training regression failed to compile:
E0502 at examples/support/resident_graph_training.rs, reading p.name() inside
a p.value_mut().data_mut().fill(...) argument. The coefficient is now computed
before taking the mutable borrow. This was a test-fixture compile error, not a
GPU runtime failure. The original command output is retained in the thread;
this note is a summary, not a substituted raw log.

The first build-only driver used non-isolated Python and emitted ambient
Spiralton startup messages. No timing occurred in that process. Products were
subsequently frozen again by Python -S in baseline-isolated with the same clean
source; only those products are admitted for the comparison.

The first archival pass (LZMA preset 6, default dictionary) was deliberately
interrupted after benchmarks had completed. A wide browser report alone was
38 MiB compressed because repeated full-state captures exceeded that dictionary.
The partial outputs remain in incomplete-preset6-archive. The replacement uses
a faster 64 MiB dictionary, retains the identical raw input bytes, and verifies
every decompressed hash. This was an archival restart, not a benchmark retry.
