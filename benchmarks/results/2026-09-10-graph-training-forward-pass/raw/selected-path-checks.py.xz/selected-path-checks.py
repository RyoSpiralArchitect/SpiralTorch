"""Verify and remeasure the selected Metal-only policy, not just the trial."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG=Path(__file__).parent
BASE=LOG/'baseline-isolated'
CAND=LOG/'selected'
OUT=LOG/'selected-checks'; OUT.mkdir()
TARGET=ROOT.parent/'spiraltorch-spiralk-golden-blackcat-contract-v1/target'
P='/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
LOADER='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py'
env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_TARGET_DIR=str(TARGET),PYO3_PYTHON=P,
         SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1',PYTORCH_ENABLE_MPS_FALLBACK='0',
         NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=git('rev-parse','HEAD')
assert not git('status','--porcelain')
builds={lane:json.loads((folder/'build-receipt.json').read_text()) for lane,folder in [('baseline',BASE),('selected',CAND)]}
assert all(b['status']=='passed' for b in builds.values()) and builds['selected']['source']['commit']==source
products={str(folder/name):sha for lane,folder in [('baseline',BASE),('selected',CAND)] for name,sha in builds[lane]['products'].items()}
report=dict(status='error',source=source,steps=[],products=products,
            policy='Metal forward batched; BrowserWebGpu and unmeasured backends retain one forward dispatch per pass')

def run(name,args,stdout=None):
    print('START',name,flush=True);start=time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        if stdout:
            with Path(stdout).open('xb') as out:
                p=subprocess.run(args,cwd=ROOT,env=env,stdout=out,stderr=log)
        else: p=subprocess.run(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    report['steps'].append(dict(name=name,command=args,exit_code=p.returncode,seconds=time.monotonic()-start))
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print('END',name,p.returncode,flush=True)
    if p.returncode: raise RuntimeError(name)

try:
    for path,sha in products.items(): assert digest(Path(path))==sha,path
    run('fmt',['cargo','+nightly-2026-04-15','fmt','--all','--','--check'])
    run('admission',[P,'-I','tests/test_resident_training_bench.py','-v'])
    run('backend-serial',['cargo','+1.98.0','test','--locked','--release','-p','st-backend-wgpu','--lib','--','--test-threads=1'])
    run('nn-serial',['cargo','+1.98.0','test','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu','--lib','--','--test-threads=1'])
    run('integration',['cargo','+1.98.0','test','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu',
        '--test','resident_graph_forward','--test','resident_graph_training','--test','resident_nd_tensor','--test','resident_training','--','--test-threads=1'])
    for label,extra in [('native',[]),('wasm',['--target','wasm32-unknown-unknown'])]:
        run(label+'-clippy',['cargo','+1.98.0','clippy','--locked','--release','-p','st-backend-wgpu','--lib',*extra,'--','-D','warnings'])
    run('cpu-check',['cargo','+1.98.0','check','--locked','-p','st-nn','--no-default-features'])
    run('python-build',['cargo','+1.98.0','build','--locked','--release','-p','spiraltorch-py'])
    shutil.copyfile(TARGET/'release/libspiraltorch.dylib',OUT/'python-release.dylib')
    report['products'][str(OUT/'python-release.dylib')]=digest(OUT/'python-release.dylib')
    run('python-tests',[P,'-I',LOADER,str(OUT/'python-release.dylib'),str(ROOT),'tests',str(OUT/'python-tests.json')])
    run('native-correctness',[str(CAND/'resident_graph_training')],stdout=OUT/'native-correctness.json')
    run('browser-correctness',['node','tools/test_resident_browser.cjs',str(CAND/'correctness'),CHROME,str(OUT/'browser-correctness.json'),'','','','','nn-graph-training'])
    for path in [OUT/'native-correctness.json',OUT/'browser-correctness.json']:
        value=json.loads(path.read_text());rows=[r for r in value['guards'] if r['case']=='masked_forward_overflow']
        assert value['status']=='passed' and len(rows)==32 and len({(r['fault_stage'],r['policy'],r['rate']) for r in rows})==32
        assert all(r['all_parameter_bits_unchanged'] and r['retained_guard_after_reuse_and_drop'] for r in rows)
    run('torch-correctness',[TORCH,'-I','tools/validate_resident_graph_training_vs_torch.py',str(OUT/'native-correctness.json'),
        str(OUT/'browser-correctness.json'),'--devices','cpu','mps','--output',str(OUT/'torch-correctness.json')])
    # Selected-path timing starts only after all builds and tests are terminal.
    for matrix in ['standard','wide']:
        folder=OUT/matrix;folder.mkdir()
        base_source=builds['baseline']['source']['commit']
        run(matrix+'-native',[TORCH,'-I','tools/bench_resident_training_vs_torch.py','--graph','--matrix',matrix,'--device','mps',
            '--baseline',str(BASE/'resident_training_bench'),'--baseline-source',base_source,
            '--candidate',str(CAND/'resident_training_bench'),'--candidate-source',source,'--output',str(folder/'native.json')])
        run(matrix+'-browser',['node','tools/bench_resident_training_browser.cjs',str(BASE/'bench'),str(CAND/'bench'),CHROME,str(folder/'browser.json'),'graph',matrix])
        run(matrix+'-validate',[P,'-I','tools/validate_resident_training_bench.py','--native',str(folder/'native.json'),
            '--browser',str(folder/'browser.json'),'--browser-progress',str(folder/'browser.json.progress.jsonl'),
            '--baseline-source',base_source,'--candidate-source',source,'--browser-harness-source',source,'--output',str(folder/'validation.json')])
    assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
    for path,sha in report['products'].items(): assert digest(Path(path))==sha,path
    report['status']='passed'
except Exception as error:
    report['error']=repr(error)
    raise
finally:
    (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
