"""Recompute all case summaries from retained, unmodified comparison reports."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import statistics as stats
import struct
import sys

parser = argparse.ArgumentParser()
parser.add_argument("--repo", type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.repo.resolve() / "tools"))
import bench_resident_rank_adaptation_vs_torch as audit

root = Path(__file__).resolve().parent
names = ["comparison-510a3b04.json", "comparison-repeat-510a3b04.json"]
requests = list(audit.requests(audit.audit.load_bench_module()))
payload = "".join(json.dumps(r, allow_nan=False) + "\n" for r, _ in requests)
request_sha = hashlib.sha256(payload.encode()).hexdigest()
case_rows, by_group, cuda_ratios = [], defaultdict(list), []
for name in names:
    report = json.loads((root / name).read_text())
    assert report["status"] == "passed" and report["provenance"]["valid"]
    assert report["build_source_binding"]["valid"]
    assert report["build_source_binding"]["embedded_commit"] == "510a3b0487ea4959e34071d3e555d1e1191e12b7"
    assert report["request_sha256"] == request_sha
    assert len(report["cases"]) == len(requests) == 36
    for case, (request, tiles) in zip(report["cases"], requests):
        assert case["request"] == {k: v for k, v in request.items() if k != "input"}
        assert case["tiles"] == tiles and case["default_candidate_index"] == tiles.index(256)
        audit.validate_native(case["native"], request, tiles)
        assert case["torch_operation"] == audit.resident.cuda_rank_operation(request)
        expected_values, expected_indices = [], []
        for row in range(request["rows"]):
            values = [struct.unpack("f", struct.pack("f", value))[0] for value in
                      request["input"][row*request["cols"]:(row+1)*request["cols"]]]
            indices = sorted(range(len(values)), key=lambda i: (-values[i] if request["kind"] == "topk" else values[i], i))
            start = (len(values) - request["k"]) // 2 if request["kind"] == "midk" else 0
            selected = indices[start:start+request["k"]]
            expected_values.extend(values[i] for i in selected)
            expected_indices.extend(selected)
        assert case["native"]["values"] == expected_values
        assert case["native"]["indices"] == expected_indices
        for control, raw in zip(case["controls"], case["native"]["control_samples_per_op_ms"]):
            assert control == audit.audit.load_bench_module().summarize(raw)
        raw = [v["per_op_ms"] for v in case["native"]["observations"]]
        assert case["adaptive"] == audit.audit.load_bench_module().summarize(raw)
        default = case["controls"][case["default_candidate_index"]]
        best = min(range(len(tiles)), key=lambda i: case["controls"][i]["median_ms"])
        row = {
            "run": name, **{k: request[k] for k in ["kind", "rows", "cols", "k", "seed", "policy"]},
            "default_mean_ms": stats.mean(default["samples_ms"]),
            "adaptive_mean_ms": stats.mean(raw),
            "adaptive_mean_over_default_mean": stats.mean(raw) / stats.mean(default["samples_ms"]),
            "adaptive_median_over_default_median": case["adaptive"]["median_ms"] / default["median_ms"],
            "hindsight_best_control_tile": tiles[best],
            "hindsight_best_control_ms": case["controls"][best]["median_ms"],
            "torch_median_ms": case["torch_timing"]["median_ms"],
            "observations": case["native"]["rank_adaptation"]["observation_counts"]["rank_plan_variant"],
        }
        row["hindsight_best_over_torch"] = row["hindsight_best_control_ms"] / row["torch_median_ms"]
        cuda_ratios.append(row["hindsight_best_over_torch"])
        by_group[(row["kind"], row["cols"], row["policy"])].append(row)
        case_rows.append(row)

groups = []
for (kind, cols, policy), rows in sorted(by_group.items()):
    ratio = [row["adaptive_mean_over_default_mean"] for row in rows]
    groups.append(dict(kind=kind, cols=cols, policy=policy, cases=len(rows),
                       mean_ratio_median=stats.median(ratio), mean_ratio_min=min(ratio), mean_ratio_max=max(ratio),
                       median_step_ratio=stats.median(row["adaptive_median_over_default_median"] for row in rows)))
browser_name = "browser-25cd923c.json"
browser = json.loads((root / browser_name).read_text())
assert browser["status"] == "passed" and len(browser["cases"]) == 18 and not browser["page_errors"]
assert all(len(c["observations"]) == 24 for c in browser["cases"])
summary = dict(
    schema="spiraltorch.resident_rank_adaptation_evidence.v1", status="passed",
    interpretation="two complete repetitions of three seeds, not six independent seeds; whole-batch reward, per-op diagnostics",
    boundary="allocation, upload, validation readbacks, and policy overhead excluded; all 64 exploration choices included in adaptive means",
    comparison="native WGPU/Vulkan and PyTorch CUDA separate-process blocks, not interleaved or GPU-event timing",
    native_source="510a3b0487ea4959e34071d3e555d1e1191e12b7",
    python_source="365cd1fdebd3da7a450b5ccf1ae586f0da2cccb7",
    browser_fixture_source="25cd923c3ea0fc346c0da4b8c6ec3903756fcb90",
    request_sha256=request_sha, native_cases=len(case_rows),
    native_observations=sum(len(r["native"]["observations"]) for name in names for r in json.loads((root / name).read_text())["cases"]),
    browser_cases=len(browser["cases"]), browser_observations=432, browser_adapter=browser["adapter"],
    hindsight_best_over_torch_min=min(cuda_ratios), hindsight_best_over_torch_max=max(cuda_ratios),
    hindsight_best_over_torch_median=stats.median(cuda_ratios),
    file_sha256={name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in names+[browser_name]},
    groups=groups, cases=case_rows,
)
print(json.dumps(summary, indent=2, allow_nan=False))
