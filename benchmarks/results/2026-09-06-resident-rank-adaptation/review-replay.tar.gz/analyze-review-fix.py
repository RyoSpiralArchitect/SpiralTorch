"""Recompute the separate, source-bound post-review replay (not pooled evidence)."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import statistics as stats
import struct
import sys

parser = argparse.ArgumentParser()
parser.add_argument("--repo", type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.repo.resolve() / "tools"))
import bench_resident_rank_adaptation_vs_torch as audit

root = Path(__file__).resolve().parent
source = "5caf31829ecc668493e2a08d832b7e611745fd10"
native_name, browser_name = "comparison-5caf3182.json", "browser-5caf3182.json"
report = json.loads((root / native_name).read_text())
assert report["status"] == "passed" and report["provenance"]["valid"]
assert report["source"] == report["provenance"]["source_after"]
assert report["build_source_binding"]["valid"]
assert report["build_source_binding"]["embedded_commit"] == source
assert report["native_returncode"] == 0 and not report["native_stderr"]
bench = audit.audit.load_bench_module()
requests = list(audit.requests(bench))
payload = "".join(json.dumps(r, allow_nan=False) + "\n" for r, _ in requests)
assert report["request_sha256"] == hashlib.sha256(payload.encode()).hexdigest()
assert len(report["cases"]) == len(requests) == 36
rows, grouped = [], defaultdict(list)
for case, (request, tiles) in zip(report["cases"], requests):
    assert case["request"] == {k: v for k, v in request.items() if k != "input"}
    assert case["tiles"] == tiles and case["default_candidate_index"] == tiles.index(256)
    audit.validate_native(case["native"], request, tiles)
    assert case["torch_operation"] == audit.resident.cuda_rank_operation(request)
    expected_values, expected_indices = [], []
    for row in range(request["rows"]):
        values = [struct.unpack("f", struct.pack("f", value))[0] for value in
                  request["input"][row * request["cols"]:(row + 1) * request["cols"]]]
        order = sorted(range(len(values)), key=lambda i:
                       (-values[i] if request["kind"] == "topk" else values[i], i))
        start = (len(values) - request["k"]) // 2 if request["kind"] == "midk" else 0
        selected = order[start:start + request["k"]]
        expected_values.extend(values[i] for i in selected)
        expected_indices.extend(selected)
    assert case["native"]["values"] == expected_values
    assert case["native"]["indices"] == expected_indices
    for control, raw in zip(case["controls"], case["native"]["control_samples_per_op_ms"]):
        assert control == bench.summarize(raw)
    adaptive = [item["per_op_ms"] for item in case["native"]["observations"]]
    assert case["adaptive"] == bench.summarize(adaptive)
    default = case["controls"][case["default_candidate_index"]]
    best = min(case["controls"], key=lambda c: c["median_ms"])
    row = {k: request[k] for k in ["kind", "rows", "cols", "k", "seed", "policy"]}
    row.update(adaptive_mean_ms=stats.mean(adaptive),
               default_mean_ms=stats.mean(default["samples_ms"]),
               mean_ratio=stats.mean(adaptive) / stats.mean(default["samples_ms"]),
               hindsight_best_over_torch=best["median_ms"] / case["torch_timing"]["median_ms"],
               observation_counts=case["native"]["rank_adaptation"]["observation_counts"])
    rows.append(row)
    grouped[(row["kind"], row["cols"], row["policy"])].append(row["mean_ratio"])

browser = json.loads((root / browser_name).read_text())
assert browser["status"] == "passed" and not browser["page_errors"]
assert len(browser["cases"]) == 18
for case in browser["cases"]:
    request = {k: case[k] for k in ["kind", "rows", "cols", "k", "seed", "policy"]}
    request.update(rounds=24, scripts=[f"u2: true; rank_tile: {t}; ctile: {t};" for t in [32, 128, 256, 512]])
    # Reuse the receipt validator; browser controls retain six rather than twelve batches.
    native_shape = dict(case, repetitions=16, rank_adaptation=case["final"],
                        control_samples_per_op_ms=[samples * 2 for samples in case["control_samples_per_op_ms"]])
    assert all(len(samples) == 6 for samples in case["control_samples_per_op_ms"])
    audit.validate_native(native_shape, request, [32, 128, 256, 512])
assert browser["wasm_sha256"] == browser["asset_sha256"]["/module/spiraltorch_wasm_bg.wasm"]
products = {name: digest for digest, name in
            (line.split() for line in (root / "build-products-5caf3182.sha256").read_text().splitlines())}
assert products["web-5caf3182/spiraltorch_wasm_bg.wasm"] == browser["wasm_sha256"]
identity = json.loads((root / "python-identity-5caf3182.json").read_text())
names = [native_name, browser_name, "build-info-5caf3182.json", "python-identity-5caf3182.json",
         "build-products-5caf3182.sha256", "rank-tile-review-regression-red.log",
         "rank-tile-review-regression-red-v2.log", "rank-tile-review-regression-green.log",
         "rust-tests-5caf3182.log", "python-runtime-5caf3182.log", "clippy-5caf3182.log",
         "kdsl-clippy-5caf3182.log", "wasm-all-targets-5caf3182.log", "fmt-5caf3182.log",
         "harness-tests-5caf3182.log", "native-build-5caf3182.log", "wasm-build-5caf3182.log",
         "wheel-build-5caf3182.log", "wheel-install-5caf3182.log", "browser-5caf3182.log",
         "comparison-5caf3182.log", "analyze-review-fix.py"]
summary = dict(
    schema="spiraltorch.resident_rank_adaptation_review_replay.v1", status="passed", source=source,
    interpretation="one post-fix repetition of three seeds; separate from the earlier two-run table; no PyTorch win",
    boundary=report["boundary"], comparison=report["comparison"],
    native_cases=36, native_observations=2304, browser_cases=18, browser_observations=432,
    native_build_identity=report["native_build_identity"], executable=report["provenance"]["executable"],
    python=identity, browser_adapter=browser["adapter"], browser_version=browser["browser_version"],
    browser_asset_sha256=browser["asset_sha256"], build_products_sha256=products,
    binding_provenance="Python/WASM source labels use retained build logs and artifact hashes, not embedded Git attestation",
    groups=[dict(kind=k, cols=c, policy=p, mean_ratio_median=stats.median(v),
                 mean_ratio_min=min(v), mean_ratio_max=max(v)) for (k, c, p), v in sorted(grouped.items())],
    hindsight_best_over_torch_min=min(r["hindsight_best_over_torch"] for r in rows),
    hindsight_best_over_torch_max=max(r["hindsight_best_over_torch"] for r in rows), cases=rows,
    file_sha256={name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in names},
)
print(json.dumps(summary, indent=2, allow_nan=False))
