"""Archive the adopted handoff validation, including failed attempts."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess
import sys

LOG = Path(__file__).parent
ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
OUT = ROOT/'benchmarks/results/2026-09-12-resident-module-handoff'
ADOPTED = sys.argv[1]
RUN = LOG/ADOPTED
LOADER = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py')

def read(path): return json.loads(path.read_text())
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''): h.update(block)
    return h.hexdigest()

verified = read(RUN/'receipt.json')
assert verified['status']=='passed' and all(s['exit_code']==0 for s in verified['steps'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==verified['source']['commit']
for name,sha in verified['products'].items(): assert digest(RUN/name)==sha,name
assert digest(LOG/'run.py')==verified['harness_sha256']
assert digest(LOADER)==verified['loader_sha256']
report = dict(schema='spiraltorch.resident_module_handoff_evidence.v1',status='passed',
    source=verified['source'],adopted=ADOPTED,
    verification=dict(steps=len(verified['steps']),frozen_products=len(verified['products'])),
    scope='Explicit original Module -> resident graph learning -> checked original Module weight handoff -> fresh ModuleTrainer phase. Rust owns policy, Python exposes it, WASM exports the common portable plan.',
    fixes=[
        'All role bindings are checked against actual visited Parameter identities, names, shapes, program and bitwise baseline values before mutation. Known pointwise fusion is normalized in Rust. Attached parameter optimizer state requires explicit reset.',
        'Handoff invalidates both forward and transpose parameter packs and preserves supported host layouts.',
        'Column-major Tensor transpose formerly read raw bytes as row-major, corrupting Linear input VJPs. CPU and explicit WGPU transpose now preserve logical values. Protected snapshots share; writable/foreign paths do not expose transpose inputs via a mutable DLPack result alias.',
        'Python plan rejection keeps the existing InferencePlan ValueError mapping; its shipped typing declaration is checked against the native signature.'
    ], boundaries=[
        'Weights only, not optimizer-state continuation, trainer-level reset, automatic ModuleTrainer GPU dispatch, or generic pure::Tensor/autograd migration.',
        'No new CUDA/Furnace run, wheel release, push or merge. No new latency/throughput or model-quality evidence.',
        'The explicit handoff fixture is a small deterministic integration case, not a model-quality experiment. Gradient policies remain explicit and distinct.',
        'Module commit relies on the pre-existing stable parameter visitor contract. Duplicate names/tied slots are unsupported; compatibility is not object identity, lineage or authorization.',
        'Native WGPU uses Apple M4 Metal; Chrome reports BrowserWebGpu, not an attestation of its exact physical adapter. Owned GPU work serial; host contention UNKNOWN.',
        'Prior mixed benchmark timings and the old parallel GPU VJP failure remain unresolved; passing serial tests does not resolve them.',
        'DLPack remains contiguous row-major CPU f32 only. These tests do not certify all tensor/optimizer layout combinations.'
    ],exploratory_failures=[
        dict(paths=['exploratory-cpu.log','exploratory-cpu-values.log'],
             cause='Pre-fix column-major Linear backward input-gradient mismatch. Forward matched. Kept exact comparison and corrected Tensor transpose rather than relaxing tolerance.'),
        dict(paths=['verified-a/receipt.json','verified-a/python-module_update.log'],
             cause='Source-bound initial verification stopped after native training passed but three Python negative tests received RuntimeError instead of the plan ValueError contract. Fixed the binding to preserve the typed plan error.'),
        dict(paths=['exploratory-dlpack.log'],
             cause='New regression fixture incorrectly tried column-major DLPack export, which is unsupported. Rewrote the test using the actual public row-major transpose-result export; no DLPack feature expansion was made.')
    ], exploratory_boundary='Exploratory logs are intermediate dirty-source tests, not frozen performance baselines. The failed source-bound verification is separate from the adopted complete run.')
report['rust_tests']={}
for name in ['contracts','tensor-cpu','tensor-wgpu','nn-cpu-handoff','nn-serial','backend-serial','integration']:
    log=(RUN/(name+'.log')).read_text()
    matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
    assert matches and all(int(m[1])==0 for m in matches),name
    report['rust_tests'][name]=dict(passed=sum(int(m[0]) for m in matches),ignored=sum(int(m[2]) for m in matches))
report['rust_tests']['tensor-wgpu']['ignored_boundary']='Existing fractional GL live-adapter test is marked ignored; not part of the transpose or handoff changes.'
report['python']={}
existing=read(RUN/'python-tests.json')
assert existing['status']=='passed' and existing['tests']==32 and existing['skipped']==0
report['python']['existing']=existing
for name,count in [('python-graph_autograd',3),('python-graph_learner',3),('python-module_update',5),('python-pointwise',5),('python-cpu-handoff',4)]:
    log=(RUN/(name+'.log')).read_text()
    assert f'Ran {count} tests' in log and '\nOK\n' in log and 'skipped=' not in log,name
    report['python'][name]=dict(tests=count,status='passed')
cpu=read(RUN/'python-cpu-probe.json')
assert cpu['status']=='passed' and not cpu['build_info']['features']['wgpu']
report['python']['cpu_build']=cpu
report['handoff']={}
browser=read(RUN/'browser-handoff.json')
assert browser['status']=='passed' and len(browser['cases'])==4
assert {(c['policy'],c['fused']) for c in browser['cases']}=={(p,f) for p in ['exact','module_compatible'] for f in [False,True]}
report['handoff']['browser']=dict(adapter=browser['adapter'],cases=[
    dict(policy=c['policy'],fused=c['fused'],updates=c['updates'],submitted_steps=c['submitted_steps'],
         first_pre_update_loss=c['losses'][0],last_pre_update_loss=c['losses'][-1],prediction=c['prediction'])
    for c in browser['cases']])
for name in ['browser-to-python','browser-to-cpu-python']:
    item=read(RUN/(name+'.json'))
    assert item['status']=='passed' and len(item['cases'])==4
    assert all(c['parameters']==6 and c['new_module_trainer_phase']=='passed' for c in item['cases'])
    report['handoff'][name]=item
report['regression']={}
for origin in ['native','browser']:
    item=read(RUN/(origin+'-correctness.json'))
    assert item['status']=='passed'
    learning=item['learning']
    assert len(learning['cases'])==12 and all(c['steps']==c['accepted_updates']==64 and c['resume']=='bit_identical' for c in learning['cases'])
    assert all(g['passed'] for g in learning['guards'])
    assert all(g['passed'] for g in item['autograd']['guards'])
    report['regression'][origin]=dict(adapter=item['adapter'],learner_cases=len(learning['cases']),
        accepted_learning_updates=sum(c['accepted_updates'] for c in learning['cases']),
        max_abs_error_vs_rust_module=max(c['max_abs_error'] for c in learning['cases']))
for name in ['wasm-pointwise','wasm-learner','wasm-autograd','wasm-fusion','wasm-forward']:
    item=read(RUN/(name+'.json'))
    assert item['status']=='passed'
    report['regression'][name]={k:item[k] for k in ['status','assertions','adapter','custom_loss_update'] if k in item}
    if 'cases' in item: report['regression'][name]['case_count']=len(item['cases'])
torch=read(RUN/'torch-correctness.json')
assert torch['status']=='passed'
report['regression']['torch']=dict(version=torch['torch'],cases=len(torch['cases']),
    comparisons=sum(c['comparisons'] for c in torch['cases']),max_abs_error=max(c['max_abs_error'] for c in torch['cases']),
    boundary='Independent CPU/MPS numerical replay of existing graph/autograd/learner fixtures, not a new performance benchmark.')

OUT.mkdir()
(OUT/'raw').mkdir()
files=sorted(p for p in LOG.rglob('*') if p.is_file() and p.suffix in ['.py','.json','.jsonl','.log','.stderr'])+[LOADER]
manifest=dict(schema='spiraltorch.compressed_evidence_manifest.v1',artifacts=[])
for index,source in enumerate(files):
    destination=OUT/'raw'/f'{index:03d}-{source.name}.xz'
    with source.open('rb') as src,lzma.open(destination,'wb',filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024*1024)]) as dst:
        for block in iter(lambda:src.read(1024*1024),b''): dst.write(block)
    h,size=hashlib.sha256(),0
    with lzma.open(destination,'rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block);size+=len(block)
    assert h.hexdigest()==digest(source) and size==source.stat().st_size
    assert destination.stat().st_size<95*1024*1024
    manifest['artifacts'].append(dict(source=str(source.relative_to(LOG)) if source.is_relative_to(LOG) else 'external/python-client.py',
        path=str(destination.relative_to(OUT)),raw_sha256=h.hexdigest(),raw_bytes=size,
        compressed_sha256=digest(destination),compressed_bytes=destination.stat().st_size))
report['artifacts']=len(manifest['artifacts'])
report['compressed_bytes']=sum(a['compressed_bytes'] for a in manifest['artifacts'])
report['raw_bytes']=sum(a['raw_bytes'] for a in manifest['artifacts'])
for name,value in [('summary',report),('manifest',manifest)]:
    with (OUT/(name+'.json')).open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')
print(json.dumps({k:report[k] for k in ['status','source','artifacts','raw_bytes','compressed_bytes']}))
