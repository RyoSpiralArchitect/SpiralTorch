# Canonical CUDA Rank Reference

Compiled/native/benchmark source: dc840c9725d11a445d5df109da62e9e7c2479b2d.
Later commits only update documentation/evidence. source.bundle requires
8a3624f89b60b1586167e5c2978b2d19848dadeb. Rust/backend/WASM source is unchanged
from that implementation. No browser speedup is measured in this study.

## Test And Build

Local Torch 2.12.1 uses isolated -I Python. Furnace Torch 2.13.0+cu132 is in
the user site, so the remote recipes omit -I. Requested CUDA tests may not
fall back. Existing stdlib CI tests do not acquire a Torch dependency.

```sh
SPIRALTORCH_RUN_TORCH_RANK_TESTS=1 SPIRALTORCH_TORCH_RANK_DEVICE=cpu PRIVATE_PYTHON -I tests/test_resident_rank_bench.py -v
SPIRALTORCH_RUN_TORCH_RANK_TESTS=1 SPIRALTORCH_TORCH_RANK_DEVICE=cuda python3 tests/test_resident_rank_bench.py -v
python3 -I tests/test_resident_rank_adaptation_bench.py -v
python3 -I tests/test_matmul_rank_bench.py -v
cargo +1.98.1 build -p st-core --no-default-features --features wgpu-rt,kdsl --example resident_rank_adaptation_bench --example resident_rank_bench --release
install -m 555 TARGET/release/examples/resident_rank_adaptation_bench NEW_ADAPTATION_IMAGE
install -m 555 TARGET/release/examples/resident_rank_bench NEW_RANK_IMAGE
NEW_ADAPTATION_IMAGE --build-info
NEW_RANK_IMAGE --build-info
sha256sum NEW_ADAPTATION_IMAGE NEW_RANK_IMAGE
```

Use a clean detached Furnace worktree, private Rust toolchain and four build
jobs. Freeze each executable before timing, verify embedded source identity,
and retain image hashes before and after all runs. Never time a shared target.

## Run

Inspect `spiral status` before EACH GPU launch and decide whether to proceed.
Keep owned GPU jobs terminal before starting another, including across hosts.
No same-host build overlaps timing. Keep existing CPU workloads untouched.
Use `spiral run --dir MATCHING_WORKTREE -- ...` for these remote recipes:

```sh
python3 run_native_finite_probe.py --repo MATCHING_WORKTREE --executable NEW_ADAPTATION_IMAGE --output NEW_FIRST_JSON
python3 run_native_finite_probe.py --repo MATCHING_WORKTREE --executable NEW_ADAPTATION_IMAGE --output NEW_REPEAT_JSON
python3 tools/bench_resident_rank_vs_torch.py --executable NEW_RANK_IMAGE --suite standard --resident-only --output NEW_STANDARD_JSON
python3 run_tail_ties_probe.py --repo MATCHING_WORKTREE --executable NEW_ADAPTATION_IMAGE --output NEW_TAIL_FIRST_JSON
python3 run_tail_ties_probe.py --repo MATCHING_WORKTREE --executable NEW_ADAPTATION_IMAGE --output NEW_TAIL_REPEAT_JSON
```

The finite fixture generator is byte-identical to the preceding finite-bound
study. The actual order was CUDA tests, build/freeze, first 18-case run, repeat
18-case run, standard 54-case run, and two targeted 4-case tail-tie diagnostics.
The targeted synthetic cases verify plain-topk admission with duplicated values
only outside the retained set; do not pool them into representative speedups.
WGPU completes before CUDA inside every run;
eligible CUDA controls rotate within each case. Two warmup and twelve retained
batches of sixteen operations include all key/repair/gather costs, with exact
checks/readbacks outside timing. Best fixed is post-hoc, not policy or a claim
to the fastest possible PyTorch implementation. Slower controls are retained.

## Replay

```sh
python -I analyze_references.py --repo /path/to/SpiralTorch --output recomputed.json
```

Only the unchanged repository benchmark validators, fixture generator, control
contract and standard library are required, not Torch, a GPU or browser. The
summary hashes every included raw file. Large binaries and private session
listings are excluded; GPU-only status observations retain private-file hashes.
