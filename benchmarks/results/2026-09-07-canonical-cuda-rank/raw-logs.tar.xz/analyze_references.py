"""Validate and replay all fixed CUDA controls without Torch or a GPU."""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from statistics import mean
import struct
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = "dc840c9725d11a445d5df109da62e9e7c2479b2d"


def read(name):
    return json.loads((ROOT / name).read_text())


def samples(values):
    assert values and all(math.isfinite(value) and value > 0 for value in values)
    return values


def bits(values):
    return [struct.pack("<f", value) for value in values]


def cuda(case, request, reference):
    admitted = reference.contract(request)
    controls = case["torch_controls"]
    assert controls["schema"] == "spiraltorch.cuda_rank_controls.v1"
    assert controls["operations"] == admitted["operations"]
    assert (controls["repetitions"], controls["warmup_batches"], controls["retained_batches"]) == (16, 2, 12)
    names = controls["operations"]
    assert set(controls["timings"]) == set(names) and len(controls["samples"]) == 12
    for block, pair in enumerate(controls["samples"], 2):
        offset = (block + request["seed"]) % len(names)
        order = names[offset:] + names[:offset]
        if (block // len(names)) % 2:
            order.reverse()
        assert pair["order"] == order and set(pair["per_op_ms"]) == set(names)
    elapsed = {}
    for name in names:
        values = samples(controls["timings"][name]["samples_ms"])
        assert values == [pair["per_op_ms"][name] for pair in controls["samples"]]
        assert len(values) == 12
        elapsed[name] = mean(values)
    best = min(names, key=lambda name: elapsed[name])
    assert controls["best_fixed"] == case["torch_operation"] == best
    legacy = case["legacy_torch_operation"]
    assert legacy in elapsed
    return dict(best=best, legacy=legacy, mean_ms=elapsed,
                ratio_to_legacy={name: value / elapsed[legacy] for name, value in elapsed.items()})


def run(name, requests, audit, resident, adaptation, reference, adaptive, runner="run_native_finite_probe.py"):
    report = read(name + ".json")
    schema = "spiraltorch.resident_rank_adaptation_comparison.v2" if adaptive else "spiraltorch.resident_rank_comparison.v2"
    assert report["schema"] == schema and report["status"] == "passed"
    assert report["source"]["commit"] == SOURCE and not report["source"]["tracked_dirty"]
    assert audit.validate_source_binding(report["native_build_identity"], report["source"])["valid"]
    assert report["provenance"]["valid"] and report["provenance"]["source_after"] == report["source"]
    image_name = "adaptation-dc840c97" if adaptive else "rank-dc840c97"
    image_hashes = {Path(path).name: digest for digest, path in (
        line.split() for line in (ROOT / "native-images-before.sha256").read_text().splitlines())}
    for key in ("executable", "execution_image"):
        assert report["provenance"][key]["sha256"] == image_hashes[image_name]
        assert report["provenance"][key]["mode"] & 0o777 == 0o555
    assert report["native_build_identity"] == read("products.json")["native_builds"][image_name + "-build-info.json"]
    assert len(report["cases"]) == len(requests)
    payload = "".join(json.dumps(request, allow_nan=False) + "\n" for request, _ in requests)
    assert report["request_sha256"] == hashlib.sha256(payload.encode()).hexdigest()
    if adaptive:
        assert report["native_returncode"] == 0 and not report["native_stderr"]
        assert report["probe"]["runner_sha256"] == hashlib.sha256((ROOT / runner).read_bytes()).hexdigest()
    else:
        assert report["resident_only_requested"] and report["suite"] == "standard"
    cells = []
    for case, (request, tiles) in zip(report["cases"], requests):
        assert case["request"] == {key: value for key, value in request.items() if key != "input"}
        result = case["native"]
        if adaptive:
            assert case["tiles"] == tiles
            adaptation.validate_native(result, request, tiles)
            native_means = [mean(samples(values)) for values in result["control_samples_per_op_ms"]]
        else:
            resident.validate_native_result(result, request, True)
            values = samples(result["samples_ms"]["resident_dispatch_fence_per_op"])
            assert len(values) == 12
            native_means = [mean(values)]
        expected = reference.contract(request)
        assert bits(result["values"]) == bits(expected["values"]) and result["indices"] == expected["indices"]
        assert result["adapter"]["name"] == report["torch_device"]
        control = cuda(case, request, reference)
        assert control["legacy"] == resident.cuda_rank_operation(request)
        primary = case["torch_timing"] if adaptive else case["timings"]["torch_resident_per_op"]
        assert primary == case["torch_controls"]["timings"][control["best"]]
        best_native = min(native_means)
        cells.append(dict(request={key: request[key] for key in ("kind", "rows", "cols", "k", "seed")},
            native_mean_ms=native_means, cuda=control,
            wgpu_best_fixed_over_cuda_best_fixed=best_native / control["mean_ms"][control["best"]],
            wgpu_best_fixed_over_legacy=best_native / control["mean_ms"][control["legacy"]]))
    return dict(cells=cells, winners=dict(Counter(cell["cuda"]["best"] for cell in cells)),
                torch=report["torch"], device=report["torch_device"], request_sha256=report["request_sha256"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    import bench_resident_rank_vs_torch as resident
    import bench_resident_rank_adaptation_vs_torch as adaptation
    import torch_rank_reference as reference
    products = read("products.json")
    assert products["compiled_source"] == SOURCE and products["source_clean"]
    assert products["backend_and_binding_rust_identical_to"] == "8a3624f89b60b1586167e5c2978b2d19848dadeb"
    for name, digest in products["runtime_files"].items():
        assert hashlib.sha256((args.repo / name).read_bytes()).hexdigest() == digest
    spec = importlib.util.spec_from_file_location("probe", ROOT / "run_native_finite_probe.py")
    probe = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(probe)
    bench = audit.load_bench_module()
    requests = list(probe.requests(bench))
    runs = {name: run(name, requests, audit, resident, adaptation, reference, True)
            for name in ("native-first", "native-repeat")}
    runs["standard"] = run("standard", [(request, None) for request in resident.requests_for(bench, "standard")],
                            audit, resident, adaptation, reference, False)
    tail_spec = importlib.util.spec_from_file_location("tail_probe", ROOT / "run_tail_ties_probe.py")
    tail_probe = importlib.util.module_from_spec(tail_spec)
    tail_spec.loader.exec_module(tail_probe)
    for name in ("tail-first", "tail-repeat"):
        runs[name] = run(name, list(tail_probe.requests(None)), audit, resident, adaptation, reference, True,
                         runner="run_tail_ties_probe.py")
    assert runs["tail-first"]["request_sha256"] == runs["tail-repeat"]["request_sha256"]
    assert runs["native-first"]["request_sha256"] == runs["native-repeat"]["request_sha256"]
    assert (ROOT / "native-images-before.sha256").read_bytes() == (ROOT / "native-images-after.sha256").read_bytes()
    result = dict(schema="spiraltorch.canonical_cuda_rank_evidence.v1", status="passed", source=SOURCE, runs=runs,
        interpretation="Hindsight best fixed controls, not online policy wins, confidence intervals, GPU-event timing, or the fastest possible PyTorch implementation. All candidate costs and losing cells are retained. Tail-tie cases are targeted synthetic admission diagnostics, not representative speedups.",
        raw_sha256={path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(ROOT.iterdir())
            if path.is_file() and path.suffix in (".json", ".log", ".py", ".txt", ".sha256", ".md", ".bundle")
            and not path.name.startswith("private-") and path.name not in ("summary.json", args.output.name)})
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({name: dict(cases=len(value["cells"]), winners=value["winners"],
        wgpu_over_cuda_range=[min(c["wgpu_best_fixed_over_cuda_best_fixed"] for c in value["cells"]),
                              max(c["wgpu_best_fixed_over_cuda_best_fixed"] for c in value["cells"])])
        for name, value in runs.items()}, indent=2))


if __name__ == "__main__":
    main()
