"""Verify the installed extension is exactly the frozen source-built wheel."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile
import spiraltorch as st
import spiraltorch.spiraltorch as native

ROOT = Path(__file__).resolve().parent
REPO = Path("/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-rank-finite-bound-v1")
SOURCE = "8a3624f89b60b1586167e5c2978b2d19848dadeb"
extension = Path(native.__file__).resolve()
assert extension.is_relative_to(Path(sys.prefix).resolve())
assert st.WgpuRank is not None
wheels = list((ROOT / "wheels-8a3624f8").glob("*.whl"))
assert len(wheels) == 1
wheel = wheels[0]
digest = lambda value: hashlib.sha256(value).hexdigest()
with zipfile.ZipFile(wheel) as archive:
    entries = [name for name in archive.namelist() if name.endswith("/" + extension.name)]
    assert len(entries) == 1 and archive.read(entries[0]) == extension.read_bytes()
assert not subprocess.check_output(["git", "-C", str(REPO), "diff", SOURCE, "HEAD", "--",
    "crates", "bindings/st-py/src", "bindings/st-py/spiraltorch", "bindings/st-wasm/src"])
report = dict(status="passed", compiled_source=SOURCE, python=sys.executable,
    extension=str(extension), extension_sha256=digest(extension.read_bytes()),
    wheel_sha256=digest(wheel.read_bytes()), build_info=st.build_info(),
    attribution="Source/build logs and installed extension byte-matched to the wheel, not an embedded Git attestation.")
with (ROOT / "python-products.json").open("x") as stream:
    json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write("\n")
print(json.dumps({"status": "passed", "extension_sha256": report["extension_sha256"]}))
