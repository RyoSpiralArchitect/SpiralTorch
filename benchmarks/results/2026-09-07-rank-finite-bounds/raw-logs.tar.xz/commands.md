# Finite Tile Bounds

Native baseline: 6da35010c48f3461024680862735edc9c4530c61.
Initial binary-only candidate: b4bf9399efacdbcf43f6797e3e9dbda9a08c7a69.
Bracketed implementation: 8a3624f89b60b1586167e5c2978b2d19848dadeb.
source-candidate.bundle requires 322f831a and 593c4be7; source-guarded requires
b4bf9399. These are recipes; retained logs/reports establish actual outcomes.

## Local

Rust 1.98.0, formatter nightly-2026-04-15, wasm-bindgen 0.2.104. Dedicated
worktree, four build jobs, private Python (-I), private Playwright and headless
Chrome only. Never use a personal browser profile. Freeze raw compiler output
before bindgen; never feed processed *_bg.wasm to bindgen.

```sh
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 cargo +1.98.0 test -p st-backend-wgpu --lib --test wgsl_syntax -- --test-threads=1
cargo +1.98.0 build --manifest-path bindings/st-wasm/Cargo.toml --target wasm32-unknown-unknown --features webgpu --release
install -m 444 TARGET/wasm32-unknown-unknown/release/spiraltorch_wasm.wasm NEW_RAW_WASM
wasm-bindgen NEW_RAW_WASM --out-name spiraltorch_wasm --target web --out-dir NEW_WEB
NODE_PATH=PRIVATE_PLAYWRIGHT node tools/test_resident_browser.cjs CANDIDATE_WEB CHROME NEW_JSON '' '' '' '' rank-count-matched BASELINE_WEB
cargo +1.98.0 clippy -p st-backend-wgpu --all-targets -- -D warnings
cargo +1.98.0 clippy -p st-backend-wgpu --target wasm32-unknown-unknown --all-targets -- -D warnings
node bindings/st-wasm/tests/resident_types.cjs NEW_WEB/spiraltorch_wasm.d.ts
maturin build --locked --release --manifest-path bindings/st-py/Cargo.toml --features wgpu-rt --interpreter PRIVATE_PYTHON --out NEW_WHEEL_DIR
PRIVATE_PYTHON -I -m pip install --no-deps NEW_WHEEL
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 PRIVATE_PYTHON -I -m pytest --import-mode=importlib --confcutdir=bindings/st-py -q bindings/st-py/tests/test_wgpu_rank.py bindings/st-py/tests/test_wgpu_resident.py bindings/st-py/tests/test_spiralk_rank_tile.py bindings/st-py/tests/test_resident_rank_adaptation.py bindings/st-py/tests/test_wgpu_rank_reports.py bindings/st-py/tests/test_wgpu_rank_profile.py
PRIVATE_PYTHON -I tests/test_resident_rank_adaptation_bench.py -v
cargo +nightly-2026-04-15 fmt --all --check
PRIVATE_PYTHON -I tools/sync_rankk_wgsl.py --check
```

Browser baseline is frozen 322f831a from the previous parallel-prefix study;
Git confirms identical backend/WASM Rust sources at 6da35010. It is not
relabeled as a fresh baseline build. Order: binary-only A/B, A/A, bracketed
A/B, bracketed A/B repeat, all with the same 117-case fixture. A/A serves
identical baseline products. Sparse/non-finite density cases are browser-only.
They use exact per-tile finite counts; the final partial tile caps the requested
count at its length. Host API/fence timings are not GPU-event measurements.

## Furnace

Inspect `spiral status` before EACH GPU launch and decide whether to proceed;
do not chain status to an unconditional launch. Keep existing CPU workloads
and system configuration untouched. The existing Torch installation is in the
user site, so no -I on Furnace. Use separate clean baseline/candidate worktrees,
private Rust 1.98.1, four build jobs and immutable mode-555 executable images.

```sh
cargo +1.98.1 build -p st-core --no-default-features --features wgpu-rt,kdsl --example resident_rank_adaptation_bench --release
install -m 555 TARGET/release/examples/resident_rank_adaptation_bench NEW_IMAGE
NEW_IMAGE --build-info
sha256sum NEW_IMAGE
python3 run_native_finite_probe.py --repo MATCHING_WORKTREE --executable NEW_IMAGE --output NEW_JSON
```

Native A-B-B-A order uses finite fixtures, including ties, with separate native
WGPU and Torch CUDA blocks in each run. Six fixed controls never seed Black Cat;
16 real correctness-gated observations per request do. Each owned GPU process
is terminal before another starts, including across hosts. No same-host build
overlaps benchmark timing. GPU availability gates are point checks, not
continuous monitoring. Publish GPU-only observations and private-status hashes,
not unrelated session listings.

## Replay

```sh
python -I analyze_counts.py --repo /path/to/SpiralTorch --output recomputed.json
```

The unchanged repository validators and standard library suffice; no Torch,
GPU or browser is needed. Large executables, wheels and generated modules are
excluded from the raw archive. All measured cells and the binary-only sparse
regression signal are retained, rather than promoting only favorable cases.
