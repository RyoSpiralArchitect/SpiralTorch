"""Replay exact finite-count comparisons without a GPU, browser, or Torch."""
import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
from statistics import mean, median
import sys

ROOT = Path(__file__).resolve().parent
BASELINE = "6da35010c48f3461024680862735edc9c4530c61"
CANDIDATE = "8a3624f89b60b1586167e5c2978b2d19848dadeb"


def read(name):
    return json.loads((ROOT / name).read_text())


def finite(values):
    assert values and all(math.isfinite(x) and x > 0 for x in values)
    return values


def describe(values):
    return dict(cells=len(values), median=median(values), minimum=min(values), maximum=max(values))


def grouped(cells, fields):
    groups = defaultdict(list)
    for cell in cells:
        key = ",".join(f"{field}={cell[field]}" for field in fields)
        groups[key].append(cell["ratio"])
    return {key: describe(values) for key, values in sorted(groups.items())}


def browser(name, aa=False, initial=False):
    report = read(name)
    assert report["status"] == "passed" and not report["page_errors"]
    assert report["fixture_suite"] == "count-bounds" and len(report["cases"]) == 117
    assert (report["repetitions"], report["warmup_batches"], report["retained_batches"]) == (64, 4, 16)
    assets = report["asset_sha256"]
    assert (assets["/module/spiraltorch_wasm_bg.wasm"] == assets["/baseline/spiraltorch_wasm_bg.wasm"]) == aa
    products = read("products.json")
    candidate_assets = products["baseline_assets"] if aa else products["initial_assets" if initial else "candidate_assets"]
    assert report["page_sha256"] == hashlib.sha256((ROOT / "browser-fixture.html").read_bytes()).hexdigest()
    for prefix, expected_assets in (("/module/", candidate_assets), ("/baseline/", products["baseline_assets"])):
        assert {k.removeprefix(prefix): v for k, v in assets.items() if k.startswith(prefix)} == {
            k: v for k, v in expected_assets.items() if k.endswith((".js", ".wasm"))}
    shapes = [(2,1023,32), (2,4095,128), (2,8191,256), (2,8193,512),
              (64,8191,256), (64,8193,512), (2,8193,1024), (2,8193,2048)]
    expected = {(seed, kind, rows, cols, tile, None) for seed in (17,29,43)
                for kind in ("topk", "midk", "bottomk") for rows,cols,tile in shapes}
    expected.update((seed, kind, 2, 1025, 512, density) for seed in (17,29,43)
                    for kind in ("topk", "midk", "bottomk") for density in (0,1,7,511,512))
    seen, cells = set(), []
    for i, case in enumerate(report["cases"]):
        key = tuple(case[k] for k in ("seed", "kind", "rows", "cols", "tile_cols")) + (case.get("finite_per_tile"),)
        assert key in expected and key not in seen and case["status"] == "passed" and case["k"] == 65
        seen.add(key)
        samples = case["samples"]
        assert len(samples) == 16
        for batch, sample in enumerate(samples, 4):
            assert sample["order"] == (["baseline", "candidate"] if (i + batch) % 2 == 0 else ["candidate", "baseline"])
        a = finite([s["baseline_ms"] for s in samples])
        b = finite([s["candidate_ms"] for s in samples])
        cells.append(dict(seed=key[0], kind=key[1], rows=key[2], cols=key[3], tile=key[4], finite_per_tile=key[5],
                          baseline_mean_ms=mean(a), candidate_mean_ms=mean(b), ratio=mean(b) / mean(a)))
    assert seen == expected
    return dict(cells=cells, by_shape=grouped(cells, ("rows", "cols", "tile", "finite_per_tile")),
                adapter=report["adapters"], page_sha256=report["page_sha256"], assets=assets)


def native(name, commit, adaptation, audit):
    report = read(name)
    assert report["status"] == "passed" and len(report["cases"]) == 18
    assert report["source"]["commit"] == commit and not report["source"]["tracked_dirty"]
    assert audit.validate_source_binding(report["native_build_identity"], report["source"])["valid"]
    assert report["provenance"]["valid"] and report["native_returncode"] == 0 and not report["native_stderr"]
    assert report["provenance"]["source_after"] == report["source"]
    assert report["probe"]["runner_sha256"] == hashlib.sha256((ROOT / "run_native_finite_probe.py").read_bytes()).hexdigest()
    expected = {(seed,kind,rows) for seed in (17,29,43) for kind in ("topk", "midk", "bottomk") for rows in (2,64)}
    seen, cells = set(), []
    for case in report["cases"]:
        request, result, tiles = case["request"], case["native"], case["tiles"]
        adaptation.validate_native(result, request, tiles)
        key = tuple(request[k] for k in ("seed", "kind", "rows"))
        assert key in expected and key not in seen
        seen.add(key)
        assert (request["cols"], request["k"], request["rounds"], request["policy"]) == (8193,65,16,"ucb")
        assert sorted(tiles) == [32,128,256,512,1024,2048]
        assert result["adapter"]["name"] == report["torch_device"]
        torch_samples = finite(case["torch_timing"]["samples_ms"])
        assert len(torch_samples) == 12
        torch_mean = mean(torch_samples)
        for tile, samples in zip(tiles, result["control_samples_per_op_ms"]):
            assert len(samples) == 12
            elapsed = mean(finite(samples))
            cells.append(dict(seed=key[0], kind=key[1], rows=key[2], cols=8193, tile=tile,
                              mean_ms=elapsed, torch_mean_ms=torch_mean, torch_operation=case["torch_operation"],
                              wgpu_over_cuda=elapsed / torch_mean))
    assert seen == expected
    return dict(cells=cells, torch=report["torch"], adapter=report["torch_device"],
                request_sha256=report["request_sha256"], policy_observations=18*16)


def native_pair(a, b):
    assert a["request_sha256"] == b["request_sha256"]
    key = lambda c: tuple(c[k] for k in ("seed", "kind", "rows", "cols", "tile"))
    left = {key(c): c for c in a["cells"]}
    cells = [dict(c, baseline_mean_ms=left[key(c)]["mean_ms"], ratio=c["mean_ms"] / left[key(c)]["mean_ms"])
             for c in b["cells"]]
    return dict(cells=cells, by_tile=grouped(cells, ("tile",)), by_rows_tile=grouped(cells, ("rows", "tile")))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    import bench_resident_rank_adaptation_vs_torch as adaptation
    browser_runs = {name: browser(name + ".json", aa=name == "browser-aa")
                    for name in ("browser-guarded-first", "browser-aa", "browser-guarded-repeat")}
    assert len({v["page_sha256"] for v in browser_runs.values()}) == 1
    runs = {name: native(name + ".json", commit, adaptation, audit) for name, commit in (
        ("native-a1", BASELINE), ("native-b1", CANDIDATE), ("native-b2", CANDIDATE), ("native-a2", BASELINE))}
    products = read("products.json")
    assert products["candidate_source"] == CANDIDATE and products["baseline_backend_wasm_sources_identical"]
    assert read("python-products.json")["status"] == "passed" and read("python-products.json")["compiled_source"] == CANDIDATE
    for name in ("browser-standard.json", "browser-profile.json"):
        assert read(name)["status"] == "passed" and not read(name)["page_errors"]
    result = dict(schema="spiraltorch.rank_finite_count_comparison.v1", status="passed",
        baseline=BASELINE, candidate=CANDIDATE, browser=browser_runs,
        superseded=dict(source="b4bf9399efacdbcf43f6797e3e9dbda9a08c7a69",
            browser=browser("browser-ab-first.json", initial=True),
            reason="A full-width binary search penalized sparse prefixes; add exponential bracketing rather than a fixed admission threshold."),
        native={"first": native_pair(runs["native-a1"], runs["native-b1"]),
                "reverse": native_pair(runs["native-a2"], runs["native-b2"]), "runs": runs},
        interpretation="Ratios of fixed-control sample means; not confidence intervals, online policy wins, model quality, or a SpiralTorch CUDA implementation. Sparse/non-finite density comparisons are browser-only.")
    result["raw_sha256"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ROOT.iterdir())
        if p.is_file() and p.suffix in (".json", ".log", ".py", ".cjs", ".txt", ".sha256", ".md", ".bundle", ".html")
        and not p.name.startswith("private-") and p.name not in ("summary.json", args.output.name)}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"browser": {k: v["by_shape"] for k, v in browser_runs.items()},
                      "native": {k: result["native"][k]["by_rows_tile"] for k in ("first", "reverse")}}, indent=2))


if __name__ == "__main__":
    main()
