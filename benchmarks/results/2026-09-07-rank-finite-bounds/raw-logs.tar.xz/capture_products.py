"""Bind source builds, frozen compiler inputs, and final served browser assets."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path("/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-rank-finite-bound-v1")
BASE_WEB = ROOT.parent / "parallel-rank-prefix-20260907/web-322f831a"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def assets(root):
    return {p.relative_to(root).as_posix(): digest(p) for p in sorted(root.rglob("*")) if p.is_file()}


def main():
    result = {"schema": "spiraltorch.rank_finite_count_products.v1",
        "baseline_native_source": "6da35010c48f3461024680862735edc9c4530c61",
        "baseline_wasm_source": "322f831a0c16688862e76b87893af8360456b661",
        "candidate_source": "8a3624f89b60b1586167e5c2978b2d19848dadeb",
        "initial_source": "b4bf9399efacdbcf43f6797e3e9dbda9a08c7a69",
        "baseline_assets": assets(BASE_WEB),
        "candidate_assets": assets(ROOT / "web-8a3624f8"),
        "initial_assets": assets(ROOT / "web-b4bf9399"),
        "raw_wasm_sha256": {p.name: digest(p) for p in sorted(ROOT.glob("raw-*.wasm"))},
        "attribution": "Native embeds clean Git commit/tree; WASM is source/build logs plus frozen raw compiler input and served product hashes, not embedded Git or a byte-reproducible-build claim."}
    diff = subprocess.check_output(["git", "-C", str(REPO), "diff", result["baseline_wasm_source"],
        result["baseline_native_source"], "--", "crates/st-backend-wgpu/src", "bindings/st-wasm/src"])
    assert not diff
    result["baseline_backend_wasm_sources_identical"] = True
    (ROOT / "products.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    observations = []
    for path in sorted(ROOT.glob("private-status-*.txt")):
        text = path.read_text()
        gpu = text.split("── gpu ──\n", 1)[1].split("── tmux ──", 1)[0].strip()
        assert "(no compute processes)" in gpu
        observations.append({"launch": path.stem.removeprefix("private-status-"),
            "gpu_only_observation": gpu, "private_status_sha256": digest(path)})
    (ROOT / "availability.json").write_text(json.dumps({"observations": observations,
        "boundary": "Read-only point checks before each Furnace GPU launch, not continuous monitoring. Unrelated CPU workloads and session contents are not published."}, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
