"""Recompute paired summaries and archive all completed measurement evidence."""
import hashlib
import json
import lzma
import math
from pathlib import Path
import re
import sys

LOG=Path(__file__).parent
ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
OUT=ROOT/'benchmarks/results/2026-09-11-graph-pointwise-fusion'
rounds=sys.argv[1:]
assert rounds
def read(path): return json.loads(path.read_text())
def geomean(values): return math.exp(sum(map(math.log,values))/len(values))
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''): h.update(block)
    return h.hexdigest()
verified=read(LOG/'verified/receipt.json'); assert verified['status']=='passed'
report=dict(schema='spiraltorch.graph_pointwise_fusion_evidence.v1',status='passed',
    candidate_source=verified['source'],rounds=[],correctness={},default_changed=False,
    scope='Explicit Rust plan fusion, not generic Module/autograd migration or a universal speedup.')
report['excluded_attempts']=[dict(name='timing-a',reason='Browser admission compared JSON key insertion order before any browser samples. Native standard result is retained but not a complete paired round.')]
report['boundaries']=['Eager Torch, not torch.compile or the fastest possible PyTorch route.',
    'Native Metal/MPS and Chrome WebGPU on this host only; no CUDA/remote GPU claim.',
    'Prior parallel GPU VJP one-off remains UNKNOWN; current GPU tests are serial.',
    'Current-source bindings only; no wheel release, push or merge in this change.']
report['measurement_counts']=dict(completed_paired_rounds=len(rounds),raw_intervals=1800*len(rounds),
    retained_intervals=1440*len(rounds),nonzero_sgd_updates=14400*len(rounds))
for name in ['native-correctness','browser-correctness']:
    item=read(LOG/'verified'/(name+'.json')); assert item['status']=='passed'
    fusion=item['pointwise_fusion']
    report['correctness'][name]=dict(cases=len(fusion['cases']),guards=len(fusion['guards']),
        fused_unfused_max_abs=max(c['fused_unfused_max_abs_error'] for c in fusion['cases']))
torch=read(LOG/'verified/torch-correctness.json'); assert torch['status']=='passed'
report['correctness']['torch']=dict(trajectories=len(torch['cases']),comparisons=sum(c['comparisons'] for c in torch['cases']),
    max_abs=max(c['max_abs_error'] for c in torch['cases']))
report['correctness']['python']=read(LOG/'verified/python-tests.json')
report['correctness']['wasm_clients']=read(LOG/'verified/wasm-clients.json')['status']
report['test_counts']={name:sum(map(int,re.findall(r'test result: ok\. (\d+) passed',
    (LOG/'verified'/(name+'.log')).read_text()))) for name in ['contracts','nn-serial','backend-serial','integration']}
for folder in rounds:
    receipt=read(LOG/folder/'receipt.json'); assert receipt['status']=='passed'
    item=dict(name=folder,matrices={})
    for matrix in ['standard','wide']:
        v=read(LOG/folder/(matrix+'-validation.json')); assert v['status']=='passed' and v['pointwise_fusion'] is True
        row=dict(max_abs=max(e for c in v['cases'] for e in c['max_abs_errors'].values()),native={},browser={})
        for origin in ['native','browser']:
            for cadence in ['immediate','deferred']:
                values=[c[origin][cadence]['baseline_over_candidate'] for c in v['cases']]
                worst=min(range(len(values)),key=lambda i:values[i])
                row[origin][cadence]=dict(baseline_over_candidate_geomean=geomean(values),
                    minimum_ratio=values[worst],maximum_ratio=max(values),
                    worst_config=v['cases'][worst]['config'],cases=len(values))
                if origin=='native':
                    row[origin][cadence]['torch_over_candidate_geomean']=geomean(
                        [c[origin][cadence]['torch_over_candidate'] for c in v['cases']])
        item['matrices'][matrix]=row
    report['rounds'].append(item)
OUT.mkdir()
(OUT/'raw').mkdir()
files=[LOG/'run.py',LOG/'analyze.py']
for folder in ['verified',*(p.name for p in sorted(LOG.glob('timing-*')) if p.is_dir())]:
    files.extend(sorted(p for p in (LOG/folder).iterdir() if p.suffix in ('.json','.jsonl','.log','.stderr')))
files.extend(sorted(LOG.glob('final-*.json')))
files.extend(sorted(LOG.glob('final-*.log')))
manifest=dict(schema='spiraltorch.compressed_evidence_manifest.v1',artifacts=[])
for i,source in enumerate(files):
    destination=OUT/'raw'/f'{i:03d}-{source.name}.xz'
    with source.open('rb') as src, lzma.open(destination,'wb',filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024*1024)]) as dst:
        for block in iter(lambda:src.read(1024*1024),b''): dst.write(block)
    raw_hash=digest(source); h=hashlib.sha256(); size=0
    with lzma.open(destination,'rb') as restored:
        for block in iter(lambda:restored.read(1024*1024),b''): h.update(block); size+=len(block)
    assert h.hexdigest()==raw_hash and size==source.stat().st_size
    assert destination.stat().st_size < 95*1024*1024
    manifest['artifacts'].append(dict(source=str(source.relative_to(LOG)),path=str(destination.relative_to(OUT)),
        raw_sha256=raw_hash,raw_bytes=size,compressed_sha256=digest(destination),compressed_bytes=destination.stat().st_size))
report['artifacts']=len(manifest['artifacts'])
report['compressed_bytes']=sum(a['compressed_bytes'] for a in manifest['artifacts'])
for name,value in [('summary',report),('manifest',manifest)]:
    (OUT/(name+'.json')).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2,allow_nan=False))
