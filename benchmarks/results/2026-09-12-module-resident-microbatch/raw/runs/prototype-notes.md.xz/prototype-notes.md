# Preliminary Checks

These logs precede the frozen source-bound run and are not counted as its tests.

- `backend-a.log`: the new test helper used the Python readback name rather than
  Rust's `read`; only the test helper was corrected.
- `backend-b.log`: both real-GPU accumulation/guard tests passed, including 300
  contributions, stale/foreign states, overflow, zero weights and recovery.
- `nn-a.log`: the fixture imported ResidentLoss from the wrong Rust module;
  corrected to `resident_tensor::loss::ResidentLoss`.
- `nn-b.log`: the existing full graph-learning fixture, including six changing
  microbatch cases, passed against ordinary Rust Modules.

After these checks, parameter-state identity was changed from a separately
allocated revision object to a learner-owned identity plus checked generation.
That avoids a new per-update allocation. The frozen run rechecks all routes.
No performance conclusion follows from the preliminary runs.
