"""Independently compare compressed records to originals/Git and frozen products."""
from collections import Counter
import hashlib
import json
import lzma
from pathlib import Path
import subprocess

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
OUT = ROOT / 'benchmarks/results/2026-09-12-module-resident-microbatch'
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest_bytes = (OUT / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
summary = json.loads((OUT / 'summary.json').read_bytes())
assert summary['status'] == manifest['status'] == 'passed'
assert summary['manifest_sha256'] == sha(manifest_bytes)
names = set()
origins = Counter()
raw_total = packed_total = 0
for entry in manifest['records']:
    name = entry['archive']
    path = OUT / name
    assert name not in names and path.resolve().is_relative_to((OUT / 'raw').resolve())
    names.add(name)
    packed = path.read_bytes()
    data = lzma.decompress(packed)
    assert len(packed) == entry['compressed_bytes'] and sha(packed) == entry['compressed_sha256'], name
    assert len(data) == entry['bytes'] and sha(data) == entry['sha256'], name
    origin = entry['origin']
    if 'git_commit' in origin:
        original = subprocess.check_output(['git', 'show', origin['git_commit'] + ':' + origin['git_path']], cwd=ROOT)
        origins['git'] += 1
    else:
        original = Path(origin['path']).read_bytes()
        origins['local'] += 1
    assert data == original, name
    raw_total += len(data)
    packed_total += len(packed)
assert names == {str(path.relative_to(OUT)) for path in (OUT / 'raw').rglob('*') if path.is_file()}
assert raw_total == manifest['raw_bytes'] and packed_total == manifest['compressed_bytes']
assert len(names) == summary['raw_records']
for item in summary['products']:
    assert sha(Path(item['path']).read_bytes()) == item['sha256'], item['path']
assert len(summary['products']) == summary['frozen_products_checked']
source = summary['candidate_source']
assert subprocess.check_output(['git', 'rev-parse', source['commit'] + '^{tree}'], cwd=ROOT, text=True).strip() == source['tree']
subprocess.run(['git', 'merge-base', '--is-ancestor', source['commit'], 'HEAD'], cwd=ROOT, check=True)
run_path = OUT / 'raw/runs/verified-a/receipt.json.xz'
run = json.loads(lzma.decompress(run_path.read_bytes()))
assert run['status'] == 'passed' and 'active' not in run and run['source'] == source
assert len(run['steps']) == summary['verification_steps'] == 69
assert all(step['exit_code'] == 0 for step in run['steps'])
torch = json.loads(lzma.decompress((OUT / 'raw/runs/verified-a/torch-correctness.json.xz').read_bytes()))
for item in torch['inputs']:
    assert sha(Path(item['path']).read_bytes()) == item['sha256']
microbatch = [case for case in torch['cases'] if case.get('microbatch')]
assert len(microbatch) == summary['torch_microbatch_matched']['cases'] == 24
assert len(torch['reference_gaps']) == len(summary['existing_torch_reference_gaps']) == 4
assert all('NOT a matched' in gap['scope'] for gap in torch['reference_gaps'])
verification = dict(status='passed', scope='Independent archive and source/product integrity check; not a second runtime run',
    source=source, records=len(names), origins=dict(origins), products=len(summary['products']),
    manifest_sha256=sha(manifest_bytes), raw_bytes=raw_total, compressed_bytes=packed_total,
    runtime_steps=len(run['steps']), torch_cases=len(torch['cases']),
    torch_comparisons=sum(case['comparisons'] for case in torch['cases']),
    microbatch_cases=len(microbatch),
    microbatch_comparisons=sum(case['comparisons'] for case in microbatch),
    separate_reference_gaps=len(torch['reference_gaps']))
with (OUT / 'verification.json').open('x') as stream:
    json.dump(verification, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps(verification))
