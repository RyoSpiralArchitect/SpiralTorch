"""Public pointwise clients and explicitly selected learner seed fusion evidence."""
import hashlib
import json
import lzma
import math
from pathlib import Path
import re

LOG = Path(__file__).parent
ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
OUT = ROOT / 'benchmarks/results/2026-09-12-pointwise-clients-seed-fusion'


def read(path):
    return json.loads(path.read_text())


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def gm(values):
    return math.exp(sum(map(math.log, values)) / len(values))


ADOPTED = 'verified-c'
verified = read(LOG / ADOPTED / 'receipt.json')
assert verified['status'] == 'passed'
batch = read(LOG / 'benchmark-batch.json')
assert batch['status'] == 'passed' and batch['rounds'] == [
    dict(name=name, exit_code=0) for name in ['timing', 'timing-b', 'control']]
for name, sha in verified['products'].items():
    assert digest(LOG / ADOPTED / name) == sha
report = dict(
    schema='spiraltorch.pointwise_clients_seed_fusion_evidence.v1', status='passed',
    source=verified['source'], adopted=ADOPTED, correctness={}, rounds=[],
    verification=dict(steps=len(verified['steps']), frozen_products=len(verified['products'])),
    scope='Public owning PointwiseInputs and reusable PointwisePlan clients expose existing Rust fusion to Python/WASM. Shape/device checks and operation vocabulary stay in Rust. Caller-selected cubic-cotangent fusion replaces three elementwise tensor submissions with one prepared dispatch; graph and optimizer remain unchanged.',
    performance_scope='End-to-end custom learner performance: GPU quadratic/quartic seeds, two exact VJPs, weighted SGD and all update acceptance receipts. Initial/final loss/state probes outside timing. The control is the same unfused learner, not ordinary MSE. Model-graph fusion is disabled in all lanes; only candidate cubic-cotangent fusion is selected in the two treatment rounds. Python boundary overhead is not timed.',
    boundaries=[
        'No ModuleTrainer, generic autograd or pure::Tensor migration. No Adam, momentum, cross-forward accumulation or mixed precision.',
        'Learning fixture uses three seed/shape pairs, not an independent crossed seed-by-shape sweep. Bounded numerical learning, not model quality.',
        'Submitted updates are attempts; only their individual captured receipts establish acceptance.',
        'Owned GPU work serial; host contention UNKNOWN. Prior parallel GPU VJP one-off remains UNKNOWN.',
        'Prior ordinary MSE native timing regressions remain unresolved; this control measures the unfused custom learner, not ordinary MSE.',
        'Native Apple M4 Metal/MPS; Chrome WebGPU does not attest an exact physical browser adapter.',
        'Eager Torch only, not torch.compile or the fastest possible Torch. No CUDA/Furnace, push, merge or wheel release.'
    ],
    exploratory_failures=[dict(path='exploratory-admission.log', phase='new-admission-test',
        cause='New negative test passed a three-lane expectation to an existing two-lane fixture. Corrected the test, retained the initial failure and the passing rerun.'),
        dict(path='verified/receipt.json', phase='client-types', cause='Type checker assumed an opaque constructor for the intentionally public WgpuPointwiseInputs builder. Fixed the checker; the first result is not adopted.'),
        dict(path='verified-b/receipt.json', phase='interrupted-python-build', cause='Execution handle 89270 was missing and a live process search found no driver, build or test process. The incomplete receipt ended after cpu-check; a new full verification was started in verified-c without overwriting the interrupted logs.')])
for origin in ['native', 'browser']:
    item = read(LOG / ADOPTED / (origin + '-correctness.json'))
    assert item['status'] == 'passed'
    autograd = item['autograd']
    assert len(autograd['guards']) == 12 and all(g['passed'] for g in autograd['guards'])
    learning = item['learning']
    assert len(learning['cases']) == 12 and len(learning['guards']) == 8
    assert all(g['passed'] for g in learning['guards'])
    assert all(c['steps'] == c['accepted_updates'] == 64 and c['resume'] == 'bit_identical' for c in learning['cases'])
    report['correctness'][origin] = dict(
        adapter=item['adapter'], learner_cases=12, learner_guards=8, learning_updates=768,
        retained_checkpoints=sum(len(c['captures']) for c in learning['cases']),
        max_abs_error_vs_rust_module=max(c['max_abs_error'] for c in learning['cases']),
        cases=[{k: c[k] for k in ['seed', 'shape', 'policy', 'fused', 'initial_loss', 'final_loss', 'resume']} for c in learning['cases']],
        composition_reuse=next(g for g in learning['guards'] if g['case']=='composition_reuse'),
        autograd_cases=len(autograd['cases']), autograd_guards=len(autograd['guards']),
        capture_reuse=next(g for g in autograd['guards'] if g['case']=='queued_capture_tail_shapes_detached_guard_recovery'),
        prior_fusion_cases=len(item['pointwise_fusion']['cases']))
torch = read(LOG / ADOPTED / 'torch-correctness.json')
assert torch['status'] == 'passed'
report['correctness']['torch'] = dict(version=torch['torch'], cases=len(torch['cases']),
    comparisons=sum(c['comparisons'] for c in torch['cases']), max_abs=max(c['max_abs_error'] for c in torch['cases']))
weighted = [c for c in torch['cases'] if c['weighted_learning']]
assert len(weighted) == 48 and {c['device'] for c in weighted} == {'cpu', 'mps'}
report['correctness']['torch']['weighted_learning'] = dict(cases=len(weighted),
    updates=sum(c['updates'] for c in weighted), comparisons=sum(c['comparisons'] for c in weighted),
    max_abs=max(c['max_abs_error'] for c in weighted))
report['correctness']['python_existing'] = read(LOG / ADOPTED / 'python-tests.json')
for name in ['python-autograd', 'python-learner']:
    text = (LOG / ADOPTED / (name + '.log')).read_text()
    assert 'Ran 3 tests' in text and '\nOK\n' in text
    report['correctness'][name] = dict(tests=3, status='passed')
for name in ['wasm-learner', 'wasm-autograd', 'wasm-fusion', 'wasm-forward', 'wasm-pointwise']:
    item = read(LOG / ADOPTED / (name + '.json'))
    assert item['status'] == 'passed'
    report['correctness'][name] = {k: item[k] for k in ('status', 'assertions', 'adapter', 'custom_loss_update') if k in item}
    if 'cases' in item:
        report['correctness'][name]['case_count'] = len(item['cases'])
    if name == 'wasm-learner':
        report['correctness'][name]['cases'] = item['cases']
text = (LOG / ADOPTED / 'python-pointwise.log').read_text()
assert 'Ran 5 tests' in text and '\nOK\n' in text
report['correctness']['python-pointwise'] = dict(tests=5, status='passed')
report['test_counts'] = {name: sum(map(int, re.findall(r'test result: ok\. (\d+) passed',
    (LOG / ADOPTED / (name + '.log')).read_text()))) for name in ['contracts', 'nn-serial', 'backend-serial', 'integration']}
raw_intervals = retained_intervals = updates = 0
for name in ['timing', 'timing-b', 'control']:
    receipt = read(LOG / name / 'receipt.json')
    assert receipt['status'] == 'passed' and receipt['source'] == verified['source']
    value = read(LOG / name / 'validation.json')
    assert value['status'] == 'passed' and len(value['cases']) == 9
    assert value['workload'] == 'learner'
    assert value['learner_seed_fusion'] is (name != 'control')
    row = dict(name=name, workload=value['workload'], comparison='unfused learner A/B control' if name=='control' else 'explicit candidate seed fusion A/B', learner_seed_fusion=value['learner_seed_fusion'], baseline=receipt['baseline']['source'], candidate=receipt['candidate']['source'],
        max_abs=max(e for c in value['cases'] for e in c['max_abs_errors'].values()), native={}, browser={})
    for origin in ['native', 'browser']:
        for cadence in ['immediate', 'deferred']:
            ratios = [c[origin][cadence]['baseline_over_candidate'] for c in value['cases']]
            worst = min(range(len(ratios)), key=lambda i: ratios[i])
            stats = dict(baseline_over_candidate_geomean=gm(ratios), min_ratio=min(ratios), max_ratio=max(ratios),
                         worst_config=value['cases'][worst]['config'])
            if origin == 'native':
                stats['torch_over_candidate_geomean'] = gm([c[origin][cadence]['torch_over_candidate'] for c in value['cases']])
            row[origin][cadence] = stats
        original = read(LOG / name / (origin + '.json'))
        row[origin]['matching_final_state_fingerprints'] = sum(
            c['fingerprints']['baseline'] == c['fingerprints']['candidate'] for c in original['cases'])
        for case in original['cases']:
            for s in case['samples']:
                lanes = len(s['times_ms'])
                raw_intervals += lanes
                retained_intervals += 0 if s['warmup'] else lanes
                updates += lanes * case['config']['steps']
    report['rounds'].append(row)
report['measurement_counts'] = dict(raw_intervals=raw_intervals, retained_intervals=retained_intervals, nonzero_sgd_updates=updates)
report['performance_conclusion'] = dict(
    status='mixed_no_universal_speedup',
    native='Immediate-cadence aggregate ratios are below one in both treatment rounds. Deferred aggregates improve, but individual conditions regress substantially.',
    browser='Both treatment rounds improve in aggregate for both cadences, but individual conditions regress; this is not uniform improvement.',
    control='The unfused learner A/B control also varies. It uses different source-bound products, not identical-product A/A, and is not a scalar correction to the treatment.',
    torch='Eager Torch has lower aggregate elapsed time in every native round/cadence. Its completion synchronization does not supply equivalent Rust finite-check or rollback receipts.',
    decision='Keep fusion explicit. No automatic routing change, latency-regression-free claim, Python-call timing claim, or isolated-kernel causal attribution follows from this set.')

OUT.mkdir(exist_ok=True)
(OUT / 'raw').mkdir(exist_ok=True)
loader = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py')
report['external_python_loader'] = dict(path=str(loader), sha256=digest(loader),
    boundary='Loader archived at collection time; tests assert the loaded extension is the frozen product, not an installed wheel.')
files = sorted(p for p in LOG.rglob('*') if p.is_file() and 'provisional-evidence' not in p.parts and p.suffix in ('.py', '.json', '.jsonl', '.log', '.stderr')) + [loader]
manifest = dict(schema='spiraltorch.compressed_evidence_manifest.v1', artifacts=[])
for i, source in enumerate(files):
    destination = OUT / 'raw' / f'{i:03d}-{source.name}.xz'
    with source.open('rb') as src, lzma.open(destination, 'wb', filters=[dict(id=lzma.FILTER_LZMA2, preset=1, dict_size=64*1024*1024)]) as dst:
        for block in iter(lambda: src.read(1024*1024), b''):
            dst.write(block)
    raw_sha = digest(source)
    h, size = hashlib.sha256(), 0
    with lzma.open(destination, 'rb') as restored:
        for block in iter(lambda: restored.read(1024*1024), b''):
            h.update(block)
            size += len(block)
    assert h.hexdigest() == raw_sha and size == source.stat().st_size
    assert destination.stat().st_size < 95*1024*1024
    manifest['artifacts'].append(dict(source=str(source.relative_to(LOG)) if source.is_relative_to(LOG) else 'external/python-client.py', path=str(destination.relative_to(OUT)),
        raw_sha256=raw_sha, raw_bytes=size, compressed_sha256=digest(destination), compressed_bytes=destination.stat().st_size))
report['artifacts'] = len(manifest['artifacts'])
report['compressed_bytes'] = sum(a['compressed_bytes'] for a in manifest['artifacts'])
report['raw_bytes'] = sum(a['raw_bytes'] for a in manifest['artifacts'])
for name, value in [('summary', report), ('manifest', manifest)]:
    (OUT / (name + '.json')).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
print(json.dumps({k: report[k] for k in ['status', 'source', 'artifacts', 'compressed_bytes', 'raw_bytes']}))
