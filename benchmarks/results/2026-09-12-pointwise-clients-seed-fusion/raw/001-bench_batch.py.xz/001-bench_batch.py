"""One durable, serial, finite benchmark batch; no scheduler or retries."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

LOG = Path(__file__).parent
RECEIPT = LOG / 'benchmark-batch.json'
ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
if sys.argv[1:] == ['--launch']:
    if RECEIPT.exists():
        raise RuntimeError('inspect the existing batch before any new launch')
    with (LOG / 'benchmark-batch.log').open('xb') as output:
        child = subprocess.Popen(
            [sys.executable, '-S', str(Path(__file__).resolve())], cwd=ROOT,
            stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    print(json.dumps(dict(pid=child.pid, log=str(LOG / 'benchmark-batch.log'))))
    raise SystemExit(0)
if sys.argv[1:]:
    raise ValueError('unknown batch arguments')
report = dict(status='running', pid=os.getpid(), rounds=[], started=time.time())


def save():
    temporary = RECEIPT.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(report, indent=2) + '\n')
    temporary.replace(RECEIPT)


if RECEIPT.exists():
    raise RuntimeError('batch already exists; inspect it rather than retrying')
save()
try:
    for name, mode in [('timing', 'bench'), ('timing-b', 'bench'), ('control', 'control')]:
        args = [sys.executable, '-S', str(LOG / 'run.py'), name, mode, 'verified-c']
        print('BATCH START', name, flush=True)
        child = subprocess.Popen(args, cwd=ROOT)
        report['active'] = dict(name=name, pid=child.pid, command=args)
        save()
        code = child.wait()
        report['rounds'].append(dict(name=name, exit_code=code))
        report.pop('active')
        save()
        print('BATCH END', name, code, flush=True)
        if code:
            raise RuntimeError(name + ' failed; no subsequent round was started')
    report['status'] = 'passed'
except BaseException as error:
    report['status'] = 'error'
    report['error'] = repr(error)
    raise
finally:
    report['finished'] = time.time()
    save()
