"""Summarize all frozen factorial trials without filtering regressions."""
import hashlib
import json
from pathlib import Path
import statistics
import sys

LOG=Path(__file__).parent
RUN=LOG/sys.argv[1]
def read(path):return json.loads(path.read_bytes())
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def spread(values):return dict(median=statistics.median(values),min=min(values),max=max(values))
receipt=read(RUN/'receipt.json')
assert receipt['status']=='passed' and len(receipt['steps'])==60
assert all(s['exit_code']==0 for s in receipt['steps']) and len(receipt['trials'])==4
assert sha(LOG/'run.py')==receipt['harness_sha256']
for path,digest in receipt['inputs'].items():assert sha(Path(path))==digest
products=0
for version in receipt['versions'].values():
    root=Path(version['root']);assert sha(root/'receipt.json')==version['receipt_sha256']
    for path,digest in version['products'].items():assert sha(root/path)==digest;products+=1
validations=[]
for trial in receipt['trials']:
    for name,digest in trial['files'].items():assert sha(RUN/name)==digest
    for version in ['assembly','comparison','both']:
        data=read(RUN/f"{trial['trial']}-{version}-validation.json")
        assert data['status']=='passed'
        validations.append(dict(trial=trial['trial'],version=version,validation=data))
summary=dict(schema='spiraltorch.module_preparation_factorial_summary.v1',status='passed',
    boundary='Correctness and artifact admission, not a performance acceptance gate. Native ratios share each trial baseline process; candidate comparisons are correlated. Browser variants use separate same-page baseline pairs, not a four-way common device instance. No significance, host exclusivity or fastest-Torch claim.',
    receipt_sha256=sha(RUN/'receipt.json'),sources={k:v['source'] for k,v in receipt['versions'].items()},
    orders=receipt['orders'],verification_steps=len(receipt['steps']),frozen_products_checked=products,
    groups=[],regressions=[],native_factor_effects=[],validations=validations)
for version in ['assembly','comparison','both']:
    data=[entry['validation'] for entry in validations if entry['version']==version]
    for shape in [[2,3,7],[2,8,64],[4,8,128]]:
        py=[c for d in data for c in d['python'] if c['shape']==shape]
        web=[c for d in data for c in d['browser'] if c['shape']==shape]
        assert len(py)==len(web)==12
        med=lambda c,route:c['summary'][route]['median_ms_per_forward']
        summary['groups'].append(dict(version=version,shape=shape,depth=py[0]['depth'],seed_run_pairs=12,
            python_ms={v:statistics.median(med(c[v],'module_resident_burst') for c in py) for v in ['baseline','candidate']},
            python_burst_ratio=spread([c['candidate_over_baseline']['module_resident_burst'] for c in py]),
            python_d2h_ratio=spread([c['candidate_over_baseline']['module_resident_d2h'] for c in py]),
            python_controls={r:spread([c['candidate_over_baseline'][r] for c in py]) for r in ['python_scalar_burst','torch_mps_burst']},
            python_over_torch=spread([c['candidate']['module_burst_over_torch_mps'] for c in py]),
            browser_ms={v:statistics.median(med(c,v+'_module_burst') for c in web) for v in ['baseline','candidate']},
            browser_burst_ratio=spread([c['candidate_over_baseline']['module_burst'] for c in web]),
            browser_d2h_ratio=spread([c['candidate_over_baseline']['module_d2h'] for c in web]),
            browser_control=spread([c['candidate_over_baseline']['scalar_burst'] for c in web])))
for entry in validations:
    for client,routes in [('python',['module_resident_burst','module_resident_d2h']),('browser',['module_burst','module_d2h'])]:
        for case in entry['validation'][client]:
            for route in routes:
                ratio=case['candidate_over_baseline'][route]
                if ratio>1:summary['regressions'].append(dict(trial=entry['trial'],version=entry['version'],
                    client=client,shape=case['shape'],seed=case['seed'],route=route,ratio=ratio))
for shape in [[2,3,7],[2,8,64],[4,8,128]]:
    effects={name:[] for name in ['assembly_given_scalar','assembly_given_bulk','bulk_given_old_assembly','bulk_given_new_assembly','interaction']}
    for trial in range(1,5):
        by_version={v:[entry['validation']['python'] for entry in validations if entry['version']==v and entry['trial']==trial][0]
            for v in ['assembly','comparison','both']}
        for seed in [17,29,43]:
            row={v:[c for c in cases if c['shape']==shape and c['seed']==seed][0] for v,cases in by_version.items()}
            timing=lambda c:c['summary']['module_resident_burst']['median_ms_per_forward']
            b=timing(row['assembly']['baseline'])
            assert all(timing(c['baseline'])==b for c in row.values())
            a,c,d=(timing(row[v]['candidate']) for v in ['assembly','comparison','both'])
            for key,value in dict(assembly_given_scalar=a/b,assembly_given_bulk=d/c,
                bulk_given_old_assembly=c/b,bulk_given_new_assembly=d/a,interaction=d*b/(a*c)).items():effects[key].append(value)
    summary['native_factor_effects'].append(dict(shape=shape,ratios={key:spread(values) for key,values in effects.items()},
        boundary='Ratios of separately completed native worker medians in the same trial/seed; diagnostic, not isolated CPU/GPU phase timing.'))
browser=[c for entry in validations for c in entry['validation']['browser']]
summary['browser_correctness']=dict(paired_cases=len(browser),comparisons=sum(c['comparisons'] for c in browser),
    max_abs_error=max(c['max_abs_error'] for c in browser))
output=LOG/'analysis.json'
with output.open('x') as out:json.dump(summary,out,indent=2,allow_nan=False);out.write('\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['validations','regressions']},indent=2))

