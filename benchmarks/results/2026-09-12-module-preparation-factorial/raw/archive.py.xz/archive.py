"""Archive the complete factorial experiment; never equate admission with speed."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import shutil
import subprocess
import sys

LOG=Path(__file__).parent
ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
RUN=LOG/sys.argv[1]
OUT=ROOT/'benchmarks/results/2026-09-12-module-preparation-factorial'
def read(path):return json.loads(path.read_bytes())
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
receipt=read(RUN/'receipt.json');report=read(LOG/'analysis.json')
assert receipt['status']==report['status']=='passed'
assert sha(RUN/'receipt.json')==report['receipt_sha256']
assert sha(LOG/'run.py')==receipt['harness_sha256']
assert report['verification_steps']==60 and len(receipt['trials'])==4
matrix={}
fields={
    'backend':'crates/st-backend-wgpu',
    'tensor':'crates/st-tensor',
    'bindings':'bindings',
    'layers':'crates/st-nn/src/layers',
    'module':'crates/st-nn/src/module.rs',
    'resident':'crates/st-nn/src/resident.rs',
    'comparison':'crates/st-nn/src/resident/module_forward.rs',
    'manifest':'crates/st-nn/Cargo.toml',
    'lock':'Cargo.lock',
}
for key,item in receipt['versions'].items():
    root=Path(item['root']);assert sha(root/'receipt.json')==item['receipt_sha256']
    for name,digest in item['products'].items():assert sha(root/name)==digest
    source=item['source']['commit']
    assert git('rev-parse',source+'^{tree}')==item['source']['tree']
    matrix[key]={name:git('rev-parse',source+':'+path) for name,path in fields.items()}
    (LOG/(key+'-commit.txt')).write_text(git('show','--no-patch','--format=raw',source)+'\n')
    if key!='baseline':
        patch=subprocess.check_output(['git','diff','542c7445',source,'--','Cargo.toml','Cargo.lock','crates','bindings'],cwd=ROOT)
        (LOG/(key+'-source.patch')).write_bytes(patch)
for field in ['backend','tensor','bindings']:
    assert len({item[field] for item in matrix.values()})==1
for left,right,fields_ in [('baseline','assembly',['comparison','manifest','lock']),
        ('both','assembly',['layers','module','resident']),
        ('baseline','comparison',['layers','module','resident']),
        ('both','comparison',['comparison','manifest','lock'])]:
    assert all(matrix[left][field]==matrix[right][field] for field in fields_)
report['factor_source_matrix']=matrix
report['verification']={}
for key in ['assembly','comparison']:
    nn=(RUN/(key+'-nn.log')).read_text()
    match=re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',nn)
    assert match and int(match[1])==752
    for name in ['bulk_comparison_matches_scalar_bits_at_odd_lengths_and_nonfinite_payloads','bulk_cache_detects_signed_zero_and_last_word_foreign_linear_updates']:
        assert f'test resident::module_forward::tests::{name} ... ok' in nn
    test_counts={}
    for suite in ['python-existing','python-module']:
        content=(RUN/(key+'-'+suite+'.log')).read_text()
        count=re.search(r'Ran (\d+) tests?',content)
        assert count and '\nOK\n' in content
        test_counts[suite]=int(count[1])
    browser=read(RUN/key/'browser-module.json')
    assert browser['status']=='passed' and browser['assertions']==111
    assert all(browser[name] is True for name in ['direct_io_guards','output_reuse_guards','shared_stage_guards'])
    report['verification'][key]=dict(nn_tests=int(match[1]),python_tests=test_counts,browser_assertions=browser['assertions'])
for feature in ['cpu','wgpu']:
    content=(RUN/('assembly-allocations-'+feature+'.log')).read_text()
    assert 'previous assembly=69, current=1' in content
    assert 'nested caller-capacity assembly: 0 allocations across each of 20 calls' in content
report['allocation_boundary']='Assembly-only native integration test: 69 allocations for the former assembly algorithm using the same checked leaf descriptors, 1 for the new original Module, 0 with nested caller capacity. Not instrumentation of old production binaries or of timing workers.'
for trial in receipt['trials']:
    for name,digest in trial['files'].items():assert sha(RUN/name)==digest
for path,digest in receipt['inputs'].items():assert sha(Path(path))==digest
fixture=next(Path(path) for path in receipt['inputs'] if path.endswith('/native-forward-bench.json'))
shutil.copyfile(fixture,LOG/'fixture.json')
report['isolation_receipt']=receipt
OUT.mkdir()
paths=sorted({*LOG.rglob('*.json'),*LOG.rglob('*.log'),*LOG.glob('*.py'),*LOG.glob('*.txt'),*LOG.glob('*.patch')})
manifest=[]
for path in paths:
    relative=path.relative_to(LOG);destination=OUT/'raw'/(str(relative)+'.xz')
    destination.parent.mkdir(parents=True,exist_ok=True)
    raw=path.read_bytes();compressed=lzma.compress(raw,preset=6)
    assert lzma.decompress(compressed)==raw
    destination.write_bytes(compressed)
    manifest.append(dict(path=str(destination.relative_to(OUT)),original=str(relative),bytes=len(raw),
        sha256=hashlib.sha256(raw).hexdigest(),compressed_bytes=len(compressed),compressed_sha256=sha(destination)))
report['archive']=dict(files=len(manifest),raw_bytes=sum(x['bytes'] for x in manifest),
    compressed_bytes=sum(x['compressed_bytes'] for x in manifest))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'summary.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(output=str(OUT),archive=report['archive'],verification=report['verification'],
    browser_correctness=report['browser_correctness']),indent=2))

