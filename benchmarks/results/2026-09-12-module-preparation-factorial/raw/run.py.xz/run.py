"""Frozen 2x2 preparation ablation; serial GPU work, fixed orders, no retries."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

LOG=Path(__file__).parent
ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
TARGET=ROOT.parent/'spiraltorch-spiralk-golden-blackcat-contract-v1/target'
OLD=Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-shared-guard-20260912/verified-a')
BOTH=Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-descriptor-assembly-20260912/verified-a')
FIXTURE=BOTH/'native-forward-bench.json'
P='/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
BINDGEN='/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen'
LOADER=Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py')
ISOLATIONS={
    'assembly':(ROOT.parent/'spiraltorch-module-assembly-only-v1','dedd955ed37013cb57ba0357c72970d6d624fc44'),
    'comparison':(ROOT.parent/'spiraltorch-module-comparison-only-v1','a50239bcda35ae529f57d5b5b2818026a5abd912'),
}
ORDERS=[
    ['baseline','assembly','both','comparison'],
    ['assembly','comparison','baseline','both'],
    ['comparison','both','assembly','baseline'],
    ['both','baseline','comparison','assembly'],
]
if len(sys.argv)==3 and sys.argv[1]=='--launch':
    name=sys.argv[2]
    if Path(name).name!=name or (LOG/name).exists():raise ValueError('fresh run name required')
    with (LOG/(name+'.log')).open('xb') as log:
        child=subprocess.Popen([P,'-S',str(Path(__file__).resolve()),name],cwd=ROOT,
            stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps(dict(pid=child.pid,log=str(LOG/(name+'.log')))))
    raise SystemExit(0)
if len(sys.argv)!=2 or Path(sys.argv[1]).name!=sys.argv[1]:raise ValueError('OUTPUT or --launch OUTPUT')
OUT=LOG/sys.argv[1]
OUT.mkdir()
def read(path):return json.loads(path.read_bytes())
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def identity(root):return dict(commit=git(root,'rev-parse','HEAD'),tree=git(root,'rev-parse','HEAD^{tree}'))
env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_TARGET_DIR=str(TARGET),PYO3_PYTHON=P,
    SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1',PYTORCH_ENABLE_MPS_FALLBACK='0',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
report=dict(schema='spiraltorch.module_preparation_factorial.v1',status='running',pid=os.getpid(),
    source=identity(ROOT),orders=ORDERS,steps=[],versions={},trials=[],harness_sha256=sha(Path(__file__)),
    boundary='Frozen 2x2: assembly and exact comparison. GPU arithmetic, guards and output slots unchanged. Four fixed native orders; each version occupies each position once and each directed adjacency occurs once. Browser comparisons remain same-page rotated pairs against baseline, not simultaneous four-device measurement. No host exclusivity, causal timing guarantee, fastest-Torch, CUDA or automatic tuning claim.')
def save():
    tmp=OUT/'receipt.json.tmp';tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(OUT/'receipt.json')
def run(name,args,root=ROOT):
    print('START',name,flush=True);start=time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        child=subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
        report['active']=dict(name=name,pid=child.pid,command=args,workdir=str(root));save()
        try:code=child.wait(timeout=1800)
        except subprocess.TimeoutExpired:child.kill();child.wait();raise
    report.pop('active');report['steps'].append(dict(name=name,command=args,workdir=str(root),exit_code=code,seconds=time.monotonic()-start));save()
    print('END',name,code,flush=True)
    if code:raise RuntimeError(name)
def verify_products(root,receipt):
    assert receipt['status']=='passed'
    for name,digest in receipt['products'].items():assert sha(root/name)==digest,(root,name)
def freeze(src,dest,product_root,products):
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);dest.chmod(0o555)
    products[str(dest.relative_to(product_root))]=sha(dest)
def assert_sources():
    assert identity(ROOT)==report['source'] and not git(ROOT,'status','--porcelain')
    for key,(root,commit) in ISOLATIONS.items():
        assert git(root,'rev-parse','HEAD')==commit and not git(root,'status','--porcelain')
def register(key,root,receipt):
    verify_products(root,receipt)
    report['versions'][key]=dict(root=str(root),receipt_sha256=sha(root/'receipt.json'),source=receipt['source'],
        products=receipt['products'],assembly=key in ('assembly','both'),bulk_comparison=key in ('comparison','both'))
    save()
C=['cargo','+1.98.0']
NN=['-p','st-nn','--no-default-features','--features','wgpu']
SERIAL=['--','--test-threads=1']
try:
    assert_sources()
    for key,root in [('baseline',OLD),('both',BOTH)]:
        receipt=read(root/'receipt.json');register(key,root,receipt)
        shutil.copyfile(root/'receipt.json',OUT/(key+'-receipt.json'))
    report['inputs']={str(path):sha(path) for path in [FIXTURE,LOADER,ROOT/'tools/bench_graph_forward_paths.py',
        ROOT/'tools/validate_module_forward_paths.py',ROOT/'tools/validate_module_direct_io.py',
        ROOT/'tools/test_resident_browser.cjs',ROOT/'bindings/st-wasm/tests/module_resident_matched.html']}
    common=['Cargo.lock','crates/st-nn/Cargo.toml','crates/st-nn/src/resident/module_forward.rs']
    lowering=['crates/st-nn/src/layers','crates/st-nn/src/module.rs','crates/st-nn/src/resident.rs']
    for key,(root,_) in ISOLATIONS.items():
        comparator='542c7445' if key=='assembly' else 'd65b87f6'
        assembler='d65b87f6' if key=='assembly' else '542c7445'
        assert not git(root,'diff',comparator,'--',*common)
        assert not git(root,'diff',assembler,'--',*lowering)
        assert not git(root,'diff','542c7445','--','crates/st-backend-wgpu','crates/st-tensor','bindings')
    save()
    for key,(root,_) in ISOLATIONS.items():
        dest=OUT/key;dest.mkdir();products={};start=len(report['steps'])
        run(key+'-format',['cargo','+nightly-2026-04-15','fmt','--all','--','--check'],root)
        run(key+'-nn',C+['test','--locked','--release']+NN+['--lib']+SERIAL,root)
        if key=='assembly':
            for label,features in [('cpu',[]),('wgpu',['--features','wgpu'])]:
                run(key+'-allocations-'+label,C+['test','--locked','--release','-p','st-nn','--no-default-features',
                    *features,'--test','inference_lowering_allocations','--','--test-threads=1','--nocapture'],root)
        run(key+'-python-build',C+['build','--locked','--release','-p','spiraltorch-py'],root)
        freeze(TARGET/'release/libspiraltorch.dylib',dest/'python-release.dylib',dest,products)
        run(key+'-python-existing',[P,'-I',str(LOADER),str(dest/'python-release.dylib'),str(root),'tests',str(dest/'python-tests.json')],root)
        run(key+'-python-module',[P,'-I',str(LOADER),str(dest/'python-release.dylib'),str(root),'bindings/st-py/tests/test_nn_module_resident_forward.py','-v'],root)
        run(key+'-wasm-build',C+['build','--locked','--release','-p','spiraltorch-wasm','--features','webgpu','--target','wasm32-unknown-unknown'],root)
        run(key+'-bindgen',[BINDGEN,str(TARGET/'wasm32-unknown-unknown/release/spiraltorch_wasm.wasm'),
            '--target','web','--out-dir',str(dest/'client'),'--out-name','spiraltorch_wasm'],root)
        for path in (dest/'client').rglob('*'):
            if path.is_file():products[str(path.relative_to(dest))]=sha(path)
        freeze(FIXTURE,dest/'client/forward-bench-fixture.json',dest,products)
        run(key+'-browser-module',['node',str(ROOT/'tools/test_resident_browser.cjs'),str(dest/'client'),CHROME,
            str(dest/'browser-module.json'),'','','','','nn-module-forward'])
        browser=read(dest/'browser-module.json')
        assert browser['status']=='passed' and browser['assertions']==111
        assert all(browser[name] is True for name in ['direct_io_guards','output_reuse_guards','shared_stage_guards'])
        run(key+'-types',['node','bindings/st-wasm/tests/resident_types.cjs',str(dest/'client/spiraltorch_wasm.d.ts'),
            str(root/'bindings/st-wasm/types/spiraltorch-wasm.d.ts')],root)
        py=read(dest/'python-tests.json')
        assert py['status']=='passed' and py['skipped']==0 and py['build_info']['features']['wgpu'] is True
        assert_sources()
        receipt=dict(status='passed',source=identity(root),products=products,steps=report['steps'][start:])
        (dest/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        register(key,dest,receipt)
    for trial,order in enumerate(ORDERS,1):
        files={}
        for key in order:
            root=Path(report['versions'][key]['root']);output=OUT/f'{trial}-{key}-python.json'
            run(f'{trial}-{key}-python',[TORCH,'-I','tools/bench_graph_forward_paths.py','--fixture',str(FIXTURE),
                '--native-library',str(root/'python-release.dylib'),'--include-module','--output',str(output)])
            files[output.name]=sha(output)
        browser_order=[key for key in order if key!='baseline']
        for key in browser_order:
            root=Path(report['versions'][key]['root']);browser=OUT/f'{trial}-{key}-browser.json'
            run(f'{trial}-{key}-browser',['node','tools/test_resident_browser.cjs',str(root/'client'),CHROME,
                str(browser),'','','','','nn-module-matched',str(OLD/'client')])
            output=OUT/f'{trial}-{key}-validation.json'
            run(f'{trial}-{key}-validation',[P,'-I','tools/validate_module_direct_io.py','--fixture',str(FIXTURE),
                '--baseline-python',str(OUT/f'{trial}-baseline-python.json'),'--candidate-python',str(OUT/f'{trial}-{key}-python.json'),
                '--browser',str(browser),'--baseline-receipt',str(OLD/'receipt.json'),
                '--candidate-library',str(root/'python-release.dylib'),'--candidate-wasm',str(root/'client/spiraltorch_wasm_bg.wasm'),
                '--output',str(output)])
            assert read(output)['status']=='passed'
            files[browser.name]=sha(browser);files[output.name]=sha(output)
        report['trials'].append(dict(trial=trial,native_order=order,browser_order=browser_order,files=files));save()
    assert_sources()
    for item in report['versions'].values():
        root=Path(item['root']);assert sha(root/'receipt.json')==item['receipt_sha256'];verify_products(root,read(root/'receipt.json'))
    for path,digest in report['inputs'].items():assert sha(Path(path))==digest
    assert sha(Path(__file__))==report['harness_sha256']
    report['status']='passed'
except BaseException as error:
    report.update(status='error',error=repr(error));raise
finally:save()

