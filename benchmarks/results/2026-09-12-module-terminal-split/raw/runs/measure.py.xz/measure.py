"""Fixed split-schedule comparisons: original controls and same-API single-vs-split."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
RUN = LOG/'verified-a'
SINGLE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-terminal-capture-20260912/--launch')
BASE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-inline-guard-20260912/verified-a')
OUT = LOG/'measurement'
P = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH = '/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
ORDERS = [['baseline','candidate'],['candidate','baseline'],['baseline','candidate'],['candidate','baseline']]
if sys.argv[1:] == ['--launch']:
    if OUT.exists(): raise ValueError('measurement exists; inspect rather than restart')
    with (LOG/'measurement.log').open('xb') as log:
        child = subprocess.Popen([P,'-S',str(Path(__file__).resolve())],cwd=ROOT,stdin=subprocess.DEVNULL,
            stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps(dict(pid=child.pid,log=str(LOG/'measurement.log'))));raise SystemExit(0)
if sys.argv[1:]: raise ValueError('--launch or no arguments')
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
candidate, baseline = read(RUN/'receipt.json'),read(BASE/'receipt.json')
single = read(SINGLE/'receipt.json')
assert single['status'] == 'passed'
assert candidate['status'] == baseline['status'] == 'passed'
assert candidate['source']['commit'] == git('rev-parse','HEAD') and not git('status','--porcelain')
for root,receipt in [(RUN,candidate),(BASE,baseline),(SINGLE,single)]:
    for name,digest in receipt['products'].items(): assert sha(root/name)==digest
OUT.mkdir()
env = dict(os.environ,PYTORCH_ENABLE_MPS_FALLBACK='0',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
report = dict(status='running',pid=os.getpid(),source=candidate['source'],baseline_source=baseline['source'],
    single_submission_source=single['source'],single_submission_receipt_sha256=sha(SINGLE/'receipt.json'),
    orders=ORDERS,steps=[],trials=[],harness_sha256=sha(Path(__file__)),
    candidate_receipt_sha256=sha(RUN/'receipt.json'),baseline_receipt_sha256=sha(BASE/'receipt.json'),
    boundary='Four fixed paired native terminal-vs-ordinary matrices, each with eager Torch controls. Then three separate fixed 4-matrix browser protocols: original-vs-split ordinary API regression control, original ordinary-vs-split terminal API, then prototype single-vs-split using the same terminal API on both sides. Completed read every forward, no retry or filtering. Host/API costs included; no exclusive-host or isolated GPU-cost claim.')


def save():
    temp=OUT/'receipt.json.tmp';temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(OUT/'receipt.json')


def run(name,args):
    args=[str(v) for v in args];print('START',name,flush=True);start=time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        child=subprocess.Popen(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
        report['active']=dict(name=name,pid=child.pid,command=args);save()
        try: code=child.wait(timeout=2100)
        except subprocess.TimeoutExpired:
            child.kill();child.wait();raise
    report.pop('active');report['steps'].append(dict(name=name,exit_code=code,seconds=time.monotonic()-start,command=args));save()
    print('END',name,code,flush=True)
    if code: raise RuntimeError(name)


start=time.monotonic()
try:
    save()
    for trial,order in enumerate(ORDERS,1):
        for version in order:
            root=RUN if version=='candidate' else BASE
            args=[TORCH,'-I','tools/bench_graph_forward_paths.py','--fixture',RUN/'native-forward-bench.json',
                '--native-library',root/'python-release.dylib','--include-module','--output',OUT/f'{trial}-{version}.json']
            if version=='candidate':args+=['--terminal-module']
            run(f'{trial}-{version}',args)
        run(f'{trial}-validation',[P,'-I','tools/validate_module_terminal_paths.py','--fixture',RUN/'native-forward-bench.json',
            '--baseline-python',OUT/f'{trial}-baseline.json','--candidate-python',OUT/f'{trial}-candidate.json',
            '--baseline-receipt',BASE/'receipt.json','--candidate-receipt',RUN/'receipt.json','--output',OUT/f'{trial}-validation.json'])
        assert read(OUT/f'{trial}-validation.json')['status']=='passed'
        report['trials'].append(dict(trial=trial,order=order,
            files={f'{trial}-{label}.json':sha(OUT/f'{trial}-{label}.json') for label in ['baseline','candidate','validation']}));save()
    browser_modes = [
        ('ordinary',BASE,'nn-module-intervals',[]),
        ('terminal',BASE,'nn-module-terminal-intervals',['--terminal-capture']),
        ('same-api',SINGLE,'nn-module-terminal-matched-intervals',['--terminal-capture','--same-terminal-api']),
    ]
    for mode,reference,fixture,flags in browser_modes:
        run(mode+'-browser',['node','tools/test_resident_browser.cjs',RUN/'client',CHROME,
            OUT/(mode+'-browser.json'),'','','','',fixture,reference/'client'])
        args=[P,'-I','tools/validate_module_resident_intervals.py','--fixture',RUN/'native-forward-bench.json',
            '--browser',OUT/(mode+'-browser.json'),'--baseline-receipt',reference/'receipt.json',
            '--candidate-receipt',RUN/'receipt.json','--output',OUT/(mode+'-validation.json'),*flags]
        run(mode+'-validation',args)
        assert read(OUT/(mode+'-validation.json'))['status']=='passed'
    for root,receipt in [(RUN,candidate),(BASE,baseline),(SINGLE,single)]:
        for name,digest in receipt['products'].items():assert sha(root/name)==digest
    assert git('rev-parse','HEAD')==candidate['source']['commit'] and not git('status','--porcelain')
    report['status']='passed'
except BaseException as error:
    report.update(status='error',error=repr(error));raise
finally:
    report['seconds']=time.monotonic()-start;save()
