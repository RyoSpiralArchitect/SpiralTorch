"""Check source-body identity only, not generated code or timing equivalence."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
BASE = '6703df35e8389c3ebb9ddf5eb099f440995a930d'
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
candidate = git('rev-parse', 'HEAD')
assert not git('status', '--porcelain')
rows = []
for path, names in [
    ('crates/st-backend-wgpu/src/resident_tensor.rs', ['apply', 'apply_into', 'snapshot', 'contiguous_into']),
    ('crates/st-backend-wgpu/src/resident_graph/direct.rs', ['forward_tensor']),
    ('crates/st-nn/src/resident/module_forward.rs', ['forward']),
]:
    for name in names:
        bodies = []
        for source in [BASE, candidate]:
            text = git('show', source + ':' + path)
            match = re.search(r'^    (?:pub(?:\(crate\))? )?fn ' + name + r'\(', text, re.MULTILINE)
            assert match is not None, (path, name)
            end = text.index('\n    }', match.start()) + len('\n    }')
            bodies.append(text[match.start():end])
        assert bodies[0] == bodies[1], (path, name)
        rows.append(dict(path=path, function=name, bytes=len(bodies[0].encode()),
                         sha256=hashlib.sha256(bodies[0].encode()).hexdigest()))
report = dict(status='passed', baseline_commit=BASE, candidate_commit=candidate, functions=rows,
              boundary='Exact restored source functions, not machine-code identity or a zero-regression performance claim.')
with Path(__file__).with_suffix('.json').open('x') as output:
    json.dump(report, output, indent=2); output.write('\n')
print(json.dumps(report))
