"""Freeze split scheduling, original controls and same-API evidence without filtering."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import statistics
import subprocess
import sys

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
RUN = LOG/'verified-a'
SINGLE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-terminal-capture-20260912/--launch')
BASE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-inline-guard-20260912/verified-a')
MEASURE = LOG/'measurement'
OUT = ROOT/'benchmarks/results/2026-09-12-module-terminal-split'
sys.path.insert(0,str(ROOT/'tools'))
from validate_module_resident_intervals import admit_case_stream, admit_native, validate
from validate_module_forward_paths import validate_python

sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_bytes())
git = lambda *args: subprocess.check_output(['git',*args],cwd=ROOT)


def write(path,value):
    path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def checked(path,count=None):
    receipt=read(path)
    assert receipt['status']=='passed' and 'active' not in receipt
    assert all(step['exit_code']==0 for step in receipt['steps'])
    if count is not None:assert len(receipt['steps'])==count
    return receipt


assert not OUT.exists(), 'archive exists; inspect rather than overwrite'
base=checked(BASE/'receipt.json')
single=checked(SINGLE/'receipt.json',56)
run=checked(RUN/'receipt.json',56)
measure=checked(MEASURE/'receipt.json',18)
body_identity=read(LOG/'verify_original_bodies.json')
assert body_identity['status']=='passed' and len(body_identity['functions'])==6
assert body_identity['candidate_commit']==run['source']['commit']
assert body_identity['baseline_commit']==base['source']['commit']
assert sha((SINGLE/'receipt.json').read_bytes())==measure['single_submission_receipt_sha256']
assert git('rev-parse','HEAD').decode().strip()==run['source']['commit']==measure['source']['commit']
assert not git('status','--porcelain').strip()
assert sha((RUN/'receipt.json').read_bytes())==measure['candidate_receipt_sha256']
for report in (run,measure):
    assert sha((BASE/'receipt.json').read_bytes())==report['baseline_receipt_sha256']
for report,name in ((run,'run.py'),(measure,'measure.py')):
    assert sha((LOG/name).read_bytes())==report['harness_sha256']
products=[]
for label,folder,receipt in [('baseline',BASE,base),('single-submission',SINGLE,single),('candidate',RUN,run)]:
    for name,digest in receipt['products'].items():
        path=folder/name
        assert sha(path.read_bytes())==digest,str(path)
        products.append(dict(version=label,path=str(path),sha256=digest))
assert len(products)==61
native=read(RUN/'native-forward-bench.json');old_native=read(BASE/'native-forward-bench.json')
admit_native(native);admit_native(old_native)
for old,new in zip(old_native['cases'],native['cases'],strict=True):
    keys=set(old)-{'samples','compile_two_graphs_ms'}
    assert keys==set(new)-{'samples','compile_two_graphs_ms'}
    assert {k:old[k] for k in keys}=={k:new[k] for k in keys}
intervals={}
for mode in ['ordinary','terminal','same-api']:
    validation=read(MEASURE/(mode+'-validation.json'))
    browser_path=MEASURE/(mode+'-browser.json');browser=read(browser_path)
    assert validation['status']=='passed' and validation['candidate_source']==run['source']
    assert validation['baseline_source']==(single if mode=='same-api' else base)['source']
    for name,digest in validation['sources'].items(): assert sha(Path(name).read_bytes())==digest,name
    admit_case_stream(browser,browser_path)
    again=validate(browser,native,terminal_capture=mode!='ordinary',same_terminal_api=mode=='same-api')
    assert all(validation[key]==value for key,value in again.items())
    intervals[mode]=dict(**{k:v for k,v in again.items() if k!='cases'},protocol=validation['protocol'],
        baseline_source=validation['baseline_source'],candidate_source=validation['candidate_source'],
        module_apis=browser.get('module_apis',dict(baseline='forward_then_snapshot',candidate='forward_then_snapshot')),
        browser_version=browser['browser_version'],cross_origin_isolated=browser['cross_origin_isolated'],
        adapters=browser['cases'][0]['adapters'],validation_sha256=sha((MEASURE/(mode+'-validation.json')).read_bytes()),
        boundary=validation['boundary'])
rows=[]
for trial in range(1,5):
    report=read(MEASURE/f'{trial}-validation.json')
    assert report['status']=='passed'
    for name,digest in report['sources'].items(): assert sha(Path(name).read_bytes())==digest,name
    old=validate_python(read(MEASURE/f'{trial}-baseline.json'),native,RUN/'native-forward-bench.json')
    new=validate_python(read(MEASURE/f'{trial}-candidate.json'),native,RUN/'native-forward-bench.json',terminal_capture=True)
    for row,a,b in zip(report['python'],old,new,strict=True):
        assert row['baseline']==a and row['candidate']==b
        for route,ratio in row['candidate_over_baseline'].items():
            assert ratio==b['summary'][route]['median_ms_per_forward']/a['summary'][route]['median_ms_per_forward']
        rows.append(row)
aggregates=[]
for shape in dict.fromkeys(tuple(row['shape']) for row in rows):
    selected=[row for row in rows if tuple(row['shape'])==shape]
    routes={}
    for route in selected[0]['candidate_over_baseline']:
        values=[row['candidate_over_baseline'][route] for row in selected]
        routes[route]=dict(median_of_case_median_ratios=statistics.median(values),min_ratio=min(values),max_ratio=max(values),
                           regressions=sum(v>1 for v in values),total_cases=len(values))
    aggregates.append(dict(shape=list(shape),routes=routes))
torch=read(RUN/'torch-correctness.json');assert torch['status']=='passed'
module=read(RUN/'browser-module-forward.json');assert module['terminal_forward_capture'] is True
nd=read(RUN/'browser-nd.json')['tensor_snapshots'];assert nd['terminal_cancelled_pending_maps']==4
counts={}
for path in RUN.glob('*.log'):
    text=path.read_text()
    rust=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    python=re.findall(r'^Ran (\d+) tests? in',text,re.MULTILINE)
    if rust or python:
        assert all(int(f)==0 for _,f,_ in rust)
        counts[path.name]=dict(rust_passed=sum(int(p) for p,_,_ in rust),rust_ignored=sum(int(i) for _,_,i in rust),python_ran=sum(map(int,python)))
files={'runs/'+str(p.relative_to(LOG)):p for p in LOG.rglob('*') if p.is_file() and '__pycache__' not in p.parts
       and p.suffix in ('.json','.jsonl','.log','.py','.js','.mjs','.ts','.html')}
loader=Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py')
assert sha(loader.read_bytes())==run['loader_sha256']
files.update({'inputs/baseline-receipt.json':BASE/'receipt.json','inputs/baseline-native-fixture.json':BASE/'native-forward-bench.json',
              'inputs/single-submission-receipt.json':SINGLE/'receipt.json',
              'inputs/single-submission-summary.json':ROOT/'benchmarks/results/2026-09-12-module-terminal-capture/summary.json',
              'inputs/python-client.py':loader,'inputs/cpu_probe.py':Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-parameter-handoff-20260912/cpu_probe.py')})
payloads={name:(path.read_bytes(),dict(path=str(path))) for name,path in files.items()}
names={name for name in git('diff','--name-only','65955fd2',run['source']['commit']).decode().splitlines()
       if not name.startswith('benchmarks/results/')}
names.update(['tools/test_module_direct_io.py','tools/test_module_resident_intervals.mjs','tools/test_module_forward_reference.py',
              'tools/validate_module_direct_io.py','tools/validate_resident_graph_training_vs_torch.py',
              'tools/bench_resident_nn_vs_torch.py','tools/resident_module_handoff_fixture.py',
              'bindings/st-wasm/tests/module_resident_intervals.mjs','bindings/st-wasm/tests/module_resident_matched.html',
              'crates/st-nn/examples/resident_graph_forward_bench.rs','crates/st-backend-wgpu/src/runtime.rs'])
for label,source in [('baseline',base['source']),('single-submission',single['source']),('candidate',run['source'])]:
    existing=set(git('ls-tree','-r','--name-only',source['commit']).decode().splitlines())
    for name in sorted(names & existing):
        payloads[f'source/{label}/{name}']=(git('show',source['commit']+':'+name),dict(git_commit=source['commit'],git_path=name))
(OUT/'raw').mkdir(parents=True)
entries=[]
for name,(data,origin) in sorted(payloads.items()):
    packed=lzma.compress(data);path=OUT/'raw'/(name+'.xz');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(packed)
    assert lzma.decompress(path.read_bytes())==data
    entries.append(dict(archive=str(path.relative_to(OUT)),origin=origin,bytes=len(data),sha256=sha(data),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
manifest=dict(schema='spiraltorch.source_archive.v1',status='passed',records=entries,
    raw_bytes=sum(r['bytes'] for r in entries),compressed_bytes=sum(r['compressed_bytes'] for r in entries))
write(OUT/'manifest.json',manifest)
summary=dict(schema='spiraltorch.module_terminal_split_record.v1',status='passed',baseline_source=base['source'],candidate_source=run['source'],
    single_submission_source=single['source'],
    decision='Retain the explicit terminal API with original split scheduling: all 36 same-API browser pairs improve over the rejected single-submission prototype, with shape medians 1.8-5.7% lower. Original ordinary controls remain 0.2-0.6% slower and terminal-vs-original medians 0.2-0.4% slower. No original-baseline speedup or zero-regression claim.',
    source_body_identity=body_identity,
    verification_steps=len(run['steps']),verification_seconds=run['seconds'],measurement_steps=len(measure['steps']),measurement_seconds=measure['seconds'],
    test_counts=counts,browser_module_assertions=module['assertions'],tensor_snapshot_checks=nd,
    torch_correctness=dict(version=torch['torch'],cases=len(torch['cases']),comparisons=sum(r['comparisons'] for r in torch['cases']),
                           max_abs_error=max(r['max_abs_error'] for r in torch['cases']),scope=torch['scope']),
    browser_intervals=intervals,native_terminal_aggregates=aggregates,native_orders=measure['orders'],
    interval_completed_reads=sum(v['checked_forwards_including_warmup'] for v in intervals.values()),
    interval_compared_values=sum(v['checked_values_including_warmup'] for v in intervals.values()),
    frozen_products_checked=len(products),products=products,raw_records=len(entries),manifest_sha256=sha((OUT/'manifest.json').read_bytes()),
    verification_directory_note='The split run used the explicit fresh name verified-a. The rejected single-submission reference keeps its original literal --launch directory unchanged.',
    boundary='Split terminal API versus original forward+snapshot plus a separate same-API single-vs-split comparison, not a new automatic policy. Native Apple M4/Metal; eager Torch with no MPS CPU fallback. Browser physical GPU and host exclusivity UNKNOWN. No GPU kernel-time attribution, CUDA/Furnace, generic autograd migration, release, push or merge. All samples and ordinary-path controls retained.')
write(OUT/'summary.json',summary)
print(json.dumps(dict(status='passed',records=len(entries),raw_bytes=manifest['raw_bytes'],compressed_bytes=manifest['compressed_bytes'],products=len(products))))
