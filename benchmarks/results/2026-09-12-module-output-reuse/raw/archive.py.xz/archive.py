"""Preserve source-bound bounded-output reuse, including all timing rows."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import statistics
import subprocess
import sys

LOG=Path(__file__).parent
ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
RUN=LOG/sys.argv[1]
OUT=ROOT/'benchmarks/results/2026-09-12-module-output-reuse'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
receipt=read(RUN/'receipt.json')
assert receipt['status']=='passed' and all(s['exit_code']==0 for s in receipt['steps'])
assert receipt['source']['commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
assert sha(LOG/'run.py')==receipt['harness_sha256']
for name,digest in receipt['products'].items():assert sha(RUN/name)==digest,name
validation=read(RUN/'direct-io-validation.json')
replay=read(RUN/'module-forward-validation.json')
assert validation['status']==replay['status']=='passed'
report=dict(schema='spiraltorch.module_output_reuse_evidence.v1',status='passed',adopted=RUN.name,
    source=receipt['source'],baseline_source=receipt['baseline_source'],steps=len(receipt['steps']),
    products=receipt['products'],verification={},
    capabilities=[
        'Original Module forwarding reuses output values, owning guards and final-stage bindings only when no strong/weak tensor or guard owner can observe the old version.',
        'A per-graph four-slot / 32 MiB output-data budget bounds retention; busy or oversized slots allocate separately without blocking or CPU fallback.',
        'Multi-stage graphs reuse the first boundary for identical packed input storage. Explicit upload/set-input clears the key. Singleton/changed-input boundaries still rebind.',
        'Native resource tests confirm two output allocations for twenty fixed-input forwards, three for recurrent forwarding, and four with a retained early view/consumer. Test-only counters are absent from measured production builds.',
        'Rust, Python and browser checks cover retained views/consumers, pending snapshots, shared guards, saturation, the actual 32 MiB boundary, cache drop, and another thread retaining a version.'
    ],boundaries=[
        'Reuse is ownership-gated, not a claim of global allocation-free execution. Per-call descriptors, CPU parameter checks, command encoders, scratch flags and terminal readbacks remain.',
        'The 32 MiB budget is retained output values/flags, not total physical GPU, binding, model or scratch memory. User-retained outputs can exceed it.',
        'No shader math, accumulation policy, one-submission schedule, error thresholds or automatic pure Tensor/autograd/ModuleTrainer routing changes.',
        'Browser A/B uses separate WASM/device instances in one page with rotated serial routes. Physical browser GPU and host exclusivity UNKNOWN; browser samples are visibly quantized.',
        'Native versions run serially in separate processes, each with eager Torch controls. Control drift is retained and cannot be entirely attributed to the code change.',
        'Burst means eight independent fixed-input forwards plus final completed host observation, not recurrent decoding, peak GPU timestamps or fastest PyTorch.',
        'No CUDA/Furnace, push, merge or release in this slice. Preliminary dirty-source logs are only preflight, not admitted timing evidence.'
    ])
for name in ['contracts','tensor-cpu','tensor-wgpu','nn-cpu-handoff','nn-serial','backend-serial','integration']:
    matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (RUN/(name+'.log')).read_text())
    assert matches and all(int(m[1])==0 for m in matches),name
    report['verification'][name]=dict(passed=sum(int(m[0]) for m in matches),ignored=sum(int(m[2]) for m in matches))
report['verification']['python_existing']=read(RUN/'python-tests.json')
for name in ['admission-tests','python-graph_autograd','python-graph_learner','python-module_update','python-pointwise',
             'python-module-forward','python-cpu-handoff','python-cpu-module-forward','torch-reference-shapes']:
    log=(RUN/(name+'.log')).read_text();match=re.search(r'Ran (\d+) tests?',log)
    assert match and '\nOK\n' in log and 'skipped=' not in log,name
    report['verification'][name]=dict(tests=int(match[1]),status='passed')
report['verification']['cpu_build']=read(RUN/'python-cpu-probe.json')
assert report['verification']['cpu_build']['status']=='passed'
for name in ['browser-handoff','browser-module-forward','browser-module-matched','browser-to-python','browser-to-cpu-python',
             'wasm-pointwise','wasm-learner','wasm-autograd','wasm-fusion','wasm-forward','torch-correctness']:
    item=read(RUN/(name+'.json'));assert item['status']=='passed',name
    report['verification'][name]={k:v for k,v in item.items() if k in ['status','schema','adapter','assertions','comparisons','max_abs_error','direct_io_guards','output_reuse_guards']}
    if isinstance(item.get('cases'),list):report['verification'][name]['cases']=len(item['cases'])
    if name=='torch-correctness':report['verification'][name].update(comparisons=sum(c['comparisons'] for c in item['cases']),max_abs_error=max(c['max_abs_error'] for c in item['cases']))
report['browser_replay']=replay['browser_replay']
report['python_timing']=validation['python'];report['browser_timing']=validation['browser']
report['timing_groups']=[]
for shape in [[2,3,7],[2,8,64],[4,8,128]]:
    py=[c for c in validation['python'] if c['shape']==shape]
    web=[c for c in validation['browser'] if c['shape']==shape]
    assert len(py)==len(web)==3
    median=lambda c,r:c['summary'][r]['median_ms_per_forward']
    ratios=lambda values:dict(min=min(values),max=max(values),median=statistics.median(values))
    report['timing_groups'].append(dict(shape=shape,depth=py[0]['depth'],
        python_ms={v:statistics.median(median(c[v],'module_resident_burst') for c in py) for v in ['baseline','candidate']},
        python_candidate_over_baseline=ratios([c['candidate_over_baseline']['module_resident_burst'] for c in py]),
        python_candidate_over_torch=ratios([c['candidate']['module_burst_over_torch_mps'] for c in py]),
        browser_ms={v:statistics.median(median(c,v+'_module_burst') for c in web) for v in ['baseline','candidate']},
        browser_candidate_over_baseline=ratios([c['candidate_over_baseline']['module_burst'] for c in web])))
report['regressions']={
    'python_module_burst':[dict(shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_resident_burst']) for c in validation['python'] if c['candidate_over_baseline']['module_resident_burst']>1],
    'browser_module_burst':[dict(shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_burst']) for c in validation['browser'] if c['candidate_over_baseline']['module_burst']>1],
    'python_slower_than_torch':[dict(shape=c['shape'],seed=c['seed'],ratio=c['candidate']['module_burst_over_torch_mps']) for c in validation['python'] if c['candidate']['module_burst_over_torch_mps']>1],
    'python_module_d2h':[dict(shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_resident_d2h']) for c in validation['python'] if c['candidate_over_baseline']['module_resident_d2h']>1],
    'browser_module_d2h':[dict(shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_d2h']) for c in validation['browser'] if c['candidate_over_baseline']['module_d2h']>1],
    'native_control_drift_over_ten_percent':[dict(shape=c['shape'],seed=c['seed'],route=r,ratio=c['candidate_over_baseline'][r]) for c in validation['python'] for r in ['python_scalar_burst','torch_mps_burst'] if not .9<=c['candidate_over_baseline'][r]<=1.1],
}
replication=read(LOG/'replications/receipt.json')
assert replication['status']=='passed' and len(replication['trials'])==3
assert len(replication['steps'])==12 and all(s['exit_code']==0 for s in replication['steps'])
assert replication['source']==receipt['source'] and replication['baseline_source']==receipt['baseline_source']
assert sha(LOG/'replicate.py')==replication['harness_sha256']
assert replication['orders']==[['candidate','baseline'],['baseline','candidate'],['candidate','baseline']]
series=[dict(label='initial',order=['baseline','candidate'],validation=validation)]
for trial in replication['trials']:
    for name,digest in trial['files'].items():assert sha(LOG/'replications'/name)==digest,name
    value=read(LOG/f"replications/{trial['trial']}-validation.json")
    assert value['status']=='passed'
    series.append(dict(label=str(trial['trial']),order=trial['order'],validation=value))
report['replications']=dict(receipt=replication,series=series,
    boundary='Four complete matrices retained: initial plus three counterbalanced native replications. Twelve seed-run medians per shape/client. No inferential significance or host exclusivity claim.')
report['verification_steps_total']=report['steps']+len(replication['steps'])
report['initial_regressions']=report.pop('regressions')
report['all_trials_regressions']={
    'python_module_burst':[dict(trial=s['label'],shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_resident_burst']) for s in series for c in s['validation']['python'] if c['candidate_over_baseline']['module_resident_burst']>1],
    'browser_module_burst':[dict(trial=s['label'],shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_burst']) for s in series for c in s['validation']['browser'] if c['candidate_over_baseline']['module_burst']>1],
    'python_module_d2h':[dict(trial=s['label'],shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_resident_d2h']) for s in series for c in s['validation']['python'] if c['candidate_over_baseline']['module_resident_d2h']>1],
    'browser_module_d2h':[dict(trial=s['label'],shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_d2h']) for s in series for c in s['validation']['browser'] if c['candidate_over_baseline']['module_d2h']>1],
    'native_control_drift_over_ten_percent':[dict(trial=s['label'],shape=c['shape'],seed=c['seed'],route=r,ratio=c['candidate_over_baseline'][r]) for s in series for c in s['validation']['python'] for r in ['python_scalar_burst','torch_mps_burst'] if not .9<=c['candidate_over_baseline'][r]<=1.1],
}
report['all_trials_groups']=[]
spread=lambda values:dict(min=min(values),max=max(values),median=statistics.median(values))
for shape in [[2,3,7],[2,8,64],[4,8,128]]:
    py=[c for s in series for c in s['validation']['python'] if c['shape']==shape]
    web=[c for s in series for c in s['validation']['browser'] if c['shape']==shape]
    assert len(py)==len(web)==12
    median=lambda c,r:c['summary'][r]['median_ms_per_forward']
    report['all_trials_groups'].append(dict(shape=shape,depth=py[0]['depth'],seed_run_pairs=12,
        python_ms={v:statistics.median(median(c[v],'module_resident_burst') for c in py) for v in ['baseline','candidate']},
        python_candidate_over_baseline=spread([c['candidate_over_baseline']['module_resident_burst'] for c in py]),
        python_d2h_candidate_over_baseline=spread([c['candidate_over_baseline']['module_resident_d2h'] for c in py]),
        python_candidate_over_torch=spread([c['candidate']['module_burst_over_torch_mps'] for c in py]),
        python_control_drift={r:spread([c['candidate_over_baseline'][r] for c in py]) for r in ['python_scalar_burst','torch_mps_burst']},
        browser_ms={v:statistics.median(median(c,v+'_module_burst') for c in web) for v in ['baseline','candidate']},
        browser_candidate_over_baseline=spread([c['candidate_over_baseline']['module_burst'] for c in web]),
        browser_d2h_candidate_over_baseline=spread([c['candidate_over_baseline']['module_d2h'] for c in web]),
        browser_scalar_control_drift=spread([c['candidate_over_baseline']['scalar_burst'] for c in web])))
OUT.mkdir()
paths=sorted(set(LOG.rglob('*.json'))|set(LOG.rglob('*.log'))|{LOG/'run.py',LOG/'replicate.py',LOG/'archive.py'})
manifest=[]
for path in paths:
    relative=path.relative_to(LOG);destination=OUT/'raw'/(str(relative)+'.xz')
    destination.parent.mkdir(parents=True,exist_ok=True)
    raw=path.read_bytes();compressed=lzma.compress(raw,preset=6)
    assert lzma.decompress(compressed)==raw
    destination.write_bytes(compressed)
    manifest.append(dict(path=str(destination.relative_to(OUT)),original=str(relative),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),compressed_bytes=len(compressed),compressed_sha256=sha(destination)))
report['archive']=dict(files=len(manifest),raw_bytes=sum(p['bytes'] for p in manifest),compressed_bytes=sum(p['compressed_bytes'] for p in manifest))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'summary.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
assert {str(p.relative_to(OUT)) for p in (OUT/'raw').rglob('*.xz')}=={p['path'] for p in manifest}
print(json.dumps(dict(output=str(OUT),source=report['source'],steps=report['steps'],archive=report['archive'],all_trials_groups=report['all_trials_groups']),indent=2))
