"""Serial, source-bound checks. Separate products from the shared Cargo cache."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

W = Path('/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-resident-graph-forward-v1')
L = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-20260910')
T = Path('/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-spiralk-golden-blackcat-contract-v1/target')
P = '/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
env = dict(os.environ, CARGO_TARGET_DIR=str(T), CARGO_BUILD_JOBS='4',
           SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1', PYO3_PYTHON=P,
           PYTORCH_ENABLE_MPS_FALLBACK='0',
           NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
cargo = ['cargo', '+1.98.0']
receipt = dict(status='running', checks=[], products={}, base=subprocess.check_output(
    ['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip(), source_sha256={})
files = subprocess.check_output(['git', 'ls-files', '-m', '-o', '--exclude-standard'], cwd=W, text=True).splitlines()
for name in files:
    receipt['source_sha256'][name] = hashlib.sha256((W/name).read_bytes()).hexdigest()


def save():
    (L/'final-receipt-v2.json').write_text(json.dumps(receipt, indent=2)+'\n')


def run(label, args, output=None):
    label += '-v2'
    print('START', label, flush=True)
    start = time.monotonic()
    with (L/(label+'.log')).open('x') as log:
        if output:
            with (L/output).open('x') as out:
                result = subprocess.run(args, cwd=W, env=env, stdout=out, stderr=log)
        else:
            result = subprocess.run(args, cwd=W, env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt['checks'].append(dict(label=label, command=args, exit_code=result.returncode,
                                 seconds=time.monotonic()-start, output=output))
    save()
    print('END', label, result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(label)


try:
    run('final-fmt', ['cargo', '+nightly-2026-04-15', 'fmt', '--all', '--', '--check'])
    run('final-backend-tests', cargo+['test','--locked','--release','-p','st-backend-wgpu','--lib','--','--test-threads=1'])
    run('final-nn-tests', cargo+['test','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu',
        '--lib','--test','resident_inference','--test','resident_training','--test','resident_nd_tensor',
        '--test','resident_graph_training','--test','resident_graph_forward','--','--test-threads=1'])
    run('final-backend-clippy', cargo+['clippy','--locked','-p','st-backend-wgpu','--all-targets','--','-D','warnings'])
    run('final-backend-wasm-clippy', cargo+['clippy','--locked','-p','st-backend-wgpu',
        '--target','wasm32-unknown-unknown','--all-targets','--','-D','warnings'])
    run('final-python-check', cargo+['check','--locked','--manifest-path','bindings/st-py/Cargo.toml'])
    run('final-wasm-package-check', cargo+['check','--locked','--manifest-path','bindings/st-wasm/Cargo.toml',
        '--no-default-features','--features','webgpu','--target','wasm32-unknown-unknown'])
    run('final-admission', [P,'-I','tests/test_resident_graph_forward_validation.py','-v'])
    run('final-native', cargo+['run','--locked','--release','-p','st-nn','--no-default-features',
        '--features','wgpu','--example','resident_graph_forward'], 'native-final.json')
    run('final-wasm-build', cargo+['build','--locked','--release','-p','st-nn','--no-default-features',
        '--features','wgpu','--target','wasm32-unknown-unknown','--example','resident_graph_forward_browser'])
    run('final-bindgen', ['/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen',
        str(T/'wasm32-unknown-unknown/release/examples/resident_graph_forward_browser.wasm'),
        '--target','web','--out-dir',str(L/'browser-final'),'--out-name','spiraltorch_wasm'])
    run('final-browser', ['node','tools/test_resident_browser.cjs',str(L/'browser-final'),
        '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',str(L/'browser-final.json'),
        '', '', '', '', 'nn-graph-forward'])
    run('final-torch', ['/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python',
        '-I','tools/verify_resident_graph_forward_torch.py',str(L/'native-final.json'),str(L/'browser-final.json'),
        '--output',str(L/'torch-final.json')])
    run('final-diff-check', ['git','diff','--check'])
    for name, expected in receipt['source_sha256'].items():
        if hashlib.sha256((W/name).read_bytes()).hexdigest() != expected:
            raise RuntimeError('source changed during verification: '+name)
    for path in [L/'native-final.json',L/'browser-final.json',L/'torch-final.json',
                 T/'release/examples/resident_graph_forward', *sorted((L/'browser-final').rglob('*'))]:
        if path.is_file():
            receipt['products'][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    receipt['status'] = 'passed'
except Exception as error:
    receipt.update(status='error', error=repr(error))
    raise
finally:
    save()
