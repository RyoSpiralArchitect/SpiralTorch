"""Archive derived reports without publishing binaries or ambient environment."""
import hashlib
import json
import lzma
from pathlib import Path

W = Path('/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-resident-graph-forward-v1')
L = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-20260910')
out = W/'benchmarks/results/2026-09-10-resident-graph-forward'
out.mkdir(parents=True, exist_ok=False)
(out/'raw').mkdir()
receipt = json.loads((L/'final-receipt-v2.json').read_text())
if receipt['status'] != 'passed':
    raise RuntimeError('final checks did not pass')
for name, sha in receipt['source_sha256'].items():
    if hashlib.sha256((W/name).read_bytes()).hexdigest() != sha:
        raise RuntimeError('verified source changed: '+name)
entries = []
paths = [L/'native-final.json', L/'browser-final.json', L/'torch-final.json',
         L/'final-receipt-v2.json', L/'verify-final.py', L/'pack-evidence.py',
         L/'final-receipt.json', L/'verify-first-attempt.py.gz',
         L/'final-backend-tests.log', L/'backend-failure-isolated.log',
         L/'baseline-parallel-backend.log', L/'baseline-parallel-repeats.json',
         L/'candidate-parallel-backend.log', L/'candidate-parallel-repeats.json']
paths.extend(sorted(L.glob('final-*-v2.log')))
paths.extend(sorted(L.glob('baseline-parallel-repeat-*.log')))
paths.extend(sorted(L.glob('candidate-parallel-repeat-*.log')))
for path in paths:
    raw = path.read_bytes()
    compressed = lzma.compress(raw)
    name = 'raw/'+path.name+'.xz'
    (out/name).write_bytes(compressed)
    entries.append(dict(path=name, original_name=path.name, bytes=len(raw),
                        sha256=hashlib.sha256(raw).hexdigest(),
                        compressed_sha256=hashlib.sha256(compressed).hexdigest()))
native = json.loads((L/'native-final.json').read_text())
browser = json.loads((L/'browser-final.json').read_text())
torch = json.loads((L/'torch-final.json').read_text())
summary = dict(schema='spiraltorch.resident_graph_forward_evidence.v1',
    feature_checks='passed', parallel_regression_status='unresolved_single_failure',
    source=dict(kind='working_tree', base=receipt['base'], files_sha256=receipt['source_sha256']),
    native=native['adapter'], browser=dict(version=browser['browser_version'], adapter=browser['adapter'],
                                          physical_adapter_verified=False),
    torch=dict(version=torch['torch'], devices=sorted({c['device'] for c in torch['cases']}),
               replays=len(torch['cases']), comparisons=sum(c['comparisons'] for c in torch['cases']),
               max_abs_error=max(c['max_abs_error'] for c in torch['cases'])),
    native_cases=len(native['cases']), browser_cases=len(browser['cases']),
    guards=native['guards'], verified_checks=receipt['checks'], product_sha256=receipt['products'],
    tests=dict(backend_serial=111, nn_lib=733, gpu_integration=8, admission_only=5),
    unresolved=dict(test='resident_training::stage_tests::transposed_vjps_cover_rectangular_tiles_and_partial_edges_when_enabled',
        observed='one initial candidate parallel-suite failure: prediction[0] 0 != -0.044921875',
        isolation='passed', baseline_parallel_additional_repetitions=10,
        candidate_parallel_additional_repetitions=10, repeated_failures=0,
        root_cause='UNKNOWN; not claimed fixed or proven pre-existing'),
    boundary='Explicit Rust forward compiler; real native/browser execution; not public Python/JS mixed inference, automatic Module/autograd residency, throughput or CUDA evidence.')
(out/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
(out/'manifest.json').write_text(json.dumps(dict(schema='spiraltorch.hash_archive.v1',entries=entries),indent=2)+'\n')
for entry in entries:
    packed=(out/entry['path']).read_bytes()
    assert hashlib.sha256(packed).hexdigest()==entry['compressed_sha256']
    assert hashlib.sha256(lzma.decompress(packed)).hexdigest()==entry['sha256']
print(json.dumps(dict(directory=str(out),archives=len(entries),compressed_bytes=sum((out/e['path']).stat().st_size for e in entries),torch=summary['torch']),indent=2))
