"""Preserve source-bound in-pass terminal guard validation and matched comparisons."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import statistics
import subprocess
import sys

LOG=Path(__file__).parent
ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
RUN=LOG/sys.argv[1]
OUT=ROOT/'benchmarks/results/2026-09-12-module-inline-guard'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
receipt=read(RUN/'receipt.json')
assert receipt['status']=='passed' and all(s['exit_code']==0 for s in receipt['steps'])
assert receipt['source']['commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
assert sha(LOG/'run.py')==receipt['harness_sha256']
for name,digest in receipt['products'].items():assert sha(RUN/name)==digest,name
validation=read(RUN/'direct-io-validation.json')
replay=read(RUN/'module-forward-validation.json')
assert validation['status']==replay['status']=='passed'
report=dict(schema='spiraltorch.module_inline_guard_evidence.v1',status='passed',adopted=RUN.name,
    source=receipt['source'],baseline_source=receipt['baseline_source'],steps=len(receipt['steps']),
    products=receipt['products'],verification={},
    capabilities=[
        'Direct resident graph forwards append the terminal output-guard capture dispatch to the same compute pass as all NN stages, removing one pass boundary.',
        'Shader sources, arithmetic, stage flag addresses, dispatch order/count, queue submission count, parameters, direct I/O and output-slot ownership are unchanged.',
        'One clear and the upstream flag copy still precede graph execution. The terminal guard still runs and overwrites recycled output flags; no validation is skipped.',
        'Rust, Python and WASM share the same backend implementation. Existing content-stamp reuse, finite checks, lowering and explicit snapshot semantics are retained.'
    ],boundaries=[
        'This is compute-pass grouping, not operator fusion, a removed dispatch, an allocation-free guarantee, or automatic Tensor/autograd/ModuleTrainer migration.',
        'View packing may use another pass. Explicit dispatch and snapshot/output-capture APIs retain their separate behaviors; the one-pass statement concerns direct graph plus terminal capture.',
        'The 32 MiB budget is retained output values/flags, not total physical GPU, binding, model or scratch memory. User-retained outputs can exceed it.',
        'Native versions run serially in separate processes. Browser A/B uses two frozen WASM/device instances in one page and rotates serial routes. Physical browser GPU and host exclusivity UNKNOWN; browser samples are quantized.',
        'The untargeted explicit dispatch route and eager Torch remain controls; explicit graph commands omit terminal capture and keep their schedule. Ratios are descriptive and never normalized to hide drift.',
        'Burst means eight independent fixed-input forwards plus final completed host observation, not recurrent decoding, peak GPU timestamps or fastest PyTorch.',
        'No CUDA/Furnace, push, merge or release in this slice. Frozen source 04fec016 is the immediately preceding verified content-stamp baseline.'
    ])
report['selection_context']='Isolated compute-pass grouping change versus content-stamp runtime 04fec016. One candidate and four complete paired matrices; no adaptive selection or discarded timing attempts.'
for name in ['contracts','tensor-cpu','tensor-wgpu','nn-cpu','nn-serial','backend-serial','integration','descriptor-cpu','descriptor-wgpu']:
    matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (RUN/(name+'.log')).read_text())
    assert matches and all(int(m[1])==0 for m in matches),name
    report['verification'][name]=dict(passed=sum(int(m[0]) for m in matches),ignored=sum(int(m[2]) for m in matches))
report['verification']['python_existing']=read(RUN/'python-tests.json')
for name in ['admission-tests','python-graph_autograd','python-graph_learner','python-module_update','python-pointwise',
             'python-module-forward','python-cpu-handoff','python-cpu-module-forward','torch-reference-shapes']:
    log=(RUN/(name+'.log')).read_text();match=re.search(r'Ran (\d+) tests?',log)
    assert match and '\nOK\n' in log and 'skipped=' not in log,name
    report['verification'][name]=dict(tests=int(match[1]),status='passed')
report['verification']['cpu_build']=read(RUN/'python-cpu-probe.json')
assert report['verification']['cpu_build']['status']=='passed'
for name in ['browser-handoff','browser-module-forward','browser-module-matched','browser-to-python','browser-to-cpu-python',
             'wasm-pointwise','wasm-learner','wasm-autograd','wasm-fusion','wasm-forward','torch-correctness']:
    item=read(RUN/(name+'.json'));assert item['status']=='passed',name
    report['verification'][name]={k:v for k,v in item.items() if k in ['status','schema','adapter','assertions','comparisons','max_abs_error','direct_io_guards','output_reuse_guards','shared_stage_guards','terminal_guard_ordering']}
    if isinstance(item.get('cases'),list):report['verification'][name]['cases']=len(item['cases'])
    if name=='torch-correctness':report['verification'][name].update(comparisons=sum(c['comparisons'] for c in item['cases']),max_abs_error=max(c['max_abs_error'] for c in item['cases']))
assert report['verification']['browser-module-forward']['shared_stage_guards'] is True
assert report['verification']['browser-module-forward']['terminal_guard_ordering'] is True
assert 'test resident_graph::guard_tests::terminal_guard_observes_late_workgroups_and_survives_queued_valid_forwards ... ok' in (RUN/'backend-serial.log').read_text()
assert 'test_late_workgroup_guard_survives_same_pass_capture_and_slot_reuse' in (RUN/'python-module-forward.log').read_text()
nn=(RUN/'nn-serial.log').read_text()
for name in ['exact_comparison_preserves_bits_at_odd_lengths_and_nonfinite_payloads','cache_detects_signed_zero_and_last_word_foreign_linear_updates','stamps_skip_scans_refresh_equal_replacements_and_revoke_on_late_export','native_cached_linear_detects_later_export_and_retains_original_output']:
    assert f'test resident::module_forward::tests::{name} ... ok' in nn
report['development_failures'] = {}
report['development_context']='backend-focused.log is the pre-freeze 15-test GPU-enabled development check; the full adopted-source verification is separate.'
report['allocation_checks']={}
for name in ['descriptor-cpu','descriptor-wgpu']:
    content=(RUN/(name+'.log')).read_text()
    match=re.search(r'descriptor allocations: previous assembly=(\d+), current=(\d+)',content)
    assert match and int(match[1])>=64 and int(match[2])==1
    assert 'nested caller-capacity assembly: 0 allocations across each of 20 calls' in content
    report['allocation_checks'][name]=dict(previous_assembly=int(match[1]),current_assembly=int(match[2]),nested_with_capacity=0,
        boundary='Native integration-test allocator only. Former Vec-per-leaf assembly algorithm using the same checked leaf descriptors; not old production-binary allocation instrumentation or a timing benchmark.')
report['browser_replay']=replay['browser_replay']
report['python_timing']=validation['python'];report['browser_timing']=validation['browser']
report['timing_groups']=[]
for shape in [[2,3,7],[2,8,64],[4,8,128]]:
    py=[c for c in validation['python'] if c['shape']==shape]
    web=[c for c in validation['browser'] if c['shape']==shape]
    assert len(py)==len(web)==3
    median=lambda c,r:c['summary'][r]['median_ms_per_forward']
    ratios=lambda values:dict(min=min(values),max=max(values),median=statistics.median(values))
    report['timing_groups'].append(dict(shape=shape,depth=py[0]['depth'],
        python_ms={v:statistics.median(median(c[v],'module_resident_burst') for c in py) for v in ['baseline','candidate']},
        python_candidate_over_baseline=ratios([c['candidate_over_baseline']['module_resident_burst'] for c in py]),
        python_candidate_over_torch=ratios([c['candidate']['module_burst_over_torch_mps'] for c in py]),
        browser_ms={v:statistics.median(median(c,v+'_module_burst') for c in web) for v in ['baseline','candidate']},
        browser_candidate_over_baseline=ratios([c['candidate_over_baseline']['module_burst'] for c in web])))
report['regressions']={
    'python_module_burst':[dict(shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_resident_burst']) for c in validation['python'] if c['candidate_over_baseline']['module_resident_burst']>1],
    'browser_module_burst':[dict(shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_burst']) for c in validation['browser'] if c['candidate_over_baseline']['module_burst']>1],
    'python_slower_than_torch':[dict(shape=c['shape'],seed=c['seed'],ratio=c['candidate']['module_burst_over_torch_mps']) for c in validation['python'] if c['candidate']['module_burst_over_torch_mps']>1],
    'python_module_d2h':[dict(shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_resident_d2h']) for c in validation['python'] if c['candidate_over_baseline']['module_resident_d2h']>1],
    'browser_module_d2h':[dict(shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_d2h']) for c in validation['browser'] if c['candidate_over_baseline']['module_d2h']>1],
    'native_reference_ratio_outside_ten_percent':[dict(shape=c['shape'],seed=c['seed'],route=r,ratio=c['candidate_over_baseline'][r]) for c in validation['python'] for r in ['python_scalar_burst','torch_mps_burst'] if not .9<=c['candidate_over_baseline'][r]<=1.1],
}
replication=read(LOG/'replications/receipt.json')
assert replication['status']=='passed' and len(replication['trials'])==3
assert len(replication['steps'])==12 and all(s['exit_code']==0 for s in replication['steps'])
assert replication['source']==receipt['source'] and replication['baseline_source']==receipt['baseline_source']
assert sha(LOG/'replicate.py')==replication['harness_sha256']
assert replication['orders']==[['candidate','baseline'],['baseline','candidate'],['candidate','baseline']]
series=[dict(label='initial',order=['baseline','candidate'],validation=validation)]
for trial in replication['trials']:
    for name,digest in trial['files'].items():assert sha(LOG/'replications'/name)==digest,name
    value=read(LOG/f"replications/{trial['trial']}-validation.json")
    assert value['status']=='passed'
    series.append(dict(label=str(trial['trial']),order=trial['order'],validation=value))
report['replications']=dict(receipt=replication,series=series,
    boundary='Four complete matrices retained: initial plus three counterbalanced native replications. Twelve seed-run medians per shape/client. No inferential significance or host exclusivity claim.')
report['verification_steps_total']=report['steps']+len(replication['steps'])
report['initial_regressions']=report.pop('regressions')
report['all_trials_regressions']={
    'python_module_burst':[dict(trial=s['label'],shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_resident_burst']) for s in series for c in s['validation']['python'] if c['candidate_over_baseline']['module_resident_burst']>1],
    'browser_module_burst':[dict(trial=s['label'],shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_burst']) for s in series for c in s['validation']['browser'] if c['candidate_over_baseline']['module_burst']>1],
    'python_module_d2h':[dict(trial=s['label'],shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_resident_d2h']) for s in series for c in s['validation']['python'] if c['candidate_over_baseline']['module_resident_d2h']>1],
    'browser_module_d2h':[dict(trial=s['label'],shape=c['shape'],seed=c['seed'],ratio=c['candidate_over_baseline']['module_d2h']) for s in series for c in s['validation']['browser'] if c['candidate_over_baseline']['module_d2h']>1],
    'native_reference_ratio_outside_ten_percent':[dict(trial=s['label'],shape=c['shape'],seed=c['seed'],route=r,ratio=c['candidate_over_baseline'][r]) for s in series for c in s['validation']['python'] for r in ['python_scalar_burst','torch_mps_burst'] if not .9<=c['candidate_over_baseline'][r]<=1.1],
}
report['reference_boundary']='The untargeted explicit graph dispatch schedule and eager Torch remain controls. No ratio normalizes away host/device drift.'
report['all_trials_groups']=[]
spread=lambda values:dict(min=min(values),max=max(values),median=statistics.median(values))
for shape in [[2,3,7],[2,8,64],[4,8,128]]:
    py=[c for s in series for c in s['validation']['python'] if c['shape']==shape]
    web=[c for s in series for c in s['validation']['browser'] if c['shape']==shape]
    assert len(py)==len(web)==12
    median=lambda c,r:c['summary'][r]['median_ms_per_forward']
    report['all_trials_groups'].append(dict(shape=shape,depth=py[0]['depth'],seed_run_pairs=12,
        python_ms={v:statistics.median(median(c[v],'module_resident_burst') for c in py) for v in ['baseline','candidate']},
        python_candidate_over_baseline=spread([c['candidate_over_baseline']['module_resident_burst'] for c in py]),
        python_d2h_candidate_over_baseline=spread([c['candidate_over_baseline']['module_resident_d2h'] for c in py]),
        python_candidate_over_torch=spread([c['candidate']['module_burst_over_torch_mps'] for c in py]),
        python_reference_ratios={r:spread([c['candidate_over_baseline'][r] for c in py]) for r in ['python_scalar_burst','torch_mps_burst']},
        browser_ms={v:statistics.median(median(c,v+'_module_burst') for c in web) for v in ['baseline','candidate']},
        browser_candidate_over_baseline=spread([c['candidate_over_baseline']['module_burst'] for c in web]),
        browser_d2h_candidate_over_baseline=spread([c['candidate_over_baseline']['module_d2h'] for c in web]),
        browser_explicit_graph_ratio=spread([c['candidate_over_baseline']['scalar_burst'] for c in web])))
OUT.mkdir()
paths=sorted(set(LOG.rglob('*.json'))|set(LOG.rglob('*.log'))|{LOG/'run.py',LOG/'replicate.py',LOG/'archive.py'})
manifest=[]
for path in paths:
    relative=path.relative_to(LOG);destination=OUT/'raw'/(str(relative)+'.xz')
    destination.parent.mkdir(parents=True,exist_ok=True)
    raw=path.read_bytes();compressed=lzma.compress(raw,preset=6)
    assert lzma.decompress(compressed)==raw
    destination.write_bytes(compressed)
    manifest.append(dict(path=str(destination.relative_to(OUT)),original=str(relative),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),compressed_bytes=len(compressed),compressed_sha256=sha(destination)))
report['archive']=dict(files=len(manifest),raw_bytes=sum(p['bytes'] for p in manifest),compressed_bytes=sum(p['compressed_bytes'] for p in manifest))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'summary.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
assert {str(p.relative_to(OUT)) for p in (OUT/'raw').rglob('*.xz')}=={p['path'] for p in manifest}
print(json.dumps(dict(output=str(OUT),source=report['source'],steps=report['steps'],archive=report['archive'],all_trials_groups=report['all_trials_groups']),indent=2))


