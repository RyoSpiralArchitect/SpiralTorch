"""Three predeclared paired replications after the complete verification run.

Never substitutes for the first full matrix. No retries or discarded trials.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG=Path(__file__).parent
RUN=LOG/'verified-a'
BASE=Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/parameter-content-stamps-20260912/verified-a')
OUT=LOG/'replications'
P='/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
ORDERS=[['candidate','baseline'],['baseline','candidate'],['candidate','baseline']]
if sys.argv[1:]==['--launch']:
    if OUT.exists():raise ValueError('replications already exist; inspect rather than retry')
    with (LOG/'replications.log').open('xb') as log:
        child=subprocess.Popen([P,'-S',str(Path(__file__).resolve())],cwd=ROOT,stdin=subprocess.DEVNULL,
            stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps(dict(pid=child.pid,log=str(LOG/'replications.log'))));raise SystemExit(0)
if sys.argv[1:]:raise ValueError('--launch or no arguments')
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
initial,baseline=read(RUN/'receipt.json'),read(BASE/'receipt.json')
assert initial['status']==baseline['status']=='passed'
assert initial['source']['commit']==git('rev-parse','HEAD') and not git('status','--porcelain')
for root,receipt in [(RUN,initial),(BASE,baseline)]:
    for name,digest in receipt['products'].items():assert sha(root/name)==digest
OUT.mkdir()
env=dict(os.environ,PYTORCH_ENABLE_MPS_FALLBACK='0',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
report=dict(status='running',pid=os.getpid(),source=initial['source'],baseline_source=baseline['source'],
    orders=ORDERS,steps=[],trials=[],harness_sha256=sha(Path(__file__)),
    initial_receipt_sha256=sha(RUN/'receipt.json'),baseline_receipt_sha256=sha(BASE/'receipt.json'),
    boundary='Three fixed replications; first standalone matrix remains included separately. No retries, filtering, exclusive-GPU claim or automatic tuning.')
def save():
    temp=OUT/'receipt.json.tmp';temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(OUT/'receipt.json')
def run(name,args):
    print('START',name,flush=True);start=time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        child=subprocess.Popen(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
        report['active']=dict(name=name,pid=child.pid,command=args);save()
        try:code=child.wait(timeout=1800)
        except subprocess.TimeoutExpired:child.kill();child.wait();raise
    report.pop('active');report['steps'].append(dict(name=name,exit_code=code,seconds=time.monotonic()-start,command=args));save()
    print('END',name,code,flush=True)
    if code:raise RuntimeError(name)
try:
    save()
    for trial,order in enumerate(ORDERS,1):
        for version in order:
            library=(RUN if version=='candidate' else BASE)/'python-release.dylib'
            run(f'{trial}-{version}',[TORCH,'-I','tools/bench_graph_forward_paths.py','--fixture',str(RUN/'native-forward-bench.json'),
                '--native-library',str(library),'--include-module','--output',str(OUT/f'{trial}-{version}.json')])
        run(f'{trial}-browser',['node','tools/test_resident_browser.cjs',str(RUN/'client'),CHROME,
            str(OUT/f'{trial}-browser.json'),'','','','','nn-module-matched',str(BASE/'client')])
        run(f'{trial}-validation',[P,'-I','tools/validate_module_direct_io.py','--fixture',str(RUN/'native-forward-bench.json'),
            '--baseline-python',str(OUT/f'{trial}-baseline.json'),'--candidate-python',str(OUT/f'{trial}-candidate.json'),
            '--browser',str(OUT/f'{trial}-browser.json'),'--baseline-receipt',str(BASE/'receipt.json'),
            '--candidate-library',str(RUN/'python-release.dylib'),'--candidate-wasm',str(RUN/'client/spiraltorch_wasm_bg.wasm'),
            '--output',str(OUT/f'{trial}-validation.json')])
        assert read(OUT/f'{trial}-validation.json')['status']=='passed'
        report['trials'].append(dict(trial=trial,order=order,
            files={f'{trial}-{label}.json':sha(OUT/f'{trial}-{label}.json') for label in ['baseline','candidate','browser','validation']}));save()
    for root,receipt in [(RUN,initial),(BASE,baseline)]:
        for name,digest in receipt['products'].items():assert sha(root/name)==digest
    assert git('rev-parse','HEAD')==initial['source']['commit'] and not git('status','--porcelain')
    report['status']='passed'
except BaseException as error:
    report.update(status='error',error=repr(error));raise
finally:save()


