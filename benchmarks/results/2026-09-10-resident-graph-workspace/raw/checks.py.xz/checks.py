import json
import os
from pathlib import Path
import subprocess
import sys
import time

w=Path('/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-resident-graph-workspace-v1')
l=Path(__file__).parent
if len(sys.argv)>1:
    l=l/sys.argv[1];l.mkdir()
env=dict(os.environ,CARGO_BUILD_JOBS='4',SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1',
    CARGO_TARGET_DIR='/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-spiralk-golden-blackcat-contract-v1/target')
cargo=['cargo','+1.98.0']
jobs=[
('backend-clippy',cargo+['clippy','--locked','-p','st-backend-wgpu','--no-default-features','--lib','--','-D','warnings']),
('backend-tests',cargo+['test','--locked','-p','st-backend-wgpu','--no-default-features','--lib']),
('nn-tests',cargo+['test','--locked','-p','st-nn','--no-default-features','--features','wgpu','--lib','--test','resident_graph_training','--test','resident_training','--test','resident_nd_tensor']),
('wasm-clippy',cargo+['clippy','--locked','-p','st-backend-wgpu','--no-default-features','--target','wasm32-unknown-unknown','--lib','--','-D','warnings']),
('nn-clippy',cargo+['clippy','--locked','-p','st-nn','--no-default-features','--features','wgpu','--lib','--example','resident_graph_training','--example','resident_training_bench']),
('python-tests',['/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12','-I','-S','-m','unittest','discover','-s','tests','-p','test_resident_training_bench.py','-v']),
]
with (l/'checks.jsonl').open('x') as out:
    for name,args in jobs:
        print('start',name,flush=True);start=time.monotonic()
        with (l/(name+'.log')).open('xb') as log:
            p=subprocess.run(args,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
        row=dict(name=name,command=args,returncode=p.returncode,seconds=time.monotonic()-start)
        out.write(json.dumps(row)+'\n');out.flush();print(json.dumps(row),flush=True)
        if p.returncode:raise SystemExit(p.returncode)
