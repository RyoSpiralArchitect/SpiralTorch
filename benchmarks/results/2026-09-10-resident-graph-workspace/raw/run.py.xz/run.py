import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

w=Path('/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-resident-graph-workspace-v1')
l=Path(__file__).parent
env=dict(os.environ,PYTORCH_ENABLE_MPS_FALLBACK='0',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
python='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
chrome='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
baseline=json.loads((l/'baseline/receipt.json').read_text())
candidate=json.loads((l/'candidate/receipt.json').read_text())
report=dict(status='error',steps=[],source=candidate['source'])
for label,receipt in [('baseline',baseline),('candidate',candidate)]:
    if receipt['status']!='passed':raise RuntimeError('product build failed')
    for name,digest in receipt['products'].items():
        if hashlib.sha256((l/label/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('changed product')
def run(name,args,output=None):
    print('start',name,flush=True);start=time.monotonic()
    with (l/(name+'.log')).open('xb') as log:
        if output:
            with (l/output).open('xb') as out:p=subprocess.run(args,cwd=w,env=env,stdout=out,stderr=log)
        else:p=subprocess.run(args,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
    row=dict(name=name,command=args,returncode=p.returncode,seconds=time.monotonic()-start)
    report['steps'].append(row);print(json.dumps(row),flush=True)
    if p.returncode:raise RuntimeError(name+' failed; no sample retry')
with (l/'run-receipt.json').open('x') as out:
    try:
        for name,label,suite in [('resident_graph_training','graph','nn-graph-training'),('resident_nd_tensor','nd','nd-tensor')]:
            run('native-'+label,[str(l/'candidate'/name)],'native-'+label+'.json')
            run('browser-'+label,['node',str(w/'tools/test_resident_browser.cjs'),str(l/'candidate'/(name+'-wasm')),chrome,str(l/('browser-'+label+'.json')),'','','','',suite])
        run('torch-graph-replay',[python,'-I',str(w/'tools/validate_resident_graph_training_vs_torch.py'),str(l/'native-graph.json'),str(l/'browser-graph.json'),'--devices','cpu','mps','--output',str(l/'torch-graph-replay.json')])
        run('torch-vjp-replay',[python,'-I',str(w/'tools/validate_pointwise_vjp_vs_torch.py'),'--reports',str(l/'native-nd.json'),str(l/'browser-nd.json'),'--devices','cpu','mps','--source',candidate['source'],'--allow-mps-empty-reference-gap','--output',str(l/'torch-vjp-replay.json')])
        run('native-bench',[python,'-I',str(w/'tools/bench_resident_training_vs_torch.py'),'--graph','--baseline',str(l/'baseline/resident_training_bench'),'--baseline-source',baseline['source'],'--candidate',str(l/'candidate/resident_training_bench'),'--candidate-source',candidate['source'],'--device','mps','--output',str(l/'native-bench.json')])
        run('browser-bench',['node',str(w/'tools/bench_resident_training_browser.cjs'),str(l/'baseline/resident_training_bench-wasm'),str(l/'candidate/resident_training_bench-wasm'),chrome,str(l/'browser-bench.json'),'graph'])
        run('validate-bench',[python,'-I',str(w/'tools/validate_resident_training_bench.py'),'--native',str(l/'native-bench.json'),'--browser',str(l/'browser-bench.json'),'--browser-progress',str(l/'browser-bench.json.progress.jsonl'),'--baseline-source',baseline['source'],'--candidate-source',candidate['source'],'--browser-harness-source',candidate['source'],'--output',str(l/'bench-validation.json')])
        for label,receipt in [('baseline',baseline),('candidate',candidate)]:
            for name,digest in receipt['products'].items():
                if hashlib.sha256((l/label/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('changed product')
        report['status']='passed_with_known_mps_empty_reference_gaps'
    except BaseException as error:
        report['error']=repr(error);raise
    finally:
        json.dump(report,out,indent=2);out.write('\n')
