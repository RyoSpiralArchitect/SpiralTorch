import lzma
import hashlib
import json
from pathlib import Path
import statistics

l=Path(__file__).parent
p=Path('/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-resident-graph-workspace-v1/benchmarks/results/2026-09-10-resident-graph-workspace')
p.mkdir(parents=True,exist_ok=True);(p/'raw').mkdir(exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
validation=json.loads((l/'bench-validation.json').read_bytes())
assert validation['status']=='passed' and len(validation['cases'])==9
summary=dict(schema='spiraltorch.graph_workspace_summary.v1',status='passed',ratios={},
    definition='geometric mean of nine per-case median ratios; >1 means candidate is faster; 8 retained blocks after 2 warmups; no significance or universal speed claim',
    max_benchmark_abs_error=max(max(c['max_abs_errors'].values()) for c in validation['cases']))
for client in ('native','browser'):
    summary['ratios'][client]={}
    for cadence in ('immediate','deferred'):
        values=[c[client][cadence]['baseline_over_candidate'] for c in validation['cases']]
        summary['ratios'][client][cadence]=dict(geometric_mean=statistics.geometric_mean(values),
            minimum=min(values),maximum=max(values),faster_cases=sum(v>1 for v in values),cases=len(values))
summary['native_torch_over_candidate']={cadence:statistics.geometric_mean(c['native'][cadence]['torch_over_candidate'] for c in validation['cases']) for cadence in ('immediate','deferred')}
(p/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
manifest=dict(schema='spiraltorch.graph_workspace_evidence.v1',baseline=json.loads((l/'baseline/receipt.json').read_bytes()),
    candidate=json.loads((l/'candidate/receipt.json').read_bytes()),files=[],
    scope='Raw local evidence, including the initial Clippy failure; no binaries, credentials, browser physical-device attestation, or CUDA result')
for f in sorted(l.rglob('*')):
    if not f.is_file() or f.suffix not in ('.json','.jsonl','.log','.stderr','.py','.diff') or '-wasm/' in str(f):continue
    name=f.relative_to(l).as_posix();raw=f.read_bytes();compressed=lzma.compress(raw,preset=6)
    assert lzma.decompress(compressed)==raw
    dest=p/'raw'/('/'.join(name.split('/')).replace('/','__')+'.xz')
    assert not dest.exists();dest.write_bytes(compressed)
    manifest['files'].append(dict(path=dest.relative_to(p).as_posix(),source=name,raw_sha256=sha(raw),
        xz_sha256=sha(compressed),raw_bytes=len(raw),xz_bytes=len(compressed)))
old=json.loads((p/'manifest.json').read_text()) if (p/'manifest.json').exists() else None
if old:
    for entry in old['files']:
        if entry['path'].endswith('.gz'):
            f=p/entry['path'];assert sha(f.read_bytes())==entry['gzip_sha256'];f.unlink()
(p/'manifest.json').write_text(json.dumps(manifest,indent=2,allow_nan=False)+'\n')
files=sorted(f for f in p.rglob('*') if f.is_file() and f.name not in ('README.md','SHA256SUMS'))
(p/'SHA256SUMS').write_text(''.join(sha(f.read_bytes())+'  '+f.relative_to(p).as_posix()+'\n' for f in files))
print(json.dumps(dict(files=len(files),raw_archives=len(manifest['files']),bytes=sum(f.stat().st_size for f in files),summary=summary)))
