import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

work=Path(sys.argv[1]);out=Path(__file__).parent/sys.argv[2];out.mkdir()
target=Path('/Users/ryospiralarchitect/🌀SpiralReality🌀/_wt/spiraltorch-spiralk-golden-blackcat-contract-v1/target')
env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_TARGET_DIR=str(target))
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=work,text=True).strip()
if subprocess.check_output(['git','status','--porcelain'],cwd=work):raise RuntimeError('source must be clean')
report=dict(status='error',source=source,tree=tree,steps=[],products={})
def run(label,args):
    print('start',label,flush=True);start=time.monotonic()
    with (out/(label+'.log')).open('xb') as log:
        result=subprocess.run(args,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
    row=dict(label=label,command=args,returncode=result.returncode,seconds=time.monotonic()-start)
    report['steps'].append(row);print(json.dumps(row),flush=True)
    if result.returncode:raise RuntimeError(label+' failed')
def register(path,executable=False):
    path.chmod(0o555 if executable else 0o444)
    report['products'][str(path.relative_to(out))]=hashlib.sha256(path.read_bytes()).hexdigest()
with (out/'receipt.json').open('x') as receipt:
    try:
        examples=['resident_training_bench']
        if len(sys.argv)>3:examples+=['resident_graph_training','resident_nd_tensor']
        flags=['--locked','--release','-p','st-nn','--no-default-features','--features','wgpu']
        run('native-build',['cargo','+1.98.0','build',*flags,*sum((['--example',n] for n in examples),[])])
        for name in examples:
            product=out/name;shutil.copyfile(target/'release/examples'/name,product);register(product,True)
        identity=json.loads(subprocess.check_output([str(out/'resident_training_bench'),'--build-info'],text=True))
        if identity['manifest']['git']!=dict(commit=source,tree=tree,dirty=False):
            git=identity['manifest']['git']
            if any(git[k]!=v for k,v in dict(commit=source,tree=tree,dirty=False).items()):raise RuntimeError('source binding mismatch')
        report['identity']=identity
        run('wasm-build',['cargo','+1.98.0','build',*flags,'--target','wasm32-unknown-unknown',*sum((['--example',n+'_browser'] for n in examples),[])])
        for name in examples:
            module=out/(name+'-wasm')
            run(name+'-bindgen',['/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen','--target','web','--out-dir',str(module),'--out-name','spiraltorch_wasm',str(target/'wasm32-unknown-unknown/release/examples'/(name+'_browser.wasm'))])
            for product in module.rglob('*'):
                if product.is_file():register(product)
        if subprocess.check_output(['git','status','--porcelain'],cwd=work):raise RuntimeError('source changed')
        report['status']='passed'
    except BaseException as error:
        report['error']=repr(error);raise
    finally:
        json.dump(report,receipt,indent=2);receipt.write('\n')
