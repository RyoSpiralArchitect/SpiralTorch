// SPDX-License-Identifier: AGPL-3.0-or-later
// © 2025 Ryo ∴ SpiralArchitect (kishkavsesvit@icloud.com)
// Part of SpiralTorch — Licensed under AGPL-3.0-or-later.
// Unauthorized derivative works or closed redistribution prohibited under AGPL §13.

// ============================================================================
//  SpiralReality Proprietary
//  Copyright (c) 2025 SpiralReality. All Rights Reserved.
//
//  NOTICE: This file contains confidential and proprietary information of
//  SpiralReality. ANY USE, COPYING, MODIFICATION, DISTRIBUTION, DISPLAY,
//  OR DISCLOSURE OF THIS FILE, IN WHOLE OR IN PART, IS STRICTLY PROHIBITED
//  WITHOUT THE PRIOR WRITTEN CONSENT OF SPIRALREALITY.
//
//  NO LICENSE IS GRANTED OR IMPLIED BY THIS FILE. THIS SOFTWARE IS PROVIDED
//  "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
//  NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
//  PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL SPIRALREALITY OR ITS
//  SUPPLIERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
//  AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
//  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
// ============================================================================

#[cfg(feature = "selfsup")]
pub mod selfsup;

use crate::cloud::CloudTargetSummary;
use crate::dataset::DataLoader;
use crate::execution::{
    push_backend_policy, BackendPolicy, RuntimeExecutionContext, RuntimeExecutionPlanError,
    RuntimeExecutionPlanPayload,
};
use crate::gnn::spiralk::{GraphConsensusBridge, GraphConsensusDigest};
use crate::gnn::RoundtableBandSignal;
#[cfg(feature = "golden")]
use crate::golden::{GoldenBlackcatPulse, GoldenCooperativeDirective, GoldenCouncilSnapshot};
use crate::language::{
    checkpoint_desire_bridges, commit_desire_checkpoint_restore, DesireRoundtableBridge,
    DesireRoundtableSummary, DesireTelemetryBundle, DesireTrainerBridge, DesireTrainerSummary,
    PreparedDesireRoundtableCheckpoint, PreparedDesireTrainerQueue,
};
#[cfg(feature = "psi")]
use crate::language::{DesirePsiBridge, DesirePsiSummary};
use crate::loss::Loss;
use crate::module::{Module, PreparedParameterOptimizerState};
use crate::optim::{
    emit_parameter_control_receipt, parameter_control_error, plan_zspace_parameter_control,
    scale_module_learning_rates, LocalLearningRateAdapter, SpectralLrAdapter,
    SpectralLrAdapterState, ZSpaceParameterControlReceipt,
};
use crate::plan::RankPlanner;
use crate::roundtable::{
    simulate_proposal_locally, BlackcatModerator, BlackcatScore, DistConfig, GlobalProposal,
    HeurOpKind, HeurOpLog, MetaConductor, ModeratorMinutes, OutcomeBand, RoundtableGnnBridge,
    RoundtableGnnBridgeState, RoundtableNode,
};
use crate::schedule::{BandEnergy, GradientBands, RoundtableConfig, RoundtableSchedule};
use crate::zspace_coherence::{
    CoherenceDiagnostics, CoherenceLabel, CoherenceObservation, ZSpaceTraceEvent,
};
use crate::{PureResult, Tensor, TensorError};
use rand::rngs::StdRng;
use rand::{seq::SliceRandom, SeedableRng};
use serde_json::Value;
use st_core::backend::device_caps::{BackendKind, DeviceCaps};
use st_core::backend::execution_plan::{AcceleratorFallback, ExecutionConfig};
use st_core::backend::unison_heuristics::RankKind;
use st_core::distributed::{AccumulatorSyncError, AccumulatorSynchronizer};
use st_core::ecosystem::{
    CloudConnector, ConnectorEvent, DistributionSummary, EcosystemRegistry, MetricSample,
    RankPlanSummary, RoundtableConfigSummary, RoundtableSummary,
};
#[cfg(feature = "collapse")]
use st_core::engine::collapse_drive::{CollapseConfig, CollapseDrive, DriveCmd};
use st_core::heur::free_energy::FreeEnergyReport;
use st_core::inference::zspace_coherence::{
    project_zspace_coherence, validate_zspace_coherence_distribution_witness,
    ZSpaceCoherenceClassificationPayload, ZSpaceCoherenceClassificationPolicy,
    ZSpaceCoherenceControlPayload, ZSpaceCoherenceDiagnosticsInput,
    ZSpaceCoherenceDistributionWitness, ZSpaceCoherenceProjectionConfig,
    ZSpaceCoherenceProjectionRequest, ZSPACE_COHERENCE_CLASSIFICATION_CONTRACT_VERSION,
    ZSPACE_COHERENCE_CLASSIFICATION_FORMULA, ZSPACE_COHERENCE_CLASSIFICATION_KIND,
    ZSPACE_COHERENCE_CONTROL_CONTRACT_VERSION, ZSPACE_COHERENCE_CONTROL_FORMULA,
    ZSPACE_COHERENCE_CONTROL_KIND, ZSPACE_COHERENCE_PROJECTION_SEMANTIC_BACKEND,
    ZSPACE_COHERENCE_PROJECTION_SEMANTIC_OWNER,
};
use st_core::ops::rank_entry::RankPlan;
use st_core::plugin::{global_registry, PluginEvent};
use st_core::runtime::autopilot::Autopilot;
use st_core::runtime::blackcat::{
    BlackCatRuntime, BlackcatRuntimeStats, SoftHeuristicAdoptionReport, StepMetrics,
};
use st_core::runtime::trainer_checkpoint::{
    build_trainer_runtime_checkpoint_bundle, evaluate_trainer_runtime_checkpoint_bundle,
    evaluate_trainer_runtime_checkpoint_restore, TrainerRuntimeCheckpointBundle,
    TrainerRuntimeCheckpointError, TrainerRuntimeCheckpointValidation,
};
#[cfg(feature = "psi")]
use st_core::runtime::trainer_external::PSI_METER_COMPONENT;
use st_core::runtime::trainer_external::{
    build_trainer_external_state_checkpoint_from_components,
    evaluate_trainer_external_state_checkpoint, evaluate_trainer_external_state_restore,
    TrainerCoherenceBridgeCheckpoint, TrainerCoherenceSignalCheckpoint,
    TrainerExternalCheckpointComponents, TrainerExternalCheckpointError,
    TrainerExternalCheckpointValidation, TrainerExternalStateCheckpoint,
    TrainerGnnRoundtableBridgeCheckpoint, TrainerGnnRoundtableSignalCheckpoint,
    ACCUMULATOR_SYNCHRONIZER_COMPONENT, COHERENCE_BRIDGE_COMPONENT, DESIRE_TRAINER_COMPONENT,
    GNN_ROUNDTABLE_BRIDGE_COMPONENT,
};
use st_core::runtime::trainer_optimizer::{
    build_trainer_optimizer_checkpoint, evaluate_trainer_optimizer_checkpoint,
    evaluate_trainer_optimizer_config, TrainerBackendCounters, TrainerCurvatureSchedulerState,
    TrainerExecutionTopology, TrainerOptimizerCheckpoint, TrainerOptimizerCheckpointError,
    TrainerOptimizerCheckpointValidation, TrainerOptimizerConfig, TrainerOptimizerConfigContract,
    TrainerOptimizerConfigError, TrainerOptimizerRuntimeState, TrainerPhaseTrackerState,
    TrainerSoftLogicConfigState, TrainerSoftLogicFeedbackState, TrainerSoftLogicState,
    TrainerSpectralPolicyState, TRAINER_CURVATURE_PRESSURE_MAX,
};
use st_core::runtime::zspace_optimizer::{
    zspace_parameter_control_from_report, ZSpaceMetaOptimizerStepReport, ZSpaceParameterControl,
};
#[cfg(feature = "collapse")]
use st_core::telemetry::hub::CollapsePulse;
use st_core::telemetry::hub::{self, LoopbackEnvelope, SoftlogicZFeedback};
#[cfg(feature = "psi")]
use st_core::telemetry::psi::{PsiComponent, PsiConfig, PsiInput, PsiMeter, PsiReading};
#[cfg(feature = "psychoid")]
use st_core::telemetry::psychoid::{PsychoidConfig, PsychoidEvent, PsychoidMeter, PsychoidReading};
use st_core::telemetry::region_visualizer::{
    RegionHeatmapCell, RegionHeatmapHistory, RegionHeatmapSnapshot,
};
use st_core::telemetry::xai_report::AttributionReport;
use st_core::telemetry::zspace_region::{
    ZSpaceRadiusBand, ZSpaceRegionDescriptor, ZSpaceRegionKey, ZSpaceSpinBand,
};
use st_core::theory::zpulse::ZScale;
use st_tensor::{
    set_thread_meta_observer, topos::OpenCartesianTopos, GradientSummary, TensorExecutionReceipt,
    TensorExecutionRouteStatus, TensorOpMetaEvent, TensorOpMetaObserver,
};
use std::collections::HashMap;
use std::env;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant, SystemTime};
use thiserror::Error;

#[cfg(all(test, feature = "selfsup"))]
fn tensor_meta_observer_test_lock() -> std::sync::MutexGuard<'static, ()> {
    crate::test_global_state_lock()
}

/// Adaptive curvature controller that nudges the trainer's hyperbolic geometry
/// towards the pressure window observed in recent gradients.
#[derive(Debug, Clone)]
pub struct CurvatureScheduler {
    min_curvature: f32,
    max_curvature: f32,
    target_pressure: f32,
    tolerance: f32,
    step: f32,
    kp: f32,
    alpha: f32,
    current: f32,
    ema_pressure: Option<f32>,
    ema_pressure2: Option<f32>,
    stability_threshold: f32,
    stability_boost: f32,
    stable_steps: u32,
    dither_strength: f32,
    dither_period: u32,
    dither_sign: f32,
}

impl CurvatureScheduler {
    /// Builds a scheduler anchored to the provided curvature range and target
    /// gradient pressure. `initial` is clamped into `[min_curvature,
    /// max_curvature]` and the range itself is normalised so both bounds remain
    /// negative.
    pub fn new(initial: f32, min_curvature: f32, max_curvature: f32, target_pressure: f32) -> Self {
        let mut min_curvature = min_curvature.min(-1e-6);
        let mut max_curvature = max_curvature.min(-1e-6);
        if min_curvature > max_curvature {
            core::mem::swap(&mut min_curvature, &mut max_curvature);
        }
        let current = initial.clamp(min_curvature, max_curvature).min(-1e-6);
        Self {
            min_curvature,
            max_curvature,
            target_pressure: if target_pressure.is_finite() {
                target_pressure.clamp(0.0, TRAINER_CURVATURE_PRESSURE_MAX)
            } else {
                0.0
            },
            tolerance: 0.05,
            step: 0.05,
            kp: 1.0,
            alpha: 0.2,
            current,
            ema_pressure: None,
            ema_pressure2: None,
            stability_threshold: 1.0e-3,
            stability_boost: 0.5,
            stable_steps: 0,
            dither_strength: 0.15,
            dither_period: 8,
            dither_sign: 1.0,
        }
    }

    /// Adjusts the maximum step a single observation may move the curvature by.
    pub fn with_step(mut self, step: f32) -> Self {
        if step.is_finite() && step > 0.0 {
            self.step = step;
        }
        self
    }

    /// Adjusts the proportional gain used to convert pressure error into curvature delta.
    pub fn with_proportional_gain(mut self, gain: f32) -> Self {
        self.set_proportional_gain(gain);
        self
    }

    /// Adjusts the tolerated pressure band before the curvature is nudged.
    pub fn with_tolerance(mut self, tolerance: f32) -> Self {
        if tolerance.is_finite() && tolerance >= 0.0 {
            self.tolerance = tolerance;
        }
        self
    }

    /// Adjusts the stability threshold used to detect "settled" pressure conditions.
    pub fn with_stability_threshold(mut self, threshold: f32) -> Self {
        self.set_stability_threshold(threshold);
        self
    }

    /// Adjusts the stability boost applied to the proportional gain when pressure settles.
    pub fn with_stability_boost(mut self, boost: f32) -> Self {
        self.set_stability_boost(boost);
        self
    }

    /// Enables a small curvature dither when pressure remains stable within tolerance.
    pub fn with_dither(mut self, strength: f32, period: u32) -> Self {
        self.set_dither(strength, period);
        self
    }

    /// Applies environment overrides to the scheduler in-place.
    ///
    /// Supported variables:
    /// - `SPIRAL_CURVATURE_STEP`
    /// - `SPIRAL_CURVATURE_TOLERANCE`
    /// - `SPIRAL_CURVATURE_ALPHA`
    /// - `SPIRAL_CURVATURE_KP`
    /// - `SPIRAL_CURVATURE_STABILITY_THRESHOLD`
    /// - `SPIRAL_CURVATURE_STABILITY_BOOST`
    /// - `SPIRAL_CURVATURE_DITHER_STRENGTH`
    /// - `SPIRAL_CURVATURE_DITHER_PERIOD`
    pub fn apply_env_overrides(&mut self) {
        if let Ok(value) = env::var("SPIRAL_CURVATURE_STEP") {
            if let Ok(step) = value.parse::<f32>() {
                self.set_step(step);
            }
        }
        if let Ok(value) = env::var("SPIRAL_CURVATURE_TOLERANCE") {
            if let Ok(tolerance) = value.parse::<f32>() {
                self.set_tolerance(tolerance);
            }
        }
        if let Ok(value) = env::var("SPIRAL_CURVATURE_ALPHA") {
            if let Ok(alpha) = value.parse::<f32>() {
                self.set_smoothing(alpha);
            }
        }
        if let Ok(value) = env::var("SPIRAL_CURVATURE_KP") {
            if let Ok(kp) = value.parse::<f32>() {
                self.set_proportional_gain(kp);
            }
        }
        if let Ok(value) = env::var("SPIRAL_CURVATURE_STABILITY_THRESHOLD") {
            if let Ok(threshold) = value.parse::<f32>() {
                self.set_stability_threshold(threshold);
            }
        }
        if let Ok(value) = env::var("SPIRAL_CURVATURE_STABILITY_BOOST") {
            if let Ok(boost) = value.parse::<f32>() {
                self.set_stability_boost(boost);
            }
        }

        let mut dither_strength = self.dither_strength;
        let mut dither_period = self.dither_period;
        let mut changed = false;
        if let Ok(value) = env::var("SPIRAL_CURVATURE_DITHER_STRENGTH") {
            if let Ok(strength) = value.parse::<f32>() {
                dither_strength = strength;
                changed = true;
            }
        }
        if let Ok(value) = env::var("SPIRAL_CURVATURE_DITHER_PERIOD") {
            if let Ok(period) = value.parse::<u32>() {
                dither_period = period;
                changed = true;
            }
        }
        if changed {
            self.set_dither(dither_strength, dither_period);
        }
    }

    /// Applies environment overrides and returns `self` for fluent construction.
    pub fn with_env_overrides(mut self) -> Self {
        self.apply_env_overrides();
        self
    }

    /// Adjusts the smoothing factor applied to the pressure EMA.
    pub fn with_smoothing(mut self, alpha: f32) -> Self {
        if alpha.is_finite() && alpha > 0.0 {
            self.alpha = alpha.clamp(0.01, 1.0);
        }
        self
    }

    /// Returns the proportional gain used to compute curvature deltas.
    pub fn proportional_gain(&self) -> f32 {
        self.kp
    }

    /// Returns the curvature currently enforced by the scheduler.
    pub fn current(&self) -> f32 {
        self.current
    }

    /// Returns the minimum curvature allowed by the scheduler.
    pub fn min_curvature(&self) -> f32 {
        self.min_curvature
    }

    /// Returns the maximum curvature allowed by the scheduler.
    pub fn max_curvature(&self) -> f32 {
        self.max_curvature
    }

    /// Returns the configured target pressure.
    pub fn target_pressure(&self) -> f32 {
        self.target_pressure
    }

    /// Returns the maximum curvature delta applied per observation.
    pub fn step_size(&self) -> f32 {
        self.step
    }

    /// Returns the stability threshold applied to pressure variance estimates.
    pub fn stability_threshold(&self) -> f32 {
        self.stability_threshold
    }

    /// Returns the stability boost applied to the proportional gain.
    pub fn stability_boost(&self) -> f32 {
        self.stability_boost
    }

    /// Returns the dither strength expressed as a fraction of the step size.
    pub fn dither_strength(&self) -> f32 {
        self.dither_strength
    }

    /// Returns the minimum stable observation count before applying dither.
    pub fn dither_period(&self) -> u32 {
        self.dither_period
    }

    /// Returns the tolerated pressure band before adjustments.
    pub fn tolerance(&self) -> f32 {
        self.tolerance
    }

    /// Returns the smoothing factor applied to the pressure EMA.
    pub fn smoothing(&self) -> f32 {
        self.alpha
    }

    /// Returns the last smoothed pressure observation, if available.
    pub fn last_pressure(&self) -> Option<f32> {
        self.ema_pressure
    }

    /// Returns the estimated pressure variance (EMA(p²) - EMA(p)²), if available.
    pub fn last_pressure_variance(&self) -> Option<f32> {
        let mean = self.ema_pressure?;
        let second = self.ema_pressure2?;
        if !mean.is_finite() || !second.is_finite() {
            return None;
        }
        let variance = (f64::from(second) - f64::from(mean) * f64::from(mean)).max(0.0);
        Some(variance.min(f64::from(f32::MAX)) as f32)
    }

    /// Returns the estimated relative variance (var / (mean² + eps)), if available.
    pub fn last_pressure_rel_variance(&self) -> Option<f32> {
        let mean = self.ema_pressure?;
        let var = self.last_pressure_variance()?;
        if !mean.is_finite() || !var.is_finite() {
            return None;
        }
        let denom = f64::from(mean) * f64::from(mean) + 1.0e-6;
        let rel = f64::from(var) / denom;
        if rel.is_finite() {
            Some(rel.min(f64::from(f32::MAX)) as f32)
        } else {
            None
        }
    }

    /// Captures configuration and pressure history for deterministic resume.
    pub fn state(&self) -> TrainerCurvatureSchedulerState {
        TrainerCurvatureSchedulerState {
            min_curvature: self.min_curvature,
            max_curvature: self.max_curvature,
            target_pressure: self.target_pressure,
            tolerance: self.tolerance,
            step: self.step,
            proportional_gain: self.kp,
            smoothing: self.alpha,
            current: self.current,
            ema_pressure: self.ema_pressure,
            ema_pressure2: self.ema_pressure2,
            stability_threshold: self.stability_threshold,
            stability_boost: self.stability_boost,
            stable_steps: self.stable_steps,
            dither_strength: self.dither_strength,
            dither_period: self.dither_period,
            dither_sign: self.dither_sign,
        }
    }

    /// Reconstructs a scheduler only after the Rust checkpoint validator accepts it.
    pub fn from_state(
        state: TrainerCurvatureSchedulerState,
    ) -> Result<Self, TrainerOptimizerCheckpointError> {
        state.validate()?;
        Ok(Self {
            min_curvature: state.min_curvature,
            max_curvature: state.max_curvature,
            target_pressure: state.target_pressure,
            tolerance: state.tolerance,
            step: state.step,
            kp: state.proportional_gain,
            alpha: state.smoothing,
            current: state.current,
            ema_pressure: state.ema_pressure,
            ema_pressure2: state.ema_pressure2,
            stability_threshold: state.stability_threshold,
            stability_boost: state.stability_boost,
            stable_steps: state.stable_steps,
            dither_strength: state.dither_strength,
            dither_period: state.dither_period,
            dither_sign: state.dither_sign,
        })
    }

    /// Synchronises the scheduler with an externally adjusted curvature and
    /// clears the pressure history so subsequent observations start fresh.
    pub fn sync(&mut self, curvature: f32) {
        self.current = curvature
            .clamp(self.min_curvature, self.max_curvature)
            .min(-1e-6);
        self.ema_pressure = None;
        self.ema_pressure2 = None;
        self.stable_steps = 0;
        self.dither_sign = 1.0;
    }

    /// Adjusts the curvature bounds while keeping the current value within range.
    pub fn set_bounds(&mut self, min_curvature: f32, max_curvature: f32) {
        let mut min_curvature = min_curvature.min(-1e-6);
        let mut max_curvature = max_curvature.min(-1e-6);
        if min_curvature > max_curvature {
            core::mem::swap(&mut min_curvature, &mut max_curvature);
        }
        self.min_curvature = min_curvature;
        self.max_curvature = max_curvature;
        self.current = self
            .current
            .clamp(self.min_curvature, self.max_curvature)
            .min(-1e-6);
    }

    /// Adjusts the target pressure for future observations.
    pub fn set_target_pressure(&mut self, target_pressure: f32) {
        if target_pressure.is_finite() {
            self.target_pressure = target_pressure.clamp(0.0, TRAINER_CURVATURE_PRESSURE_MAX);
        }
    }

    /// Adjusts the maximum step a single observation may move the curvature by.
    pub fn set_step(&mut self, step: f32) {
        if step.is_finite() && step > 0.0 {
            self.step = step;
        }
    }

    /// Adjusts the proportional gain used to convert pressure error into curvature delta.
    pub fn set_proportional_gain(&mut self, gain: f32) {
        if gain.is_finite() && gain >= 0.0 {
            self.kp = gain;
        }
    }

    /// Adjusts the tolerated pressure band before the curvature is nudged.
    pub fn set_tolerance(&mut self, tolerance: f32) {
        if tolerance.is_finite() && tolerance >= 0.0 {
            self.tolerance = tolerance;
        }
    }

    /// Adjusts the stability threshold used to detect low-variance pressure.
    pub fn set_stability_threshold(&mut self, threshold: f32) {
        if threshold.is_finite() && threshold > 0.0 {
            self.stability_threshold = threshold;
        }
    }

    /// Adjusts the stability boost applied to the proportional gain.
    pub fn set_stability_boost(&mut self, boost: f32) {
        if boost.is_finite() && boost >= 0.0 {
            self.stability_boost = boost;
        }
    }

    /// Enables a small curvature dither when pressure remains stable within tolerance.
    pub fn set_dither(&mut self, strength: f32, period: u32) {
        if strength.is_finite() && strength >= 0.0 {
            self.dither_strength = strength.clamp(0.0, 1.0);
        }
        if period > 0 {
            self.dither_period = period.max(1);
        }
    }

    /// Adjusts the smoothing factor applied to the pressure EMA.
    pub fn set_smoothing(&mut self, alpha: f32) {
        if alpha.is_finite() && alpha > 0.0 {
            self.alpha = alpha.clamp(0.01, 1.0);
        }
    }

    /// Records a gradient summary returning the raw/smoothed pressure alongside
    /// the curvature chosen for the next step.
    pub fn observe(&mut self, summary: GradientSummary) -> CurvatureDecision {
        let raw_pressure = summary.mean_abs();
        self.observe_pressure(raw_pressure)
    }

    /// Records a raw pressure observation without requiring a full gradient summary.
    pub fn observe_pressure(&mut self, raw_pressure: f32) -> CurvatureDecision {
        let raw_pressure = if raw_pressure.is_finite() {
            raw_pressure.clamp(0.0, TRAINER_CURVATURE_PRESSURE_MAX)
        } else {
            0.0
        };
        let alpha = if self.alpha.is_finite() && self.alpha > 0.0 {
            self.alpha.clamp(0.01, 1.0)
        } else {
            1.0
        };
        let smoothed = match self.ema_pressure.filter(|value| value.is_finite()) {
            Some(prev) => prev + alpha * (raw_pressure - prev),
            None => raw_pressure,
        }
        .clamp(0.0, TRAINER_CURVATURE_PRESSURE_MAX);
        self.ema_pressure = Some(smoothed);
        let raw_sq =
            (f64::from(raw_pressure) * f64::from(raw_pressure)).min(f64::from(f32::MAX)) as f32;
        let smoothed_sq = match self.ema_pressure2.filter(|value| value.is_finite()) {
            Some(prev) => prev + alpha * (raw_sq - prev),
            None => raw_sq,
        }
        .clamp(0.0, f32::MAX);
        self.ema_pressure2 = Some(smoothed_sq);
        let variance =
            (f64::from(smoothed_sq) - f64::from(smoothed) * f64::from(smoothed)).max(0.0);
        let variance = variance.min(f64::from(f32::MAX)) as f32;
        let denom = f64::from(smoothed) * f64::from(smoothed) + 1.0e-6;
        let rel_var = (f64::from(variance) / denom).min(f64::from(f32::MAX)) as f32;
        let error = smoothed - self.target_pressure;
        let within_band = error.abs() <= self.tolerance;

        let mut curvature = self.current;
        let mut changed = false;
        let stable = within_band && rel_var.is_finite() && rel_var <= self.stability_threshold;
        if stable {
            self.stable_steps = self.stable_steps.saturating_add(1);
        } else {
            self.stable_steps = 0;
        }

        let mut delta = 0.0f32;
        if !within_band {
            let stability = if rel_var.is_finite() && self.stability_threshold > 0.0 {
                (1.0 - (rel_var / self.stability_threshold).clamp(0.0, 1.0)).max(0.0)
            } else {
                0.0
            };
            let kp = self.kp * (1.0 + self.stability_boost * stability);
            delta = (kp * error).clamp(-self.step, self.step);
        } else if stable
            && self.dither_strength > 0.0
            && self.dither_period > 0
            && self.stable_steps >= self.dither_period
        {
            delta = self.dither_sign * self.dither_strength * self.step;
            self.dither_sign = -self.dither_sign;
            self.stable_steps = 0;
        }

        if delta.abs() > f32::EPSILON {
            let next = (self.current + delta)
                .clamp(self.min_curvature, self.max_curvature)
                .min(-1e-6);
            if (next - self.current).abs() > f32::EPSILON {
                curvature = next;
                changed = true;
                self.current = curvature;
            }
        }

        CurvatureDecision {
            raw_pressure,
            smoothed_pressure: smoothed,
            curvature,
            changed,
        }
    }
}

/// Decision emitted by [`CurvatureScheduler::observe`].
#[derive(Debug, Clone, Copy)]
pub struct CurvatureDecision {
    pub raw_pressure: f32,
    pub smoothed_pressure: f32,
    pub curvature: f32,
    pub changed: bool,
}

/// Last curvature update captured by the trainer.
#[derive(Debug, Clone, Copy, Default)]
pub struct CurvatureMetrics {
    pub raw_pressure: f32,
    pub smoothed_pressure: f32,
    pub curvature: f32,
}

impl From<CurvatureDecision> for CurvatureMetrics {
    fn from(decision: CurvatureDecision) -> Self {
        Self {
            raw_pressure: decision.raw_pressure,
            smoothed_pressure: decision.smoothed_pressure,
            curvature: decision.curvature,
        }
    }
}

/// Coherence statistics required by [`SpectralLearningRatePolicy`].
#[derive(Debug, Clone)]
pub struct CoherenceSignal {
    dominant_channel: Option<usize>,
    preserved_channels: usize,
    z_bias: f32,
    distribution_witness: ZSpaceCoherenceDistributionWitness,
    control: ZSpaceCoherenceControlPayload,
    classification: ZSpaceCoherenceClassificationPayload,
    repaired_non_finite_weights: usize,
    repaired_negative_weights: usize,
    pre_discard_repaired_non_finite: usize,
    pre_discard_repaired_negative: usize,
}

impl CoherenceSignal {
    pub fn dominant_channel(&self) -> Option<usize> {
        self.dominant_channel
    }

    pub fn preserved_channels(&self) -> usize {
        self.preserved_channels
    }

    pub fn mean_coherence(&self) -> f32 {
        self.control.raw_mean_coherence as f32
    }

    pub fn z_bias(&self) -> f32 {
        self.z_bias
    }

    pub fn energy_ratio(&self) -> f32 {
        self.control.energy_ratio as f32
    }

    pub fn coherence_entropy(&self) -> f32 {
        self.control.raw_coherence_entropy as f32
    }

    pub fn normalized_entropy(&self) -> f32 {
        self.control.spectral_entropy as f32
    }

    pub fn concentration(&self) -> f32 {
        self.control.spectral_radius as f32
    }

    pub fn spectral_pressure(&self) -> f32 {
        self.control.spectral_pressure as f32
    }

    pub fn effective_channels(&self) -> f32 {
        self.control.effective_channels as f32
    }

    pub fn distribution_channels(&self) -> usize {
        self.control.channels
    }

    pub fn label(&self) -> CoherenceLabel {
        self.classification.label
    }

    pub fn control(&self) -> &ZSpaceCoherenceControlPayload {
        &self.control
    }

    pub fn classification(&self) -> &ZSpaceCoherenceClassificationPayload {
        &self.classification
    }

    pub fn repaired_non_finite_weights(&self) -> usize {
        self.repaired_non_finite_weights
    }

    pub fn repaired_negative_weights(&self) -> usize {
        self.repaired_negative_weights
    }

    pub fn repaired_weights_total(&self) -> usize {
        self.repaired_non_finite_weights
            .saturating_add(self.repaired_negative_weights)
    }

    pub fn pre_discard_repaired_non_finite(&self) -> usize {
        self.pre_discard_repaired_non_finite
    }

    pub fn pre_discard_repaired_negative(&self) -> usize {
        self.pre_discard_repaired_negative
    }

    pub fn pre_discard_repairs_total(&self) -> usize {
        self.pre_discard_repaired_non_finite
            .saturating_add(self.pre_discard_repaired_negative)
    }

    pub fn repairs_total(&self) -> usize {
        self.repaired_weights_total()
            .saturating_add(self.pre_discard_repairs_total())
    }

    fn checkpoint(
        &self,
    ) -> Result<TrainerCoherenceSignalCheckpoint, TrainerExternalCheckpointError> {
        let portable_counter = |field: &'static str, value: usize| {
            u64::try_from(value).map_err(|_| TrainerExternalCheckpointError::InvalidState {
                field: format!("coherence_bridge.signal.{field}"),
                message: "does not fit the portable checkpoint domain".to_owned(),
            })
        };
        let checkpoint = TrainerCoherenceSignalCheckpoint {
            dominant_channel: self
                .dominant_channel
                .map(|value| portable_counter("dominant_channel", value))
                .transpose()?,
            preserved_channels: portable_counter("preserved_channels", self.preserved_channels)?,
            z_bias: self.z_bias,
            distribution_witness: self.distribution_witness.clone(),
            energy_ratio: self.control.energy_ratio,
            raw_mean_coherence: self.control.raw_mean_coherence,
            classification_policy: self.classification.policy,
            repaired_non_finite_weights: portable_counter(
                "repaired_non_finite_weights",
                self.repaired_non_finite_weights,
            )?,
            repaired_negative_weights: portable_counter(
                "repaired_negative_weights",
                self.repaired_negative_weights,
            )?,
            pre_discard_repaired_non_finite: portable_counter(
                "pre_discard_repaired_non_finite",
                self.pre_discard_repaired_non_finite,
            )?,
            pre_discard_repaired_negative: portable_counter(
                "pre_discard_repaired_negative",
                self.pre_discard_repaired_negative,
            )?,
        };
        checkpoint.validate()?;
        Ok(checkpoint)
    }

    fn from_checkpoint(
        checkpoint: &TrainerCoherenceSignalCheckpoint,
    ) -> Result<Self, TrainerExternalCheckpointError> {
        let projection = checkpoint.canonical_projection()?;
        let native_counter = |field: &'static str, value: u64| {
            usize::try_from(value).map_err(|_| TrainerExternalCheckpointError::InvalidState {
                field: format!("coherence_bridge.signal.{field}"),
                message: "does not fit this platform".to_owned(),
            })
        };
        Ok(Self {
            dominant_channel: checkpoint
                .dominant_channel
                .map(|value| native_counter("dominant_channel", value))
                .transpose()?,
            preserved_channels: native_counter(
                "preserved_channels",
                checkpoint.preserved_channels,
            )?,
            z_bias: checkpoint.z_bias,
            distribution_witness: checkpoint.distribution_witness.clone(),
            control: projection.control,
            classification: projection.classification,
            repaired_non_finite_weights: native_counter(
                "repaired_non_finite_weights",
                checkpoint.repaired_non_finite_weights,
            )?,
            repaired_negative_weights: native_counter(
                "repaired_negative_weights",
                checkpoint.repaired_negative_weights,
            )?,
            pre_discard_repaired_non_finite: native_counter(
                "pre_discard_repaired_non_finite",
                checkpoint.pre_discard_repaired_non_finite,
            )?,
            pre_discard_repaired_negative: native_counter(
                "pre_discard_repaired_negative",
                checkpoint.pre_discard_repaired_negative,
            )?,
        })
    }

    fn trace_value_matches(actual: Option<f32>, expected: f64) -> bool {
        actual.is_some_and(|actual| {
            actual.is_finite()
                && (f64::from(actual) - expected).abs()
                    <= 8.0 * f32::EPSILON as f64 * expected.abs().max(1.0)
        })
    }

    fn from_zspace_trace_event(event: &ZSpaceTraceEvent) -> Option<Self> {
        let ZSpaceTraceEvent::Aggregated {
            coherence,
            diagnostics,
            ..
        } = event
        else {
            return None;
        };
        let witness = diagnostics.distribution_witness.as_ref()?;
        let distribution = validate_zspace_coherence_distribution_witness(witness).ok()?;
        if diagnostics.distribution_channels != Some(distribution.channels)
            || !Self::trace_value_matches(
                diagnostics.distribution_weight_mass,
                distribution.weight_mass,
            )
            || !Self::trace_value_matches(Some(diagnostics.entropy), distribution.weight_entropy)
            || !Self::trace_value_matches(
                diagnostics.normalized_entropy,
                distribution.normalized_entropy,
            )
            || !Self::trace_value_matches(diagnostics.concentration, distribution.concentration)
            || !Self::trace_value_matches(
                diagnostics.effective_channels,
                distribution.effective_channels,
            )
        {
            return None;
        }

        let policy = ZSpaceCoherenceClassificationPolicy {
            background_energy_ratio_max: diagnostics.background_energy_ratio_max?,
            cascade_energy_ratio_min: diagnostics.cascade_energy_ratio_min?,
        };
        let complete_coherence = if coherence.len() == distribution.channels {
            coherence.iter().map(|value| f64::from(*value)).collect()
        } else {
            Vec::new()
        };
        let projection = project_zspace_coherence(ZSpaceCoherenceProjectionRequest {
            diagnostics: ZSpaceCoherenceDiagnosticsInput {
                mean_coherence: f64::from(diagnostics.mean_coherence),
                coherence_entropy: f64::from(diagnostics.entropy),
                energy_ratio: f64::from(diagnostics.energy_ratio),
                z_bias: f64::from(diagnostics.z_bias),
                fractional_order: f64::from(diagnostics.fractional_order),
                normalized_weights: witness.normalized_weights.clone(),
                preserved_channels: Some(diagnostics.preserved_channels),
                discarded_channels: Some(diagnostics.discarded_channels),
                dominant_channel: diagnostics.dominant_channel,
            },
            coherence: complete_coherence,
            contour: None,
            config: ZSpaceCoherenceProjectionConfig::default(),
            classification_policy: policy,
        })
        .ok()?;
        let control = projection.control?;
        if diagnostics.control_kind.as_deref() != Some(ZSPACE_COHERENCE_CONTROL_KIND)
            || diagnostics.control_contract_version.as_deref()
                != Some(ZSPACE_COHERENCE_CONTROL_CONTRACT_VERSION)
            || diagnostics.control_semantic_owner.as_deref()
                != Some(ZSPACE_COHERENCE_PROJECTION_SEMANTIC_OWNER)
            || diagnostics.control_semantic_backend.as_deref()
                != Some(ZSPACE_COHERENCE_PROJECTION_SEMANTIC_BACKEND)
            || diagnostics.control_formula.as_deref() != Some(ZSPACE_COHERENCE_CONTROL_FORMULA)
            || !Self::trace_value_matches(diagnostics.spectral_radius, control.spectral_radius)
            || !Self::trace_value_matches(diagnostics.spectral_entropy, control.spectral_entropy)
            || !Self::trace_value_matches(diagnostics.spectral_pressure, control.spectral_pressure)
        {
            return None;
        }
        let classification = projection.classification?;
        if diagnostics.label != classification.label.as_str()
            || diagnostics.swap_invariant != Some(classification.swap_invariant)
            || diagnostics.classification_kind.as_deref()
                != Some(ZSPACE_COHERENCE_CLASSIFICATION_KIND)
            || diagnostics.classification_contract_version.as_deref()
                != Some(ZSPACE_COHERENCE_CLASSIFICATION_CONTRACT_VERSION)
            || diagnostics.classification_semantic_owner.as_deref()
                != Some(ZSPACE_COHERENCE_PROJECTION_SEMANTIC_OWNER)
            || diagnostics.classification_semantic_backend.as_deref()
                != Some(ZSPACE_COHERENCE_PROJECTION_SEMANTIC_BACKEND)
            || diagnostics.classification_formula.as_deref()
                != Some(ZSPACE_COHERENCE_CLASSIFICATION_FORMULA)
            || diagnostics.classification_reason.as_deref() != Some(classification.reason)
        {
            return None;
        }
        Some(Self {
            dominant_channel: diagnostics.dominant_channel,
            preserved_channels: diagnostics.preserved_channels,
            z_bias: diagnostics.z_bias,
            distribution_witness: witness.as_ref().clone(),
            control,
            classification,
            repaired_non_finite_weights: diagnostics.repaired_non_finite_weights,
            repaired_negative_weights: diagnostics.repaired_negative_weights,
            pre_discard_repaired_non_finite: diagnostics.pre_discard_repaired_non_finite,
            pre_discard_repaired_negative: diagnostics.pre_discard_repaired_negative,
        })
    }

    fn from_diagnostics(diagnostics: &CoherenceDiagnostics) -> Option<Self> {
        let distribution_witness = diagnostics.distribution_witness().ok()?;
        let projection = diagnostics
            .project_to_zspace_partial(ZSpaceCoherenceProjectionConfig::default(), None)
            .ok()?;
        let control = projection.control?;
        let classification = projection.classification?;
        Some(Self {
            dominant_channel: diagnostics.dominant_channel(),
            preserved_channels: diagnostics.preserved_channels(),
            z_bias: diagnostics.z_bias(),
            distribution_witness,
            control,
            classification,
            repaired_non_finite_weights: diagnostics.repaired_non_finite_weights(),
            repaired_negative_weights: diagnostics.repaired_negative_weights(),
            pre_discard_repaired_non_finite: diagnostics
                .pre_discard()
                .map(|telemetry| telemetry.repaired_non_finite())
                .unwrap_or(0),
            pre_discard_repaired_negative: diagnostics
                .pre_discard()
                .map(|telemetry| telemetry.repaired_negative())
                .unwrap_or(0),
        })
    }
}

impl From<&CoherenceDiagnostics> for CoherenceSignal {
    fn from(diagnostics: &CoherenceDiagnostics) -> Self {
        Self::from_diagnostics(diagnostics)
            .expect("CoherenceDiagnostics must satisfy its Rust-owned control contract")
    }
}

/// Listens for `ZSpaceTrace` plugin events and lifts coherence diagnostics into a signal.
pub struct ZSpaceTraceCoherenceBridge {
    bus: st_core::plugin::PluginEventBus,
    subscription_id: usize,
    latest: Arc<Mutex<Option<CoherenceSignal>>>,
}

impl ZSpaceTraceCoherenceBridge {
    fn replace_latest(latest: &Mutex<Option<CoherenceSignal>>, signal: Option<CoherenceSignal>) {
        let mut guard = latest
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        *guard = signal;
    }

    fn replace_latest_from_trace_event(
        latest: &Mutex<Option<CoherenceSignal>>,
        trace_event: &ZSpaceTraceEvent,
    ) {
        if matches!(trace_event, ZSpaceTraceEvent::Aggregated { .. }) {
            Self::replace_latest(
                latest,
                CoherenceSignal::from_zspace_trace_event(trace_event),
            );
        }
    }

    fn subscribe_with_latest(initial: Option<CoherenceSignal>) -> Self {
        let bus = global_registry().event_bus().clone();
        let latest: Arc<Mutex<Option<CoherenceSignal>>> = Arc::new(Mutex::new(initial));
        let latest_clone = Arc::clone(&latest);
        let subscription_id = bus.subscribe(
            "ZSpaceTrace",
            Arc::new(move |event: &PluginEvent| {
                let Some(payload) = event.downcast_data::<serde_json::Value>() else {
                    return;
                };
                let is_aggregated = payload.get("kind").and_then(Value::as_str)
                    == Some("Aggregated")
                    || payload.get("Aggregated").is_some();
                let Ok(trace_event) = ZSpaceTraceEvent::from_plugin_payload(payload.clone()) else {
                    if is_aggregated {
                        Self::replace_latest(&latest_clone, None);
                    }
                    return;
                };
                Self::replace_latest_from_trace_event(&latest_clone, &trace_event);
            }),
        );
        Self {
            bus,
            subscription_id,
            latest,
        }
    }

    pub fn subscribe() -> Self {
        Self::subscribe_with_latest(None)
    }

    fn checkpoint_latest(&self) -> Option<CoherenceSignal> {
        self.latest
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
            .clone()
    }

    fn restore_latest(&self, signal: Option<CoherenceSignal>) {
        Self::replace_latest(&self.latest, signal);
    }

    pub fn drain(&self) -> Option<CoherenceSignal> {
        let mut guard = self
            .latest
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        guard.take()
    }
}

impl Drop for ZSpaceTraceCoherenceBridge {
    fn drop(&mut self) {
        let _ = self.bus.unsubscribe("ZSpaceTrace", self.subscription_id);
    }
}

#[derive(Debug, Default)]
struct TensorBackendStepTrace {
    total: usize,
    fallbacks: usize,
    meta_events: usize,
    meta_null_values: usize,
    meta_non_finite_strings: usize,
    by_backend: HashMap<String, usize>,
    by_kernel_backend: HashMap<String, usize>,
    by_op: HashMap<String, usize>,
    by_op_backend: HashMap<String, usize>,
    by_op_kernel_backend: HashMap<String, usize>,
    requested_wgpu_hits: usize,
    requested_wgpu_runtime_fallbacks: usize,
    requested_wgpu_hits_by_op_backend: HashMap<String, usize>,
    requested_wgpu_runtime_fallbacks_by_op_backend: HashMap<String, usize>,
    requested_wgpu_component_hits: usize,
    requested_wgpu_component_fallbacks: usize,
    requested_wgpu_component_hits_by_op_backend: HashMap<String, usize>,
    requested_wgpu_component_fallbacks_by_op_backend: HashMap<String, usize>,
    embedding_tokens: usize,
    embedding_unique_token_indices: usize,
    embedding_repeated_token_indices: usize,
    embedding_non_finite_tokens: usize,
    embedding_rounded_tokens: usize,
    embedding_clamped_low_tokens: usize,
    embedding_clamped_high_tokens: usize,
    backend_policy_events: usize,
    backend_policy_status: HashMap<String, usize>,
    backend_policy_source: HashMap<String, usize>,
    backend_policy_wgpu_choices: usize,
    backend_policy_unison_choices: usize,
    backend_policy_kdsl_env_events: usize,
    backend_policy_kdsl_kv_events: usize,
    backend_policy_kv_soft_events: usize,
    backend_policy_wasm_tuner_events: usize,
    backend_policy_tensor_util_routes: usize,
    backend_policy_wgpu_last_workgroup: Option<f64>,
    backend_policy_wgpu_last_lanes: Option<f64>,
    backend_policy_wgpu_last_compaction_tile: Option<f64>,
    backend_policy_wgpu_last_fft_radix: Option<f64>,
    backend_policy_wgpu_last_fft_segments: Option<f64>,
    backend_policy_wgpu_last_override_count: Option<f64>,
    backend_policy_unison_last_candidate_count: Option<f64>,
    backend_policy_unison_last_best_score: Option<f64>,
    backend_policy_unison_last_baseline_score: Option<f64>,
    backend_policy_unison_last_wgpu_generated_score: Option<f64>,
    backend_policy_unison_last_wgpu_generated_score_delta: Option<f64>,
    backend_policy_tensor_util_last_values: Option<f64>,
    backend_policy_tensor_util_last_threshold: Option<f64>,
    lstm_forward_estimated_gate_activation_ops: usize,
    lstm_forward_estimated_gate_activation_cpu_debt_ops: usize,
    lstm_forward_estimated_gate_activation_wgpu_ops: usize,
    lstm_backward_estimated_gate_activation_ops: usize,
    lstm_backward_estimated_gate_activation_cpu_debt_ops: usize,
    lstm_backward_estimated_gate_activation_wgpu_ops: usize,
    lstm_backward_estimated_bptt_ops: usize,
    lstm_backward_estimated_bptt_cpu_debt_ops: usize,
    lstm_backward_estimated_bptt_wgpu_ops: usize,
    lstm_backward_estimated_bptt_gate_derivative_ops: usize,
    lstm_backward_estimated_bptt_cell_recurrence_ops: usize,
    lstm_backward_estimated_bptt_state_carry_ops: usize,
    lstm_backward_estimated_bptt_scan_steps: usize,
}

impl TensorBackendStepTrace {
    fn record_sub_backend(
        &mut self,
        op: &str,
        requested_backend: Option<&str>,
        field: &'static str,
        sub_backend: &str,
        count_fallback: bool,
    ) {
        let sub_backend = backend_metric_fragment(sub_backend);
        if sub_backend == "auto" {
            return;
        }
        let field = field.strip_suffix("_backend").unwrap_or(field);
        *self
            .by_op_backend
            .entry(format!("{op}_{field}_{sub_backend}"))
            .or_default() += 1;
        if count_fallback && requested_backend == Some("wgpu") {
            let key = format!("{op}_{field}_{sub_backend}");
            if sub_backend == "wgpu" {
                self.requested_wgpu_component_hits =
                    self.requested_wgpu_component_hits.saturating_add(1);
                *self
                    .requested_wgpu_component_hits_by_op_backend
                    .entry(key)
                    .or_default() += 1;
            } else if !is_metadata_only_backend(&sub_backend) {
                self.requested_wgpu_component_fallbacks =
                    self.requested_wgpu_component_fallbacks.saturating_add(1);
                *self
                    .requested_wgpu_component_fallbacks_by_op_backend
                    .entry(key)
                    .or_default() += 1;
            }
        }
        if count_fallback {
            if let Some(requested) = requested_backend {
                if requested != "auto"
                    && requested != sub_backend
                    && !is_metadata_only_backend(&sub_backend)
                {
                    self.fallbacks = self.fallbacks.saturating_add(1);
                }
            }
        }
    }

    fn record(&mut self, event: &TensorOpMetaEvent) {
        self.meta_events = self.meta_events.saturating_add(1);
        let mut meta_health = TensorMetaHealth::default();
        meta_health.record(&event.data);
        self.meta_null_values = self
            .meta_null_values
            .saturating_add(meta_health.null_values);
        self.meta_non_finite_strings = self
            .meta_non_finite_strings
            .saturating_add(meta_health.non_finite_strings);

        self.record_backend_policy_event(event);

        if event
            .data
            .get("counts_as_execution")
            .and_then(|value| value.as_bool())
            == Some(false)
        {
            return;
        }

        let execution_receipt = match event.data.get("execution_receipt") {
            None => None,
            Some(value) => {
                let Ok(receipt) = serde_json::from_value::<TensorExecutionReceipt>(value.clone())
                else {
                    return;
                };
                if receipt.validate().is_err() {
                    return;
                }
                if receipt.operation != event.op_name {
                    return;
                }
                Some(receipt)
            }
        };

        let executed_backend = match execution_receipt.as_ref() {
            Some(receipt) => receipt.executed_backend.map(|backend| backend.as_str()),
            None => event.data.get("backend").and_then(|value| value.as_str()),
        };
        let Some(backend) = executed_backend else {
            return;
        };
        let kernel_backend = match execution_receipt.as_ref() {
            Some(receipt) => receipt
                .kernel_backend
                .map(|kernel| metric_fragment(kernel.as_str())),
            None => Some(metric_fragment(backend)),
        };
        let Some(kernel_backend) = kernel_backend else {
            return;
        };
        let backend = backend_metric_fragment(backend);
        let op = metric_fragment(event.op_name);
        self.total = self.total.saturating_add(1);
        *self.by_backend.entry(backend.clone()).or_default() += 1;
        *self
            .by_kernel_backend
            .entry(kernel_backend.clone())
            .or_default() += 1;
        *self.by_op.entry(op.clone()).or_default() += 1;
        *self
            .by_op_backend
            .entry(format!("{op}_{backend}"))
            .or_default() += 1;
        *self
            .by_op_kernel_backend
            .entry(format!("{op}_{kernel_backend}"))
            .or_default() += 1;

        let receipt_requested_backend = execution_receipt
            .as_ref()
            .map(|receipt| receipt.requested_backend.as_str());
        let requested_backend = receipt_requested_backend
            .or_else(|| {
                event
                    .data
                    .get("requested_backend")
                    .and_then(|value| value.as_str())
            })
            .map(backend_metric_fragment);
        if let Some(requested) = requested_backend.as_deref() {
            if requested == "wgpu" {
                let op_backend = format!("{op}_{backend}");
                if backend == "wgpu" {
                    self.requested_wgpu_hits = self.requested_wgpu_hits.saturating_add(1);
                    *self
                        .requested_wgpu_hits_by_op_backend
                        .entry(op_backend)
                        .or_default() += 1;
                } else if is_cpu_runtime_backend(&backend)
                    && execution_receipt
                        .as_ref()
                        .map(|receipt| {
                            receipt.route_status == TensorExecutionRouteStatus::RuntimeFallback
                        })
                        .unwrap_or_else(|| is_wgpu_runtime_fallback(&event.data))
                {
                    self.requested_wgpu_runtime_fallbacks =
                        self.requested_wgpu_runtime_fallbacks.saturating_add(1);
                    *self
                        .requested_wgpu_runtime_fallbacks_by_op_backend
                        .entry(op_backend)
                        .or_default() += 1;
                }
            }
            let typed_runtime_fallback = execution_receipt.as_ref().is_some_and(|receipt| {
                receipt.route_status == TensorExecutionRouteStatus::RuntimeFallback
            });
            if typed_runtime_fallback
                || (execution_receipt.is_none()
                    && requested != "auto"
                    && requested != backend
                    && !is_metadata_only_backend(&backend))
            {
                self.fallbacks = self.fallbacks.saturating_add(1);
            }
        }
        for (field, count_fallback) in [
            ("input_gradient_backend", true),
            ("input_gradient_reduction_backend", true),
            ("gradient_reduction_backend", true),
            ("affine_gradient_backend", true),
            ("normalization_backend", true),
            ("input_projection_backend", true),
            ("bias_backend", true),
            ("recurrent_backend", true),
            ("gate_activation_backend", true),
            ("bptt_backend", true),
            ("bptt_scan_backend", false),
            ("bptt_gate_derivative_backend", true),
            ("bptt_cell_recurrence_backend", true),
            ("bptt_state_carry_backend", true),
            ("raw_parameter_gradient_backend", true),
            ("parameter_gradient_reduction_backend", true),
            ("bias_gradient_backend", true),
            ("parameter_gradient_scale_backend", true),
            ("broadcast_backend", true),
            ("activation_backend", true),
            ("preactivation_backend", true),
            ("geometry_backend", true),
            ("mask_backend", true),
            ("rng_backend", false),
            ("deterministic_backend", true),
            ("gradient_scale_backend", true),
            ("merge_backend", true),
            ("accumulation_backend", true),
            ("normalise_backend", true),
            ("rewrite_backend", true),
            ("projection_backend", true),
            ("projection_gradient_backend", true),
            ("saturation_gradient_backend", true),
            ("softmax_backend", true),
            ("exp_backend", true),
            ("sanitize_backend", true),
            ("distribution_scale_backend", true),
            ("semantic_inference_backend", true),
            ("semantic_sparse_scan_backend", true),
            ("semantic_accumulation_backend", true),
            ("semantic_sanitize_backend", true),
            ("window_energy_backend", true),
            ("fusion_accumulation_backend", true),
            ("marginal_scan_backend", true),
            ("marginal_sum_backend", true),
            ("row_scan_backend", true),
            ("row_sum_backend", true),
            ("state_sum_backend", true),
            ("precision_backend", true),
            ("reduction_backend", true),
            ("covariance_centering_backend", true),
            ("covariance_accumulation_backend", true),
            ("low_rank_projection_backend", true),
            ("psd_projection_backend", true),
        ] {
            if let Some(sub_backend) = event.data.get(field).and_then(|value| value.as_str()) {
                self.record_sub_backend(
                    &op,
                    requested_backend.as_deref(),
                    field,
                    sub_backend,
                    count_fallback,
                );
            }
        }

        if matches!(event.op_name, "embedding_forward" | "embedding_backward") {
            self.embedding_tokens = self
                .embedding_tokens
                .saturating_add(meta_usize(&event.data, "tokens"));
            self.embedding_unique_token_indices = self
                .embedding_unique_token_indices
                .saturating_add(meta_usize(&event.data, "unique_token_indices"));
            self.embedding_repeated_token_indices = self
                .embedding_repeated_token_indices
                .saturating_add(meta_usize(&event.data, "repeated_token_indices"));
            self.embedding_non_finite_tokens = self
                .embedding_non_finite_tokens
                .saturating_add(meta_usize(&event.data, "non_finite_tokens"));
            self.embedding_rounded_tokens = self
                .embedding_rounded_tokens
                .saturating_add(meta_usize(&event.data, "rounded_tokens"));
            self.embedding_clamped_low_tokens = self
                .embedding_clamped_low_tokens
                .saturating_add(meta_usize(&event.data, "clamped_low_tokens"));
            self.embedding_clamped_high_tokens = self
                .embedding_clamped_high_tokens
                .saturating_add(meta_usize(&event.data, "clamped_high_tokens"));
        }
        if event.op_name == "lstm_forward" {
            let gate_activation_ops = meta_usize(&event.data, "estimated_gate_activation_ops");
            self.lstm_forward_estimated_gate_activation_ops = self
                .lstm_forward_estimated_gate_activation_ops
                .saturating_add(gate_activation_ops);
            let gate_backend = event
                .data
                .get("gate_activation_backend")
                .and_then(|value| value.as_str())
                .map(backend_metric_fragment)
                .unwrap_or_else(|| "cpu".to_string());
            if gate_backend == "wgpu" {
                self.lstm_forward_estimated_gate_activation_wgpu_ops = self
                    .lstm_forward_estimated_gate_activation_wgpu_ops
                    .saturating_add(gate_activation_ops);
            } else {
                self.lstm_forward_estimated_gate_activation_cpu_debt_ops = self
                    .lstm_forward_estimated_gate_activation_cpu_debt_ops
                    .saturating_add(gate_activation_ops);
            }
        }
        if event.op_name == "lstm_backward" {
            let gate_activation_ops = meta_usize(&event.data, "estimated_gate_activation_ops");
            self.lstm_backward_estimated_gate_activation_ops = self
                .lstm_backward_estimated_gate_activation_ops
                .saturating_add(gate_activation_ops);
            let gate_backend = event
                .data
                .get("gate_activation_backend")
                .and_then(|value| value.as_str())
                .map(backend_metric_fragment)
                .unwrap_or_else(|| "cpu".to_string());
            if gate_backend == "wgpu" {
                self.lstm_backward_estimated_gate_activation_wgpu_ops = self
                    .lstm_backward_estimated_gate_activation_wgpu_ops
                    .saturating_add(gate_activation_ops);
            } else {
                self.lstm_backward_estimated_gate_activation_cpu_debt_ops = self
                    .lstm_backward_estimated_gate_activation_cpu_debt_ops
                    .saturating_add(gate_activation_ops);
            }
            let bptt_ops = meta_usize(&event.data, "estimated_bptt_ops");
            self.lstm_backward_estimated_bptt_ops = self
                .lstm_backward_estimated_bptt_ops
                .saturating_add(bptt_ops);
            let bptt_backend = event
                .data
                .get("bptt_backend")
                .or_else(|| event.data.get("bptt_scan_backend"))
                .and_then(|value| value.as_str())
                .map(backend_metric_fragment);
            let bptt_cpu_debt_ops = if event.data.get("estimated_bptt_cpu_debt_ops").is_some() {
                meta_usize(&event.data, "estimated_bptt_cpu_debt_ops")
            } else if bptt_backend.as_deref() == Some("cpu") {
                bptt_ops
            } else {
                0
            };
            let bptt_wgpu_ops = if event.data.get("estimated_bptt_wgpu_ops").is_some() {
                meta_usize(&event.data, "estimated_bptt_wgpu_ops")
            } else if bptt_backend.as_deref() == Some("wgpu") {
                bptt_ops
            } else {
                0
            };
            self.lstm_backward_estimated_bptt_cpu_debt_ops = self
                .lstm_backward_estimated_bptt_cpu_debt_ops
                .saturating_add(bptt_cpu_debt_ops);
            self.lstm_backward_estimated_bptt_wgpu_ops = self
                .lstm_backward_estimated_bptt_wgpu_ops
                .saturating_add(bptt_wgpu_ops);
            self.lstm_backward_estimated_bptt_gate_derivative_ops = self
                .lstm_backward_estimated_bptt_gate_derivative_ops
                .saturating_add(meta_usize(
                    &event.data,
                    "estimated_bptt_gate_derivative_ops",
                ));
            self.lstm_backward_estimated_bptt_cell_recurrence_ops = self
                .lstm_backward_estimated_bptt_cell_recurrence_ops
                .saturating_add(meta_usize(
                    &event.data,
                    "estimated_bptt_cell_recurrence_ops",
                ));
            self.lstm_backward_estimated_bptt_state_carry_ops = self
                .lstm_backward_estimated_bptt_state_carry_ops
                .saturating_add(meta_usize(&event.data, "estimated_bptt_state_carry_ops"));
            self.lstm_backward_estimated_bptt_scan_steps = self
                .lstm_backward_estimated_bptt_scan_steps
                .saturating_add(meta_usize(&event.data, "estimated_bptt_scan_steps"));
        }
    }

    fn record_backend_policy_event(&mut self, event: &TensorOpMetaEvent) {
        let op = metric_fragment(event.op_name);
        let tracked = matches!(
            event.op_name,
            "wgpu_heuristic_choice"
                | "unison_rank_choice"
                | "kdsl_env_bridge"
                | "kdsl_kv_bridge"
                | "kv_consensus_soft_rules"
                | "wasm_tuner_choice"
                | "backend_resolution"
                | "backend_device_report"
                | "temporal_spectral_fusion"
                | "tensor_util_route"
        );
        if !tracked {
            return;
        }

        self.backend_policy_events = self.backend_policy_events.saturating_add(1);
        if let Some(status) = meta_str_fragment(&event.data, "status") {
            *self
                .backend_policy_status
                .entry(format!("{op}_{status}"))
                .or_default() += 1;
        }
        if let Some(source) = meta_str_fragment(&event.data, "choice_source") {
            *self
                .backend_policy_source
                .entry(format!("{op}_{source}"))
                .or_default() += 1;
        }

        match event.op_name {
            "wgpu_heuristic_choice" => {
                self.backend_policy_wgpu_choices =
                    self.backend_policy_wgpu_choices.saturating_add(1);
                self.backend_policy_wgpu_last_workgroup = meta_f64(&event.data, "workgroup");
                self.backend_policy_wgpu_last_lanes = meta_f64(&event.data, "lanes");
                self.backend_policy_wgpu_last_compaction_tile =
                    meta_f64(&event.data, "compaction_tile");
                self.backend_policy_wgpu_last_fft_radix = meta_f64(&event.data, "fft_radix");
                self.backend_policy_wgpu_last_fft_segments = meta_f64(&event.data, "fft_segments");
                self.backend_policy_wgpu_last_override_count =
                    meta_f64(&event.data, "override_count");
            }
            "unison_rank_choice" => {
                self.backend_policy_unison_choices =
                    self.backend_policy_unison_choices.saturating_add(1);
                self.backend_policy_unison_last_candidate_count =
                    meta_f64(&event.data, "candidate_count");
                self.backend_policy_unison_last_best_score = meta_f64(&event.data, "best_score");
                self.backend_policy_unison_last_baseline_score =
                    meta_f64(&event.data, "baseline_score");
                self.backend_policy_unison_last_wgpu_generated_score =
                    meta_f64(&event.data, "wgpu_generated_score");
                self.backend_policy_unison_last_wgpu_generated_score_delta =
                    meta_f64(&event.data, "wgpu_generated_score_delta");
            }
            "kdsl_env_bridge" => {
                self.backend_policy_kdsl_env_events =
                    self.backend_policy_kdsl_env_events.saturating_add(1);
            }
            "kdsl_kv_bridge" => {
                self.backend_policy_kdsl_kv_events =
                    self.backend_policy_kdsl_kv_events.saturating_add(1);
            }
            "kv_consensus_soft_rules" => {
                self.backend_policy_kv_soft_events =
                    self.backend_policy_kv_soft_events.saturating_add(1);
            }
            "wasm_tuner_choice" => {
                self.backend_policy_wasm_tuner_events =
                    self.backend_policy_wasm_tuner_events.saturating_add(1);
            }
            "tensor_util_route" => {
                self.backend_policy_tensor_util_routes =
                    self.backend_policy_tensor_util_routes.saturating_add(1);
                self.backend_policy_tensor_util_last_values = meta_f64(&event.data, "values");
                self.backend_policy_tensor_util_last_threshold = meta_f64(&event.data, "threshold");
            }
            _ => {}
        }
    }

    fn write_extra(self, extra: &mut HashMap<String, f64>) {
        if self.meta_events > 0 {
            extra.insert("tensor_meta_events".to_string(), self.meta_events as f64);
            extra.insert(
                "tensor_meta_null_values".to_string(),
                self.meta_null_values as f64,
            );
            extra.insert(
                "tensor_meta_non_finite_strings".to_string(),
                self.meta_non_finite_strings as f64,
            );
            let sentinels = self
                .meta_null_values
                .saturating_add(self.meta_non_finite_strings);
            extra.insert(
                "tensor_meta_non_finite_sentinels".to_string(),
                sentinels as f64,
            );
            if sentinels > 0 {
                extra.insert("tensor_meta_non_finite_detected".to_string(), 1.0);
            }
        }

        if self.total > 0 {
            extra.insert("tensor_ops_total".to_string(), self.total as f64);
            extra.insert(
                "tensor_backend_fallbacks".to_string(),
                self.fallbacks as f64,
            );
            for (backend, count) in self.by_backend {
                extra.insert(format!("tensor_backend_{backend}"), count as f64);
            }
            for (backend, count) in self.by_kernel_backend {
                extra.insert(format!("tensor_kernel_backend_{backend}"), count as f64);
            }
            for (op, count) in self.by_op {
                extra.insert(format!("tensor_op_{op}"), count as f64);
            }
            for (op_backend, count) in self.by_op_backend {
                extra.insert(format!("tensor_op_backend_{op_backend}"), count as f64);
            }
            for (op_backend, count) in self.by_op_kernel_backend {
                extra.insert(
                    format!("tensor_op_kernel_backend_{op_backend}"),
                    count as f64,
                );
            }
            let requested_wgpu_total = self
                .requested_wgpu_hits
                .saturating_add(self.requested_wgpu_runtime_fallbacks);
            if requested_wgpu_total > 0 {
                extra.insert(
                    "tensor_backend_requested_wgpu_hits".to_string(),
                    self.requested_wgpu_hits as f64,
                );
                extra.insert(
                    "tensor_backend_requested_wgpu_runtime_fallbacks".to_string(),
                    self.requested_wgpu_runtime_fallbacks as f64,
                );
                extra.insert(
                    "tensor_backend_requested_wgpu_hit_rate".to_string(),
                    self.requested_wgpu_hits as f64 / requested_wgpu_total as f64,
                );
                extra.insert(
                    "tensor_backend_requested_wgpu_runtime_fallback_rate".to_string(),
                    self.requested_wgpu_runtime_fallbacks as f64 / requested_wgpu_total as f64,
                );
                for (op_backend, count) in self.requested_wgpu_hits_by_op_backend {
                    extra.insert(
                        format!("tensor_op_backend_requested_wgpu_hit_{op_backend}"),
                        count as f64,
                    );
                }
                for (op_backend, count) in self.requested_wgpu_runtime_fallbacks_by_op_backend {
                    extra.insert(
                        format!("tensor_op_backend_wgpu_runtime_fallback_{op_backend}"),
                        count as f64,
                    );
                }
            }
            let requested_wgpu_component_total = self
                .requested_wgpu_component_hits
                .saturating_add(self.requested_wgpu_component_fallbacks);
            if requested_wgpu_component_total > 0 {
                extra.insert(
                    "tensor_backend_requested_wgpu_component_hits".to_string(),
                    self.requested_wgpu_component_hits as f64,
                );
                extra.insert(
                    "tensor_backend_requested_wgpu_component_fallbacks".to_string(),
                    self.requested_wgpu_component_fallbacks as f64,
                );
                extra.insert(
                    "tensor_backend_requested_wgpu_component_hit_rate".to_string(),
                    self.requested_wgpu_component_hits as f64
                        / requested_wgpu_component_total as f64,
                );
                extra.insert(
                    "tensor_backend_requested_wgpu_component_fallback_rate".to_string(),
                    self.requested_wgpu_component_fallbacks as f64
                        / requested_wgpu_component_total as f64,
                );
                for (op_backend, count) in self.requested_wgpu_component_hits_by_op_backend {
                    extra.insert(
                        format!("tensor_op_backend_requested_wgpu_component_hit_{op_backend}"),
                        count as f64,
                    );
                }
                for (op_backend, count) in self.requested_wgpu_component_fallbacks_by_op_backend {
                    extra.insert(
                        format!("tensor_op_backend_requested_wgpu_component_fallback_{op_backend}"),
                        count as f64,
                    );
                }
            }
        }

        if self.embedding_tokens > 0 {
            extra.insert(
                "tensor_embedding_tokens".to_string(),
                self.embedding_tokens as f64,
            );
            extra.insert(
                "tensor_embedding_unique_token_indices".to_string(),
                self.embedding_unique_token_indices as f64,
            );
            extra.insert(
                "tensor_embedding_repeated_token_indices".to_string(),
                self.embedding_repeated_token_indices as f64,
            );
            extra.insert(
                "tensor_embedding_non_finite_tokens".to_string(),
                self.embedding_non_finite_tokens as f64,
            );
            extra.insert(
                "tensor_embedding_rounded_tokens".to_string(),
                self.embedding_rounded_tokens as f64,
            );
            extra.insert(
                "tensor_embedding_clamped_low_tokens".to_string(),
                self.embedding_clamped_low_tokens as f64,
            );
            extra.insert(
                "tensor_embedding_clamped_high_tokens".to_string(),
                self.embedding_clamped_high_tokens as f64,
            );
            let repairs = self
                .embedding_non_finite_tokens
                .saturating_add(self.embedding_rounded_tokens)
                .saturating_add(self.embedding_clamped_low_tokens)
                .saturating_add(self.embedding_clamped_high_tokens);
            extra.insert(
                "tensor_embedding_token_repairs_total".to_string(),
                repairs as f64,
            );
            if repairs > 0 {
                extra.insert("tensor_embedding_token_repair_detected".to_string(), 1.0);
            }
        }

        if self.lstm_forward_estimated_gate_activation_ops > 0
            || self.lstm_backward_estimated_gate_activation_ops > 0
            || self.lstm_backward_estimated_bptt_ops > 0
        {
            let gate_activation_ops = self
                .lstm_forward_estimated_gate_activation_ops
                .saturating_add(self.lstm_backward_estimated_gate_activation_ops);
            let gate_activation_cpu_debt_ops = self
                .lstm_forward_estimated_gate_activation_cpu_debt_ops
                .saturating_add(self.lstm_backward_estimated_gate_activation_cpu_debt_ops);
            let gate_activation_wgpu_ops = self
                .lstm_forward_estimated_gate_activation_wgpu_ops
                .saturating_add(self.lstm_backward_estimated_gate_activation_wgpu_ops);
            let cpu_debt_ops = gate_activation_cpu_debt_ops
                .saturating_add(self.lstm_backward_estimated_bptt_cpu_debt_ops);
            extra.insert(
                "lstm_estimated_gate_activation_ops".to_string(),
                gate_activation_ops as f64,
            );
            extra.insert(
                "lstm_estimated_gate_activation_cpu_debt_ops".to_string(),
                gate_activation_cpu_debt_ops as f64,
            );
            extra.insert(
                "lstm_estimated_gate_activation_wgpu_ops".to_string(),
                gate_activation_wgpu_ops as f64,
            );
            extra.insert(
                "lstm_estimated_cpu_debt_ops".to_string(),
                cpu_debt_ops as f64,
            );
            extra.insert(
                "lstm_forward_estimated_gate_activation_ops".to_string(),
                self.lstm_forward_estimated_gate_activation_ops as f64,
            );
            extra.insert(
                "lstm_forward_estimated_gate_activation_cpu_debt_ops".to_string(),
                self.lstm_forward_estimated_gate_activation_cpu_debt_ops as f64,
            );
            extra.insert(
                "lstm_forward_estimated_gate_activation_wgpu_ops".to_string(),
                self.lstm_forward_estimated_gate_activation_wgpu_ops as f64,
            );
            extra.insert(
                "lstm_backward_estimated_gate_activation_ops".to_string(),
                self.lstm_backward_estimated_gate_activation_ops as f64,
            );
            extra.insert(
                "lstm_backward_estimated_gate_activation_cpu_debt_ops".to_string(),
                self.lstm_backward_estimated_gate_activation_cpu_debt_ops as f64,
            );
            extra.insert(
                "lstm_backward_estimated_gate_activation_wgpu_ops".to_string(),
                self.lstm_backward_estimated_gate_activation_wgpu_ops as f64,
            );
            extra.insert(
                "lstm_backward_estimated_bptt_ops".to_string(),
                self.lstm_backward_estimated_bptt_ops as f64,
            );
            extra.insert(
                "lstm_estimated_bptt_cpu_debt_ops".to_string(),
                self.lstm_backward_estimated_bptt_cpu_debt_ops as f64,
            );
            extra.insert(
                "lstm_estimated_bptt_wgpu_ops".to_string(),
                self.lstm_backward_estimated_bptt_wgpu_ops as f64,
            );
            extra.insert(
                "lstm_backward_estimated_bptt_cpu_debt_ops".to_string(),
                self.lstm_backward_estimated_bptt_cpu_debt_ops as f64,
            );
            extra.insert(
                "lstm_backward_estimated_bptt_wgpu_ops".to_string(),
                self.lstm_backward_estimated_bptt_wgpu_ops as f64,
            );
            extra.insert(
                "lstm_backward_estimated_bptt_gate_derivative_ops".to_string(),
                self.lstm_backward_estimated_bptt_gate_derivative_ops as f64,
            );
            extra.insert(
                "lstm_backward_estimated_bptt_cell_recurrence_ops".to_string(),
                self.lstm_backward_estimated_bptt_cell_recurrence_ops as f64,
            );
            extra.insert(
                "lstm_backward_estimated_bptt_state_carry_ops".to_string(),
                self.lstm_backward_estimated_bptt_state_carry_ops as f64,
            );
            extra.insert(
                "lstm_backward_estimated_bptt_scan_steps".to_string(),
                self.lstm_backward_estimated_bptt_scan_steps as f64,
            );
        }

        if self.backend_policy_events > 0 {
            extra.insert(
                "backend_policy_events".to_string(),
                self.backend_policy_events as f64,
            );
            extra.insert(
                "backend_policy_wgpu_choices".to_string(),
                self.backend_policy_wgpu_choices as f64,
            );
            extra.insert(
                "backend_policy_unison_choices".to_string(),
                self.backend_policy_unison_choices as f64,
            );
            extra.insert(
                "backend_policy_kdsl_env_events".to_string(),
                self.backend_policy_kdsl_env_events as f64,
            );
            extra.insert(
                "backend_policy_kdsl_kv_events".to_string(),
                self.backend_policy_kdsl_kv_events as f64,
            );
            extra.insert(
                "backend_policy_kv_soft_events".to_string(),
                self.backend_policy_kv_soft_events as f64,
            );
            extra.insert(
                "backend_policy_wasm_tuner_events".to_string(),
                self.backend_policy_wasm_tuner_events as f64,
            );
            extra.insert(
                "backend_policy_tensor_util_routes".to_string(),
                self.backend_policy_tensor_util_routes as f64,
            );
            for (status, count) in self.backend_policy_status {
                extra.insert(format!("backend_policy_status_{status}"), count as f64);
            }
            for (source, count) in self.backend_policy_source {
                extra.insert(format!("backend_policy_source_{source}"), count as f64);
            }
            insert_optional_extra(
                extra,
                "backend_policy_wgpu_last_workgroup",
                self.backend_policy_wgpu_last_workgroup,
            );
            insert_optional_extra(
                extra,
                "backend_policy_wgpu_last_lanes",
                self.backend_policy_wgpu_last_lanes,
            );
            insert_optional_extra(
                extra,
                "backend_policy_wgpu_last_compaction_tile",
                self.backend_policy_wgpu_last_compaction_tile,
            );
            insert_optional_extra(
                extra,
                "backend_policy_wgpu_last_fft_radix",
                self.backend_policy_wgpu_last_fft_radix,
            );
            insert_optional_extra(
                extra,
                "backend_policy_wgpu_last_fft_segments",
                self.backend_policy_wgpu_last_fft_segments,
            );
            insert_optional_extra(
                extra,
                "backend_policy_wgpu_last_override_count",
                self.backend_policy_wgpu_last_override_count,
            );
            insert_optional_extra(
                extra,
                "backend_policy_unison_last_candidate_count",
                self.backend_policy_unison_last_candidate_count,
            );
            insert_optional_extra(
                extra,
                "backend_policy_unison_last_best_score",
                self.backend_policy_unison_last_best_score,
            );
            insert_optional_extra(
                extra,
                "backend_policy_unison_last_baseline_score",
                self.backend_policy_unison_last_baseline_score,
            );
            insert_optional_extra(
                extra,
                "backend_policy_unison_last_wgpu_generated_score",
                self.backend_policy_unison_last_wgpu_generated_score,
            );
            insert_optional_extra(
                extra,
                "backend_policy_unison_last_wgpu_generated_score_delta",
                self.backend_policy_unison_last_wgpu_generated_score_delta,
            );
            insert_optional_extra(
                extra,
                "backend_policy_tensor_util_last_values",
                self.backend_policy_tensor_util_last_values,
            );
            insert_optional_extra(
                extra,
                "backend_policy_tensor_util_last_threshold",
                self.backend_policy_tensor_util_last_threshold,
            );
        }
    }

    fn validate_expected_backend(&self, expected: BackendKind) -> PureResult<()> {
        let expected_label = expected.as_str();
        let kernel_total = self
            .by_backend
            .iter()
            .filter(|(backend, _)| !is_metadata_only_backend(backend))
            .map(|(_, count)| *count)
            .sum::<usize>();
        if kernel_total == 0 {
            return Err(TensorError::BackendFailure {
                backend: expected_label,
                message: format!(
                    "trainer requested {expected_label} with SPIRALTORCH_STRICT_GPU, but no tensor kernel backend metadata was emitted"
                ),
            });
        }
        let mismatched = self
            .by_backend
            .iter()
            .filter(|(backend, _)| {
                backend.as_str() != expected_label && !is_metadata_only_backend(backend)
            })
            .map(|(backend, count)| format!("{backend}:{count}"))
            .collect::<Vec<_>>();
        if mismatched.is_empty() {
            return Ok(());
        }
        let mut observed = self
            .by_backend
            .iter()
            .map(|(backend, count)| format!("{backend}:{count}"))
            .collect::<Vec<_>>();
        observed.sort();
        Err(TensorError::BackendFailure {
            backend: expected_label,
            message: format!(
                "trainer requested {expected_label} with SPIRALTORCH_STRICT_GPU, but tensor kernels used [{}]; mismatched [{}]",
                observed.join(", "),
                mismatched.join(", ")
            ),
        })
    }
}

/// Tensor backend counters aggregated across one training epoch.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, serde::Deserialize, serde::Serialize)]
pub struct EpochTensorBackendStats {
    pub ops_total: usize,
    pub fallbacks: usize,
    pub meta_events: usize,
    pub meta_non_finite_sentinels: usize,
    pub backend_wgpu: usize,
    pub backend_cuda: usize,
    pub backend_hip: usize,
    pub backend_cpu: usize,
    pub backend_cpu_simd: usize,
    pub backend_f64_cpu: usize,
    pub backend_faer: usize,
    pub backend_naive: usize,
    pub backend_other: usize,
    pub kernel_backend_wgpu_dense: usize,
    pub kernel_backend_simd: usize,
    pub kernel_backend_other: usize,
    pub requested_wgpu_hits: usize,
    pub requested_wgpu_runtime_fallbacks: usize,
    pub requested_wgpu_component_hits: usize,
    pub requested_wgpu_component_fallbacks: usize,
    pub embedding_tokens: usize,
    pub embedding_unique_token_indices: usize,
    pub embedding_repeated_token_indices: usize,
    pub embedding_token_repairs: usize,
}

impl EpochTensorBackendStats {
    fn checkpoint_counters(&self) -> TrainerBackendCounters {
        TrainerBackendCounters {
            epochs_recorded: 1,
            ops_total: self.ops_total as u64,
            fallbacks: self.fallbacks as u64,
            backend_wgpu: self.backend_wgpu as u64,
            backend_cuda: self.backend_cuda as u64,
            backend_hip: self.backend_hip as u64,
            backend_cpu: self
                .backend_cpu
                .saturating_add(self.backend_cpu_simd)
                .saturating_add(self.backend_f64_cpu)
                .saturating_add(self.backend_faer)
                .saturating_add(self.backend_naive) as u64,
            backend_other: self.backend_other as u64,
            requested_wgpu_hits: self.requested_wgpu_hits as u64,
            requested_wgpu_runtime_fallbacks: self.requested_wgpu_runtime_fallbacks as u64,
            requested_wgpu_component_hits: self.requested_wgpu_component_hits as u64,
            requested_wgpu_component_fallbacks: self.requested_wgpu_component_fallbacks as u64,
        }
    }

    pub fn requested_wgpu_total(&self) -> usize {
        self.requested_wgpu_hits
            .saturating_add(self.requested_wgpu_runtime_fallbacks)
    }

    pub fn requested_wgpu_hit_rate(&self) -> Option<f64> {
        let total = self.requested_wgpu_total();
        (total > 0).then(|| self.requested_wgpu_hits as f64 / total as f64)
    }

    pub fn requested_wgpu_runtime_fallback_rate(&self) -> Option<f64> {
        let total = self.requested_wgpu_total();
        (total > 0).then(|| self.requested_wgpu_runtime_fallbacks as f64 / total as f64)
    }

    pub fn requested_wgpu_component_total(&self) -> usize {
        self.requested_wgpu_component_hits
            .saturating_add(self.requested_wgpu_component_fallbacks)
    }

    pub fn requested_wgpu_component_hit_rate(&self) -> Option<f64> {
        let total = self.requested_wgpu_component_total();
        (total > 0).then(|| self.requested_wgpu_component_hits as f64 / total as f64)
    }

    pub fn requested_wgpu_component_fallback_rate(&self) -> Option<f64> {
        let total = self.requested_wgpu_component_total();
        (total > 0).then(|| self.requested_wgpu_component_fallbacks as f64 / total as f64)
    }

    fn accumulate_trace(&mut self, trace: &TensorBackendStepTrace) {
        self.ops_total = self.ops_total.saturating_add(trace.total);
        self.fallbacks = self.fallbacks.saturating_add(trace.fallbacks);
        self.requested_wgpu_hits = self
            .requested_wgpu_hits
            .saturating_add(trace.requested_wgpu_hits);
        self.requested_wgpu_runtime_fallbacks = self
            .requested_wgpu_runtime_fallbacks
            .saturating_add(trace.requested_wgpu_runtime_fallbacks);
        self.requested_wgpu_component_hits = self
            .requested_wgpu_component_hits
            .saturating_add(trace.requested_wgpu_component_hits);
        self.requested_wgpu_component_fallbacks = self
            .requested_wgpu_component_fallbacks
            .saturating_add(trace.requested_wgpu_component_fallbacks);
        self.meta_events = self.meta_events.saturating_add(trace.meta_events);
        self.meta_non_finite_sentinels = self.meta_non_finite_sentinels.saturating_add(
            trace
                .meta_null_values
                .saturating_add(trace.meta_non_finite_strings),
        );
        self.embedding_tokens = self.embedding_tokens.saturating_add(trace.embedding_tokens);
        self.embedding_unique_token_indices = self
            .embedding_unique_token_indices
            .saturating_add(trace.embedding_unique_token_indices);
        self.embedding_repeated_token_indices = self
            .embedding_repeated_token_indices
            .saturating_add(trace.embedding_repeated_token_indices);
        self.embedding_token_repairs = self.embedding_token_repairs.saturating_add(
            trace
                .embedding_non_finite_tokens
                .saturating_add(trace.embedding_rounded_tokens)
                .saturating_add(trace.embedding_clamped_low_tokens)
                .saturating_add(trace.embedding_clamped_high_tokens),
        );
        for (backend, count) in trace.by_backend.iter() {
            match backend.as_str() {
                "wgpu" => self.backend_wgpu = self.backend_wgpu.saturating_add(*count),
                "cuda" => self.backend_cuda = self.backend_cuda.saturating_add(*count),
                "hip" => self.backend_hip = self.backend_hip.saturating_add(*count),
                "cpu" => self.backend_cpu = self.backend_cpu.saturating_add(*count),
                "cpu_simd" => self.backend_cpu_simd = self.backend_cpu_simd.saturating_add(*count),
                "f64_cpu" => self.backend_f64_cpu = self.backend_f64_cpu.saturating_add(*count),
                "faer" => self.backend_faer = self.backend_faer.saturating_add(*count),
                "naive" => self.backend_naive = self.backend_naive.saturating_add(*count),
                _ => self.backend_other = self.backend_other.saturating_add(*count),
            }
        }
        for (backend, count) in trace.by_kernel_backend.iter() {
            match backend.as_str() {
                "wgpu_dense" => {
                    self.kernel_backend_wgpu_dense =
                        self.kernel_backend_wgpu_dense.saturating_add(*count)
                }
                "simd" => {
                    self.kernel_backend_simd = self.kernel_backend_simd.saturating_add(*count)
                }
                "wgpu" | "cuda" | "hip" | "cpu" | "cpu_simd" | "faer" | "naive" => {}
                _ => self.kernel_backend_other = self.kernel_backend_other.saturating_add(*count),
            }
        }
    }

    /// Writes this summary using the same metric vocabulary as trainer traces.
    pub fn write_extra(&self, extra: &mut HashMap<String, f64>) {
        extra.insert("epoch_tensor_ops_total".to_string(), self.ops_total as f64);
        extra.insert(
            "epoch_tensor_backend_fallbacks".to_string(),
            self.fallbacks as f64,
        );
        extra.insert(
            "epoch_tensor_backend_requested_wgpu_hits".to_string(),
            self.requested_wgpu_hits as f64,
        );
        extra.insert(
            "epoch_tensor_backend_requested_wgpu_runtime_fallbacks".to_string(),
            self.requested_wgpu_runtime_fallbacks as f64,
        );
        if let Some(hit_rate) = self.requested_wgpu_hit_rate() {
            extra.insert(
                "epoch_tensor_backend_requested_wgpu_hit_rate".to_string(),
                hit_rate,
            );
        }
        if let Some(fallback_rate) = self.requested_wgpu_runtime_fallback_rate() {
            extra.insert(
                "epoch_tensor_backend_requested_wgpu_runtime_fallback_rate".to_string(),
                fallback_rate,
            );
        }
        extra.insert(
            "epoch_tensor_backend_requested_wgpu_component_hits".to_string(),
            self.requested_wgpu_component_hits as f64,
        );
        extra.insert(
            "epoch_tensor_backend_requested_wgpu_component_fallbacks".to_string(),
            self.requested_wgpu_component_fallbacks as f64,
        );
        if let Some(hit_rate) = self.requested_wgpu_component_hit_rate() {
            extra.insert(
                "epoch_tensor_backend_requested_wgpu_component_hit_rate".to_string(),
                hit_rate,
            );
        }
        if let Some(fallback_rate) = self.requested_wgpu_component_fallback_rate() {
            extra.insert(
                "epoch_tensor_backend_requested_wgpu_component_fallback_rate".to_string(),
                fallback_rate,
            );
        }
        extra.insert(
            "epoch_tensor_meta_events".to_string(),
            self.meta_events as f64,
        );
        extra.insert(
            "epoch_tensor_meta_non_finite_sentinels".to_string(),
            self.meta_non_finite_sentinels as f64,
        );
        extra.insert(
            "epoch_tensor_backend_wgpu".to_string(),
            self.backend_wgpu as f64,
        );
        extra.insert(
            "epoch_tensor_backend_cuda".to_string(),
            self.backend_cuda as f64,
        );
        extra.insert(
            "epoch_tensor_backend_hip".to_string(),
            self.backend_hip as f64,
        );
        extra.insert(
            "epoch_tensor_backend_cpu".to_string(),
            self.backend_cpu as f64,
        );
        extra.insert(
            "epoch_tensor_backend_cpu_simd".to_string(),
            self.backend_cpu_simd as f64,
        );
        extra.insert(
            "epoch_tensor_backend_f64_cpu".to_string(),
            self.backend_f64_cpu as f64,
        );
        extra.insert(
            "epoch_tensor_backend_faer".to_string(),
            self.backend_faer as f64,
        );
        extra.insert(
            "epoch_tensor_backend_naive".to_string(),
            self.backend_naive as f64,
        );
        extra.insert(
            "epoch_tensor_backend_other".to_string(),
            self.backend_other as f64,
        );
        extra.insert(
            "epoch_tensor_kernel_backend_wgpu_dense".to_string(),
            self.kernel_backend_wgpu_dense as f64,
        );
        extra.insert(
            "epoch_tensor_kernel_backend_simd".to_string(),
            self.kernel_backend_simd as f64,
        );
        extra.insert(
            "epoch_tensor_kernel_backend_other".to_string(),
            self.kernel_backend_other as f64,
        );
        extra.insert(
            "epoch_tensor_embedding_tokens".to_string(),
            self.embedding_tokens as f64,
        );
        extra.insert(
            "epoch_tensor_embedding_unique_token_indices".to_string(),
            self.embedding_unique_token_indices as f64,
        );
        extra.insert(
            "epoch_tensor_embedding_repeated_token_indices".to_string(),
            self.embedding_repeated_token_indices as f64,
        );
        extra.insert(
            "epoch_tensor_embedding_token_repairs".to_string(),
            self.embedding_token_repairs as f64,
        );
    }
}

fn meta_usize(data: &Value, key: &str) -> usize {
    data.get(key)
        .and_then(|value| value.as_u64())
        .and_then(|value| usize::try_from(value).ok())
        .unwrap_or(0)
}

fn meta_f64(data: &Value, key: &str) -> Option<f64> {
    data.get(key)
        .and_then(|value| value.as_f64())
        .filter(|value| value.is_finite())
}

fn meta_str_fragment(data: &Value, key: &str) -> Option<String> {
    data.get(key)
        .and_then(|value| value.as_str())
        .map(metric_fragment)
}

fn insert_optional_extra(extra: &mut HashMap<String, f64>, key: &str, value: Option<f64>) {
    if let Some(value) = value.filter(|value| value.is_finite()) {
        extra.insert(key.to_string(), value);
    }
}

fn insert_tensor_shape_extra(
    extra: &mut HashMap<String, f64>,
    prefix: &str,
    shape: (usize, usize),
) {
    extra.insert(format!("{prefix}_rows"), shape.0 as f64);
    extra.insert(format!("{prefix}_cols"), shape.1 as f64);
    extra.insert(
        format!("{prefix}_values"),
        shape.0.saturating_mul(shape.1) as f64,
    );
}

#[derive(Debug, Default)]
struct ParameterValueSnapshot {
    params: usize,
    values: Vec<Vec<f32>>,
}

#[derive(Debug, Default)]
struct ParameterUpdateStats {
    params: usize,
    values: usize,
    before_l2_sq: f64,
    after_l2_sq: f64,
    delta_l1: f64,
    delta_l2_sq: f64,
    delta_linf: f64,
    non_finite_values: usize,
    active_params: usize,
    zero_update_params: usize,
    max_update_l2: f64,
    max_update_l2_index: Option<usize>,
    max_update_l2_values: usize,
    max_update_l2_ratio: f64,
    max_update_ratio_l2: f64,
    max_update_ratio_index: Option<usize>,
}

impl ParameterUpdateStats {
    fn write_extra(&self, extra: &mut HashMap<String, f64>) {
        let before_l2 = self.before_l2_sq.sqrt();
        let after_l2 = self.after_l2_sq.sqrt();
        let delta_l2 = self.delta_l2_sq.sqrt();
        let ratio = delta_l2 / before_l2.max(1.0e-12);
        extra.insert("optim_param_update_params".to_string(), self.params as f64);
        extra.insert("optim_param_update_values".to_string(), self.values as f64);
        extra.insert("optim_param_l2_before".to_string(), before_l2);
        extra.insert("optim_param_l2_after".to_string(), after_l2);
        extra.insert("optim_param_update_l1".to_string(), self.delta_l1);
        extra.insert("optim_param_update_l2".to_string(), delta_l2);
        extra.insert("optim_param_update_linf".to_string(), self.delta_linf);
        extra.insert("optim_param_update_ratio_l2".to_string(), ratio);
        extra.insert(
            "optim_param_update_active_params".to_string(),
            self.active_params as f64,
        );
        extra.insert(
            "optim_param_update_zero_params".to_string(),
            self.zero_update_params as f64,
        );
        extra.insert(
            "optim_param_update_zero_param_ratio".to_string(),
            if self.params == 0 {
                0.0
            } else {
                self.zero_update_params as f64 / self.params as f64
            },
        );
        extra.insert("optim_param_update_max_l2".to_string(), self.max_update_l2);
        extra.insert(
            "optim_param_update_max_l2_values".to_string(),
            self.max_update_l2_values as f64,
        );
        extra.insert(
            "optim_param_update_max_l2_ratio".to_string(),
            self.max_update_l2_ratio,
        );
        extra.insert(
            "optim_param_update_max_ratio_l2".to_string(),
            self.max_update_ratio_l2,
        );
        if let Some(index) = self.max_update_l2_index {
            extra.insert("optim_param_update_max_l2_index".to_string(), index as f64);
        }
        if let Some(index) = self.max_update_ratio_index {
            extra.insert(
                "optim_param_update_max_ratio_index".to_string(),
                index as f64,
            );
        }
        extra.insert(
            "optim_param_update_non_finite_values".to_string(),
            self.non_finite_values as f64,
        );
        if delta_l2 > 0.0 {
            extra.insert("optim_param_update_detected".to_string(), 1.0);
        }
        if self.non_finite_values > 0 {
            extra.insert("optim_param_update_non_finite_detected".to_string(), 1.0);
        }
    }
}

#[derive(Debug, Default)]
struct TensorValueHealth {
    total: usize,
    finite: usize,
    non_finite: usize,
    nan: usize,
    infinite: usize,
    finite_l1: f64,
    finite_l2_sq: f64,
    finite_linf: f32,
}

impl TensorValueHealth {
    fn from_tensor(tensor: &Tensor) -> Self {
        let mut health = Self::default();
        health.record_values(tensor.data());
        health
    }

    fn record_values(&mut self, values: &[f32]) {
        for &value in values {
            self.total = self.total.saturating_add(1);
            if value.is_finite() {
                let abs = value.abs();
                self.finite = self.finite.saturating_add(1);
                self.finite_l1 += abs as f64;
                self.finite_l2_sq += (value as f64) * (value as f64);
                self.finite_linf = self.finite_linf.max(abs);
            } else {
                self.non_finite = self.non_finite.saturating_add(1);
                if value.is_nan() {
                    self.nan = self.nan.saturating_add(1);
                } else if value.is_infinite() {
                    self.infinite = self.infinite.saturating_add(1);
                }
            }
        }
    }

    fn non_finite_ratio(&self) -> f64 {
        if self.total == 0 {
            0.0
        } else {
            self.non_finite as f64 / self.total as f64
        }
    }

    fn write_extra(&self, extra: &mut HashMap<String, f64>, prefix: &str) {
        if self.total == 0 {
            return;
        }
        extra.insert(format!("{prefix}_values_total"), self.total as f64);
        extra.insert(format!("{prefix}_finite_values"), self.finite as f64);
        extra.insert(
            format!("{prefix}_non_finite_values"),
            self.non_finite as f64,
        );
        extra.insert(
            format!("{prefix}_non_finite_ratio"),
            self.non_finite_ratio(),
        );
        extra.insert(format!("{prefix}_nan_values"), self.nan as f64);
        extra.insert(format!("{prefix}_infinite_values"), self.infinite as f64);
        extra.insert(format!("{prefix}_l1_finite"), self.finite_l1);
        extra.insert(format!("{prefix}_l2_finite"), self.finite_l2_sq.sqrt());
        extra.insert(format!("{prefix}_linf_finite"), self.finite_linf as f64);
        if self.non_finite > 0 {
            extra.insert(format!("{prefix}_non_finite_detected"), 1.0);
        }
    }
}

fn capture_parameter_value_snapshot<M: Module + ?Sized>(
    module: &M,
) -> PureResult<ParameterValueSnapshot> {
    let mut snapshot = ParameterValueSnapshot::default();
    module.visit_parameters(&mut |param| {
        snapshot.params = snapshot.params.saturating_add(1);
        snapshot.values.push(param.value().data().to_vec());
        Ok(())
    })?;
    Ok(snapshot)
}

fn collect_parameter_update_stats<M: Module + ?Sized>(
    module: &M,
    snapshot: &ParameterValueSnapshot,
) -> PureResult<ParameterUpdateStats> {
    let mut stats = ParameterUpdateStats::default();
    let mut index = 0usize;
    module.visit_parameters(&mut |param| {
        let Some(before) = snapshot.values.get(index) else {
            return Err(TensorError::ShapeMismatch {
                left: (snapshot.values.len(), 1),
                right: (index.saturating_add(1), 1),
            });
        };
        let after = param.value().data();
        if before.len() != after.len() {
            return Err(TensorError::ShapeMismatch {
                left: (before.len(), 1),
                right: (after.len(), 1),
            });
        }
        stats.params = stats.params.saturating_add(1);
        let param_index = index;
        let mut param_before_l2_sq = 0.0f64;
        let mut param_delta_l2_sq = 0.0f64;
        for (&before_value, &after_value) in before.iter().zip(after.iter()) {
            stats.values = stats.values.saturating_add(1);
            if before_value.is_finite() {
                let value = before_value as f64;
                stats.before_l2_sq += value * value;
                param_before_l2_sq += value * value;
            } else {
                stats.non_finite_values = stats.non_finite_values.saturating_add(1);
            }
            if after_value.is_finite() {
                let value = after_value as f64;
                stats.after_l2_sq += value * value;
            } else {
                stats.non_finite_values = stats.non_finite_values.saturating_add(1);
            }
            let delta = after_value - before_value;
            if delta.is_finite() {
                let value = delta as f64;
                stats.delta_l1 += value.abs();
                stats.delta_l2_sq += value * value;
                param_delta_l2_sq += value * value;
                stats.delta_linf = stats.delta_linf.max(value.abs());
            } else {
                stats.non_finite_values = stats.non_finite_values.saturating_add(1);
            }
        }
        let param_update_l2 = param_delta_l2_sq.sqrt();
        let param_update_ratio_l2 = param_update_l2 / param_before_l2_sq.sqrt().max(1.0e-12);
        if param_update_l2 > 0.0 {
            stats.active_params = stats.active_params.saturating_add(1);
        } else {
            stats.zero_update_params = stats.zero_update_params.saturating_add(1);
        }
        if stats
            .max_update_l2_index
            .map(|_| param_update_l2 > stats.max_update_l2)
            .unwrap_or(true)
        {
            stats.max_update_l2 = param_update_l2;
            stats.max_update_l2_index = Some(param_index);
            stats.max_update_l2_values = after.len();
            stats.max_update_l2_ratio = param_update_ratio_l2;
        }
        if stats
            .max_update_ratio_index
            .map(|_| param_update_ratio_l2 > stats.max_update_ratio_l2)
            .unwrap_or(true)
        {
            stats.max_update_ratio_l2 = param_update_ratio_l2;
            stats.max_update_ratio_index = Some(param_index);
        }
        index = index.saturating_add(1);
        Ok(())
    })?;
    if index != snapshot.params {
        return Err(TensorError::ShapeMismatch {
            left: (snapshot.params, 1),
            right: (index, 1),
        });
    }
    Ok(stats)
}

#[derive(Debug, Default)]
struct TensorMetaHealth {
    null_values: usize,
    non_finite_strings: usize,
}

impl TensorMetaHealth {
    fn record(&mut self, value: &Value) {
        match value {
            Value::Null => {
                self.null_values = self.null_values.saturating_add(1);
            }
            Value::Bool(_) | Value::Number(_) => {}
            Value::String(text) => {
                if is_non_finite_sentinel(text) {
                    self.non_finite_strings = self.non_finite_strings.saturating_add(1);
                }
            }
            Value::Array(values) => {
                for value in values {
                    self.record(value);
                }
            }
            Value::Object(values) => {
                for value in values.values() {
                    self.record(value);
                }
            }
        }
    }
}

fn is_non_finite_sentinel(text: &str) -> bool {
    let trimmed = text.trim();
    matches!(
        trimmed.to_ascii_lowercase().as_str(),
        "nan" | "+nan" | "-nan" | "inf" | "+inf" | "-inf" | "infinity" | "+infinity" | "-infinity"
    )
}

fn validate_trainer_scalar(label: &'static str, value: f32) -> PureResult<f32> {
    if !value.is_finite() {
        return Err(TensorError::NonFiniteValue { label, value });
    }
    Ok(value)
}

fn validate_trainer_slice(label: &'static str, values: &[f32]) -> PureResult<()> {
    for value in values.iter().copied() {
        validate_trainer_scalar(label, value)?;
    }
    Ok(())
}

fn validate_trainer_tensor(label: &'static str, tensor: &Tensor) -> PureResult<()> {
    validate_trainer_slice(label, tensor.data())
}

fn trainer_tensor_sum(label: &'static str, tensor: &Tensor) -> PureResult<f32> {
    validate_trainer_tensor(label, tensor)?;
    let sum = tensor
        .data()
        .iter()
        .fold(0.0f64, |acc, value| acc + f64::from(*value));
    if !sum.is_finite() || sum.abs() > f64::from(f32::MAX) {
        let value = if sum.is_sign_negative() {
            f32::NEG_INFINITY
        } else {
            f32::INFINITY
        };
        return Err(TensorError::NonFiniteValue { label, value });
    }
    Ok(sum as f32)
}

fn validate_band_energy_for_trainer(energy: &BandEnergy) -> PureResult<()> {
    validate_trainer_scalar("trainer_band_energy_above", energy.above)?;
    validate_trainer_scalar("trainer_band_energy_here", energy.here)?;
    validate_trainer_scalar("trainer_band_energy_beneath", energy.beneath)?;
    validate_trainer_scalar("trainer_band_energy_drift", energy.drift)?;
    validate_trainer_scalar(
        "trainer_band_spectral_sheet_confidence",
        energy.spectral.sheet_confidence,
    )?;
    validate_trainer_scalar("trainer_band_spectral_curvature", energy.spectral.curvature)?;
    validate_trainer_scalar("trainer_band_spectral_spin", energy.spectral.spin)?;
    validate_trainer_scalar("trainer_band_spectral_energy", energy.spectral.energy)?;
    Ok(())
}

fn validate_band_weights_for_trainer(weights: (f32, f32, f32)) -> PureResult<()> {
    validate_trainer_scalar("trainer_band_weight_above", weights.0)?;
    validate_trainer_scalar("trainer_band_weight_here", weights.1)?;
    validate_trainer_scalar("trainer_band_weight_beneath", weights.2)?;
    Ok(())
}

#[derive(Debug, Default)]
struct GradientHealth {
    total: usize,
    finite: usize,
    non_finite: usize,
    nan: usize,
    infinite: usize,
    finite_l1: f64,
    finite_l2_sq: f64,
    finite_linf: f32,
    first_non_finite: Option<f32>,
}

impl GradientHealth {
    fn record_values(&mut self, values: &[f32]) {
        for &value in values {
            self.total = self.total.saturating_add(1);
            if value.is_finite() {
                let abs = value.abs();
                self.finite = self.finite.saturating_add(1);
                self.finite_l1 += abs as f64;
                self.finite_l2_sq += (value as f64) * (value as f64);
                self.finite_linf = self.finite_linf.max(abs);
            } else {
                self.non_finite = self.non_finite.saturating_add(1);
                if self.first_non_finite.is_none() {
                    self.first_non_finite = Some(value);
                }
                if value.is_nan() {
                    self.nan = self.nan.saturating_add(1);
                } else if value.is_infinite() {
                    self.infinite = self.infinite.saturating_add(1);
                }
            }
        }
    }

    fn non_finite_ratio(&self) -> f64 {
        if self.total == 0 {
            0.0
        } else {
            self.non_finite as f64 / self.total as f64
        }
    }

    fn write_extra(&self, extra: &mut HashMap<String, f64>) {
        if self.total == 0 {
            return;
        }
        extra.insert("grad_values_total".to_string(), self.total as f64);
        extra.insert("grad_values_finite".to_string(), self.finite as f64);
        extra.insert("grad_values_non_finite".to_string(), self.non_finite as f64);
        extra.insert(
            "grad_values_non_finite_ratio".to_string(),
            self.non_finite_ratio(),
        );
        extra.insert("grad_values_nan".to_string(), self.nan as f64);
        extra.insert("grad_values_infinite".to_string(), self.infinite as f64);
        extra.insert("grad_l1_finite".to_string(), self.finite_l1);
        extra.insert("grad_l2_finite".to_string(), self.finite_l2_sq.sqrt());
        extra.insert("grad_linf_finite".to_string(), self.finite_linf as f64);
        if self.non_finite > 0 {
            extra.insert("grad_non_finite_detected".to_string(), 1.0);
        }
    }

    fn ensure_finite(&self, label: &'static str) -> PureResult<()> {
        if let Some(value) = self.first_non_finite {
            return Err(TensorError::NonFiniteValue { label, value });
        }
        Ok(())
    }
}

fn write_backend_policy_extra(policy: BackendPolicy, extra: &mut HashMap<String, f64>) {
    extra.insert(
        "tensor_policy_runtime_plan_committed".to_string(),
        if policy.runtime_plan_output_sha256().is_some() {
            1.0
        } else {
            0.0
        },
    );
    extra.insert(
        format!(
            "tensor_policy_device_{}",
            metric_fragment(policy.device_backend_label())
        ),
        1.0,
    );
    extra.insert(
        format!(
            "tensor_policy_matmul_{}",
            metric_fragment(policy.matmul_backend_label())
        ),
        1.0,
    );
    extra.insert(
        format!(
            "tensor_policy_prepacked_matmul_{}",
            metric_fragment(policy.prepacked_matmul_backend_label())
        ),
        1.0,
    );
    extra.insert(
        format!(
            "tensor_policy_layer_norm_{}",
            metric_fragment(policy.layer_norm_backend_label())
        ),
        1.0,
    );
    extra.insert(
        format!(
            "tensor_policy_attention_{}",
            metric_fragment(policy.attention_backend_label())
        ),
        1.0,
    );
    extra.insert(
        format!(
            "tensor_policy_softmax_{}",
            metric_fragment(policy.softmax_backend_label())
        ),
        1.0,
    );
}

fn write_coherence_signal_extra(
    signal: Option<&CoherenceSignal>,
    extra: &mut HashMap<String, f64>,
) {
    let Some(signal) = signal else {
        return;
    };
    extra.insert(
        "coherence_repaired_non_finite_weights".to_string(),
        signal.repaired_non_finite_weights() as f64,
    );
    extra.insert(
        "coherence_repaired_negative_weights".to_string(),
        signal.repaired_negative_weights() as f64,
    );
    extra.insert(
        "coherence_repaired_weights_total".to_string(),
        signal.repaired_weights_total() as f64,
    );
    extra.insert(
        "coherence_pre_discard_repaired_non_finite".to_string(),
        signal.pre_discard_repaired_non_finite() as f64,
    );
    extra.insert(
        "coherence_pre_discard_repaired_negative".to_string(),
        signal.pre_discard_repaired_negative() as f64,
    );
    extra.insert(
        "coherence_pre_discard_repairs_total".to_string(),
        signal.pre_discard_repairs_total() as f64,
    );
    extra.insert("coherence_control_ready".to_string(), 1.0);
    extra.insert(
        "coherence_raw_mean".to_string(),
        signal.mean_coherence() as f64,
    );
    extra.insert(
        "coherence_raw_entropy".to_string(),
        signal.coherence_entropy() as f64,
    );
    extra.insert(
        "coherence_normalized_entropy".to_string(),
        signal.normalized_entropy() as f64,
    );
    extra.insert(
        "coherence_concentration".to_string(),
        signal.concentration() as f64,
    );
    extra.insert(
        "coherence_spectral_pressure".to_string(),
        signal.spectral_pressure() as f64,
    );
    extra.insert(
        "coherence_effective_channels".to_string(),
        signal.effective_channels() as f64,
    );
    extra.insert(
        "coherence_distribution_channels".to_string(),
        signal.distribution_channels() as f64,
    );
    extra.insert(
        "coherence_preserved_channels".to_string(),
        signal.preserved_channels() as f64,
    );
    extra.insert("coherence_control_contract_v1".to_string(), 1.0);
    extra.insert("coherence_control_backend_rust".to_string(), 1.0);
    extra.insert(
        "coherence_repairs_total".to_string(),
        signal.repairs_total() as f64,
    );
    if signal.repairs_total() > 0 {
        extra.insert("coherence_repaired_detected".to_string(), 1.0);
    }
}

struct TensorOpMetaStepCollector {
    trace: Arc<Mutex<TensorBackendStepTrace>>,
    previous: Option<TensorOpMetaObserver>,
}

impl TensorOpMetaStepCollector {
    fn install() -> Self {
        let trace = Arc::new(Mutex::new(TensorBackendStepTrace::default()));
        let trace_capture = Arc::clone(&trace);
        let previous_slot: Arc<Mutex<Option<TensorOpMetaObserver>>> = Arc::new(Mutex::new(None));
        let previous_capture = Arc::clone(&previous_slot);
        let observer: TensorOpMetaObserver = Arc::new(move |event: &TensorOpMetaEvent| {
            trace_capture
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner())
                .record(event);
            let previous = previous_capture
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner())
                .clone();
            if let Some(previous) = previous {
                previous(event);
            }
        });
        let previous = set_thread_meta_observer(Some(observer));
        *previous_slot
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner()) = previous.clone();
        Self { trace, previous }
    }

    fn clear(&self) {
        *self
            .trace
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner()) = TensorBackendStepTrace::default();
    }

    fn drain(&self) -> TensorBackendStepTrace {
        std::mem::take(
            &mut *self
                .trace
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner()),
        )
    }
}

impl Drop for TensorOpMetaStepCollector {
    fn drop(&mut self) {
        set_thread_meta_observer(self.previous.take());
    }
}

fn metric_fragment(label: &str) -> String {
    let mut out = String::with_capacity(label.len());
    let mut last_underscore = false;
    for ch in label.chars() {
        if ch.is_ascii_alphanumeric() {
            out.push(ch.to_ascii_lowercase());
            last_underscore = false;
        } else if !last_underscore {
            out.push('_');
            last_underscore = true;
        }
    }
    while out.ends_with('_') {
        out.pop();
    }
    if out.is_empty() {
        "unknown".to_string()
    } else {
        out
    }
}

fn backend_metric_fragment(label: &str) -> String {
    let fragment = metric_fragment(label);
    match fragment.as_str() {
        "wgpu_dense" => "wgpu".to_string(),
        "simd" => "cpu_simd".to_string(),
        _ => fragment,
    }
}

fn is_metadata_only_backend(label: &str) -> bool {
    matches!(
        label,
        "composite" | "hybrid" | "view" | "semantic_bridge_window_distribution"
    )
}

fn is_cpu_runtime_backend(label: &str) -> bool {
    matches!(
        label,
        "cpu"
            | "cpu_eigen"
            | "cpu_simd"
            | "f64_cpu"
            | "faer"
            | "naive"
            | "probability_cpu"
            | "semantic_cpu"
            | "topos_cpu"
    )
}

fn is_wgpu_runtime_fallback(data: &Value) -> bool {
    let Some(fallback) = data.get("fallback") else {
        return false;
    };
    if fallback.get("from").and_then(Value::as_str) != Some("wgpu") {
        return false;
    }
    if fallback.get("reason").and_then(Value::as_str) == Some("runtime_unavailable") {
        return true;
    }
    let Some(message) = fallback.get("message").and_then(Value::as_str) else {
        return false;
    };
    message.contains("no suitable WGPU adapter")
        || message.contains("failed to initialize WGPU")
        || message.contains("WGPU backend not available")
}

fn strict_expected_tensor_backend(
    caps: DeviceCaps,
    accelerator_fallback: AcceleratorFallback,
) -> Option<BackendKind> {
    if !accelerator_fallback.is_strict() {
        return None;
    }
    match caps.backend {
        BackendKind::Wgpu | BackendKind::Cuda | BackendKind::Hip => Some(caps.backend),
        BackendKind::Mps | BackendKind::Cpu => None,
    }
}

/// High-level orchestrator that keeps hypergrad, SpiralK, and module updates aligned.
pub struct ModuleTrainer {
    epoch: usize,
    execution_context: RuntimeExecutionContext,
    curvature: f32,
    hyper_learning_rate: f32,
    fallback_learning_rate: f32,
    meta_learning_rate_scale: f32,
    meta_optimizer_step: Option<u64>,
    grad_clip_max_norm: Option<f32>,
    real_learning_rate: Option<f32>,
    blackcat: Option<BlackCatRuntime>,
    blackcat_moderator: Option<BlackcatModerator>,
    autopilot: Option<Autopilot>,
    band_weight_fn: Option<BandWeightFn>,
    text_infusion: Option<TextInfusionConfig>,
    injector_enabled: bool,
    distribution: Option<RoundtableNode>,
    meta_conductor: Option<MetaConductor>,
    heur_log: HeurOpLog,
    rewrite_budget: Option<RewriteBudget>,
    softlogic: SoftLogicFlex,
    spectral_adapter: SpectralLrAdapter,
    accumulator_synchronizer: Option<Arc<dyn AccumulatorSynchronizer>>,
    last_accumulator_sync: TrainerAccumulatorSyncStats,
    cumulative_backend_counters: TrainerBackendCounters,
    desire_bridge: Option<DesireTrainerBridge>,
    desire_roundtable_bridge: Option<DesireRoundtableBridge>,
    last_desire_roundtable_summary: Option<DesireRoundtableSummary>,
    #[cfg(feature = "psi")]
    desire_psi_bridge: Option<DesirePsiBridge>,
    graph_bridge: Option<GraphConsensusBridge>,
    graph_pending: Option<GraphConsensusDigest>,
    graph_last_hint: Option<String>,
    gnn_roundtable_bridge: Option<RoundtableGnnBridge>,
    gnn_last_roundtable_signal: Option<RoundtableBandSignal>,
    curvature_scheduler: Option<CurvatureScheduler>,
    last_curvature_metrics: Option<CurvatureMetrics>,
    loss_strategy: LossStrategy,
    spectral_policy: Option<SpectralLearningRatePolicy>,
    coherence_bridge: Option<ZSpaceTraceCoherenceBridge>,
    pending_coherence: Option<CoherenceSignal>,
    last_spectral_metrics: Option<SpectralAdjustmentMetrics>,
    last_band_energy: Option<BandEnergy>,
    phase_turnover_spike_threshold: f32,
    phase_loss_ema_alpha: f32,
    phase_loss_spike_ratio: f32,
    phase_drift_spike_threshold: f32,
    phase_last_label: Option<CoherenceLabel>,
    phase_last_turnover: Option<f32>,
    phase_last_band: Option<u8>,
    phase_last_drift_abs: Option<f32>,
    phase_loss_ema: Option<f32>,
    phase_loss_spiking: bool,
    #[cfg(feature = "golden")]
    golden_pulse: Option<GoldenBlackcatPulse>,
    #[cfg(feature = "golden")]
    golden_directive: Option<GoldenCooperativeDirective>,
    #[cfg(feature = "golden")]
    golden_council: Option<GoldenCouncilSnapshot>,
    #[cfg(feature = "psi")]
    psi: Option<PsiMeter>,
    #[cfg(feature = "psychoid")]
    psychoid: Option<PsychoidMeter>,
    #[cfg(feature = "psychoid")]
    psychoid_log: bool,
    #[cfg(feature = "collapse")]
    collapse: Option<CollapseDrive>,
}

impl core::fmt::Debug for ModuleTrainer {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        write!(
            f,
            "ModuleTrainer(curv={},lr_h={},lr_f={},lr_r={:?},meta_scale={},meta_step={:?})",
            self.curvature,
            self.hyper_learning_rate,
            self.fallback_learning_rate,
            self.real_learning_rate,
            self.meta_learning_rate_scale,
            self.meta_optimizer_step,
        )
    }
}

/// Copyable optimizer-facing trainer state for traces and future checkpoints.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TrainerOptimizerState {
    pub epoch: usize,
    pub curvature: f32,
    pub hyper_learning_rate: f32,
    pub fallback_learning_rate: f32,
    pub real_learning_rate: Option<f32>,
    pub meta_learning_rate_scale: f32,
    pub meta_optimizer_step: Option<u64>,
    pub grad_clip_max_norm: Option<f32>,
    pub spectral_policy_enabled: bool,
    pub curvature_scheduler_enabled: bool,
    pub training_device_enabled: bool,
    pub training_rank: usize,
    pub training_world_size: usize,
    pub spectral_adapter: SpectralLrAdapterState,
    pub backend_counters: TrainerBackendCounters,
}

#[derive(Debug, Error)]
pub enum TrainerCheckpointError {
    #[error(transparent)]
    Runtime(#[from] TrainerRuntimeCheckpointError),
    #[error(transparent)]
    Contract(#[from] TrainerOptimizerCheckpointError),
    #[error(transparent)]
    Tensor(#[from] TensorError),
    #[error(transparent)]
    External(#[from] TrainerExternalCheckpointError),
    #[error(transparent)]
    Accumulator(#[from] AccumulatorSyncError),
    #[error("checkpoint execution topology does not match the configured trainer")]
    TopologyMismatch,
    #[error("checkpoint parameter set does not match the target module: {message}")]
    ParameterSetMismatch { message: String },
    #[error("checkpoint external component set does not match the configured trainer")]
    ExternalComponentSetMismatch,
    #[error("checkpoint epoch {epoch} does not fit this platform")]
    EpochOutOfRange { epoch: u64 },
    #[error("checkpoint counter {field}={value} does not fit this platform")]
    CounterOutOfRange { field: &'static str, value: u64 },
    #[error(
        "runtime checkpoint is not ready: unresolved components [{unresolved}], missing resource reattachments [{missing_reattachments}]"
    )]
    RuntimeCheckpointNotReady {
        unresolved: String,
        missing_reattachments: String,
    },
}

struct PreparedTrainerExternalRestore {
    validation: TrainerExternalCheckpointValidation,
    desire_trainer: Option<PreparedDesireTrainerQueue>,
    desire_roundtable: Option<PreparedDesireRoundtableCheckpoint>,
    coherence_bridge: Option<PreparedTrainerCoherenceBridgeCheckpoint>,
    gnn_roundtable_bridge: Option<PreparedTrainerGnnRoundtableBridgeCheckpoint>,
    #[cfg(feature = "psi")]
    psi_meter: Option<PsiMeter>,
    reattached_components: Vec<String>,
}

struct PreparedTrainerGnnRoundtableBridgeCheckpoint {
    state: RoundtableGnnBridgeState,
    trainer_last: Option<RoundtableBandSignal>,
}

impl PreparedTrainerGnnRoundtableBridgeCheckpoint {
    fn prepare(
        checkpoint: &TrainerGnnRoundtableBridgeCheckpoint,
    ) -> Result<Self, TrainerExternalCheckpointError> {
        checkpoint.validate()?;
        let history_limit = usize::try_from(checkpoint.history_limit).map_err(|_| {
            TrainerExternalCheckpointError::InvalidState {
                field: "gnn_roundtable_bridge.history_limit".to_owned(),
                message: "does not fit this platform".to_owned(),
            }
        })?;
        let history = checkpoint
            .history
            .iter()
            .enumerate()
            .map(|(index, signal)| {
                gnn_roundtable_signal_from_checkpoint(
                    signal,
                    &format!("gnn_roundtable_bridge.history[{index}]"),
                )
            })
            .collect::<Result<Vec<_>, _>>()?;
        let latest = checkpoint
            .latest
            .as_ref()
            .map(|signal| {
                gnn_roundtable_signal_from_checkpoint(signal, "gnn_roundtable_bridge.latest")
            })
            .transpose()?;
        let trainer_last = checkpoint
            .trainer_last
            .as_ref()
            .map(|signal| {
                gnn_roundtable_signal_from_checkpoint(signal, "gnn_roundtable_bridge.trainer_last")
            })
            .transpose()?;
        Ok(Self {
            state: RoundtableGnnBridgeState {
                latest,
                history,
                history_limit,
            },
            trainer_last,
        })
    }
}

struct PreparedTrainerCoherenceBridgeCheckpoint {
    subscribed: bool,
    pending: Option<CoherenceSignal>,
    latest: Option<CoherenceSignal>,
}

impl PreparedTrainerCoherenceBridgeCheckpoint {
    fn prepare(
        checkpoint: &TrainerCoherenceBridgeCheckpoint,
    ) -> Result<Self, TrainerExternalCheckpointError> {
        checkpoint.validate()?;
        Ok(Self {
            subscribed: checkpoint.subscribed,
            pending: checkpoint
                .pending
                .as_ref()
                .map(CoherenceSignal::from_checkpoint)
                .transpose()?,
            latest: checkpoint
                .latest
                .as_ref()
                .map(CoherenceSignal::from_checkpoint)
                .transpose()?,
        })
    }
}

fn gnn_roundtable_signal_checkpoint(
    signal: &RoundtableBandSignal,
    field: &str,
) -> Result<TrainerGnnRoundtableSignalCheckpoint, TrainerExternalCheckpointError> {
    let observation =
        signal
            .observation()
            .map_err(|error| TrainerExternalCheckpointError::InvalidState {
                field: format!("{field}.observation"),
                message: error.to_string(),
            })?;
    let issued_at = signal.issued_at_checkpoint();
    issued_at.validate(&format!("{field}.issued_at"))?;
    let checkpoint = TrainerGnnRoundtableSignalCheckpoint {
        observation,
        issued_at,
    };
    checkpoint.canonical_influence()?;
    Ok(checkpoint)
}

fn gnn_roundtable_signal_from_checkpoint(
    checkpoint: &TrainerGnnRoundtableSignalCheckpoint,
    field: &str,
) -> Result<RoundtableBandSignal, TrainerExternalCheckpointError> {
    checkpoint.canonical_influence()?;
    let timestamp_field = format!("{field}.issued_at");
    checkpoint.issued_at.validate(&timestamp_field)?;
    checkpoint.issued_at.try_to_system_time(&timestamp_field)?;
    RoundtableBandSignal::from_observation_checkpoint(checkpoint.observation, checkpoint.issued_at)
        .map_err(|error| TrainerExternalCheckpointError::InvalidState {
            field: format!("{field}.observation"),
            message: error.to_string(),
        })
}

struct PreparedTrainerOptimizerRestore {
    validation: TrainerOptimizerCheckpointValidation,
    config: TrainerOptimizerConfig,
    topology: TrainerExecutionTopology,
    state: TrainerOptimizerRuntimeState,
    epoch: usize,
    sync_buffers: usize,
    sync_values: usize,
    spectral_adapter: SpectralLrAdapter,
    curvature_scheduler: Option<CurvatureScheduler>,
    spectral_policy: Option<SpectralLearningRatePolicy>,
    softlogic: SoftLogicFlex,
    parameters: HashMap<String, PreparedParameterOptimizerState>,
}

impl TrainerOptimizerState {
    fn write_extra(&self, extra: &mut HashMap<String, f64>) {
        extra.insert("optim_state_epoch".to_string(), self.epoch as f64);
        extra.insert("optim_state_curvature".to_string(), self.curvature as f64);
        extra.insert(
            "optim_state_hyper_lr".to_string(),
            self.hyper_learning_rate as f64,
        );
        extra.insert(
            "optim_state_fallback_lr".to_string(),
            self.fallback_learning_rate as f64,
        );
        extra.insert(
            "optim_state_meta_lr_scale".to_string(),
            self.meta_learning_rate_scale as f64,
        );
        if let Some(step) = self.meta_optimizer_step {
            extra.insert("optim_state_meta_step".to_string(), step as f64);
        }
        extra.insert(
            "optim_state_realgrad_enabled".to_string(),
            if self.real_learning_rate.is_some() {
                1.0
            } else {
                0.0
            },
        );
        if let Some(rate) = self.real_learning_rate {
            extra.insert("optim_state_real_lr".to_string(), rate as f64);
        }
        extra.insert(
            "optim_state_grad_clip_enabled".to_string(),
            if self.grad_clip_max_norm.is_some() {
                1.0
            } else {
                0.0
            },
        );
        if let Some(limit) = self.grad_clip_max_norm {
            extra.insert("optim_state_grad_clip_max_norm".to_string(), limit as f64);
        }
        extra.insert(
            "optim_state_spectral_policy_enabled".to_string(),
            if self.spectral_policy_enabled {
                1.0
            } else {
                0.0
            },
        );
        extra.insert(
            "optim_state_curvature_scheduler_enabled".to_string(),
            if self.curvature_scheduler_enabled {
                1.0
            } else {
                0.0
            },
        );
        extra.insert(
            "optim_state_training_device_enabled".to_string(),
            if self.training_device_enabled {
                1.0
            } else {
                0.0
            },
        );
        extra.insert(
            "optim_state_training_rank".to_string(),
            self.training_rank as f64,
        );
        extra.insert(
            "optim_state_training_world_size".to_string(),
            self.training_world_size as f64,
        );
        extra.insert(
            "optim_state_adapter_sheet_hint".to_string(),
            self.spectral_adapter.sheet_hint as f64,
        );
        extra.insert(
            "optim_state_adapter_curvature_target".to_string(),
            self.spectral_adapter.curvature_target as f64,
        );
        extra.insert(
            "optim_state_adapter_avg_curvature".to_string(),
            self.spectral_adapter.avg_curvature as f64,
        );
        extra.insert(
            "optim_state_adapter_avg_spin".to_string(),
            self.spectral_adapter.avg_spin as f64,
        );
        extra.insert(
            "optim_state_adapter_avg_energy".to_string(),
            self.spectral_adapter.avg_energy as f64,
        );
        extra.insert(
            "optim_state_adapter_min_scale".to_string(),
            self.spectral_adapter.min_scale as f64,
        );
        extra.insert(
            "optim_state_adapter_max_scale".to_string(),
            self.spectral_adapter.max_scale as f64,
        );
        extra.insert(
            "optim_state_backend_epochs".to_string(),
            self.backend_counters.epochs_recorded as f64,
        );
        extra.insert(
            "optim_state_backend_ops".to_string(),
            self.backend_counters.ops_total as f64,
        );
        extra.insert(
            "optim_state_backend_fallbacks".to_string(),
            self.backend_counters.fallbacks as f64,
        );
        extra.insert(
            "optim_state_wgpu_runtime_fallbacks".to_string(),
            self.backend_counters.requested_wgpu_runtime_fallbacks as f64,
        );
    }
}

/// Summary of the most recent accumulator synchronization pass.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct TrainerAccumulatorSyncStats {
    pub enabled: bool,
    pub rank: usize,
    pub world_size: usize,
    pub buffers: usize,
    pub values: usize,
}

impl TrainerAccumulatorSyncStats {
    fn disabled() -> Self {
        Self {
            enabled: false,
            rank: 0,
            world_size: 1,
            buffers: 0,
            values: 0,
        }
    }

    fn write_extra(&self, extra: &mut HashMap<String, f64>) {
        extra.insert(
            "optim_accumulator_sync_enabled".to_string(),
            if self.enabled { 1.0 } else { 0.0 },
        );
        extra.insert("optim_accumulator_sync_rank".to_string(), self.rank as f64);
        extra.insert(
            "optim_accumulator_sync_world_size".to_string(),
            self.world_size as f64,
        );
        extra.insert(
            "optim_accumulator_sync_buffers".to_string(),
            self.buffers as f64,
        );
        extra.insert(
            "optim_accumulator_sync_values".to_string(),
            self.values as f64,
        );
    }
}

/// Function pointer used to convert band energy into Above/Here/Beneath weights.
pub type BandWeightFn = fn(BandEnergy) -> (f32, f32, f32);

/// Controls how often the trainer injects [`Module::infuse_text`] calls.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TextInfusionEvery {
    /// Infuse once at the start of the first epoch only.
    Once,
    /// Infuse once at the start of each epoch (after clearing accumulators).
    Epoch,
    /// Infuse before every optimisation step (each batch).
    Batch,
}

/// Controls whether infused text is blended into the loss update or applied as a
/// separate optimiser step.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TextInfusionMode {
    /// Add infused gradients to the current loss update before stepping.
    Blend,
    /// Apply infused gradients in a dedicated optimiser step.
    Separate,
}

#[derive(Clone, Debug)]
struct TextInfusionConfig {
    text: String,
    every: TextInfusionEvery,
    mode: TextInfusionMode,
}

fn append_cloud_targets(metadata: &mut HashMap<String, String>, targets: &[CloudConnector]) {
    CloudTargetSummary::from_targets(targets).extend_map(metadata);
}

/// Configures how regional Z-space weights influence the aggregated loss.
#[derive(Clone, Debug)]
pub struct RegionLossWeights {
    default: f32,
    overrides: HashMap<ZSpaceRegionKey, f32>,
}

impl RegionLossWeights {
    /// Creates a weight table with the provided default multiplier.
    pub fn new(default: f32) -> Self {
        Self {
            default: default.max(0.0),
            overrides: HashMap::new(),
        }
    }

    /// Inserts or replaces the multiplier for the supplied region key.
    pub fn with_override(mut self, key: ZSpaceRegionKey, weight: f32) -> Self {
        self.set_override(key, weight);
        self
    }

    /// Updates the multiplier for the supplied region key.
    pub fn set_override(&mut self, key: ZSpaceRegionKey, weight: f32) {
        self.overrides.insert(key, weight.max(0.0));
    }

    /// Looks up the multiplier for the given key.
    pub fn weight_for(&self, key: ZSpaceRegionKey) -> f32 {
        self.overrides
            .get(&key)
            .copied()
            .unwrap_or(self.default)
            .max(0.0)
    }

    /// Returns the default multiplier applied when no overrides match.
    pub fn default(&self) -> f32 {
        self.default
    }
}

impl Default for RegionLossWeights {
    fn default() -> Self {
        Self::new(1.0)
    }
}

/// Optional thresholds controlling when region weights apply.
#[derive(Clone, Debug, Default)]
pub struct RegionLossCondition {
    min_spin_magnitude: Option<f32>,
    min_radius: Option<f32>,
}

impl RegionLossCondition {
    /// Requires the absolute spin alignment to exceed the provided threshold.
    pub fn with_min_spin_magnitude(mut self, threshold: f32) -> Self {
        if threshold > 0.0 {
            self.min_spin_magnitude = Some(threshold.min(1.0));
        }
        self
    }

    /// Requires the normalised radius to exceed the provided threshold.
    pub fn with_min_radius(mut self, threshold: f32) -> Self {
        if threshold > 0.0 {
            self.min_radius = Some(threshold.clamp(0.0, 1.0));
        }
        self
    }

    fn satisfied(&self, descriptor: &ZSpaceRegionDescriptor) -> bool {
        if let Some(threshold) = self.min_spin_magnitude {
            if descriptor.spin_alignment.abs() < threshold {
                return false;
            }
        }
        if let Some(threshold) = self.min_radius {
            if descriptor.normalized_radius < threshold {
                return false;
            }
        }
        true
    }

    /// Returns the minimum spin magnitude threshold, if configured.
    pub fn min_spin_magnitude(&self) -> Option<f32> {
        self.min_spin_magnitude
    }

    /// Returns the minimum radius threshold, if configured.
    pub fn min_radius(&self) -> Option<f32> {
        self.min_radius
    }
}

/// Adaptive policy that adjusts regional multipliers based on observed losses.
#[derive(Clone, Debug)]
pub struct AdaptiveRegionWeighting {
    learning_rate: f32,
    min_samples: u32,
    min_multiplier: f32,
    max_multiplier: f32,
    epsilon: f32,
    global_loss: Option<f32>,
    entries: HashMap<ZSpaceRegionKey, AdaptiveRegionEntry>,
}

impl AdaptiveRegionWeighting {
    /// Builds a policy with sensible defaults for smoothing and bounds.
    pub fn new() -> Self {
        Self {
            learning_rate: 0.1,
            min_samples: 4,
            min_multiplier: 0.25,
            max_multiplier: 4.0,
            epsilon: 1e-4,
            global_loss: None,
            entries: HashMap::new(),
        }
    }

    /// Sets the learning rate used for EMA updates.
    pub fn with_learning_rate(mut self, rate: f32) -> Self {
        if rate.is_finite() && rate > 0.0 {
            self.learning_rate = rate.clamp(0.01, 1.0);
        }
        self
    }

    /// Sets the minimum sample count required before adaptation kicks in.
    pub fn with_min_samples(mut self, samples: u32) -> Self {
        if samples > 0 {
            self.min_samples = samples;
        }
        self
    }

    /// Sets the allowed multiplier bounds.
    pub fn with_bounds(mut self, min: f32, max: f32) -> Self {
        if min.is_finite() && max.is_finite() && min > 0.0 && max >= min {
            self.min_multiplier = min;
            self.max_multiplier = max;
        }
        self
    }

    /// Returns the last recorded global loss EMA.
    pub fn global_loss(&self) -> Option<f32> {
        self.global_loss
    }

    /// Returns the adaptive entry tracked for a specific region key.
    pub fn entry_for(&self, key: ZSpaceRegionKey) -> Option<&AdaptiveRegionEntry> {
        self.entries.get(&key)
    }

    fn observe_background(&mut self, loss: f32) {
        let magnitude = loss.max(self.epsilon);
        let reference = self.global_loss.unwrap_or(magnitude);
        let next = reference + self.learning_rate * (magnitude - reference);
        self.global_loss = Some(next);
    }

    fn observe_region(&mut self, key: ZSpaceRegionKey, loss: f32) -> f32 {
        let magnitude = loss.max(self.epsilon);
        let reference = self.global_loss.unwrap_or(magnitude);
        let entry = self.entries.entry(key).or_default();
        entry.samples = entry.samples.saturating_add(1);
        if entry.samples == 1 {
            entry.ema_loss = magnitude;
        } else {
            entry.ema_loss += self.learning_rate * (magnitude - entry.ema_loss);
        }
        let mut multiplier = 1.0;
        if entry.samples >= self.min_samples && reference > self.epsilon {
            multiplier =
                (entry.ema_loss / reference).clamp(self.min_multiplier, self.max_multiplier);
        }
        entry.multiplier = multiplier;
        let next_global = reference + self.learning_rate * (magnitude - reference);
        self.global_loss = Some(next_global);
        multiplier
    }
}

impl Default for AdaptiveRegionWeighting {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Clone, Debug)]
pub struct AdaptiveRegionEntry {
    ema_loss: f32,
    samples: u32,
    multiplier: f32,
}

impl AdaptiveRegionEntry {
    fn new() -> Self {
        Self {
            ema_loss: 0.0,
            samples: 0,
            multiplier: 1.0,
        }
    }

    /// Returns the EMA of the regional loss.
    pub fn ema_loss(&self) -> f32 {
        self.ema_loss
    }

    /// Returns the number of samples accumulated for this region.
    pub fn samples(&self) -> u32 {
        self.samples
    }

    /// Returns the most recent adaptive multiplier.
    pub fn multiplier(&self) -> f32 {
        self.multiplier
    }
}

impl Default for AdaptiveRegionEntry {
    fn default() -> Self {
        Self::new()
    }
}

/// Complete configuration describing how regional multipliers are applied.
#[derive(Clone, Debug)]
pub struct RegionLossConfig {
    weights: RegionLossWeights,
    condition: RegionLossCondition,
    adaptive: Option<AdaptiveRegionWeighting>,
    history: Option<RegionHeatmapHistory>,
}

impl RegionLossConfig {
    /// Creates a configuration with the supplied weight table and default condition.
    pub fn new(weights: RegionLossWeights) -> Self {
        Self {
            weights,
            condition: RegionLossCondition::default(),
            adaptive: None,
            history: None,
        }
    }

    /// Updates the condition controlling when region weights are used.
    pub fn with_condition(mut self, condition: RegionLossCondition) -> Self {
        self.condition = condition;
        self
    }

    /// Attaches an adaptive weighting policy to the configuration.
    pub fn with_adaptive(mut self, adaptive: AdaptiveRegionWeighting) -> Self {
        self.adaptive = Some(adaptive);
        self
    }

    /// Enables temporal aggregation over a rolling window of snapshots.
    pub fn with_history_window(mut self, window: usize) -> Self {
        if window >= 2 {
            self.history = Some(RegionHeatmapHistory::new(window));
        }
        self
    }

    fn region_factor(
        &mut self,
        feedback: &SoftlogicZFeedback,
        base_loss: f32,
    ) -> Option<(f32, ZSpaceRegionDescriptor)> {
        let descriptor = match feedback.region_descriptor() {
            Some(descriptor) => descriptor,
            None => {
                if let Some(adaptive) = self.adaptive.as_mut() {
                    adaptive.observe_background(base_loss.abs());
                }
                return None;
            }
        };
        if !self.condition.satisfied(&descriptor) {
            if let Some(adaptive) = self.adaptive.as_mut() {
                adaptive.observe_background(base_loss.abs());
            }
            return None;
        }
        let factor = self.weights.weight_for(descriptor.key());
        let mut factor = factor;
        if let Some(adaptive) = self.adaptive.as_mut() {
            let multiplier = adaptive.observe_region(descriptor.key(), base_loss.abs());
            factor *= multiplier;
        }
        Some((factor, descriptor))
    }

    /// Returns a reference to the underlying weights.
    pub fn weights(&self) -> &RegionLossWeights {
        &self.weights
    }

    /// Returns the configured condition.
    pub fn condition(&self) -> &RegionLossCondition {
        &self.condition
    }

    /// Returns the adaptive weighting policy, if one is configured.
    pub fn adaptive(&self) -> Option<&AdaptiveRegionWeighting> {
        self.adaptive.as_ref()
    }

    /// Returns the configured history buffer, if enabled.
    pub fn history(&self) -> Option<&RegionHeatmapHistory> {
        self.history.as_ref()
    }

    /// Captures a snapshot of all region multipliers for visualization.
    pub fn snapshot(&self, highlight: Option<ZSpaceRegionDescriptor>) -> RegionHeatmapSnapshot {
        let mut snapshot = RegionHeatmapSnapshot::new(self.weights.default())
            .with_highlight(highlight)
            .with_condition(
                self.condition.min_spin_magnitude(),
                self.condition.min_radius(),
            );
        if let Some(adaptive) = self.adaptive.as_ref() {
            snapshot = snapshot.with_global_loss(adaptive.global_loss());
        }
        for spin in ZSpaceSpinBand::values() {
            for radius in ZSpaceRadiusBand::values() {
                let key = ZSpaceRegionKey::new(spin, radius);
                let base_weight = self.weights.weight_for(key);
                let (adaptive_multiplier, samples, ema_loss) = if let Some(adaptive) =
                    self.adaptive.as_ref()
                {
                    adaptive
                        .entry_for(key)
                        .map(|entry| (entry.multiplier(), entry.samples(), Some(entry.ema_loss())))
                        .unwrap_or((1.0, 0, None))
                } else {
                    (1.0, 0, None)
                };
                snapshot.insert_cell(RegionHeatmapCell::new(
                    key,
                    base_weight,
                    adaptive_multiplier,
                    samples,
                    ema_loss,
                ));
            }
        }
        snapshot
    }

    /// Builds a bundle of reports, updating the history buffer when enabled.
    pub fn reports(
        &mut self,
        highlight: Option<ZSpaceRegionDescriptor>,
        step: u64,
    ) -> RegionReportBundle {
        let snapshot = self.snapshot(highlight);
        let mut bundle = RegionReportBundle {
            snapshot: Some(snapshot.clone().into_report()),
            ..RegionReportBundle::default()
        };
        if let Some(history) = self.history.as_mut() {
            history.push(step, snapshot);
            bundle.trend = history.delta_report();
            bundle.volatility = history.volatility_report();
        }
        bundle
    }

    /// Builds an attribution report summarising the configured region weights.
    pub fn visualize(&self, highlight: Option<ZSpaceRegionDescriptor>) -> AttributionReport {
        self.snapshot(highlight).into_report()
    }
}

/// Loss aggregation strategies supported by [`ModuleTrainer`].
#[derive(Clone, Debug, Default)]
pub enum LossStrategy {
    /// Baseline behaviour using band weights only.
    #[default]
    Baseline,
    /// Applies additional region weights extracted from Softlogic feedback.
    Region(RegionLossConfig),
}

impl LossStrategy {
    fn region_factor(
        &mut self,
        feedback: &SoftlogicZFeedback,
        base_loss: f32,
    ) -> Option<(f32, ZSpaceRegionDescriptor)> {
        match self {
            LossStrategy::Baseline => None,
            LossStrategy::Region(config) => config.region_factor(feedback, base_loss),
        }
    }

    fn region_reports(
        &mut self,
        highlight: Option<ZSpaceRegionDescriptor>,
        step: u64,
    ) -> RegionReportBundle {
        match self {
            LossStrategy::Baseline => RegionReportBundle::default(),
            LossStrategy::Region(config) => config.reports(highlight, step),
        }
    }
}

/// Container bundling the available region visualization reports.
#[derive(Default, Clone, Debug)]
pub struct RegionReportBundle {
    pub snapshot: Option<AttributionReport>,
    pub trend: Option<AttributionReport>,
    pub volatility: Option<AttributionReport>,
}

/// Configuration describing how SoftLogic adjusts gradient band weighting.
///
/// Environment overrides (all optional):
/// - `SPIRAL_SOFTLOGIC_INERTIA`
/// - `SPIRAL_SOFTLOGIC_INERTIA_MIN`
/// - `SPIRAL_SOFTLOGIC_INERTIA_DRIFT_K`
/// - `SPIRAL_SOFTLOGIC_INERTIA_Z_K`
/// - `SPIRAL_SOFTLOGIC_DRIFT_GAIN`
/// - `SPIRAL_SOFTLOGIC_PSI_GAIN`
/// - `SPIRAL_SOFTLOGIC_LOSS_GAIN`
/// - `SPIRAL_SOFTLOGIC_FLOOR`
/// - `SPIRAL_SOFTLOGIC_SCALE_GAIN`
/// - `SPIRAL_SOFTLOGIC_REGION_GAIN`
/// - `SPIRAL_SOFTLOGIC_REGION_FACTOR_GAIN`
/// - `SPIRAL_SOFTLOGIC_ENERGY_EQUALIZE_GAIN`
/// - `SPIRAL_SOFTLOGIC_MEAN_NORMALIZE_GAIN`
/// - `SPIRAL_SOFTLOGIC_ENERGY_EQUALIZE_AUTO`
/// - `SPIRAL_SOFTLOGIC_MEAN_NORMALIZE_AUTO`
#[derive(Debug, Clone, Copy)]
pub struct SoftLogicConfig {
    pub inertia: f32,
    pub inertia_min: f32,
    pub inertia_drift_k: f32,
    pub inertia_z_k: f32,
    pub drift_gain: f32,
    pub psi_gain: f32,
    pub loss_gain: f32,
    pub floor: f32,
    pub scale_gain: f32,
    pub region_gain: f32,
    pub region_factor_gain: f32,
    pub energy_equalize_gain: f32,
    pub mean_normalize_gain: f32,
    pub energy_equalize_auto: f32,
    pub mean_normalize_auto: f32,
}

impl Default for SoftLogicConfig {
    fn default() -> Self {
        Self {
            inertia: 0.65,
            inertia_min: 0.15,
            inertia_drift_k: 0.6,
            inertia_z_k: 0.2,
            drift_gain: 0.25,
            psi_gain: 0.5,
            loss_gain: 0.35,
            floor: 0.25,
            scale_gain: 0.2,
            region_gain: 0.15,
            region_factor_gain: 0.35,
            energy_equalize_gain: 0.0,
            mean_normalize_gain: 0.0,
            energy_equalize_auto: 0.0,
            mean_normalize_auto: 0.0,
        }
    }
}

impl SoftLogicConfig {
    fn checkpoint_state(self) -> TrainerSoftLogicConfigState {
        TrainerSoftLogicConfigState {
            inertia: self.inertia,
            inertia_min: self.inertia_min,
            inertia_drift_k: self.inertia_drift_k,
            inertia_z_k: self.inertia_z_k,
            drift_gain: self.drift_gain,
            psi_gain: self.psi_gain,
            loss_gain: self.loss_gain,
            floor: self.floor,
            scale_gain: self.scale_gain,
            region_gain: self.region_gain,
            region_factor_gain: self.region_factor_gain,
            energy_equalize_gain: self.energy_equalize_gain,
            mean_normalize_gain: self.mean_normalize_gain,
            energy_equalize_auto: self.energy_equalize_auto,
            mean_normalize_auto: self.mean_normalize_auto,
        }
    }

    fn from_checkpoint_state(
        state: TrainerSoftLogicConfigState,
    ) -> Result<Self, TrainerOptimizerCheckpointError> {
        state.validate()?;
        Ok(Self {
            inertia: state.inertia,
            inertia_min: state.inertia_min,
            inertia_drift_k: state.inertia_drift_k,
            inertia_z_k: state.inertia_z_k,
            drift_gain: state.drift_gain,
            psi_gain: state.psi_gain,
            loss_gain: state.loss_gain,
            floor: state.floor,
            scale_gain: state.scale_gain,
            region_gain: state.region_gain,
            region_factor_gain: state.region_factor_gain,
            energy_equalize_gain: state.energy_equalize_gain,
            mean_normalize_gain: state.mean_normalize_gain,
            energy_equalize_auto: state.energy_equalize_auto,
            mean_normalize_auto: state.mean_normalize_auto,
        })
    }

    pub fn clamp_inplace(&mut self) {
        if !self.inertia.is_finite() {
            self.inertia = 0.65;
        }
        if !self.inertia_min.is_finite() {
            self.inertia_min = 0.15;
        }
        if !self.inertia_drift_k.is_finite() {
            self.inertia_drift_k = 0.6;
        }
        if !self.inertia_z_k.is_finite() {
            self.inertia_z_k = 0.2;
        }
        if !self.drift_gain.is_finite() {
            self.drift_gain = 0.25;
        }
        if !self.psi_gain.is_finite() {
            self.psi_gain = 0.5;
        }
        if !self.loss_gain.is_finite() {
            self.loss_gain = 0.35;
        }
        if !self.floor.is_finite() {
            self.floor = 0.25;
        }
        if !self.scale_gain.is_finite() {
            self.scale_gain = 0.2;
        }
        if !self.region_gain.is_finite() {
            self.region_gain = 0.15;
        }
        if !self.region_factor_gain.is_finite() {
            self.region_factor_gain = 0.35;
        }
        if !self.energy_equalize_gain.is_finite() {
            self.energy_equalize_gain = 0.0;
        }
        if !self.mean_normalize_gain.is_finite() {
            self.mean_normalize_gain = 0.0;
        }
        if !self.energy_equalize_auto.is_finite() {
            self.energy_equalize_auto = 0.0;
        }
        if !self.mean_normalize_auto.is_finite() {
            self.mean_normalize_auto = 0.0;
        }

        self.inertia = self.inertia.clamp(0.0, 0.95);
        self.inertia_min = self.inertia_min.clamp(0.0, 0.95).min(self.inertia);
        self.inertia_drift_k = self.inertia_drift_k.clamp(0.0, 4.0);
        self.inertia_z_k = self.inertia_z_k.clamp(0.0, 2.0);
        self.drift_gain = self.drift_gain.clamp(0.0, 1.0);
        self.psi_gain = self.psi_gain.clamp(0.0, 2.0);
        self.loss_gain = self.loss_gain.clamp(0.0, 1.5);
        self.floor = self.floor.clamp(0.05, 1.0);
        self.scale_gain = self.scale_gain.clamp(0.0, 1.5);
        self.region_gain = self.region_gain.clamp(0.0, 1.5);
        self.region_factor_gain = self.region_factor_gain.clamp(0.0, 2.0);
        self.energy_equalize_gain = self.energy_equalize_gain.clamp(0.0, 1.0);
        self.mean_normalize_gain = self.mean_normalize_gain.clamp(0.0, 1.0);
        self.energy_equalize_auto = self.energy_equalize_auto.clamp(0.0, 1.0);
        self.mean_normalize_auto = self.mean_normalize_auto.clamp(0.0, 1.0);
    }

    /// Applies environment overrides to the configuration in-place.
    pub fn apply_env_overrides(&mut self) {
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_INERTIA") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.inertia = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_INERTIA_MIN") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.inertia_min = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_INERTIA_DRIFT_K") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.inertia_drift_k = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_INERTIA_Z_K") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.inertia_z_k = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_DRIFT_GAIN") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.drift_gain = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_PSI_GAIN") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.psi_gain = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_LOSS_GAIN") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.loss_gain = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_FLOOR") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.floor = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_SCALE_GAIN") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.scale_gain = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_REGION_GAIN") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.region_gain = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_REGION_FACTOR_GAIN") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.region_factor_gain = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_ENERGY_EQUALIZE_GAIN") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.energy_equalize_gain = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_MEAN_NORMALIZE_GAIN") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.mean_normalize_gain = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_ENERGY_EQUALIZE_AUTO") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.energy_equalize_auto = parsed;
            }
        }
        if let Ok(value) = env::var("SPIRAL_SOFTLOGIC_MEAN_NORMALIZE_AUTO") {
            if let Ok(parsed) = value.parse::<f32>() {
                self.mean_normalize_auto = parsed;
            }
        }

        self.clamp_inplace();
    }

    /// Applies environment overrides and returns `self` for fluent construction.
    pub fn with_env_overrides(mut self) -> Self {
        self.apply_env_overrides();
        self
    }
}

#[derive(Clone, Copy, Debug, Default)]
struct SoftLogicAdaptiveMetrics {
    energy_equalize_gain_eff: f32,
    energy_equalize_strength: f32,
    energy_equalize_over: f32,
    energy_equalize_state: f32,
    mean_normalize_gain_eff: f32,
    mean_normalize_need: f32,
    mean_normalize_state: f32,
    mean_target: f32,
}

#[derive(Debug, Clone)]
struct SoftLogicFlex {
    config: SoftLogicConfig,
    last_weights: (f32, f32, f32),
    last_z: f32,
    last_feedback: Option<SoftlogicZFeedback>,
    last_inertia: f32,
    last_region: Option<ZSpaceRegionDescriptor>,
    last_region_factor: f32,
    last_region_scale: (f32, f32, f32),
    equalize_state: f32,
    mean_normalize_state: f32,
    adaptive_metrics: SoftLogicAdaptiveMetrics,
    pending_events: Vec<String>,
    equalize_guard_on: bool,
    equalize_clamp_on: bool,
    normalize_on: bool,
}

impl SoftLogicFlex {
    fn new() -> Self {
        Self::from_config(SoftLogicConfig::default().with_env_overrides())
    }

    fn from_config(mut config: SoftLogicConfig) -> Self {
        config.clamp_inplace();
        let mut flex = Self {
            config,
            last_weights: (1.0, 1.0, 1.0),
            last_z: 0.0,
            last_feedback: None,
            last_inertia: 0.0,
            last_region: None,
            last_region_factor: 1.0,
            last_region_scale: (1.0, 1.0, 1.0),
            equalize_state: 1.0,
            mean_normalize_state: 1.0,
            adaptive_metrics: SoftLogicAdaptiveMetrics::default(),
            pending_events: Vec::new(),
            equalize_guard_on: false,
            equalize_clamp_on: false,
            normalize_on: false,
        };
        flex.last_inertia = flex.config.inertia;
        flex
    }

    fn config(&self) -> SoftLogicConfig {
        self.config
    }

    fn set_config(&mut self, mut config: SoftLogicConfig) {
        config.clamp_inplace();
        self.config = config;
        self.last_inertia = self.config.inertia;
        self.equalize_state = 1.0;
        self.mean_normalize_state = 1.0;
        self.adaptive_metrics = SoftLogicAdaptiveMetrics::default();
        self.pending_events.clear();
        self.equalize_guard_on = false;
        self.equalize_clamp_on = false;
        self.normalize_on = false;
    }

    fn state(&self) -> TrainerSoftLogicState {
        TrainerSoftLogicState {
            config: self.config.checkpoint_state(),
            last_weights: [
                self.last_weights.0,
                self.last_weights.1,
                self.last_weights.2,
            ],
            last_z: self.last_z,
            last_feedback: self.last_feedback.as_ref().map(|feedback| {
                TrainerSoftLogicFeedbackState {
                    z_signal: feedback.z_signal,
                    scale_log_radius: feedback.scale.map(|scale| scale.log_radius),
                }
            }),
            last_inertia: self.last_inertia,
            last_region: self.last_region,
            last_region_factor: self.last_region_factor,
            last_region_scale: [
                self.last_region_scale.0,
                self.last_region_scale.1,
                self.last_region_scale.2,
            ],
            equalize_state: self.equalize_state,
            mean_normalize_state: self.mean_normalize_state,
            pending_events: self.pending_events.clone(),
            equalize_guard_on: self.equalize_guard_on,
            equalize_clamp_on: self.equalize_clamp_on,
            normalize_on: self.normalize_on,
        }
    }

    fn from_state(state: TrainerSoftLogicState) -> Result<Self, TrainerOptimizerCheckpointError> {
        state.validate()?;
        let config = SoftLogicConfig::from_checkpoint_state(state.config)?;
        let last_feedback = state.last_feedback.map(|feedback| SoftlogicZFeedback {
            z_signal: feedback.z_signal,
            scale: feedback.scale_log_radius.and_then(ZScale::from_log),
            ..SoftlogicZFeedback::default()
        });
        Ok(Self {
            config,
            last_weights: (
                state.last_weights[0],
                state.last_weights[1],
                state.last_weights[2],
            ),
            last_z: state.last_z,
            last_feedback,
            last_inertia: state.last_inertia,
            last_region: state.last_region,
            last_region_factor: state.last_region_factor,
            last_region_scale: (
                state.last_region_scale[0],
                state.last_region_scale[1],
                state.last_region_scale[2],
            ),
            equalize_state: state.equalize_state,
            mean_normalize_state: state.mean_normalize_state,
            adaptive_metrics: SoftLogicAdaptiveMetrics::default(),
            pending_events: state.pending_events,
            equalize_guard_on: state.equalize_guard_on,
            equalize_clamp_on: state.equalize_clamp_on,
            normalize_on: state.normalize_on,
        })
    }

    fn adaptive_metrics(&self) -> SoftLogicAdaptiveMetrics {
        self.adaptive_metrics
    }

    fn record_region_feedback(&mut self, descriptor: ZSpaceRegionDescriptor, factor: f32) {
        self.last_region = Some(descriptor);
        self.last_region_factor = if factor.is_finite() {
            factor.max(0.0)
        } else {
            1.0
        };
    }

    fn clear_region_feedback(&mut self) {
        self.last_region = None;
        self.last_region_factor = 1.0;
        self.last_region_scale = (1.0, 1.0, 1.0);
    }

    fn last_inertia(&self) -> f32 {
        self.last_inertia
    }

    fn last_region_scale(&self) -> (f32, f32, f32) {
        self.last_region_scale
    }

    fn effective_inertia(&mut self, band_energy: &BandEnergy) -> f32 {
        let drift_drive = (band_energy.drift.abs() * self.config.inertia_drift_k).tanh();
        let z_drive = self
            .last_feedback
            .as_ref()
            .map(|feedback| feedback.z_signal.abs())
            .unwrap_or(self.last_z.abs())
            * self.config.inertia_z_k;
        let spectral_curvature = band_energy.spectral_curvature();
        let spectral_diffusion = (1.0 - band_energy.spectral.spin.abs()).clamp(0.0, 1.0);
        let spectral_drive =
            (0.18 * spectral_curvature + 0.12 * spectral_diffusion).clamp(0.0, 0.3);
        let mut adapt = (drift_drive + z_drive + spectral_drive).clamp(0.0, 0.9);
        if self.config.energy_equalize_auto > 0.0 {
            let above_abs = band_energy.above.abs();
            let here_abs = band_energy.here.abs();
            let beneath_abs = band_energy.beneath.abs();
            let norm = (above_abs + here_abs + beneath_abs).max(1e-4);
            let max_share = above_abs.max(here_abs).max(beneath_abs) / norm;
            let energy_drive = ((max_share - (1.0 / 3.0)) / (2.0 / 3.0)).clamp(0.0, 1.0);
            adapt =
                (adapt + energy_drive * 0.35 * self.config.energy_equalize_auto).clamp(0.0, 0.9);
        }
        let inertia = (self.config.inertia * (1.0 - adapt)).clamp(self.config.inertia_min, 0.95);
        self.last_inertia = inertia;
        inertia
    }

    fn region_steering(&mut self, z_bias: f32) -> (f32, f32, f32) {
        let Some(descriptor) = self.last_region else {
            self.last_region_scale = (1.0, 1.0, 1.0);
            return self.last_region_scale;
        };
        if self.config.region_gain <= 0.0 {
            self.last_region_scale = (1.0, 1.0, 1.0);
            return self.last_region_scale;
        }
        let factor_boost = if self.last_region_factor.is_finite() && self.last_region_factor > 1.0 {
            1.0 + self.config.region_factor_gain * (self.last_region_factor - 1.0).clamp(0.0, 3.0)
        } else {
            1.0
        };
        let gain = (self.config.region_gain * factor_boost).clamp(0.0, 0.9);
        let radius_weight = match descriptor.key().radius {
            ZSpaceRadiusBand::Core => 0.25,
            ZSpaceRadiusBand::Mantle => 0.6,
            ZSpaceRadiusBand::Edge => 1.0,
        };
        let intensity = (gain * radius_weight).clamp(0.0, 0.9);
        let preferred_band = match descriptor.key().spin {
            ZSpaceSpinBand::Leading => 0,
            ZSpaceSpinBand::Trailing => 2,
            ZSpaceSpinBand::Neutral => {
                if matches!(descriptor.key().radius, ZSpaceRadiusBand::Edge) {
                    if z_bias >= 0.0 {
                        0
                    } else {
                        2
                    }
                } else {
                    1
                }
            }
        };
        let other = (1.0 - 0.5 * intensity).max(0.1);
        self.last_region_scale = match preferred_band {
            0 => (1.0 + intensity, other, other),
            1 => (other, 1.0 + intensity, other),
            _ => (other, other, 1.0 + intensity),
        };
        self.last_region_scale
    }

    fn prepare_weights(&mut self, band_energy: &BandEnergy) -> (f32, f32, f32) {
        let inertia = self.effective_inertia(band_energy);
        self.adaptive_metrics = SoftLogicAdaptiveMetrics::default();
        let above_abs = band_energy.above.abs();
        let here_abs = band_energy.here.abs();
        let beneath_abs = band_energy.beneath.abs();
        let norm = (above_abs + here_abs + beneath_abs).max(1e-4);
        let asymmetry = (band_energy.above - band_energy.beneath) / norm;
        let drift_term = band_energy.drift.tanh();
        let spectral_focus = band_energy.spectral_focus();
        let spectral_curvature = band_energy.spectral_curvature();
        let spectral_spin = band_energy.spectral.spin.clamp(-1.0, 1.0);
        let spectral_stability = band_energy.spectral_stability();
        let z_bias = self
            .last_feedback
            .as_ref()
            .map(|feedback| feedback.z_signal)
            .unwrap_or(self.last_z);
        let mut target_above =
            1.0 + (asymmetry * self.config.drift_gain) + (z_bias * self.config.psi_gain);
        let mut target_here = 1.0
            + ((band_energy.here / norm) - (band_energy.drift.abs() / norm))
                * self.config.loss_gain;
        let mut target_beneath =
            1.0 - (asymmetry * self.config.drift_gain) - (z_bias * self.config.psi_gain)
                + (-drift_term * self.config.drift_gain * 0.5);

        if spectral_focus > 0.0 {
            let edge_gain = 0.25 * self.config.drift_gain * spectral_focus;
            target_above *= 1.0 + edge_gain * spectral_spin.max(0.0);
            target_beneath *= 1.0 + edge_gain * (-spectral_spin).max(0.0);
            target_here *= 1.0 + 0.2 * self.config.loss_gain * spectral_stability;
            target_here *= 1.0 - 0.08 * spectral_focus * spectral_curvature;
        }

        if self.config.scale_gain > 0.0 {
            if let Some(scale) = self
                .last_feedback
                .as_ref()
                .and_then(|feedback| feedback.scale)
            {
                let bias = (-scale.log_radius).tanh();
                let explore = bias.max(0.0);
                let settle = (-bias).max(0.0);
                target_above *= 1.0 + self.config.scale_gain * explore;
                target_here *= 1.0 + self.config.scale_gain * 0.5 * (explore - settle);
                target_beneath *= 1.0 + self.config.scale_gain * settle;
            }
        }

        let region_scale = self.region_steering(z_bias);
        target_above *= region_scale.0;
        target_here *= region_scale.1;
        target_beneath *= region_scale.2;

        if self.config.energy_equalize_gain > 0.0 {
            let target_share = 1.0 / 3.0;
            let eps = 1e-4;
            let pa = (above_abs / norm).max(eps);
            let ph = (here_abs / norm).max(eps);
            let pb = (beneath_abs / norm).max(eps);
            let ratio_max = 9.0;
            let ra_raw = target_share / pa;
            let rh_raw = target_share / ph;
            let rb_raw = target_share / pb;
            let ra = ra_raw.clamp(1.0 / ratio_max, ratio_max);
            let rh = rh_raw.clamp(1.0 / ratio_max, ratio_max);
            let rb = rb_raw.clamp(1.0 / ratio_max, ratio_max);
            let raw_max = ra_raw.max(rh_raw).max(rb_raw);
            let ln_ratio_max = ratio_max.ln().max(1e-4);
            let strength = if raw_max.is_finite() && raw_max > 0.0 {
                (raw_max.ln() / ln_ratio_max).clamp(0.0, 2.0)
            } else if raw_max.is_sign_positive() && raw_max.is_infinite() {
                2.0
            } else {
                0.0
            };
            let strength_clamped = strength.clamp(0.0, 1.0);
            let over = ((strength_clamped - 0.85) / 0.15).clamp(0.0, 1.0);
            let desired_guard = (1.0 - 0.75 * over).clamp(0.05, 1.0);

            let gain_base = self.config.energy_equalize_gain.clamp(0.0, 1.0);
            let auto = self.config.energy_equalize_auto.clamp(0.0, 1.0);
            let gain = if auto > 0.0 {
                let update = (auto * (1.0 - inertia)).clamp(0.0, 1.0);
                self.equalize_state =
                    Self::lerp(self.equalize_state, desired_guard, update).clamp(0.0, 1.0);
                let guard_on = desired_guard < 0.999;
                let clamp_on = ra_raw > ratio_max || rh_raw > ratio_max || rb_raw > ratio_max;
                if guard_on != self.equalize_guard_on {
                    self.pending_events.push(if guard_on {
                        "equalize.guard.on".to_string()
                    } else {
                        "equalize.guard.off".to_string()
                    });
                    self.equalize_guard_on = guard_on;
                }
                if clamp_on != self.equalize_clamp_on {
                    self.pending_events.push(if clamp_on {
                        "equalize.clamp.on".to_string()
                    } else {
                        "equalize.clamp.off".to_string()
                    });
                    self.equalize_clamp_on = clamp_on;
                }
                gain_base * self.equalize_state
            } else {
                self.equalize_state = 1.0;
                self.equalize_guard_on = false;
                self.equalize_clamp_on = false;
                gain_base
            };

            self.adaptive_metrics.energy_equalize_gain_eff = gain;
            self.adaptive_metrics.energy_equalize_strength = strength_clamped;
            self.adaptive_metrics.energy_equalize_over = over;
            self.adaptive_metrics.energy_equalize_state = self.equalize_state;

            target_above *= ra.powf(gain);
            target_here *= rh.powf(gain);
            target_beneath *= rb.powf(gain);
        }

        let mut target = (
            target_above.clamp(self.config.floor, 3.0),
            target_here.clamp(self.config.floor, 2.5),
            target_beneath.clamp(self.config.floor, 3.0),
        );

        if self.config.mean_normalize_gain > 0.0 {
            let mean = (target.0 + target.1 + target.2) / 3.0;
            if mean.is_finite() && mean > 0.0 {
                self.adaptive_metrics.mean_target = mean;
                let gain_base = self.config.mean_normalize_gain.clamp(0.0, 1.0);
                let auto = self.config.mean_normalize_auto.clamp(0.0, 1.0);
                let mean_dev = mean.ln().abs();
                let need = (mean_dev / 0.4).clamp(0.0, 1.0);
                let gain = if auto > 0.0 {
                    let update = (auto * (1.0 - inertia)).clamp(0.0, 1.0);
                    self.mean_normalize_state =
                        Self::lerp(self.mean_normalize_state, need, update).clamp(0.0, 1.0);
                    let normalize_on = need > 0.25;
                    if normalize_on != self.normalize_on {
                        self.pending_events.push(if normalize_on {
                            "normalize.on".to_string()
                        } else {
                            "normalize.off".to_string()
                        });
                        self.normalize_on = normalize_on;
                    }
                    gain_base * self.mean_normalize_state
                } else {
                    self.mean_normalize_state = 1.0;
                    self.normalize_on = false;
                    gain_base
                };
                let norm_factor = 1.0 / mean;
                let blend = (1.0 - gain) + gain * norm_factor;
                target.0 = (target.0 * blend).clamp(self.config.floor, 3.0);
                target.1 = (target.1 * blend).clamp(self.config.floor, 2.5);
                target.2 = (target.2 * blend).clamp(self.config.floor, 3.0);

                self.adaptive_metrics.mean_normalize_gain_eff = gain;
                self.adaptive_metrics.mean_normalize_need = need;
                self.adaptive_metrics.mean_normalize_state = self.mean_normalize_state;
            }
        }
        self.last_weights = (
            Self::lerp(self.last_weights.0, target.0, 1.0 - inertia),
            Self::lerp(self.last_weights.1, target.1, 1.0 - inertia),
            Self::lerp(self.last_weights.2, target.2, 1.0 - inertia),
        );
        self.last_weights
    }

    fn observe(
        &mut self,
        band_energy: &BandEnergy,
        weighted_loss: f32,
        psi_total: Option<f32>,
        scale_hint: Option<ZScale>,
    ) -> SoftlogicZFeedback {
        let inertia = self.effective_inertia(band_energy);
        let psi_total = psi_total.unwrap_or(0.0);
        let total = (band_energy.above + band_energy.here + band_energy.beneath).max(1e-4);
        let asym = (band_energy.above - band_energy.beneath) / total;
        let drift = band_energy.drift;
        let raw_signal = 0.6 * (psi_total - weighted_loss) + 0.3 * asym + 0.1 * drift;
        let z_signal = raw_signal.tanh();
        self.last_z = Self::lerp(self.last_z, z_signal, 1.0 - inertia);
        let feedback = SoftlogicZFeedback {
            psi_total,
            weighted_loss,
            band_energy: (band_energy.above, band_energy.here, band_energy.beneath),
            drift,
            z_signal: self.last_z,
            scale: scale_hint,
            events: std::mem::take(&mut self.pending_events),
            attributions: Vec::new(),
            elliptic: None,
        };
        let mut feedback = feedback;
        if feedback.elliptic.is_none() {
            if let Some(last) = self
                .last_feedback
                .as_ref()
                .and_then(|sample| sample.elliptic)
            {
                feedback.elliptic = Some(last);
            }
        }
        self.last_feedback = Some(feedback.clone());
        feedback
    }

    fn lerp(current: f32, target: f32, factor: f32) -> f32 {
        current + (target - current) * factor
    }
}

#[derive(Debug, Clone)]
pub struct SpectralLearningRatePolicy {
    smoothing: f32,
    event_smoothing: f32,
    turnover_smoothing: f32,
    coherence_gain: f32,
    curvature_gain: f32,
    sheet_gain: f32,
    spin_gain: f32,
    radius_gain: f32,
    energy_gain: f32,
    phase_gain: f32,
    stuck_phase_gain: f32,
    max_phase_gain: f32,
    stuck_turnover_threshold: f32,
    dominant_turnover: f32,
    last_dominant: Option<usize>,
    last_label: Option<CoherenceLabel>,
    min_lr_scale: f32,
    max_lr_scale: f32,
    max_lr_step: f32,
    min_band_scale: f32,
    max_band_scale: f32,
    band_state: (f32, f32, f32),
    lr_state: f32,
    applied_lr_scale: f32,
    local_lr_state: (f32, f32, f32),
}

impl SpectralLearningRatePolicy {
    pub fn new() -> Self {
        Self {
            smoothing: 0.2,
            event_smoothing: 0.75,
            turnover_smoothing: 0.15,
            coherence_gain: 0.5,
            curvature_gain: 0.15,
            sheet_gain: 0.6,
            spin_gain: 0.4,
            radius_gain: 0.35,
            energy_gain: 0.25,
            phase_gain: 0.25,
            stuck_phase_gain: 0.35,
            max_phase_gain: 0.65,
            stuck_turnover_threshold: 0.12,
            dominant_turnover: 0.0,
            last_dominant: None,
            last_label: None,
            min_lr_scale: 0.1,
            max_lr_scale: 6.0,
            max_lr_step: 1.4,
            min_band_scale: 0.5,
            max_band_scale: 2.75,
            band_state: (1.0, 1.0, 1.0),
            lr_state: 1.0,
            applied_lr_scale: 1.0,
            local_lr_state: (1.0, 1.0, 1.0),
        }
    }

    /// Captures configuration and every smoothing accumulator used by the policy.
    pub fn state(&self) -> TrainerSpectralPolicyState {
        TrainerSpectralPolicyState {
            smoothing: self.smoothing,
            event_smoothing: self.event_smoothing,
            turnover_smoothing: self.turnover_smoothing,
            coherence_gain: self.coherence_gain,
            curvature_gain: self.curvature_gain,
            sheet_gain: self.sheet_gain,
            spin_gain: self.spin_gain,
            radius_gain: self.radius_gain,
            energy_gain: self.energy_gain,
            phase_gain: self.phase_gain,
            stuck_phase_gain: self.stuck_phase_gain,
            max_phase_gain: self.max_phase_gain,
            stuck_turnover_threshold: self.stuck_turnover_threshold,
            dominant_turnover: self.dominant_turnover,
            last_dominant: self.last_dominant,
            last_label: self.last_label,
            min_lr_scale: self.min_lr_scale,
            max_lr_scale: self.max_lr_scale,
            max_lr_step: self.max_lr_step,
            min_band_scale: self.min_band_scale,
            max_band_scale: self.max_band_scale,
            band_state: [self.band_state.0, self.band_state.1, self.band_state.2],
            lr_state: self.lr_state,
            applied_lr_scale: self.applied_lr_scale,
            local_lr_state: [
                self.local_lr_state.0,
                self.local_lr_state.1,
                self.local_lr_state.2,
            ],
        }
    }

    /// Reconstructs a policy after Rust validates all transported state.
    pub fn from_state(
        state: TrainerSpectralPolicyState,
    ) -> Result<Self, TrainerOptimizerCheckpointError> {
        state.validate()?;
        Ok(Self {
            smoothing: state.smoothing,
            event_smoothing: state.event_smoothing,
            turnover_smoothing: state.turnover_smoothing,
            coherence_gain: state.coherence_gain,
            curvature_gain: state.curvature_gain,
            sheet_gain: state.sheet_gain,
            spin_gain: state.spin_gain,
            radius_gain: state.radius_gain,
            energy_gain: state.energy_gain,
            phase_gain: state.phase_gain,
            stuck_phase_gain: state.stuck_phase_gain,
            max_phase_gain: state.max_phase_gain,
            stuck_turnover_threshold: state.stuck_turnover_threshold,
            dominant_turnover: state.dominant_turnover,
            last_dominant: state.last_dominant,
            last_label: state.last_label,
            min_lr_scale: state.min_lr_scale,
            max_lr_scale: state.max_lr_scale,
            max_lr_step: state.max_lr_step,
            min_band_scale: state.min_band_scale,
            max_band_scale: state.max_band_scale,
            band_state: (
                state.band_state[0],
                state.band_state[1],
                state.band_state[2],
            ),
            lr_state: state.lr_state,
            applied_lr_scale: state.applied_lr_scale,
            local_lr_state: (
                state.local_lr_state[0],
                state.local_lr_state[1],
                state.local_lr_state[2],
            ),
        })
    }

    fn clamp_state_to_bounds(&mut self) {
        self.band_state.0 = self
            .band_state
            .0
            .clamp(self.min_band_scale, self.max_band_scale);
        self.band_state.1 = self
            .band_state
            .1
            .clamp(self.min_band_scale, self.max_band_scale);
        self.band_state.2 = self
            .band_state
            .2
            .clamp(self.min_band_scale, self.max_band_scale);
        self.local_lr_state.0 = self
            .local_lr_state
            .0
            .clamp(self.min_band_scale, self.max_band_scale);
        self.local_lr_state.1 = self
            .local_lr_state
            .1
            .clamp(self.min_band_scale, self.max_band_scale);
        self.local_lr_state.2 = self
            .local_lr_state
            .2
            .clamp(self.min_band_scale, self.max_band_scale);
        self.lr_state = self.lr_state.clamp(self.min_lr_scale, self.max_lr_scale);
        self.applied_lr_scale = self
            .applied_lr_scale
            .clamp(self.min_lr_scale, self.max_lr_scale);
    }

    pub fn with_smoothing(mut self, smoothing: f32) -> Self {
        if smoothing.is_finite() && smoothing > 0.0 {
            self.smoothing = smoothing.clamp(1.0e-3, 1.0);
        }
        self
    }

    /// Overrides the smoothing factor used when a coherence label transition is detected.
    pub fn with_event_smoothing(mut self, smoothing: f32) -> Self {
        if smoothing.is_finite() && smoothing > 0.0 {
            self.event_smoothing = smoothing.clamp(1.0e-3, 1.0);
        }
        self
    }

    /// Overrides the smoothing factor used to track dominant channel turnover.
    pub fn with_turnover_smoothing(mut self, smoothing: f32) -> Self {
        if smoothing.is_finite() && smoothing > 0.0 {
            self.turnover_smoothing = smoothing.clamp(1.0e-3, 1.0);
        }
        self
    }

    /// Adjusts the base phase gain used to bias band scales towards a dominant "seat".
    pub fn with_phase_gain(mut self, gain: f32) -> Self {
        if gain.is_finite() && gain >= 0.0 {
            self.phase_gain = gain;
        }
        self
    }

    /// Adjusts the extra phase gain applied when dominant channel turnover drops below threshold.
    pub fn with_stuck_phase_gain(mut self, gain: f32) -> Self {
        if gain.is_finite() && gain >= 0.0 {
            self.stuck_phase_gain = gain;
        }
        self
    }

    /// Adjusts the turnover threshold used to detect "stuck" coherence.
    pub fn with_stuck_turnover_threshold(mut self, threshold: f32) -> Self {
        if threshold.is_finite() && threshold >= 0.0 {
            self.stuck_turnover_threshold = threshold;
        }
        self
    }

    pub fn with_coherence_gain(mut self, gain: f32) -> Self {
        if gain.is_finite() {
            self.coherence_gain = gain.max(0.0);
        }
        self
    }

    pub fn with_sheet_gain(mut self, gain: f32) -> Self {
        if gain.is_finite() {
            self.sheet_gain = gain.max(0.0);
        }
        self
    }

    pub fn with_spin_gain(mut self, gain: f32) -> Self {
        if gain.is_finite() {
            self.spin_gain = gain.max(0.0);
        }
        self
    }

    pub fn with_radius_gain(mut self, gain: f32) -> Self {
        if gain.is_finite() {
            self.radius_gain = gain.max(0.0);
        }
        self
    }

    pub fn with_energy_gain(mut self, gain: f32) -> Self {
        if gain.is_finite() {
            self.energy_gain = gain.max(0.0);
        }
        self
    }

    pub fn with_lr_bounds(mut self, min: f32, max: f32) -> Self {
        if min.is_finite() && max.is_finite() && min > 0.0 && max > min {
            self.min_lr_scale = min;
            self.max_lr_scale = max;
            self.clamp_state_to_bounds();
        }
        self
    }

    pub fn with_band_bounds(mut self, min: f32, max: f32) -> Self {
        if min.is_finite() && max.is_finite() && min > 0.0 && max > min {
            self.min_band_scale = min;
            self.max_band_scale = max;
            self.clamp_state_to_bounds();
        }
        self
    }

    pub fn with_max_lr_step(mut self, max_step: f32) -> Self {
        if max_step.is_finite() && max_step > 0.0 {
            self.max_lr_step = max_step.max(1.0);
        }
        self
    }

    /// Applies environment overrides to the policy in-place.
    ///
    /// Supported variables (all optional):
    /// - `SPIRAL_SPECTRAL_POLICY_SMOOTHING`
    /// - `SPIRAL_SPECTRAL_POLICY_EVENT_SMOOTHING`
    /// - `SPIRAL_SPECTRAL_POLICY_TURNOVER_SMOOTHING`
    /// - `SPIRAL_SPECTRAL_POLICY_PHASE_GAIN`
    /// - `SPIRAL_SPECTRAL_POLICY_STUCK_PHASE_GAIN`
    /// - `SPIRAL_SPECTRAL_POLICY_MAX_PHASE_GAIN`
    /// - `SPIRAL_SPECTRAL_POLICY_STUCK_TURNOVER_THRESHOLD`
    /// - `SPIRAL_SPECTRAL_POLICY_LR_MIN` / `SPIRAL_SPECTRAL_POLICY_LR_MAX`
    /// - `SPIRAL_SPECTRAL_POLICY_BAND_MIN` / `SPIRAL_SPECTRAL_POLICY_BAND_MAX`
    pub fn apply_env_overrides(&mut self) {
        if let Ok(value) = env::var("SPIRAL_SPECTRAL_POLICY_SMOOTHING") {
            if let Ok(smoothing) = value.parse::<f32>() {
                if smoothing.is_finite() && smoothing > 0.0 {
                    self.smoothing = smoothing.clamp(1.0e-3, 1.0);
                }
            }
        }
        if let Ok(value) = env::var("SPIRAL_SPECTRAL_POLICY_EVENT_SMOOTHING") {
            if let Ok(smoothing) = value.parse::<f32>() {
                if smoothing.is_finite() && smoothing > 0.0 {
                    self.event_smoothing = smoothing.clamp(1.0e-3, 1.0);
                }
            }
        }
        if let Ok(value) = env::var("SPIRAL_SPECTRAL_POLICY_TURNOVER_SMOOTHING") {
            if let Ok(smoothing) = value.parse::<f32>() {
                if smoothing.is_finite() && smoothing > 0.0 {
                    self.turnover_smoothing = smoothing.clamp(1.0e-3, 1.0);
                }
            }
        }
        if let Ok(value) = env::var("SPIRAL_SPECTRAL_POLICY_PHASE_GAIN") {
            if let Ok(gain) = value.parse::<f32>() {
                if gain.is_finite() && gain >= 0.0 {
                    self.phase_gain = gain;
                }
            }
        }
        if let Ok(value) = env::var("SPIRAL_SPECTRAL_POLICY_STUCK_PHASE_GAIN") {
            if let Ok(gain) = value.parse::<f32>() {
                if gain.is_finite() && gain >= 0.0 {
                    self.stuck_phase_gain = gain;
                }
            }
        }
        if let Ok(value) = env::var("SPIRAL_SPECTRAL_POLICY_MAX_PHASE_GAIN") {
            if let Ok(gain) = value.parse::<f32>() {
                if gain.is_finite() && gain >= 0.0 {
                    self.max_phase_gain = gain;
                }
            }
        }
        if let Ok(value) = env::var("SPIRAL_SPECTRAL_POLICY_STUCK_TURNOVER_THRESHOLD") {
            if let Ok(threshold) = value.parse::<f32>() {
                if threshold.is_finite() && threshold >= 0.0 {
                    self.stuck_turnover_threshold = threshold.clamp(0.0, 1.0);
                }
            }
        }
        let lr_min = env::var("SPIRAL_SPECTRAL_POLICY_LR_MIN")
            .ok()
            .and_then(|value| value.parse::<f32>().ok());
        let lr_max = env::var("SPIRAL_SPECTRAL_POLICY_LR_MAX")
            .ok()
            .and_then(|value| value.parse::<f32>().ok());
        if let (Some(min), Some(max)) = (lr_min, lr_max) {
            if min.is_finite() && max.is_finite() && min > 0.0 && max > min {
                self.min_lr_scale = min;
                self.max_lr_scale = max;
            }
        }
        let band_min = env::var("SPIRAL_SPECTRAL_POLICY_BAND_MIN")
            .ok()
            .and_then(|value| value.parse::<f32>().ok());
        let band_max = env::var("SPIRAL_SPECTRAL_POLICY_BAND_MAX")
            .ok()
            .and_then(|value| value.parse::<f32>().ok());
        if let (Some(min), Some(max)) = (band_min, band_max) {
            if min.is_finite() && max.is_finite() && min > 0.0 && max > min {
                self.min_band_scale = min;
                self.max_band_scale = max;
            }
        }
        self.max_lr_step = self.max_lr_step.max(1.0);
        self.max_phase_gain = self.max_phase_gain.max(0.0);
        self.phase_gain = self.phase_gain.max(0.0);
        self.stuck_phase_gain = self.stuck_phase_gain.max(0.0);
        self.clamp_state_to_bounds();
    }

    /// Applies environment overrides and returns `self` for fluent construction.
    pub fn with_env_overrides(mut self) -> Self {
        self.apply_env_overrides();
        self
    }

    /// Returns the last semantic coherence label that influenced the policy.
    pub fn last_coherence_label(&self) -> Option<CoherenceLabel> {
        self.last_label
    }

    /// Returns the EMA of dominant channel changes (0 = locked, 1 = swapping every step).
    pub fn dominant_turnover(&self) -> f32 {
        self.dominant_turnover
    }

    pub fn observe(
        &mut self,
        diagnostics: Option<&CoherenceDiagnostics>,
        curvature: f32,
        band_energy: &BandEnergy,
    ) -> Option<SpectralAdjustment> {
        let signal = diagnostics.and_then(CoherenceSignal::from_diagnostics);
        self.observe_signal(signal.as_ref(), curvature, band_energy)
    }

    pub fn observe_signal(
        &mut self,
        diagnostics: Option<&CoherenceSignal>,
        curvature: f32,
        band_energy: &BandEnergy,
    ) -> Option<SpectralAdjustment> {
        let diagnostics = diagnostics?;
        let label = diagnostics.label();
        let sheets = diagnostics.distribution_channels().max(1);
        let dominant = diagnostics.dominant_channel().unwrap_or(0).min(sheets - 1);
        let dominant_changed = self
            .last_dominant
            .map(|previous| previous != dominant)
            .unwrap_or(false);
        self.dominant_turnover = Self::smooth(
            self.dominant_turnover,
            if dominant_changed { 1.0 } else { 0.0 },
            self.turnover_smoothing,
        )
        .clamp(0.0, 1.0);
        self.last_dominant = Some(dominant);
        let label_changed = self
            .last_label
            .map(|previous| previous != label)
            .unwrap_or(false);
        self.last_label = Some(label);
        let smoothing = if label_changed {
            self.event_smoothing.max(self.smoothing)
        } else {
            self.smoothing
        };
        let sheet_ratio = (dominant as f32 + 0.5) / sheets as f32;
        let sheet_bias = (sheet_ratio - 0.5) * self.sheet_gain;
        let spin = diagnostics.z_bias().clamp(-1.0, 1.0);
        let spin_bias = spin * self.spin_gain;
        let spectral_radius = diagnostics.concentration();
        let entropy = diagnostics.normalized_entropy();
        let energy_ratio = diagnostics.energy_ratio();
        let spectral_pressure = diagnostics.spectral_pressure();
        let curvature_term = if curvature < 0.0 {
            (-curvature).sqrt() * self.curvature_gain
        } else {
            0.0
        };
        let radius_bias = (1.0 - spectral_radius).clamp(0.0, 1.0) * self.radius_gain;

        let base_above = 1.0
            + sheet_bias.max(0.0)
            + spin_bias.max(0.0)
            + curvature_term * 0.25
            + radius_bias * 0.5;
        let base_here = 1.0
            + (1.0 - sheet_bias.abs()).max(0.0) * 0.5 * self.sheet_gain
            + curvature_term * 0.5
            + (1.0 - radius_bias) * 0.25;
        let base_beneath = 1.0
            + (-sheet_bias).max(0.0)
            + (-spin_bias).max(0.0)
            + curvature_term * 0.25
            + radius_bias * 0.5;

        let energy_total =
            (band_energy.above.abs() + band_energy.here.abs() + band_energy.beneath.abs())
                .max(1e-5);
        let energy_bias = (
            (band_energy.above / energy_total).clamp(-1.0, 1.0),
            (band_energy.here / energy_total).clamp(-1.0, 1.0),
            (band_energy.beneath / energy_total).clamp(-1.0, 1.0),
        );

        let label_lr_scale = match label {
            CoherenceLabel::Background => {
                if self.dominant_turnover < self.stuck_turnover_threshold {
                    1.05
                } else {
                    1.0
                }
            }
            CoherenceLabel::SymmetricPulse => 0.9,
            CoherenceLabel::CascadeImbalance => 0.7,
            CoherenceLabel::DiffuseDrift => 1.15,
        };
        let label_band_bias = match label {
            CoherenceLabel::CascadeImbalance => (0.92, 1.15, 0.92),
            CoherenceLabel::SymmetricPulse => (0.96, 1.06, 0.96),
            _ => (1.0, 1.0, 1.0),
        };
        let mut phase_gain = match label {
            CoherenceLabel::DiffuseDrift => self.phase_gain * 1.15,
            CoherenceLabel::CascadeImbalance => 0.0,
            CoherenceLabel::SymmetricPulse => self.phase_gain * 0.35,
            CoherenceLabel::Background => self.phase_gain,
        };
        if self.dominant_turnover < self.stuck_turnover_threshold
            && !matches!(label, CoherenceLabel::CascadeImbalance)
        {
            phase_gain += self.stuck_phase_gain;
        }
        phase_gain = phase_gain.clamp(0.0, self.max_phase_gain);
        let phase = dominant % 3;
        let phase_mul = match phase {
            0 => (
                1.0 + phase_gain,
                1.0 - 0.5 * phase_gain,
                1.0 - 0.5 * phase_gain,
            ),
            1 => (
                1.0 - 0.5 * phase_gain,
                1.0 + phase_gain,
                1.0 - 0.5 * phase_gain,
            ),
            _ => (
                1.0 - 0.5 * phase_gain,
                1.0 - 0.5 * phase_gain,
                1.0 + phase_gain,
            ),
        };

        let mut target_band = (
            (base_above * (1.0 + energy_bias.0 * self.energy_gain))
                .clamp(self.min_band_scale, self.max_band_scale),
            (base_here * (1.0 + energy_bias.1 * self.energy_gain))
                .clamp(self.min_band_scale, self.max_band_scale),
            (base_beneath * (1.0 + energy_bias.2 * self.energy_gain))
                .clamp(self.min_band_scale, self.max_band_scale),
        );
        target_band.0 = (target_band.0 * phase_mul.0 * label_band_bias.0)
            .clamp(self.min_band_scale, self.max_band_scale);
        target_band.1 = (target_band.1 * phase_mul.1 * label_band_bias.1)
            .clamp(self.min_band_scale, self.max_band_scale);
        target_band.2 = (target_band.2 * phase_mul.2 * label_band_bias.2)
            .clamp(self.min_band_scale, self.max_band_scale);

        self.band_state.0 = Self::smooth(self.band_state.0, target_band.0, smoothing);
        self.band_state.1 = Self::smooth(self.band_state.1, target_band.1, smoothing);
        self.band_state.2 = Self::smooth(self.band_state.2, target_band.2, smoothing);
        target_band = self.band_state;

        let mean_band = (target_band.0 + target_band.1 + target_band.2) / 3.0;
        let coherence_boost = 1.0 + spectral_pressure * self.coherence_gain;
        let mut target_lr = (mean_band * coherence_boost * label_lr_scale)
            .clamp(self.min_lr_scale, self.max_lr_scale);
        self.lr_state = Self::smooth(self.lr_state, target_lr, smoothing);
        target_lr = self.lr_state.clamp(self.min_lr_scale, self.max_lr_scale);

        let mut target_local = (
            (target_band.0 / mean_band).clamp(self.min_band_scale, self.max_band_scale),
            (target_band.1 / mean_band).clamp(self.min_band_scale, self.max_band_scale),
            (target_band.2 / mean_band).clamp(self.min_band_scale, self.max_band_scale),
        );
        self.local_lr_state.0 = Self::smooth(self.local_lr_state.0, target_local.0, smoothing);
        self.local_lr_state.1 = Self::smooth(self.local_lr_state.1, target_local.1, smoothing);
        self.local_lr_state.2 = Self::smooth(self.local_lr_state.2, target_local.2, smoothing);
        target_local = self.local_lr_state;

        let mut lr_multiplier = 1.0;
        if self.applied_lr_scale.is_finite() && self.applied_lr_scale > 0.0 {
            let max_lr_step = if label_changed {
                (self.max_lr_step * 1.25).max(self.max_lr_step)
            } else {
                self.max_lr_step
            };
            lr_multiplier =
                (target_lr / self.applied_lr_scale).clamp(1.0 / max_lr_step, max_lr_step);
        }
        self.applied_lr_scale =
            (self.applied_lr_scale * lr_multiplier).clamp(self.min_lr_scale, self.max_lr_scale);

        Some(SpectralAdjustment {
            band_scale: target_band,
            lr_multiplier,
            lr_scale: self.applied_lr_scale,
            local_lr: target_local,
            metrics: SpectralAdjustmentMetrics {
                absolute_lr_scale: self.applied_lr_scale,
                sheet_index: diagnostics.dominant_channel().map(|idx| idx as u32),
                sheet_count: sheets as u32,
                spin_alignment: spin,
                raw_mean_coherence: diagnostics.mean_coherence(),
                raw_coherence_entropy: diagnostics.coherence_entropy(),
                spectral_radius,
                spectral_entropy: entropy,
                spectral_pressure,
                effective_channels: diagnostics.effective_channels(),
                distribution_channels: diagnostics.distribution_channels() as u32,
                energy_ratio,
                control_kind: diagnostics.control().kind,
                control_contract_version: diagnostics.control().contract_version,
                control_semantic_owner: diagnostics.control().semantic_owner,
                control_semantic_backend: diagnostics.control().semantic_backend,
                control_formula: diagnostics.control().control_formula,
                classification_reason: diagnostics.classification().reason,
                classification_contract_version: diagnostics.classification().contract_version,
                classification_formula: diagnostics.classification().classification_formula,
                band_scale: target_band,
                local_lr: target_local,
            },
        })
    }

    fn smooth(previous: f32, target: f32, alpha: f32) -> f32 {
        if !previous.is_finite() {
            return target;
        }
        previous + (target - previous) * alpha
    }
}

impl Default for SpectralLearningRatePolicy {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone)]
pub struct SpectralAdjustment {
    pub band_scale: (f32, f32, f32),
    pub lr_multiplier: f32,
    pub lr_scale: f32,
    pub local_lr: (f32, f32, f32),
    pub metrics: SpectralAdjustmentMetrics,
}

#[derive(Debug, Clone)]
pub struct SpectralAdjustmentMetrics {
    pub absolute_lr_scale: f32,
    pub sheet_index: Option<u32>,
    pub sheet_count: u32,
    pub spin_alignment: f32,
    pub raw_mean_coherence: f32,
    pub raw_coherence_entropy: f32,
    pub spectral_radius: f32,
    pub spectral_entropy: f32,
    pub spectral_pressure: f32,
    pub effective_channels: f32,
    pub distribution_channels: u32,
    pub energy_ratio: f32,
    pub control_kind: &'static str,
    pub control_contract_version: &'static str,
    pub control_semantic_owner: &'static str,
    pub control_semantic_backend: &'static str,
    pub control_formula: &'static str,
    pub classification_reason: &'static str,
    pub classification_contract_version: &'static str,
    pub classification_formula: &'static str,
    pub band_scale: (f32, f32, f32),
    pub local_lr: (f32, f32, f32),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TrainerSpectralMetricsSource {
    BandEnergy,
    CoherenceAdjustment,
    Combined,
}

impl TrainerSpectralMetricsSource {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::BandEnergy => "band_energy",
            Self::CoherenceAdjustment => "coherence_adjustment",
            Self::Combined => "combined",
        }
    }
}

#[derive(Debug, Clone)]
pub struct TrainerSpectralMetrics {
    pub source: TrainerSpectralMetricsSource,
    pub turnover: Option<f32>,
    pub label: Option<CoherenceLabel>,
    pub adjustment: Option<SpectralAdjustmentMetrics>,
    pub band_energy: Option<BandEnergy>,
}

#[derive(Debug, Clone)]
struct RewriteBudget {
    per_epoch: u32,
    cooldown: u32,
    used_this_epoch: u32,
    cooldown_left: u32,
}

impl RewriteBudget {
    fn new(per_epoch: u32, cooldown: u32) -> Self {
        Self {
            per_epoch: per_epoch.max(1),
            cooldown,
            used_this_epoch: 0,
            cooldown_left: 0,
        }
    }

    fn begin_epoch(&mut self) {
        if self.cooldown_left > 0 {
            self.cooldown_left -= 1;
        }
        self.used_this_epoch = 0;
    }

    fn try_consume(&mut self, amount: u32) -> bool {
        if amount == 0 {
            return true;
        }
        if self.cooldown_left > 0 {
            return false;
        }
        if self.used_this_epoch.saturating_add(amount) > self.per_epoch {
            self.used_this_epoch = self.per_epoch;
            if self.cooldown > 0 {
                self.cooldown_left = self.cooldown;
            }
            return false;
        }
        self.used_this_epoch += amount;
        if self.used_this_epoch >= self.per_epoch && self.cooldown > 0 {
            self.cooldown_left = self.cooldown;
        }
        true
    }
}

impl ModuleTrainer {
    /// Creates a new trainer with the provided device capabilities and learning rates.
    ///
    /// # Panics
    ///
    /// Panics when optimizer controls violate the Rust contract. Use
    /// [`Self::try_new`] for user-provided or otherwise untrusted controls.
    pub fn new(
        caps: DeviceCaps,
        curvature: f32,
        hyper_learning_rate: f32,
        fallback_learning_rate: f32,
    ) -> Self {
        Self::try_new(caps, curvature, hyper_learning_rate, fallback_learning_rate)
            .expect("invalid ModuleTrainer optimizer configuration")
    }

    /// Tries to create a trainer after validating the Rust-owned optimizer contract.
    pub fn try_new(
        caps: DeviceCaps,
        curvature: f32,
        hyper_learning_rate: f32,
        fallback_learning_rate: f32,
    ) -> Result<Self, TrainerOptimizerConfigError> {
        Self::try_new_with_execution_config(
            caps,
            ExecutionConfig::from_env(),
            curvature,
            hyper_learning_rate,
            fallback_learning_rate,
        )
    }

    /// Creates a trainer bound to an explicit, stable execution contract.
    ///
    /// # Panics
    ///
    /// Panics when optimizer controls violate the Rust contract. Use
    /// [`Self::try_new_with_execution_config`] for untrusted controls.
    pub fn new_with_execution_config(
        caps: DeviceCaps,
        execution_config: ExecutionConfig,
        curvature: f32,
        hyper_learning_rate: f32,
        fallback_learning_rate: f32,
    ) -> Self {
        Self::try_new_with_execution_config(
            caps,
            execution_config,
            curvature,
            hyper_learning_rate,
            fallback_learning_rate,
        )
        .expect("invalid ModuleTrainer optimizer configuration")
    }

    /// Tries to create a trainer bound to an explicit execution contract.
    pub fn try_new_with_execution_config(
        caps: DeviceCaps,
        execution_config: ExecutionConfig,
        curvature: f32,
        hyper_learning_rate: f32,
        fallback_learning_rate: f32,
    ) -> Result<Self, TrainerOptimizerConfigError> {
        Self::try_new_with_execution_context(
            RuntimeExecutionContext::from_device_caps_with_config(caps, execution_config),
            curvature,
            hyper_learning_rate,
            fallback_learning_rate,
        )
    }

    /// Creates a trainer from an already materialized Rust execution context.
    ///
    /// # Panics
    ///
    /// Panics when optimizer controls violate the Rust contract. Use
    /// [`Self::try_new_with_execution_context`] for untrusted controls.
    pub fn new_with_execution_context(
        execution_context: RuntimeExecutionContext,
        curvature: f32,
        hyper_learning_rate: f32,
        fallback_learning_rate: f32,
    ) -> Self {
        Self::try_new_with_execution_context(
            execution_context,
            curvature,
            hyper_learning_rate,
            fallback_learning_rate,
        )
        .expect("invalid ModuleTrainer optimizer configuration")
    }

    /// Tries to create a trainer without rebuilding its execution semantics.
    pub fn try_new_with_execution_context(
        execution_context: RuntimeExecutionContext,
        curvature: f32,
        hyper_learning_rate: f32,
        fallback_learning_rate: f32,
    ) -> Result<Self, TrainerOptimizerConfigError> {
        let optimizer_config = TrainerOptimizerConfig::try_new(
            curvature,
            hyper_learning_rate,
            fallback_learning_rate,
        )?;
        #[cfg(feature = "psi")]
        let psi = Self::init_psi_meter();

        let mut spectral_adapter = SpectralLrAdapter::default().with_sheet_hint(8);
        spectral_adapter.set_curvature_target(optimizer_config.curvature);

        let phase_turnover_spike_threshold =
            env::var("SPIRAL_TRAINER_PHASE_TURNOVER_SPIKE_THRESHOLD")
                .ok()
                .and_then(|value| value.parse::<f32>().ok())
                .filter(|value| value.is_finite() && (0.0..=1.0).contains(value))
                .unwrap_or(0.35);
        let phase_loss_ema_alpha = env::var("SPIRAL_TRAINER_PHASE_LOSS_EMA_ALPHA")
            .ok()
            .and_then(|value| value.parse::<f32>().ok())
            .filter(|value| value.is_finite() && *value > 0.0 && *value <= 1.0)
            .unwrap_or(0.12);
        let phase_loss_spike_ratio = env::var("SPIRAL_TRAINER_PHASE_LOSS_SPIKE_RATIO")
            .ok()
            .and_then(|value| value.parse::<f32>().ok())
            .filter(|value| value.is_finite() && *value >= 0.0)
            .map(|value| value.clamp(0.0, 10.0))
            .unwrap_or(0.25);
        let phase_drift_spike_threshold = env::var("SPIRAL_TRAINER_PHASE_DRIFT_SPIKE_THRESHOLD")
            .ok()
            .and_then(|value| value.parse::<f32>().ok())
            .filter(|value| value.is_finite() && *value >= 0.0)
            .map(|value| value.max(0.0))
            .unwrap_or(0.6);

        Ok(Self {
            epoch: 0,
            execution_context,
            curvature: optimizer_config.curvature,
            hyper_learning_rate: optimizer_config.hyper_learning_rate,
            fallback_learning_rate: optimizer_config.fallback_learning_rate,
            meta_learning_rate_scale: 1.0,
            meta_optimizer_step: None,
            grad_clip_max_norm: None,
            real_learning_rate: None,
            blackcat: None,
            blackcat_moderator: None,
            autopilot: None,
            band_weight_fn: None,
            text_infusion: None,
            injector_enabled: false,
            distribution: None,
            meta_conductor: None,
            heur_log: HeurOpLog::default(),
            rewrite_budget: None,
            softlogic: SoftLogicFlex::new(),
            spectral_adapter,
            accumulator_synchronizer: None,
            last_accumulator_sync: TrainerAccumulatorSyncStats::disabled(),
            cumulative_backend_counters: TrainerBackendCounters::default(),
            desire_bridge: None,
            desire_roundtable_bridge: None,
            last_desire_roundtable_summary: None,
            #[cfg(feature = "psi")]
            desire_psi_bridge: None,
            graph_bridge: None,
            graph_pending: None,
            graph_last_hint: None,
            gnn_roundtable_bridge: None,
            gnn_last_roundtable_signal: None,
            curvature_scheduler: None,
            last_curvature_metrics: None,
            loss_strategy: LossStrategy::default(),
            spectral_policy: None,
            coherence_bridge: None,
            pending_coherence: None,
            last_spectral_metrics: None,
            last_band_energy: None,
            phase_turnover_spike_threshold,
            phase_loss_ema_alpha,
            phase_loss_spike_ratio,
            phase_drift_spike_threshold,
            phase_last_label: None,
            phase_last_turnover: None,
            phase_last_band: None,
            phase_last_drift_abs: None,
            phase_loss_ema: None,
            phase_loss_spiking: false,
            #[cfg(feature = "golden")]
            golden_pulse: None,
            #[cfg(feature = "golden")]
            golden_directive: None,
            #[cfg(feature = "golden")]
            golden_council: None,
            #[cfg(feature = "psi")]
            psi,
            #[cfg(feature = "psychoid")]
            psychoid: None,
            #[cfg(feature = "psychoid")]
            psychoid_log: false,
            #[cfg(feature = "collapse")]
            collapse: None,
        })
    }

    /// Enables the graph consensus feedback loop by attaching a bridge that
    /// drains graph flow telemetry after each optimisation step.
    pub fn enable_graph_feedback(&mut self, bridge: GraphConsensusBridge) {
        self.graph_bridge = Some(bridge);
        self.graph_pending = None;
    }

    /// Enables roundtable-driven adjustments for GNN modules.
    pub fn enable_gnn_roundtable_bridge(&mut self, bridge: RoundtableGnnBridge) {
        self.gnn_roundtable_bridge = Some(bridge);
        self.gnn_last_roundtable_signal = None;
    }

    /// Disables any previously attached GNN roundtable bridge.
    pub fn disable_gnn_roundtable_bridge(&mut self) {
        self.gnn_roundtable_bridge = None;
        self.gnn_last_roundtable_signal = None;
    }

    /// Returns the most recent roundtable signal broadcast to the GNN.
    pub fn gnn_roundtable_signal(&self) -> Option<RoundtableBandSignal> {
        self.gnn_last_roundtable_signal.clone()
    }

    /// Enables desire telemetry feedback so automation and training can share
    /// aggregated summaries without bespoke glue.
    pub fn enable_desire_pipeline(&mut self, bridge: DesireTrainerBridge) {
        self.desire_bridge = Some(bridge);
    }

    /// Enables the roundtable desire braid so Z-space impulses can steer the
    /// A/B/C consensus without bespoke glue.
    pub fn enable_desire_roundtable_bridge(&mut self, bridge: DesireRoundtableBridge) {
        self.desire_roundtable_bridge = Some(bridge);
    }

    /// Bundles desire trainer, roundtable, and ψ bridges so experiments can
    /// attach every compatible telemetry stream in one call.
    pub fn enable_desire_telemetry(&mut self, bundle: &DesireTelemetryBundle) {
        if let Some(bridge) = bundle.trainer_bridge() {
            self.enable_desire_pipeline(bridge.clone());
        }
        if let Some(bridge) = bundle.roundtable_bridge() {
            self.enable_desire_roundtable_bridge(bridge.clone());
        }
        #[cfg(feature = "psi")]
        if let Some(bridge) = bundle.psi_bridge() {
            self.enable_desire_psi_bridge(bridge.clone());
        }
    }

    /// Clears any attached roundtable desire bridge.
    pub fn disable_desire_roundtable_bridge(&mut self) {
        self.desire_roundtable_bridge = None;
        self.last_desire_roundtable_summary = None;
    }

    /// Returns a new trainer with the provided loss strategy.
    pub fn with_loss_strategy(mut self, strategy: LossStrategy) -> Self {
        self.loss_strategy = strategy;
        self
    }

    /// Installs a loss strategy controlling how band losses are aggregated.
    pub fn set_loss_strategy(&mut self, strategy: LossStrategy) {
        self.loss_strategy = strategy;
    }

    /// Configures the trainer to apply region-aware loss weights.
    pub fn enable_region_loss(&mut self, config: RegionLossConfig) {
        self.loss_strategy = LossStrategy::Region(config);
    }

    /// Restores the baseline loss aggregation strategy.
    pub fn disable_region_loss(&mut self) {
        self.loss_strategy = LossStrategy::Baseline;
    }

    /// Returns the currently configured loss strategy.
    pub fn loss_strategy(&self) -> &LossStrategy {
        &self.loss_strategy
    }

    /// Returns the active SoftLogic configuration.
    pub fn softlogic_config(&self) -> SoftLogicConfig {
        self.softlogic.config()
    }

    /// Installs a new SoftLogic configuration (clamped to safe ranges).
    pub fn set_softlogic_config(&mut self, config: SoftLogicConfig) {
        self.softlogic.set_config(config);
    }

    /// Resets SoftLogic state and reloads environment overrides.
    pub fn reset_softlogic(&mut self) {
        self.softlogic = SoftLogicFlex::new();
    }

    /// Surfaces the qualitative coherence observation so schedulers can react.
    pub fn coherence_observation(
        &self,
        diagnostics: &CoherenceDiagnostics,
    ) -> CoherenceObservation {
        diagnostics.observation()
    }

    /// Converts coherence observations into semantic labels.
    pub fn interpret_coherence(&self, diagnostics: &CoherenceDiagnostics) -> CoherenceLabel {
        self.coherence_observation(diagnostics).lift_to_label()
    }

    /// Installs a curvature scheduler so the trainer can adapt its hyperbolic
    /// geometry based on recent gradient pressure observations.
    pub fn enable_curvature_scheduler(&mut self, mut scheduler: CurvatureScheduler) {
        scheduler.apply_env_overrides();
        scheduler.sync(self.curvature);
        self.curvature_scheduler = Some(scheduler);
        self.last_curvature_metrics = None;
        self.spectral_adapter.set_curvature_target(self.curvature);
    }

    /// Disables any configured curvature scheduler and clears cached metrics.
    pub fn disable_curvature_scheduler(&mut self) {
        self.curvature_scheduler = None;
        self.last_curvature_metrics = None;
        self.spectral_adapter.set_curvature_target(self.curvature);
    }

    /// Returns the most recently recorded curvature metrics emitted by the
    /// scheduler, when available.
    pub fn curvature_metrics(&self) -> Option<CurvatureMetrics> {
        self.last_curvature_metrics
    }

    /// Enables the spectral learning rate adaptation policy driven by Z-space coherence.
    pub fn enable_spectral_learning_rate(&mut self, mut policy: SpectralLearningRatePolicy) {
        policy.apply_env_overrides();
        self.spectral_policy = Some(policy);
        self.last_spectral_metrics = None;
        self.last_band_energy = None;
        self.phase_last_label = None;
        self.phase_last_turnover = None;
        self.enable_zspace_trace_coherence_bridge();
    }

    /// Disables the spectral learning rate policy.
    pub fn disable_spectral_learning_rate(&mut self) {
        self.spectral_policy = None;
        self.last_spectral_metrics = None;
        self.last_band_energy = None;
        self.phase_last_label = None;
        self.phase_last_turnover = None;
    }

    /// Publishes fresh coherence diagnostics when their Rust control contract validates.
    pub fn push_coherence_diagnostics(&mut self, diagnostics: CoherenceDiagnostics) -> bool {
        self.pending_coherence = CoherenceSignal::from_diagnostics(&diagnostics);
        self.pending_coherence.is_some()
    }

    /// Enables automatic coherence injection by listening to `ZSpaceTrace` plugin events.
    pub fn enable_zspace_trace_coherence_bridge(&mut self) {
        if self.coherence_bridge.is_none() {
            self.coherence_bridge = Some(ZSpaceTraceCoherenceBridge::subscribe());
        }
    }

    /// Disables any configured ZSpaceTrace coherence bridge.
    pub fn disable_zspace_trace_coherence_bridge(&mut self) {
        self.coherence_bridge = None;
    }

    /// Returns the last recorded spectral metrics, including the most recent
    /// roundtable band snapshot even when coherence adaptation did not fire.
    pub fn spectral_metrics(&self) -> Option<TrainerSpectralMetrics> {
        if self.spectral_policy.is_none() && self.last_spectral_metrics.is_none() {
            return None;
        }
        let adjustment = self.last_spectral_metrics.clone();
        let band_energy = self.last_band_energy;
        let source = match (adjustment.is_some(), band_energy.is_some()) {
            (true, true) => TrainerSpectralMetricsSource::Combined,
            (true, false) => TrainerSpectralMetricsSource::CoherenceAdjustment,
            (false, true) => TrainerSpectralMetricsSource::BandEnergy,
            (false, false) => return None,
        };
        Some(TrainerSpectralMetrics {
            source,
            turnover: self.phase_last_turnover,
            label: self.phase_last_label,
            adjustment,
            band_energy,
        })
    }

    #[cfg(feature = "psi")]
    pub fn enable_desire_psi_bridge(&mut self, bridge: DesirePsiBridge) {
        self.desire_psi_bridge = Some(bridge);
    }

    /// Returns the SpiralK hint generated from the most recently applied graph
    /// digest, if any.
    pub fn graph_hint(&self) -> Option<&str> {
        self.graph_last_hint.as_deref()
    }

    /// Returns the last drained roundtable desire summary, if available.
    pub fn desire_roundtable_summary(&self) -> Option<DesireRoundtableSummary> {
        self.last_desire_roundtable_summary.clone()
    }

    #[cfg(feature = "psi")]
    fn init_psi_meter() -> Option<PsiMeter> {
        let enabled = env::var("SPIRAL_PSI")
            .map(|value| {
                matches!(
                    value.trim().to_ascii_lowercase().as_str(),
                    "1" | "true" | "on"
                )
            })
            .unwrap_or(false);
        if !enabled {
            return None;
        }

        let mut cfg = PsiConfig {
            enabled: true,
            components: PsiComponent::defaults(),
            ..Default::default()
        };

        if let Ok(spec) = env::var("SPIRAL_PSI_COMPONENTS") {
            if let Ok(mask) = PsiComponent::parse_list(&spec) {
                cfg.components = mask;
            }
        }

        if let Ok(alpha_str) = env::var("SPIRAL_PSI_ALPHA") {
            if let Ok(alpha) = alpha_str.parse::<f32>() {
                cfg.ema_alpha = alpha.clamp(1.0e-3, 0.999);
            }
        }

        if let Ok(rate_str) = env::var("SPIRAL_PSI_SAMPLE_RATE") {
            if let Ok(rate) = rate_str.parse::<u32>() {
                cfg.sample_rate = rate.max(1);
            }
        }

        for (var, component) in [
            ("SPIRAL_PSI_WEIGHT_LOSS", PsiComponent::LOSS),
            ("SPIRAL_PSI_WEIGHT_GRAD", PsiComponent::GRAD_NORM),
            ("SPIRAL_PSI_WEIGHT_UPDATE", PsiComponent::UPDATE_RATIO),
            ("SPIRAL_PSI_WEIGHT_ACT", PsiComponent::ACT_DRIFT),
            ("SPIRAL_PSI_WEIGHT_ATTN", PsiComponent::ATTN_ENTROPY),
            ("SPIRAL_PSI_WEIGHT_BAND", PsiComponent::BAND_ENERGY),
        ] {
            if let Ok(weight_str) = env::var(var) {
                if let Ok(weight) = weight_str.parse::<f32>() {
                    cfg.weights.insert(component, weight);
                }
            }
        }

        for (var, component) in [
            ("SPIRAL_PSI_TH_LOSS", PsiComponent::LOSS),
            ("SPIRAL_PSI_TH_GRAD", PsiComponent::GRAD_NORM),
            ("SPIRAL_PSI_TH_UPDATE", PsiComponent::UPDATE_RATIO),
            ("SPIRAL_PSI_TH_ACT", PsiComponent::ACT_DRIFT),
            ("SPIRAL_PSI_TH_ATTN", PsiComponent::ATTN_ENTROPY),
            ("SPIRAL_PSI_TH_BAND", PsiComponent::BAND_ENERGY),
        ] {
            if let Ok(threshold_str) = env::var(var) {
                if let Ok(threshold) = threshold_str.parse::<f32>() {
                    cfg.thresholds.insert(component, threshold);
                }
            }
        }

        Some(PsiMeter::new(cfg))
    }

    /// Attaches the BlackCat runtime so contextual rewards update after each step.
    pub fn with_blackcat(mut self, runtime: BlackCatRuntime) -> Self {
        self.blackcat = Some(runtime);
        self
    }

    /// Installs a Blackcat moderator that seats between local and distributed consensus.
    pub fn install_blackcat_moderator(&mut self, threshold: f32, participants: usize) {
        self.blackcat_moderator = Some(BlackcatModerator::with_default_runtime(
            threshold.max(0.1),
            participants.max(1),
        ));
        self.meta_conductor = None;
    }

    /// Installs a moderator with a custom runtime configuration.
    pub fn install_blackcat_moderator_with_runtime(
        &mut self,
        runtime: BlackCatRuntime,
        threshold: f32,
        participants: usize,
    ) {
        self.blackcat_moderator = Some(BlackcatModerator::new(
            runtime,
            threshold.max(0.1),
            participants.max(1),
        ));
        self.meta_conductor = None;
    }

    /// Clears any configured moderator.
    pub fn clear_blackcat_moderator(&mut self) {
        self.blackcat_moderator = None;
    }

    /// Attaches an Autopilot runtime for contextual kernel selection.
    pub fn with_autopilot(mut self, autopilot: Autopilot) -> Self {
        self.autopilot = Some(autopilot);
        self
    }

    /// Enables per-band reweighting of the loss/gradient.
    pub fn set_band_weights(&mut self, weight_fn: BandWeightFn) {
        self.band_weight_fn = Some(weight_fn);
    }

    /// Connects the trainer to a distributed roundtable node.
    pub fn configure_distribution(&mut self, config: DistConfig) {
        let mut metadata = HashMap::new();
        metadata.insert("node_id".to_string(), config.node_id.clone());
        metadata.insert("mode".to_string(), config.mode.as_str().to_string());
        metadata.insert(
            "push_interval_ms".to_string(),
            config
                .push_interval
                .as_millis()
                .min(u64::MAX as u128)
                .to_string(),
        );
        metadata.insert(
            "summary_window".to_string(),
            config.summary_window.to_string(),
        );
        if !config.meta_endpoints.is_empty() {
            metadata.insert(
                "meta_endpoints".to_string(),
                config.meta_endpoints.join(","),
            );
        }

        append_cloud_targets(&mut metadata, &config.cloud_targets);
        self.log_connector_event("configure_distribution", metadata);
        self.distribution = Some(RoundtableNode::new(config));
    }

    /// Removes any configured distribution node.
    pub fn clear_distribution(&mut self) {
        if let Some(node) = self.distribution.as_mut() {
            node.drain();
        }
        if self.distribution.is_some() {
            self.log_connector_event("clear_distribution", HashMap::new());
        }
        self.distribution = None;
    }

    /// Returns the currently configured distribution node, if any.
    pub fn distribution_config(&self) -> Option<&DistConfig> {
        self.distribution.as_ref().map(|node| node.config())
    }

    /// Installs a meta-layer conductor so this trainer can aggregate remote summaries.
    pub fn install_meta_conductor(&mut self, threshold: f32, participants: usize) {
        self.blackcat_moderator = None;
        self.meta_conductor = Some(MetaConductor::new(threshold.max(0.1), participants.max(1)));
    }

    /// Returns the current heuristics op-log.
    pub fn heuristics_log(&self) -> &HeurOpLog {
        &self.heur_log
    }

    /// Merges the provided heuristics log into the trainer's local log.
    pub fn merge_heuristics_log(&mut self, log: &HeurOpLog) {
        self.heur_log.merge(log);
    }

    /// Returns the latest moderator minutes captured by Blackcat.
    pub fn blackcat_minutes(&self) -> Vec<ModeratorMinutes> {
        self.blackcat_moderator
            .as_ref()
            .map(|m| m.minutes().to_vec())
            .unwrap_or_default()
    }

    /// Returns the aggregated scoreboard derived from the local Blackcat moderator.
    pub fn blackcat_scoreboard(&self) -> Vec<BlackcatScore> {
        self.blackcat_moderator
            .as_ref()
            .map(|m| m.scoreboard())
            .unwrap_or_default()
    }

    /// Returns aggregated stats tracked by the embedded Blackcat runtime, when available.
    pub fn blackcat_runtime_stats(&self) -> Option<BlackcatRuntimeStats> {
        self.blackcat.as_ref().map(|rt| rt.stats())
    }

    /// Returns the last canonical Rust free-energy report committed by BlackCat.
    pub fn blackcat_free_energy_report(&self) -> Option<&FreeEnergyReport> {
        self.blackcat
            .as_ref()
            .and_then(BlackCatRuntime::last_free_energy_report)
    }

    /// Returns the latest cumulative, evidence-backed heuristic adoption report.
    pub fn blackcat_heuristic_adoption_report(&self) -> Option<&SoftHeuristicAdoptionReport> {
        self.blackcat
            .as_ref()
            .and_then(BlackCatRuntime::last_heuristic_adoption_report)
    }

    /// Replays moderator minutes so the embedded Blackcat runtime can stay aligned.
    pub fn sync_blackcat_minutes(&mut self, minutes: &[ModeratorMinutes]) {
        if let Some(moderator) = self.blackcat_moderator.as_mut() {
            moderator.absorb_minutes(minutes);
        }
    }

    #[cfg(feature = "golden")]
    /// Applies a cooperative pulse emitted by the Golden retriever.
    pub fn apply_blackcat_pulse(&mut self, pulse: &GoldenBlackcatPulse) {
        self.golden_pulse = Some(pulse.clone());
        self.golden_directive = None;
        if let Some(node) = self.distribution.as_mut() {
            let base_interval = node.config().push_interval;
            let base_window = node.config().summary_window.max(1);
            let directive = pulse.directive(base_interval, base_window);
            node.retune(directive.push_interval, directive.summary_window);
            if directive.reinforcement_weight > 0.1 {
                self.injector_enabled = true;
            }
            self.golden_directive = Some(directive);
        } else if pulse.reinforcement_weight > 0.1 || pulse.optimization_gain > 0.1 {
            self.injector_enabled = true;
        }
    }

    #[cfg(feature = "golden")]
    pub(crate) fn record_golden_council(&mut self, snapshot: &GoldenCouncilSnapshot) {
        self.golden_council = Some(snapshot.clone());
    }

    #[cfg(feature = "golden")]
    /// Returns the most recent cooperative pulse applied to this trainer.
    pub fn last_blackcat_pulse(&self) -> Option<&GoldenBlackcatPulse> {
        self.golden_pulse.as_ref()
    }

    #[cfg(feature = "golden")]
    /// Returns the latest cooperative directive derived from the Golden pulse.
    pub fn last_blackcat_directive(&self) -> Option<&GoldenCooperativeDirective> {
        self.golden_directive.as_ref()
    }

    #[cfg(feature = "golden")]
    /// Returns the latest self-rewrite council snapshot received from GoldenRetriever.
    pub fn last_golden_council_snapshot(&self) -> Option<&GoldenCouncilSnapshot> {
        self.golden_council.as_ref()
    }

    #[cfg(feature = "golden")]
    /// Returns a clone of the latest council snapshot for downstream mutation.
    pub fn last_council(&self) -> Option<GoldenCouncilSnapshot> {
        self.golden_council.clone()
    }

    /// Configures how many rewrite operations may be applied per epoch and the cooldown required
    /// before new rewrites are accepted.
    pub fn set_rewrite_budget(&mut self, per_epoch: u32, cooldown: u32) {
        if per_epoch == 0 {
            self.rewrite_budget = None;
        } else {
            self.rewrite_budget = Some(RewriteBudget::new(per_epoch, cooldown));
        }
    }

    /// Clears any registered band weighting rule.
    pub fn clear_band_weights(&mut self) {
        self.band_weight_fn = None;
    }

    /// Enables or disables the adaptive injector heuristics.
    pub fn enable_injector(&mut self, on: bool) {
        self.injector_enabled = on;
    }

    /// Returns the underlying planner.
    pub fn planner(&self) -> &RankPlanner {
        self.execution_context.planner()
    }

    /// Returns the single execution context used by planning and tensor kernels.
    pub fn execution_context(&self) -> &RuntimeExecutionContext {
        &self.execution_context
    }

    /// Returns the executable tensor policy currently bound to this trainer.
    pub fn backend_policy(&self) -> BackendPolicy {
        self.execution_context.backend_policy()
    }

    /// Returns the canonical plan retained by a plan-bound trainer.
    pub fn runtime_execution_plan(&self) -> Option<&RuntimeExecutionPlanPayload> {
        self.execution_context.runtime_execution_plan()
    }

    /// Returns the commitment identifying the bound canonical execution plan.
    pub fn runtime_execution_plan_output_sha256(&self) -> Option<String> {
        self.execution_context
            .runtime_execution_plan_output_sha256()
    }

    /// Atomically binds a validated canonical execution plan to this trainer.
    pub fn bind_runtime_execution_plan(
        &mut self,
        plan: &RuntimeExecutionPlanPayload,
    ) -> Result<(), RuntimeExecutionPlanError> {
        let execution_context = RuntimeExecutionContext::try_from_runtime_plan(plan)?;
        self.execution_context = execution_context;
        Ok(())
    }

    /// Produces the static baseline schedule for the provided output dimensions.
    ///
    /// An attached Autopilot is deliberately not consulted here. Adaptive
    /// selection, execution, and reward credit are kept inside one
    /// [`Self::train_epoch`] step so a suggested arm cannot be credited for a
    /// different schedule.
    pub fn roundtable(
        &mut self,
        rows: u32,
        cols: u32,
        config: RoundtableConfig,
    ) -> RoundtableSchedule {
        let schedule = RoundtableSchedule::new(self.planner(), rows, cols, config);
        let bus = global_registry().event_bus();
        if bus.has_listeners("RoundtablePlanned") {
            let encode_plan = |plan: &RankPlan| {
                serde_json::json!({
                    "kind": plan.kind.as_str(),
                    "rows": plan.rows,
                    "cols": plan.cols,
                    "k": plan.k,
                    "choice": {
                        "subgroup": plan.choice.subgroup,
                        "use_2ce": plan.choice.use_2ce,
                        "wg": plan.choice.wg,
                        "kl": plan.choice.kl,
                        "ch": plan.choice.ch,
                        "tile": plan.choice.tile,
                        "ctile": plan.choice.ctile,
                        "fft_tile": plan.choice.fft_tile,
                        "fft_radix": plan.choice.fft_radix,
                        "fft_segments": plan.choice.fft_segments,
                    }
                })
            };
            bus.publish(&PluginEvent::custom(
                "RoundtablePlanned",
                serde_json::json!({
                    "rows": rows,
                    "cols": cols,
                    "config": {
                        "top_k": config.top_k,
                        "mid_k": config.mid_k,
                        "bottom_k": config.bottom_k,
                        "here_tolerance": config.here_tolerance,
                    },
                    "autopilot_enabled": self.autopilot.is_some(),
                    "autopilot_scope": if self.autopilot.is_some() {
                        "train_step"
                    } else {
                        "disabled"
                    },
                    "autopilot_picks": serde_json::Value::Null,
                    "bands": {
                        "above": encode_plan(schedule.above()),
                        "here": encode_plan(schedule.here()),
                        "beneath": encode_plan(schedule.beneath()),
                    },
                }),
            ));
        }
        self.emit_roundtable_summary(rows, cols, config, &schedule);
        schedule
    }

    fn emit_roundtable_summary(
        &self,
        rows: u32,
        cols: u32,
        config: RoundtableConfig,
        schedule: &RoundtableSchedule,
    ) {
        let pipeline = crate::language::LanguagePipeline::builder("module_trainer")
            .with_tag("component", "module_trainer")
            .build();
        pipeline.record_roundtable(
            rows,
            cols,
            config,
            schedule,
            self.autopilot.is_some(),
            self.distribution.as_ref(),
        );
        let cfg_summary = {
            #[allow(unused_mut)]
            let mut summary = RoundtableConfigSummary::new(
                config.top_k,
                config.mid_k,
                config.bottom_k,
                config.here_tolerance,
            );
            #[cfg(feature = "psychoid")]
            {
                summary
                    .extras
                    .insert("psychoid".to_string(), config.psychoid_enabled);
                if config.psychoid_log {
                    summary.extras.insert("psychoid_log".to_string(), true);
                }
            }
            #[cfg(feature = "psi")]
            {
                summary.extras.insert("psi".to_string(), config.psi_enabled);
            }
            #[cfg(feature = "collapse")]
            {
                summary
                    .extras
                    .insert("collapse".to_string(), config.collapse_enabled);
            }
            summary
        };

        let plans = vec![
            Self::summarize_rank_plan(schedule.above()),
            Self::summarize_rank_plan(schedule.here()),
            Self::summarize_rank_plan(schedule.beneath()),
        ];

        let distribution = self.distribution.as_ref().map(|node| {
            let cfg = node.config();
            DistributionSummary {
                node_id: cfg.node_id.clone(),
                mode: cfg.mode.as_str().to_string(),
                summary_window: cfg.summary_window,
                push_interval_ms: cfg.push_interval.as_millis().min(u64::MAX as u128) as u64,
                meta_endpoints: cfg.meta_endpoints.clone(),
                cloud_targets: cfg.cloud_targets.clone(),
            }
        });

        let summary = RoundtableSummary {
            rows,
            cols,
            config: cfg_summary,
            plans,
            autopilot_enabled: self.autopilot.is_some(),
            distribution,
            issued_at: SystemTime::now(),
        };

        let registry = EcosystemRegistry::global();
        let autopilot_tag = summary.autopilot_enabled.to_string();
        let distribution_mode = summary.distribution.as_ref().map(|d| d.mode.clone());
        let tag_sample = |sample: MetricSample| {
            let mut sample = sample.with_tag("autopilot", autopilot_tag.as_str());
            if let Some(mode) = &distribution_mode {
                sample = sample.with_tag("distribution_mode", mode.clone());
            }
            sample
        };

        registry.record_metric(tag_sample(
            MetricSample::new("roundtable.rows", rows as f64).with_unit("rows"),
        ));
        registry.record_metric(tag_sample(
            MetricSample::new("roundtable.cols", cols as f64).with_unit("cols"),
        ));
        registry.record_metric(tag_sample(
            MetricSample::new(
                "roundtable.autopilot",
                if summary.autopilot_enabled { 1.0 } else { 0.0 },
            )
            .with_unit("flag"),
        ));
        registry.record_metric(tag_sample(
            MetricSample::new("roundtable.config.top_k", config.top_k as f64).with_unit("items"),
        ));
        registry.record_metric(tag_sample(
            MetricSample::new("roundtable.config.mid_k", config.mid_k as f64).with_unit("items"),
        ));
        registry.record_metric(tag_sample(
            MetricSample::new("roundtable.config.bottom_k", config.bottom_k as f64)
                .with_unit("items"),
        ));
        registry.record_metric(tag_sample(
            MetricSample::new(
                "roundtable.config.here_tolerance",
                config.here_tolerance as f64,
            )
            .with_unit("ratio"),
        ));

        let plan_summaries = [
            ("above", schedule.above()),
            ("here", schedule.here()),
            ("beneath", schedule.beneath()),
        ];
        for (band, plan) in plan_summaries {
            let tag_band = |sample: MetricSample| tag_sample(sample.with_tag("band", band));
            registry.record_metric(tag_band(
                MetricSample::new("roundtable.band.rows", plan.rows as f64).with_unit("rows"),
            ));
            registry.record_metric(tag_band(
                MetricSample::new("roundtable.band.cols", plan.cols as f64).with_unit("cols"),
            ));
            registry.record_metric(tag_band(
                MetricSample::new("roundtable.band.k", plan.k as f64).with_unit("items"),
            ));
            registry.record_metric(tag_band(
                MetricSample::new("roundtable.band.workgroup", plan.choice.wg as f64)
                    .with_unit("threads"),
            ));
            registry.record_metric(tag_band(
                MetricSample::new("roundtable.band.lanes", plan.choice.kl as f64)
                    .with_unit("lanes"),
            ));
            registry.record_metric(tag_band(
                MetricSample::new("roundtable.band.channel_stride", plan.choice.ch as f64)
                    .with_unit("stride"),
            ));
            registry.record_metric(tag_band(
                MetricSample::new("roundtable.band.tile", plan.choice.tile as f64)
                    .with_unit("tile"),
            ));
            registry.record_metric(tag_band(
                MetricSample::new("roundtable.band.compaction_tile", plan.choice.ctile as f64)
                    .with_unit("tile"),
            ));
            registry.record_metric(tag_band(
                MetricSample::new(
                    "roundtable.band.subgroup",
                    if plan.choice.subgroup { 1.0 } else { 0.0 },
                )
                .with_unit("flag"),
            ));
            registry.record_metric(tag_band(
                MetricSample::new("roundtable.band.fft_tile", plan.choice.fft_tile as f64)
                    .with_unit("tile"),
            ));
            registry.record_metric(tag_band(
                MetricSample::new("roundtable.band.fft_radix", plan.choice.fft_radix as f64)
                    .with_unit("radix"),
            ));
            registry.record_metric(tag_band(
                MetricSample::new(
                    "roundtable.band.fft_segments",
                    plan.choice.fft_segments as f64,
                )
                .with_unit("segments"),
            ));
        }

        registry.record_roundtable(summary);
    }

    fn summarize_rank_plan(plan: &RankPlan) -> RankPlanSummary {
        let mut summary = RankPlanSummary::new(plan.kind, plan.rows, plan.cols, plan.k);
        summary.workgroup = plan.choice.wg;
        summary.lanes = plan.choice.kl;
        summary.channel_stride = plan.choice.ch;
        summary.tile = plan.choice.tile;
        summary.compaction_tile = plan.choice.ctile;
        summary.subgroup = plan.choice.subgroup;
        summary.fft_tile = plan.choice.fft_tile;
        summary.fft_radix = plan.choice.fft_radix;
        summary.fft_segments = plan.choice.fft_segments;
        summary
    }

    fn log_connector_event(&self, stage: &str, metadata: HashMap<String, String>) {
        EcosystemRegistry::global().record_connector(ConnectorEvent {
            name: "module_trainer".to_string(),
            stage: stage.to_string(),
            metadata,
            issued_at: SystemTime::now(),
        });
    }

    /// Returns the fallback Euclidean learning rate.
    pub fn fallback_learning_rate(&self) -> f32 {
        self.fallback_learning_rate
    }

    fn accumulator_synchronizer_snapshot(&self) -> (bool, usize, usize) {
        if let Some(device) = self.accumulator_synchronizer.as_ref() {
            return (true, device.rank(), device.world_size());
        }
        (false, 0, 1)
    }

    fn optimizer_external_state_required(&self) -> Vec<String> {
        let mut components = Vec::new();
        if self.blackcat.is_some() {
            components.push("blackcat_runtime");
        }
        if self.blackcat_moderator.is_some() {
            components.push("blackcat_moderator");
        }
        if self.autopilot.is_some() {
            components.push("autopilot");
        }
        if self.band_weight_fn.is_some() {
            components.push("band_weight_function");
        }
        if self.text_infusion.is_some() {
            components.push("text_infusion");
        }
        if self.injector_enabled {
            components.push("injector");
        }
        if self.distribution.is_some() {
            components.push("roundtable_distribution");
        }
        if self.meta_conductor.is_some() {
            components.push("meta_conductor");
        }
        if self.rewrite_budget.is_some() {
            components.push("rewrite_budget");
        }
        if self.accumulator_synchronizer.is_some() {
            components.push("accumulator_synchronizer");
        }
        if self.desire_bridge.is_some() {
            components.push(DESIRE_TRAINER_COMPONENT);
        }
        if self.desire_roundtable_bridge.is_some() {
            components.push("desire_roundtable_bridge");
        }
        #[cfg(feature = "psi")]
        if self.desire_psi_bridge.is_some() {
            components.push("desire_psi_bridge");
        }
        if self.graph_bridge.is_some() || self.graph_pending.is_some() {
            components.push("graph_consensus_bridge");
        }
        if self.gnn_roundtable_bridge.is_some() {
            components.push(GNN_ROUNDTABLE_BRIDGE_COMPONENT);
        }
        if self.coherence_bridge.is_some() || self.pending_coherence.is_some() {
            components.push(COHERENCE_BRIDGE_COMPONENT);
        }
        if matches!(&self.loss_strategy, LossStrategy::Region(_)) {
            components.push("region_loss_strategy");
        }
        #[cfg(feature = "golden")]
        if self.golden_pulse.is_some()
            || self.golden_directive.is_some()
            || self.golden_council.is_some()
        {
            components.push("golden_runtime");
        }
        #[cfg(feature = "psi")]
        if self.psi.is_some() {
            components.push("psi_meter");
        }
        #[cfg(feature = "psychoid")]
        if self.psychoid.is_some() {
            components.push("psychoid_meter");
        }
        #[cfg(feature = "collapse")]
        if self.collapse.is_some() {
            components.push("collapse_drive");
        }
        components.sort_unstable();
        components.dedup();
        components.into_iter().map(str::to_owned).collect()
    }

    fn optimizer_execution_topology(&self) -> TrainerExecutionTopology {
        let caps = self.planner().device_caps();
        let execution = self.planner().execution_config();
        let (training_device_enabled, training_rank, training_world_size) =
            self.accumulator_synchronizer_snapshot();
        TrainerExecutionTopology {
            backend: caps.backend.as_str().to_owned(),
            subgroup: caps.subgroup,
            lane_width: caps.lane_width,
            max_workgroup: caps.max_workgroup,
            shared_mem_per_workgroup: caps.shared_mem_per_workgroup,
            accelerator_fallback: execution.accelerator_fallback.as_str().to_owned(),
            tensor_util_wgpu_min_values: execution.tensor_util_wgpu_min_values,
            runtime_execution_plan_output_sha256: self.runtime_execution_plan_output_sha256(),
            training_device_enabled,
            training_rank,
            training_world_size,
            external_state_required: self.optimizer_external_state_required(),
        }
    }

    fn optimizer_phase_tracker_state(&self) -> TrainerPhaseTrackerState {
        TrainerPhaseTrackerState {
            turnover_spike_threshold: self.phase_turnover_spike_threshold,
            loss_ema_alpha: self.phase_loss_ema_alpha,
            loss_spike_ratio: self.phase_loss_spike_ratio,
            drift_spike_threshold: self.phase_drift_spike_threshold,
            last_label: self.phase_last_label,
            last_turnover: self.phase_last_turnover,
            last_band: self.phase_last_band,
            last_drift_abs: self.phase_last_drift_abs,
            loss_ema: self.phase_loss_ema,
            loss_spiking: self.phase_loss_spiking,
        }
    }

    /// Returns a copyable optimizer-facing state snapshot.
    pub fn optimizer_state(&self) -> TrainerOptimizerState {
        let (training_device_enabled, training_rank, training_world_size) =
            self.accumulator_synchronizer_snapshot();
        TrainerOptimizerState {
            epoch: self.epoch,
            curvature: self.curvature,
            hyper_learning_rate: self.hyper_learning_rate,
            fallback_learning_rate: self.fallback_learning_rate,
            real_learning_rate: self.real_learning_rate,
            meta_learning_rate_scale: self.meta_learning_rate_scale,
            meta_optimizer_step: self.meta_optimizer_step,
            grad_clip_max_norm: self.grad_clip_max_norm,
            spectral_policy_enabled: self.spectral_policy.is_some(),
            curvature_scheduler_enabled: self.curvature_scheduler.is_some(),
            training_device_enabled,
            training_rank,
            training_world_size,
            spectral_adapter: self.spectral_adapter.state(),
            backend_counters: self.cumulative_backend_counters,
        }
    }

    /// Returns the optimizer controls as the canonical Rust-owned config.
    pub fn optimizer_config(&self) -> TrainerOptimizerConfig {
        TrainerOptimizerConfig {
            curvature: self.curvature,
            hyper_learning_rate: self.hyper_learning_rate,
            fallback_learning_rate: self.fallback_learning_rate,
            real_learning_rate: self.real_learning_rate,
            grad_clip_max_norm: self.grad_clip_max_norm,
        }
    }

    /// Evaluates the current controls through the versioned semantic contract.
    pub fn optimizer_config_contract(
        &self,
    ) -> Result<TrainerOptimizerConfigContract, TrainerOptimizerConfigError> {
        evaluate_trainer_optimizer_config(self.optimizer_config())
    }

    /// Captures the supported runtime components outside optimizer ownership.
    ///
    /// Unsupported components remain explicit in the unresolved component list.
    pub fn external_state_checkpoint(
        &self,
    ) -> Result<TrainerExternalStateCheckpoint, TrainerCheckpointError> {
        let (desire_trainer, desire_roundtable) = checkpoint_desire_bridges(
            self.desire_bridge.as_ref(),
            self.desire_roundtable_bridge.as_ref(),
        )?;
        #[cfg(feature = "psi")]
        let psi_meter = self
            .psi
            .as_ref()
            .map(PsiMeter::checkpoint)
            .transpose()
            .map_err(TrainerExternalCheckpointError::from)?;
        #[cfg(not(feature = "psi"))]
        let psi_meter = None;
        let coherence_bridge = self.coherence_bridge_checkpoint()?;
        let gnn_roundtable_bridge = self.gnn_roundtable_bridge_checkpoint()?;
        let accumulator_synchronizer = self
            .accumulator_synchronizer
            .as_ref()
            .map(|synchronizer| synchronizer.checkpoint())
            .transpose()?;
        Ok(build_trainer_external_state_checkpoint_from_components(
            self.optimizer_external_state_required(),
            TrainerExternalCheckpointComponents::new()
                .with_desire_trainer(desire_trainer)
                .with_desire_roundtable(desire_roundtable)
                .with_coherence_bridge(coherence_bridge)
                .with_gnn_roundtable_bridge(gnn_roundtable_bridge)
                .with_psi_meter(psi_meter)
                .with_accumulator_synchronizer(accumulator_synchronizer),
        )?)
    }

    fn coherence_bridge_checkpoint(
        &self,
    ) -> Result<Option<TrainerCoherenceBridgeCheckpoint>, TrainerExternalCheckpointError> {
        if self.coherence_bridge.is_none() && self.pending_coherence.is_none() {
            return Ok(None);
        }
        let checkpoint = TrainerCoherenceBridgeCheckpoint {
            subscribed: self.coherence_bridge.is_some(),
            pending: self
                .pending_coherence
                .as_ref()
                .map(CoherenceSignal::checkpoint)
                .transpose()?,
            latest: self
                .coherence_bridge
                .as_ref()
                .and_then(ZSpaceTraceCoherenceBridge::checkpoint_latest)
                .as_ref()
                .map(CoherenceSignal::checkpoint)
                .transpose()?,
        };
        checkpoint.validate()?;
        Ok(Some(checkpoint))
    }

    fn gnn_roundtable_bridge_checkpoint(
        &self,
    ) -> Result<Option<TrainerGnnRoundtableBridgeCheckpoint>, TrainerExternalCheckpointError> {
        let Some(bridge) = self.gnn_roundtable_bridge.as_ref() else {
            return Ok(None);
        };
        let state = bridge.snapshot_state();
        let history_limit = u64::try_from(state.history_limit).map_err(|_| {
            TrainerExternalCheckpointError::InvalidState {
                field: "gnn_roundtable_bridge.history_limit".to_owned(),
                message: "does not fit the portable checkpoint domain".to_owned(),
            }
        })?;
        let history = state
            .history
            .iter()
            .enumerate()
            .map(|(index, signal)| {
                gnn_roundtable_signal_checkpoint(
                    signal,
                    &format!("gnn_roundtable_bridge.history[{index}]"),
                )
            })
            .collect::<Result<Vec<_>, _>>()?;
        let latest = state
            .latest
            .as_ref()
            .map(|signal| gnn_roundtable_signal_checkpoint(signal, "gnn_roundtable_bridge.latest"))
            .transpose()?;
        let trainer_last = self
            .gnn_last_roundtable_signal
            .as_ref()
            .map(|signal| {
                gnn_roundtable_signal_checkpoint(signal, "gnn_roundtable_bridge.trainer_last")
            })
            .transpose()?;
        let checkpoint = TrainerGnnRoundtableBridgeCheckpoint {
            history_limit,
            history,
            latest,
            trainer_last,
        };
        checkpoint.validate()?;
        Ok(Some(checkpoint))
    }

    /// Restores supported external state after concrete resources are attached.
    ///
    /// Resource identity and all replacement state are validated before any
    /// trainer-owned component is mutated.
    pub fn restore_external_state_checkpoint(
        &mut self,
        checkpoint: &TrainerExternalStateCheckpoint,
    ) -> Result<TrainerExternalCheckpointValidation, TrainerCheckpointError> {
        let prepared = self.prepare_external_state_checkpoint_restore(checkpoint)?;
        self.commit_external_state_checkpoint_restore(prepared)
    }

    fn prepare_external_state_checkpoint_restore(
        &self,
        checkpoint: &TrainerExternalStateCheckpoint,
    ) -> Result<PreparedTrainerExternalRestore, TrainerCheckpointError> {
        evaluate_trainer_external_state_checkpoint(checkpoint)?;
        let mut target_components = self.optimizer_external_state_required();
        if checkpoint.coherence_bridge.is_some()
            && target_components
                .binary_search_by(|component| component.as_str().cmp(COHERENCE_BRIDGE_COMPONENT))
                .is_err()
        {
            target_components.push(COHERENCE_BRIDGE_COMPONENT.to_owned());
        }
        #[cfg(feature = "psi")]
        if checkpoint.psi_meter.is_some()
            && target_components
                .binary_search_by(|component| component.as_str().cmp(PSI_METER_COMPONENT))
                .is_err()
        {
            target_components.push(PSI_METER_COMPONENT.to_owned());
        }
        target_components.sort_unstable();
        target_components.dedup();
        if checkpoint.required_components != target_components {
            return Err(TrainerCheckpointError::ExternalComponentSetMismatch);
        }

        let desire_trainer = checkpoint
            .desire_trainer
            .as_ref()
            .map(DesireTrainerBridge::prepare_checkpoint_restore)
            .transpose()?;
        if desire_trainer.is_some() && self.desire_bridge.is_none() {
            return Err(TrainerCheckpointError::ExternalComponentSetMismatch);
        }
        let desire_roundtable = checkpoint
            .desire_roundtable
            .map(DesireRoundtableBridge::prepare_checkpoint_restore)
            .transpose()?;
        if desire_roundtable.is_some() && self.desire_roundtable_bridge.is_none() {
            return Err(TrainerCheckpointError::ExternalComponentSetMismatch);
        }
        let coherence_bridge = checkpoint
            .coherence_bridge
            .as_ref()
            .map(PreparedTrainerCoherenceBridgeCheckpoint::prepare)
            .transpose()?;
        let gnn_roundtable_bridge = checkpoint
            .gnn_roundtable_bridge
            .as_ref()
            .map(PreparedTrainerGnnRoundtableBridgeCheckpoint::prepare)
            .transpose()?;
        if gnn_roundtable_bridge.is_some() && self.gnn_roundtable_bridge.is_none() {
            return Err(TrainerCheckpointError::ExternalComponentSetMismatch);
        }

        #[cfg(feature = "psi")]
        let psi_meter = checkpoint
            .psi_meter
            .clone()
            .map(PsiMeter::from_checkpoint)
            .transpose()
            .map_err(TrainerExternalCheckpointError::from)?;
        #[cfg(not(feature = "psi"))]
        if checkpoint.psi_meter.is_some() {
            return Err(TrainerCheckpointError::ExternalComponentSetMismatch);
        }

        let mut reattached_components = Vec::new();
        if let Some(accumulator) = checkpoint.accumulator_synchronizer.as_ref() {
            let synchronizer = self
                .accumulator_synchronizer
                .as_ref()
                .ok_or(TrainerCheckpointError::ExternalComponentSetMismatch)?;
            synchronizer.validate_checkpoint(accumulator)?;
            reattached_components.push(ACCUMULATOR_SYNCHRONIZER_COMPONENT.to_owned());
        }
        let validation =
            evaluate_trainer_external_state_restore(checkpoint, &reattached_components)?;

        Ok(PreparedTrainerExternalRestore {
            validation,
            desire_trainer,
            desire_roundtable,
            coherence_bridge,
            gnn_roundtable_bridge,
            #[cfg(feature = "psi")]
            psi_meter,
            reattached_components,
        })
    }

    fn commit_external_state_checkpoint_restore(
        &mut self,
        prepared: PreparedTrainerExternalRestore,
    ) -> Result<TrainerExternalCheckpointValidation, TrainerCheckpointError> {
        commit_desire_checkpoint_restore(
            self.desire_bridge.as_ref(),
            prepared.desire_trainer,
            self.desire_roundtable_bridge.as_ref(),
            prepared.desire_roundtable,
        )?;
        if let Some(coherence) = prepared.coherence_bridge {
            self.pending_coherence = coherence.pending;
            if coherence.subscribed {
                if let Some(bridge) = self.coherence_bridge.as_ref() {
                    bridge.restore_latest(coherence.latest);
                } else {
                    self.coherence_bridge = Some(
                        ZSpaceTraceCoherenceBridge::subscribe_with_latest(coherence.latest),
                    );
                }
            } else {
                self.coherence_bridge = None;
            }
        }
        if let Some(gnn_roundtable) = prepared.gnn_roundtable_bridge {
            self.gnn_roundtable_bridge
                .as_ref()
                .expect("GNN roundtable bridge checked during restore preparation")
                .restore_state(gnn_roundtable.state);
            self.gnn_last_roundtable_signal = gnn_roundtable.trainer_last;
        }
        #[cfg(feature = "psi")]
        if let Some(psi_meter) = prepared.psi_meter {
            self.psi = Some(psi_meter);
        }
        Ok(prepared.validation)
    }

    /// Captures trainer update policy and every parameter accumulator.
    ///
    /// Parameter values remain in [`Module::state_dict`]. Their fingerprints
    /// make restoring optimizer state against the wrong model fail closed.
    pub fn optimizer_checkpoint<M: Module + ?Sized>(
        &self,
        module: &M,
    ) -> Result<TrainerOptimizerCheckpoint, TrainerCheckpointError> {
        let mut parameters = Vec::new();
        module.visit_parameters(&mut |parameter| {
            parameters.push(parameter.optimizer_checkpoint_state());
            Ok(())
        })?;
        let epoch =
            u64::try_from(self.epoch).map_err(|_| TrainerCheckpointError::CounterOutOfRange {
                field: "epoch",
                value: u64::MAX,
            })?;
        let state = TrainerOptimizerRuntimeState {
            epoch,
            meta_learning_rate_scale: self.meta_learning_rate_scale,
            meta_optimizer_step: self.meta_optimizer_step,
            spectral_adapter: self.spectral_adapter.state(),
            curvature_scheduler: self
                .curvature_scheduler
                .as_ref()
                .map(CurvatureScheduler::state),
            spectral_policy: self
                .spectral_policy
                .as_ref()
                .map(SpectralLearningRatePolicy::state),
            phase_tracker: self.optimizer_phase_tracker_state(),
            softlogic: self.softlogic.state(),
            backend_counters: self.cumulative_backend_counters,
            last_accumulator_sync_buffers: u64::try_from(self.last_accumulator_sync.buffers)
                .map_err(|_| TrainerCheckpointError::CounterOutOfRange {
                    field: "last_accumulator_sync_buffers",
                    value: u64::MAX,
                })?,
            last_accumulator_sync_values: u64::try_from(self.last_accumulator_sync.values)
                .map_err(|_| TrainerCheckpointError::CounterOutOfRange {
                    field: "last_accumulator_sync_values",
                    value: u64::MAX,
                })?,
        };
        Ok(build_trainer_optimizer_checkpoint(
            self.optimizer_config(),
            self.optimizer_execution_topology(),
            state,
            parameters,
        )?)
    }

    /// Captures optimizer and supported external runtime state in one
    /// integrity-bound Rust contract.
    pub fn runtime_checkpoint_bundle<M: Module + ?Sized>(
        &self,
        module: &M,
    ) -> Result<TrainerRuntimeCheckpointBundle, TrainerCheckpointError> {
        let optimizer = self.optimizer_checkpoint(module)?;
        let external = self.external_state_checkpoint()?;
        Ok(build_trainer_runtime_checkpoint_bundle(
            optimizer, external,
        )?)
    }

    /// Restores an integrity-bound runtime bundle only after every child
    /// payload, model fingerprint, topology, and concrete resource is ready.
    pub fn restore_runtime_checkpoint_bundle<M: Module + ?Sized>(
        &mut self,
        module: &mut M,
        bundle: &TrainerRuntimeCheckpointBundle,
    ) -> Result<TrainerRuntimeCheckpointValidation, TrainerCheckpointError> {
        let portable = evaluate_trainer_runtime_checkpoint_bundle(bundle)?;
        if !portable.payload_complete {
            return Err(TrainerCheckpointError::RuntimeCheckpointNotReady {
                unresolved: portable.unresolved_components.join(", "),
                missing_reattachments: portable.reattach_required_components.join(", "),
            });
        }

        let external = self.prepare_external_state_checkpoint_restore(&bundle.external)?;
        let mut projected_topology = self.optimizer_execution_topology();
        projected_topology.external_state_required = bundle.external.required_components.clone();
        let optimizer = self.prepare_optimizer_checkpoint_restore_for_topology(
            module,
            &bundle.optimizer,
            &projected_topology,
        )?;
        let validation =
            evaluate_trainer_runtime_checkpoint_restore(bundle, &external.reattached_components)?;
        if !validation.deterministic_resume_ready {
            let missing_reattachments = validation
                .reattach_required_components
                .iter()
                .filter(|component| {
                    validation
                        .reattached_components
                        .binary_search(component)
                        .is_err()
                })
                .cloned()
                .collect::<Vec<_>>();
            return Err(TrainerCheckpointError::RuntimeCheckpointNotReady {
                unresolved: validation.unresolved_components.join(", "),
                missing_reattachments: missing_reattachments.join(", "),
            });
        }

        self.commit_external_state_checkpoint_restore(external)?;
        self.commit_optimizer_checkpoint_restore(module, optimizer)?;
        Ok(validation)
    }

    /// Restores a checkpoint as one transaction after validating the model and
    /// execution topology. No trainer or parameter state changes on failure.
    pub fn restore_optimizer_checkpoint<M: Module + ?Sized>(
        &mut self,
        module: &mut M,
        checkpoint: &TrainerOptimizerCheckpoint,
    ) -> Result<TrainerOptimizerCheckpointValidation, TrainerCheckpointError> {
        let prepared = self.prepare_optimizer_checkpoint_restore(module, checkpoint)?;
        self.commit_optimizer_checkpoint_restore(module, prepared)
    }

    fn prepare_optimizer_checkpoint_restore<M: Module + ?Sized>(
        &self,
        module: &mut M,
        checkpoint: &TrainerOptimizerCheckpoint,
    ) -> Result<PreparedTrainerOptimizerRestore, TrainerCheckpointError> {
        let topology = self.optimizer_execution_topology();
        self.prepare_optimizer_checkpoint_restore_for_topology(module, checkpoint, &topology)
    }

    fn prepare_optimizer_checkpoint_restore_for_topology<M: Module + ?Sized>(
        &self,
        module: &mut M,
        checkpoint: &TrainerOptimizerCheckpoint,
        target_topology: &TrainerExecutionTopology,
    ) -> Result<PreparedTrainerOptimizerRestore, TrainerCheckpointError> {
        let validation = evaluate_trainer_optimizer_checkpoint(checkpoint)?;
        if checkpoint.topology != *target_topology {
            return Err(TrainerCheckpointError::TopologyMismatch);
        }

        let epoch = usize::try_from(checkpoint.state.epoch).map_err(|_| {
            TrainerCheckpointError::EpochOutOfRange {
                epoch: checkpoint.state.epoch,
            }
        })?;
        let sync_buffers = usize::try_from(checkpoint.state.last_accumulator_sync_buffers)
            .map_err(|_| TrainerCheckpointError::CounterOutOfRange {
                field: "last_accumulator_sync_buffers",
                value: checkpoint.state.last_accumulator_sync_buffers,
            })?;
        let sync_values =
            usize::try_from(checkpoint.state.last_accumulator_sync_values).map_err(|_| {
                TrainerCheckpointError::CounterOutOfRange {
                    field: "last_accumulator_sync_values",
                    value: checkpoint.state.last_accumulator_sync_values,
                }
            })?;
        let spectral_adapter = SpectralLrAdapter::from_state(checkpoint.state.spectral_adapter)?;
        let curvature_scheduler = checkpoint
            .state
            .curvature_scheduler
            .map(CurvatureScheduler::from_state)
            .transpose()?;
        let spectral_policy = checkpoint
            .state
            .spectral_policy
            .map(SpectralLearningRatePolicy::from_state)
            .transpose()?;
        let softlogic = SoftLogicFlex::from_state(checkpoint.state.softlogic.clone())?;

        let checkpoint_parameters = checkpoint
            .parameters
            .iter()
            .map(|state| (state.name.as_str(), state))
            .collect::<HashMap<_, _>>();
        let mut prepared = HashMap::<String, PreparedParameterOptimizerState>::new();
        module.visit_parameters(&mut |parameter| {
            if prepared.contains_key(parameter.name()) {
                return Err(TensorError::Generic(format!(
                    "duplicate target parameter {}",
                    parameter.name()
                )));
            }
            let Some(state) = checkpoint_parameters.get(parameter.name()) else {
                return Err(TensorError::MissingParameter {
                    name: parameter.name().to_owned(),
                });
            };
            let state = parameter.prepare_optimizer_checkpoint_restore(state)?;
            prepared.insert(parameter.name().to_owned(), state);
            Ok(())
        })?;
        if prepared.len() != checkpoint.parameters.len() {
            let missing = checkpoint
                .parameters
                .iter()
                .filter(|state| !prepared.contains_key(&state.name))
                .map(|state| state.name.clone())
                .collect::<Vec<_>>();
            return Err(TrainerCheckpointError::ParameterSetMismatch {
                message: format!("target module is missing [{}]", missing.join(", ")),
            });
        }

        let mut mutable_parameter_names = Vec::with_capacity(prepared.len());
        module.visit_parameters_mut(&mut |parameter| {
            mutable_parameter_names.push(parameter.name().to_owned());
            Ok(())
        })?;
        mutable_parameter_names.sort_unstable();
        let mut prepared_parameter_names = prepared.keys().cloned().collect::<Vec<_>>();
        prepared_parameter_names.sort_unstable();
        if mutable_parameter_names != prepared_parameter_names {
            return Err(TrainerCheckpointError::ParameterSetMismatch {
                message: "immutable and mutable parameter traversals do not match".to_owned(),
            });
        }

        Ok(PreparedTrainerOptimizerRestore {
            validation,
            config: checkpoint.config,
            topology: checkpoint.topology.clone(),
            state: checkpoint.state.clone(),
            epoch,
            sync_buffers,
            sync_values,
            spectral_adapter,
            curvature_scheduler,
            spectral_policy,
            softlogic,
            parameters: prepared,
        })
    }

    fn commit_optimizer_checkpoint_restore<M: Module + ?Sized>(
        &mut self,
        module: &mut M,
        mut prepared: PreparedTrainerOptimizerRestore,
    ) -> Result<TrainerOptimizerCheckpointValidation, TrainerCheckpointError> {
        module.visit_parameters_mut(&mut |parameter| {
            let state = prepared
                .parameters
                .remove(parameter.name())
                .ok_or_else(|| {
                    TensorError::Generic(format!(
                        "parameter traversal changed while restoring {}",
                        parameter.name()
                    ))
                })?;
            parameter.commit_optimizer_checkpoint_restore(state);
            Ok(())
        })?;
        if !prepared.parameters.is_empty() {
            return Err(TrainerCheckpointError::ParameterSetMismatch {
                message: format!(
                    "mutable target traversal omitted [{}]",
                    prepared
                        .parameters
                        .keys()
                        .cloned()
                        .collect::<Vec<_>>()
                        .join(", ")
                ),
            });
        }

        self.epoch = prepared.epoch;
        self.curvature = prepared.config.curvature;
        self.hyper_learning_rate = prepared.config.hyper_learning_rate;
        self.fallback_learning_rate = prepared.config.fallback_learning_rate;
        self.real_learning_rate = prepared.config.real_learning_rate;
        self.grad_clip_max_norm = prepared.config.grad_clip_max_norm;
        self.meta_learning_rate_scale = prepared.state.meta_learning_rate_scale;
        self.meta_optimizer_step = prepared.state.meta_optimizer_step;
        self.spectral_adapter = prepared.spectral_adapter;
        self.curvature_scheduler = prepared.curvature_scheduler;
        self.spectral_policy = prepared.spectral_policy;
        self.phase_turnover_spike_threshold = prepared.state.phase_tracker.turnover_spike_threshold;
        self.phase_loss_ema_alpha = prepared.state.phase_tracker.loss_ema_alpha;
        self.phase_loss_spike_ratio = prepared.state.phase_tracker.loss_spike_ratio;
        self.phase_drift_spike_threshold = prepared.state.phase_tracker.drift_spike_threshold;
        self.phase_last_label = prepared.state.phase_tracker.last_label;
        self.phase_last_turnover = prepared.state.phase_tracker.last_turnover;
        self.phase_last_band = prepared.state.phase_tracker.last_band;
        self.phase_last_drift_abs = prepared.state.phase_tracker.last_drift_abs;
        self.phase_loss_ema = prepared.state.phase_tracker.loss_ema;
        self.phase_loss_spiking = prepared.state.phase_tracker.loss_spiking;
        self.softlogic = prepared.softlogic;
        self.cumulative_backend_counters = prepared.state.backend_counters;
        self.last_accumulator_sync = TrainerAccumulatorSyncStats {
            enabled: prepared.topology.training_device_enabled,
            rank: prepared.topology.training_rank,
            world_size: prepared.topology.training_world_size,
            buffers: prepared.sync_buffers,
            values: prepared.sync_values,
        };
        self.last_curvature_metrics = None;
        self.last_spectral_metrics = None;
        Ok(prepared.validation)
    }

    /// Returns details for the most recent accumulator synchronization pass.
    pub fn last_accumulator_sync(&self) -> TrainerAccumulatorSyncStats {
        self.last_accumulator_sync
    }

    /// Installs a training device used to synchronize parameter accumulators before updates.
    pub fn set_training_device<D>(&mut self, device: D)
    where
        D: AccumulatorSynchronizer + 'static,
    {
        self.accumulator_synchronizer = Some(Arc::new(device));
    }

    /// Installs a shared training device used to synchronize parameter accumulators before updates.
    pub fn set_training_device_arc(&mut self, device: Arc<dyn AccumulatorSynchronizer>) {
        self.accumulator_synchronizer = Some(device);
    }

    /// Clears any configured training device and returns to local-only updates.
    pub fn clear_training_device(&mut self) {
        self.accumulator_synchronizer = None;
        self.last_accumulator_sync = TrainerAccumulatorSyncStats::disabled();
    }

    /// Returns the curvature used for hypergrad preparation.
    pub fn curvature(&self) -> f32 {
        self.curvature
    }

    /// Returns the learning rate used for hypergrad updates.
    pub fn hyper_learning_rate(&self) -> f32 {
        self.hyper_learning_rate
    }

    /// Multiplies all learning rates (hypergrad, fallback, optional realgrad) by `factor`.
    ///
    /// This also scales any per-parameter learning rates so optimiser state stays consistent.
    pub fn mul_learning_rate<M: Module + ?Sized>(
        &mut self,
        module: &mut M,
        factor: f32,
    ) -> PureResult<()> {
        self.scale_learning_rates(module, factor)
    }

    /// Returns the latest absolute meta-optimizer scale applied to parameter
    /// learning rates.
    pub fn meta_learning_rate_scale(&self) -> f32 {
        self.meta_learning_rate_scale
    }

    /// Returns the latest accepted meta-optimizer step, if any.
    pub fn meta_optimizer_step(&self) -> Option<u64> {
        self.meta_optimizer_step
    }

    /// Applies the model-parameter projection of a typed Rust meta-optimizer
    /// report without importing latent-gradient semantics into the trainer.
    pub fn apply_zspace_meta_optimizer_report<M: Module + ?Sized>(
        &mut self,
        module: &mut M,
        report: &ZSpaceMetaOptimizerStepReport,
    ) -> PureResult<ZSpaceParameterControlReceipt> {
        let control =
            zspace_parameter_control_from_report(report).map_err(parameter_control_error)?;
        self.apply_zspace_parameter_control(module, &control)
    }

    /// Applies a control previously validated by the Rust semantic core.
    pub fn apply_zspace_parameter_control<M: Module + ?Sized>(
        &mut self,
        module: &mut M,
        control: &ZSpaceParameterControl,
    ) -> PureResult<ZSpaceParameterControlReceipt> {
        let plan = plan_zspace_parameter_control(
            self.meta_learning_rate_scale,
            self.meta_optimizer_step,
            control,
        )?;
        let receipt = plan.receipt();
        if receipt.changed {
            self.scale_learning_rates(module, receipt.applied_learning_rate_ratio)?;
        }
        self.meta_learning_rate_scale = receipt.absolute_learning_rate_scale;
        self.meta_optimizer_step = Some(receipt.source_meta_step);
        emit_parameter_control_receipt("module_trainer", receipt);
        Ok(receipt)
    }

    /// Returns the optional gradient clipping threshold.
    pub fn grad_clip_max_norm(&self) -> Option<f32> {
        self.grad_clip_max_norm
    }

    /// Sets the gradient clipping threshold (global L2 norm).
    ///
    /// Invalid values are rejected without changing the existing guard.
    pub fn set_grad_clip_max_norm(
        &mut self,
        max_norm: f32,
    ) -> Result<(), TrainerOptimizerConfigError> {
        let config = self
            .optimizer_config()
            .with_grad_clip_max_norm(Some(max_norm))?;
        self.grad_clip_max_norm = config.grad_clip_max_norm;
        Ok(())
    }

    /// Disables any previously configured gradient clipping.
    pub fn clear_grad_clip_max_norm(&mut self) {
        self.grad_clip_max_norm = None;
    }

    /// Returns the Euclidean realgrad learning rate, when enabled.
    pub fn real_learning_rate(&self) -> Option<f32> {
        self.real_learning_rate
    }

    /// Enables Euclidean realgrad accumulation with the provided learning rate.
    pub fn with_realgrad(mut self, learning_rate: f32) -> Self {
        self.enable_realgrad(learning_rate)
            .expect("invalid ModuleTrainer realgrad learning rate");
        self
    }

    /// Tries to enable Euclidean realgrad accumulation.
    pub fn try_with_realgrad(
        mut self,
        learning_rate: f32,
    ) -> Result<Self, TrainerOptimizerConfigError> {
        self.enable_realgrad(learning_rate)?;
        Ok(self)
    }

    /// Enables Euclidean realgrad accumulation with the provided learning rate.
    pub fn enable_realgrad(
        &mut self,
        learning_rate: f32,
    ) -> Result<(), TrainerOptimizerConfigError> {
        let config = self
            .optimizer_config()
            .with_real_learning_rate(Some(learning_rate))?;
        self.real_learning_rate = config.real_learning_rate;
        Ok(())
    }

    /// Disables the optional realgrad accumulation pathway.
    pub fn disable_realgrad(&mut self) {
        self.real_learning_rate = None;
    }

    /// Configures the trainer to broadcast a text infusion signal through the module.
    pub fn set_text_infusion(
        &mut self,
        text: impl Into<String>,
        every: TextInfusionEvery,
        mode: TextInfusionMode,
    ) -> PureResult<()> {
        let text = text.into();
        if text.trim().is_empty() {
            return Err(TensorError::EmptyInput("text_infusion"));
        }
        self.text_infusion = Some(TextInfusionConfig { text, every, mode });
        Ok(())
    }

    /// Disables any previously configured text infusion signal.
    pub fn clear_text_infusion(&mut self) {
        self.text_infusion = None;
    }

    /// Attaches hypergrad tapes to all parameters of the provided module.
    pub fn prepare<M: Module + ?Sized>(&self, module: &mut M) -> PureResult<()> {
        module.attach_hypergrad(self.curvature, self.hyper_learning_rate)?;
        if let Some(rate) = self.real_learning_rate {
            module.attach_realgrad(rate)?;
        }
        Ok(())
    }

    /// Attaches hypergrad tapes with an explicit topos shared across parameters.
    pub fn prepare_with_topos<M: Module + ?Sized>(
        &self,
        module: &mut M,
        topos: OpenCartesianTopos,
    ) -> PureResult<()> {
        module.attach_hypergrad_with_topos(self.curvature, self.hyper_learning_rate, topos)?;
        if let Some(rate) = self.real_learning_rate {
            module.attach_realgrad(rate)?;
        }
        Ok(())
    }

    /// Clears accumulated gradients or hypergrad buffers.
    pub fn zero<M: Module + ?Sized>(&self, module: &mut M) -> PureResult<()> {
        module.zero_accumulators()
    }

    /// Applies the parameter updates using either the hypergrad tape or the fallback rate.
    pub fn step<M: Module + ?Sized>(&mut self, module: &mut M) -> PureResult<()> {
        let backend_policy = self.backend_policy();
        let _backend_policy_guard = push_backend_policy(backend_policy);
        self.synchronize_parameter_accumulators(module)?;
        if let Some(limit) = self.grad_clip_max_norm {
            self.clip_grad_global_norm(module, limit)?;
        }
        let adapter: &mut dyn LocalLearningRateAdapter = &mut self.spectral_adapter;
        module.apply_step_with_adapter(self.fallback_learning_rate, Some(adapter))
    }

    /// Runs a full epoch over the provided iterator of `(input, target)` pairs.
    pub fn train_epoch<M, L, I>(
        &mut self,
        module: &mut M,
        loss: &mut L,
        batches: I,
        schedule: &RoundtableSchedule,
    ) -> PureResult<EpochStats>
    where
        M: Module + ?Sized,
        L: Loss + ?Sized,
        I: IntoIterator,
        I::Item: IntoBatch,
    {
        let result = self.train_epoch_inner(module, loss, batches, schedule);
        if let Err(error) = &result {
            let abandoned_selection_id = self
                .autopilot
                .as_mut()
                .and_then(Autopilot::abandon_suggestion);
            if let Some(selection_id) = abandoned_selection_id {
                let bus = global_registry().event_bus();
                if bus.has_listeners("TrainerAutopilotRejected") {
                    bus.publish(&PluginEvent::custom(
                        "TrainerAutopilotRejected",
                        serde_json::json!({
                            "stage": "epoch_error",
                            "error": error.to_string(),
                            "abandoned_selection_id": selection_id,
                        }),
                    ));
                }
            }
        }
        result
    }

    fn train_epoch_inner<M, L, I>(
        &mut self,
        module: &mut M,
        loss: &mut L,
        batches: I,
        schedule: &RoundtableSchedule,
    ) -> PureResult<EpochStats>
    where
        M: Module + ?Sized,
        L: Loss + ?Sized,
        I: IntoIterator,
        I::Item: IntoBatch,
    {
        let backend_policy = self.backend_policy();
        schedule
            .validate_execution_policy(backend_policy)
            .map_err(|error| TensorError::Generic(error.to_string()))?;
        self.epoch = self.epoch.saturating_add(1);
        let epoch = self.epoch;
        global_registry()
            .event_bus()
            .publish(&PluginEvent::EpochStart { epoch });
        if let Some(budget) = self.rewrite_budget.as_mut() {
            budget.begin_epoch();
        }
        self.zero(module)?;
        module.train()?;
        if let Some(infusion) = self.text_infusion.clone() {
            let should_apply = match infusion.every {
                TextInfusionEvery::Once => epoch == 1,
                TextInfusionEvery::Epoch => true,
                TextInfusionEvery::Batch => false,
            };
            if should_apply {
                module.infuse_text(&infusion.text)?;
                if infusion.mode == TextInfusionMode::Separate {
                    self.step(module)?;
                }
                if matches!(infusion.every, TextInfusionEvery::Once) {
                    self.text_infusion = None;
                }
            }
        }
        self.phase_last_label = None;
        self.phase_last_turnover = None;
        self.phase_last_band = None;
        self.phase_last_drift_abs = None;
        self.phase_loss_ema = None;
        self.phase_loss_spiking = false;
        self.last_band_energy = None;
        self.last_spectral_metrics = None;
        #[cfg(feature = "psi")]
        self.bootstrap_psi(schedule);
        #[cfg(feature = "psychoid")]
        self.bootstrap_psychoid(schedule);
        #[cfg(feature = "collapse")]
        self.bootstrap_collapse(schedule);
        let mut total_loss = 0.0f32;
        let mut steps = 0usize;
        let strict_expected_backend = strict_expected_tensor_backend(
            backend_policy.device_caps(),
            backend_policy.execution_config().accelerator_fallback,
        );
        let trace_trainer_steps = global_registry().event_bus().has_listeners("TrainerStep");
        let trace_parameter_updates = trace_trainer_steps;
        let tensor_trace = Some(TensorOpMetaStepCollector::install());
        let mut epoch_tensor_backend = EpochTensorBackendStats::default();
        for batch in batches.into_iter() {
            if let Some(trace) = tensor_trace.as_ref() {
                trace.clear();
            }
            let mut step_schedule = (*schedule).clone();
            let mut autopilot_picks = None;
            let mut autopilot_selection_witness = None;
            let (input, target) = batch.into_batch()?;
            validate_trainer_tensor("trainer_batch_input", &input)?;
            validate_trainer_tensor("trainer_batch_target", &target)?;
            let input_shape = input.shape();
            let target_shape = target.shape();
            let graph_adjustment = self.graph_pending.take();
            self.graph_last_hint = graph_adjustment
                .as_ref()
                .and_then(|digest| digest.spiralk_script.clone());
            let step_start = Instant::now();
            if let Some(rt) = self.blackcat.as_mut() {
                rt.begin_step();
            }
            let device_load = self.estimate_device_load();
            if let Some(ap) = self.autopilot.as_mut() {
                let (rows, cols) = input.shape();
                let depth =
                    step_schedule.above().k + step_schedule.here().k + step_schedule.beneath().k;
                let context = ap
                    .try_build_context(rows as u32, cols as u32, depth, device_load, &[])
                    .map_err(|_| TensorError::InvalidValue {
                        label: "autopilot context",
                    })?;
                let picks = ap
                    .try_suggest(context)
                    .map_err(|_| TensorError::InvalidValue {
                        label: "autopilot suggestion",
                    })?
                    .clone();
                if let Err(error) = step_schedule.try_apply_knob_overrides(&picks) {
                    let abandoned_selection_id = ap.abandon_suggestion();
                    let bus = global_registry().event_bus();
                    if bus.has_listeners("TrainerAutopilotRejected") {
                        bus.publish(&PluginEvent::custom(
                            "TrainerAutopilotRejected",
                            serde_json::json!({
                                "stage": "schedule_override",
                                "error": error.to_string(),
                                "picks": picks,
                                "abandoned_selection_id": abandoned_selection_id,
                            }),
                        ));
                    }
                    return Err(TensorError::InvalidValue {
                        label: "autopilot schedule override",
                    });
                }
                autopilot_selection_witness = ap.runtime().last_selection_witness().cloned();
                autopilot_picks = Some(picks);
            }
            let _backend_policy_guard = push_backend_policy(backend_policy);
            let prediction = module.forward(&input)?;
            validate_trainer_tensor("trainer_prediction", &prediction)?;
            let prediction_shape = prediction.shape();
            let loss_value = loss.forward(&prediction, &target)?;
            validate_trainer_tensor("trainer_loss", &loss_value)?;
            let loss_shape = loss_value.shape();
            let step_loss = trainer_tensor_sum("trainer_step_loss", &loss_value)?;
            let grad_output = loss.backward(&prediction, &target)?;
            validate_trainer_tensor("trainer_grad_output", &grad_output)?;
            let grad_output_shape = grad_output.shape();
            let mut band_energy = step_schedule.band_energy(&grad_output)?;
            validate_band_energy_for_trainer(&band_energy)?;
            let baseline_band_energy = band_energy;
            let mut desire_impulse = None;
            if let Some(bridge) = self.desire_roundtable_bridge.as_ref() {
                if let Some(impulse) = bridge.impulse()? {
                    band_energy.above *= impulse.multipliers.0;
                    band_energy.here *= impulse.multipliers.1;
                    band_energy.beneath *= impulse.multipliers.2;
                    band_energy.drift += impulse.drift;
                    desire_impulse = Some(impulse);
                }
            }
            if let Some(ref digest) = graph_adjustment {
                band_energy.above *= digest.multipliers.0;
                band_energy.here *= digest.multipliers.1;
                band_energy.beneath *= digest.multipliers.2;
            }
            if let Some(rt) = self.blackcat.as_ref() {
                band_energy.drift = rt.frac_penalty() as f32;
            }
            validate_band_energy_for_trainer(&band_energy)?;
            let mut roundtable_signal =
                RoundtableBandSignal::from_schedule(&step_schedule, band_energy)?;
            if let Some(bridge) = self.gnn_roundtable_bridge.as_ref() {
                roundtable_signal = bridge.publish(roundtable_signal.clone())?;
            }
            self.gnn_last_roundtable_signal = Some(roundtable_signal.clone());
            let mut bands: GradientBands = step_schedule.split(&grad_output)?;
            let mut weights = self.softlogic.prepare_weights(&band_energy);
            if let Some(ref impulse) = desire_impulse {
                weights.0 *= impulse.multipliers.0;
                weights.1 *= impulse.multipliers.1;
                weights.2 *= impulse.multipliers.2;
            }
            if let Some(ref digest) = graph_adjustment {
                weights.0 *= digest.multipliers.0;
                weights.1 *= digest.multipliers.1;
                weights.2 *= digest.multipliers.2;
            }
            if let Some(f) = self.band_weight_fn {
                let override_weights = f(band_energy);
                weights.0 *= override_weights.0;
                weights.1 *= override_weights.1;
                weights.2 *= override_weights.2;
            }
            validate_band_weights_for_trainer(weights)?;
            let mut spectral_used = false;
            let mut spectral_extra: Option<SpectralAdjustmentMetrics> = None;
            if self.pending_coherence.is_none() {
                if let Some(bridge) = self.coherence_bridge.as_ref() {
                    if let Some(signal) = bridge.drain() {
                        self.pending_coherence = Some(signal);
                    }
                }
            }
            let coherence_snapshot = self.pending_coherence.take();
            let coherence_label = coherence_snapshot
                .as_ref()
                .map(|diagnostics| diagnostics.label());
            let mut spectral_label_code = coherence_label.map(|label| match label {
                CoherenceLabel::Background => 0.0,
                CoherenceLabel::SymmetricPulse => 1.0,
                CoherenceLabel::CascadeImbalance => 2.0,
                CoherenceLabel::DiffuseDrift => 3.0,
            });
            let mut spectral_turnover = None;
            let mut spectral_adjustment: Option<SpectralAdjustment> = None;
            if let Some(policy) = self.spectral_policy.as_mut() {
                spectral_adjustment = policy.observe_signal(
                    coherence_snapshot.as_ref(),
                    self.curvature,
                    &band_energy,
                );
                spectral_turnover = Some(policy.dominant_turnover());
                if let Some(label) = policy.last_coherence_label() {
                    spectral_label_code = Some(match label {
                        CoherenceLabel::Background => 0.0,
                        CoherenceLabel::SymmetricPulse => 1.0,
                        CoherenceLabel::CascadeImbalance => 2.0,
                        CoherenceLabel::DiffuseDrift => 3.0,
                    });
                }
            }
            if let Some(adjustment) = spectral_adjustment {
                weights.0 *= adjustment.band_scale.0;
                weights.1 *= adjustment.band_scale.1;
                weights.2 *= adjustment.band_scale.2;
                if adjustment.lr_multiplier.is_finite()
                    && (adjustment.lr_multiplier - 1.0).abs() > 1.0e-3
                {
                    self.scale_learning_rates(module, adjustment.lr_multiplier)?;
                }
                spectral_extra = Some(adjustment.metrics.clone());
                self.last_spectral_metrics = Some(adjustment.metrics);
                spectral_used = coherence_snapshot.is_some();
            }
            if coherence_snapshot.is_some() && !spectral_used {
                self.pending_coherence = coherence_snapshot.clone();
            }
            validate_band_weights_for_trainer(weights)?;
            bands.scale_inplace(weights.0, weights.1, weights.2)?;
            for band in bands.iter() {
                validate_trainer_tensor("trainer_scaled_band_gradient", band)?;
            }
            let weight_mean = validate_trainer_scalar(
                "trainer_band_weight_mean",
                (weights.0 + weights.1 + weights.2) / 3.0,
            )?;
            let weighted_loss_base = validate_trainer_scalar(
                "trainer_weighted_loss_base",
                step_loss * weight_mean.max(0.0),
            )?;
            let mut weighted_loss = weighted_loss_base;
            let mut extra = HashMap::new();
            insert_tensor_shape_extra(&mut extra, "batch_input", input_shape);
            insert_tensor_shape_extra(&mut extra, "batch_target", target_shape);
            insert_tensor_shape_extra(&mut extra, "batch_prediction", prediction_shape);
            insert_tensor_shape_extra(&mut extra, "batch_loss", loss_shape);
            insert_tensor_shape_extra(&mut extra, "batch_grad_output", grad_output_shape);
            if trace_trainer_steps {
                TensorValueHealth::from_tensor(&input).write_extra(&mut extra, "batch_input");
                TensorValueHealth::from_tensor(&target).write_extra(&mut extra, "batch_target");
                TensorValueHealth::from_tensor(&prediction)
                    .write_extra(&mut extra, "batch_prediction");
                TensorValueHealth::from_tensor(&loss_value).write_extra(&mut extra, "batch_loss");
                TensorValueHealth::from_tensor(&grad_output)
                    .write_extra(&mut extra, "batch_grad_output");
            }
            write_backend_policy_extra(backend_policy, &mut extra);
            write_coherence_signal_extra(coherence_snapshot.as_ref(), &mut extra);
            extra.insert("softlogic_w_above".to_string(), weights.0 as f64);
            extra.insert("softlogic_w_here".to_string(), weights.1 as f64);
            extra.insert("softlogic_w_beneath".to_string(), weights.2 as f64);
            extra.insert(
                "softlogic_inertia".to_string(),
                self.softlogic.last_inertia() as f64,
            );
            let region_scale = self.softlogic.last_region_scale();
            extra.insert(
                "softlogic_region_scale_above".to_string(),
                region_scale.0 as f64,
            );
            extra.insert(
                "softlogic_region_scale_here".to_string(),
                region_scale.1 as f64,
            );
            extra.insert(
                "softlogic_region_scale_beneath".to_string(),
                region_scale.2 as f64,
            );
            let softlogic_config = self.softlogic.config();
            let softlogic_metrics = self.softlogic.adaptive_metrics();
            extra.insert(
                "softlogic_energy_equalize_gain".to_string(),
                softlogic_config.energy_equalize_gain as f64,
            );
            extra.insert(
                "softlogic_energy_equalize_auto".to_string(),
                softlogic_config.energy_equalize_auto as f64,
            );
            extra.insert(
                "softlogic_energy_equalize_gain_eff".to_string(),
                softlogic_metrics.energy_equalize_gain_eff as f64,
            );
            extra.insert(
                "softlogic_energy_equalize_strength".to_string(),
                softlogic_metrics.energy_equalize_strength as f64,
            );
            extra.insert(
                "softlogic_energy_equalize_over".to_string(),
                softlogic_metrics.energy_equalize_over as f64,
            );
            extra.insert(
                "softlogic_energy_equalize_state".to_string(),
                softlogic_metrics.energy_equalize_state as f64,
            );
            extra.insert(
                "softlogic_mean_normalize_gain".to_string(),
                softlogic_config.mean_normalize_gain as f64,
            );
            extra.insert(
                "softlogic_mean_normalize_auto".to_string(),
                softlogic_config.mean_normalize_auto as f64,
            );
            extra.insert(
                "softlogic_mean_normalize_gain_eff".to_string(),
                softlogic_metrics.mean_normalize_gain_eff as f64,
            );
            extra.insert(
                "softlogic_mean_normalize_need".to_string(),
                softlogic_metrics.mean_normalize_need as f64,
            );
            extra.insert(
                "softlogic_mean_normalize_state".to_string(),
                softlogic_metrics.mean_normalize_state as f64,
            );
            extra.insert(
                "softlogic_mean_target".to_string(),
                softlogic_metrics.mean_target as f64,
            );
            if let Some(label) = spectral_label_code {
                extra.insert("spectral_label".to_string(), label);
            }
            if let Some(turnover) = spectral_turnover {
                extra.insert("spectral_turnover".to_string(), turnover as f64);
            }
            if let Some(metrics) = spectral_extra {
                extra.insert(
                    "spectral_lr_scale".to_string(),
                    metrics.absolute_lr_scale as f64,
                );
                extra.insert(
                    "spectral_band_above".to_string(),
                    metrics.band_scale.0 as f64,
                );
                extra.insert(
                    "spectral_band_here".to_string(),
                    metrics.band_scale.1 as f64,
                );
                extra.insert(
                    "spectral_band_beneath".to_string(),
                    metrics.band_scale.2 as f64,
                );
                extra.insert(
                    "spectral_local_lr_above".to_string(),
                    metrics.local_lr.0 as f64,
                );
                extra.insert(
                    "spectral_local_lr_here".to_string(),
                    metrics.local_lr.1 as f64,
                );
                extra.insert(
                    "spectral_local_lr_beneath".to_string(),
                    metrics.local_lr.2 as f64,
                );
                extra.insert("spectral_spin".to_string(), metrics.spin_alignment as f64);
                extra.insert(
                    "spectral_radius".to_string(),
                    metrics.spectral_radius as f64,
                );
                extra.insert(
                    "spectral_raw_mean_coherence".to_string(),
                    metrics.raw_mean_coherence as f64,
                );
                extra.insert(
                    "spectral_raw_coherence_entropy".to_string(),
                    metrics.raw_coherence_entropy as f64,
                );
                extra.insert(
                    "spectral_entropy".to_string(),
                    metrics.spectral_entropy as f64,
                );
                extra.insert(
                    "spectral_pressure".to_string(),
                    metrics.spectral_pressure as f64,
                );
                extra.insert(
                    "spectral_effective_channels".to_string(),
                    metrics.effective_channels as f64,
                );
                extra.insert(
                    "spectral_distribution_channels".to_string(),
                    metrics.distribution_channels as f64,
                );
                extra.insert("spectral_control_contract_v1".to_string(), 1.0);
                extra.insert("spectral_control_backend_rust".to_string(), 1.0);
                extra.insert(
                    "spectral_energy_ratio".to_string(),
                    metrics.energy_ratio as f64,
                );
                if let Some(index) = metrics.sheet_index {
                    extra.insert("spectral_sheet_index".to_string(), index as f64);
                }
                extra.insert(
                    "spectral_sheet_count".to_string(),
                    metrics.sheet_count as f64,
                );
            } else {
                self.last_spectral_metrics = None;
            }
            if let Some(ref impulse) = desire_impulse {
                extra.insert(
                    "desire_roundtable_multiplier_above".to_string(),
                    impulse.multipliers.0 as f64,
                );
                extra.insert(
                    "desire_roundtable_multiplier_here".to_string(),
                    impulse.multipliers.1 as f64,
                );
                extra.insert(
                    "desire_roundtable_multiplier_beneath".to_string(),
                    impulse.multipliers.2 as f64,
                );
                extra.insert("desire_roundtable_drift".to_string(), impulse.drift as f64);
            }
            if let Some(bridge) = self.desire_bridge.as_ref() {
                if let Some(summary) = bridge.drain_summary()? {
                    Self::insert_desire_summary(&mut extra, &summary);
                }
            }
            if let Some(bridge) = self.desire_roundtable_bridge.as_ref() {
                if let Some(summary) = bridge.drain_summary()? {
                    Self::insert_desire_roundtable_summary(&mut extra, &summary);
                    self.last_desire_roundtable_summary = Some(summary);
                }
            }
            #[cfg(feature = "psi")]
            if let Some(bridge) = self.desire_psi_bridge.as_ref() {
                if let Some(summary) = bridge.drain_summary()? {
                    Self::insert_desire_psi_summary(&mut extra, &summary);
                }
            }
            if let Some(ref digest) = graph_adjustment {
                extra.insert("graph_share".to_string(), digest.barycentric[3] as f64);
                extra.insert(
                    "graph_multiplier_above".to_string(),
                    digest.multipliers.0 as f64,
                );
                extra.insert(
                    "graph_multiplier_here".to_string(),
                    digest.multipliers.1 as f64,
                );
                extra.insert(
                    "graph_multiplier_beneath".to_string(),
                    digest.multipliers.2 as f64,
                );
                extra.insert("graph_layers".to_string(), digest.layer_count() as f64);
            }
            module.apply_roundtable_band(&roundtable_signal)?;
            let backward_result = module.backward_bands(&input, &bands);
            module.clear_roundtable_band()?;
            if let Err(error) = backward_result {
                self.zero(module)?;
                return Err(error);
            }
            let gradient_health = Self::collect_gradient_health(module)?;
            gradient_health.write_extra(&mut extra);
            let gradient_error = gradient_health
                .ensure_finite("trainer_gradient_accumulator")
                .err();
            if let Some(error) = gradient_error {
                self.zero(module)?;
                return Err(error);
            }
            if let Some(bridge) = self.graph_bridge.as_ref() {
                self.graph_pending = bridge.digest(&baseline_band_energy)?;
            }
            if let Some(trace) = tensor_trace.as_ref() {
                let step_trace = trace.drain();
                if let Some(expected) = strict_expected_backend {
                    step_trace.validate_expected_backend(expected)?;
                }
                epoch_tensor_backend.accumulate_trace(&step_trace);
                step_trace.write_extra(&mut extra);
            }
            #[cfg(feature = "psychoid")]
            let mut psychoid_events = 0usize;
            #[cfg(feature = "psi")]
            let mut psi_snapshot: Option<PsiReading> = None;
            #[cfg(feature = "psi")]
            {
                let curvature_pos = self
                    .curvature_metrics()
                    .map(|metrics| metrics.curvature.max(0.0))
                    .unwrap_or(0.0);
                if let Some(meter) = self.psi.as_mut() {
                    let grad_l2 = Self::collect_grad_l2(module)?;
                    let act_drift = module.psi_probe().unwrap_or(0.0);
                    let input_snapshot = PsiInput {
                        loss: step_loss.abs(),
                        grad_l2,
                        update_ratio: 0.0,
                        act_drift,
                        attn_entropy: 0.0,
                        band_energy: band_energy.l1() + band_energy.drift.abs(),
                        curvature_pos,
                    };
                    let (reading, events) = meter.update(&input_snapshot);
                    psi_snapshot = Some(reading.clone());
                    hub::set_last_psi(&reading);
                    hub::set_last_psi_events(&events);
                    extra.insert("psi_total".to_string(), reading.total as f64);
                    for (component, value) in reading.breakdown.iter() {
                        let key = format!("psi_{}", component);
                        extra.insert(key, *value as f64);
                    }
                    extra.insert("psi_loss".to_string(), input_snapshot.loss as f64);
                    extra.insert("psi_grad_l2".to_string(), input_snapshot.grad_l2 as f64);
                    extra.insert(
                        "psi_update_ratio".to_string(),
                        input_snapshot.update_ratio as f64,
                    );
                    extra.insert("psi_act_drift".to_string(), input_snapshot.act_drift as f64);
                    extra.insert(
                        "psi_band_energy".to_string(),
                        input_snapshot.band_energy as f64,
                    );
                    extra.insert("psi_events".to_string(), events.len() as f64);
                }
            }
            #[cfg(feature = "psychoid")]
            {
                if let Some(meter) = self.psychoid.as_mut() {
                    if let Some(sample) = module.psychoid_sample(&input, &prediction) {
                        if let Some((reading, events)) = meter.observe(sample) {
                            hub::set_last_psychoid(&reading);
                            if self.psychoid_log {
                                Self::log_psychoid(&reading, &events);
                            }
                            extra.insert("psychoid_cti".to_string(), reading.cti as f64);
                            for (metric, value) in reading.raw.iter() {
                                extra.insert(
                                    format!("psychoid_raw_{}", metric.to_lowercase()),
                                    *value as f64,
                                );
                            }
                            for (metric, value) in reading.z_scores.iter() {
                                extra.insert(
                                    format!("psychoid_z_{}", metric.to_lowercase()),
                                    *value as f64,
                                );
                            }
                            psychoid_events = events.len();
                        }
                    }
                }
            }
            #[cfg(feature = "collapse")]
            if let Some(reading) = psi_snapshot.as_ref() {
                let command = self.collapse.as_mut().map(|driver| driver.update(reading));
                if let Some(command) = command {
                    match &command {
                        DriveCmd::Collapse {
                            grad_scale,
                            max_norm,
                            lr_decay,
                            ..
                        } => {
                            if *grad_scale < 0.999 {
                                self.apply_grad_scale(module, *grad_scale)?;
                            }
                            if let Some(limit) = max_norm {
                                self.clip_grad_global_norm(module, *limit)?;
                            }
                            if let Some(decay) = lr_decay {
                                let factor = (1.0 - decay).clamp(0.1, 1.0);
                                self.optimizer_mul_lr(module, factor)?;
                            }
                        }
                        DriveCmd::Bloom { lr_mul, .. } => {
                            if *lr_mul > 1.0 {
                                self.optimizer_mul_lr(module, *lr_mul)?;
                            }
                        }
                        DriveCmd::None => {}
                    }
                    if !matches!(command, DriveCmd::None) {
                        let loop_signal = hub::get_chrono_loop();
                        hub::set_collapse_pulse(CollapsePulse {
                            step: reading.step,
                            total: reading.total,
                            command,
                            loop_signal,
                        });
                    }
                }
            }
            let psi_total_opt: Option<f32> = {
                #[cfg(feature = "psi")]
                {
                    psi_snapshot.as_ref().map(|reading| reading.total.max(0.0))
                }
                #[cfg(not(feature = "psi"))]
                {
                    None
                }
            };
            let scale_hint = hub::get_softlogic_z().and_then(|feedback| feedback.scale);
            let mut z_feedback =
                self.softlogic
                    .observe(&band_energy, weighted_loss_base, psi_total_opt, scale_hint);
            if z_feedback.elliptic.is_none() {
                if let Some(previous) = hub::get_softlogic_z() {
                    if let Some(sample) = previous.elliptic {
                        z_feedback.elliptic = Some(sample);
                    }
                }
            }
            hub::set_softlogic_z(z_feedback.clone());
            extra.insert("softlogic_z".to_string(), z_feedback.z_signal as f64);
            for event in z_feedback.events.iter() {
                let trimmed = event.trim();
                if trimmed.is_empty() {
                    continue;
                }
                let key = format!("softlogic_event_{}", trimmed.replace(['.', '-'], "_"));
                extra.insert(key, 1.0);
            }
            let mut region_highlight = None;
            if let Some((region_factor, region_descriptor)) = self
                .loss_strategy
                .region_factor(&z_feedback, weighted_loss_base)
            {
                validate_trainer_scalar("trainer_loss_region_factor", region_factor)?;
                let factor = region_factor.max(0.0);
                if factor > 0.0 {
                    weighted_loss =
                        validate_trainer_scalar("trainer_weighted_loss", weighted_loss * factor)?;
                }
                extra.insert("loss_region_factor".to_string(), factor as f64);
                extra.insert(
                    "region_spin_alignment".to_string(),
                    region_descriptor.spin_alignment as f64,
                );
                extra.insert(
                    "region_normalized_radius".to_string(),
                    region_descriptor.normalized_radius as f64,
                );
                self.softlogic
                    .record_region_feedback(region_descriptor, factor);
                region_highlight = Some(region_descriptor);
            } else {
                self.softlogic.clear_region_feedback();
            }
            let region_bundle = self
                .loss_strategy
                .region_reports(region_highlight, steps as u64);
            match region_bundle.snapshot {
                Some(report) => hub::set_region_loss_report(report),
                None => hub::clear_region_loss_report(),
            }
            match region_bundle.trend {
                Some(report) => hub::set_region_loss_trend_report(report),
                None => hub::clear_region_loss_trend_report(),
            }
            match region_bundle.volatility {
                Some(report) => hub::set_region_loss_volatility_report(report),
                None => hub::clear_region_loss_volatility_report(),
            }
            validate_trainer_scalar("trainer_weighted_loss", weighted_loss)?;
            total_loss = validate_trainer_scalar("trainer_total_loss", total_loss + weighted_loss)?;
            extra.insert("loss_weighted_base".to_string(), weighted_loss_base as f64);
            let mut loop_broadcasted = false;
            if let Some(node) = self.distribution.as_mut() {
                let outcome = OutcomeBand::from_weights(
                    band_energy.above,
                    band_energy.here,
                    band_energy.beneath,
                );
                let plan = match outcome {
                    OutcomeBand::Above => step_schedule.above(),
                    OutcomeBand::Here => step_schedule.here(),
                    OutcomeBand::Beneath => step_schedule.beneath(),
                };
                let signature = plan_signature(plan, outcome);
                let script_hint = plan.choice.to_unison_script(plan.kind).replace('\n', "; ");
                // This is a local bounded loss-quality signal for distributed
                // consensus, not the BlackCat variational reward computed later.
                let roundtable_loss_quality = (1.0 / (1.0 + weighted_loss.abs())).clamp(0.0, 1.0);
                extra.insert(
                    "roundtable_loss_quality".to_string(),
                    roundtable_loss_quality as f64,
                );
                if let Some(summary) = node.record_decision(
                    signature,
                    script_hint,
                    plan.kind,
                    outcome,
                    roundtable_loss_quality,
                    psi_total_opt,
                    (band_energy.above, band_energy.here, band_energy.beneath),
                    band_energy.drift,
                    z_feedback.z_signal,
                ) {
                    if let Some(moderator) = self.blackcat_moderator.as_mut() {
                        let outcome = moderator.ingest(summary.clone());
                        if let Some(proposal) = outcome.proposal {
                            let (accepted, preview) =
                                simulate_proposal_locally(&proposal, &mut self.heur_log);
                            if accepted {
                                self.apply_proposal(&proposal, preview)?;
                            }
                        }
                    } else if let Some(conductor) = self.meta_conductor.as_mut() {
                        if let Some(proposal) = conductor.ingest(summary.clone()) {
                            let (accepted, preview) =
                                simulate_proposal_locally(&proposal, &mut self.heur_log);
                            if accepted {
                                self.apply_proposal(&proposal, preview)?;
                            }
                        }
                    }
                    if let Some(loop_signal) = hub::get_chrono_loop() {
                        let collapse_hint = psi_total_opt
                            .filter(|value| *value > 0.0)
                            .or((summary.mean_psi > 0.0).then_some(summary.mean_psi));
                        let support = (summary.support + summary.mean_score).max(0.1);
                        let envelope = LoopbackEnvelope::new(loop_signal)
                            .with_source(summary.node_id.clone())
                            .with_support(support)
                            .with_collapse_total(collapse_hint)
                            .with_z_signal(Some(z_feedback.z_signal))
                            .with_script_hint(Some(summary.script_hint.clone()));
                        hub::push_loopback_envelope(envelope);
                        loop_broadcasted = true;
                    }
                }
            }
            if !loop_broadcasted {
                if let Some(loop_signal) = hub::get_chrono_loop() {
                    let envelope = LoopbackEnvelope::new(loop_signal)
                        .with_support(1.0)
                        .with_collapse_total(psi_total_opt.filter(|value| *value > 0.0))
                        .with_z_signal(Some(z_feedback.z_signal));
                    hub::push_loopback_envelope(envelope);
                }
            }
            let batch_infusion = self
                .text_infusion
                .clone()
                .filter(|infusion| infusion.every == TextInfusionEvery::Batch);
            if let Some(infusion) = batch_infusion
                .as_ref()
                .filter(|infusion| infusion.mode == TextInfusionMode::Blend)
            {
                module.infuse_text(&infusion.text)?;
            }
            let curvature_summary = if self.curvature_scheduler.is_some() {
                Some(Self::collect_gradient_summary(module)?)
            } else {
                None
            };
            let update_snapshot = if trace_parameter_updates {
                Some(capture_parameter_value_snapshot(module)?)
            } else {
                None
            };
            let optim_step_fallback_lr = self.fallback_learning_rate;
            let optim_step_hyper_lr = self.hyper_learning_rate;
            let optim_step_real_lr = self.real_learning_rate;
            let optim_step_grad_clip = self.grad_clip_max_norm;
            let optim_state_before_step = self.optimizer_state();
            self.step(module)?;
            if let Some(snapshot) = update_snapshot.as_ref() {
                collect_parameter_update_stats(module, snapshot)?.write_extra(&mut extra);
            }
            optim_state_before_step.write_extra(&mut extra);
            self.last_accumulator_sync.write_extra(&mut extra);
            extra.insert(
                "optim_step_fallback_lr".to_string(),
                optim_step_fallback_lr as f64,
            );
            extra.insert(
                "optim_step_hyper_lr".to_string(),
                optim_step_hyper_lr as f64,
            );
            extra.insert(
                "optim_realgrad_enabled".to_string(),
                if optim_step_real_lr.is_some() {
                    1.0
                } else {
                    0.0
                },
            );
            if let Some(rate) = optim_step_real_lr {
                extra.insert("optim_step_real_lr".to_string(), rate as f64);
            }
            if let Some(limit) = optim_step_grad_clip {
                extra.insert("optim_step_grad_clip_max_norm".to_string(), limit as f64);
            }
            if let Some(summary) = curvature_summary {
                if let Some(decision) = self.apply_curvature_scheduler(module, summary)? {
                    extra.insert(
                        "curvature_pressure".to_string(),
                        decision.raw_pressure as f64,
                    );
                    extra.insert(
                        "curvature_pressure_ema".to_string(),
                        decision.smoothed_pressure as f64,
                    );
                    extra.insert("curvature_value".to_string(), decision.curvature as f64);
                    if decision.changed {
                        extra.insert("curvature_adjusted".to_string(), 1.0);
                    }
                    if let Some(scheduler) = self.curvature_scheduler.as_ref() {
                        extra.insert(
                            "curvature_kp".to_string(),
                            scheduler.proportional_gain() as f64,
                        );
                        extra.insert("curvature_step".to_string(), scheduler.step_size() as f64);
                        extra.insert(
                            "curvature_tolerance".to_string(),
                            scheduler.tolerance() as f64,
                        );
                        extra.insert(
                            "curvature_dither_strength".to_string(),
                            scheduler.dither_strength() as f64,
                        );
                        extra.insert(
                            "curvature_dither_period".to_string(),
                            scheduler.dither_period() as f64,
                        );
                        if let Some(var) = scheduler.last_pressure_variance() {
                            extra.insert("curvature_pressure_var".to_string(), var as f64);
                        }
                        if let Some(rel_var) = scheduler.last_pressure_rel_variance() {
                            extra.insert("curvature_pressure_rel_var".to_string(), rel_var as f64);
                        }
                    }
                }
            }
            if let Some(infusion) = batch_infusion
                .as_ref()
                .filter(|infusion| infusion.mode == TextInfusionMode::Separate)
            {
                module.infuse_text(&infusion.text)?;
                self.step(module)?;
            }
            self.zero(module)?;
            steps += 1;

            let phase_label = self
                .spectral_policy
                .as_ref()
                .and_then(|policy| policy.last_coherence_label())
                .or(coherence_label);
            let mut phase_label_change = None;
            if let Some(label) = phase_label {
                if let Some(previous) = self.phase_last_label {
                    if previous != label {
                        phase_label_change = Some((previous, label));
                    }
                }
                self.phase_last_label = Some(label);
            }

            let mut turnover_spike = None;
            if let Some(turnover) = spectral_turnover {
                if let Some(previous) = self.phase_last_turnover {
                    if previous <= self.phase_turnover_spike_threshold
                        && turnover > self.phase_turnover_spike_threshold
                    {
                        turnover_spike = Some((previous, turnover));
                    }
                }
                self.phase_last_turnover = Some(turnover);
            }

            let mut band_shift = None;
            let band_abs = [
                baseline_band_energy.above.abs(),
                baseline_band_energy.here.abs(),
                baseline_band_energy.beneath.abs(),
            ];
            let mut dominant_band = 0usize;
            for idx in 1..band_abs.len() {
                if band_abs[idx] > band_abs[dominant_band] {
                    dominant_band = idx;
                }
            }
            let dominant_band = dominant_band as u8;
            if let Some(previous) = self.phase_last_band {
                if previous != dominant_band {
                    band_shift = Some((previous, dominant_band));
                }
            }
            self.phase_last_band = Some(dominant_band);

            let mut drift_spike = None;
            let drift_abs = band_energy.drift.abs();
            if drift_abs.is_finite() {
                if let Some(previous) = self.phase_last_drift_abs {
                    if previous <= self.phase_drift_spike_threshold
                        && drift_abs > self.phase_drift_spike_threshold
                    {
                        drift_spike = Some((previous, drift_abs));
                    }
                }
                self.phase_last_drift_abs = Some(drift_abs);
            }

            let mut loss_spike = None;
            let loss_value = weighted_loss.abs();
            if loss_value.is_finite() {
                let ema = if let Some(previous) = self.phase_loss_ema {
                    previous + self.phase_loss_ema_alpha * (loss_value - previous)
                } else {
                    loss_value
                };
                self.phase_loss_ema = Some(ema);
                let threshold = ema * (1.0 + self.phase_loss_spike_ratio);
                let spiking = threshold.is_finite() && loss_value > threshold;
                if spiking && !self.phase_loss_spiking {
                    loss_spike = Some((loss_value, ema, threshold));
                }
                self.phase_loss_spiking = spiking;
            }

            let bus = global_registry().event_bus();
            if bus.has_listeners("TrainerPhase") {
                let label_code = |label: CoherenceLabel| -> u8 {
                    match label {
                        CoherenceLabel::Background => 0,
                        CoherenceLabel::SymmetricPulse => 1,
                        CoherenceLabel::CascadeImbalance => 2,
                        CoherenceLabel::DiffuseDrift => 3,
                    }
                };

                if let Some((from, to)) = phase_label_change {
                    bus.publish(&PluginEvent::custom(
                        "TrainerPhase",
                        serde_json::json!({
                            "epoch": epoch,
                            "step": steps,
                            "kind": "label_change",
                            "from": {"code": label_code(from), "label": from.to_string()},
                            "to": {"code": label_code(to), "label": to.to_string()},
                            "turnover": spectral_turnover.map(|v| v as f64),
                            "curvature": self.curvature as f64,
                        }),
                    ));
                }

                if let Some((prev, now)) = turnover_spike {
                    bus.publish(&PluginEvent::custom(
                        "TrainerPhase",
                        serde_json::json!({
                            "epoch": epoch,
                            "step": steps,
                            "kind": "turnover_spike",
                            "turnover_prev": prev as f64,
                            "turnover": now as f64,
                            "threshold": self.phase_turnover_spike_threshold as f64,
                            "label": phase_label.map(|label| label.to_string()),
                            "label_code": phase_label.map(label_code),
                            "curvature": self.curvature as f64,
                        }),
                    ));
                }

                let band_name = |code: u8| -> &'static str {
                    match code {
                        0 => "above",
                        1 => "here",
                        2 => "beneath",
                        _ => "unknown",
                    }
                };

                if let Some((from, to)) = band_shift {
                    bus.publish(&PluginEvent::custom(
                        "TrainerPhase",
                        serde_json::json!({
                            "epoch": epoch,
                            "step": steps,
                            "kind": "band_shift",
                            "from": {"code": from, "band": band_name(from)},
                            "to": {"code": to, "band": band_name(to)},
                            "baseline_energy": {
                                "above": baseline_band_energy.above as f64,
                                "here": baseline_band_energy.here as f64,
                                "beneath": baseline_band_energy.beneath as f64,
                                "drift": baseline_band_energy.drift as f64,
                            },
                            "energy": {
                                "above": band_energy.above as f64,
                                "here": band_energy.here as f64,
                                "beneath": band_energy.beneath as f64,
                                "drift": band_energy.drift as f64,
                            },
                            "turnover": spectral_turnover.map(|v| v as f64),
                            "label": phase_label.map(|label| label.to_string()),
                            "label_code": phase_label.map(label_code),
                            "curvature": self.curvature as f64,
                        }),
                    ));
                }

                if let Some((prev, now)) = drift_spike {
                    bus.publish(&PluginEvent::custom(
                        "TrainerPhase",
                        serde_json::json!({
                            "epoch": epoch,
                            "step": steps,
                            "kind": "drift_spike",
                            "drift": band_energy.drift as f64,
                            "drift_abs_prev": prev as f64,
                            "drift_abs": now as f64,
                            "threshold": self.phase_drift_spike_threshold as f64,
                            "turnover": spectral_turnover.map(|v| v as f64),
                            "label": phase_label.map(|label| label.to_string()),
                            "label_code": phase_label.map(label_code),
                            "curvature": self.curvature as f64,
                        }),
                    ));
                }

                if let Some((loss, ema, threshold)) = loss_spike {
                    bus.publish(&PluginEvent::custom(
                        "TrainerPhase",
                        serde_json::json!({
                            "epoch": epoch,
                            "step": steps,
                            "kind": "loss_spike",
                            "loss_weighted": loss as f64,
                            "loss_ema": ema as f64,
                            "threshold": threshold as f64,
                            "ratio": self.phase_loss_spike_ratio as f64,
                            "turnover": spectral_turnover.map(|v| v as f64),
                            "label": phase_label.map(|label| label.to_string()),
                            "label_code": phase_label.map(label_code),
                            "curvature": self.curvature as f64,
                        }),
                    ));
                }
            }

            let elapsed_ms = if let Some(rt) = self.blackcat.as_ref() {
                rt.elapsed_since_begin()
                    .unwrap_or_else(|| Duration::from_secs_f64(0.0))
                    .as_secs_f64()
                    * 1_000.0
            } else {
                step_start.elapsed().as_secs_f64() * 1_000.0
            };
            extra.insert("band_above".to_string(), band_energy.above as f64);
            extra.insert("band_here".to_string(), band_energy.here as f64);
            extra.insert("band_beneath".to_string(), band_energy.beneath as f64);
            extra.insert("band_drift".to_string(), band_energy.drift as f64);
            extra.insert(
                "band_sheet_confidence".to_string(),
                band_energy.spectral.sheet_confidence as f64,
            );
            extra.insert("band_spin".to_string(), band_energy.spectral.spin as f64);
            extra.insert(
                "band_curvature".to_string(),
                band_energy.spectral.curvature as f64,
            );
            extra.insert(
                "band_mean_energy".to_string(),
                band_energy.spectral.energy as f64,
            );
            self.last_band_energy = Some(band_energy);
            if !step_loss.is_finite() {
                extra.insert("step_loss_non_finite".to_string(), 1.0);
            }
            if !weighted_loss.is_finite() {
                extra.insert("loss_weighted_non_finite".to_string(), 1.0);
            }
            extra.insert("step_loss".to_string(), step_loss as f64);
            extra.insert("loss_weighted".to_string(), weighted_loss as f64);
            extra.insert("reference_loss".to_string(), step_loss as f64);
            extra.insert("candidate_loss".to_string(), weighted_loss as f64);
            #[cfg(feature = "psychoid")]
            {
                extra.insert("psychoid_events".to_string(), psychoid_events as f64);
            }
            let mut metrics = StepMetrics {
                step_time_ms: elapsed_ms,
                mem_peak_mb: 0.0,
                retry_rate: 0.0,
                extra,
            };
            if let Some(ap) = self.autopilot.as_mut() {
                let _ = ap
                    .try_report(&metrics)
                    .map_err(|_| TensorError::InvalidValue {
                        label: "autopilot report",
                    })?;
            }
            let mut free_energy_report = None;
            let mut heuristic_adoption_report = None;
            if let Some(rt) = self.blackcat.as_mut() {
                let report =
                    rt.try_post_step_report(&metrics)
                        .map_err(|_| TensorError::InvalidValue {
                            label: "blackcat free-energy reward",
                        })?;
                let reward = report.utility;
                metrics
                    .extra
                    .insert("free_energy".to_string(), report.free_energy);
                metrics
                    .extra
                    .insert("free_energy_utility".to_string(), report.utility);
                metrics.extra.insert(
                    "free_energy_acceptance_probability".to_string(),
                    report.acceptance_probability,
                );
                metrics.extra.insert(
                    "free_energy_kl".to_string(),
                    report.distribution.kl_divergence,
                );
                metrics.extra.insert(
                    "free_energy_band_potential".to_string(),
                    report.components.band_potential,
                );
                let plan = step_schedule.above();
                let script = plan
                    .choice
                    .to_unison_script(RankKind::TopK)
                    .replace('\n', "; ");
                let adoption = rt.try_observe_soft(&script, reward > 0.0).map_err(|_| {
                    TensorError::InvalidValue {
                        label: "blackcat heuristic evidence",
                    }
                })?;
                metrics.extra.insert(
                    "blackcat_heuristic_successes".to_string(),
                    adoption.interval.successes as f64,
                );
                metrics.extra.insert(
                    "blackcat_heuristic_trials".to_string(),
                    adoption.interval.trials as f64,
                );
                metrics.extra.insert(
                    "blackcat_heuristic_wilson_lower".to_string(),
                    adoption.interval.lower,
                );
                metrics.extra.insert(
                    "blackcat_heuristic_eligible".to_string(),
                    if adoption.eligible { 1.0 } else { 0.0 },
                );
                metrics.extra.insert(
                    "blackcat_heuristic_persisted".to_string(),
                    if adoption.decision.is_persisted() {
                        1.0
                    } else {
                        0.0
                    },
                );
                metrics.extra.insert(
                    "blackcat_heuristic_persistence_failed".to_string(),
                    if adoption.persistence_error.is_some() {
                        1.0
                    } else {
                        0.0
                    },
                );
                heuristic_adoption_report = Some(adoption);
                free_energy_report = Some(report);
            }
            bus.publish(&PluginEvent::custom(
                "TrainerStep",
                serde_json::json!({
                    "epoch": epoch,
                    "step": steps,
                    "metrics": {
                        "step_time_ms": metrics.step_time_ms,
                        "mem_peak_mb": metrics.mem_peak_mb,
                        "retry_rate": metrics.retry_rate,
                        "extra": &metrics.extra,
                    },
                    "free_energy": free_energy_report.as_ref(),
                    "heuristic_adoption": heuristic_adoption_report.as_ref(),
                    "runtime_execution_plan_output_sha256": backend_policy.runtime_plan_output_sha256_hex(),
                    "autopilot": autopilot_picks.as_ref().map(|picks| serde_json::json!({
                        "picks": picks,
                        "selection": autopilot_selection_witness.as_ref(),
                        "executed_choices": {
                            "above": {
                                "wg": step_schedule.above().choice.wg,
                                "kl": step_schedule.above().choice.kl,
                                "ch": step_schedule.above().choice.ch,
                                "mk": step_schedule.above().choice.mk,
                                "mkd": step_schedule.above().choice.mkd,
                                "tile": step_schedule.above().choice.tile,
                                "ctile": step_schedule.above().choice.ctile,
                                "subgroup": step_schedule.above().choice.subgroup,
                                "fft_tile": step_schedule.above().choice.fft_tile,
                                "fft_radix": step_schedule.above().choice.fft_radix,
                                "fft_segments": step_schedule.above().choice.fft_segments,
                            },
                            "here": {
                                "wg": step_schedule.here().choice.wg,
                                "kl": step_schedule.here().choice.kl,
                                "ch": step_schedule.here().choice.ch,
                                "mk": step_schedule.here().choice.mk,
                                "mkd": step_schedule.here().choice.mkd,
                                "tile": step_schedule.here().choice.tile,
                                "ctile": step_schedule.here().choice.ctile,
                                "subgroup": step_schedule.here().choice.subgroup,
                                "fft_tile": step_schedule.here().choice.fft_tile,
                                "fft_radix": step_schedule.here().choice.fft_radix,
                                "fft_segments": step_schedule.here().choice.fft_segments,
                            },
                            "beneath": {
                                "wg": step_schedule.beneath().choice.wg,
                                "kl": step_schedule.beneath().choice.kl,
                                "ch": step_schedule.beneath().choice.ch,
                                "mk": step_schedule.beneath().choice.mk,
                                "mkd": step_schedule.beneath().choice.mkd,
                                "tile": step_schedule.beneath().choice.tile,
                                "ctile": step_schedule.beneath().choice.ctile,
                                "subgroup": step_schedule.beneath().choice.subgroup,
                                "fft_tile": step_schedule.beneath().choice.fft_tile,
                                "fft_radix": step_schedule.beneath().choice.fft_radix,
                                "fft_segments": step_schedule.beneath().choice.fft_segments,
                            },
                        },
                    })),
                }),
            ));
        }
        let stats = EpochStats {
            batches: steps,
            total_loss,
            average_loss: if steps == 0 {
                0.0
            } else {
                total_loss / steps as f32
            },
            tensor_backend: epoch_tensor_backend,
        };
        self.cumulative_backend_counters
            .saturating_accumulate(stats.tensor_backend.checkpoint_counters());
        global_registry()
            .event_bus()
            .publish(&PluginEvent::EpochEnd {
                epoch,
                loss: stats.average_loss,
            });
        Ok(stats)
    }

    /// Evaluates an epoch without accumulating gradients or stepping parameters.
    pub fn evaluate_epoch<M, L, I>(
        &mut self,
        module: &mut M,
        loss: &mut L,
        batches: I,
    ) -> PureResult<EpochStats>
    where
        M: Module + ?Sized,
        L: Loss + ?Sized,
        I: IntoIterator,
        I::Item: IntoBatch,
    {
        module.eval()?;
        let result = (|| {
            let mut total_loss = 0.0f32;
            let mut steps = 0usize;
            let backend_policy = self.backend_policy();
            for batch in batches.into_iter() {
                let (input, target) = batch.into_batch()?;
                validate_trainer_tensor("trainer_eval_input", &input)?;
                validate_trainer_tensor("trainer_eval_target", &target)?;
                let _backend_policy_guard = push_backend_policy(backend_policy);
                let prediction = module.forward(&input)?;
                validate_trainer_tensor("trainer_eval_prediction", &prediction)?;
                let loss_value = loss.forward(&prediction, &target)?;
                validate_trainer_tensor("trainer_eval_loss", &loss_value)?;
                let step_loss = trainer_tensor_sum("trainer_eval_step_loss", &loss_value)?;
                total_loss =
                    validate_trainer_scalar("trainer_eval_total_loss", total_loss + step_loss)?;
                steps += 1;
            }
            let average_loss = if steps == 0 {
                0.0
            } else {
                validate_trainer_scalar("trainer_eval_average_loss", total_loss / steps as f32)?
            };
            Ok(EpochStats {
                batches: steps,
                total_loss,
                average_loss,
                tensor_backend: EpochTensorBackendStats::default(),
            })
        })();
        let restore = module.train();
        match (result, restore) {
            (Ok(stats), Ok(())) => Ok(stats),
            (Err(err), _) => Err(err),
            (Ok(_), Err(err)) => Err(err),
        }
    }

    /// Runs a reusable multi-epoch training loop with optional validation.
    pub fn train_epochs<M, L, B>(
        &mut self,
        module: &mut M,
        loss: &mut L,
        train_batches: &[B],
        validation_batches: Option<&[B]>,
        schedule: &RoundtableSchedule,
        config: TrainingRunConfig,
    ) -> PureResult<TrainingRunReport>
    where
        M: Module + ?Sized,
        L: Loss + ?Sized,
        B: Clone + IntoBatch,
    {
        self.train_epochs_from_factory(
            module,
            loss,
            |epoch_idx| batches_for_epoch(train_batches, config, epoch_idx),
            |_| validation_batches.map(|batches| batches.to_vec()),
            schedule,
            config,
        )
    }

    /// Runs a reusable multi-epoch training loop from [`DataLoader`] inputs.
    pub fn train_epochs_loader<M, L>(
        &mut self,
        module: &mut M,
        loss: &mut L,
        train_loader: &DataLoader,
        validation_loader: Option<&DataLoader>,
        schedule: &RoundtableSchedule,
        config: TrainingRunConfig,
    ) -> PureResult<TrainingRunReport>
    where
        M: Module + ?Sized,
        L: Loss + ?Sized,
    {
        self.train_epochs_from_factory(
            module,
            loss,
            |epoch_idx| loader_for_epoch(train_loader, config, epoch_idx),
            |_| validation_loader.cloned(),
            schedule,
            config,
        )
    }

    fn train_epochs_from_factory<M, L, FT, FV, TI, VI>(
        &mut self,
        module: &mut M,
        loss: &mut L,
        mut train_batches_for_epoch: FT,
        mut validation_batches_for_epoch: FV,
        schedule: &RoundtableSchedule,
        config: TrainingRunConfig,
    ) -> PureResult<TrainingRunReport>
    where
        M: Module + ?Sized,
        L: Loss + ?Sized,
        FT: FnMut(usize) -> TI,
        TI: IntoIterator,
        TI::Item: IntoBatch,
        FV: FnMut(usize) -> Option<VI>,
        VI: IntoIterator,
        VI::Item: IntoBatch,
    {
        let mut history = Vec::with_capacity(config.epochs());
        let mut best_score: Option<f32> = None;
        let mut best_epoch_index = None;
        let mut best_state = None;
        let mut stale_epochs = 0usize;
        let mut stopped_early = false;

        for epoch_idx in 0..config.epochs() {
            let train =
                self.train_epoch(module, loss, train_batches_for_epoch(epoch_idx), schedule)?;
            let validation = match validation_batches_for_epoch(epoch_idx) {
                Some(batches) => Some(self.evaluate_epoch(module, loss, batches)?),
                None => None,
            };
            let score = validation
                .as_ref()
                .map(|stats| stats.average_loss)
                .unwrap_or(train.average_loss);
            let improved = score.is_finite()
                && best_score
                    .map(|best| score + config.min_delta() < best)
                    .unwrap_or(true);
            if improved {
                best_score = Some(score);
                best_epoch_index = Some(history.len());
                if config.restore_best() {
                    best_state = Some(module.state_dict()?);
                }
                stale_epochs = 0;
            } else {
                stale_epochs = stale_epochs.saturating_add(1);
            }

            history.push(TrainingEpochStats {
                epoch: epoch_idx + 1,
                train,
                validation,
                score,
                improved,
            });

            if let Some(patience) = config.validation_patience() {
                if stale_epochs > patience {
                    stopped_early = true;
                    break;
                }
            }
        }

        let restored_best = if config.restore_best() {
            if let Some(state) = best_state.as_ref() {
                module.load_state_dict(state)?;
                true
            } else {
                false
            }
        } else {
            false
        };

        Ok(TrainingRunReport::new(
            history,
            best_epoch_index,
            stopped_early,
            restored_best,
        ))
    }

    fn apply_curvature_scheduler<M: Module + ?Sized>(
        &mut self,
        module: &mut M,
        summary: GradientSummary,
    ) -> PureResult<Option<CurvatureDecision>> {
        let Some(scheduler) = self.curvature_scheduler.as_mut() else {
            return Ok(None);
        };
        let decision = scheduler.observe(summary);
        self.last_curvature_metrics = Some(decision.into());
        if decision.changed {
            Self::retune_hypergrads(module, decision.curvature, self.hyper_learning_rate)?;
            self.curvature = decision.curvature;
            self.spectral_adapter
                .set_curvature_target(decision.curvature);
        }
        Ok(Some(decision))
    }

    fn estimate_device_load(&self) -> f64 {
        let caps = self.planner().device_caps();
        caps.occupancy_score(caps.max_workgroup) as f64
    }

    fn collect_gradient_summary<M: Module + ?Sized>(module: &M) -> PureResult<GradientSummary> {
        let mut accumulator = CurvatureGradientAccumulator::default();
        module.visit_parameters(&mut |param| {
            let mut accounted = false;
            if let Some(tape) = param.hypergrad() {
                accumulator.accumulate(tape.summary());
                accounted = true;
            }
            if let Some(tape) = param.realgrad() {
                accumulator.accumulate(tape.summary());
                accounted = true;
            }
            if !accounted {
                if let Some(grad) = param.gradient() {
                    accumulator.accumulate(GradientSummary::from_slice(grad.data()));
                }
            }
            Ok(())
        })?;
        Ok(accumulator.finish())
    }

    fn collect_gradient_health<M: Module + ?Sized>(module: &M) -> PureResult<GradientHealth> {
        let mut health = GradientHealth::default();
        module.visit_parameters(&mut |param| {
            let mut accounted = false;
            if let Some(tape) = param.hypergrad() {
                health.record_values(tape.gradient());
                accounted = true;
            }
            if let Some(tape) = param.realgrad() {
                health.record_values(tape.gradient());
                accounted = true;
            }
            if !accounted {
                if let Some(grad) = param.gradient() {
                    health.record_values(grad.data());
                }
            }
            Ok(())
        })?;
        Ok(health)
    }

    fn retune_hypergrads<M: Module + ?Sized>(
        module: &mut M,
        curvature: f32,
        learning_rate: f32,
    ) -> PureResult<()> {
        module.visit_parameters_mut(&mut |param| {
            if let Some(tape) = param.hypergrad_mut() {
                tape.retune(curvature, learning_rate)?;
            }
            Ok(())
        })
    }

    fn insert_desire_summary(target: &mut HashMap<String, f64>, summary: &DesireTrainerSummary) {
        target.insert("desire_steps".to_string(), summary.total as f64);
        target.insert(
            "desire_phase_observation".to_string(),
            summary.observation as f64,
        );
        target.insert(
            "desire_phase_injection".to_string(),
            summary.injection as f64,
        );
        target.insert(
            "desire_phase_integration".to_string(),
            summary.integration as f64,
        );
        target.insert(
            "desire_mean_entropy".to_string(),
            summary.mean_entropy as f64,
        );
        target.insert(
            "desire_mean_temperature".to_string(),
            summary.mean_temperature as f64,
        );
        target.insert(
            "desire_mean_penalty".to_string(),
            summary.mean_penalty as f64,
        );
        target.insert("desire_mean_alpha".to_string(), summary.mean_alpha as f64);
        target.insert("desire_mean_beta".to_string(), summary.mean_beta as f64);
        target.insert("desire_mean_gamma".to_string(), summary.mean_gamma as f64);
        target.insert("desire_mean_lambda".to_string(), summary.mean_lambda as f64);
        target.insert("desire_triggers".to_string(), summary.triggers as f64);
        target.insert(
            "desire_trigger_mean_penalty".to_string(),
            summary.trigger_mean_penalty as f64,
        );
        target.insert(
            "desire_trigger_mean_entropy".to_string(),
            summary.trigger_mean_entropy as f64,
        );
        target.insert(
            "desire_trigger_mean_temperature".to_string(),
            summary.trigger_mean_temperature as f64,
        );
        target.insert(
            "desire_trigger_mean_samples".to_string(),
            summary.trigger_mean_samples as f64,
        );
    }

    fn insert_desire_roundtable_summary(
        target: &mut HashMap<String, f64>,
        summary: &DesireRoundtableSummary,
    ) {
        target.insert("desire_roundtable_steps".to_string(), summary.steps as f64);
        target.insert(
            "desire_roundtable_triggers".to_string(),
            summary.triggers as f64,
        );
        target.insert(
            "desire_roundtable_mean_entropy".to_string(),
            summary.mean_entropy as f64,
        );
        target.insert(
            "desire_roundtable_mean_temperature".to_string(),
            summary.mean_temperature as f64,
        );
        target.insert(
            "desire_roundtable_mean_alpha".to_string(),
            summary.mean_alpha as f64,
        );
        target.insert(
            "desire_roundtable_mean_beta".to_string(),
            summary.mean_beta as f64,
        );
        target.insert(
            "desire_roundtable_mean_gamma".to_string(),
            summary.mean_gamma as f64,
        );
        target.insert(
            "desire_roundtable_mean_lambda".to_string(),
            summary.mean_lambda as f64,
        );
        target.insert(
            "desire_roundtable_mean_above".to_string(),
            summary.mean_above as f64,
        );
        target.insert(
            "desire_roundtable_mean_here".to_string(),
            summary.mean_here as f64,
        );
        target.insert(
            "desire_roundtable_mean_beneath".to_string(),
            summary.mean_beneath as f64,
        );
        target.insert(
            "desire_roundtable_mean_drift".to_string(),
            summary.mean_drift as f64,
        );
    }

    #[cfg(feature = "psi")]
    fn insert_desire_psi_summary(target: &mut HashMap<String, f64>, summary: &DesirePsiSummary) {
        target.insert("desire_psi_steps".to_string(), summary.steps as f64);
        target.insert("desire_psi_triggers".to_string(), summary.triggers as f64);
        target.insert("desire_psi_samples".to_string(), summary.psi_samples as f64);
        target.insert(
            "desire_psi_mean_total".to_string(),
            summary.mean_psi_total as f64,
        );
        target.insert(
            "desire_psi_mean_entropy".to_string(),
            summary.mean_entropy as f64,
        );
        target.insert(
            "desire_psi_mean_temperature".to_string(),
            summary.mean_temperature as f64,
        );
        target.insert(
            "desire_psi_mean_penalty".to_string(),
            summary.mean_hypergrad_penalty as f64,
        );
        target.insert(
            "desire_psi_mean_z".to_string(),
            summary.mean_z_signal as f64,
        );
        for (component, mean) in summary.component_means.iter() {
            let key = format!("desire_psi_component_{}_mean", component);
            target.insert(key, *mean as f64);
        }
        for (component, (up, down)) in summary.threshold_crossings.iter() {
            let up_key = format!("desire_psi_threshold_{}_up", component);
            let down_key = format!("desire_psi_threshold_{}_down", component);
            target.insert(up_key, *up as f64);
            target.insert(down_key, *down as f64);
        }
    }

    #[cfg(feature = "psi")]
    fn bootstrap_psi(&mut self, schedule: &RoundtableSchedule) {
        if self.psi.is_some() || !schedule.psi_enabled() {
            return;
        }
        let cfg = PsiConfig::automated(schedule.psi_hint());
        self.psi = Some(PsiMeter::new(cfg));
    }

    #[cfg(feature = "psychoid")]
    fn bootstrap_psychoid(&mut self, schedule: &RoundtableSchedule) {
        if self.psychoid.is_some() || !schedule.psychoid_enabled() {
            return;
        }
        let cfg = PsychoidConfig::default();
        self.psychoid = Some(PsychoidMeter::new(cfg));
        self.psychoid_log = schedule.psychoid_log();
    }

    fn scale_learning_rates<M: Module + ?Sized>(
        &mut self,
        module: &mut M,
        factor: f32,
    ) -> PureResult<()> {
        if !factor.is_finite() || factor <= 0.0 {
            return Err(TensorError::NonPositiveLearningRate { rate: factor });
        }
        let next_fallback_learning_rate =
            Self::checked_scaled_learning_rate(self.fallback_learning_rate, factor)?;
        let next_hyper_learning_rate =
            Self::checked_scaled_learning_rate(self.hyper_learning_rate, factor)?;
        let next_real_learning_rate = self
            .real_learning_rate
            .map(|rate| Self::checked_scaled_learning_rate(rate, factor))
            .transpose()?;
        scale_module_learning_rates(module, factor)?;
        self.fallback_learning_rate = next_fallback_learning_rate;
        self.hyper_learning_rate = next_hyper_learning_rate;
        if let Some(rate) = self.real_learning_rate.as_mut() {
            *rate = next_real_learning_rate.expect("real learning rate");
        }
        self.spectral_adapter.on_global_scale(factor);
        Ok(())
    }

    fn checked_scaled_learning_rate(rate: f32, factor: f32) -> PureResult<f32> {
        let next = rate * factor;
        if next <= 0.0 || !next.is_finite() {
            return Err(TensorError::NonPositiveLearningRate { rate: next });
        }
        Ok(next)
    }

    fn map_accumulator_sync_error(error: AccumulatorSyncError) -> TensorError {
        TensorError::BackendFailure {
            backend: "accumulator_synchronizer",
            message: error.to_string(),
        }
    }

    fn synchronize_parameter_accumulators<M: Module + ?Sized>(
        &mut self,
        module: &mut M,
    ) -> PureResult<()> {
        let Some(device) = self.accumulator_synchronizer.as_ref().cloned() else {
            self.last_accumulator_sync = TrainerAccumulatorSyncStats::disabled();
            return Ok(());
        };
        let mut stats = TrainerAccumulatorSyncStats {
            enabled: true,
            rank: device.rank(),
            world_size: device.world_size(),
            buffers: 0,
            values: 0,
        };
        module.visit_parameters_mut(&mut |param| {
            let buffers = param.synchronize_accumulators_with(|gradient| {
                stats.values += gradient.len();
                device
                    .synchronize_accumulators(gradient)
                    .map_err(Self::map_accumulator_sync_error)
            })?;
            stats.buffers += buffers;
            Ok(())
        })?;
        self.last_accumulator_sync = stats;
        Ok(())
    }

    #[cfg(feature = "collapse")]
    fn bootstrap_collapse(&mut self, schedule: &RoundtableSchedule) {
        if self.collapse.is_some() || !schedule.collapse_enabled() {
            return;
        }
        let cfg = CollapseConfig::automated(schedule.psi_hint());
        self.collapse = Some(CollapseDrive::new(cfg));
    }

    fn apply_grad_scale<M: Module + ?Sized>(&self, module: &mut M, scale: f32) -> PureResult<()> {
        if (scale - 1.0).abs() <= f32::EPSILON {
            return Ok(());
        }
        module.visit_parameters_mut(&mut |param| {
            param.scale_accumulators_with_backend_policy(scale)?;
            Ok(())
        })
    }

    fn clip_grad_global_norm<M: Module + ?Sized>(
        &self,
        module: &mut M,
        max_norm: f32,
    ) -> PureResult<()> {
        let clip = st_kernel_contracts::gradient_clip::GlobalNormClip::new(max_norm)
            .map_err(|e| TensorError::Generic(e.to_string()))?;
        let mut total = 0.0f64;
        module.visit_parameters(&mut |param| {
            total += param.accumulators_norm_sq();
            Ok(())
        })?;
        let factors = clip
            .factors(total)
            .map_err(|e| TensorError::Generic(e.to_string()))?;
        for &scale in factors.as_slice() {
            self.apply_grad_scale(module, scale)?;
        }
        Ok(())
    }

    #[cfg(feature = "collapse")]
    fn optimizer_mul_lr<M: Module + ?Sized>(
        &mut self,
        module: &mut M,
        factor: f32,
    ) -> PureResult<()> {
        self.scale_learning_rates(module, factor)
    }

    #[cfg(feature = "psi")]
    fn collect_grad_l2<M: Module + ?Sized>(module: &M) -> PureResult<f32> {
        let mut sum = 0.0f64;
        module.visit_parameters(&mut |param| {
            if let Some(tape) = param.hypergrad() {
                for &value in tape.gradient().iter() {
                    let v = value as f64;
                    sum += v * v;
                }
            }
            if let Some(tape) = param.realgrad() {
                for &value in tape.gradient().iter() {
                    let v = value as f64;
                    sum += v * v;
                }
            }
            if param.hypergrad().is_none() && param.realgrad().is_none() {
                if let Some(grad) = param.gradient() {
                    for &value in grad.data().iter() {
                        let v = value as f64;
                        sum += v * v;
                    }
                }
            }
            Ok(())
        })?;
        Ok((sum).sqrt() as f32)
    }

    fn apply_proposal(
        &mut self,
        proposal: &GlobalProposal,
        preview_metrics: HashMap<String, f32>,
    ) -> PureResult<()> {
        let _ = preview_metrics;
        let rewrite_ops = proposal
            .ops
            .iter()
            .filter(|op| {
                matches!(
                    op.kind,
                    HeurOpKind::AppendSoft { .. } | HeurOpKind::Retract { .. }
                )
            })
            .count()
            .min(u32::MAX as usize) as u32;
        if let Some(budget) = self.rewrite_budget.as_mut() {
            if !budget.try_consume(rewrite_ops) {
                return Ok(());
            }
        }
        for op in &proposal.ops {
            let mut applied = op.clone();
            applied.issued_at = SystemTime::now();
            self.heur_log.append(applied);
        }
        Ok(())
    }

    #[cfg(feature = "psychoid")]
    fn log_psychoid(reading: &PsychoidReading, events: &[PsychoidEvent]) {
        println!(
            "[psychoid] step={} cti={:.4} raw={{D:{:.3} S:{:.3} C:{:.3} K:{:.3} H:{:.3}}}",
            reading.step,
            reading.cti,
            reading.raw.get("D").copied().unwrap_or(0.0),
            reading.raw.get("S").copied().unwrap_or(0.0),
            reading.raw.get("C").copied().unwrap_or(0.0),
            reading.raw.get("K").copied().unwrap_or(0.0),
            reading.raw.get("H").copied().unwrap_or(0.0)
        );
        for event in events {
            match event {
                PsychoidEvent::DreamPass { step, cti } => {
                    println!("[psychoid-event] step={} dream-pass cti={:.4}", step, cti);
                }
                PsychoidEvent::DreamExport {
                    step,
                    diary,
                    symbols,
                } => {
                    println!(
                        "[psychoid-event] step={} dream-export symbols={:?} diary=\"{}\"",
                        step, symbols, diary
                    );
                }
            }
        }
    }
}

fn outcome_label(outcome: OutcomeBand) -> &'static str {
    match outcome {
        OutcomeBand::Above => "above",
        OutcomeBand::Here => "here",
        OutcomeBand::Beneath => "beneath",
    }
}

fn plan_signature(plan: &st_core::ops::rank_entry::RankPlan, outcome: OutcomeBand) -> String {
    format!(
        "{:?}:{}x{}:k{}:{}",
        plan.kind,
        plan.rows,
        plan.cols,
        plan.k,
        outcome_label(outcome)
    )
}

fn epoch_shuffle_seed(config: TrainingRunConfig, epoch_index: usize) -> Option<u64> {
    config
        .epoch_shuffle_seed()
        .map(|seed| seed.wrapping_add(epoch_index as u64))
}

fn batches_for_epoch<B: Clone>(
    batches: &[B],
    config: TrainingRunConfig,
    epoch_index: usize,
) -> Vec<B> {
    let mut items = batches.to_vec();
    if let Some(seed) = epoch_shuffle_seed(config, epoch_index) {
        let mut rng = StdRng::seed_from_u64(seed);
        items.shuffle(&mut rng);
    }
    items
}

fn loader_for_epoch(
    loader: &DataLoader,
    config: TrainingRunConfig,
    epoch_index: usize,
) -> DataLoader {
    let loader = loader.clone();
    match epoch_shuffle_seed(config, epoch_index) {
        Some(seed) => loader.shuffle(seed),
        None => loader,
    }
}

/// Metrics captured while running [`ModuleTrainer::train_epoch`].
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct EpochStats {
    pub batches: usize,
    pub total_loss: f32,
    pub average_loss: f32,
    pub tensor_backend: EpochTensorBackendStats,
}

/// Configuration for running several training epochs with optional validation.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TrainingRunConfig {
    epochs: usize,
    validation_patience: Option<usize>,
    min_delta: f32,
    epoch_shuffle_seed: Option<u64>,
    restore_best: bool,
}

impl TrainingRunConfig {
    /// Creates a multi-epoch training configuration.
    pub fn new(epochs: usize) -> Self {
        Self {
            epochs,
            validation_patience: None,
            min_delta: 0.0,
            epoch_shuffle_seed: None,
            restore_best: false,
        }
    }

    /// Sets how many non-improving epochs are tolerated before stopping.
    pub fn with_validation_patience(mut self, patience: Option<usize>) -> Self {
        self.validation_patience = patience;
        self
    }

    /// Sets the minimum score improvement required to reset patience.
    pub fn with_min_delta(mut self, min_delta: f32) -> Self {
        self.min_delta = min_delta.max(0.0);
        self
    }

    /// Sets the seed used to deterministically reshuffle training batches each epoch.
    pub fn with_epoch_shuffle_seed(mut self, seed: Option<u64>) -> Self {
        self.epoch_shuffle_seed = seed;
        self
    }

    /// Restores the best recorded parameter state before returning the report.
    pub fn with_restore_best(mut self, restore_best: bool) -> Self {
        self.restore_best = restore_best;
        self
    }

    /// Returns the number of epochs requested.
    pub fn epochs(&self) -> usize {
        self.epochs
    }

    /// Returns the optional early-stop patience.
    pub fn validation_patience(&self) -> Option<usize> {
        self.validation_patience
    }

    /// Returns the minimum score improvement required to count as better.
    pub fn min_delta(&self) -> f32 {
        self.min_delta
    }

    /// Returns the seed used to reshuffle training batches per epoch, when enabled.
    pub fn epoch_shuffle_seed(&self) -> Option<u64> {
        self.epoch_shuffle_seed
    }

    /// Returns whether the run should restore the best recorded parameter state.
    pub fn restore_best(&self) -> bool {
        self.restore_best
    }
}

impl Default for TrainingRunConfig {
    fn default() -> Self {
        Self::new(1)
    }
}

/// Metrics captured for one epoch inside a multi-epoch training run.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TrainingEpochStats {
    pub epoch: usize,
    pub train: EpochStats,
    pub validation: Option<EpochStats>,
    pub score: f32,
    pub improved: bool,
}

/// Aggregated report emitted by [`ModuleTrainer::train_epochs`].
#[derive(Debug, Clone, PartialEq)]
pub struct TrainingRunReport {
    pub epochs: Vec<TrainingEpochStats>,
    pub best_epoch_index: Option<usize>,
    pub stopped_early: bool,
    pub restored_best: bool,
}

impl TrainingRunReport {
    /// Builds a report from the captured epoch history.
    pub fn new(
        epochs: Vec<TrainingEpochStats>,
        best_epoch_index: Option<usize>,
        stopped_early: bool,
        restored_best: bool,
    ) -> Self {
        Self {
            epochs,
            best_epoch_index,
            stopped_early,
            restored_best,
        }
    }

    /// Returns the best epoch, using validation loss when available.
    pub fn best_epoch(&self) -> Option<&TrainingEpochStats> {
        self.best_epoch_index
            .and_then(|index| self.epochs.get(index))
    }

    /// Returns the last recorded epoch.
    pub fn last_epoch(&self) -> Option<&TrainingEpochStats> {
        self.epochs.last()
    }

    /// Returns the number of epochs that actually ran.
    pub fn epochs_run(&self) -> usize {
        self.epochs.len()
    }
}

#[derive(Default)]
struct CurvatureGradientAccumulator {
    l1: f64,
    sum: f64,
    sum_squares: f64,
    sum_cubes: f64,
    sum_quartic: f64,
    linf: f32,
    count: usize,
    min: f32,
    max: f32,
    positive: usize,
    negative: usize,
    near_zero: usize,
}

impl CurvatureGradientAccumulator {
    fn accumulate(&mut self, summary: GradientSummary) {
        self.l1 += summary.l1() as f64;
        self.sum += summary.sum() as f64;
        self.sum_squares += summary.sum_squares() as f64;
        self.sum_cubes += summary.sum_cubes() as f64;
        self.sum_quartic += summary.sum_quartic() as f64;
        self.linf = self.linf.max(summary.linf());
        self.count += summary.count();
        if self.count == summary.count() {
            self.min = summary.min();
            self.max = summary.max();
        } else {
            self.min = self.min.min(summary.min());
            self.max = self.max.max(summary.max());
        }
        self.positive += summary.positive_count();
        self.negative += summary.negative_count();
        self.near_zero += summary.near_zero_count();
    }

    fn finish(self) -> GradientSummary {
        if self.count == 0 {
            GradientSummary::default()
        } else {
            GradientSummary::from_extended_moments(
                self.l1 as f32,
                self.sum as f32,
                self.sum_squares as f32,
                self.sum_cubes as f32,
                self.sum_quartic as f32,
                self.linf,
                self.count,
            )
            .with_support(
                self.min,
                self.max,
                self.positive,
                self.negative,
                self.near_zero,
            )
        }
    }
}

/// Helper trait that allows [`ModuleTrainer::train_epoch`] to accept both raw
/// `(Tensor, Tensor)` batches and fallible [`PureResult`] batches produced by
/// the [`crate::dataset::DataLoader`] surface.
pub trait IntoBatch {
    fn into_batch(self) -> PureResult<(Tensor, Tensor)>;
}

impl IntoBatch for (Tensor, Tensor) {
    fn into_batch(self) -> PureResult<(Tensor, Tensor)> {
        Ok(self)
    }
}

impl IntoBatch for PureResult<(Tensor, Tensor)> {
    fn into_batch(self) -> PureResult<(Tensor, Tensor)> {
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dataset::Dataset;
    use crate::gnn::{GraphActivation, GraphContext, GraphLayerSpec, ZSpaceGraphNetworkBuilder};
    use crate::language::{
        constant, warmup, ConceptHint, DesireAutomation, DesireLagrangian, DesirePipeline,
        DesireTrainerBridge, DesireTriggerBuffer, RepressionField, SemanticBridge, SparseKernel,
        SymbolGeometry, TemperatureController,
    };
    use crate::layers::linear::Linear;
    use crate::layers::sequential::Sequential;
    use crate::layers::wave_gate::WaveGate;
    use crate::loss::MeanSquaredError;
    use crate::module::Parameter;
    use crate::roundtable::RoundtableGnnBridge;
    use crate::roundtable::{HeurOp, HeurOpKind};
    use crate::schedule::RoundtableConfig;
    use crate::zspace_coherence::{
        ZSpaceCoherenceSequencer, ZSpaceTraceConfig, ZSpaceTraceRecorder,
    };
    #[cfg(feature = "golden")]
    use crate::CouncilEvidence;
    use st_core::backend::execution_plan::{
        evaluate_runtime_execution_plan, RuntimeComponentResolution, RuntimeExecutionPlanRequest,
    };
    use st_core::backend::runtime_probe::{
        evaluate_runtime_device_probe, RuntimeDeviceProbeRequest,
    };
    use st_core::inference::zspace_coherence::{
        build_zspace_coherence_distribution_witness, summarize_zspace_coherence_distribution,
    };
    use st_core::plugin::{PluginEventRecorder, PluginEventRecorderConfig, PluginEventSnapshot};
    use st_core::runtime::autopilot::{AutoConfig, AutoMode, KnobSpec};
    use st_core::runtime::blackcat::{
        bandit::SoftBanditMode, zmeta::ZMetaParams, ChoiceGroups, SoftHeuristicAdoptionConfig,
    };
    use st_core::runtime::zspace_optimizer::{
        transition_zspace_meta_optimizer, ZSpaceMetaObservation, ZSpaceMetaOptimizerConfig,
        ZSpaceMetaOptimizerState, ZSpaceMetaOptimizerStepRequest,
    };
    use st_core::telemetry::hub::{SoftlogicEllipticSample, SoftlogicZFeedback};
    use st_core::telemetry::xai::GraphFlowTracer;
    use st_core::telemetry::zspace_region::{ZSpaceRadiusBand, ZSpaceRegionKey, ZSpaceSpinBand};
    use st_core::theory::zpulse::ZSource;
    use st_tensor::topos::{OpenCartesianTopos, ToposOptimizerStateControl};
    use std::collections::{BTreeMap, HashMap};
    use std::num::NonZeroUsize;
    use std::sync::{Arc, Mutex};
    use std::time::{Duration, Instant, SystemTime};

    fn committed_cpu_session_plan(config: ExecutionConfig) -> RuntimeExecutionPlanPayload {
        let runtime_probe = evaluate_runtime_device_probe(RuntimeDeviceProbeRequest {
            requested_backend: BackendKind::Cpu,
            caps: DeviceCaps::cpu(),
            mps_probe: None,
            requested_workgroup: None,
            cols: None,
            tile_hint: None,
            compaction_hint: None,
        })
        .expect("CPU runtime probe");
        let request = RuntimeExecutionPlanRequest {
            runtime_probe,
            execution_config: config,
            component_resolution: RuntimeComponentResolution::Deferred,
            component_workloads: Vec::new(),
            component_capability_observation: None,
            tensor_util_values: None,
            required_native_components: Vec::new(),
        };
        evaluate_runtime_execution_plan(request).expect("committed CPU execution plan")
    }

    fn parameter_control_report(
        state: ZSpaceMetaOptimizerState,
        learning_rate_scale: f64,
    ) -> ZSpaceMetaOptimizerStepReport {
        transition_zspace_meta_optimizer(ZSpaceMetaOptimizerStepRequest {
            config: ZSpaceMetaOptimizerConfig {
                dimension: 2,
                topos_control_gain: 1.0,
                ..ZSpaceMetaOptimizerConfig::default()
            },
            state,
            observation: ZSpaceMetaObservation {
                gradient: vec![0.1, -0.2],
                telemetry: BTreeMap::from([(
                    "topos.training_hints.learning_rate_scale".to_owned(),
                    learning_rate_scale,
                )]),
                ..ZSpaceMetaObservation::default()
            },
        })
        .expect("parameter control report")
    }

    fn coherence_signal_for_weights(
        weights: Vec<f32>,
        energy_ratio: f32,
        z_bias: f32,
    ) -> CoherenceSignal {
        let channels = weights.len();
        let raw_mean_coherence = weights.iter().sum::<f32>() / channels as f32;
        let distribution = summarize_zspace_coherence_distribution(&weights).unwrap();
        let distribution_witness = build_zspace_coherence_distribution_witness(&weights).unwrap();
        let dominant_channel = weights
            .iter()
            .enumerate()
            .max_by(|(_, lhs), (_, rhs)| lhs.total_cmp(rhs))
            .map(|(index, _)| index);
        let preserved_channels = weights.iter().filter(|weight| **weight > 0.0).count();
        let normalized_weights = weights
            .iter()
            .map(|weight| f64::from(*weight))
            .collect::<Vec<_>>();
        let projection = project_zspace_coherence(ZSpaceCoherenceProjectionRequest {
            diagnostics: ZSpaceCoherenceDiagnosticsInput {
                mean_coherence: f64::from(raw_mean_coherence),
                coherence_entropy: distribution.weight_entropy,
                energy_ratio: f64::from(energy_ratio),
                z_bias: f64::from(z_bias),
                fractional_order: 0.0,
                normalized_weights: normalized_weights.clone(),
                preserved_channels: Some(preserved_channels),
                discarded_channels: Some(channels - preserved_channels),
                dominant_channel,
            },
            coherence: normalized_weights,
            contour: None,
            config: ZSpaceCoherenceProjectionConfig::default(),
            classification_policy: ZSpaceCoherenceClassificationPolicy::default(),
        })
        .unwrap();
        CoherenceSignal {
            dominant_channel,
            preserved_channels,
            z_bias,
            distribution_witness,
            control: projection.control.unwrap(),
            classification: projection.classification.unwrap(),
            repaired_non_finite_weights: 0,
            repaired_negative_weights: 0,
            pre_discard_repaired_non_finite: 0,
            pre_discard_repaired_negative: 0,
        }
    }

    fn build_language_geometry() -> SymbolGeometry {
        let syn = SparseKernel::from_rows(
            vec![vec![(0, 0.6), (1, 0.4)], vec![(0, 0.5), (1, 0.5)]],
            1e-6,
        )
        .unwrap();
        let par = SparseKernel::from_rows(
            vec![vec![(0, 0.7), (1, 0.3)], vec![(0, 0.2), (1, 0.8)]],
            1e-6,
        )
        .unwrap();
        SymbolGeometry::new(syn, par).unwrap()
    }

    fn build_language_semantics() -> SemanticBridge {
        use std::collections::HashSet;

        let log_pi = vec![
            vec![(0, (0.65f32).ln()), (1, (0.35f32).ln())],
            vec![(0, (0.4f32).ln()), (1, (0.6f32).ln())],
        ];
        let row = vec![1.0, 1.0];
        let col = vec![1.0, 1.0];
        let anchors = HashSet::new();
        let concept_kernel =
            SparseKernel::from_rows(vec![vec![(0, 1.0)], vec![(1, 1.0)]], 1e-6).unwrap();
        SemanticBridge::new(log_pi, row, col, anchors, 1e-6, concept_kernel).unwrap()
    }

    fn build_language_automation() -> DesireAutomation {
        let geometry = build_language_geometry();
        let repression = RepressionField::new(vec![0.05, 0.15]).unwrap();
        let semantics = build_language_semantics();
        let controller =
            TemperatureController::new(1.0, 0.8, 0.4, 0.4, 1.6).expect("valid controller");
        let desire = DesireLagrangian::new(geometry, repression, semantics, controller)
            .unwrap()
            .with_alpha_schedule(warmup(0.0, 0.2, 1))
            .with_beta_schedule(warmup(0.0, 0.1, 1))
            .with_gamma_schedule(constant(0.04))
            .with_lambda_schedule(constant(0.02))
            .with_observation_horizon(Some(1))
            .with_integration_horizon(Some(2));
        let cfg = st_core::config::self_rewrite::SelfRewriteCfg {
            score_thresh: 0.0,
            min_samples: 2,
            cooldown_sec: 0,
        };
        DesireAutomation::new(desire, cfg)
    }

    fn populate_desire_bridges(
        trainer_bridge: Option<&DesireTrainerBridge>,
        roundtable_bridge: Option<&DesireRoundtableBridge>,
        steps: usize,
    ) {
        let mut bundle = DesireTelemetryBundle::new();
        if let Some(bridge) = trainer_bridge {
            bundle = bundle.with_trainer_bridge(bridge);
        }
        if let Some(bridge) = roundtable_bridge {
            bundle = bundle.with_roundtable_bridge(bridge);
        }
        let mut pipeline = DesirePipeline::builder(build_language_automation())
            .with_telemetry_bundle(&bundle)
            .build();
        let logits = vec![2.0, 0.4];
        let concept = ConceptHint::Distribution(vec![0.6, 0.4]);
        let start = Instant::now();
        let anchor = SystemTime::now();
        for step in 0..steps {
            pipeline
                .step_at(
                    &logits,
                    step % 2,
                    &concept,
                    start + Duration::from_millis((step * 100) as u64),
                    anchor + Duration::from_millis((step * 100) as u64),
                )
                .unwrap();
        }
    }

    struct FixedGradientModule {
        param: Parameter,
        grad_value: f32,
    }

    impl FixedGradientModule {
        fn new(grad_value: f32) -> Self {
            let tensor = Tensor::zeros(1, 1).unwrap();
            let param = Parameter::new("weight", tensor);
            Self { param, grad_value }
        }
    }

    struct IdentityModule;

    impl Module for IdentityModule {
        fn forward(&self, input: &Tensor) -> PureResult<Tensor> {
            Ok(input.clone())
        }

        fn backward(&mut self, _input: &Tensor, grad_output: &Tensor) -> PureResult<Tensor> {
            Ok(grad_output.clone())
        }

        fn visit_parameters(
            &self,
            _visitor: &mut dyn FnMut(&Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            Ok(())
        }

        fn visit_parameters_mut(
            &mut self,
            _visitor: &mut dyn FnMut(&mut Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            Ok(())
        }
    }

    struct PolicyCaptureModule {
        commitments: Arc<Mutex<Vec<Option<String>>>>,
    }

    impl PolicyCaptureModule {
        fn new(commitments: Arc<Mutex<Vec<Option<String>>>>) -> Self {
            Self { commitments }
        }
    }

    impl Module for PolicyCaptureModule {
        fn forward(&self, input: &Tensor) -> PureResult<Tensor> {
            let commitment = st_core::backend::execution::current_backend_policy()
                .and_then(BackendPolicy::runtime_plan_output_sha256_hex);
            self.commitments
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner())
                .push(commitment);
            Ok(input.clone())
        }

        fn backward(&mut self, _input: &Tensor, grad_output: &Tensor) -> PureResult<Tensor> {
            Ok(grad_output.clone())
        }

        fn visit_parameters(
            &self,
            _visitor: &mut dyn FnMut(&Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            Ok(())
        }

        fn visit_parameters_mut(
            &mut self,
            _visitor: &mut dyn FnMut(&mut Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            Ok(())
        }
    }

    struct FailingForwardModule;

    impl Module for FailingForwardModule {
        fn forward(&self, _input: &Tensor) -> PureResult<Tensor> {
            Err(TensorError::InvalidValue {
                label: "intentional forward failure",
            })
        }

        fn backward(&mut self, _input: &Tensor, _grad_output: &Tensor) -> PureResult<Tensor> {
            unreachable!("forward failure prevents backward execution")
        }

        fn visit_parameters(
            &self,
            _visitor: &mut dyn FnMut(&Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            Ok(())
        }

        fn visit_parameters_mut(
            &mut self,
            _visitor: &mut dyn FnMut(&mut Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            Ok(())
        }
    }

    struct TrainingFlagModule {
        training: bool,
    }

    impl TrainingFlagModule {
        fn new() -> Self {
            Self { training: true }
        }

        fn training(&self) -> bool {
            self.training
        }
    }

    impl Module for TrainingFlagModule {
        fn forward(&self, input: &Tensor) -> PureResult<Tensor> {
            Ok(input.clone())
        }

        fn backward(&mut self, _input: &Tensor, grad_output: &Tensor) -> PureResult<Tensor> {
            Ok(grad_output.clone())
        }

        fn visit_parameters(
            &self,
            _visitor: &mut dyn FnMut(&Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            Ok(())
        }

        fn visit_parameters_mut(
            &mut self,
            _visitor: &mut dyn FnMut(&mut Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            Ok(())
        }

        fn set_training(&mut self, training: bool) -> PureResult<()> {
            self.training = training;
            Ok(())
        }
    }

    struct ConstantLoss {
        value: f32,
    }

    impl ConstantLoss {
        fn new(value: f32) -> Self {
            Self { value }
        }
    }

    impl Loss for ConstantLoss {
        fn forward(&mut self, prediction: &Tensor, _target: &Tensor) -> PureResult<Tensor> {
            let len = prediction.data().len();
            Tensor::from_vec(
                prediction.shape().0,
                prediction.shape().1,
                vec![self.value; len],
            )
        }

        fn backward(&mut self, prediction: &Tensor, _target: &Tensor) -> PureResult<Tensor> {
            Tensor::zeros(prediction.shape().0, prediction.shape().1)
        }
    }

    impl Module for FixedGradientModule {
        fn forward(&self, input: &Tensor) -> PureResult<Tensor> {
            Ok(input.clone())
        }

        fn backward(&mut self, _input: &Tensor, grad_output: &Tensor) -> PureResult<Tensor> {
            let update = Tensor::from_vec(1, 1, vec![self.grad_value])?;
            self.param.accumulate_euclidean(&update)?;
            Ok(grad_output.clone())
        }

        fn visit_parameters(
            &self,
            visitor: &mut dyn FnMut(&Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            visitor(&self.param)
        }

        fn visit_parameters_mut(
            &mut self,
            visitor: &mut dyn FnMut(&mut Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            visitor(&mut self.param)
        }
    }

    struct NonFiniteAccumulatorModule {
        param: Parameter,
        value: f32,
    }

    impl NonFiniteAccumulatorModule {
        fn new(value: f32) -> Self {
            Self {
                param: Parameter::new("poison", Tensor::zeros(1, 1).unwrap()),
                value,
            }
        }

        fn value(&self) -> &Tensor {
            self.param.value()
        }

        fn gradients_are_zero(&self) -> bool {
            self.param
                .hypergrad()
                .map(|tape| tape.gradient().iter().all(|value| *value == 0.0))
                .unwrap_or(false)
        }
    }

    impl Module for NonFiniteAccumulatorModule {
        fn forward(&self, input: &Tensor) -> PureResult<Tensor> {
            Ok(input.clone())
        }

        fn backward(&mut self, _input: &Tensor, grad_output: &Tensor) -> PureResult<Tensor> {
            if let Some(tape) = self.param.hypergrad_mut() {
                if let Some(slot) = tape.gradient_mut().first_mut() {
                    *slot = self.value;
                }
            } else {
                let update = Tensor::from_vec(1, 1, vec![self.value])?;
                self.param.accumulate_euclidean(&update)?;
            }
            Ok(grad_output.clone())
        }

        fn visit_parameters(
            &self,
            visitor: &mut dyn FnMut(&Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            visitor(&self.param)
        }

        fn visit_parameters_mut(
            &mut self,
            visitor: &mut dyn FnMut(&mut Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            visitor(&mut self.param)
        }
    }

    struct SpectralGradientModule {
        param: Parameter,
        grad: Vec<f32>,
    }

    impl SpectralGradientModule {
        fn new(grad: Vec<f32>) -> Self {
            let cols = grad.len();
            let param = Parameter::new("spectral", Tensor::zeros(1, cols).unwrap());
            Self { param, grad }
        }

        fn accumulate(&mut self) {
            let update = Tensor::from_vec(1, self.grad.len(), self.grad.clone()).unwrap();
            self.param.accumulate_euclidean(&update).unwrap();
        }

        fn weights(&self) -> &Tensor {
            self.param.value()
        }
    }

    impl Module for SpectralGradientModule {
        fn forward(&self, input: &Tensor) -> PureResult<Tensor> {
            Ok(input.clone())
        }

        fn backward(&mut self, _input: &Tensor, grad_output: &Tensor) -> PureResult<Tensor> {
            let update = Tensor::from_vec(1, self.grad.len(), self.grad.clone()).unwrap();
            self.param.accumulate_euclidean(&update)?;
            Ok(grad_output.clone())
        }

        fn visit_parameters(
            &self,
            visitor: &mut dyn FnMut(&Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            visitor(&self.param)
        }

        fn visit_parameters_mut(
            &mut self,
            visitor: &mut dyn FnMut(&mut Parameter) -> PureResult<()>,
        ) -> PureResult<()> {
            visitor(&mut self.param)
        }
    }

    #[derive(Debug)]
    struct ScalingTrainingDevice {
        factor: f32,
        calls: Arc<Mutex<usize>>,
        policy_requests: Option<Arc<Mutex<Vec<&'static str>>>>,
        policy_commitments: Option<Arc<Mutex<Vec<Option<String>>>>>,
        rank: usize,
        world_size: usize,
    }

    impl ScalingTrainingDevice {
        fn new(factor: f32, calls: Arc<Mutex<usize>>) -> Self {
            Self {
                factor,
                calls,
                policy_requests: None,
                policy_commitments: None,
                rank: 1,
                world_size: 2,
            }
        }

        fn with_policy_capture(mut self, capture: Arc<Mutex<Vec<&'static str>>>) -> Self {
            self.policy_requests = Some(capture);
            self
        }

        fn with_policy_commitment_capture(
            mut self,
            capture: Arc<Mutex<Vec<Option<String>>>>,
        ) -> Self {
            self.policy_commitments = Some(capture);
            self
        }
    }

    impl AccumulatorSynchronizer for ScalingTrainingDevice {
        fn rank(&self) -> usize {
            self.rank
        }

        fn world_size(&self) -> usize {
            self.world_size
        }

        fn synchronize_accumulators(
            &self,
            gradients: &mut [f32],
        ) -> Result<(), AccumulatorSyncError> {
            *self
                .calls
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner()) += 1;
            if let Some(capture) = &self.policy_requests {
                let requested_backend = st_core::backend::execution::current_backend_policy()
                    .map(BackendPolicy::tensor_util_backend_label)
                    .unwrap_or("none");
                capture
                    .lock()
                    .unwrap_or_else(|poisoned| poisoned.into_inner())
                    .push(requested_backend);
            }
            if let Some(capture) = &self.policy_commitments {
                let commitment = st_core::backend::execution::current_backend_policy()
                    .and_then(BackendPolicy::runtime_plan_output_sha256_hex);
                capture
                    .lock()
                    .unwrap_or_else(|poisoned| poisoned.into_inner())
                    .push(commitment);
            }
            for value in gradients {
                *value *= self.factor;
            }
            Ok(())
        }

        fn checkpoint_provider(&self) -> &'static str {
            "st-nn.tests.scaling_accumulator.v1"
        }

        fn checkpoint_state(&self) -> Result<Option<Value>, AccumulatorSyncError> {
            Ok(Some(serde_json::json!({ "factor": self.factor })))
        }

        fn validate_checkpoint_state(
            &self,
            state: Option<&Value>,
        ) -> Result<(), AccumulatorSyncError> {
            let factor = state
                .and_then(|state| state.get("factor"))
                .and_then(Value::as_f64)
                .ok_or_else(|| AccumulatorSyncError::backend("scaling factor is missing"))?
                as f32;
            if factor.to_bits() == self.factor.to_bits() {
                Ok(())
            } else {
                Err(AccumulatorSyncError::backend(format!(
                    "scaling factor mismatch: expected {}, got {factor}",
                    self.factor
                )))
            }
        }
    }

    #[test]
    fn trainer_attaches_and_steps() {
        let caps = DeviceCaps::wgpu(32, true, 256);
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut layer = Linear::new("fc", 2, 1).unwrap();
        trainer.prepare(&mut layer).unwrap();
        let input = crate::Tensor::from_vec(1, 2, vec![1.0, -1.0]).unwrap();
        let target = crate::Tensor::from_vec(1, 1, vec![0.5]).unwrap();
        let out = layer.forward(&input).unwrap();
        let grad = out.sub(&target).unwrap();
        let _ = layer.backward(&input, &grad).unwrap();
        trainer.step(&mut layer).unwrap();
        assert!(trainer.planner().topk(64, 128, 32).k > 0);
    }

    #[test]
    fn trainer_rejects_non_finite_batch_input_before_forward() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = Linear::new("finite_gate_input", 2, 1).unwrap();
        trainer.prepare(&mut model).unwrap();
        let before = model.weight().value().clone();
        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let dataset = vec![(
            Tensor::from_vec(1, 2, vec![f32::NAN, 1.0]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
        )];
        let mut loss = MeanSquaredError::new();

        let err = trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .expect_err("trainer should reject non-finite batch input");

        match err {
            TensorError::NonFiniteValue { label, value } => {
                assert_eq!(label, "trainer_batch_input");
                assert!(value.is_nan());
            }
            other => panic!("unexpected error: {other:?}"),
        }
        assert_eq!(model.weight().value().data(), before.data());
    }

    #[test]
    fn trainer_rejects_loss_sum_overflow_before_backward() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = IdentityModule;
        let schedule = trainer.roundtable(1, 2, RoundtableConfig::default());
        let dataset = vec![(
            Tensor::from_vec(1, 2, vec![0.0, 0.0]).unwrap(),
            Tensor::from_vec(1, 2, vec![0.0, 0.0]).unwrap(),
        )];
        let mut loss = ConstantLoss::new(f32::MAX);

        let err = trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .expect_err("trainer should reject overflowed step loss");

        match err {
            TensorError::NonFiniteValue { label, value } => {
                assert_eq!(label, "trainer_step_loss");
                assert!(value.is_infinite());
            }
            other => panic!("unexpected error: {other:?}"),
        }
    }

    #[test]
    fn trainer_rejects_non_finite_band_weight_before_replay() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        trainer.set_band_weights(|_| (f32::NAN, 1.0, 1.0));
        let mut model = Linear::new("finite_gate_band", 2, 1).unwrap();
        trainer.prepare(&mut model).unwrap();
        let before = model.weight().value().clone();
        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let dataset = vec![(
            Tensor::from_vec(1, 2, vec![0.5, -0.25]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.75]).unwrap(),
        )];
        let mut loss = MeanSquaredError::new();

        let err = trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .expect_err("trainer should reject non-finite band weight");

        match err {
            TensorError::NonFiniteValue { label, value } => {
                assert_eq!(label, "trainer_band_weight_above");
                assert!(value.is_nan());
            }
            other => panic!("unexpected error: {other:?}"),
        }
        assert_eq!(model.weight().value().data(), before.data());
    }

    #[test]
    fn trainer_rejects_non_finite_accumulator_before_optimizer_step() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = NonFiniteAccumulatorModule::new(f32::NAN);
        trainer.prepare(&mut model).unwrap();
        let before = model.value().clone();
        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let dataset = vec![(
            Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
            Tensor::from_vec(1, 1, vec![1.0]).unwrap(),
        )];
        let mut loss = MeanSquaredError::new();

        let err = trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .expect_err("trainer should reject non-finite accumulators before stepping");

        match err {
            TensorError::NonFiniteValue { label, value } => {
                assert_eq!(label, "trainer_gradient_accumulator");
                assert!(value.is_nan());
            }
            other => panic!("unexpected error: {other:?}"),
        }
        assert_eq!(model.value().data(), before.data());
        assert!(model.gradients_are_zero());
    }

    #[test]
    fn evaluate_epoch_rejects_non_finite_input_and_restores_training_mode() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = TrainingFlagModule::new();
        let dataset = vec![(
            Tensor::from_vec(1, 1, vec![f32::NAN]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
        )];
        let mut loss = MeanSquaredError::new();

        let err = trainer
            .evaluate_epoch(&mut model, &mut loss, dataset)
            .expect_err("evaluation should reject non-finite inputs");

        match err {
            TensorError::NonFiniteValue { label, value } => {
                assert_eq!(label, "trainer_eval_input");
                assert!(value.is_nan());
            }
            other => panic!("unexpected error: {other:?}"),
        }
        assert!(model.training());
    }

    #[test]
    fn evaluate_epoch_rejects_loss_sum_overflow() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = IdentityModule;
        let dataset = vec![(
            Tensor::from_vec(1, 2, vec![0.0, 0.0]).unwrap(),
            Tensor::from_vec(1, 2, vec![0.0, 0.0]).unwrap(),
        )];
        let mut loss = ConstantLoss::new(f32::MAX);

        let err = trainer
            .evaluate_epoch(&mut model, &mut loss, dataset)
            .expect_err("evaluation should reject overflowed loss sums");

        match err {
            TensorError::NonFiniteValue { label, value } => {
                assert_eq!(label, "trainer_eval_step_loss");
                assert!(value.is_infinite());
            }
            other => panic!("unexpected error: {other:?}"),
        }
    }

    #[test]
    fn trainer_attaches_realgrad_when_enabled() {
        let caps = DeviceCaps::wgpu(32, true, 256);
        let trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01).with_realgrad(0.02);
        let mut layer = Linear::new("fc", 2, 1).unwrap();
        trainer.prepare(&mut layer).unwrap();
        let mut saw_parameter = false;
        layer
            .visit_parameters(&mut |param| {
                saw_parameter = true;
                assert!(param.realgrad().is_some());
                Ok(())
            })
            .unwrap();
        assert!(saw_parameter);
    }

    #[test]
    fn trainer_optimizer_ingress_uses_the_rust_contract() {
        assert!(matches!(
            ModuleTrainer::try_new(DeviceCaps::cpu(), 1.0, 0.05, 0.01),
            Err(TrainerOptimizerConfigError::InvalidCurvature { .. })
        ));
        assert!(matches!(
            ModuleTrainer::try_new(DeviceCaps::cpu(), -1.0, 0.0, 0.01),
            Err(TrainerOptimizerConfigError::InvalidPositiveFinite {
                field: "hyper_learning_rate",
                ..
            })
        ));
        assert!(matches!(
            ModuleTrainer::try_new(DeviceCaps::cpu(), -1.0, 0.05, f32::NAN),
            Err(TrainerOptimizerConfigError::InvalidPositiveFinite {
                field: "fallback_learning_rate",
                ..
            })
        ));

        let mut trainer = ModuleTrainer::try_new(DeviceCaps::cpu(), -1.0, 0.05, 0.01).unwrap();
        trainer.enable_realgrad(0.02).unwrap();
        trainer.set_grad_clip_max_norm(0.5).unwrap();
        let contract = trainer.optimizer_config_contract().unwrap();

        assert_eq!(
            contract.contract_version,
            "spiraltorch.trainer_optimizer_config.v1"
        );
        assert_eq!(
            contract.semantic_owner,
            "st-core::runtime::trainer_optimizer"
        );
        assert_eq!(contract.semantic_backend, "rust");
        assert!(contract.realgrad_enabled);
        assert!(contract.gradient_clip_enabled);
        assert_eq!(contract.config.real_learning_rate, Some(0.02));
        assert_eq!(contract.config.grad_clip_max_norm, Some(0.5));
    }

    #[test]
    fn invalid_optional_optimizer_controls_preserve_existing_guards() {
        let mut trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        trainer.enable_realgrad(0.02).unwrap();
        trainer.set_grad_clip_max_norm(0.5).unwrap();
        let before = trainer.optimizer_config();

        assert!(trainer.enable_realgrad(f32::NAN).is_err());
        assert!(trainer.set_grad_clip_max_norm(0.0).is_err());

        assert_eq!(trainer.optimizer_config(), before);
        assert_eq!(trainer.real_learning_rate(), Some(0.02));
        assert_eq!(trainer.grad_clip_max_norm(), Some(0.5));
    }

    #[test]
    fn global_clip_preserves_finite_wide_gradients_and_small_limits() {
        let _cpu = push_backend_policy(BackendPolicy::from_device_caps(DeviceCaps::cpu()));
        let trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1., 0.05, 0.01);
        for limit in [1., 1e-30] {
            let mut model = crate::Sequential::new();
            model.push(crate::layers::Scaler::new("clip", 4).unwrap());
            model
                .visit_parameters_mut(&mut |p| {
                    p.accumulate_euclidean(&Tensor::from_vec(1, 4, vec![f32::MAX; 4])?)
                })
                .unwrap();
            trainer.clip_grad_global_norm(&mut model, limit).unwrap();
            model
                .visit_parameters(&mut |p| {
                    for &value in p.gradient().unwrap().data() {
                        assert!((f64::from(value) / f64::from(limit) - 0.5).abs() < 1e-6);
                    }
                    Ok(())
                })
                .unwrap();
        }
    }

    #[test]
    fn trainer_prepares_with_topos_for_wave_gate() {
        let caps = DeviceCaps::wgpu(64, true, 512);
        let mut trainer = ModuleTrainer::new(caps, -0.9, 0.06, 0.02);
        let encoder_curvature = trainer.curvature();
        let topos = OpenCartesianTopos::new(encoder_curvature, 1e-6, 1e4, 512, 16384).unwrap();
        let mut gate = WaveGate::with_topos(
            "wg",
            8,
            st_tensor::LanguageWaveEncoder::new(encoder_curvature, 0.7).unwrap(),
            topos.clone(),
        )
        .unwrap();
        trainer.prepare_with_topos(&mut gate, topos).unwrap();
        let input =
            Tensor::from_vec(1, 8, vec![0.1, -0.2, 0.3, -0.4, 0.5, -0.6, 0.7, -0.8]).unwrap();
        let grad_out = gate.forward(&input).unwrap();
        let _ = gate.backward(&input, &grad_out).unwrap();
        trainer.step(&mut gate).unwrap();
        assert!(gate.gate().value().squared_l2_norm() > 0.0);
    }

    #[test]
    fn trainer_prepare_with_topos_attaches_realgrad() {
        let caps = DeviceCaps::wgpu(32, true, 256);
        let trainer = ModuleTrainer::new(caps, -0.95, 0.05, 0.01).with_realgrad(0.015);
        let mut layer = Linear::new("fc", 3, 2).unwrap();
        let topos = OpenCartesianTopos::new(trainer.curvature(), 1e-6, 1e4, 128, 4096).unwrap();
        trainer.prepare_with_topos(&mut layer, topos).unwrap();
        layer
            .visit_parameters(&mut |param| {
                assert!(param.realgrad().is_some());
                Ok(())
            })
            .unwrap();
    }

    #[test]
    fn spectral_adapter_scales_local_learning_rate() {
        let caps = DeviceCaps::wgpu(32, true, 256);
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let grad = vec![0.8f32, -0.4, 0.6, -0.2];
        let mut module = SpectralGradientModule::new(grad.clone());
        module.accumulate();

        let mut probe = SpectralLrAdapter::default().with_sheet_hint(8);
        probe.set_curvature_target(trainer.curvature());
        let features = st_core::ops::zspace_round::SpectralFeatureSample::from_slice(
            &grad,
            probe.sheet_hint(),
        )
        .unwrap();
        let factor = probe.scale_factor("spectral", &features);

        trainer.step(&mut module).unwrap();

        let lr = trainer.fallback_learning_rate();
        for (value, expected_grad) in module.weights().data().iter().zip(grad.iter()) {
            let expected = -lr * factor * expected_grad;
            assert!(
                (value - expected).abs() < 1e-4,
                "value {value} vs expected {expected}"
            );
        }
    }

    #[test]
    fn trainer_optimizer_state_tracks_lr_scale_and_adapter_reset() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01).with_realgrad(0.02);
        trainer.set_grad_clip_max_norm(0.5).unwrap();
        let mut module = SpectralGradientModule::new(vec![0.8, -0.4, 0.6, -0.2]);
        module.accumulate();

        trainer.step(&mut module).unwrap();
        let before_scale = trainer.optimizer_state();
        assert_eq!(before_scale.epoch, 0);
        assert_eq!(before_scale.real_learning_rate, Some(0.02));
        assert_eq!(before_scale.grad_clip_max_norm, Some(0.5));
        assert!(before_scale.spectral_adapter.avg_energy > 0.0);

        trainer.mul_learning_rate(&mut module, 0.5).unwrap();
        let after_scale = trainer.optimizer_state();
        assert!((after_scale.fallback_learning_rate - 0.005).abs() < 1e-8);
        assert!((after_scale.hyper_learning_rate - 0.025).abs() < 1e-8);
        assert!((after_scale.real_learning_rate.unwrap_or(0.0) - 0.01).abs() < 1e-8);
        assert_eq!(after_scale.spectral_adapter.avg_curvature, 0.0);
        assert_eq!(after_scale.spectral_adapter.avg_spin, 0.0);
        assert_eq!(after_scale.spectral_adapter.avg_energy, 0.0);
    }

    fn configure_checkpoint_momentum(module: &mut SpectralGradientModule) {
        let control = ToposOptimizerStateControl::new(
            0.1,
            [0.2, -0.2, 0.3, -0.3, 0.1, -0.1, 0.4, -0.4, 0.0, 0.25],
            0.85,
            0.5,
        )
        .unwrap();
        module
            .param
            .hypergrad_mut()
            .expect("prepared hypergrad")
            .configure_optimizer_state(control);
        module
            .param
            .realgrad_mut()
            .expect("prepared realgrad")
            .configure_optimizer_state(control);
    }

    fn configure_checkpoint_phase_tracker(trainer: &mut ModuleTrainer) {
        trainer.phase_turnover_spike_threshold = 0.42;
        trainer.phase_loss_ema_alpha = 0.2;
        trainer.phase_loss_spike_ratio = 0.4;
        trainer.phase_drift_spike_threshold = 0.3;
        trainer.phase_last_label = Some(CoherenceLabel::SymmetricPulse);
        trainer.phase_last_turnover = Some(0.55);
        trainer.phase_last_band = Some(2);
        trainer.phase_last_drift_abs = Some(0.65);
        trainer.phase_loss_ema = Some(1.25);
        trainer.phase_loss_spiking = true;
    }

    fn run_checkpoint_steps(
        trainer: &mut ModuleTrainer,
        module: &mut SpectralGradientModule,
        steps: usize,
    ) {
        for _ in 0..steps {
            module.accumulate();
            trainer.step(module).unwrap();
        }
    }

    #[test]
    fn interrupted_optimizer_run_matches_uninterrupted_rust_resume() {
        let make_trainer =
            || ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01).with_realgrad(0.02);
        let gradient = vec![0.8, -0.4, 0.6, -0.2];

        let mut uninterrupted_trainer = make_trainer();
        let mut uninterrupted_module = SpectralGradientModule::new(gradient.clone());
        uninterrupted_trainer
            .prepare(&mut uninterrupted_module)
            .unwrap();
        configure_checkpoint_momentum(&mut uninterrupted_module);
        configure_checkpoint_phase_tracker(&mut uninterrupted_trainer);
        run_checkpoint_steps(&mut uninterrupted_trainer, &mut uninterrupted_module, 5);

        let mut interrupted_trainer = make_trainer();
        let mut interrupted_module = SpectralGradientModule::new(gradient.clone());
        interrupted_trainer
            .prepare(&mut interrupted_module)
            .unwrap();
        configure_checkpoint_momentum(&mut interrupted_module);
        configure_checkpoint_phase_tracker(&mut interrupted_trainer);
        run_checkpoint_steps(&mut interrupted_trainer, &mut interrupted_module, 2);
        let model_state = interrupted_module.state_dict().unwrap();
        let checkpoint = interrupted_trainer
            .optimizer_checkpoint(&interrupted_module)
            .unwrap();
        let encoded = serde_json::to_string(&checkpoint).unwrap();
        let checkpoint: TrainerOptimizerCheckpoint = serde_json::from_str(&encoded).unwrap();

        let mut resumed_trainer = make_trainer();
        let mut resumed_module = SpectralGradientModule::new(gradient);
        resumed_module.load_state_dict(&model_state).unwrap();
        resumed_trainer.prepare(&mut resumed_module).unwrap();
        let validation = resumed_trainer
            .restore_optimizer_checkpoint(&mut resumed_module, &checkpoint)
            .unwrap();
        assert!(validation.deterministic_resume_ready);
        assert_eq!(validation.hypergrad_parameters, 1);
        assert_eq!(validation.realgrad_parameters, 1);
        run_checkpoint_steps(&mut resumed_trainer, &mut resumed_module, 3);

        assert_eq!(
            resumed_module.weights().data(),
            uninterrupted_module.weights().data()
        );
        assert_eq!(
            resumed_trainer.optimizer_state(),
            uninterrupted_trainer.optimizer_state()
        );
        assert_eq!(
            resumed_trainer.optimizer_phase_tracker_state(),
            uninterrupted_trainer.optimizer_phase_tracker_state()
        );
        assert_eq!(
            resumed_module
                .param
                .hypergrad()
                .unwrap()
                .optimizer_momentum(),
            uninterrupted_module
                .param
                .hypergrad()
                .unwrap()
                .optimizer_momentum()
        );
        assert_eq!(
            resumed_module
                .param
                .realgrad()
                .unwrap()
                .optimizer_momentum(),
            uninterrupted_module
                .param
                .realgrad()
                .unwrap()
                .optimizer_momentum()
        );
    }

    #[test]
    fn runtime_bundle_resume_matches_uninterrupted_training() {
        let make_trainer =
            || ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01).with_realgrad(0.02);
        let gradient = vec![0.8, -0.4, 0.6, -0.2];

        let mut uninterrupted_trainer = make_trainer();
        let mut uninterrupted_module = SpectralGradientModule::new(gradient.clone());
        uninterrupted_trainer
            .prepare(&mut uninterrupted_module)
            .unwrap();
        configure_checkpoint_momentum(&mut uninterrupted_module);
        configure_checkpoint_phase_tracker(&mut uninterrupted_trainer);
        run_checkpoint_steps(&mut uninterrupted_trainer, &mut uninterrupted_module, 5);

        let mut interrupted_trainer = make_trainer();
        let mut interrupted_module = SpectralGradientModule::new(gradient.clone());
        interrupted_trainer
            .prepare(&mut interrupted_module)
            .unwrap();
        configure_checkpoint_momentum(&mut interrupted_module);
        configure_checkpoint_phase_tracker(&mut interrupted_trainer);
        run_checkpoint_steps(&mut interrupted_trainer, &mut interrupted_module, 2);
        let model_state = interrupted_module.state_dict().unwrap();
        let bundle = interrupted_trainer
            .runtime_checkpoint_bundle(&interrupted_module)
            .unwrap();
        let encoded = serde_json::to_string(&bundle).unwrap();
        let bundle: TrainerRuntimeCheckpointBundle = serde_json::from_str(&encoded).unwrap();

        let mut resumed_trainer = make_trainer();
        let mut resumed_module = SpectralGradientModule::new(gradient);
        resumed_module.load_state_dict(&model_state).unwrap();
        resumed_trainer.prepare(&mut resumed_module).unwrap();
        let receipt = resumed_trainer
            .restore_runtime_checkpoint_bundle(&mut resumed_module, &bundle)
            .unwrap();
        assert!(receipt.deterministic_resume_ready);
        assert_eq!(receipt.parameter_count, 1);
        run_checkpoint_steps(&mut resumed_trainer, &mut resumed_module, 3);

        assert_eq!(
            resumed_module.weights().data(),
            uninterrupted_module.weights().data()
        );
        assert_eq!(
            resumed_trainer.optimizer_state(),
            uninterrupted_trainer.optimizer_state()
        );
        assert_eq!(
            resumed_module
                .param
                .hypergrad()
                .unwrap()
                .optimizer_momentum(),
            uninterrupted_module
                .param
                .hypergrad()
                .unwrap()
                .optimizer_momentum()
        );
    }

    #[test]
    fn runtime_bundle_restores_coherence_topology_and_next_two_steps() {
        let _global_state = crate::test_global_state_lock();
        let pending = coherence_signal_for_weights(vec![0.72, 0.18, 0.1], 0.82, 0.25);
        let latest = coherence_signal_for_weights(vec![0.2, 0.55, 0.25], 0.61, -0.15);
        let mut source_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        source_trainer.enable_spectral_learning_rate(SpectralLearningRatePolicy::default());
        source_trainer.pending_coherence = Some(pending);
        source_trainer
            .coherence_bridge
            .as_ref()
            .expect("spectral policy coherence bridge")
            .restore_latest(Some(latest));
        let mut source_module = FixedGradientModule::new(0.75);
        source_trainer.prepare(&mut source_module).unwrap();
        let model_state = source_module.state_dict().unwrap();
        let bundle = source_trainer
            .runtime_checkpoint_bundle(&source_module)
            .unwrap();
        let encoded = serde_json::to_string(&bundle).unwrap();
        let bundle: TrainerRuntimeCheckpointBundle = serde_json::from_str(&encoded).unwrap();

        let coherence = bundle
            .external
            .coherence_bridge
            .as_ref()
            .expect("captured coherence bridge");
        assert!(coherence.subscribed);
        assert!(coherence.pending.is_some());
        assert!(coherence.latest.is_some());
        assert_eq!(
            evaluate_trainer_external_state_checkpoint(&bundle.external)
                .unwrap()
                .captured_components,
            [COHERENCE_BRIDGE_COMPONENT]
        );

        let mut resumed_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        let mut resumed_module = FixedGradientModule::new(0.75);
        resumed_module.load_state_dict(&model_state).unwrap();
        resumed_trainer.prepare(&mut resumed_module).unwrap();
        let receipt = resumed_trainer
            .restore_runtime_checkpoint_bundle(&mut resumed_module, &bundle)
            .unwrap();

        assert!(receipt.deterministic_resume_ready);
        assert!(resumed_trainer.coherence_bridge.is_some());
        assert_eq!(
            resumed_trainer.external_state_checkpoint().unwrap(),
            bundle.external
        );

        let schedule = source_trainer.roundtable(1, 1, RoundtableConfig::default());
        let batch = vec![(
            Tensor::from_vec(1, 1, vec![1.0]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
        )];
        let mut source_loss = ConstantLoss::new(1.0);
        let mut resumed_loss = ConstantLoss::new(1.0);

        source_trainer
            .train_epoch(
                &mut source_module,
                &mut source_loss,
                batch.clone(),
                &schedule,
            )
            .unwrap();
        resumed_trainer
            .train_epoch(
                &mut resumed_module,
                &mut resumed_loss,
                batch.clone(),
                &schedule,
            )
            .unwrap();
        assert_eq!(
            source_module.state_dict().unwrap(),
            resumed_module.state_dict().unwrap()
        );
        assert_eq!(
            source_trainer.optimizer_checkpoint(&source_module).unwrap(),
            resumed_trainer
                .optimizer_checkpoint(&resumed_module)
                .unwrap()
        );
        assert_eq!(
            source_trainer.external_state_checkpoint().unwrap(),
            resumed_trainer.external_state_checkpoint().unwrap()
        );
        assert!(source_trainer.pending_coherence.is_none());
        assert!(source_trainer
            .coherence_bridge
            .as_ref()
            .and_then(ZSpaceTraceCoherenceBridge::checkpoint_latest)
            .is_some());

        source_trainer
            .train_epoch(
                &mut source_module,
                &mut source_loss,
                batch.clone(),
                &schedule,
            )
            .unwrap();
        resumed_trainer
            .train_epoch(&mut resumed_module, &mut resumed_loss, batch, &schedule)
            .unwrap();
        assert_eq!(
            source_module.state_dict().unwrap(),
            resumed_module.state_dict().unwrap()
        );
        assert_eq!(
            source_trainer.optimizer_checkpoint(&source_module).unwrap(),
            resumed_trainer
                .optimizer_checkpoint(&resumed_module)
                .unwrap()
        );
        assert_eq!(
            source_trainer.external_state_checkpoint().unwrap(),
            resumed_trainer.external_state_checkpoint().unwrap()
        );
        assert!(source_trainer
            .coherence_bridge
            .as_ref()
            .and_then(ZSpaceTraceCoherenceBridge::checkpoint_latest)
            .is_none());
    }

    #[test]
    fn runtime_bundle_restores_gnn_roundtable_state_and_next_step_semantics() {
        let source_bridge = RoundtableGnnBridge::new();
        source_bridge.set_history_limit(3).unwrap();
        source_bridge
            .publish(RoundtableBandSignal::new(BandEnergy::new(0.7, 0.2, 0.1), (2, 1, 1)).unwrap())
            .unwrap();
        let mut source_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        source_trainer.enable_gnn_roundtable_bridge(source_bridge.clone());
        let mut source_module = FixedGradientModule::new(0.75);
        source_trainer.prepare(&mut source_module).unwrap();
        let schedule = source_trainer.roundtable(1, 1, RoundtableConfig::default());
        let batch = vec![(
            Tensor::from_vec(1, 1, vec![1.0]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
        )];
        let mut source_loss = ConstantLoss::new(1.0);
        source_trainer
            .train_epoch(
                &mut source_module,
                &mut source_loss,
                batch.clone(),
                &schedule,
            )
            .unwrap();
        let model_state = source_module.state_dict().unwrap();
        let bundle = source_trainer
            .runtime_checkpoint_bundle(&source_module)
            .unwrap();

        let captured = bundle
            .external
            .gnn_roundtable_bridge
            .as_ref()
            .expect("captured GNN roundtable bridge");
        assert_eq!(captured.history_limit, 3);
        assert_eq!(captured.history.len(), 2);
        assert_eq!(captured.latest.as_ref(), captured.history.last());
        assert!(captured.trainer_last.is_some());

        let target_bridge = RoundtableGnnBridge::new();
        target_bridge.set_history_limit(1).unwrap();
        target_bridge
            .publish(RoundtableBandSignal::new(BandEnergy::new(0.1, 0.2, 0.7), (1, 1, 2)).unwrap())
            .unwrap();
        let mut resumed_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        resumed_trainer.enable_gnn_roundtable_bridge(target_bridge.clone());
        let mut resumed_module = FixedGradientModule::new(0.75);
        resumed_module.load_state_dict(&model_state).unwrap();
        resumed_trainer.prepare(&mut resumed_module).unwrap();
        let receipt = resumed_trainer
            .restore_runtime_checkpoint_bundle(&mut resumed_module, &bundle)
            .unwrap();

        assert!(receipt.deterministic_resume_ready);
        assert_eq!(
            target_bridge.snapshot_state(),
            source_bridge.snapshot_state()
        );
        assert_eq!(
            resumed_trainer.external_state_checkpoint().unwrap(),
            bundle.external
        );

        let mut resumed_loss = ConstantLoss::new(1.0);
        source_trainer
            .train_epoch(
                &mut source_module,
                &mut source_loss,
                batch.clone(),
                &schedule,
            )
            .unwrap();
        resumed_trainer
            .train_epoch(&mut resumed_module, &mut resumed_loss, batch, &schedule)
            .unwrap();

        assert_eq!(
            source_module.state_dict().unwrap(),
            resumed_module.state_dict().unwrap()
        );
        assert_eq!(
            source_trainer.optimizer_checkpoint(&source_module).unwrap(),
            resumed_trainer
                .optimizer_checkpoint(&resumed_module)
                .unwrap()
        );
        let source_state = source_bridge.snapshot_state();
        let resumed_state = target_bridge.snapshot_state();
        assert_eq!(source_state.history_limit, resumed_state.history_limit);
        assert_eq!(source_state.history.len(), resumed_state.history.len());
        for (source, resumed) in source_state.history.iter().zip(&resumed_state.history) {
            assert_eq!(
                source.observation().unwrap(),
                resumed.observation().unwrap()
            );
        }
        assert_eq!(
            source_state.latest.unwrap().observation().unwrap(),
            resumed_state.latest.unwrap().observation().unwrap()
        );
        assert_eq!(
            source_trainer
                .gnn_roundtable_signal()
                .unwrap()
                .observation()
                .unwrap(),
            resumed_trainer
                .gnn_roundtable_signal()
                .unwrap()
                .observation()
                .unwrap()
        );
    }

    #[test]
    fn external_checkpoint_rejects_gnn_roundtable_tampering_without_mutation() {
        let source_bridge = RoundtableGnnBridge::new();
        source_bridge
            .publish(RoundtableBandSignal::new(BandEnergy::new(0.6, 0.3, 0.1), (2, 1, 1)).unwrap())
            .unwrap();
        let mut source = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        source.enable_gnn_roundtable_bridge(source_bridge);
        let checkpoint = source.external_state_checkpoint().unwrap();

        let target_bridge = RoundtableGnnBridge::new();
        target_bridge
            .publish(RoundtableBandSignal::new(BandEnergy::new(0.1, 0.3, 0.6), (1, 1, 2)).unwrap())
            .unwrap();
        let mut target = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        target.enable_gnn_roundtable_bridge(target_bridge);
        let before = target.external_state_checkpoint().unwrap();
        let mut tampered = checkpoint;
        tampered.gnn_roundtable_bridge.as_mut().unwrap().history[0]
            .observation
            .spectral
            .sheet_confidence = 1.5;

        assert!(target.restore_external_state_checkpoint(&tampered).is_err());
        assert_eq!(target.external_state_checkpoint().unwrap(), before);
    }

    #[test]
    fn runtime_bundle_composes_roundtable_and_optimizer_readiness() {
        let source_desire = DesireTrainerBridge::new();
        let mut source_bridge = DesireRoundtableBridge::new();
        source_bridge.set_blend(0.74);
        source_bridge.set_drift_gain(0.58);
        populate_desire_bridges(Some(&source_desire), Some(&source_bridge), 4);
        let expected_desire = source_desire.checkpoint().unwrap();
        let expected_roundtable = source_bridge.checkpoint().unwrap();
        let source_telemetry = DesireTelemetryBundle::new()
            .with_trainer_bridge(&source_desire)
            .with_roundtable_bridge(&source_bridge);
        let mut source_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        source_trainer.enable_desire_telemetry(&source_telemetry);
        let mut source_module = SpectralGradientModule::new(vec![0.5, -0.25]);
        source_trainer.prepare(&mut source_module).unwrap();
        let model_state = source_module.state_dict().unwrap();
        let bundle = source_trainer
            .runtime_checkpoint_bundle(&source_module)
            .unwrap();
        assert!(
            !evaluate_trainer_optimizer_checkpoint(&bundle.optimizer)
                .unwrap()
                .deterministic_resume_ready
        );

        let target_desire = DesireTrainerBridge::new();
        let target_desire_probe = target_desire.clone();
        let mut target_bridge = DesireRoundtableBridge::new();
        target_bridge.set_blend(0.12);
        target_bridge.set_drift_gain(0.2);
        let target_probe = target_bridge.clone();
        let target_telemetry = DesireTelemetryBundle::new()
            .with_trainer_bridge(&target_desire)
            .with_roundtable_bridge(&target_bridge);
        let mut target_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        target_trainer.enable_desire_telemetry(&target_telemetry);
        let mut target_module = SpectralGradientModule::new(vec![0.5, -0.25]);
        target_module.load_state_dict(&model_state).unwrap();
        target_trainer.prepare(&mut target_module).unwrap();

        let receipt = target_trainer
            .restore_runtime_checkpoint_bundle(&mut target_module, &bundle)
            .unwrap();

        assert!(receipt.deterministic_resume_ready);
        assert_eq!(
            receipt.captured_components,
            [DESIRE_TRAINER_COMPONENT, "desire_roundtable_bridge"]
        );
        assert_eq!(target_desire_probe.checkpoint().unwrap(), expected_desire);
        assert_eq!(target_probe.checkpoint().unwrap(), expected_roundtable);
        assert_eq!(target_probe.blend(), 0.74);
        assert_eq!(target_probe.drift_gain(), 0.58);
    }

    #[test]
    fn runtime_bundle_model_mismatch_preserves_external_and_optimizer_state() {
        let source_desire = DesireTrainerBridge::new();
        let mut source_roundtable = DesireRoundtableBridge::new();
        source_roundtable.set_blend(0.8);
        populate_desire_bridges(Some(&source_desire), Some(&source_roundtable), 4);
        let source_telemetry = DesireTelemetryBundle::new()
            .with_trainer_bridge(&source_desire)
            .with_roundtable_bridge(&source_roundtable);
        let mut source_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        source_trainer.enable_desire_telemetry(&source_telemetry);
        let mut source_module = SpectralGradientModule::new(vec![0.5, -0.25]);
        source_trainer.prepare(&mut source_module).unwrap();
        let bundle = source_trainer
            .runtime_checkpoint_bundle(&source_module)
            .unwrap();

        let target_desire = DesireTrainerBridge::new();
        let mut target_roundtable = DesireRoundtableBridge::new();
        target_roundtable.set_blend(0.15);
        populate_desire_bridges(Some(&target_desire), Some(&target_roundtable), 2);
        let target_telemetry = DesireTelemetryBundle::new()
            .with_trainer_bridge(&target_desire)
            .with_roundtable_bridge(&target_roundtable);
        let mut target_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        target_trainer.enable_desire_telemetry(&target_telemetry);
        let mut target_module = SpectralGradientModule::new(vec![0.5, -0.25]);
        target_trainer.prepare(&mut target_module).unwrap();
        target_module.param.value_mut().data_mut()[0] = 99.0;
        let trainer_before = target_trainer.optimizer_state();
        let parameter_before = target_module.param.optimizer_checkpoint_state();
        let external_before = target_trainer.external_state_checkpoint().unwrap();

        assert!(target_trainer
            .restore_runtime_checkpoint_bundle(&mut target_module, &bundle)
            .is_err());

        assert_eq!(target_trainer.optimizer_state(), trainer_before);
        assert_eq!(
            target_module.param.optimizer_checkpoint_state(),
            parameter_before
        );
        assert_eq!(
            target_trainer.external_state_checkpoint().unwrap(),
            external_before
        );
    }

    #[test]
    fn runtime_bundle_restores_and_consumes_desire_queue() {
        let source_bridge = DesireTrainerBridge::new();
        let mut pipeline = DesirePipeline::builder(build_language_automation())
            .with_trainer_bridge(&source_bridge)
            .build();
        let logits = vec![2.0, 0.4];
        let concept = ConceptHint::Distribution(vec![0.6, 0.4]);
        let start = Instant::now();
        let anchor = SystemTime::now();
        for step in 0..6 {
            pipeline
                .step_at(
                    &logits,
                    step % 2,
                    &concept,
                    start + Duration::from_millis((step * 100) as u64),
                    anchor + Duration::from_millis((step * 100) as u64),
                )
                .unwrap();
        }
        let expected_queue = source_bridge.checkpoint().unwrap();

        let mut source_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        source_trainer.enable_desire_pipeline(source_bridge);
        let mut source_module = SpectralGradientModule::new(vec![0.5, -0.25]);
        source_trainer.prepare(&mut source_module).unwrap();
        let model_state = source_module.state_dict().unwrap();
        let bundle = source_trainer
            .runtime_checkpoint_bundle(&source_module)
            .unwrap();
        let portable = evaluate_trainer_runtime_checkpoint_bundle(&bundle).unwrap();
        assert!(portable.unresolved_components.is_empty());
        assert_eq!(portable.captured_components, [DESIRE_TRAINER_COMPONENT]);
        assert_eq!(bundle.external.desire_trainer, Some(expected_queue.clone()));

        let target_bridge = DesireTrainerBridge::new();
        let target_probe = target_bridge.clone();
        let mut target_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        target_trainer.enable_desire_pipeline(target_bridge);
        let mut target_module = SpectralGradientModule::new(vec![0.5, -0.25]);
        target_module.load_state_dict(&model_state).unwrap();
        target_trainer.prepare(&mut target_module).unwrap();
        let receipt = target_trainer
            .restore_runtime_checkpoint_bundle(&mut target_module, &bundle)
            .unwrap();
        assert!(receipt.deterministic_resume_ready);
        assert_eq!(target_probe.checkpoint().unwrap(), expected_queue);

        let schedule = target_trainer.roundtable(1, 1, RoundtableConfig::default());
        let mut loss = MeanSquaredError::new();
        target_trainer
            .train_epoch(
                &mut target_module,
                &mut loss,
                vec![(
                    Tensor::from_vec(1, 2, vec![0.5, -0.25]).unwrap(),
                    Tensor::from_vec(1, 2, vec![0.0, 0.0]).unwrap(),
                )],
                &schedule,
            )
            .unwrap();
        assert!(target_probe.is_empty());
    }

    #[test]
    fn optimizer_restore_rejects_wrong_model_without_partial_mutation() {
        let mut source_trainer =
            ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01).with_realgrad(0.02);
        let mut source_module = SpectralGradientModule::new(vec![0.5, -0.25]);
        source_trainer.prepare(&mut source_module).unwrap();
        source_module.accumulate();
        source_trainer.step(&mut source_module).unwrap();
        let checkpoint = source_trainer.optimizer_checkpoint(&source_module).unwrap();

        let mut target_trainer =
            ModuleTrainer::new(DeviceCaps::cpu(), -0.8, 0.03, 0.02).with_realgrad(0.01);
        let mut target_module = SpectralGradientModule::new(vec![0.5, -0.25]);
        target_trainer.prepare(&mut target_module).unwrap();
        target_module.param.value_mut().data_mut()[0] = 99.0;
        let trainer_before = target_trainer.optimizer_state();
        let parameter_before = target_module.param.optimizer_checkpoint_state();

        let error = target_trainer
            .restore_optimizer_checkpoint(&mut target_module, &checkpoint)
            .expect_err("mismatched model values must fail closed");

        assert!(error.to_string().contains("fingerprint mismatch"));
        assert_eq!(target_trainer.optimizer_state(), trainer_before);
        assert_eq!(
            target_module.param.optimizer_checkpoint_state(),
            parameter_before
        );
    }

    #[test]
    fn external_checkpoint_restores_shared_desire_controller_state() {
        let mut source_bridge = DesireRoundtableBridge::new();
        let source_bundle = DesireTelemetryBundle::new().with_roundtable_bridge(&source_bridge);
        let mut source_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        source_trainer.enable_desire_telemetry(&source_bundle);
        source_bridge.set_blend(0.73);
        source_bridge.set_drift_gain(0.62);
        let checkpoint = source_trainer.external_state_checkpoint().unwrap();

        assert!(checkpoint.unresolved_components.is_empty());
        assert_eq!(
            checkpoint.desire_roundtable.unwrap().blend,
            source_bridge.blend()
        );

        let target_bridge = DesireRoundtableBridge::new();
        let target_bundle = DesireTelemetryBundle::new().with_roundtable_bridge(&target_bridge);
        let mut target_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        target_trainer.enable_desire_telemetry(&target_bundle);
        let report = target_trainer
            .restore_external_state_checkpoint(&checkpoint)
            .unwrap();

        assert!(report.payload_complete);
        assert!(report.deterministic_resume_ready);
        assert_eq!(target_bridge.blend(), 0.73);
        assert_eq!(target_bridge.drift_gain(), 0.62);

        let before = target_trainer.external_state_checkpoint().unwrap();
        let mut invalid = checkpoint;
        invalid.desire_roundtable.as_mut().unwrap().blend = f32::NAN;
        assert!(target_trainer
            .restore_external_state_checkpoint(&invalid)
            .is_err());
        assert_eq!(target_trainer.external_state_checkpoint().unwrap(), before);
    }

    #[test]
    fn external_checkpoint_restores_pending_coherence_without_subscription() {
        let expected = coherence_signal_for_weights(vec![0.65, 0.25, 0.1], 0.78, 0.2);
        let mut source = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        source.enable_spectral_learning_rate(SpectralLearningRatePolicy::default());
        source.disable_zspace_trace_coherence_bridge();
        source.pending_coherence = Some(expected);
        let checkpoint = source.external_state_checkpoint().unwrap();

        let coherence = checkpoint
            .coherence_bridge
            .as_ref()
            .expect("pending coherence checkpoint");
        assert!(!coherence.subscribed);
        assert!(coherence.pending.is_some());
        assert!(coherence.latest.is_none());

        let mut target = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        target.enable_zspace_trace_coherence_bridge();
        target.pending_coherence = Some(coherence_signal_for_weights(
            vec![0.2, 0.3, 0.5],
            0.45,
            -0.1,
        ));
        let receipt = target
            .restore_external_state_checkpoint(&checkpoint)
            .unwrap();

        assert!(receipt.deterministic_resume_ready);
        assert!(target.coherence_bridge.is_none());
        assert_eq!(target.external_state_checkpoint().unwrap(), checkpoint);
    }

    #[test]
    fn external_checkpoint_leaves_unresolved_desire_queue_untouched() {
        let bridge = DesireTrainerBridge::new();
        populate_desire_bridges(Some(&bridge), None, 3);
        let before = bridge.checkpoint().unwrap();
        let telemetry = DesireTelemetryBundle::new().with_trainer_bridge(&bridge);
        let mut trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        trainer.enable_desire_telemetry(&telemetry);
        let checkpoint =
            st_core::runtime::trainer_external::build_trainer_external_state_checkpoint(
                vec![DESIRE_TRAINER_COMPONENT.to_owned()],
                None,
                None,
                None,
            )
            .unwrap();

        let report = trainer
            .restore_external_state_checkpoint(&checkpoint)
            .unwrap();

        assert!(!report.payload_complete);
        assert!(!report.deterministic_resume_ready);
        assert_eq!(bridge.checkpoint().unwrap(), before);
    }

    #[test]
    fn external_checkpoint_verifies_reattached_accumulator_provider_state() {
        let source_calls = Arc::new(Mutex::new(0));
        let mut source = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        source.set_training_device(ScalingTrainingDevice::new(0.5, Arc::clone(&source_calls)));
        let checkpoint = source.external_state_checkpoint().unwrap();
        let preflight = evaluate_trainer_external_state_checkpoint(&checkpoint).unwrap();
        assert!(!preflight.deterministic_resume_ready);
        assert_eq!(
            preflight.reattach_required_components,
            [ACCUMULATOR_SYNCHRONIZER_COMPONENT]
        );

        let target_calls = Arc::new(Mutex::new(0));
        let mut target = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        target.set_training_device(ScalingTrainingDevice::new(0.5, Arc::clone(&target_calls)));
        let restored = target
            .restore_external_state_checkpoint(&checkpoint)
            .unwrap();
        assert!(restored.payload_complete);
        assert!(restored.deterministic_resume_ready);
        assert_eq!(
            restored.reattached_components,
            [ACCUMULATOR_SYNCHRONIZER_COMPONENT]
        );

        let mut wrong = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        wrong.set_training_device(ScalingTrainingDevice::new(0.25, Arc::new(Mutex::new(0))));
        assert!(wrong
            .restore_external_state_checkpoint(&checkpoint)
            .unwrap_err()
            .to_string()
            .contains("scaling factor mismatch"));
    }

    #[cfg(feature = "psi")]
    #[test]
    fn external_checkpoint_preserves_psi_ema_and_sampling_clock() {
        let mut config = PsiConfig {
            enabled: true,
            components: PsiComponent::LOSS | PsiComponent::GRAD_NORM,
            ema_alpha: 0.35,
            sample_rate: 2,
            ..PsiConfig::default()
        };
        config.weights.insert(PsiComponent::LOSS, 1.0);
        config.weights.insert(PsiComponent::GRAD_NORM, 0.4);
        let mut source = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        source.psi = Some(PsiMeter::new(config));
        source.psi.as_mut().unwrap().update(&PsiInput {
            loss: 0.8,
            grad_l2: 0.4,
            ..PsiInput::default()
        });
        source.psi.as_mut().unwrap().update(&PsiInput {
            loss: 1.6,
            grad_l2: 1.2,
            ..PsiInput::default()
        });
        let checkpoint = source.external_state_checkpoint().unwrap();

        let mut target = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        assert!(target.psi.is_none());
        let restored = target
            .restore_external_state_checkpoint(&checkpoint)
            .unwrap();
        assert!(restored.payload_complete);
        assert!(restored.deterministic_resume_ready);
        assert!(target.psi.is_some());

        let next = PsiInput {
            loss: 2.4,
            grad_l2: 3.0,
            ..PsiInput::default()
        };
        let expected = source.psi.as_mut().unwrap().update(&next);
        let actual = target.psi.as_mut().unwrap().update(&next);
        assert_eq!(actual.0.total, expected.0.total);
        assert_eq!(actual.0.breakdown, expected.0.breakdown);
        assert_eq!(actual.0.step, expected.0.step);
        assert_eq!(
            actual.1.iter().map(ToString::to_string).collect::<Vec<_>>(),
            expected
                .1
                .iter()
                .map(ToString::to_string)
                .collect::<Vec<_>>()
        );
        assert_eq!(
            target.psi.as_ref().unwrap().checkpoint().unwrap(),
            source.psi.as_ref().unwrap().checkpoint().unwrap()
        );
    }

    #[cfg(feature = "psi")]
    #[test]
    fn runtime_bundle_bootstraps_psi_before_projected_topology_commit() {
        let mut config = PsiConfig {
            enabled: true,
            components: PsiComponent::LOSS,
            ema_alpha: 0.4,
            sample_rate: 1,
            ..PsiConfig::default()
        };
        config.weights.insert(PsiComponent::LOSS, 1.0);
        let mut source = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        source.psi = Some(PsiMeter::new(config));
        source.psi.as_mut().unwrap().update(&PsiInput {
            loss: 1.25,
            ..PsiInput::default()
        });
        let mut source_module = SpectralGradientModule::new(vec![0.5, -0.25]);
        source.prepare(&mut source_module).unwrap();
        let model_state = source_module.state_dict().unwrap();
        let bundle = source.runtime_checkpoint_bundle(&source_module).unwrap();

        let mut target = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        assert!(target.psi.is_none());
        let mut target_module = SpectralGradientModule::new(vec![0.5, -0.25]);
        target_module.load_state_dict(&model_state).unwrap();
        target.prepare(&mut target_module).unwrap();

        let receipt = target
            .restore_runtime_checkpoint_bundle(&mut target_module, &bundle)
            .unwrap();

        assert!(receipt.deterministic_resume_ready);
        assert_eq!(receipt.captured_components, [PSI_METER_COMPONENT]);
        assert_eq!(
            target.psi.as_ref().unwrap().checkpoint().unwrap(),
            source.psi.as_ref().unwrap().checkpoint().unwrap()
        );
    }

    #[test]
    fn trainer_consumes_meta_reports_as_idempotent_parameter_control() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01).with_realgrad(0.02);
        let mut module = Linear::new("trainer_meta_control", 2, 2).unwrap();
        trainer.prepare(&mut module).unwrap();
        let first = parameter_control_report(ZSpaceMetaOptimizerState::zeros(2), 0.5);

        let receipt = trainer
            .apply_zspace_meta_optimizer_report(&mut module, &first)
            .unwrap();
        assert!(receipt.changed);
        assert_eq!(trainer.meta_learning_rate_scale(), 0.5);
        assert_eq!(trainer.meta_optimizer_step(), Some(1));
        assert!((trainer.fallback_learning_rate() - 0.005).abs() < 1.0e-8);
        assert!((trainer.hyper_learning_rate() - 0.025).abs() < 1.0e-8);
        assert!((trainer.real_learning_rate().unwrap() - 0.01).abs() < 1.0e-8);

        let replay = trainer
            .apply_zspace_meta_optimizer_report(&mut module, &first)
            .unwrap();
        assert!(!replay.changed);
        assert!((trainer.fallback_learning_rate() - 0.005).abs() < 1.0e-8);

        let second = parameter_control_report(first.state_after.clone(), 1.0);
        trainer
            .apply_zspace_meta_optimizer_report(&mut module, &second)
            .unwrap();
        assert_eq!(trainer.meta_learning_rate_scale(), 1.0);
        assert_eq!(trainer.meta_optimizer_step(), Some(2));
        assert!((trainer.fallback_learning_rate() - 0.01).abs() < 1.0e-8);
    }

    #[test]
    fn trainer_rejects_overflow_lr_scale_without_mutating_state() {
        let caps = DeviceCaps::cpu();
        let mut trainer =
            ModuleTrainer::new(caps, -1.0, f32::MAX, f32::MAX).with_realgrad(f32::MAX);
        let mut module = SpectralGradientModule::new(vec![0.8, -0.4, 0.6, -0.2]);
        let before = trainer.optimizer_state();

        let err = trainer.mul_learning_rate(&mut module, 2.0).unwrap_err();

        assert!(matches!(
            err,
            TensorError::NonPositiveLearningRate { rate } if !rate.is_finite()
        ));
        assert_eq!(trainer.optimizer_state(), before);
    }

    #[test]
    fn trainer_synchronizes_accumulators_before_apply_step() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let calls = Arc::new(Mutex::new(0usize));
        trainer.set_training_device(ScalingTrainingDevice::new(0.0, Arc::clone(&calls)));
        let mut module = SpectralGradientModule::new(vec![0.8, -0.4, 0.6, -0.2]);
        module.accumulate();

        trainer.step(&mut module).unwrap();

        assert_eq!(
            *calls
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner()),
            1
        );
        assert!(module.weights().data().iter().all(|value| *value == 0.0));
        let sync = trainer.last_accumulator_sync();
        assert!(sync.enabled);
        assert_eq!(sync.rank, 1);
        assert_eq!(sync.world_size, 2);
        assert_eq!(sync.buffers, 1);
        assert_eq!(sync.values, 4);
        let state = trainer.optimizer_state();
        assert!(state.training_device_enabled);
        assert_eq!(state.training_rank, 1);
        assert_eq!(state.training_world_size, 2);
    }

    #[test]
    fn trainer_binds_committed_execution_plan_transactionally() {
        let initial_config = ExecutionConfig::new(AcceleratorFallback::Allow, 1024);
        let mut trainer = ModuleTrainer::new_with_execution_config(
            DeviceCaps::wgpu(32, true, 256),
            initial_config,
            -1.0,
            0.05,
            0.01,
        );
        let committed_config = ExecutionConfig::new(AcceleratorFallback::Forbid, 37);
        let plan = committed_cpu_session_plan(committed_config);

        trainer
            .bind_runtime_execution_plan(&plan)
            .expect("committed plan binds");

        assert_eq!(trainer.planner().device_caps(), DeviceCaps::cpu());
        assert_eq!(trainer.planner().execution_config(), committed_config);
        assert_eq!(trainer.backend_policy().device_caps(), DeviceCaps::cpu());
        assert_eq!(
            trainer.backend_policy().execution_config(),
            committed_config
        );
        assert_eq!(trainer.runtime_execution_plan(), Some(&plan));
        assert_eq!(
            trainer.runtime_execution_plan_output_sha256().as_deref(),
            Some(plan.output_sha256.as_str())
        );

        let mut tampered = plan.clone();
        tampered.output_sha256 = "0".repeat(64);
        trainer
            .bind_runtime_execution_plan(&tampered)
            .expect_err("tampered plan must not bind");

        assert_eq!(trainer.runtime_execution_plan(), Some(&plan));
        assert_eq!(trainer.planner().device_caps(), DeviceCaps::cpu());
        assert_eq!(trainer.planner().execution_config(), committed_config);
    }

    #[test]
    fn committed_execution_plan_scopes_step_train_and_evaluate() {
        assert!(st_core::backend::execution::current_backend_policy().is_none());
        let plan =
            committed_cpu_session_plan(ExecutionConfig::new(AcceleratorFallback::Forbid, 37));
        let expected_commitment = Some(plan.output_sha256.clone());
        let mut trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        trainer
            .bind_runtime_execution_plan(&plan)
            .expect("committed plan binds");

        let calls = Arc::new(Mutex::new(0usize));
        let step_commitments = Arc::new(Mutex::new(Vec::new()));
        trainer.set_training_device(
            ScalingTrainingDevice::new(1.0, Arc::clone(&calls))
                .with_policy_commitment_capture(Arc::clone(&step_commitments)),
        );
        let mut step_module = SpectralGradientModule::new(vec![0.8, -0.4, 0.6, -0.2]);
        step_module.accumulate();
        trainer.step(&mut step_module).unwrap();

        assert_eq!(
            *step_commitments
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner()),
            vec![expected_commitment.clone()]
        );

        let forward_commitments = Arc::new(Mutex::new(Vec::new()));
        let mut module = PolicyCaptureModule::new(Arc::clone(&forward_commitments));
        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let batch = (
            Tensor::from_vec(1, 1, vec![0.25]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.5]).unwrap(),
        );
        let mut loss = MeanSquaredError::new();
        trainer
            .train_epoch(&mut module, &mut loss, vec![batch.clone()], &schedule)
            .unwrap();
        trainer
            .evaluate_epoch(&mut module, &mut loss, vec![batch])
            .unwrap();

        assert_eq!(
            *forward_commitments
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner()),
            vec![expected_commitment.clone(), expected_commitment]
        );
        assert!(st_core::backend::execution::current_backend_policy().is_none());
    }

    #[test]
    fn plan_bound_checkpoint_requires_the_same_execution_plan_on_restore() {
        let config = ExecutionConfig::new(AcceleratorFallback::Forbid, 37);
        let plan = committed_cpu_session_plan(config);
        let mut source_trainer =
            ModuleTrainer::new_with_execution_config(DeviceCaps::cpu(), config, -1.0, 0.05, 0.01);
        source_trainer
            .bind_runtime_execution_plan(&plan)
            .expect("source plan binds");
        let mut source_module = SpectralGradientModule::new(vec![0.8, -0.4, 0.6, -0.2]);
        source_trainer.prepare(&mut source_module).unwrap();
        let checkpoint = source_trainer.optimizer_checkpoint(&source_module).unwrap();

        assert_eq!(
            checkpoint
                .topology
                .runtime_execution_plan_output_sha256
                .as_deref(),
            Some(plan.output_sha256.as_str())
        );

        let mut target_trainer =
            ModuleTrainer::new_with_execution_config(DeviceCaps::cpu(), config, -1.0, 0.05, 0.01);
        let mut target_module = SpectralGradientModule::new(vec![0.8, -0.4, 0.6, -0.2]);
        target_trainer.prepare(&mut target_module).unwrap();
        let trainer_before = target_trainer.optimizer_state();
        let parameter_before = target_module.param.optimizer_checkpoint_state();

        assert!(matches!(
            target_trainer.restore_optimizer_checkpoint(&mut target_module, &checkpoint),
            Err(TrainerCheckpointError::TopologyMismatch)
        ));
        assert_eq!(target_trainer.optimizer_state(), trainer_before);
        assert_eq!(
            target_module.param.optimizer_checkpoint_state(),
            parameter_before
        );

        target_trainer
            .bind_runtime_execution_plan(&plan)
            .expect("target plan binds");
        target_trainer
            .restore_optimizer_checkpoint(&mut target_module, &checkpoint)
            .expect("matching plan restores");
    }

    #[test]
    fn trainer_rejects_schedule_from_a_different_execution_context_before_epoch_start() {
        let mut trainer = ModuleTrainer::new_with_execution_config(
            DeviceCaps::cpu(),
            ExecutionConfig::new(AcceleratorFallback::Forbid, 37),
            -1.0,
            0.05,
            0.01,
        );
        let foreign_planner = RankPlanner::with_execution_config(
            DeviceCaps::cpu(),
            ExecutionConfig::new(AcceleratorFallback::Allow, 1024),
        );
        let schedule = RoundtableSchedule::new(&foreign_planner, 1, 1, RoundtableConfig::default());
        let mut module = IdentityModule;
        let mut loss = MeanSquaredError::new();
        let batch = (
            Tensor::from_vec(1, 1, vec![0.25]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.5]).unwrap(),
        );

        let error = trainer
            .train_epoch(&mut module, &mut loss, vec![batch], &schedule)
            .expect_err("foreign schedule must be rejected");

        assert!(error
            .to_string()
            .contains("execution config differs from the trainer execution context"));
        assert_eq!(trainer.epoch, 0);
    }

    #[test]
    fn plan_bound_trainer_rejects_uncommitted_schedule_with_matching_config() {
        let config = ExecutionConfig::new(AcceleratorFallback::Forbid, 37);
        let plan = committed_cpu_session_plan(config);
        let mut trainer =
            ModuleTrainer::new_with_execution_config(DeviceCaps::cpu(), config, -1.0, 0.05, 0.01);
        trainer
            .bind_runtime_execution_plan(&plan)
            .expect("runtime plan binds");
        let uncommitted_planner = RankPlanner::with_execution_config(DeviceCaps::cpu(), config);
        let schedule =
            RoundtableSchedule::new(&uncommitted_planner, 1, 1, RoundtableConfig::default());
        let mut module = IdentityModule;
        let mut loss = MeanSquaredError::new();
        let batch = (
            Tensor::from_vec(1, 1, vec![0.25]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.5]).unwrap(),
        );

        let error = trainer
            .train_epoch(&mut module, &mut loss, vec![batch], &schedule)
            .expect_err("a schedule without the parent commitment must be rejected");

        assert!(error
            .to_string()
            .contains("runtime-plan commitment differs"));
        assert_eq!(trainer.epoch, 0);
    }

    #[test]
    fn trainer_step_scopes_core_backend_policy_over_accumulator_sync() {
        assert!(st_core::backend::execution::current_backend_policy().is_none());
        let caps = DeviceCaps::wgpu(32, true, 256);
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let expected_backend = trainer.backend_policy().tensor_util_backend_label();
        let calls = Arc::new(Mutex::new(0usize));
        let policy_requests = Arc::new(Mutex::new(Vec::new()));
        trainer.set_training_device(
            ScalingTrainingDevice::new(1.0, Arc::clone(&calls))
                .with_policy_capture(Arc::clone(&policy_requests)),
        );
        let mut module = SpectralGradientModule::new(vec![0.8, -0.4, 0.6, -0.2]);
        module.accumulate();

        trainer.step(&mut module).unwrap();

        assert_eq!(
            *policy_requests
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner()),
            vec![expected_backend]
        );
        assert!(st_core::backend::execution::current_backend_policy().is_none());
    }

    #[test]
    fn trainer_rejects_non_finite_synchronized_accumulator_without_updating_weights() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let calls = Arc::new(Mutex::new(0usize));
        trainer.set_training_device(ScalingTrainingDevice::new(
            f32::INFINITY,
            Arc::clone(&calls),
        ));
        let mut module = SpectralGradientModule::new(vec![0.8, -0.4, 0.6, -0.2]);
        module.accumulate();
        let grad_before = module.param.gradient().unwrap().clone();

        let err = trainer.step(&mut module).unwrap_err();

        assert!(matches!(
            err,
            TensorError::NonFiniteValue {
                label: "synchronized_accumulator",
                value,
            } if !value.is_finite()
        ));
        assert_eq!(
            *calls
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner()),
            1
        );
        assert!(module.weights().data().iter().all(|value| *value == 0.0));
        assert_eq!(*module.param.gradient().unwrap(), grad_before);
    }

    #[test]
    fn trainer_runs_epoch_with_roundtable_schedule() {
        let caps = DeviceCaps::wgpu(32, true, 256);
        let mut trainer = ModuleTrainer::new(caps, -1.1, 0.05, 0.01);
        let mut model = Sequential::new();
        model.push(Linear::new("lin", 2, 1).unwrap());
        trainer.prepare(&mut model).unwrap();

        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let dataset = vec![
            (
                Tensor::from_vec(1, 2, vec![0.0, 1.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![1.0]).unwrap(),
            ),
            (
                Tensor::from_vec(1, 2, vec![1.0, 0.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
            ),
        ];

        let mut loss = MeanSquaredError::new();
        let stats = trainer
            .train_epoch(&mut model, &mut loss, dataset.clone(), &schedule)
            .unwrap();
        assert_eq!(stats.batches, dataset.len());
        assert!(stats.total_loss.is_finite());

        // Ensure the model parameters changed by running another batch and checking the outputs.
        let input = Tensor::from_vec(1, 2, vec![1.0, 1.0]).unwrap();
        let before = model.forward(&input).unwrap();
        trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .unwrap();
        let after = model.forward(&input).unwrap();
        assert_ne!(before.data(), after.data());
    }

    #[test]
    fn trainer_train_epochs_tracks_validation_history() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = Sequential::new();
        model.push(Linear::new("fit_lin", 2, 1).unwrap());
        trainer.prepare(&mut model).unwrap();

        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let train_batches = vec![
            (
                Tensor::from_vec(1, 2, vec![0.0, 1.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![1.0]).unwrap(),
            ),
            (
                Tensor::from_vec(1, 2, vec![1.0, 0.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
            ),
        ];
        let validation_batches = vec![(
            Tensor::from_vec(1, 2, vec![0.5, 0.5]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.5]).unwrap(),
        )];

        let mut loss = MeanSquaredError::new();
        let report = trainer
            .train_epochs(
                &mut model,
                &mut loss,
                &train_batches,
                Some(validation_batches.as_slice()),
                &schedule,
                TrainingRunConfig::new(3),
            )
            .unwrap();

        assert_eq!(report.epochs_run(), 3);
        assert!(report.best_epoch_index.is_some());
        assert!(!report.stopped_early);
        assert!(!report.restored_best);
        assert!(report.epochs.iter().all(|epoch| epoch.validation.is_some()));
        assert!(report.best_epoch().expect("best epoch").score.is_finite());
    }

    #[test]
    fn trainer_train_epochs_can_stop_on_validation_patience() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = Sequential::new();
        model.push(Linear::new("early_stop_lin", 2, 1).unwrap());
        trainer.prepare(&mut model).unwrap();

        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let batches = vec![(
            Tensor::from_vec(1, 2, vec![0.25, 0.75]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.5]).unwrap(),
        )];
        let mut loss = MeanSquaredError::new();

        let report = trainer
            .train_epochs(
                &mut model,
                &mut loss,
                &batches,
                Some(batches.as_slice()),
                &schedule,
                TrainingRunConfig::new(5)
                    .with_validation_patience(Some(0))
                    .with_min_delta(100.0),
            )
            .unwrap();

        assert_eq!(report.epochs_run(), 2);
        assert_eq!(report.best_epoch_index, Some(0));
        assert!(report.stopped_early);
        assert!(!report.epochs[1].improved);
    }

    #[test]
    fn trainer_train_epochs_can_restore_best_state() {
        let mut schedule_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        let schedule = schedule_trainer.roundtable(1, 1, RoundtableConfig::default());
        let batches = vec![(
            Tensor::from_vec(1, 1, vec![1.0]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
        )];

        let mut expected_trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        let mut expected = FixedGradientModule::new(1.0);
        expected_trainer.prepare(&mut expected).unwrap();
        let mut expected_loss = ConstantLoss::new(1.0);
        expected_trainer
            .train_epoch(
                &mut expected,
                &mut expected_loss,
                batches.clone(),
                &schedule,
            )
            .unwrap();
        let expected_state = expected.state_dict().unwrap();

        let mut trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        let mut module = FixedGradientModule::new(1.0);
        trainer.prepare(&mut module).unwrap();
        let mut loss = ConstantLoss::new(1.0);
        let report = trainer
            .train_epochs(
                &mut module,
                &mut loss,
                &batches,
                Some(batches.as_slice()),
                &schedule,
                TrainingRunConfig::new(5)
                    .with_validation_patience(Some(0))
                    .with_min_delta(100.0)
                    .with_restore_best(true),
            )
            .unwrap();

        assert_eq!(report.epochs_run(), 2);
        assert_eq!(report.best_epoch_index, Some(0));
        assert!(report.stopped_early);
        assert!(report.restored_best);
        assert_eq!(module.state_dict().unwrap(), expected_state);
    }

    #[test]
    fn trainer_train_epochs_loader_rebuilds_epoch_batches() {
        let mut trainer = ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01);
        let mut model = Sequential::new();
        model.push(Linear::new("loader_fit", 1, 1).unwrap());
        trainer.prepare(&mut model).unwrap();
        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let train = Dataset::from_vec(vec![
            (
                Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
            ),
            (
                Tensor::from_vec(1, 1, vec![1.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![1.0]).unwrap(),
            ),
            (
                Tensor::from_vec(1, 1, vec![2.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![2.0]).unwrap(),
            ),
        ]);
        let validation = Dataset::from_vec(vec![(
            Tensor::from_vec(1, 1, vec![0.5]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.5]).unwrap(),
        )]);
        let train_loader = train.loader().batched(1);
        let validation_loader = validation.loader().batched(1);
        let mut loss = MeanSquaredError::new();

        let report = trainer
            .train_epochs_loader(
                &mut model,
                &mut loss,
                &train_loader,
                Some(&validation_loader),
                &schedule,
                TrainingRunConfig::new(3)
                    .with_epoch_shuffle_seed(Some(7))
                    .with_restore_best(true),
            )
            .unwrap();

        assert_eq!(report.epochs_run(), 3);
        assert!(report.restored_best);
        assert!(report.epochs.iter().all(|epoch| epoch.train.batches == 3));
        assert!(report
            .epochs
            .iter()
            .all(|epoch| epoch.validation.map(|stats| stats.batches) == Some(1)));
    }

    #[test]
    fn trainer_spectral_metrics_capture_band_snapshot_without_coherence_events() {
        let caps = DeviceCaps::wgpu(32, true, 256);
        let mut trainer = ModuleTrainer::new(caps, -1.1, 0.05, 0.01);
        trainer.enable_spectral_learning_rate(SpectralLearningRatePolicy::default());
        let mut model = Sequential::new();
        model.push(Linear::new("lin", 2, 3).unwrap());
        trainer.prepare(&mut model).unwrap();

        let schedule = trainer.roundtable(
            1,
            3,
            RoundtableConfig {
                top_k: 1,
                mid_k: 1,
                bottom_k: 1,
                here_tolerance: 1e-6,
                ..RoundtableConfig::default()
            },
        );
        let dataset = vec![
            (
                Tensor::from_vec(1, 2, vec![0.0, 1.0]).unwrap(),
                Tensor::from_vec(1, 3, vec![1.0, 0.5, -0.5]).unwrap(),
            ),
            (
                Tensor::from_vec(1, 2, vec![1.0, -0.5]).unwrap(),
                Tensor::from_vec(1, 3, vec![0.25, -0.75, 0.5]).unwrap(),
            ),
        ];

        let mut loss = MeanSquaredError::new();
        trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .unwrap();

        let metrics = trainer.spectral_metrics().expect("spectral metrics");
        assert_eq!(metrics.source, TrainerSpectralMetricsSource::BandEnergy);
        assert!(metrics.adjustment.is_none());
        assert_eq!(metrics.turnover, Some(0.0));
        let band = metrics.band_energy.expect("band energy snapshot");
        assert!(band.l1().is_finite());
        assert!(band.l1() > 0.0);
        assert!((0.0..=1.0).contains(&band.spectral.sheet_confidence));
    }

    #[test]
    fn spectral_policy_reconfigured_bounds_keep_checkpoint_state_admissible() {
        let policy = SpectralLearningRatePolicy::default()
            .with_lr_bounds(2.0, 3.0)
            .with_band_bounds(1.5, 2.5);
        let state = policy.state();

        assert_eq!(state.lr_state, 2.0);
        assert_eq!(state.applied_lr_scale, 2.0);
        assert_eq!(state.band_state, [1.5; 3]);
        assert_eq!(state.local_lr_state, [1.5; 3]);
        assert_eq!(
            SpectralLearningRatePolicy::from_state(state)
                .unwrap()
                .state(),
            state
        );

        let mut invalid = state;
        invalid.max_lr_step = 0.5;
        assert!(SpectralLearningRatePolicy::from_state(invalid).is_err());

        let mut invalid = state;
        invalid.local_lr_state[0] = 9.0;
        assert!(SpectralLearningRatePolicy::from_state(invalid).is_err());
    }

    #[test]
    fn spectral_policy_control_is_dimension_invariant_at_distribution_extremes() {
        fn policy() -> SpectralLearningRatePolicy {
            SpectralLearningRatePolicy::default()
                .with_smoothing(1.0)
                .with_event_smoothing(1.0)
                .with_sheet_gain(0.0)
                .with_spin_gain(0.0)
                .with_phase_gain(0.0)
                .with_stuck_phase_gain(0.0)
                .with_energy_gain(0.0)
        }

        fn adjustment(weights: Vec<f32>) -> SpectralAdjustment {
            let signal = coherence_signal_for_weights(weights, 0.8, 0.0);
            policy()
                .observe_signal(Some(&signal), 0.0, &BandEnergy::new(1.0, 1.0, 1.0))
                .expect("validated coherence control")
        }

        for concentrated in [false, true] {
            let mut four = vec![0.25; 4];
            let mut sixty_four = vec![1.0 / 64.0; 64];
            if concentrated {
                four.fill(0.0);
                four[0] = 1.0;
                sixty_four.fill(0.0);
                sixty_four[0] = 1.0;
            }

            let four = adjustment(four);
            let sixty_four = adjustment(sixty_four);
            assert!((four.metrics.raw_mean_coherence - 0.25).abs() < 1.0e-6);
            assert!((sixty_four.metrics.raw_mean_coherence - 1.0 / 64.0).abs() < 1.0e-6);
            assert!(
                (four.metrics.spectral_radius - sixty_four.metrics.spectral_radius).abs() < 1.0e-6
            );
            assert!(
                (four.metrics.spectral_entropy - sixty_four.metrics.spectral_entropy).abs()
                    < 1.0e-6
            );
            assert!(
                (four.metrics.spectral_pressure - sixty_four.metrics.spectral_pressure).abs()
                    < 1.0e-6
            );
            assert!((four.lr_scale - sixty_four.lr_scale).abs() < 1.0e-6);
            assert!((four.band_scale.0 - sixty_four.band_scale.0).abs() < 1.0e-6);
            assert!((four.band_scale.1 - sixty_four.band_scale.1).abs() < 1.0e-6);
            assert!((four.band_scale.2 - sixty_four.band_scale.2).abs() < 1.0e-6);
            assert_eq!(four.metrics.control_kind, ZSPACE_COHERENCE_CONTROL_KIND);
            assert_eq!(
                four.metrics.control_contract_version,
                ZSPACE_COHERENCE_CONTROL_CONTRACT_VERSION
            );
            assert_eq!(four.metrics.control_semantic_backend, "rust");
            assert_eq!(four.metrics.distribution_channels, 4);
            assert_eq!(sixty_four.metrics.distribution_channels, 64);
        }
    }

    #[test]
    fn trace_bridge_accepts_only_current_consistent_rust_control_contracts() {
        let _global_state = crate::test_global_state_lock();
        let topos = OpenCartesianTopos::new(-1.0, 1.0e-5, 10.0, 256, 8192).unwrap();
        let mut sequencer = ZSpaceCoherenceSequencer::new(64, 4, -1.0, topos).unwrap();
        let recorder = ZSpaceTraceRecorder::new(ZSpaceTraceConfig {
            capacity: 16,
            max_vector_len: 64,
            publish_plugin_events: false,
        });
        sequencer.register_plugin(recorder.clone());
        let input = Tensor::from_vec(1, 64, vec![0.05; 64]).unwrap();
        sequencer.forward_with_diagnostics(&input).unwrap();
        let event = recorder
            .snapshot()
            .events
            .into_iter()
            .find(|event| matches!(event, ZSpaceTraceEvent::Aggregated { .. }))
            .expect("aggregated trace event");

        let signal = CoherenceSignal::from_zspace_trace_event(&event)
            .expect("current Rust trace contract should be accepted");
        assert_eq!(signal.control().kind, ZSPACE_COHERENCE_CONTROL_KIND);
        assert_eq!(signal.control().semantic_backend, "rust");
        let latest = Mutex::new(None);
        ZSpaceTraceCoherenceBridge::replace_latest_from_trace_event(&latest, &event);
        assert!(latest.lock().unwrap().is_some());

        let live_bridge = ZSpaceTraceCoherenceBridge::subscribe();
        let stable_payload = serde_json::to_value(event.stable_record()).unwrap();
        global_registry()
            .event_bus()
            .publish(&PluginEvent::custom("ZSpaceTrace", stable_payload));
        assert!(live_bridge.drain().is_some());
        let raw_payload = serde_json::to_value(&event).unwrap();
        global_registry()
            .event_bus()
            .publish(&PluginEvent::custom("ZSpaceTrace", raw_payload));
        assert!(live_bridge.drain().is_none());

        let mut legacy = event.clone();
        let ZSpaceTraceEvent::Aggregated { diagnostics, .. } = &mut legacy else {
            unreachable!()
        };
        diagnostics.control_contract_version = None;
        assert!(CoherenceSignal::from_zspace_trace_event(&legacy).is_none());

        let mut missing_mass = event.clone();
        let ZSpaceTraceEvent::Aggregated { diagnostics, .. } = &mut missing_mass else {
            unreachable!()
        };
        diagnostics.distribution_weight_mass = None;
        assert!(CoherenceSignal::from_zspace_trace_event(&missing_mass).is_none());

        let mut missing_witness = event.clone();
        let ZSpaceTraceEvent::Aggregated { diagnostics, .. } = &mut missing_witness else {
            unreachable!()
        };
        diagnostics.distribution_witness = None;
        assert!(CoherenceSignal::from_zspace_trace_event(&missing_witness).is_none());

        let mut tampered_concentration = event.clone();
        let ZSpaceTraceEvent::Aggregated { diagnostics, .. } = &mut tampered_concentration else {
            unreachable!()
        };
        diagnostics.concentration = diagnostics.concentration.map(|value| value + 0.1);
        assert!(CoherenceSignal::from_zspace_trace_event(&tampered_concentration).is_none());

        let mut tampered_witness_contract = event.clone();
        let ZSpaceTraceEvent::Aggregated { diagnostics, .. } = &mut tampered_witness_contract
        else {
            unreachable!()
        };
        diagnostics
            .distribution_witness
            .as_mut()
            .expect("current trace witness")
            .semantic_backend = "python".to_owned();
        assert!(CoherenceSignal::from_zspace_trace_event(&tampered_witness_contract).is_none());

        let mut tampered_witness_simplex = event.clone();
        let ZSpaceTraceEvent::Aggregated { diagnostics, .. } = &mut tampered_witness_simplex else {
            unreachable!()
        };
        diagnostics
            .distribution_witness
            .as_mut()
            .expect("current trace witness")
            .normalized_weights[0] += 0.1;
        assert!(CoherenceSignal::from_zspace_trace_event(&tampered_witness_simplex).is_none());

        let mut invalid_structure = event.clone();
        let ZSpaceTraceEvent::Aggregated { diagnostics, .. } = &mut invalid_structure else {
            unreachable!()
        };
        diagnostics.dominant_channel = diagnostics.distribution_channels;
        assert!(CoherenceSignal::from_zspace_trace_event(&invalid_structure).is_none());

        let mut tampered = event;
        let ZSpaceTraceEvent::Aggregated { diagnostics, .. } = &mut tampered else {
            unreachable!()
        };
        diagnostics.spectral_pressure = diagnostics.spectral_pressure.map(|value| value + 0.1);
        assert!(CoherenceSignal::from_zspace_trace_event(&tampered).is_none());
        ZSpaceTraceCoherenceBridge::replace_latest_from_trace_event(&latest, &tampered);
        assert!(latest.lock().unwrap().is_none());
    }

    #[test]
    fn train_epoch_applies_autopilot_overrides_to_the_credited_step() {
        let profile_dir = tempfile::tempdir().expect("temporary Autopilot profile directory");
        let recorder = PluginEventRecorder::subscribe(
            global_registry().event_bus().clone(),
            PluginEventRecorderConfig { capacity: 256 },
        );
        let caps = DeviceCaps::wgpu(32, true, 256);
        let mut groups = HashMap::new();
        groups.insert("wg".to_string(), vec!["64".to_string()]);
        groups.insert("here.tile".to_string(), vec!["42".to_string()]);
        groups.insert("beneath.fftradix".to_string(), vec!["2".to_string()]);
        let runtime = BlackCatRuntime::new(
            ZMetaParams::default(),
            ChoiceGroups { groups },
            8,
            SoftBanditMode::TS,
            None,
        );
        let autopilot = Autopilot::try_new_with_profile_dir(
            caps,
            AutoConfig {
                feat_dim: 8,
                mode: AutoMode::Auto,
                knobs: vec![
                    KnobSpec {
                        id: "wg".to_string(),
                        domain: vec!["64".to_string()],
                        default_idx: 0,
                    },
                    KnobSpec {
                        id: "here.tile".to_string(),
                        domain: vec!["42".to_string()],
                        default_idx: 0,
                    },
                    KnobSpec {
                        id: "beneath.fftradix".to_string(),
                        domain: vec!["2".to_string()],
                        default_idx: 0,
                    },
                ],
                extra_features: Vec::new(),
            },
            runtime,
            profile_dir.path(),
        )
        .expect("valid Autopilot contract");
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01).with_autopilot(autopilot);
        let schedule = trainer.roundtable(8, 16, RoundtableConfig::default());

        let mut module = Linear::new("autopilot_causal_step", 16, 16).unwrap();
        let mut loss = MeanSquaredError::new();
        trainer.prepare(&mut module).unwrap();
        let input = Tensor::from_vec(8, 16, vec![0.25; 8 * 16]).unwrap();
        let target = Tensor::from_vec(8, 16, vec![0.0; 8 * 16]).unwrap();
        trainer
            .train_epoch(&mut module, &mut loss, vec![(input, target)], &schedule)
            .unwrap();

        let trace = recorder.snapshot();
        let execution = trace.events.iter().find_map(|record| match &record.event {
            PluginEventSnapshot::Custom {
                event_type,
                data: Some(data),
            } if event_type == "TrainerStep" && data["autopilot"]["picks"]["here.tile"] == "42" => {
                Some(data)
            }
            _ => None,
        });
        let execution = execution.expect("Autopilot TrainerStep execution witness");
        assert_eq!(
            execution["autopilot"]["selection"]["contract"],
            "spiraltorch.blackcat.contextual-bandit"
        );
        assert_eq!(
            execution["autopilot"]["selection"]["decisions"]["here.tile"]["chosen"],
            "42"
        );
        assert_eq!(
            execution["autopilot"]["executed_choices"]["here"]["tile"],
            42
        );
        assert_eq!(
            execution["autopilot"]["executed_choices"]["beneath"]["fft_radix"],
            2
        );
    }

    #[test]
    fn train_epoch_abandons_autopilot_selection_when_the_step_fails() {
        let profile_dir = tempfile::tempdir().expect("temporary Autopilot profile directory");
        let caps = DeviceCaps::wgpu(32, true, 256);
        let groups = ChoiceGroups {
            groups: HashMap::from([
                ("wg".to_string(), vec!["64".to_string()]),
                ("here.tile".to_string(), vec!["42".to_string()]),
                ("beneath.fftradix".to_string(), vec!["2".to_string()]),
            ]),
        };
        let runtime =
            BlackCatRuntime::try_new(ZMetaParams::default(), groups, 8, SoftBanditMode::TS, None)
                .expect("valid BlackCat contract");
        let autopilot = Autopilot::try_new_with_profile_dir(
            caps,
            AutoConfig {
                feat_dim: 8,
                mode: AutoMode::Auto,
                knobs: vec![
                    KnobSpec {
                        id: "wg".to_string(),
                        domain: vec!["64".to_string()],
                        default_idx: 0,
                    },
                    KnobSpec {
                        id: "here.tile".to_string(),
                        domain: vec!["42".to_string()],
                        default_idx: 0,
                    },
                    KnobSpec {
                        id: "beneath.fftradix".to_string(),
                        domain: vec!["2".to_string()],
                        default_idx: 0,
                    },
                ],
                extra_features: Vec::new(),
            },
            runtime,
            profile_dir.path(),
        )
        .expect("valid Autopilot contract");
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01).with_autopilot(autopilot);
        let schedule = trainer.roundtable(8, 16, RoundtableConfig::default());
        let input = Tensor::from_vec(8, 16, vec![0.25; 8 * 16]).unwrap();
        let target = Tensor::from_vec(8, 16, vec![0.0; 8 * 16]).unwrap();

        let mut failing_module = FailingForwardModule;
        let mut loss = MeanSquaredError::new();
        assert!(trainer
            .train_epoch(
                &mut failing_module,
                &mut loss,
                vec![(input.clone(), target.clone())],
                &schedule,
            )
            .is_err());

        let autopilot = trainer.autopilot.as_ref().expect("Autopilot retained");
        let abandoned_selection = autopilot
            .runtime()
            .last_selection_witness()
            .expect("failed step selection witness")
            .selection_id;
        assert_eq!(autopilot.runtime().pending_selection_id(), None);
        assert_eq!(autopilot.runtime().last_credited_selection_id(), None);
        assert!(autopilot
            .runtime()
            .bandit_observation_counts()
            .values()
            .flat_map(|group| group.values())
            .all(|observations| *observations == 0));

        let mut module = Linear::new("autopilot_retry_after_failure", 16, 16).unwrap();
        trainer.prepare(&mut module).unwrap();
        trainer
            .train_epoch(&mut module, &mut loss, vec![(input, target)], &schedule)
            .expect("next epoch can acquire and credit a fresh selection");
        let runtime = trainer
            .autopilot
            .as_ref()
            .expect("Autopilot retained")
            .runtime();
        assert_eq!(runtime.pending_selection_id(), None);
        assert_eq!(
            runtime.last_credited_selection_id(),
            Some(abandoned_selection + 1)
        );
    }

    #[test]
    fn region_loss_strategy_scales_total_loss() {
        let elliptic = SoftlogicEllipticSample {
            curvature_radius: 1.0,
            geodesic_radius: 0.9,
            normalized_radius: 0.9,
            spin_alignment: 0.9,
            sheet_index: 1,
            sheet_position: 0.0,
            normal_bias: 0.0,
            sheet_count: 4,
            topological_sector: 2,
            homology_index: 0,
            rotor_field: [0.0; 3],
            flow_vector: [0.0; 3],
            curvature_tensor: [[0.0; 3]; 3],
            resonance_heat: 0.0,
            noise_density: 0.0,
            quaternion: [0.0; 4],
            rotation: [0.0; 9],
            lie_log: [0.0; 3],
            rotor_transport: [0.0; 3],
        };
        let seed_feedback = SoftlogicZFeedback {
            psi_total: 0.0,
            weighted_loss: 0.0,
            band_energy: (0.0, 0.0, 0.0),
            drift: 0.0,
            z_signal: 0.0,
            scale: None,
            events: Vec::new(),
            attributions: vec![(ZSource::Microlocal, 1.0)],
            elliptic: Some(elliptic),
        };

        let weights = RegionLossWeights::new(1.0).with_override(
            ZSpaceRegionKey::new(ZSpaceSpinBand::Leading, ZSpaceRadiusBand::Edge),
            2.0,
        );
        let config = RegionLossConfig::new(weights);
        let caps = DeviceCaps::wgpu(32, true, 256);
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01)
            .with_loss_strategy(LossStrategy::Region(config));
        trainer.softlogic.last_feedback = Some(seed_feedback);
        let mut module = IdentityModule;
        trainer.prepare(&mut module).unwrap();
        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let dataset = vec![(
            Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
            Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
        )];
        let mut loss = ConstantLoss::new(1.5);
        let stats = trainer
            .train_epoch(&mut module, &mut loss, dataset, &schedule)
            .unwrap();
        assert!((stats.total_loss - 3.0).abs() < 1e-6);
    }

    #[test]
    fn adaptive_region_weighting_amplifies_high_loss_regions() {
        let weights = RegionLossWeights::new(1.0);
        let adaptive = AdaptiveRegionWeighting::new()
            .with_learning_rate(1.0)
            .with_min_samples(1)
            .with_bounds(0.5, 8.0);
        let mut config = RegionLossConfig::new(weights)
            .with_adaptive(adaptive)
            .with_history_window(4);

        let elliptic = SoftlogicEllipticSample {
            curvature_radius: 1.0,
            geodesic_radius: 0.9,
            normalized_radius: 0.9,
            spin_alignment: 0.9,
            sheet_index: 1,
            sheet_position: 0.0,
            normal_bias: 0.0,
            sheet_count: 4,
            topological_sector: 2,
            homology_index: 0,
            rotor_field: [0.0; 3],
            flow_vector: [0.0; 3],
            curvature_tensor: [[0.0; 3]; 3],
            resonance_heat: 0.0,
            noise_density: 0.0,
            quaternion: [0.0; 4],
            rotation: [0.0; 9],
            lie_log: [0.0; 3],
            rotor_transport: [0.0; 3],
        };
        let feedback = SoftlogicZFeedback {
            psi_total: 0.0,
            weighted_loss: 0.0,
            band_energy: (0.0, 0.0, 0.0),
            drift: 0.0,
            z_signal: 0.0,
            scale: None,
            events: Vec::new(),
            attributions: vec![(ZSource::Microlocal, 1.0)],
            elliptic: Some(elliptic),
        };

        // Seed a low baseline loss before observing a large spike.
        let _ = config.region_factor(&feedback, 0.1);
        let result = config.region_factor(&feedback, 2.0).unwrap();
        assert!(result.0 > 1.0);
        let first_bundle = config.reports(feedback.region_descriptor(), 0);
        let report = first_bundle
            .snapshot
            .expect("snapshot report should always be present");
        assert_eq!(report.shape(), (3, 3));
        assert!(report.metadata.extras.contains_key("highlight"));
        let second_bundle = config.reports(feedback.region_descriptor(), 1);
        assert!(second_bundle.trend.is_some());
        assert!(second_bundle.volatility.is_some());
    }

    #[test]
    fn trainer_enforces_rewrite_budget() {
        let caps = DeviceCaps::wgpu(16, true, 128);
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        trainer.set_rewrite_budget(1, 1);
        if let Some(budget) = trainer.rewrite_budget.as_mut() {
            budget.begin_epoch();
        }

        let op = HeurOp {
            origin: "test".to_string(),
            kind: HeurOpKind::AppendSoft {
                script: "k:topk(2)".to_string(),
                weight: 1.0,
            },
            issued_at: SystemTime::now(),
        };
        let proposal = GlobalProposal {
            proposal_id: "proposal-test".to_string(),
            ops: vec![op],
            evidence: Vec::new(),
        };

        let initial = trainer.heuristics_log().entries().len();
        trainer
            .apply_proposal(&proposal, HashMap::new())
            .expect("first rewrite allowed");
        let after_first = trainer.heuristics_log().entries().len();
        assert_eq!(after_first, initial + proposal.ops.len());

        trainer
            .apply_proposal(&proposal, HashMap::new())
            .expect("second rewrite ignored");
        let after_second = trainer.heuristics_log().entries().len();
        assert_eq!(after_second, after_first);

        if let Some(budget) = trainer.rewrite_budget.as_mut() {
            budget.begin_epoch();
        }
        let proposal_after_cooldown = GlobalProposal {
            proposal_id: "proposal-after-cooldown".to_string(),
            ops: vec![HeurOp {
                origin: "test".to_string(),
                kind: HeurOpKind::AppendSoft {
                    script: "k:topk(3)".to_string(),
                    weight: 1.0,
                },
                issued_at: SystemTime::now(),
            }],
            evidence: Vec::new(),
        };
        trainer
            .apply_proposal(&proposal_after_cooldown, HashMap::new())
            .expect("rewrite allowed after cooldown");
        let after_third = trainer.heuristics_log().entries().len();
        assert_eq!(after_third, after_first + proposal_after_cooldown.ops.len());
    }

    #[test]
    fn trainer_exposes_blackcat_runtime_stats() {
        let caps = DeviceCaps::wgpu(16, true, 128);
        let mut groups = HashMap::new();
        groups.insert("tile".to_string(), vec!["a".to_string(), "b".to_string()]);
        let runtime = BlackCatRuntime::new(
            ZMetaParams::default(),
            ChoiceGroups { groups },
            4,
            SoftBanditMode::TS,
            None,
        );
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01).with_blackcat(runtime);
        if let Some(rt) = trainer.blackcat.as_mut() {
            rt.begin_step();
            let mut extra = HashMap::new();
            extra.insert("grad_norm".into(), 0.4);
            let metrics = StepMetrics {
                step_time_ms: 10.0,
                mem_peak_mb: 256.0,
                retry_rate: 0.05,
                extra,
            };
            let report = rt
                .try_post_step_report(&metrics)
                .expect("trainer metrics produce a guarded reward");
            assert_eq!(
                report.semantic_owner,
                st_core::heur::free_energy::FREE_ENERGY_SEMANTIC_OWNER
            );
            assert_eq!(
                rt.last_free_energy_report()
                    .expect("report retained")
                    .utility,
                report.utility
            );
        }
        let stats = trainer
            .blackcat_runtime_stats()
            .expect("runtime stats available");
        assert_eq!(stats.steps, 1);
        assert!(stats.step_time_ms_ema > 0.0);
        assert_eq!(stats.extras.get("grad_norm").cloned().unwrap(), 0.4);
    }

    #[test]
    fn trainer_step_trace_includes_tensor_backend_counters() {
        let bus = global_registry().event_bus().clone();
        let events = Arc::new(Mutex::new(Vec::<serde_json::Value>::new()));
        let captured = events.clone();
        let subscription_id = bus.subscribe(
            "TrainerStep",
            Arc::new(move |event: &PluginEvent| {
                if let Some(payload) = event.downcast_data::<serde_json::Value>() {
                    captured
                        .lock()
                        .unwrap_or_else(|poisoned| poisoned.into_inner())
                        .push(payload.clone());
                }
            }),
        );

        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = Linear::new("trace_linear", 2, 1).unwrap();
        trainer.prepare(&mut model).unwrap();
        let schedule = trainer.roundtable(2, 1, RoundtableConfig::default());
        let dataset = vec![(
            Tensor::from_vec(2, 2, vec![0.5, -1.0, 1.5, 0.25]).unwrap(),
            Tensor::from_vec(2, 1, vec![0.1, -0.2]).unwrap(),
        )];
        let mut loss = MeanSquaredError::new();
        let result = trainer.train_epoch(&mut model, &mut loss, dataset, &schedule);
        let _ = bus.unsubscribe("TrainerStep", subscription_id);
        result.unwrap();

        let events = events
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        let event = events
            .iter()
            .rev()
            .find(|event| {
                event
                    .get("metrics")
                    .and_then(|metrics| metrics.get("extra"))
                    .and_then(|extra| extra.as_object())
                    .is_some_and(|extra| {
                        extra
                            .get("tensor_op_mse_loss_forward")
                            .and_then(|value| value.as_f64())
                            .unwrap_or(0.0)
                            >= 1.0
                            && extra
                                .get("batch_input_rows")
                                .and_then(|value| value.as_f64())
                                == Some(2.0)
                            && extra
                                .get("batch_input_values_total")
                                .and_then(|value| value.as_f64())
                                == Some(4.0)
                            && extra
                                .get("tensor_policy_device_cpu")
                                .and_then(|value| value.as_f64())
                                == Some(1.0)
                    })
            })
            .expect("trainer step trace event for this test");
        let extra = event
            .get("metrics")
            .and_then(|metrics| metrics.get("extra"))
            .and_then(|extra| extra.as_object())
            .expect("TrainerStep metrics.extra");
        assert_eq!(
            extra
                .get("batch_input_rows")
                .and_then(|value| value.as_f64()),
            Some(2.0)
        );
        assert_eq!(
            extra
                .get("batch_input_cols")
                .and_then(|value| value.as_f64()),
            Some(2.0)
        );
        assert_eq!(
            extra
                .get("batch_input_values")
                .and_then(|value| value.as_f64()),
            Some(4.0)
        );
        assert_eq!(
            extra
                .get("batch_target_rows")
                .and_then(|value| value.as_f64()),
            Some(2.0)
        );
        assert_eq!(
            extra
                .get("batch_target_cols")
                .and_then(|value| value.as_f64()),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("batch_prediction_rows")
                .and_then(|value| value.as_f64()),
            Some(2.0)
        );
        assert_eq!(
            extra
                .get("batch_prediction_cols")
                .and_then(|value| value.as_f64()),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("batch_loss_values")
                .and_then(|value| value.as_f64()),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("batch_grad_output_values")
                .and_then(|value| value.as_f64()),
            Some(2.0)
        );
        assert_eq!(
            extra
                .get("batch_input_values_total")
                .and_then(|value| value.as_f64()),
            Some(4.0)
        );
        assert_eq!(
            extra
                .get("batch_input_non_finite_values")
                .and_then(|value| value.as_f64()),
            Some(0.0)
        );
        assert_eq!(
            extra
                .get("batch_prediction_values_total")
                .and_then(|value| value.as_f64()),
            Some(2.0)
        );
        assert_eq!(
            extra
                .get("batch_prediction_non_finite_values")
                .and_then(|value| value.as_f64()),
            Some(0.0)
        );
        assert!(
            extra
                .get("batch_prediction_l2_finite")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                > 0.0
        );
        assert_eq!(
            extra
                .get("batch_loss_non_finite_values")
                .and_then(|value| value.as_f64()),
            Some(0.0)
        );
        assert!(
            extra
                .get("batch_grad_output_l2_finite")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                > 0.0
        );
        assert_eq!(
            extra
                .get("optim_param_update_params")
                .and_then(|value| value.as_f64()),
            Some(2.0)
        );
        assert_eq!(
            extra
                .get("optim_param_update_values")
                .and_then(|value| value.as_f64()),
            Some(3.0)
        );
        assert!(
            extra
                .get("optim_param_update_l2")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                > 0.0
        );
        assert!(
            extra
                .get("optim_param_update_ratio_l2")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                > 0.0
        );
        assert!(
            extra
                .get("optim_param_update_active_params")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                >= 1.0
        );
        assert!(
            extra
                .get("optim_param_update_zero_params")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                <= 1.0
        );
        assert!(
            extra
                .get("optim_param_update_max_l2")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                > 0.0
        );
        assert!(
            extra
                .get("optim_param_update_max_l2_ratio")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                > 0.0
        );
        assert!(
            extra
                .get("optim_param_update_max_ratio_l2")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                > 0.0
        );
        assert!(
            extra
                .get("optim_param_update_max_l2_index")
                .and_then(|value| value.as_f64())
                .unwrap_or(99.0)
                < 2.0
        );
        assert_eq!(
            extra
                .get("optim_param_update_non_finite_values")
                .and_then(|value| value.as_f64()),
            Some(0.0)
        );
        let fallback_lr = extra
            .get("optim_step_fallback_lr")
            .and_then(|value| value.as_f64())
            .unwrap_or(0.0);
        assert!((fallback_lr - 0.01).abs() < 1.0e-8);
        let hyper_lr = extra
            .get("optim_step_hyper_lr")
            .and_then(|value| value.as_f64())
            .unwrap_or(0.0);
        assert!((hyper_lr - 0.05).abs() < 1.0e-8);
        let state_fallback_lr = extra
            .get("optim_state_fallback_lr")
            .and_then(|value| value.as_f64())
            .unwrap_or(0.0);
        assert!((state_fallback_lr - 0.01).abs() < 1.0e-8);
        let state_hyper_lr = extra
            .get("optim_state_hyper_lr")
            .and_then(|value| value.as_f64())
            .unwrap_or(0.0);
        assert!((state_hyper_lr - 0.05).abs() < 1.0e-8);
        assert_eq!(
            extra
                .get("optim_state_realgrad_enabled")
                .and_then(|value| value.as_f64()),
            Some(0.0)
        );
        assert_eq!(
            extra
                .get("optim_state_adapter_sheet_hint")
                .and_then(|value| value.as_f64()),
            Some(8.0)
        );
        assert_eq!(
            extra
                .get("optim_accumulator_sync_enabled")
                .and_then(|value| value.as_f64()),
            Some(0.0)
        );
        assert_eq!(
            extra
                .get("optim_accumulator_sync_world_size")
                .and_then(|value| value.as_f64()),
            Some(1.0)
        );
        assert!(
            extra
                .get("tensor_ops_total")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                >= 1.0
        );
        assert!(
            extra
                .get("grad_values_total")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                > 0.0
        );
        assert_eq!(
            extra
                .get("grad_values_non_finite")
                .and_then(|value| value.as_f64()),
            Some(0.0)
        );
        assert!(
            extra
                .get("tensor_op_matmul_prepacked")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                >= 1.0
        );
        assert!(
            extra
                .get("tensor_op_matmul_prepacked_bias")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                >= 1.0
        );
        assert!(
            extra
                .get("tensor_op_sum_axis0_scaled")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                >= 1.0
        );
        assert!(
            extra
                .get("tensor_op_scale")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                >= 1.0
        );
        assert!(
            extra
                .get("tensor_op_add_scaled")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                >= 1.0
        );
        assert!(
            extra
                .get("tensor_op_mse_loss_forward")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                >= 1.0
        );
        assert!(
            extra
                .get("tensor_op_mse_loss_backward")
                .and_then(|value| value.as_f64())
                .unwrap_or(0.0)
                >= 1.0
        );
        assert_eq!(
            extra
                .get("tensor_policy_device_cpu")
                .and_then(|value| value.as_f64()),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_policy_matmul_faer")
                .and_then(|value| value.as_f64()),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_policy_prepacked_matmul_faer")
                .and_then(|value| value.as_f64()),
            Some(1.0)
        );
        assert!(extra
            .keys()
            .any(|key| key.starts_with("tensor_policy_layer_norm_")));
        assert!(extra
            .keys()
            .any(|key| key.starts_with("tensor_policy_attention_")));
        assert!(extra
            .keys()
            .any(|key| key.starts_with("tensor_policy_softmax_")));
        assert!(extra
            .keys()
            .any(|key| key.starts_with("tensor_backend_") && key != "tensor_backend_fallbacks"));
    }

    #[test]
    fn trainer_step_trace_carries_canonical_free_energy_report() {
        let bus = global_registry().event_bus().clone();
        let events = Arc::new(Mutex::new(Vec::<serde_json::Value>::new()));
        let captured = events.clone();
        let subscription_id = bus.subscribe(
            "TrainerStep",
            Arc::new(move |event: &PluginEvent| {
                if let Some(payload) = event.downcast_data::<serde_json::Value>() {
                    captured
                        .lock()
                        .unwrap_or_else(|poisoned| poisoned.into_inner())
                        .push(payload.clone());
                }
            }),
        );

        let mut groups = HashMap::new();
        groups.insert("tile".to_string(), vec!["a".to_string(), "b".to_string()]);
        let runtime = BlackCatRuntime::new(
            ZMetaParams::default(),
            ChoiceGroups { groups },
            4,
            SoftBanditMode::TS,
            None,
        );
        let mut trainer =
            ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01).with_blackcat(runtime);
        let mut model = Linear::new("free_energy_trace_linear", 2, 1).unwrap();
        trainer.prepare(&mut model).unwrap();
        let schedule = trainer.roundtable(2, 1, RoundtableConfig::default());
        let dataset = vec![(
            Tensor::from_vec(2, 2, vec![0.5, -1.0, 1.5, 0.25]).unwrap(),
            Tensor::from_vec(2, 1, vec![0.1, -0.2]).unwrap(),
        )];
        let mut loss = MeanSquaredError::new();
        let result = trainer.train_epoch(&mut model, &mut loss, dataset, &schedule);
        let _ = bus.unsubscribe("TrainerStep", subscription_id);
        result.unwrap();

        let retained_utility = trainer
            .blackcat_free_energy_report()
            .map(|report| report.utility)
            .expect("BlackCat retained canonical report");
        let events = events
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        let event = events
            .iter()
            .find(|event| {
                event
                    .get("free_energy")
                    .and_then(|report| report.get("semantic_owner"))
                    .and_then(|owner| owner.as_str())
                    == Some(st_core::heur::free_energy::FREE_ENERGY_SEMANTIC_OWNER)
                    && event["free_energy"]["utility"].as_f64() == Some(retained_utility)
            })
            .expect("TrainerStep carries canonical free-energy report");
        let report = event.get("free_energy").expect("free-energy payload");
        let traced_utility = report
            .get("utility")
            .and_then(|value| value.as_f64())
            .expect("numeric utility");
        let extra_utility = event
            .get("metrics")
            .and_then(|metrics| metrics.get("extra"))
            .and_then(|extra| extra.get("free_energy_utility"))
            .and_then(|value| value.as_f64())
            .expect("utility spotlight metric");
        assert_eq!(traced_utility, retained_utility);
        assert_eq!(extra_utility, retained_utility);
        assert_eq!(
            report
                .get("contract_version")
                .and_then(|value| value.as_str()),
            Some(st_core::heur::free_energy::FREE_ENERGY_CONTRACT_VERSION)
        );
    }

    #[test]
    fn train_epoch_accumulates_blackcat_heuristic_evidence_for_every_step() {
        let bus = global_registry().event_bus().clone();
        let events = Arc::new(Mutex::new(Vec::<serde_json::Value>::new()));
        let captured = Arc::clone(&events);
        let subscription_id = bus.subscribe(
            "TrainerStep",
            Arc::new(move |event: &PluginEvent| {
                if let Some(payload) = event.downcast_data::<serde_json::Value>() {
                    captured
                        .lock()
                        .unwrap_or_else(|poisoned| poisoned.into_inner())
                        .push(payload.clone());
                }
            }),
        );
        let temp = tempfile::tempdir().expect("temporary heuristic directory");
        let heuristic_path = temp.path().join("heur.kdsl");
        let groups = ChoiceGroups {
            groups: HashMap::from([("tile".to_string(), vec!["a".to_string(), "b".to_string()])]),
        };
        let mut runtime = BlackCatRuntime::try_new(
            ZMetaParams::default(),
            groups,
            4,
            SoftBanditMode::TS,
            Some(heuristic_path.to_string_lossy().into_owned()),
        )
        .expect("guarded BlackCat runtime");
        runtime
            .try_set_heuristic_adoption_config(SoftHeuristicAdoptionConfig {
                minimum_trials: 9,
                baseline_probability: 0.4321,
                confidence_z: 1.96,
            })
            .expect("test-specific evidence policy");
        let mut trainer =
            ModuleTrainer::new(DeviceCaps::cpu(), -1.0, 0.05, 0.01).with_blackcat(runtime);
        let mut model = Linear::new("heuristic_evidence_linear", 2, 1).unwrap();
        trainer.prepare(&mut model).unwrap();
        let schedule = trainer.roundtable(2, 1, RoundtableConfig::default());
        let batches = (0..4)
            .map(|index| {
                let offset = index as f32 * 0.05;
                (
                    Tensor::from_vec(2, 2, vec![0.5 + offset, -1.0, 1.5, 0.25]).unwrap(),
                    Tensor::from_vec(2, 1, vec![0.1, -0.2 + offset]).unwrap(),
                )
            })
            .collect::<Vec<_>>();
        let mut loss = MeanSquaredError::new();
        let result = trainer.train_epoch(&mut model, &mut loss, batches, &schedule);
        let _ = bus.unsubscribe("TrainerStep", subscription_id);
        result.expect("four-step training epoch");

        let events = events
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        let observed_rules = events
            .iter()
            .filter(|data| {
                data["heuristic_adoption"]["baseline_probability"].as_f64() == Some(0.4321)
            })
            .filter_map(|data| {
                data["heuristic_adoption"]["rule"]
                    .as_str()
                    .map(str::to_owned)
            })
            .collect::<Vec<_>>();
        let retained = trainer
            .blackcat_heuristic_adoption_report()
            .expect("trainer exposes the Rust adoption report");
        assert_eq!(
            retained.interval.trials, 4,
            "all four steps must share one semantic rule: {observed_rules:?}"
        );
        assert!(retained.interval.successes <= retained.interval.trials);
        assert_eq!(
            retained.contract,
            st_core::runtime::blackcat::BLACKCAT_HEURISTIC_ADOPTION_CONTRACT
        );
        assert!(!heuristic_path.exists());

        let adoption_steps = events
            .iter()
            .filter(|data| {
                data["heuristic_adoption"]["baseline_probability"].as_f64() == Some(0.4321)
            })
            .collect::<Vec<_>>();
        assert_eq!(adoption_steps.len(), 4);
        for (index, event) in adoption_steps.iter().enumerate() {
            let expected_trials = (index + 1) as u64;
            assert_eq!(
                event["heuristic_adoption"]["interval"]["trials"].as_u64(),
                Some(expected_trials)
            );
            assert_eq!(
                event["metrics"]["extra"]["blackcat_heuristic_trials"].as_f64(),
                Some(expected_trials as f64)
            );
            assert_eq!(
                event["metrics"]["extra"]["blackcat_heuristic_persistence_failed"].as_f64(),
                Some(0.0)
            );
        }
    }

    #[test]
    fn train_epoch_returns_tensor_backend_summary_without_trace_listener() {
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = Linear::new("epoch_trace_linear", 2, 1).unwrap();
        trainer.prepare(&mut model).unwrap();
        let schedule = trainer.roundtable(2, 1, RoundtableConfig::default());
        let dataset = vec![(
            Tensor::from_vec(2, 2, vec![0.25, -0.5, 0.75, 1.0]).unwrap(),
            Tensor::from_vec(2, 1, vec![0.0, 0.5]).unwrap(),
        )];
        let mut loss = MeanSquaredError::new();

        let stats = trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .unwrap();

        assert_eq!(stats.batches, 1);
        assert!(stats.tensor_backend.ops_total >= 1);
        assert!(stats.tensor_backend.meta_events >= stats.tensor_backend.ops_total);
        assert_eq!(stats.tensor_backend.fallbacks, 0);
        assert!(stats.tensor_backend.backend_cpu >= 2);
        assert!(
            stats.tensor_backend.backend_cpu
                + stats.tensor_backend.backend_cpu_simd
                + stats.tensor_backend.backend_faer
                + stats.tensor_backend.backend_naive
                + stats.tensor_backend.backend_wgpu
                + stats.tensor_backend.backend_cuda
                + stats.tensor_backend.backend_hip
                + stats.tensor_backend.backend_other
                >= 1
        );
    }

    #[test]
    fn tensor_backend_trace_counts_non_finite_metadata_sentinels() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "scaled_dot_attention",
            data: serde_json::json!({
                "backend": "cpu",
                "requested_backend": "auto",
                "scale": null,
                "kernel": {
                    "diagnostic": "NaN",
                    "fallbacks": ["inf", "ok"],
                },
            }),
        });

        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(extra.get("tensor_meta_events").copied(), Some(1.0));
        assert_eq!(extra.get("tensor_meta_null_values").copied(), Some(1.0));
        assert_eq!(
            extra.get("tensor_meta_non_finite_strings").copied(),
            Some(2.0)
        );
        assert_eq!(
            extra.get("tensor_meta_non_finite_sentinels").copied(),
            Some(3.0)
        );
        assert_eq!(
            extra.get("tensor_meta_non_finite_detected").copied(),
            Some(1.0)
        );
    }

    #[test]
    fn tensor_backend_trace_counts_receipts_but_not_prepared_dispatches() {
        let prepared = st_tensor::prepare_tensor_execution(
            st_tensor::TensorExecutionWorkload::Softmax { rows: 2, cols: 3 },
            "row_softmax",
            st_tensor::TensorExecutionBackend::Wgpu,
        )
        .unwrap();
        let receipt = prepared
            .complete(st_tensor::TensorExecutionBackend::Wgpu, None)
            .unwrap()
            .receipt();
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "row_softmax",
            data: serde_json::json!({
                "event_phase": "dispatch_prepared",
                "counts_as_execution": false,
                "backend": "wgpu_dense",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "row_softmax",
            data: serde_json::json!({
                "execution_receipt": receipt,
            }),
        });

        assert_eq!(trace.meta_events, 2);
        assert_eq!(trace.total, 1);
        assert_eq!(trace.requested_wgpu_hits, 1);
        assert_eq!(trace.requested_wgpu_runtime_fallbacks, 0);
        assert_eq!(trace.fallbacks, 0);
        assert_eq!(trace.by_backend.get("wgpu"), Some(&1));
        assert_eq!(trace.by_kernel_backend.get("wgpu_dense"), Some(&1));
        assert_eq!(
            trace.by_op_kernel_backend.get("row_softmax_wgpu_dense"),
            Some(&1)
        );
    }

    #[test]
    fn tensor_backend_trace_does_not_misclassify_threshold_routes_as_fallbacks() {
        let _fallback = st_tensor::execution::push_accelerator_fallback(
            st_tensor::execution::AcceleratorFallback::Allow,
        );
        let _plan = st_tensor::execution::push_execution_plan_binding(
            st_tensor::TensorExecutionPlanBinding::new(
                [0xcd; 32],
                [
                    st_tensor::TensorExecutionBackend::Faer,
                    st_tensor::TensorExecutionBackend::Faer,
                    st_tensor::TensorExecutionBackend::Cpu,
                    st_tensor::TensorExecutionBackend::Cpu,
                    st_tensor::TensorExecutionBackend::Cpu,
                    st_tensor::TensorExecutionBackend::Wgpu,
                ],
                st_tensor::execution::AcceleratorFallback::Allow,
                1024,
            ),
        );
        let receipt = st_tensor::prepare_tensor_execution(
            st_tensor::TensorExecutionWorkload::TensorUtil {
                operation: st_tensor::TensorUtilOperation::Scale,
                rows: 2,
                cols: 4,
            },
            "scale",
            st_tensor::TensorExecutionBackend::Cpu,
        )
        .unwrap()
        .complete(st_tensor::TensorExecutionBackend::Cpu, None)
        .unwrap()
        .receipt();
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "scale",
            data: serde_json::json!({
                "execution_receipt": receipt,
            }),
        });

        assert_eq!(trace.total, 1);
        assert_eq!(trace.fallbacks, 0);
        assert_eq!(trace.requested_wgpu_hits, 0);
        assert_eq!(trace.requested_wgpu_runtime_fallbacks, 0);
        assert_eq!(trace.by_backend.get("cpu"), Some(&1));
    }

    #[test]
    fn tensor_backend_trace_does_not_count_a_no_op_with_stale_backend_metadata() {
        let receipt = st_tensor::prepare_tensor_execution(
            st_tensor::TensorExecutionWorkload::Softmax { rows: 0, cols: 3 },
            "row_softmax",
            st_tensor::TensorExecutionBackend::Cpu,
        )
        .unwrap()
        .complete_no_op()
        .unwrap()
        .receipt();
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "row_softmax",
            data: serde_json::json!({
                "backend": "cpu",
                "execution_receipt": receipt,
            }),
        });

        assert_eq!(trace.meta_events, 1);
        assert_eq!(trace.total, 0);
        assert!(trace.by_backend.is_empty());
    }

    #[test]
    fn tensor_backend_trace_rejects_a_receipt_attached_to_another_operation() {
        let receipt = st_tensor::prepare_tensor_execution(
            st_tensor::TensorExecutionWorkload::Softmax { rows: 2, cols: 3 },
            "row_softmax",
            st_tensor::TensorExecutionBackend::Cpu,
        )
        .unwrap()
        .complete(st_tensor::TensorExecutionBackend::Cpu, None)
        .unwrap()
        .receipt();
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "matmul",
            data: serde_json::json!({
                "execution_receipt": receipt,
            }),
        });

        assert_eq!(trace.meta_events, 1);
        assert_eq!(trace.total, 0);
        assert!(trace.by_op.is_empty());
    }

    #[test]
    fn tensor_backend_trace_surfaces_embedding_token_repairs() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "embedding_forward",
            data: serde_json::json!({
                "backend": "cpu",
                "requested_backend": "auto",
                "tokens": 5,
                "unique_token_indices": 3,
                "repeated_token_indices": 2,
                "non_finite_tokens": 1,
                "rounded_tokens": 1,
                "clamped_low_tokens": 1,
                "clamped_high_tokens": 0,
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "embedding_backward",
            data: serde_json::json!({
                "backend": "cpu",
                "requested_backend": "auto",
                "tokens": 5,
                "unique_token_indices": 3,
                "repeated_token_indices": 2,
                "non_finite_tokens": 1,
                "rounded_tokens": 1,
                "clamped_low_tokens": 1,
                "clamped_high_tokens": 1,
            }),
        });

        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(extra.get("tensor_embedding_tokens").copied(), Some(10.0));
        assert_eq!(
            extra.get("tensor_embedding_unique_token_indices").copied(),
            Some(6.0)
        );
        assert_eq!(
            extra
                .get("tensor_embedding_repeated_token_indices")
                .copied(),
            Some(4.0)
        );
        assert_eq!(
            extra.get("tensor_embedding_non_finite_tokens").copied(),
            Some(2.0)
        );
        assert_eq!(
            extra.get("tensor_embedding_rounded_tokens").copied(),
            Some(2.0)
        );
        assert_eq!(
            extra.get("tensor_embedding_clamped_low_tokens").copied(),
            Some(2.0)
        );
        assert_eq!(
            extra.get("tensor_embedding_clamped_high_tokens").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra.get("tensor_embedding_token_repairs_total").copied(),
            Some(7.0)
        );
        assert_eq!(
            extra.get("tensor_embedding_token_repair_detected").copied(),
            Some(1.0)
        );
    }

    #[test]
    fn tensor_backend_trace_records_coherence_measurement_fallbacks() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "coherence_measure_phases",
            data: serde_json::json!({
                "backend": "cpu",
                "requested_backend": "webgpu",
                "kind": "coherence_reduction",
                "rows": 2,
                "cols": 128,
                "channels": 2,
                "accelerated_requested": true,
            }),
        });

        let mut epoch = EpochTensorBackendStats::default();
        epoch.accumulate_trace(&trace);
        assert_eq!(epoch.ops_total, 1);
        assert_eq!(epoch.backend_cpu, 1);
        assert_eq!(epoch.fallbacks, 1);

        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(extra.get("tensor_ops_total").copied(), Some(1.0));
        assert_eq!(extra.get("tensor_backend_cpu").copied(), Some(1.0));
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(1.0));
        assert_eq!(
            extra.get("tensor_op_coherence_measure_phases").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_coherence_measure_phases_cpu")
                .copied(),
            Some(1.0)
        );
    }

    #[test]
    fn tensor_backend_trace_surfaces_backend_policy_choices() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "wgpu_heuristic_choice",
            data: serde_json::json!({
                "backend": "wgpu",
                "requested_backend": "wgpu",
                "choice_source": "generated",
                "workgroup": 256,
                "lanes": 32,
                "compaction_tile": 2048,
                "fft_radix": 4,
                "fft_segments": 2,
                "override_count": 1,
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "unison_rank_choice",
            data: serde_json::json!({
                "backend": "wgpu",
                "requested_backend": "wgpu",
                "choice_source": "wgpu_generated",
                "candidate_count": 3,
                "best_score": 0.75,
                "baseline_score": 0.25,
                "wgpu_generated_score": 0.75,
                "wgpu_generated_score_delta": 0.5,
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "kdsl_env_bridge",
            data: serde_json::json!({
                "backend": "cpu",
                "requested_backend": "auto",
                "status": "feature_disabled",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "kv_consensus_soft_rules",
            data: serde_json::json!({
                "backend": "cpu",
                "requested_backend": "auto",
                "status": "missing_url",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "wasm_tuner_choice",
            data: serde_json::json!({
                "backend": "wgpu",
                "requested_backend": "auto",
                "status": "hit",
            }),
        });

        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(extra.get("backend_policy_events").copied(), Some(5.0));
        assert_eq!(extra.get("backend_policy_wgpu_choices").copied(), Some(1.0));
        assert_eq!(
            extra.get("backend_policy_unison_choices").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra.get("backend_policy_kdsl_env_events").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra.get("backend_policy_kv_soft_events").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra.get("backend_policy_wasm_tuner_events").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("backend_policy_source_wgpu_heuristic_choice_generated")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("backend_policy_source_unison_rank_choice_wgpu_generated")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("backend_policy_status_kdsl_env_bridge_feature_disabled")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("backend_policy_status_kv_consensus_soft_rules_missing_url")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("backend_policy_status_wasm_tuner_choice_hit")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra.get("backend_policy_wgpu_last_workgroup").copied(),
            Some(256.0)
        );
        assert_eq!(
            extra
                .get("backend_policy_wgpu_last_compaction_tile")
                .copied(),
            Some(2048.0)
        );
        assert_eq!(
            extra
                .get("backend_policy_unison_last_candidate_count")
                .copied(),
            Some(3.0)
        );
        assert_eq!(
            extra.get("backend_policy_unison_last_best_score").copied(),
            Some(0.75)
        );
        assert_eq!(
            extra
                .get("backend_policy_unison_last_wgpu_generated_score_delta")
                .copied(),
            Some(0.5)
        );
    }

    #[test]
    fn tensor_backend_trace_records_backendless_tensor_util_routes_as_policy() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "tensor_util_route",
            data: serde_json::json!({
                "requested_backend": "wgpu",
                "selected_backend": "cpu",
                "status": "cpu_threshold",
                "choice_source": "threshold_guard",
                "values": 8,
                "threshold": 1024,
            }),
        });

        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert!(extra.get("tensor_ops_total").is_none());
        assert_eq!(extra.get("backend_policy_events").copied(), Some(1.0));
        assert_eq!(
            extra.get("backend_policy_tensor_util_routes").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("backend_policy_status_tensor_util_route_cpu_threshold")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("backend_policy_source_tensor_util_route_threshold_guard")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra.get("backend_policy_tensor_util_last_values").copied(),
            Some(8.0)
        );
        assert_eq!(
            extra
                .get("backend_policy_tensor_util_last_threshold")
                .copied(),
            Some(1024.0)
        );
    }

    #[test]
    fn gradient_health_counts_non_finite_entries() {
        let mut health = GradientHealth::default();
        health.record_values(&[1.0, f32::NAN, f32::INFINITY, f32::NEG_INFINITY, -2.0]);

        let mut extra = HashMap::new();
        health.write_extra(&mut extra);
        assert_eq!(extra.get("grad_values_total").copied(), Some(5.0));
        assert_eq!(extra.get("grad_values_finite").copied(), Some(2.0));
        assert_eq!(extra.get("grad_values_non_finite").copied(), Some(3.0));
        assert_eq!(extra.get("grad_values_nan").copied(), Some(1.0));
        assert_eq!(extra.get("grad_values_infinite").copied(), Some(2.0));
        assert_eq!(extra.get("grad_non_finite_detected").copied(), Some(1.0));
        assert!((extra["grad_values_non_finite_ratio"] - 0.6).abs() < 1e-6);
        assert!((extra["grad_l2_finite"] - 5.0f64.sqrt()).abs() < 1e-6);
        assert_eq!(extra.get("grad_linf_finite").copied(), Some(2.0));
    }

    #[test]
    fn tensor_value_health_counts_non_finite_entries() {
        let tensor = Tensor::from_vec(
            1,
            5,
            vec![1.0, f32::NAN, f32::INFINITY, f32::NEG_INFINITY, -2.0],
        )
        .unwrap();
        let health = TensorValueHealth::from_tensor(&tensor);

        let mut extra = HashMap::new();
        health.write_extra(&mut extra, "sample_tensor");
        assert_eq!(extra.get("sample_tensor_values_total").copied(), Some(5.0));
        assert_eq!(extra.get("sample_tensor_finite_values").copied(), Some(2.0));
        assert_eq!(
            extra.get("sample_tensor_non_finite_values").copied(),
            Some(3.0)
        );
        assert_eq!(extra.get("sample_tensor_nan_values").copied(), Some(1.0));
        assert_eq!(
            extra.get("sample_tensor_infinite_values").copied(),
            Some(2.0)
        );
        assert_eq!(
            extra.get("sample_tensor_non_finite_detected").copied(),
            Some(1.0)
        );
        assert!((extra["sample_tensor_non_finite_ratio"] - 0.6).abs() < 1e-6);
        assert!((extra["sample_tensor_l2_finite"] - 5.0f64.sqrt()).abs() < 1e-6);
        assert_eq!(extra.get("sample_tensor_linf_finite").copied(), Some(2.0));
    }

    #[test]
    fn coherence_signal_trace_writes_trainer_extra_metrics() {
        let mut signal = coherence_signal_for_weights(vec![0.5, 0.2, 0.2, 0.1], 0.5, 0.1);
        signal.repaired_non_finite_weights = 2;
        signal.repaired_negative_weights = 1;
        signal.pre_discard_repaired_non_finite = 3;
        signal.pre_discard_repaired_negative = 4;

        let mut extra = HashMap::new();
        write_coherence_signal_extra(Some(&signal), &mut extra);

        assert_eq!(
            extra.get("coherence_repaired_non_finite_weights").copied(),
            Some(2.0)
        );
        assert_eq!(
            extra.get("coherence_repaired_negative_weights").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra.get("coherence_repaired_weights_total").copied(),
            Some(3.0)
        );
        assert_eq!(
            extra
                .get("coherence_pre_discard_repaired_non_finite")
                .copied(),
            Some(3.0)
        );
        assert_eq!(
            extra
                .get("coherence_pre_discard_repaired_negative")
                .copied(),
            Some(4.0)
        );
        assert_eq!(
            extra.get("coherence_pre_discard_repairs_total").copied(),
            Some(7.0)
        );
        assert_eq!(extra.get("coherence_repairs_total").copied(), Some(10.0));
        assert_eq!(extra.get("coherence_repaired_detected").copied(), Some(1.0));
        assert_eq!(extra.get("coherence_control_ready").copied(), Some(1.0));
        assert_eq!(
            extra.get("coherence_distribution_channels").copied(),
            Some(4.0)
        );
        assert_eq!(
            extra.get("coherence_control_contract_v1").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra.get("coherence_control_backend_rust").copied(),
            Some(1.0)
        );
        assert!((0.0..=1.0).contains(&extra["coherence_normalized_entropy"]));
        assert!((0.0..=1.0).contains(&extra["coherence_concentration"]));
    }

    #[test]
    fn tensor_backend_trace_records_f64_precision_cpu_backend() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "concept_diffusion_state_normalise",
            data: serde_json::json!({
                "backend": "f64_cpu",
                "requested_backend": "auto",
                "precision_backend": "f64_cpu",
                "state_sum_backend": "f64_cpu",
            }),
        });

        let mut epoch = EpochTensorBackendStats::default();
        epoch.accumulate_trace(&trace);
        assert_eq!(epoch.ops_total, 1);
        assert_eq!(epoch.backend_f64_cpu, 1);
        assert_eq!(epoch.backend_other, 0);

        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(extra.get("tensor_backend_f64_cpu").copied(), Some(1.0));
        assert_eq!(
            extra
                .get("tensor_op_backend_concept_diffusion_state_normalise_f64_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_concept_diffusion_state_normalise_precision_f64_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_concept_diffusion_state_normalise_state_sum_f64_cpu")
                .copied(),
            Some(1.0)
        );
    }

    #[test]
    fn tensor_backend_trace_normalizes_kernel_backend_labels() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "layer_norm",
            data: serde_json::json!({
                "backend": "wgpu_dense",
                "requested_backend": "auto",
            }),
        });

        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect("wgpu_dense should satisfy strict WGPU expectation");
        let mut epoch = EpochTensorBackendStats::default();
        epoch.accumulate_trace(&trace);
        assert_eq!(epoch.backend_wgpu, 1);
        assert_eq!(epoch.kernel_backend_wgpu_dense, 1);
        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(extra.get("tensor_backend_wgpu").copied(), Some(1.0));
        assert_eq!(
            extra.get("tensor_kernel_backend_wgpu_dense").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra.get("tensor_op_backend_layer_norm_wgpu").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_kernel_backend_layer_norm_wgpu_dense")
                .copied(),
            Some(1.0)
        );
    }

    #[test]
    fn strict_backend_trace_ignores_metadata_only_backends_when_kernel_matches() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "matmul",
            data: serde_json::json!({
                "backend": "wgpu",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "graph_readout",
            data: serde_json::json!({
                "backend": "composite",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "reshape",
            data: serde_json::json!({
                "backend": "view",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "tensor_biome_canopy",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
            }),
        });

        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect("metadata-only composite/view events should not fail strict WGPU");
        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(extra.get("tensor_backend_wgpu").copied(), Some(1.0));
        assert_eq!(extra.get("tensor_backend_composite").copied(), Some(1.0));
        assert_eq!(extra.get("tensor_backend_hybrid").copied(), Some(1.0));
        assert_eq!(extra.get("tensor_backend_view").copied(), Some(1.0));
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(0.0));
    }

    #[test]
    fn strict_backend_trace_counts_hybrid_normalization_cpu_as_fallback() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "hadamard",
            data: serde_json::json!({
                "backend": "wgpu_dense",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "layer_norm_backward",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "input_gradient_backend": "hybrid",
                "input_gradient_reduction_backend": "wgpu",
                "normalization_backend": "cpu",
            }),
        });

        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect("hybrid metadata has WGPU kernel evidence from the affine reducer");
        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra
                .get("tensor_op_backend_layer_norm_backward_input_gradient_hybrid")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_layer_norm_backward_input_gradient_reduction_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_layer_norm_backward_normalization_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(1.0));
    }

    #[test]
    fn strict_backend_trace_counts_lstm_recurrent_cpu_sub_backends_as_fallbacks() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "matmul",
            data: serde_json::json!({
                "backend": "wgpu",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "lstm_forward",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "input_projection_backend": "wgpu",
                "bias_backend": "wgpu",
                "recurrent_backend": "wgpu",
                "gate_activation_backend": "cpu",
                "estimated_gate_activation_ops": 64,
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "lstm_backward",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "recurrent_backend": "wgpu",
                "gate_activation_backend": "cpu",
                "bptt_backend": "cpu",
                "bptt_scan_backend": "cpu",
                "bptt_gate_derivative_backend": "cpu",
                "bptt_cell_recurrence_backend": "cpu",
                "bptt_state_carry_backend": "cpu",
                "input_gradient_backend": "wgpu",
                "raw_parameter_gradient_backend": "hybrid",
                "parameter_gradient_reduction_backend": "wgpu",
                "bias_gradient_backend": "wgpu",
                "parameter_gradient_scale_backend": "wgpu",
                "estimated_gate_activation_ops": 64,
                "estimated_bptt_ops": 112,
                "estimated_bptt_gate_derivative_ops": 96,
                "estimated_bptt_cell_recurrence_ops": 32,
                "estimated_bptt_state_carry_ops": 16,
                "estimated_bptt_scan_steps": 4,
            }),
        });

        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect("hybrid LSTM metadata has WGPU projection/scaling evidence");
        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra
                .get("tensor_op_backend_lstm_forward_recurrent_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_lstm_forward_gate_activation_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_lstm_backward_bptt_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_lstm_backward_bptt_scan_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_lstm_backward_bptt_gate_derivative_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_lstm_backward_bptt_cell_recurrence_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_lstm_backward_bptt_state_carry_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_lstm_backward_input_gradient_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_lstm_backward_parameter_gradient_reduction_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_lstm_backward_bias_gradient_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("lstm_forward_estimated_gate_activation_ops")
                .copied(),
            Some(64.0)
        );
        assert_eq!(
            extra
                .get("lstm_backward_estimated_gate_activation_ops")
                .copied(),
            Some(64.0)
        );
        assert_eq!(
            extra
                .get("lstm_forward_estimated_gate_activation_wgpu_ops")
                .copied(),
            Some(0.0)
        );
        assert_eq!(
            extra
                .get("lstm_backward_estimated_gate_activation_wgpu_ops")
                .copied(),
            Some(0.0)
        );
        assert_eq!(
            extra.get("lstm_backward_estimated_bptt_ops").copied(),
            Some(112.0)
        );
        assert_eq!(
            extra
                .get("lstm_backward_estimated_bptt_gate_derivative_ops")
                .copied(),
            Some(96.0)
        );
        assert_eq!(
            extra
                .get("lstm_backward_estimated_bptt_cell_recurrence_ops")
                .copied(),
            Some(32.0)
        );
        assert_eq!(
            extra
                .get("lstm_backward_estimated_bptt_state_carry_ops")
                .copied(),
            Some(16.0)
        );
        assert_eq!(
            extra
                .get("lstm_backward_estimated_bptt_scan_steps")
                .copied(),
            Some(4.0)
        );
        assert_eq!(
            extra.get("lstm_estimated_gate_activation_ops").copied(),
            Some(128.0)
        );
        assert_eq!(
            extra
                .get("lstm_estimated_gate_activation_cpu_debt_ops")
                .copied(),
            Some(128.0)
        );
        assert_eq!(
            extra
                .get("lstm_estimated_gate_activation_wgpu_ops")
                .copied(),
            Some(0.0)
        );
        assert_eq!(
            extra.get("lstm_estimated_cpu_debt_ops").copied(),
            Some(240.0)
        );
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(6.0));
    }

    #[test]
    fn strict_backend_trace_counts_lstm_wgpu_gate_activation_ops_as_resolved() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "lstm_forward",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "input_projection_backend": "wgpu",
                "bias_backend": "wgpu",
                "recurrent_backend": "wgpu",
                "gate_activation_backend": "wgpu",
                "estimated_gate_activation_ops": 64,
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "lstm_backward",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "recurrent_backend": "wgpu",
                "gate_activation_backend": "wgpu",
                "bptt_backend": "wgpu",
                "bptt_scan_backend": "wgpu",
                "bptt_gate_derivative_backend": "wgpu",
                "bptt_cell_recurrence_backend": "wgpu",
                "bptt_state_carry_backend": "wgpu",
                "input_gradient_backend": "wgpu",
                "raw_parameter_gradient_backend": "hybrid",
                "parameter_gradient_reduction_backend": "wgpu",
                "bias_gradient_backend": "wgpu",
                "parameter_gradient_scale_backend": "wgpu",
                "estimated_gate_activation_ops": 64,
                "estimated_bptt_ops": 112,
                "estimated_bptt_wgpu_ops": 112,
            }),
        });

        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra
                .get("lstm_forward_estimated_gate_activation_wgpu_ops")
                .copied(),
            Some(64.0)
        );
        assert_eq!(
            extra
                .get("lstm_backward_estimated_gate_activation_wgpu_ops")
                .copied(),
            Some(64.0)
        );
        assert_eq!(
            extra
                .get("lstm_estimated_gate_activation_wgpu_ops")
                .copied(),
            Some(128.0)
        );
        assert_eq!(
            extra
                .get("lstm_estimated_gate_activation_cpu_debt_ops")
                .copied(),
            Some(0.0)
        );
        assert_eq!(
            extra.get("lstm_estimated_bptt_wgpu_ops").copied(),
            Some(112.0)
        );
        assert_eq!(extra.get("lstm_estimated_cpu_debt_ops").copied(), Some(0.0));
    }

    #[test]
    fn strict_backend_trace_counts_zrba_cpu_eigen_sub_backends_as_fallbacks() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "sum_axis0_scaled",
            data: serde_json::json!({
                "backend": "wgpu_dense",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "zrba_cov_head_forward",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "reduction_backend": "wgpu",
                "covariance_centering_backend": "cpu",
                "covariance_accumulation_backend": "wgpu",
                "low_rank_projection_backend": "cpu_eigen",
                "psd_projection_backend": "cpu_eigen",
            }),
        });

        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect("Z-RBA covariance reductions provide WGPU evidence");
        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra
                .get("tensor_op_backend_zrba_cov_head_forward_covariance_centering_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zrba_cov_head_forward_covariance_accumulation_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zrba_cov_head_forward_low_rank_projection_cpu_eigen")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zrba_cov_head_forward_psd_projection_cpu_eigen")
                .copied(),
            Some(1.0)
        );
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(3.0));
    }

    #[test]
    fn strict_backend_trace_counts_topos_rewrite_sub_backend_as_fallback() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "add_scaled",
            data: serde_json::json!({
                "backend": "wgpu_dense",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "tensor_biome_canopy",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "accumulation_backend": "wgpu",
                "normalise_backend": "wgpu",
                "rewrite_backend": "topos_cpu",
            }),
        });

        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect("biome canopy tensor utility work provides WGPU evidence");
        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra
                .get("tensor_op_backend_tensor_biome_canopy_rewrite_topos_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(1.0));
    }

    #[test]
    fn strict_backend_trace_counts_desire_probability_sub_backends_as_wgpu() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "scale",
            data: serde_json::json!({
                "backend": "wgpu_dense",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "desire_softmax",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "softmax_backend": "wgpu",
                "exp_backend": "wgpu",
                "distribution_scale_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "desire_normalise",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "sanitize_backend": "wgpu",
                "distribution_scale_backend": "wgpu",
            }),
        });

        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect("Desire probability normalisation provides WGPU scale evidence");
        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra
                .get("tensor_op_backend_desire_softmax_softmax_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_desire_softmax_exp_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_desire_softmax_distribution_scale_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_desire_normalise_sanitize_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_desire_normalise_distribution_scale_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(0.0));
    }

    #[test]
    fn strict_backend_trace_counts_semantic_tensor_util_sub_backends_as_wgpu() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "scale",
            data: serde_json::json!({
                "backend": "wgpu_dense",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "zspace_semantic_window",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "window_energy_backend": "wgpu",
                "distribution_scale_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "zspace_semantic_distribution_fusion",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "fusion_accumulation_backend": "wgpu",
                "distribution_scale_backend": "wgpu",
            }),
        });

        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect("semantic distribution scaling provides WGPU scale evidence");
        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra
                .get("tensor_op_backend_zspace_semantic_window_window_energy_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zspace_semantic_window_distribution_scale_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zspace_semantic_distribution_fusion_fusion_accumulation_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get(
                    "tensor_op_backend_zspace_semantic_distribution_fusion_distribution_scale_wgpu"
                )
                .copied(),
            Some(1.0)
        );
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(0.0));
    }

    #[test]
    fn strict_backend_trace_counts_zspace_layer_component_backends() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "mul_row",
            data: serde_json::json!({
                "backend": "wgpu_dense",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "zspace_mixer_forward",
            data: serde_json::json!({
                "backend": "composite",
                "requested_backend": "wgpu",
                "broadcast_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "zspace_mixer_backward",
            data: serde_json::json!({
                "backend": "composite",
                "requested_backend": "wgpu",
                "broadcast_backend": "wgpu",
                "gradient_reduction_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "zspace_projector_forward",
            data: serde_json::json!({
                "backend": "composite",
                "requested_backend": "wgpu",
                "rewrite_backend": "cpu",
                "projection_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "zspace_projector_backward",
            data: serde_json::json!({
                "backend": "cpu",
                "requested_backend": "wgpu",
                "projection_backend": "cpu",
                "projection_gradient_backend": "cpu",
                "saturation_gradient_backend": "cpu",
            }),
        });

        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect_err("CPU projector backward is still strict-GPU debt");
        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra
                .get("tensor_op_backend_zspace_mixer_forward_broadcast_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zspace_mixer_backward_broadcast_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zspace_mixer_backward_gradient_reduction_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zspace_projector_forward_rewrite_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zspace_projector_forward_projection_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zspace_projector_backward_projection_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zspace_projector_backward_projection_gradient_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_zspace_projector_backward_saturation_gradient_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(5.0));
    }

    #[test]
    fn strict_backend_trace_counts_activation_runtime_component_backends() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "scale",
            data: serde_json::json!({
                "backend": "wgpu_dense",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "non_liner_forward",
            data: serde_json::json!({
                "backend": "composite",
                "requested_backend": "wgpu",
                "preactivation_backend": "wgpu",
                "activation_backend": "cpu",
                "geometry_backend": "cpu",
                "broadcast_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "dropout_forward",
            data: serde_json::json!({
                "backend": "composite",
                "requested_backend": "wgpu",
                "mask_backend": "wgpu",
                "rng_backend": "cpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "dynamic_field_stochastic_schrodinger_forward",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "deterministic_backend": "wgpu",
                "rng_backend": "cpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "dynamic_field_stochastic_schrodinger_backward",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "input_gradient_backend": "wgpu",
                "gradient_reduction_backend": "wgpu",
                "gradient_scale_backend": "cpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "wave_scan_stack_forward",
            data: serde_json::json!({
                "backend": "composite",
                "requested_backend": "wgpu",
                "merge_backend": "cpu",
            }),
        });

        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect("runtime component metadata has WGPU kernel evidence");
        let mut epoch = EpochTensorBackendStats::default();
        epoch.accumulate_trace(&trace);
        assert_eq!(epoch.requested_wgpu_component_hits, 6);
        assert_eq!(epoch.requested_wgpu_component_fallbacks, 4);
        assert_eq!(epoch.requested_wgpu_component_total(), 10);
        assert_eq!(epoch.requested_wgpu_component_hit_rate(), Some(0.6));
        assert_eq!(epoch.requested_wgpu_component_fallback_rate(), Some(0.4));
        let mut epoch_extra = HashMap::new();
        epoch.write_extra(&mut epoch_extra);
        assert_eq!(
            epoch_extra
                .get("epoch_tensor_backend_requested_wgpu_component_hits")
                .copied(),
            Some(6.0)
        );
        assert_eq!(
            epoch_extra
                .get("epoch_tensor_backend_requested_wgpu_component_fallbacks")
                .copied(),
            Some(4.0)
        );
        assert_eq!(
            epoch_extra
                .get("epoch_tensor_backend_requested_wgpu_component_hit_rate")
                .copied(),
            Some(0.6)
        );
        assert_eq!(
            epoch_extra
                .get("epoch_tensor_backend_requested_wgpu_component_fallback_rate")
                .copied(),
            Some(0.4)
        );

        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra
                .get("tensor_backend_requested_wgpu_component_hits")
                .copied(),
            Some(6.0)
        );
        assert_eq!(
            extra
                .get("tensor_backend_requested_wgpu_component_fallbacks")
                .copied(),
            Some(4.0)
        );
        assert_eq!(
            extra
                .get("tensor_backend_requested_wgpu_component_hit_rate")
                .copied(),
            Some(0.6)
        );
        assert_eq!(
            extra
                .get("tensor_backend_requested_wgpu_component_fallback_rate")
                .copied(),
            Some(0.4)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_non_liner_forward_preactivation_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get(
                    "tensor_op_backend_requested_wgpu_component_hit_non_liner_forward_preactivation_wgpu"
                )
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_non_liner_forward_activation_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get(
                    "tensor_op_backend_requested_wgpu_component_fallback_non_liner_forward_activation_cpu"
                )
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_non_liner_forward_geometry_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get(
                    "tensor_op_backend_requested_wgpu_component_fallback_non_liner_forward_geometry_cpu"
                )
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_dropout_forward_mask_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_requested_wgpu_component_hit_dropout_forward_mask_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_dropout_forward_rng_cpu")
                .copied(),
            Some(1.0)
        );
        assert!(extra
            .get("tensor_op_backend_requested_wgpu_component_fallback_dropout_forward_rng_cpu")
            .is_none());
        assert_eq!(
            extra
                .get("tensor_op_backend_dynamic_field_stochastic_schrodinger_forward_deterministic_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get(
                    "tensor_op_backend_requested_wgpu_component_hit_dynamic_field_stochastic_schrodinger_forward_deterministic_wgpu"
                )
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_dynamic_field_stochastic_schrodinger_forward_rng_cpu")
                .copied(),
            Some(1.0)
        );
        assert!(
            extra
                .get(
                    "tensor_op_backend_requested_wgpu_component_fallback_dynamic_field_stochastic_schrodinger_forward_rng_cpu"
                )
                .is_none()
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_dynamic_field_stochastic_schrodinger_backward_gradient_scale_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get(
                    "tensor_op_backend_requested_wgpu_component_fallback_dynamic_field_stochastic_schrodinger_backward_gradient_scale_cpu"
                )
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_wave_scan_stack_forward_merge_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get(
                    "tensor_op_backend_requested_wgpu_component_fallback_wave_scan_stack_forward_merge_cpu"
                )
                .copied(),
            Some(1.0)
        );
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(4.0));
    }

    #[test]
    fn tensor_backend_trace_counts_requested_wgpu_runtime_fallbacks() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "matmul",
            data: serde_json::json!({
                "backend": "naive",
                "requested_backend": "wgpu",
                "fallback": {
                    "from": "wgpu",
                    "reason": "runtime_unavailable",
                },
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "matmul_prepacked_bias",
            data: serde_json::json!({
                "backend": "wgpu",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "sum_abs",
            data: serde_json::json!({
                "backend": "cpu",
                "requested_backend": "wgpu",
            }),
        });

        let mut epoch = EpochTensorBackendStats::default();
        epoch.accumulate_trace(&trace);
        assert_eq!(epoch.requested_wgpu_hits, 1);
        assert_eq!(epoch.requested_wgpu_runtime_fallbacks, 1);
        assert_eq!(epoch.requested_wgpu_total(), 2);
        assert_eq!(epoch.requested_wgpu_hit_rate(), Some(0.5));
        assert_eq!(epoch.requested_wgpu_runtime_fallback_rate(), Some(0.5));
        let mut epoch_extra = HashMap::new();
        epoch.write_extra(&mut epoch_extra);
        assert_eq!(
            epoch_extra
                .get("epoch_tensor_backend_requested_wgpu_hits")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            epoch_extra
                .get("epoch_tensor_backend_requested_wgpu_runtime_fallbacks")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            epoch_extra
                .get("epoch_tensor_backend_requested_wgpu_hit_rate")
                .copied(),
            Some(0.5)
        );
        assert_eq!(
            epoch_extra
                .get("epoch_tensor_backend_requested_wgpu_runtime_fallback_rate")
                .copied(),
            Some(0.5)
        );

        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra.get("tensor_backend_requested_wgpu_hits").copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_backend_requested_wgpu_runtime_fallbacks")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra.get("tensor_backend_requested_wgpu_hit_rate").copied(),
            Some(0.5)
        );
        assert_eq!(
            extra
                .get("tensor_backend_requested_wgpu_runtime_fallback_rate")
                .copied(),
            Some(0.5)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_requested_wgpu_hit_matmul_prepacked_bias_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_wgpu_runtime_fallback_matmul_naive")
                .copied(),
            Some(1.0)
        );
        assert!(extra
            .get("tensor_op_backend_wgpu_runtime_fallback_sum_abs_cpu")
            .is_none());
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(2.0));
    }

    #[test]
    fn strict_backend_trace_counts_language_semantic_mixed_sub_backends() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "scale",
            data: serde_json::json!({
                "backend": "wgpu_dense",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "semantic_bridge_window_distribution",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "semantic_sparse_scan_backend": "semantic_cpu",
                "semantic_accumulation_backend": "wgpu",
                "distribution_scale_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "concept_hint_distribution",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "semantic_inference_backend": "semantic_bridge_window_distribution",
                "semantic_sparse_scan_backend": "semantic_cpu",
                "semantic_sanitize_backend": "wgpu",
                "distribution_scale_backend": "wgpu",
            }),
        });
        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect("language semantic distribution scaling provides WGPU evidence");
        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra
                .get("tensor_op_backend_semantic_bridge_window_distribution_semantic_sparse_scan_semantic_cpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_semantic_bridge_window_distribution_semantic_accumulation_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get(
                    "tensor_op_backend_semantic_bridge_window_distribution_distribution_scale_wgpu"
                )
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get(
                    "tensor_op_backend_concept_hint_distribution_semantic_sparse_scan_semantic_cpu"
                )
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_concept_hint_distribution_semantic_inference_semantic_bridge_window_distribution")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_concept_hint_distribution_semantic_sanitize_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(2.0));
    }

    #[test]
    fn strict_backend_trace_counts_language_probability_sum_sub_backends_as_wgpu() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "scale",
            data: serde_json::json!({
                "backend": "wgpu_dense",
                "requested_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "desire_automation_vector_normalise",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "sanitize_backend": "wgpu",
                "distribution_scale_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "gw_marginal_normalise",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "marginal_sum_backend": "wgpu",
                "distribution_scale_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "gw_marginal_normalise_in_place",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "marginal_sum_backend": "wgpu",
                "distribution_scale_backend": "wgpu",
            }),
        });
        trace.record(&TensorOpMetaEvent {
            op_name: "sparse_kernel_probability_row",
            data: serde_json::json!({
                "backend": "hybrid",
                "requested_backend": "wgpu",
                "row_sum_backend": "wgpu",
                "distribution_scale_backend": "wgpu",
            }),
        });

        trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect("language probability distribution scaling provides WGPU evidence");
        let mut extra = HashMap::new();
        trace.write_extra(&mut extra);
        assert_eq!(
            extra
                .get("tensor_op_backend_desire_automation_vector_normalise_sanitize_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_desire_automation_vector_normalise_distribution_scale_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_gw_marginal_normalise_marginal_sum_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_gw_marginal_normalise_in_place_marginal_sum_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(
            extra
                .get("tensor_op_backend_sparse_kernel_probability_row_row_sum_wgpu")
                .copied(),
            Some(1.0)
        );
        assert_eq!(extra.get("tensor_backend_fallbacks").copied(), Some(0.0));
    }

    #[test]
    fn strict_backend_trace_rejects_metadata_only_without_kernel_evidence() {
        let mut trace = TensorBackendStepTrace::default();
        trace.record(&TensorOpMetaEvent {
            op_name: "coherence_wave_forward",
            data: serde_json::json!({
                "backend": "composite",
                "requested_backend": "wgpu",
            }),
        });

        let err = trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect_err("metadata-only events are not tensor kernel evidence");
        match err {
            TensorError::BackendFailure { backend, message } => {
                assert_eq!(backend, "wgpu");
                assert!(
                    message.contains("no tensor kernel backend metadata"),
                    "unexpected strict GPU message: {message}"
                );
            }
            other => panic!("unexpected error: {other:?}"),
        }
    }

    #[test]
    fn tensor_backend_trace_rejects_missing_metadata_under_strict_gpu() {
        let trace = TensorBackendStepTrace::default();
        let err = trace
            .validate_expected_backend(BackendKind::Wgpu)
            .expect_err("strict GPU needs tensor backend evidence");

        match err {
            TensorError::BackendFailure { backend, message } => {
                assert_eq!(backend, "wgpu");
                assert!(message.contains("no tensor kernel backend metadata"));
            }
            other => panic!("unexpected error: {other:?}"),
        }
    }

    #[cfg(feature = "wgpu")]
    #[test]
    fn strict_gpu_trainer_keeps_small_tensor_routes_on_wgpu() {
        let caps = DeviceCaps::wgpu(32, true, 256);
        let execution_config = ExecutionConfig::new(AcceleratorFallback::Forbid, 1024);
        let mut trainer =
            ModuleTrainer::new_with_execution_config(caps, execution_config, -1.0, 0.05, 0.01);
        let mut model = Linear::new("strict_linear", 2, 1).unwrap();
        trainer.prepare(&mut model).unwrap();
        let before = model.weight().value().clone();
        let schedule = trainer.roundtable(2, 1, RoundtableConfig::default());
        let dataset = vec![(
            Tensor::from_vec(2, 2, vec![0.5, -1.0, 1.5, 0.25]).unwrap(),
            Tensor::from_vec(2, 1, vec![0.1, -0.2]).unwrap(),
        )];
        let mut loss = MeanSquaredError::new();
        let stats = trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .expect("strict GPU trainer should keep thresholded operations on WGPU");

        assert_eq!(stats.batches, 1);
        assert_eq!(stats.tensor_backend.fallbacks, 0);
        assert_eq!(stats.tensor_backend.backend_cpu, 0);
        assert_eq!(
            stats.tensor_backend.backend_wgpu,
            stats.tensor_backend.ops_total
        );
        assert_ne!(*model.weight().value(), before);
    }

    #[test]
    fn curvature_scheduler_adjusts_curvature_and_records_metrics() {
        let caps = DeviceCaps::wgpu(8, true, 64);
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.1, 0.01);
        let scheduler = CurvatureScheduler::new(-1.0, -2.0, -0.2, 0.01)
            .with_step(0.2)
            .with_tolerance(0.0)
            .with_smoothing(1.0);
        trainer.enable_curvature_scheduler(scheduler);
        let mut module = FixedGradientModule::new(4.0);
        trainer.prepare(&mut module).unwrap();
        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let input = Tensor::from_vec(1, 1, vec![1.0]).unwrap();
        let target = Tensor::from_vec(1, 1, vec![0.0]).unwrap();
        let dataset = vec![
            (input.clone(), target.clone()),
            (input.clone(), target.clone()),
            (input, target),
        ];
        let mut loss = MeanSquaredError::new();
        trainer
            .train_epoch(&mut module, &mut loss, dataset, &schedule)
            .unwrap();
        assert!(trainer.curvature() != -1.0);
        let metrics = trainer
            .curvature_metrics()
            .expect("curvature metrics recorded");
        assert!(metrics.raw_pressure > 0.0);
        assert_eq!(metrics.curvature, trainer.curvature());
    }

    #[test]
    fn curvature_scheduler_caps_huge_pressure_without_poisoning_state() {
        let mut scheduler = CurvatureScheduler::new(-1.0, -2.0, -0.2, 0.01)
            .with_step(0.2)
            .with_smoothing(1.0);

        let decision = scheduler.observe_pressure(f32::MAX);

        assert!(decision.raw_pressure.is_finite());
        assert!(decision.raw_pressure <= TRAINER_CURVATURE_PRESSURE_MAX);
        assert!(decision.smoothed_pressure.is_finite());
        assert!(scheduler.current().is_finite());
        assert!(scheduler.last_pressure().unwrap().is_finite());
        assert!(scheduler.last_pressure_variance().unwrap().is_finite());
        assert!(scheduler.last_pressure_rel_variance().unwrap().is_finite());
    }

    #[test]
    fn curvature_scheduler_rejects_non_finite_pressure_targets() {
        let mut scheduler = CurvatureScheduler::new(-1.0, -2.0, -0.2, f32::INFINITY);
        assert_eq!(scheduler.target_pressure(), 0.0);

        scheduler.set_target_pressure(0.75);
        scheduler.set_target_pressure(f32::NAN);
        assert_eq!(scheduler.target_pressure(), 0.75);

        scheduler.set_target_pressure(f32::MAX);
        assert_eq!(scheduler.target_pressure(), TRAINER_CURVATURE_PRESSURE_MAX);
    }

    #[test]
    fn trainer_consumes_desire_bridge_summary() {
        let caps = DeviceCaps::wgpu(32, true, 256);
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = Sequential::new();
        model.push(Linear::new("lin", 2, 1).unwrap());
        trainer.prepare(&mut model).unwrap();

        let automation = build_language_automation();
        let bridge = DesireTrainerBridge::new();
        let mut pipeline = DesirePipeline::builder(automation)
            .with_trainer_bridge(&bridge)
            .with_sink(DesireTriggerBuffer::new())
            .build();

        let logits = vec![2.0, 0.4];
        let concept = ConceptHint::Distribution(vec![0.6, 0.4]);
        let start = Instant::now();
        let anchor = SystemTime::now();
        for step in 0..6 {
            let now = start + Duration::from_millis((step * 150) as u64);
            let timestamp = anchor + Duration::from_millis((step * 150) as u64);
            pipeline
                .step_at(&logits, step % 2, &concept, now, timestamp)
                .unwrap();
        }

        assert!(bridge.len() >= 6);
        trainer.enable_desire_pipeline(bridge.clone());

        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let dataset = vec![
            (
                Tensor::from_vec(1, 2, vec![0.0, 1.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![1.0]).unwrap(),
            ),
            (
                Tensor::from_vec(1, 2, vec![1.0, 0.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
            ),
        ];
        let mut loss = MeanSquaredError::new();
        trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .unwrap();

        assert!(bridge.is_empty());
    }

    #[test]
    fn trainer_consumes_roundtable_bridge_summary() {
        let caps = DeviceCaps::wgpu(32, true, 256);
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = Sequential::new();
        model.push(Linear::new("lin", 2, 1).unwrap());
        trainer.prepare(&mut model).unwrap();

        let automation = build_language_automation();
        let bridge = DesireRoundtableBridge::new();
        let mut pipeline = DesirePipeline::builder(automation)
            .with_roundtable_bridge(&bridge)
            .build();

        let logits = vec![2.0, 0.6];
        let concept = ConceptHint::Distribution(vec![0.55, 0.45]);
        let start = Instant::now();
        let anchor = SystemTime::now();
        for step in 0..6 {
            let now = start + Duration::from_millis((step * 90) as u64);
            let timestamp = anchor + Duration::from_millis((step * 90) as u64);
            pipeline
                .step_at(&logits, step % 2, &concept, now, timestamp)
                .unwrap();
        }

        trainer.enable_desire_roundtable_bridge(bridge.clone());

        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let dataset = vec![
            (
                Tensor::from_vec(1, 2, vec![0.0, 1.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![1.0]).unwrap(),
            ),
            (
                Tensor::from_vec(1, 2, vec![1.0, 0.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
            ),
        ];
        let mut loss = MeanSquaredError::new();
        trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .unwrap();

        assert!(bridge.drain_summary().unwrap().is_none());
        let summary = trainer.desire_roundtable_summary();
        assert!(summary.is_some());
    }

    #[test]
    fn trainer_enables_desire_bundle() {
        let caps = DeviceCaps::wgpu(32, true, 256);
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut model = Sequential::new();
        model.push(Linear::new("lin", 2, 1).unwrap());
        trainer.prepare(&mut model).unwrap();

        let automation = build_language_automation();
        let trainer_bridge = DesireTrainerBridge::new();
        let roundtable_bridge = DesireRoundtableBridge::new();
        let bundle = DesireTelemetryBundle::new()
            .with_trainer_bridge(&trainer_bridge)
            .with_roundtable_bridge(&roundtable_bridge);

        let mut pipeline = DesirePipeline::builder(automation)
            .with_telemetry_bundle(&bundle)
            .with_sink(DesireTriggerBuffer::new())
            .build();

        let logits = vec![2.2, 0.5];
        let concept = ConceptHint::Distribution(vec![0.6, 0.4]);
        let start = Instant::now();
        let anchor = SystemTime::now();
        for step in 0..6 {
            let now = start + Duration::from_millis((step * 120) as u64);
            let timestamp = anchor + Duration::from_millis((step * 120) as u64);
            pipeline
                .step_at(&logits, step % 2, &concept, now, timestamp)
                .unwrap();
        }

        trainer.enable_desire_telemetry(&bundle);

        let schedule = trainer.roundtable(1, 1, RoundtableConfig::default());
        let dataset = vec![
            (
                Tensor::from_vec(1, 2, vec![0.0, 1.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![1.0]).unwrap(),
            ),
            (
                Tensor::from_vec(1, 2, vec![1.0, 0.0]).unwrap(),
                Tensor::from_vec(1, 1, vec![0.0]).unwrap(),
            ),
        ];
        let mut loss = MeanSquaredError::new();
        trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .unwrap();

        assert!(trainer_bridge.is_empty());
        assert!(roundtable_bridge.is_empty());
        assert!(trainer.desire_roundtable_summary().is_some());
    }

    #[test]
    fn trainer_emits_gnn_roundtable_signal() {
        let caps = DeviceCaps::wgpu(32, true, 256);
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let adjacency = Tensor::from_vec(2, 2, vec![0.0, 1.0, 1.0, 0.0]).unwrap();
        let context = GraphContext::from_adjacency(adjacency).unwrap();
        let mut builder =
            ZSpaceGraphNetworkBuilder::new(context, NonZeroUsize::new(2).unwrap(), -1.0, 0.05);
        builder.push_layer(
            GraphLayerSpec::new(NonZeroUsize::new(2).unwrap())
                .with_activation(GraphActivation::Relu),
        );
        let mut model = builder.build("gnn_trainer").unwrap();
        trainer.prepare(&mut model).unwrap();

        let bridge = RoundtableGnnBridge::new();
        trainer.enable_gnn_roundtable_bridge(bridge.clone());

        let schedule = trainer.roundtable(2, 2, RoundtableConfig::default());
        let dataset = vec![
            (
                Tensor::from_vec(2, 2, vec![1.0, 0.0, 0.5, -0.5]).unwrap(),
                Tensor::from_vec(2, 2, vec![0.2, -0.1, 0.3, 0.4]).unwrap(),
            ),
            (
                Tensor::from_vec(2, 2, vec![0.0, 1.0, -0.3, 0.8]).unwrap(),
                Tensor::from_vec(2, 2, vec![0.1, 0.0, -0.2, 0.6]).unwrap(),
            ),
        ];
        let mut loss = MeanSquaredError::new();
        trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .unwrap();

        assert!(trainer.gnn_roundtable_signal().is_some());
        let latest = bridge.latest().unwrap();
        assert!(latest.is_some());
        assert!(!bridge.is_empty());
    }

    #[test]
    fn trainer_traces_gnn_band_replays_with_labels() {
        let tracer = Arc::new(Mutex::new(GraphFlowTracer::new()));
        let caps = DeviceCaps::cpu();
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let adjacency = Tensor::from_vec(
            4,
            4,
            vec![
                0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0,
            ],
        )
        .unwrap();
        let context = GraphContext::from_adjacency(adjacency).unwrap();
        let mut builder =
            ZSpaceGraphNetworkBuilder::new(context, NonZeroUsize::new(2).unwrap(), -1.0, 0.05)
                .with_tracer(tracer.clone());
        builder.push_layer(
            GraphLayerSpec::new(NonZeroUsize::new(3).unwrap()).with_aggregation(
                crate::NeighborhoodAggregation::multi_hop_sum(NonZeroUsize::new(2).unwrap())
                    .with_include_self(true)
                    .with_attenuation(0.6),
            ),
        );
        builder.push_layer(
            GraphLayerSpec::new(NonZeroUsize::new(2).unwrap())
                .with_activation(GraphActivation::Relu),
        );
        let mut model = builder.build("gnn_band_trace").unwrap();
        trainer.prepare(&mut model).unwrap();

        let schedule = trainer.roundtable(
            4,
            2,
            RoundtableConfig::default()
                .with_top_k(1)
                .with_mid_k(1)
                .with_bottom_k(1)
                .with_here_tolerance(1e-5),
        );
        let dataset = vec![(
            Tensor::from_vec(4, 2, vec![1.0, 0.25, 0.5, -0.75, -0.5, 1.0, 0.75, -0.25]).unwrap(),
            Tensor::from_vec(4, 2, vec![0.2, -0.1, 0.3, 0.15, -0.15, 0.25, 0.1, -0.2]).unwrap(),
        )];
        let mut loss = MeanSquaredError::new();
        trainer
            .train_epoch(&mut model, &mut loss, dataset, &schedule)
            .unwrap();

        let reports = tracer
            .lock()
            .unwrap_or_else(|poison| poison.into_inner())
            .drain();
        let band_reports: Vec<_> = reports
            .iter()
            .filter_map(|report| {
                report
                    .roundtable
                    .as_ref()
                    .and_then(|trace| trace.band_pass.as_ref().map(|pass| (report, trace, pass)))
            })
            .collect();
        assert_eq!(band_reports.len(), 6);
        let labels: Vec<_> = band_reports
            .iter()
            .map(|(_, _, pass)| pass.band.as_str())
            .collect();
        assert_eq!(labels.iter().filter(|label| **label == "above").count(), 2);
        assert_eq!(labels.iter().filter(|label| **label == "here").count(), 2);
        assert_eq!(
            labels.iter().filter(|label| **label == "beneath").count(),
            2
        );
        assert!(band_reports
            .iter()
            .all(|(_, _, pass)| pass.gradient_l1 > 0.0));
        assert!(band_reports
            .iter()
            .all(|(_, trace, _)| !trace.aggregation.effective_coefficients.is_empty()));
        let mut layer0_coeffs = HashMap::new();
        for (report, trace, pass) in &band_reports {
            if trace.aggregation.effective_coefficients.len() == 3
                && !layer0_coeffs.contains_key(pass.band.as_str())
            {
                layer0_coeffs.insert(
                    pass.band.as_str(),
                    (
                        report.layer.clone(),
                        trace.aggregation.effective_coefficients.clone(),
                    ),
                );
            }
        }
        assert_eq!(layer0_coeffs.len(), 3);
        let above = &layer0_coeffs["above"].1;
        let here = &layer0_coeffs["here"].1;
        let beneath = &layer0_coeffs["beneath"].1;
        assert_ne!(above, here);
        assert_ne!(here, beneath);
        assert_ne!(above, beneath);
    }

    #[cfg(feature = "golden")]
    #[test]
    fn trainer_records_golden_council_snapshot() {
        let caps = DeviceCaps::wgpu(16, true, 128);
        let mut trainer = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
        let mut pulse = GoldenBlackcatPulse::idle();
        pulse.exploration_drive = 0.7;
        let winner = HeurOp {
            origin: "roundtable-1".to_string(),
            kind: HeurOpKind::AppendSoft {
                script: "k:topk(2)".to_string(),
                weight: 1.2,
            },
            issued_at: SystemTime::now(),
        };
        let snapshot = GoldenCouncilSnapshot {
            epoch: 4,
            high_watermark: 9,
            missing_ranges: Vec::new(),
            winners: vec![winner.clone()],
            evidence: CouncilEvidence {
                band_energy: (1.0, 0.8, 0.6),
                graph_flow: 0.4,
                psi: 0.2,
                geometry: (0.5, 0.3, 0.1),
            },
            exploration_bias: 1.2,
            optimization_bias: 0.95,
            synergy_bias: 1.1,
            reinforcement_bias: 1.05,
            resonance: 0.4,
            stability: 0.86,
            momentum: 0.3,
            divergence: 0.2,
            schedule_hint: (1.0, 0.8, 1.1, 0.9),
            pulse_recap: pulse,
        };
        trainer.record_golden_council(&snapshot);
        let stored = trainer
            .last_golden_council_snapshot()
            .expect("snapshot stored");
        assert!((stored.exploration_bias - 1.2).abs() < 1e-4);
        assert_eq!(stored.schedule_hint.2, 1.1);
        assert_eq!(stored.pulse_recap.exploration_drive, 0.7);
        let winners = trainer.last_council().expect("cloneable snapshot").winners;
        assert_eq!(winners.len(), 1);
        match &winners[0].kind {
            HeurOpKind::AppendSoft { weight, .. } => assert!((*weight - 1.2).abs() < 1e-4),
            other => panic!("unexpected winner {:?}", other),
        }
    }
}
