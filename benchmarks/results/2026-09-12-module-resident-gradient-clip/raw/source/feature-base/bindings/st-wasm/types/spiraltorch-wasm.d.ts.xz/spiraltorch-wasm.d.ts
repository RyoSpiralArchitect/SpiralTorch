/**
 * TypeScript declarations for the `spiraltorch-wasm` package.
 *
 * The bindings expose the raw WebAssembly surface implemented in `bindings/st-wasm` so
 * JavaScript and TypeScript callers receive editor completions and compile-time safety.
 *
 * These definitions mirror the wasm-bindgen exports and intentionally keep the naming
 * scheme used by the generated JavaScript glue (snake_case for low-level routines and
 * camelCase when explicitly configured with `js_name`).
 */
declare module "spiraltorch-wasm" {
    /** Original Rust NN Module. Requires webgpu; inputs/outputs stay resident. */
    export class Sequential {
        constructor();
        addLinear(name: string, input_dim: number, output_dim: number): void;
        addScaler(name: string, gain: Float32Array): void;
        addGelu(): void;
        addRelu(): void;
        forward(input: WgpuTensor): WgpuTensor;
        forwardSnapshot(input: WgpuTensor): WgpuTensorSnapshot;
        inferencePlan(shape: number[]): InferencePlan;
        residentCacheInfo(): ResidentForwardStats;
        clearResidentCache(): void;
        free(): void;
    }
    /** Host cache/submission counts, not GPU completion receipts. */
    export class ResidentForwardStats {
        private constructor();
        readonly compilations: bigint;
        readonly cacheHits: bigint;
        readonly submittedForwards: bigint;
        free(): void;
    }
    /** Rust-owned immutable NN parameter plan, available with nn or webgpu. */
    export class InferencePlan {
        private constructor();
        applyParametersTo(module: Sequential, updated: InferencePlan, optimizer_state?: string | null): number;
        static fromJson(payload: string, max_bytes?: number | null): InferencePlan;
        toJson(): string;
        /** New checked Rust plan; parameter IDs stay fixed, stage IDs may change. */
        fusePointwise(): InferencePlan;
        readonly inputShape: Uint32Array;
        readonly outputShape: Uint32Array;
        readonly stageCount: number;
        readonly sourceOperationCount: number;
        readonly isDense: boolean;
        /** Requires webgpu; the plan may be freed while the returned promise runs. */
        compileWebGpu(tile_mnk?: number[] | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentInference>;
        compileGraphWebGpu(tile_mnk?: number[] | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentGraphInference>;
        /** Frozen parameters, exact arbitrary-cotangent VJPs; no loss or optimizer. */
        compileGraphAutogradWebGpu(tile_mnk?: number[] | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentGraphAutograd>;
        /** Custom cotangents and weighted SGD; explicit Rust update policy. */
        compileGraphLearnerWebGpu(gradient_policy: string, tile_mnk?: number[] | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentGraphLearner>;
        /** Mean-MSE, VJP and plain SGD use the same Rust core as native training. */
        compileTrainingWebGpu(tile_mnk?: number[] | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentTraining>;
        /** Explicit Rust policy: "exact" or "module_compatible". Requires webgpu. */
        compileGraphTrainingWebGpu(gradient_policy: string, tile_mnk?: number[] | null, kernel?: string | null, accumulation?: string | null): Promise<ResidentGraphTraining>;
        free(): void;
    }

    /** Immutable N-D GPU storage; available with webgpu, never host Tensor storage. */
    export class WgpuTensorDevice {
        private constructor();
        static create(): Promise<WgpuTensorDevice>;
        upload(shape: number[], data: Float32Array): WgpuTensor;
        adapterInfo(): { name: string; backend: string; device_type: string };
        free(): void;
    }
    export class WgpuPointwiseInputs {
        constructor();
        free(): void;
        readonly length: number;
        add(tensor: WgpuTensor): void;
        set(slot: number, tensor: WgpuTensor): void;
        compile(steps: string): WgpuPointwisePlan;
    }

    export class WgpuPointwisePlan {
        private constructor();
        free(): void;
        run(inputs: WgpuPointwiseInputs, execution: string): WgpuTensor;
    }

    export class WgpuTensor {
        private constructor();
        readonly shape: Uint32Array;
        readonly strides: Uint32Array;
        readonly offset: number;
        readonly numel: number;
        readonly isContiguous: boolean;
        device(): WgpuTensorDevice;
        sharesStorageWith(other: WgpuTensor): boolean;
        reshape(shape: number[]): WgpuTensor;
        permute(axes: number[]): WgpuTensor;
        narrow(axis: number, start: number, length: number): WgpuTensor;
        broadcastTo(shape: number[]): WgpuTensor;
        contiguous(): WgpuTensor;
        add(rhs: WgpuTensor): WgpuTensor;
        mul(rhs: WgpuTensor): WgpuTensor;
        relu(): WgpuTensor;
        gelu(): WgpuTensor;
        snapshot(): WgpuTensorSnapshot;
        free(): void;
    }
    export class WgpuTensorSnapshot {
        private constructor();
        readonly shape: Uint32Array;
        readValues(): Promise<Float32Array>;
        free(): void;
    }
    export class ResidentGraphInference {
        private constructor();
        readonly inputShape: Uint32Array;
        readonly outputShape: Uint32Array;
        readonly stageCount: number;
        readonly parameterCount: number;
        readonly generation: bigint;
        readonly submittedDispatches: bigint;
        adapterInfo(): { name: string; backend: string; device_type: string };
        tensorDevice(): WgpuTensorDevice;
        upload(data: Float32Array): void;
        setInputTensor(input: WgpuTensor): void;
        forwardTensor(input: WgpuTensor): WgpuTensor;
        forwardTensorSnapshot(input: WgpuTensor): WgpuTensorSnapshot;
        dispatch(): bigint;
        outputTensor(): WgpuTensor;
        snapshot(): GraphInferenceSnapshot;
        free(): void;
    }
    export class ResidentGraphAutograd {
        private constructor();
        readonly inputShape: Uint32Array;
        readonly outputShape: Uint32Array;
        readonly stageCount: number;
        readonly parameterCount: number;
        readonly inputGeneration: bigint;
        readonly submittedForwards: bigint;
        readonly submittedBackwards: bigint;
        adapterInfo(): { name: string; backend: string; device_type: string };
        tensorDevice(): WgpuTensorDevice;
        upload(data: Float32Array): void;
        setInputTensor(input: WgpuTensor): void;
        forward(): GraphForward;
        backward(forward: GraphForward, cotangent: WgpuTensor): GraphGradients;
        free(): void;
    }
    export class ResidentGraphLearner {
        private constructor();
        readonly inputShape: Uint32Array;
        readonly outputShape: Uint32Array;
        readonly stageCount: number;
        readonly parameterCount: number;
        readonly gradientPolicy: string;
        readonly inputGeneration: bigint;
        readonly submittedForwards: bigint;
        readonly submittedBackwards: bigint;
        readonly submittedUpdates: bigint;
        adapterInfo(): { name: string; backend: string; device_type: string };
        tensorDevice(): WgpuTensorDevice;
        upload(input: Float32Array): void;
        setInputTensor(input: WgpuTensor): void;
        forward(): GraphForward;
        backward(forward: GraphForward, cotangent: WgpuTensor): GraphGradients;
        /** Attempt number; acceptance requires reading an update snapshot. */
        sgd(gradients: GraphGradients, rate: number): bigint;
        sgdWeighted(batch: GraphGradientBatch, rate: number): bigint;
        gradientAccumulator(): GraphGradientAccumulator;
        zeroAccumulator(accumulator: GraphGradientAccumulator): void;
        accumulate(accumulator: GraphGradientAccumulator, gradients: GraphGradients, weight: number): bigint;
        sgdAccumulated(accumulator: GraphGradientAccumulator, rate: number): bigint;
        parameterSnapshot(): GraphTrainingParametersSnapshot;
        updateSnapshot(): GraphUpdateSnapshot;
        free(): void;
    }
    export class GraphGradientBatch {
        constructor();
        readonly length: number;
        add(gradients: GraphGradients, weight: number): void;
        free(): void;
    }
    export class GraphGradientAccumulator {
        private constructor();
        readonly length: bigint;
        readonly parameterGeneration: bigint;
        parameterGradientTensors(): WgpuTensor[];
        free(): void;
    }
    export class GraphUpdateSnapshot {
        private constructor();
        readonly inputGeneration: bigint;
        readonly submittedForward: bigint;
        readonly submittedUpdate: bigint;
        read(): Promise<bigint>;
        free(): void;
    }
    export class GraphForward {
        private constructor();
        readonly inputGeneration: bigint;
        readonly submittedForward: bigint;
        predictionTensor(): WgpuTensor;
        free(): void;
    }
    export class MeanSquaredError {
        constructor();
        /** Joint whole-loss-guarded value and exact prediction cotangent; no host read. */
        evaluateResident(prediction: WgpuTensor, target: WgpuTensor): ResidentLoss;
        free(): void;
    }
    export class CrossEntropyWithLogits {
        constructor(reduction?: string | null, ignore_index?: bigint | null, label_smoothing?: number | null);
        /** Class-last integer-label loss. None reduction uses an all-ones loss seed. */
        evaluateResident(prediction: WgpuTensor, target: WgpuTensor): ResidentLoss;
        free(): void;
    }
    export class ResidentLoss {
        private constructor();
        lossTensor(): WgpuTensor;
        predictionGradientTensor(): WgpuTensor;
        free(): void;
    }
    export class GraphGradients {
        private constructor();
        readonly inputGeneration: bigint;
        readonly submittedForward: bigint;
        readonly submittedBackward: bigint;
        readonly parameterCount: number;
        inputGradientTensor(): WgpuTensor;
        parameterGradientTensor(index: number): WgpuTensor;
        free(): void;
    }
    export class GraphInferenceSnapshot {
        private constructor();
        readonly shape: Uint32Array;
        readonly generation: bigint;
        readonly submittedDispatch: bigint;
        readValues(): Promise<Float32Array>;
        free(): void;
    }

    export class ResidentGraphTraining {
        private constructor();
        readonly inputShape: Uint32Array;
        readonly outputShape: Uint32Array;
        readonly stageCount: number;
        readonly parameterCount: number;
        readonly gradientPolicy: string;
        readonly submittedSteps: bigint;
        readonly batchGeneration: bigint;
        adapterInfo(): { name: string; backend: string; device_type: string };
        uploadBatch(input: Float32Array, target: Float32Array): void;
        uploadBatchTensors(input: WgpuTensor, target: WgpuTensor): void;
        predictionTensor(): WgpuTensor;
        inputGradientTensor(): WgpuTensor;
        /** Submitted attempt, not acceptance. Read its owning snapshot. */
        step(learning_rate: number): bigint;
        lossSnapshot(): TrainingLossSnapshot;
        stateSnapshot(): GraphTrainingSnapshot;
        parameterSnapshot(): GraphTrainingParametersSnapshot;
        free(): void;
    }

    export class GraphTrainingSnapshot {
        private constructor();
        readonly inputShape: Uint32Array;
        readonly outputShape: Uint32Array;
        readonly submittedStep: bigint;
        readonly batchGeneration: bigint;
        readonly gradientPolicy: string;
        readState(): Promise<GraphTrainingState>;
        free(): void;
    }

    export class GraphTrainingParametersSnapshot {
        private constructor();
        readPlan(): Promise<InferencePlan>;
        free(): void;
    }

    /** Pre-update loss/VJPs, post-update parameters, addressed by stable parameter ID. */
    export class GraphTrainingState {
        private constructor();
        readonly inputShape: Uint32Array;
        readonly outputShape: Uint32Array;
        readonly stageCount: number;
        readonly parameterCount: number;
        readonly gradientPolicy: string;
        readonly submittedStep: bigint;
        readonly batchGeneration: bigint;
        readonly loss: number;
        predictionValues(): Float32Array;
        inputGradientValues(): Float32Array;
        parameterRole(parameter: number): string;
        parameterShape(parameter: number): Uint32Array;
        parameterValues(parameter: number): Float32Array;
        parameterGradientValues(parameter: number): Float32Array;
        effectiveGradientValues(parameter: number): Float32Array;
        /** Weight-only v2 plan, not runtime counters, batch or gradient policy. */
        toPlan(): InferencePlan;
        free(): void;
    }

    export class ResidentTraining {
        private constructor();
        readonly inputShape: Uint32Array;
        readonly outputShape: Uint32Array;
        readonly stageCount: number;
        readonly submittedSteps: bigint;
        readonly batchGeneration: bigint;
        adapterInfo(): { name: string; backend: string; device_type: string };
        uploadBatch(input: Float32Array, target: Float32Array): void;
        /** Submitted attempt, not acceptance. Read its owning snapshot. */
        step(learning_rate: number): bigint;
        lossSnapshot(): TrainingLossSnapshot;
        stateSnapshot(): TrainingSnapshot;
        parameterSnapshot(): TrainingParametersSnapshot;
        free(): void;
    }

    export class TrainingLossSnapshot {
        private constructor();
        readonly submittedStep: bigint;
        readonly batchGeneration: bigint;
        read(): Promise<number>;
        free(): void;
    }

    export class TrainingSnapshot {
        private constructor();
        readonly inputShape: Uint32Array;
        readonly outputShape: Uint32Array;
        readonly submittedStep: bigint;
        readonly batchGeneration: bigint;
        readState(): Promise<TrainingState>;
        free(): void;
    }

    export class TrainingParametersSnapshot {
        private constructor();
        readPlan(): Promise<InferencePlan>;
        free(): void;
    }

    /** Immutable host snapshot: pre-update loss/VJP and post-update parameters. */
    export class TrainingState {
        private constructor();
        readonly inputShape: Uint32Array;
        readonly outputShape: Uint32Array;
        readonly stageCount: number;
        readonly submittedStep: bigint;
        readonly batchGeneration: bigint;
        readonly loss: number;
        predictionValues(): Float32Array;
        inputGradientValues(): Float32Array;
        layerShape(stage: number): Uint32Array;
        weightValues(stage: number): Float32Array;
        biasValues(stage: number): Float32Array;
        weightGradientValues(stage: number): Float32Array;
        biasGradientValues(stage: number): Float32Array;
        toPlan(): InferencePlan;
        free(): void;
    }

    export class ResidentInference {
        private constructor();
        readonly inputShape: Uint32Array;
        readonly outputShape: Uint32Array;
        readonly stageCount: number;
        readonly generation: bigint;
        adapterInfo(): { name: string; backend: string; device_type: string };
        upload(values: Float32Array): void;
        setInputTensor(input: WgpuTensor): void;
        tensorSnapshot(device: WgpuTensorDevice): WgpuTensor;
        dispatch(): bigint;
        snapshot(): InferenceSnapshot;
        free(): void;
    }

    /** Output and validation flags are captured at snapshot request time. */
    export class InferenceSnapshot {
        private constructor();
        readonly shape: Uint32Array;
        readonly generation: bigint;
        readValues(): Promise<Float32Array>;
        free(): void;
    }

    /** Ordered-f64 arithmetic means in WASM linear memory, not GPU storage. */
    export class TensorMeanBatch {
        constructor(rows: number, cols: number, partial_count: number, data: Float32Array);
        /** Finite scale; returns a new row-major Float32Array. */
        meanScaled(scale: number): Float32Array;
        free(): void;
    }

    /** Explicit WebGPU feature; persistent device-local matrix storage. */
    export class WgpuMatmul {
        private constructor();
        static create(rows: number, inner: number, cols: number): Promise<WgpuMatmul>;
        static createWithTile(rows: number, inner: number, cols: number, tile_m: number, tile_n: number, tile_k: number): Promise<WgpuMatmul>;
        static createWithKernel(rows: number, inner: number, cols: number, tile_m: number, tile_n: number, tile_k: number, kernel: string): Promise<WgpuMatmul>;
        static createWithOptions(rows: number, inner: number, cols: number, tile_m: number, tile_n: number, tile_k: number, kernel: string, accumulation: string): Promise<WgpuMatmul>;
        free(): void;
        readonly generation: bigint;
        readonly outputIsCurrent: boolean;
        readonly kernel: string;
        readonly accumulation: string;
        shape(): Uint32Array;
        tileMNK(): Uint32Array;
        workgroupSize(): Uint32Array;
        outputsPerThread(): Uint32Array;
        adapterInfo(): unknown;
        upload(lhs: Float32Array, rhs: Float32Array): void;
        uploadRhs(rhs: Float32Array): void;
        setLhsFrom(source: WgpuMatmul): void;
        dispatch(repetitions?: number | null): bigint;
        synchronize(): Promise<void>;
        readback(): Promise<Float32Array>;
    }

    /** Explicit WebGPU feature; exact two-stage rank, no CPU fallback. */
    export class WgpuRank {
        private constructor();
        static create(kind: "topk" | "midk" | "bottomk", rows: number, cols: number, k: number, tile_cols?: number | null, timestamp_queries?: boolean | null): Promise<WgpuRank>;
        static createFromAdaptation(session: RankAdaptationSession, candidate_index: number, timestamp_queries?: boolean | null): Promise<WgpuRank>;
        free(): void;
        readonly kind: string;
        readonly tileCols: number;
        readonly generation: bigint;
        readonly outputIsCurrent: boolean;
        readonly timestampQueriesEnabled: boolean;
        shape(): Uint32Array;
        adapterInfo(): unknown;
        upload(input: Float32Array): void;
        /** Enqueue a device-local snapshot copy; no host staging or persistent alias. */
        setInputFromMatmul(source: WgpuMatmul): void;
        dispatchFromMatmul(source: WgpuMatmul, repetitions?: number): bigint;
        dispatch(repetitions?: number): bigint;
        /** Opt-in private-device diagnostics; never policy feedback or fast-path timing. */
        profile(repetitions?: number | null): Promise<Record<string, unknown>>;
        synchronize(): Promise<void>;
        readback(): Promise<{values: Float32Array; indices: Int32Array; generation: bigint}>;
    }

    /** Structural receipt from the Rust-owned immutable reverse-mode graph. */
    export type AutogradGraphSummary = {
        contract_version: "spiraltorch.autograd.v1";
        semantic_owner: "st-tensor";
        node_count: number;
        operation_count: number;
        leaf_count: number;
        trainable_leaf_count: number;
        max_depth: number;
    };

    /** Atomic backward-pass receipt emitted by the shared Rust contract. */
    export type AutogradBackwardReport = AutogradGraphSummary & {
        gradient_node_count: number;
        leaf_gradient_count: number;
        seed_l2: number;
    };

    /** Return the reverse-mode contract version compiled into this WASM client. */
    export function autogradContractVersion(): "spiraltorch.autograd.v1";

    /** Return the crate that owns graph and reverse-mode semantics. */
    export function autogradSemanticOwner(): "st-tensor";

    /** Frozen packed source. Repack new optimizer parameters explicitly. */
    export class AutogradPackedRhs {
        private constructor();
        free(): void;
        sourceId(): string;
        rows(): number;
        cols(): number;
        requiresGrad(): boolean;
    }

    /** Thin browser handle over the Rust-owned reverse-mode graph. */
    export class AutogradTensor {
        constructor(rows: number, cols: number, values: Float32Array, requires_grad: boolean);
        id(): string;
        rows(): number;
        cols(): number;
        requiresGrad(): boolean;
        operationName(): string;
        values(): Float32Array;
        hasGradient(): boolean;
        gradientValues(): Float32Array;
        detach(): AutogradTensor;
        zeroGrad(): void;
        zeroGradGraph(): void;
        add(rhs: AutogradTensor): AutogradTensor;
        addRow(bias: AutogradTensor): AutogradTensor;
        relu(): AutogradTensor;
        gelu(): AutogradTensor;
        rowSoftmax(): AutogradTensor;
        rowLogSoftmax(): AutogradTensor;
        crossEntropyWithLogits(labels: Int32Array, reduction?: string | null, ignore_index?: number | null, label_smoothing?: number | null): AutogradTensor;
        sub(rhs: AutogradTensor): AutogradTensor;
        hadamard(rhs: AutogradTensor): AutogradTensor;
        matmul(rhs: AutogradTensor): AutogradTensor;
        prepackRhs(): AutogradPackedRhs;
        matmulPrepacked(rhs: AutogradPackedRhs): AutogradTensor;
        /** Affine gradients sum rows; defaults to epsilon=1e-5. */
        layerNormAffine(gamma: AutogradTensor, beta: AutogradTensor, epsilon?: number | null): AutogradTensor;
        gatherRows(indices: number[] | Uint32Array): AutogradTensor;
        scatterAddRows(indices: number[] | Uint32Array, outputRows: number): AutogradTensor;
        scale(factor: number): AutogradTensor;
        transpose(): AutogradTensor;
        sum(): AutogradTensor;
        mean(): AutogradTensor;
        dot(rhs: AutogradTensor): AutogradTensor;
        meanSquaredError(target: AutogradTensor): AutogradTensor;
        item(): number;
        backward(): AutogradBackwardReport;
        backwardWithGrad(values: Float32Array): AutogradBackwardReport;
        vectorJacobianProduct(input: AutogradTensor, values: Float32Array): Float32Array;
        graphSummary(): AutogradGraphSummary;
    }

    /** Bounds for the Rust-owned trailing periodic-suffix kernel. */
    export type ZSpacePeriodicityConfig = {
        maximum_period?: number;
        minimum_repetitions?: number;
    };

    /** Token sequence and optional proposal analyzed without duplicating Rust semantics. */
    export type ZSpacePeriodicityRequest = {
        token_ids: number[];
        appended_token_id?: number | null;
        config?: ZSpacePeriodicityConfig;
    };

    export type ZSpacePeriodicSuffix = {
        period: number;
        token_count: number;
        repeated_token_count: number;
        repetition_count: number;
    };

    /** Replayable periodicity report computed and validated by `st-core`. */
    export type ZSpacePeriodicityReport = {
        contract_version: "spiraltorch.zspace_periodicity.v1";
        kind: "spiraltorch.zspace_periodicity";
        semantic_owner: "st-core::runtime::zspace_periodicity";
        semantic_backend: "rust";
        analysis_validated: true;
        analysis_id: string;
        status: "ready";
        request: {
            token_ids: number[];
            appended_token_id: number | null;
            config: Required<ZSpacePeriodicityConfig>;
        };
        rule: string;
        analysis_id_rule: string;
        analysis_scope: "observed_sequence" | "observed_sequence_with_appended_token";
        input_token_count: number;
        effective_token_count: number;
        candidate_period_count: number;
        comparison_work_upper_bound: number;
        periodic_loop_detected: boolean;
        periodic_suffix: ZSpacePeriodicSuffix | null;
        periodic_suffix_token_ratio: number | null;
        periodic_suffix_repeated_token_ratio: number | null;
        efficacy_claim_ready: false;
        evidence_boundary: string;
    };

    /** Analyze a JSON request and return the canonical report as JSON. */
    export function zspacePeriodicityJson(requestJson: string): string;

    /** Analyze an object request and return the canonical report. */
    export function zspacePeriodicityObject(
        request: ZSpacePeriodicityRequest,
    ): ZSpacePeriodicityReport;

    /** Recompute a serialized report in Rust and reject any changed field. */
    export function validateZspacePeriodicityJson(reportJson: string): string;

    /** Recompute an object report in Rust and reject any changed field. */
    export function validateZspacePeriodicityObject(
        report: ZSpacePeriodicityReport,
    ): ZSpacePeriodicityReport;

    /** Numerical controls for the Rust-owned real-time stochastic step. */
    export type ZSpaceStochasticSchrodingerConfig = {
        time_step?: number;
        hopping_rate?: number;
        loss_rate?: number;
        noise_scale?: number;
    };

    /** Explicit state, potential, and standard-normal witness for one transition. */
    export type ZSpaceStochasticSchrodingerForwardRequest = {
        input: number[];
        potential: number[];
        standard_normal: number[];
        rows: number;
        features: number;
        config?: ZSpaceStochasticSchrodingerConfig;
    };

    /** Rust-normalized forward request embedded in replayable receipts. */
    export type ZSpaceStochasticSchrodingerCanonicalForwardRequest = Omit<
        ZSpaceStochasticSchrodingerForwardRequest,
        "config"
    > & {
        config: Required<ZSpaceStochasticSchrodingerConfig>;
    };

    export type ZSpaceStochasticSchrodingerAudit = {
        rows: number;
        features: number;
        pair_count: number;
        damping_factor: number;
        ensemble_dephasing_rate: number;
        expected_norm_ratio: number;
        initial_norm_squared: number;
        final_norm_squared: number;
        expected_final_norm_squared: number;
        max_row_norm_error: number;
        max_row_norm_tolerance_ratio: number;
        aggregate_norm_error: number;
        aggregate_norm_tolerance: number;
        max_phase_error: number;
        max_output_error: number;
        max_formula_tolerance_ratio: number;
        phase_rms: number;
        standard_normal_rms: number;
    };

    export type ZSpaceStochasticSchrodingerStep = {
        kind: "spiraltorch.stochastic_real_time_schrodinger";
        contract_version: "spiraltorch.stochastic_real_time_schrodinger.v1";
        semantic_owner: "st-core::dynamics::stochastic_schrodinger";
        semantic_backend: "rust";
        integrator: "strang_diagonal_pair_unitary";
        stochastic_calculus: "stratonovich";
        hamiltonian: string;
        noise_model: "independent_gaussian_phase_diffusion";
        open_system_mode: "uniform_no_jump_loss";
        output_observable: "real_quadrature";
        config: Required<ZSpaceStochasticSchrodingerConfig>;
        output_real: number[];
        output_imaginary: number[];
        phase: number[];
        audit: ZSpaceStochasticSchrodingerAudit;
    };

    /** Content-addressed transition receipt recomputable by every client. */
    export type ZSpaceStochasticSchrodingerForwardReceipt = {
        contract_version: "spiraltorch.zspace_stochastic_schrodinger_forward.v1";
        kind: "spiraltorch.zspace_stochastic_schrodinger_forward";
        semantic_owner: "st-core::dynamics::stochastic_schrodinger";
        semantic_backend: "rust";
        protocol_owner: "st-core::runtime::zspace_stochastic_schrodinger";
        forward_validated: true;
        forward_id: string;
        id_rule: string;
        status: "ready";
        request: ZSpaceStochasticSchrodingerCanonicalForwardRequest;
        step: ZSpaceStochasticSchrodingerStep;
        efficacy_claim_ready: false;
        evidence_boundary: string;
    };

    export type ZSpaceStochasticSchrodingerVjpRequest = {
        forward_request: ZSpaceStochasticSchrodingerForwardRequest;
        grad_output_real: number[];
    };

    /** Rust-normalized VJP request embedded in replayable receipts. */
    export type ZSpaceStochasticSchrodingerCanonicalVjpRequest = Omit<
        ZSpaceStochasticSchrodingerVjpRequest,
        "forward_request"
    > & {
        forward_request: ZSpaceStochasticSchrodingerCanonicalForwardRequest;
    };

    export type ZSpaceStochasticSchrodingerBackward = {
        grad_input: number[];
        grad_potential: number[];
    };

    export type ZSpaceStochasticSchrodingerBackwardAudit = {
        rows: number;
        features: number;
        max_grad_input_error: number;
        max_grad_potential_error: number;
        max_formula_tolerance_ratio: number;
    };

    /** Input/potential VJP of output_real; noise/config are fixed witnesses. */
    export type ZSpaceStochasticSchrodingerVjpReceipt = {
        contract_version: "spiraltorch.zspace_stochastic_schrodinger_vjp.v1";
        kind: "spiraltorch.zspace_stochastic_schrodinger_vjp";
        semantic_owner: "st-core::dynamics::stochastic_schrodinger";
        semantic_backend: "rust";
        protocol_owner: "st-core::runtime::zspace_stochastic_schrodinger";
        vjp_validated: true;
        vjp_id: string;
        forward_id: string;
        id_rule: string;
        status: "ready";
        request: ZSpaceStochasticSchrodingerCanonicalVjpRequest;
        output_observable: "real_quadrature";
        gradient_semantics: string;
        result: ZSpaceStochasticSchrodingerBackward;
        audit: ZSpaceStochasticSchrodingerBackwardAudit;
        efficacy_claim_ready: false;
        evidence_boundary: string;
    };

    /** Run a bounded JSON forward request and return its canonical receipt JSON. */
    export function zspaceStochasticSchrodingerForwardJson(
        requestJson: string,
    ): string;

    /** Recompute a forward receipt in Rust and reject any changed field. */
    export function validateZspaceStochasticSchrodingerForwardJson(
        receiptJson: string,
    ): string;

    /** Run a bounded JSON VJP request and return its canonical receipt JSON. */
    export function zspaceStochasticSchrodingerVjpJson(
        requestJson: string,
    ): string;

    /** Recompute a VJP receipt in Rust and reject any changed field. */
    export function validateZspaceStochasticSchrodingerVjpJson(
        receiptJson: string,
    ): string;

    /** Both quadratures are mandatory; omit cotangent for forward-only evolution. */
    export type ZSpaceSchrodingerComplexRequest = {
        forward_request: ZSpaceStochasticSchrodingerForwardRequest;
        input_imaginary: number[];
        cotangent?: { real: number[]; imaginary: number[] } | null;
    };

    export type ZSpaceSchrodingerComplexReceipt = {
        contract_version: "spiraltorch.zspace_stochastic_schrodinger_complex_step.v1";
        kind: "spiraltorch.zspace_stochastic_schrodinger_complex_step";
        semantic_owner: "st-core::dynamics::stochastic_schrodinger";
        semantic_backend: "rust";
        protocol_owner: "st-core::runtime::zspace_stochastic_schrodinger";
        evaluation_id: string;
        id_rule: string;
        status: "ready";
        request: {
            forward_request: ZSpaceStochasticSchrodingerCanonicalForwardRequest;
            input_imaginary: number[];
            cotangent: { real: number[]; imaginary: number[] } | null;
        };
        step: {
            contract_version: "spiraltorch.stochastic_complex_schrodinger.v1";
            arithmetic: "libm_0.2.16_f32_phase_f64_complex";
            output_real: number[];
            output_imaginary: number[];
            phase: number[];
            initial_norm_squared: number;
            final_norm_squared: number;
            expected_norm_ratio: number;
            max_row_norm_error: number;
        };
        gradient: {
            grad_input_real: number[];
            grad_input_imaginary: number[];
            grad_potential: number[];
        } | null;
        gradient_semantics: string;
        efficacy_claim_ready: false;
        evidence_boundary: string;
    };

    /** Rust-owned complex evolution and optional real Euclidean VJP. */
    export function zspaceStochasticSchrodingerComplexStepJson(requestJson: string): string;
    export function validateZspaceStochasticSchrodingerComplexJson(receiptJson: string): string;

    /** One content type owned by a Rust runtime protocol. */
    export type ZSpaceRuntimeProtocolArtifact = {
        name: string;
        contract_version: string;
        discriminator_field: "kind" | "schema";
        discriminator_value: string;
    };

    /** Rust-published bounds charged before protocol deserialization. */
    export type ZSpaceRuntimeProtocolAdmissionLimits = {
        maximum_bytes: number;
        maximum_nodes: number;
        maximum_depth: number;
    };

    /** Exact normal-ingress guarantee; trusted legacy replay is separate. */
    export type ZSpaceRuntimeProtocolAdmission = {
        profile:
            | "typed_native"
            | "passive_json_containers"
            | "bounded_json_string";
        guarantee: string;
        limits: ZSpaceRuntimeProtocolAdmissionLimits | null;
    };

    /** Exact admission-certified operations exposed without local semantics. */
    export type ZSpaceRuntimeProtocolClientSurface = {
        client: "rust" | "python" | "wasm";
        package: "st-core" | "spiraltorch" | "spiraltorch-wasm";
        transport: "native" | "bounded_mapping" | "bounded_json";
        normal_admission: ZSpaceRuntimeProtocolAdmission;
        operations: string[];
        trusted_legacy_replay: boolean;
    };

    /** One protocol family whose admission and semantics remain Rust-owned. */
    export type ZSpaceRuntimeProtocolDescriptor = {
        name:
            | "generation_evidence"
            | "periodicity"
            | "stochastic_schrodinger"
            | "stochastic_schrodinger_complex"
            | "repetition_unlikelihood"
            | "semantic_review";
        semantic_owner: string;
        semantic_backend: "rust";
        admission_owner: "rust";
        artifacts: ZSpaceRuntimeProtocolArtifact[];
        clients: ZSpaceRuntimeProtocolClientSurface[];
    };

    /** Content-addressed cross-client surface generated and validated by `st-core`. */
    export type ZSpaceRuntimeProtocolCatalog = {
        contract_version: "spiraltorch.zspace_runtime_protocol_catalog.v4";
        kind: "spiraltorch.zspace_runtime_protocol_catalog";
        semantic_owner: "st-core::runtime::zspace_runtime_protocol_catalog";
        semantic_backend: "rust";
        catalog_validated: true;
        catalog_id: string;
        catalog_id_rule: string;
        status: "ready";
        protocol_count: number;
        protocol_order_rule: "generation_evidence,periodicity,stochastic_schrodinger,stochastic_schrodinger_complex,repetition_unlikelihood,semantic_review";
        client_order_rule: "rust,python,wasm";
        legacy_replay_policy: string;
        protocols: ZSpaceRuntimeProtocolDescriptor[];
    };

    export function zspaceRuntimeProtocolCatalogJson(): string;
    export function zspaceRuntimeProtocolCatalogObject(): ZSpaceRuntimeProtocolCatalog;
    export function validateZspaceRuntimeProtocolCatalogJson(
        catalogJson: string,
    ): string;

    /** A held-out continuation committed to the shared Rust evidence protocol. */
    export type ZSpaceGenerationEvidenceSample = {
        prompt_id: string;
        seed: number;
        continuation_token_ids: number[];
    };

    /** Content-addressed identities and tokenizer-agnostic continuation tokens. */
    export type ZSpaceGenerationEvidenceRequest = {
        protocol_id: string;
        runtime_identity_id: string;
        model_artifact_id: string;
        prompt_set_id: string;
        decoding_config_id: string;
        samples: ZSpaceGenerationEvidenceSample[];
    };

    export type ZSpaceGenerationNgramEvidence = {
        order: number;
        possible_count: number;
        unique_count: number;
        repeated_occurrence_count: number;
        maximum_occurrence_count: number;
        distinct_ratio: number | null;
        repetition_ratio: number | null;
    };

    export type ZSpaceGenerationSampleEvidence = {
        prompt_id: string;
        seed: number;
        token_count: number;
        empty_continuation: boolean;
        adjacent_transition_count: number;
        consecutive_repeated_token_count: number;
        consecutive_repetition_ratio: number | null;
        periodic_loop_detected: boolean;
        periodic_suffix_period: number | null;
        periodic_suffix_token_count: number;
        periodic_suffix_repeated_token_count: number;
        periodic_suffix_repetition_count: number;
        periodic_suffix_repeated_token_ratio: number | null;
        loop_score: number;
        ngrams: ZSpaceGenerationNgramEvidence[];
    };

    export type ZSpaceGenerationAggregateEvidence = {
        sample_count: number;
        nonempty_sample_count: number;
        empty_sample_count: number;
        total_token_count: number;
        minimum_token_count: number;
        maximum_token_count: number;
        adjacent_transition_count: number;
        consecutive_repeated_token_count: number;
        consecutive_repetition_ratio: number | null;
        periodic_loop_sample_count: number;
        periodic_loop_sample_ratio: number;
        periodic_suffix_repeated_token_count: number;
        periodic_suffix_repeated_token_ratio: number | null;
        sample_mean_loop_score: number;
        maximum_loop_score: number;
        ngrams: ZSpaceGenerationNgramEvidence[];
    };

    /** Canonical, replayable generation evidence computed by `st-core`. */
    export type ZSpaceGenerationEvidenceReport = {
        contract_version: "spiraltorch.zspace_generation_evidence.v1";
        kind: "spiraltorch.zspace_generation_evidence";
        semantic_owner: "st-core::runtime::zspace_generation_evidence";
        semantic_backend: "rust";
        evidence_validated: true;
        evidence_id: string;
        status: "ready";
        request: ZSpaceGenerationEvidenceRequest;
        metric_rule: string;
        loop_score_rule: string;
        ngram_orders: [1, 2, 3, 4];
        periodic_suffix_max_period: number;
        periodic_suffix_min_repetitions: number;
        sample_count: number;
        evidence_scope: "held_out_generation_token_observation";
        samples: ZSpaceGenerationSampleEvidence[];
        aggregate: ZSpaceGenerationAggregateEvidence;
        efficacy_claim_ready: false;
        evidence_boundary: string;
        efficacy_claim_requirements: string;
    };

    /** Summarize held-out continuation tokens through the Rust semantic core. */
    export function zspaceGenerationEvidenceJson(requestJson: string): string;
    /** Trusted-local convenience; use the JSON route for untrusted input. */
    export function zspaceGenerationEvidenceObject(
        request: ZSpaceGenerationEvidenceRequest,
    ): ZSpaceGenerationEvidenceReport;

    /** Recompute persisted evidence and reject any changed field. */
    export function validateZspaceGenerationEvidenceJson(reportJson: string): string;
    /** Trusted-local convenience; use the JSON route for untrusted input. */
    export function validateZspaceGenerationEvidenceObject(
        report: ZSpaceGenerationEvidenceReport,
    ): ZSpaceGenerationEvidenceReport;

    export type ZSpaceRepetitionUnlikelihoodCandidateSource =
        | { kind: "prior_continuation"; ngram_order: number }
        | { kind: "model_topk_history"; proposal_top_k: number }
        | { kind: "model_topk_periodic"; proposal_top_k: number };

    export type ZSpaceRepetitionUnlikelihoodConfig = {
        strength: number;
        candidate_source: ZSpaceRepetitionUnlikelihoodCandidateSource;
        context_window: number;
        max_candidates_per_position: number;
    };

    export type ZSpaceRepetitionUnlikelihoodSequence = {
        token_ids: number[];
        token_mask: boolean[];
        label_mask: boolean[];
        proposal_token_ids?: number[][] | null;
    };

    export type ZSpaceRepetitionUnlikelihoodRequest = {
        config: ZSpaceRepetitionUnlikelihoodConfig;
        sequences: ZSpaceRepetitionUnlikelihoodSequence[];
    };

    export type ZSpaceRepetitionUnlikelihoodCandidate = {
        token_id: number;
        occurrence_count: number;
        most_recent_distance: number;
        proposal_rank?: number;
        periodic_suffix_period?: number;
        periodic_suffix_token_count?: number;
        periodic_suffix_repeated_token_count?: number;
        periodic_suffix_repetition_count?: number;
    };

    export type ZSpaceRepetitionUnlikelihoodPosition = {
        sequence_index: number;
        prediction_index: number;
        target_index: number;
        target_token_id: number;
        matched_prefix_token_ids?: number[];
        candidates: ZSpaceRepetitionUnlikelihoodCandidate[];
    };

    export type ZSpaceRepetitionUnlikelihoodAggregate = {
        sequence_count: number;
        total_token_count: number;
        eligible_target_count: number;
        active_position_count: number;
        candidate_count: number;
        excluded_target_match_count: number;
        proposal_count: number;
        excluded_target_proposal_count: number;
        excluded_out_of_history_proposal_count: number;
        excluded_non_periodic_proposal_count: number;
        periodic_candidate_count: number;
        truncated_candidate_count: number;
        maximum_candidates_per_active_position: number;
        active_position_ratio: number | null;
        mean_candidates_per_active_position: number | null;
    };

    /** Canonical negative-token plan owned and bounded by `st-core`. */
    export type ZSpaceRepetitionUnlikelihoodPlan = {
        contract_version: "spiraltorch.zspace_repetition_unlikelihood.v3";
        kind: "spiraltorch.zspace_repetition_unlikelihood_plan";
        semantic_owner: "st-core::runtime::zspace_repetition_unlikelihood";
        semantic_backend: "rust";
        differentiation_owner: "model-client-autograd";
        proposal_owner: "model-client-no-grad";
        plan_validated: true;
        plan_id: string;
        status: "ready";
        request: ZSpaceRepetitionUnlikelihoodRequest;
        proposal_rule: string;
        candidate_rule: string;
        objective_rule: string;
        probability_epsilon: number;
        periodic_suffix_max_period: number;
        periodic_suffix_min_repetitions: number;
        positions: ZSpaceRepetitionUnlikelihoodPosition[];
        aggregate: ZSpaceRepetitionUnlikelihoodAggregate;
        efficacy_claim_ready: false;
        evidence_boundary: string;
    };

    /** Plan in Rust within shared work/output budgets and bounded browser ingress. */
    export function zspaceRepetitionUnlikelihoodPlanJson(requestJson: string): string;
    export function zspaceRepetitionUnlikelihoodPlanObject(
        request: ZSpaceRepetitionUnlikelihoodRequest,
    ): ZSpaceRepetitionUnlikelihoodPlan;

    /** Recompute v3 after bounded browser ingress and reject any changed field. */
    export function validateZspaceRepetitionUnlikelihoodPlanJson(planJson: string): string;
    export function validateZspaceRepetitionUnlikelihoodPlanObject(
        plan: ZSpaceRepetitionUnlikelihoodPlan,
    ): ZSpaceRepetitionUnlikelihoodPlan;

    export type ZSpaceSemanticReviewCandidateLabel = "A" | "B" | "C";
    export type ZSpaceSemanticReviewPreference = ZSpaceSemanticReviewCandidateLabel | "tie";

    export type ZSpaceSemanticReviewCandidate = {
        candidate_label: ZSpaceSemanticReviewCandidateLabel;
        continuation: string;
    };

    export type ZSpaceSemanticReviewGroup = {
        group_id: string;
        prompt: string;
        candidates: [
            ZSpaceSemanticReviewCandidate,
            ZSpaceSemanticReviewCandidate,
            ZSpaceSemanticReviewCandidate,
        ];
    };

    export type ZSpaceSemanticReviewRubric = {
        fluency: "integer 1 through 5";
        prompt_relevance: "integer 1 through 5";
        local_coherence: "integer 1 through 5";
        non_repetition: "integer 1 through 5";
        preference: "A, B, C, or tie";
    };

    /** Uncommitted packet content; Rust owns fixed fields, counts, and packet identity. */
    export type ZSpaceSemanticReviewPacketRequest = {
        protocol_id: string;
        prompt_set_id: string;
        blinding_key_sha256: string;
        blinding_map_id: string;
        instructions: string;
        rubric: ZSpaceSemanticReviewRubric;
        groups: ZSpaceSemanticReviewGroup[];
    };

    export type ZSpaceSemanticReviewPacket = {
        schema: "spiraltorch.hf_blinded_semantic_review_packet.v1";
        status: "ready_for_blinded_review";
        protocol_id: string;
        prompt_set_id: string;
        blinding_key_sha256: string;
        blinding_map_id: string;
        group_count: number;
        candidate_count: number;
        instructions: string;
        rubric: ZSpaceSemanticReviewRubric;
        groups: ZSpaceSemanticReviewGroup[];
        packet_id: string;
    };

    export type ZSpaceSemanticReviewMapEntry = {
        group_id: string;
        seed: number;
        prompt_id: string;
        candidate_to_arm: Record<ZSpaceSemanticReviewCandidateLabel, string>;
    };

    export type ZSpaceSemanticReviewMapIdRequest = {
        entries: ZSpaceSemanticReviewMapEntry[];
    };

    export type ZSpaceSemanticReviewMap = {
        schema: "spiraltorch.hf_blinded_semantic_review_map.v1";
        status: "sealed_pending_review";
        protocol_id: string;
        packet_id: string;
        blinding_key_sha256: string;
        entries: ZSpaceSemanticReviewMapEntry[];
    };

    export type ZSpaceSemanticReviewCandidateScore = {
        candidate_label: ZSpaceSemanticReviewCandidateLabel;
        fluency: 1 | 2 | 3 | 4 | 5;
        prompt_relevance: 1 | 2 | 3 | 4 | 5;
        local_coherence: 1 | 2 | 3 | 4 | 5;
        non_repetition: 1 | 2 | 3 | 4 | 5;
    };

    export type ZSpaceSemanticReviewGroupResponse = {
        group_id: string;
        scores: [
            ZSpaceSemanticReviewCandidateScore,
            ZSpaceSemanticReviewCandidateScore,
            ZSpaceSemanticReviewCandidateScore,
        ];
        preference: ZSpaceSemanticReviewPreference;
    };

    export type ZSpaceSemanticReviewDraft = {
        schema: "spiraltorch.hf_blinded_semantic_review_draft.v1";
        packet_id: string;
        reviewer_id: string;
        review_session_id: string;
        responses: ZSpaceSemanticReviewGroupResponse[];
    };

    export type ZSpaceSemanticReviewPacketReceipt = {
        contract_version: "spiraltorch.zspace_semantic_review_packet.v1";
        kind: "spiraltorch.zspace_semantic_review_packet";
        semantic_owner: "st-core::runtime::zspace_semantic_review";
        semantic_backend: "rust";
        packet_validated: true;
        status: "ready";
        packet_id: string;
        protocol_id: string;
        prompt_set_id: string;
        blinding_key_sha256: string;
        blinding_map_id: string;
        group_count: number;
        candidate_count: number;
        candidate_labels: ["A", "B", "C"];
        score_dimensions: [
            "fluency",
            "prompt_relevance",
            "local_coherence",
            "non_repetition",
        ];
        score_minimum: 1;
        score_maximum: 5;
        preference_values: ["A", "B", "C", "tie"];
        packet_id_rule: string;
        blinding_map_id_rule: string;
        human_review_complete: false;
        unblind_ready: false;
        efficacy_claim_ready: false;
        evidence_boundary: string;
        packet: ZSpaceSemanticReviewPacket;
    };

    export type ZSpaceSemanticReviewDraftRequest = {
        packet: ZSpaceSemanticReviewPacket;
        draft: ZSpaceSemanticReviewDraft;
    };

    export type ZSpaceSemanticReviewDraftReceipt = {
        contract_version: "spiraltorch.zspace_semantic_review_draft.v1";
        kind: "spiraltorch.zspace_semantic_review_draft";
        semantic_owner: "st-core::runtime::zspace_semantic_review";
        semantic_backend: "rust";
        draft_validated: true;
        status: "in_progress" | "ready_for_unblind";
        draft_id: string;
        response_id: string | null;
        packet_id: string;
        reviewer_id: string;
        review_session_id: string;
        group_count: number;
        completed_group_count: number;
        remaining_group_count: number;
        scored_candidate_count: number;
        completion_ratio: number;
        missing_group_ids: string[];
        human_review_complete: boolean;
        unblind_ready: boolean;
        efficacy_claim_ready: false;
        evidence_boundary: string;
        request: ZSpaceSemanticReviewDraftRequest;
    };

    export type ZSpaceSemanticReviewMeanScores = {
        fluency: number;
        prompt_relevance: number;
        local_coherence: number;
        non_repetition: number;
        overall: number;
    };

    export type ZSpaceSemanticReviewArmAggregate = {
        arm: string;
        candidate_count: number;
        mean_scores: ZSpaceSemanticReviewMeanScores;
        preference_win_count: number;
        preference_share_of_groups: number;
    };

    export type ZSpaceSemanticReviewSeedAggregate = {
        seed: number;
        group_count: number;
        tie_preference_count: number;
        arms: ZSpaceSemanticReviewArmAggregate[];
    };

    export type ZSpaceSemanticReviewUnblindRequest = {
        packet: ZSpaceSemanticReviewPacket;
        draft: ZSpaceSemanticReviewDraft;
        blinding_map: ZSpaceSemanticReviewMap;
    };

    export type ZSpaceSemanticReviewUnblindReport = {
        contract_version: "spiraltorch.zspace_semantic_review_unblind.v1";
        kind: "spiraltorch.zspace_semantic_review_unblind";
        semantic_owner: "st-core::runtime::zspace_semantic_review";
        semantic_backend: "rust";
        unblind_validated: true;
        status: "unblinded";
        unblind_id: string;
        packet_id: string;
        response_id: string;
        blinding_map_id: string;
        protocol_id: string;
        reviewer_id: string;
        review_session_id: string;
        reviewed_group_count: number;
        unblinded_candidate_count: number;
        arm_count: number;
        tie_preference_count: number;
        arms: ZSpaceSemanticReviewArmAggregate[];
        seeds: ZSpaceSemanticReviewSeedAggregate[];
        human_review_complete: true;
        structural_blinding_inputs_validated: true;
        reviewer_blinding_behavior_verified: false;
        efficacy_claim_ready: false;
        evidence_boundary: string;
        request: ZSpaceSemanticReviewUnblindRequest;
    };

    /** Seal and validate a packet in the Rust semantic core. */
    export function sealZspaceSemanticReviewPacketJson(requestJson: string): string;
    export function sealZspaceSemanticReviewPacketObject(
        request: ZSpaceSemanticReviewPacketRequest,
    ): ZSpaceSemanticReviewPacketReceipt;

    /** Commit the exact pre-review candidate-to-arm assignments in Rust. */
    export function zspaceSemanticReviewMapIdJson(requestJson: string): string;
    export function zspaceSemanticReviewMapIdObject(
        request: ZSpaceSemanticReviewMapIdRequest,
    ): string;

    export function validateZspaceSemanticReviewPacketJson(packetJson: string): string;
    export function validateZspaceSemanticReviewPacketObject(
        packet: ZSpaceSemanticReviewPacket,
    ): ZSpaceSemanticReviewPacketReceipt;
    export function validateZspaceSemanticReviewPacketReceiptJson(receiptJson: string): string;
    export function validateZspaceSemanticReviewPacketReceiptObject(
        receipt: ZSpaceSemanticReviewPacketReceipt,
    ): ZSpaceSemanticReviewPacketReceipt;

    export function summarizeZspaceSemanticReviewDraftJson(requestJson: string): string;
    export function summarizeZspaceSemanticReviewDraftObject(
        request: ZSpaceSemanticReviewDraftRequest,
    ): ZSpaceSemanticReviewDraftReceipt;
    export function validateZspaceSemanticReviewDraftReceiptJson(receiptJson: string): string;
    export function validateZspaceSemanticReviewDraftReceiptObject(
        receipt: ZSpaceSemanticReviewDraftReceipt,
    ): ZSpaceSemanticReviewDraftReceipt;

    export function unblindZspaceSemanticReviewJson(requestJson: string): string;
    export function unblindZspaceSemanticReviewObject(
        request: ZSpaceSemanticReviewUnblindRequest,
    ): ZSpaceSemanticReviewUnblindReport;
    export function validateZspaceSemanticReviewUnblindJson(reportJson: string): string;
    export function validateZspaceSemanticReviewUnblindObject(
        report: ZSpaceSemanticReviewUnblindReport,
    ): ZSpaceSemanticReviewUnblindReport;

    /** Palette identifiers accepted by {@link FractalCanvas.set_palette}. */
    export type CanvasPaletteName =
        | "blue-magenta"
        | "blue_magenta"
        | "blue"
        | "turbo"
        | "grayscale"
        | "grey"
        | "gray";

    /** Canonical palette names reported by {@link FractalCanvas.palette}. */
    export type CanvasPaletteCanonicalName = "blue-magenta" | "turbo" | "grayscale";

    export type WasmReportAuditStatus = "ready" | "usable" | "needs_attention";

    export type ToposRuntimeMode =
        | "balanced"
        | "guarded"
        | "exploratory"
        | "contextual"
        | "training_first"
        | "inference_first";

    export type ToposRuntimeProfileInput = {
        training_gain?: number;
        inference_gain?: number;
        closure_risk?: number;
        exploration_budget?: number;
        control_energy?: number;
        training_rate_scale?: number;
        training_gradient_bias_scale?: number;
        inference_temperature?: number;
        inference_top_p?: number;
        inference_context_weight?: number;
        learning_inference_balance?: number;
    };

    export type ToposRuntimeProfile = Required<ToposRuntimeProfileInput> & {
        vector: [number, number, number, number, number];
    };

    export type ToposRuntimeRouteScores = {
        training: number;
        inference: number;
        guard: number;
        exploration: number;
        context: number;
        vector: number[];
    };

    export type ToposRuntimeRoute = {
        kind: "spiraltorch.topos_runtime_route";
        contract_version: "spiraltorch.topos_runtime_route.v1";
        semantic_owner: "st-tensor::pure::topos";
        semantic_backend: "rust";
        execution_client: "wasm";
        mode: ToposRuntimeMode;
        mode_id: number;
        score: number;
        score_key: "training" | "inference" | "guard" | "exploration" | "context";
        learning_action: string;
        inference_action: string;
        scores: ToposRuntimeRouteScores;
        runtime_profile: ToposRuntimeProfile;
    };

    export type RuntimeDeviceRouteEvidence = {
        requested_backend: string;
        effective_backend?: string | null;
        runtime_ready?: boolean | null;
        requested_backend_runtime_ready?: boolean | null;
        effective_backend_runtime_ready?: boolean | null;
        available?: boolean | null;
        runtime_status?: string | null;
        requested_backend_runtime_status?: string | null;
        effective_backend_runtime_status?: string | null;
        status?: string | null;
        error?: string | null;
    };

    export type RuntimeDeviceRouteRequest = {
        reports?: RuntimeDeviceRouteEvidence[];
        requested_backends?: string[];
        required_available_backends?: string[];
        required_ready_backends?: string[];
    };

    export type RuntimeDeviceRouteProbeRequest = {
        probes: RuntimeDeviceProbe[];
        diagnostic_reports?: RuntimeDeviceRouteEvidence[];
        requested_backends?: string[];
        required_available_backends?: string[];
        required_ready_backends?: string[];
    };

    export type RuntimeDeviceReadiness = "ready" | "not_ready" | "unknown";

    export type RuntimeDeviceRouteRow = {
        requested_backend: string;
        effective_backend: string;
        probe_succeeded: boolean;
        native_readiness: RuntimeDeviceReadiness;
        native_ready: boolean | null;
        route_readiness: RuntimeDeviceReadiness;
        route_ready: boolean;
        fallback: boolean;
        route: "direct" | "surrogate" | "unavailable";
        route_status: "ready" | "surrogate_ready" | "not_ready" | "unknown" | "error";
        runtime_status: string;
        requested_backend_runtime_status: string | null;
        effective_backend_runtime_status: string | null;
        diagnostic: string | null;
    };

    export type RuntimeDeviceRouteSelection = {
        requested_backend: string;
        effective_backend: string;
        native_readiness: RuntimeDeviceReadiness;
        route_readiness: RuntimeDeviceReadiness;
        fallback: boolean;
        route: "direct" | "surrogate" | "unavailable";
        route_status: "ready" | "surrogate_ready" | "not_ready" | "unknown" | "error";
    };

    export type RuntimeDeviceRoute = {
        kind: "spiraltorch.runtime_device_route";
        contract_version: "spiraltorch.runtime_device_route.v5";
        semantic_owner: "st-core::backend::runtime_route";
        semantic_backend: "rust";
        execution_client?: string;
        evidence: RuntimeDeviceRouteEvidence[];
        requested_backends: string[];
        backends: string[];
        report_count: number;
        routes: RuntimeDeviceRouteRow[];
        successful_probe_backends: string[];
        available_backends: string[];
        native_ready_backends: string[];
        native_not_ready_backends: string[];
        native_readiness_unknown_backends: string[];
        ready_backends: string[];
        not_ready_backends: string[];
        route_not_ready_backends: string[];
        route_readiness_unknown_backends: string[];
        fallback_backends: string[];
        error_backends: string[];
        missing_report_backends: string[];
        status_by_backend: Record<string, string>;
        all_ready: boolean;
        has_errors: boolean;
        runtime_readiness: RuntimeDeviceReadiness;
        runtime_ready: boolean;
        runtime_ready_basis:
            | "required_ready_backends"
            | "required_available_backends"
            | "required_available_and_ready_backends"
            | "any_ready_backend";
        runtime_missing_ready_backends: string[];
        runtime_unknown_ready_backends: string[];
        selection_candidates: string[];
        selection_policy: "first_ready_candidate";
        selection: RuntimeDeviceRouteSelection | null;
        required_available_backends: string[];
        required_available_backends_missing: string[];
        required_available_backends_unknown: string[];
        required_available_backends_passed: boolean | null;
        required_ready_backends: string[];
        required_ready_backends_missing: string[];
        required_ready_backends_unknown: string[];
        required_ready_backends_passed: boolean | null;
        failures: string[];
        passed: boolean;
        request_sha256: string;
        output_sha256: string;
        committed: true;
    };

    export type RuntimeBackendKind = "wgpu" | "mps" | "cuda" | "hip" | "cpu";

    export type RuntimeDeviceCaps = {
        backend: RuntimeBackendKind;
        subgroup: boolean;
        lane_width: number;
        max_workgroup: number;
        shared_mem_per_workgroup: number | null;
    };

    export type RuntimeDeviceCapsOverrides = {
        lane_width?: number;
        subgroup?: boolean;
        max_workgroup?: number;
        shared_mem_per_workgroup?: number;
    };

    export type RuntimeMpsProbeReport = {
        feature_enabled: boolean;
        platform_supported: boolean;
        host_class: "non-mac-host" | "apple-silicon-mac" | "intel-mac";
        backend_wired: boolean;
        initialized: boolean;
        planner_surrogate_backend: RuntimeBackendKind;
        planner_caps: RuntimeDeviceCaps;
    };

    export type RuntimeDeviceProbeRequest = {
        requested_backend: RuntimeBackendKind;
        caps: RuntimeDeviceCaps;
        mps_probe?: RuntimeMpsProbeReport;
        requested_workgroup?: number;
        cols?: number;
        tile_hint?: number;
        compaction_hint?: number;
    };

    export type RuntimeDeviceProbeObservationRequest = {
        requested_backend: RuntimeBackendKind;
        caps_overrides?: RuntimeDeviceCapsOverrides;
        requested_workgroup?: number;
        cols?: number;
        tile_hint?: number;
        compaction_hint?: number;
    };

    export type RuntimeBackendState = {
        backend: RuntimeBackendKind;
        integration_compiled: boolean;
        feature_enabled: boolean;
        real_kernels_compiled: boolean;
        placeholder: boolean;
        kernel_status:
            | "feature_disabled"
            | "cpu"
            | "kernel_wired"
            | "placeholder"
            | "stub_without_hip_real";
        runtime_probe_attempted: boolean;
        runtime_initialized: boolean;
        runtime_status:
            | "feature_disabled"
            | "cpu"
            | "ready"
            | "initialization_failed"
            | "placeholder"
            | "stub_without_hip_real";
        runtime_ready: boolean;
        runtime_error?: string;
        recommendation: string;
    };

    export type RuntimeDeviceProbe = {
        kind: "spiraltorch.runtime_device_probe";
        contract_version: "spiraltorch.runtime_device_probe.v1";
        semantic_owner: "st-core::backend::runtime_probe";
        semantic_backend: "rust";
        execution_client?: string;
        request: RuntimeDeviceProbeRequest;
        requested_runtime: RuntimeBackendState;
        effective_runtime: RuntimeBackendState;
        aligned_workgroup: number | null;
        occupancy_score: number | null;
        preferred_tile: number | null;
        preferred_compaction_tile: number | null;
        route_evidence: RuntimeDeviceRouteEvidence;
        request_sha256: string;
        output_sha256: string;
        committed: true;
    };

    export type RuntimeExecutionComponent =
        | "dense_matmul"
        | "prepacked_matmul"
        | "layer_norm"
        | "attention"
        | "softmax"
        | "tensor_util";

    export type RuntimeTensorBackend =
        | "auto"
        | "cpu"
        | "faer"
        | "cpu_simd"
        | "naive"
        | "wgpu"
        | "hip";

    export type TensorExecutionRouteStatus =
        | "direct"
        | "auto_resolved"
        | "cpu_threshold"
        | "runtime_fallback"
        | "no_op";

    export type TensorExecutionKernelBackend =
        | "cpu"
        | "cpu_simd"
        | "naive"
        | "faer"
        | "wgpu_dense"
        | "hip";

    export type TensorExecutionReceipt = {
        kind: "spiraltorch.tensor_execution_receipt";
        contract_version: "spiraltorch.tensor_execution_receipt.v1";
        semantic_owner: "st-tensor::execution";
        component: RuntimeExecutionComponent;
        operation: string;
        workload: RuntimeComponentWorkload;
        requested_backend: RuntimeTensorBackend;
        selected_backend: RuntimeTensorBackend;
        executed_backend?: RuntimeTensorBackend;
        kernel_backend?: TensorExecutionKernelBackend;
        route_status: TensorExecutionRouteStatus;
        fallback?: {
            from: RuntimeTensorBackend;
            to: RuntimeTensorBackend;
            reason: "runtime_unavailable";
        };
        runtime_execution_plan_output_sha256?: string;
    };

    export type RuntimeComponentWorkload =
        | { component: "dense_matmul"; rows: number; inner: number; cols: number }
        | {
              component: "prepacked_matmul";
              rows: number;
              inner: number;
              cols: number;
              bias?: boolean;
          }
        | { component: "layer_norm"; rows: number; cols: number }
        | {
              component: "attention";
              contexts: number;
              sequence: number;
              head_dim: number;
              z_bias?: boolean;
              attn_bias?: boolean;
          }
        | { component: "softmax"; rows: number; cols: number }
        | {
              component: "tensor_util";
              operation:
                  | "scale"
                  | "add_row"
                  | "sum_axis0"
                  | "sum_axis0_scaled"
                  | "max_axis0"
                  | "max_axis0_backward";
              rows: number;
              cols: number;
          };

    export type RuntimeComponentCapabilityStatus =
        | "ready"
        | "unavailable"
        | "not_built"
        | "unsupported";

    export type RuntimeComponentReadyProof =
        | "static_host_contract"
        | "runtime_dispatch_sentinel";

    export type RuntimeComponentCapabilityEvidence = {
        workload: RuntimeComponentWorkload;
        backend: RuntimeTensorBackend;
        status: RuntimeComponentCapabilityStatus;
        ready_proof: RuntimeComponentReadyProof | null;
    };

    export type RuntimeComponentCapabilityObservationRequest = {
        runtime_probe: RuntimeDeviceProbe;
        policy: RuntimeTensorBackendPolicy;
        component_workloads: RuntimeComponentWorkload[];
    };

    export type RuntimeComponentCapabilityObservation = {
        kind: "spiraltorch.runtime_component_capability_observation";
        contract_version: "spiraltorch.runtime_component_capability_observation.v4";
        semantic_owner: "st-core::backend::execution_capability";
        semantic_backend: "rust";
        request: RuntimeComponentCapabilityObservationRequest;
        runtime_probe_output_sha256: string;
        capabilities: RuntimeComponentCapabilityEvidence[];
        request_sha256: string;
        output_sha256: string;
        committed: true;
    };

    export type RuntimeExecutionConfig = {
        accelerator_fallback: "allow" | "forbid";
        tensor_util_wgpu_min_values: number;
    };

    export type RuntimeComponentResolution = "concrete" | "deferred";

    export type RuntimeExecutionPlanRequestInput = {
        runtime_probe: RuntimeDeviceProbe;
        execution_config: RuntimeExecutionConfig;
        component_resolution?: RuntimeComponentResolution;
        component_workloads?: RuntimeComponentWorkload[];
        component_capability_observation?: RuntimeComponentCapabilityObservation | null;
        tensor_util_values?: number | null;
        required_native_components?: RuntimeExecutionComponent[];
    };

    export type RuntimeExecutionPlanRequest = {
        runtime_probe: RuntimeDeviceProbe;
        execution_config: RuntimeExecutionConfig;
        component_resolution: RuntimeComponentResolution;
        component_workloads: RuntimeComponentWorkload[];
        component_capability_observation: RuntimeComponentCapabilityObservation | null;
        tensor_util_values: number | null;
        required_native_components: RuntimeExecutionComponent[];
    };

    export type RuntimeTensorBackendPolicy = {
        dense_matmul: RuntimeTensorBackend;
        prepacked_matmul: RuntimeTensorBackend;
        layer_norm: RuntimeTensorBackend;
        attention: RuntimeTensorBackend;
        softmax: RuntimeTensorBackend;
        tensor_util: RuntimeTensorBackend;
    };

    export type RuntimeComponentRoute = {
        component: RuntimeExecutionComponent;
        requested_backend: RuntimeTensorBackend;
        selected_backend: RuntimeTensorBackend;
        route: "direct" | "automatic" | "conditional" | "cpu_threshold_fallback";
        workloads?: RuntimeComponentWorkload[];
        capability_state:
            | "static"
            | "ready"
            | "unobserved"
            | "unavailable"
            | "not_built"
            | "unsupported"
            | "not_applicable";
        native: boolean;
        fallback: boolean;
        values?: number;
        threshold?: number;
    };

    export type RuntimeExecutionPlan = {
        kind: "spiraltorch.runtime_execution_plan";
        contract_version: "spiraltorch.runtime_execution_plan.v8";
        semantic_owner: "st-core::backend::execution_plan";
        semantic_backend: "rust";
        execution_client?: string;
        request: RuntimeExecutionPlanRequest;
        requested_backend: RuntimeBackendKind;
        effective_backend: RuntimeBackendKind;
        runtime_probe_output_sha256: string;
        component_capability_observation_output_sha256: string | null;
        runtime_route: RuntimeDeviceRoute;
        runtime_route_output_sha256: string;
        policy: RuntimeTensorBackendPolicy;
        component_routes: RuntimeComponentRoute[];
        native_components: RuntimeExecutionComponent[];
        automatic_components: RuntimeExecutionComponent[];
        conditional_components: RuntimeExecutionComponent[];
        fallback_components: RuntimeExecutionComponent[];
        required_native_components_missing: RuntimeExecutionComponent[];
        all_components_native: boolean;
        runtime_ready: boolean;
        surrogate: boolean;
        execution_allowed: boolean;
        status: "ready" | "blocked";
        blockers: string[];
        request_sha256: string;
        output_sha256: string;
        committed: true;
    };

    /** Trainer optimizer controls validated by the Rust semantic core. */
    export type TrainerOptimizerConfig = {
        curvature: number;
        hyper_learning_rate: number;
        fallback_learning_rate: number;
        real_learning_rate?: number | null;
        grad_clip_max_norm?: number | null;
    };

    /** Versioned validation receipt shared by native and browser clients. */
    export type TrainerOptimizerConfigContract = {
        kind: "spiraltorch.trainer_optimizer_config";
        contract_version: "spiraltorch.trainer_optimizer_config.v1";
        semantic_owner: "st-core::runtime::trainer_optimizer";
        semantic_backend: "rust";
        execution_client: "wasm";
        validation_rule: string;
        realgrad_enabled: boolean;
        gradient_clip_enabled: boolean;
        config: Required<TrainerOptimizerConfig>;
    };

    export type ToposOptimizerStateCheckpoint = {
        gradient_bias_scale: number;
        gradient_bias_basis: [
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number,
            number,
        ];
        gradient_clip_scale: number;
        momentum_damping: number;
    };

    export type OpenCartesianToposCheckpoint = {
        curvature: number;
        tolerance: number;
        saturation: number;
        porosity: number;
        max_depth: number;
        max_volume: number;
        site_radius_min: number;
        site_radius_max: number;
        guard_density_min: number;
        guard_density_max: number;
        guard_mass_tolerance: number;
    };

    export type AmegaHypergradCheckpoint = {
        curvature: number;
        learning_rate: number;
        rows: number;
        cols: number;
        gradient: number[];
        topos: OpenCartesianToposCheckpoint;
        optimizer_state: ToposOptimizerStateCheckpoint;
        optimizer_momentum: number[];
    };

    export type AmegaRealgradCheckpoint = {
        learning_rate: number;
        rows: number;
        cols: number;
        gradient: number[];
        optimizer_state: ToposOptimizerStateCheckpoint;
        optimizer_momentum: number[];
    };

    export type ZSpaceRegionDescriptor = {
        spin_alignment: number;
        normalized_radius: number;
        curvature_radius: number;
        geodesic_radius: number;
        sheet_index: number;
        sheet_count: number;
        topological_sector: number;
    };

    export type SpectralLrAdapterState = {
        sheet_hint: number;
        smoothing: number;
        curvature_target: number;
        curvature_gain: number;
        spin_gain: number;
        energy_gain: number;
        sheet_gain: number;
        min_scale: number;
        max_scale: number;
        avg_curvature: number;
        avg_spin: number;
        avg_energy: number;
    };

    export type TrainerCurvatureSchedulerState = {
        min_curvature: number;
        max_curvature: number;
        target_pressure: number;
        tolerance: number;
        step: number;
        proportional_gain: number;
        smoothing: number;
        current: number;
        ema_pressure: number | null;
        ema_pressure2: number | null;
        stability_threshold: number;
        stability_boost: number;
        stable_steps: number;
        dither_strength: number;
        dither_period: number;
        dither_sign: number;
    };

    export type TrainerSoftLogicConfigState = {
        inertia: number;
        inertia_min: number;
        inertia_drift_k: number;
        inertia_z_k: number;
        drift_gain: number;
        psi_gain: number;
        loss_gain: number;
        floor: number;
        scale_gain: number;
        region_gain: number;
        region_factor_gain: number;
        energy_equalize_gain: number;
        mean_normalize_gain: number;
        energy_equalize_auto: number;
        mean_normalize_auto: number;
    };

    export type TrainerSoftLogicFeedbackState = {
        z_signal: number;
        scale_log_radius: number | null;
    };

    export type TrainerSoftLogicState = {
        config: TrainerSoftLogicConfigState;
        last_weights: [number, number, number];
        last_z: number;
        last_feedback: TrainerSoftLogicFeedbackState | null;
        last_inertia: number;
        last_region: ZSpaceRegionDescriptor | null;
        last_region_factor: number;
        last_region_scale: [number, number, number];
        equalize_state: number;
        mean_normalize_state: number;
        pending_events: string[];
        equalize_guard_on: boolean;
        equalize_clamp_on: boolean;
        normalize_on: boolean;
    };

    export type TrainerSpectralPolicyState = {
        smoothing: number;
        event_smoothing: number;
        turnover_smoothing: number;
        coherence_gain: number;
        curvature_gain: number;
        sheet_gain: number;
        spin_gain: number;
        radius_gain: number;
        energy_gain: number;
        phase_gain: number;
        stuck_phase_gain: number;
        max_phase_gain: number;
        stuck_turnover_threshold: number;
        dominant_turnover: number;
        last_dominant: number | null;
        last_label: ZSpaceCoherenceLabel | null;
        min_lr_scale: number;
        max_lr_scale: number;
        max_lr_step: number;
        min_band_scale: number;
        max_band_scale: number;
        band_state: [number, number, number];
        lr_state: number;
        applied_lr_scale: number;
        local_lr_state: [number, number, number];
    };

    export type TrainerPhaseTrackerState = {
        turnover_spike_threshold: number;
        loss_ema_alpha: number;
        loss_spike_ratio: number;
        drift_spike_threshold: number;
        last_label: ZSpaceCoherenceLabel | null;
        last_turnover: number | null;
        last_band: number | null;
        last_drift_abs: number | null;
        loss_ema: number | null;
        loss_spiking: boolean;
    };

    export type TrainerBackendCounters = {
        epochs_recorded: number;
        ops_total: number;
        fallbacks: number;
        backend_wgpu: number;
        backend_cuda: number;
        backend_hip: number;
        backend_cpu: number;
        backend_other: number;
        requested_wgpu_hits: number;
        requested_wgpu_runtime_fallbacks: number;
        requested_wgpu_component_hits: number;
        requested_wgpu_component_fallbacks: number;
    };

    export type TrainerOptimizerRuntimeState = {
        epoch: number;
        meta_learning_rate_scale: number;
        meta_optimizer_step: number | null;
        spectral_adapter: SpectralLrAdapterState;
        curvature_scheduler: TrainerCurvatureSchedulerState | null;
        spectral_policy: TrainerSpectralPolicyState | null;
        phase_tracker: TrainerPhaseTrackerState;
        softlogic: TrainerSoftLogicState;
        backend_counters: TrainerBackendCounters;
        last_accumulator_sync_buffers: number;
        last_accumulator_sync_values: number;
    };

    export type TrainerParameterOptimizerState = {
        name: string;
        rows: number;
        cols: number;
        value_fingerprint: string;
        euclidean_gradient: number[] | null;
        hypergrad: AmegaHypergradCheckpoint | null;
        realgrad: AmegaRealgradCheckpoint | null;
    };

    export type TrainerOptimizerResumeScope =
        "trainer_optimizer_and_builtin_update_policy;parameter_values_external_and_fingerprint_guarded;external_runtime_components_reported";

    export type TrainerExecutionTopology = {
        backend: "cpu" | "wgpu" | "mps" | "cuda" | "hip";
        subgroup: boolean;
        lane_width: number;
        max_workgroup: number;
        shared_mem_per_workgroup: number | null;
        accelerator_fallback: "allow" | "forbid";
        tensor_util_wgpu_min_values: number;
        training_device_enabled: boolean;
        training_rank: number;
        training_world_size: number;
        external_state_required: string[];
    };

    /** Rust-produced optimizer checkpoint. WASM validates but does not execute it. */
    export type TrainerOptimizerCheckpoint = {
        kind: "spiraltorch.trainer_optimizer_checkpoint";
        contract_version: "spiraltorch.trainer_optimizer_checkpoint.v1";
        semantic_owner: "st-core::runtime::trainer_optimizer";
        semantic_backend: "rust";
        resume_scope: TrainerOptimizerResumeScope;
        config: Required<TrainerOptimizerConfig>;
        topology: TrainerExecutionTopology;
        state: TrainerOptimizerRuntimeState;
        parameters: TrainerParameterOptimizerState[];
    };

    /** Browser-side receipt produced by the same Rust checkpoint validator. */
    export type TrainerOptimizerCheckpointValidation = {
        kind: "spiraltorch.trainer_optimizer_checkpoint";
        contract_version: "spiraltorch.trainer_optimizer_checkpoint.v1";
        semantic_owner: "st-core::runtime::trainer_optimizer";
        semantic_backend: "rust";
        execution_client: "wasm";
        resume_scope: TrainerOptimizerResumeScope;
        parameter_count: number;
        hypergrad_parameters: number;
        realgrad_parameters: number;
        euclidean_parameters: number;
        captures_inflight_accumulators: boolean;
        parameter_values_external: true;
        deterministic_resume_ready: boolean;
        external_state_required: string[];
    };

    export type TrainerPsiComponent =
        | "act_drift"
        | "attn_entropy"
        | "band_energy"
        | "grad_norm"
        | "loss"
        | "positive_curvature"
        | "update_ratio";

    export type TrainerExternalPsiComponentValue = {
        component: TrainerPsiComponent;
        value: number;
    };

    export type TrainerPsiMeterCheckpoint = {
        kind: "spiraltorch.psi_meter_checkpoint";
        contract_version: "spiraltorch.psi_meter_checkpoint.v1";
        semantic_owner: "st-core::telemetry::psi";
        semantic_backend: "rust";
        enabled: boolean;
        components: TrainerPsiComponent[];
        weights: TrainerExternalPsiComponentValue[];
        ema_alpha: number;
        sample_rate: number;
        thresholds: TrainerExternalPsiComponentValue[];
        ema: TrainerExternalPsiComponentValue[];
        step: number;
    };

    export type TrainerTimestampCheckpoint = {
        unix_seconds: number;
        subsec_nanos: number;
    };

    export type TrainerDesirePhaseCheckpoint =
        | "observation"
        | "injection"
        | "integration";

    export type TrainerDesireWeightsCheckpoint = {
        alpha: number;
        beta: number;
        gamma: number;
        lambda: number;
    };

    export type TrainerDesireTriggerCheckpoint = {
        report_tokens: number[];
        report_scores: number[];
        mean_penalty: number;
        mean_entropy: number;
        temperature: number;
        samples: number;
    };

    export type TrainerDesireEventCheckpoint = {
        timestamp: TrainerTimestampCheckpoint;
        phase: TrainerDesirePhaseCheckpoint;
        temperature: number;
        entropy: number;
        hypergrad_penalty: number;
        weights: TrainerDesireWeightsCheckpoint;
        trigger: TrainerDesireTriggerCheckpoint | null;
    };

    export type TrainerDesireQueueCheckpoint = {
        events: TrainerDesireEventCheckpoint[];
    };

    export type TrainerDesireRoundtableImpulseCheckpoint = {
        multipliers: [number, number, number];
        drift: number;
        timestamp: TrainerTimestampCheckpoint;
    };

    export type TrainerDesireRoundtablePendingSummaryCheckpoint = {
        steps: number;
        triggers: number;
        sum_entropy: number;
        sum_temperature: number;
        sum_alpha: number;
        sum_beta: number;
        sum_gamma: number;
        sum_lambda: number;
        sum_above: number;
        sum_here: number;
        sum_beneath: number;
        sum_drift: number;
        last_timestamp: TrainerTimestampCheckpoint;
    };

    export type TrainerDesireRoundtableCheckpoint = {
        blend: number;
        drift_gain: number;
        latest: TrainerDesireRoundtableImpulseCheckpoint | null;
        pending_summary: TrainerDesireRoundtablePendingSummaryCheckpoint | null;
    };

    /** Minimal evidence replayed through the canonical Rust coherence contracts. */
    export type TrainerCoherenceSignalCheckpoint = {
        dominant_channel: number | null;
        preserved_channels: number;
        z_bias: number;
        distribution_witness: ZSpaceCoherenceDistributionWitness;
        energy_ratio: number;
        raw_mean_coherence: number;
        classification_policy: ZSpaceCoherenceClassificationPolicy;
        repaired_non_finite_weights: number;
        repaired_negative_weights: number;
        pre_discard_repaired_non_finite: number;
        pre_discard_repaired_negative: number;
    };

    export type TrainerCoherenceBridgeCheckpoint = {
        subscribed: boolean;
        pending: TrainerCoherenceSignalCheckpoint | null;
        latest: TrainerCoherenceSignalCheckpoint | null;
    };

    /** Raw evidence validated by the canonical Rust GNN roundtable contract. */
    export type GnnRoundtableSignalObservation = {
        band_energy: {
            above: number;
            here: number;
            beneath: number;
            drift: number;
        };
        band_sizes: {
            above: number;
            here: number;
            beneath: number;
        };
        spectral: {
            sheet_index: number;
            sheet_confidence: number;
            curvature: number;
            spin: number;
            energy: number;
        };
    };

    export type TrainerGnnRoundtableSignalCheckpoint = {
        observation: GnnRoundtableSignalObservation;
        issued_at: TrainerTimestampCheckpoint;
    };

    export type TrainerGnnRoundtableBridgeCheckpoint = {
        history_limit: number;
        history: TrainerGnnRoundtableSignalCheckpoint[];
        latest: TrainerGnnRoundtableSignalCheckpoint | null;
        trainer_last: TrainerGnnRoundtableSignalCheckpoint | null;
    };

    /** Native topology uses canonical decimal strings to preserve the complete Rust u64 range. */
    export type TrainerAccumulatorSynchronizerCheckpoint = {
        kind: "spiraltorch.accumulator_synchronizer_checkpoint";
        contract_version: "spiraltorch.accumulator_synchronizer_checkpoint.v2";
        semantic_owner: "st-core::distributed::AccumulatorSynchronizer";
        semantic_backend: "rust";
        provider: string;
        rank: string;
        world_size: string;
        state: Record<string, unknown> | null;
    };

    /** Rust-produced state for trainer components outside optimizer ownership. */
    export type TrainerExternalStateCheckpoint = {
        kind: "spiraltorch.trainer_external_state_checkpoint";
        contract_version: "spiraltorch.trainer_external_state_checkpoint.v5";
        semantic_owner: "st-core::runtime::trainer_external";
        semantic_backend: "rust";
        required_components: string[];
        desire_trainer: TrainerDesireQueueCheckpoint | null;
        desire_roundtable: TrainerDesireRoundtableCheckpoint | null;
        coherence_bridge: TrainerCoherenceBridgeCheckpoint | null;
        gnn_roundtable_bridge: TrainerGnnRoundtableBridgeCheckpoint | null;
        psi_meter: TrainerPsiMeterCheckpoint | null;
        accumulator_synchronizer: TrainerAccumulatorSynchronizerCheckpoint | null;
        unresolved_components: string[];
    };

    /** Browser preflight receipt; concrete native resources are never reattached here. */
    export type TrainerExternalStateCheckpointValidation = {
        kind: "spiraltorch.trainer_external_state_checkpoint";
        contract_version: "spiraltorch.trainer_external_state_checkpoint.v5";
        semantic_owner: "st-core::runtime::trainer_external";
        semantic_backend: "rust";
        execution_client: "wasm";
        required_components: string[];
        captured_components: string[];
        unresolved_components: string[];
        reattach_required_components: string[];
        reattached_components: string[];
        payload_complete: boolean;
        deterministic_resume_ready: boolean;
    };

    export type TrainerRuntimeCheckpointResumeScope =
        "module_trainer_optimizer_and_supported_external_runtime_state;parameter_values_external_and_fingerprint_guarded;concrete_resources_reattached_before_commit";

    /** Integrity-bound Rust envelope for optimizer and supported external state. */
    export type TrainerRuntimeCheckpointBundle = {
        kind: "spiraltorch.trainer_runtime_checkpoint_bundle";
        contract_version: "spiraltorch.trainer_runtime_checkpoint_bundle.v2";
        semantic_owner: "st-core::runtime::trainer_checkpoint";
        semantic_backend: "rust";
        resume_scope: TrainerRuntimeCheckpointResumeScope;
        optimizer_sha256: string;
        external_sha256: string;
        optimizer: TrainerOptimizerCheckpoint;
        external: TrainerExternalStateCheckpoint;
    };

    /** Browser preflight receipt; native restore and resource attachment happen elsewhere. */
    export type TrainerRuntimeCheckpointValidation = {
        kind: "spiraltorch.trainer_runtime_checkpoint_bundle";
        contract_version: "spiraltorch.trainer_runtime_checkpoint_bundle.v2";
        semantic_owner: "st-core::runtime::trainer_checkpoint";
        semantic_backend: "rust";
        execution_client: "wasm";
        resume_scope: TrainerRuntimeCheckpointResumeScope;
        optimizer_sha256: string;
        external_sha256: string;
        parameter_count: number;
        captures_inflight_accumulators: boolean;
        parameter_values_external: true;
        required_components: string[];
        captured_components: string[];
        unresolved_components: string[];
        reattach_required_components: string[];
        reattached_components: string[];
        payload_complete: boolean;
        deterministic_resume_ready: boolean;
    };

    export type RankPlanRequest = {
        kind: "topk" | "top_k" | "midk" | "mid_k" | "bottomk" | "bottom_k";
        rows: number;
        cols: number;
        k: number;
        backend?: "auto" | "wgpu" | "webgpu" | "mps" | "cuda" | "hip" | "rocm" | "cpu";
        lane_width?: number;
        subgroup?: boolean;
        max_workgroup?: number;
        shared_mem_per_workgroup?: number;
        strict_accelerator?: boolean;
        tensor_util_wgpu_min_values?: number;
        runtime_execution_plan?: RuntimeExecutionPlan;
    };

    export type RankPlanLatencyWindow = {
        target: number;
        lower: number;
        upper: number;
        min_lane: number;
        max_lane: number;
        slack: number;
        stride: number;
    };

    export type RankPlanContract = {
        kind: "spiraltorch.rank_plan";
        contract_version: "spiraltorch.rank_plan.v2";
        runtime_execution_plan_output_sha256?: string;
        semantic_owner: "st-core::ops::rank_entry";
        semantic_backend: "rust";
        execution_client: "wasm";
        requested_backend: "wgpu" | "mps" | "cuda" | "hip" | "cpu";
        effective_backend: "wgpu" | "mps" | "cuda" | "hip" | "cpu";
        rank_kind: "topk" | "midk" | "bottomk";
        rows: number;
        cols: number;
        k: number;
        input_elements: number;
        output_elements: number;
        device_caps: {
            backend: "wgpu" | "mps" | "cuda" | "hip" | "cpu";
            subgroup: boolean;
            lane_width: number;
            max_workgroup: number;
            shared_mem_per_workgroup: number | null;
        };
        choice: {
            use_two_stage: boolean;
            workgroup: number;
            lanes: number;
            channel_stride: number;
            merge_kind: number;
            merge_detail: number;
            tile: number;
            compaction_tile: number;
            subgroup: boolean;
            fft_tile: number;
            fft_radix: number;
            fft_segments: number;
            latency_window: RankPlanLatencyWindow | null;
        };
        execution: {
            accelerator_fallback: "allow" | "forbid";
            tensor_util_wgpu_min_values: number;
        };
    };

    export type RankAdaptationRequest = {
        rank_plan: RankPlanRequest;
        scripts: string[];
        policy?: "ucb" | "upper_confidence_bound" | "ts" | "thompson_sampling";
        /** Nonnegative JavaScript-safe integer. */
        seed?: number;
    };

    export type RankAdaptationBanditArm = {
        choice: string;
        posterior_mean: number;
        predictive_stddev: number;
        decision_score: number;
        selection_attempts: number;
        observations: number;
        quarantined: boolean;
        hinted: boolean;
    };

    export type RankAdaptationBanditDecision = {
        mode: string;
        chosen: string;
        decision_index: number;
        posterior_estimator: string;
        posterior_regularization: number;
        exploration_scale: number;
        forced_exploration: boolean;
        sampling_applied: boolean;
        rng_algorithm: string | null;
        /** Exact decimal u64 text; never rounded to a JavaScript number. */
        rng_stream_seed: string | null;
        arms: RankAdaptationBanditArm[];
    };

    export type RankAdaptationSelectionReceipt = {
        kind: "spiraltorch.rank_adaptation";
        contract_version: "spiraltorch.rank_adaptation.v1";
        semantic_owner: "st-core::runtime::rank_adaptation";
        semantic_backend: "rust";
        execution_client: "wasm";
        policy: "upper_confidence_bound" | "thompson_sampling";
        selection_id: number;
        candidate_index: number;
        spiralk_source_sha256: string;
        execution_signature: string;
        plan: RankPlanContract;
        decision: RankAdaptationBanditDecision;
    };

    export type RankAdaptationObservationReceipt = {
        kind: "spiraltorch.rank_adaptation";
        contract_version: "spiraltorch.rank_adaptation.v1";
        semantic_owner: "st-core::runtime::rank_adaptation";
        semantic_backend: "rust";
        execution_client: "wasm";
        selection_id: number;
        candidate_index: number;
        elapsed_ms: number;
        correctness_passed: boolean;
        credited: boolean;
        candidate_quarantined: boolean;
        reward: number | null;
        reward_formula: "1 / (1 + elapsed_ms)";
        observation_counts: Record<string, Record<string, number>>;
        quarantined_choices: Record<string, string[]>;
    };

    export type RankAdaptationAbandonmentReceipt = {
        kind: "spiraltorch.rank_adaptation";
        contract_version: "spiraltorch.rank_adaptation.v1";
        semantic_owner: "st-core::runtime::rank_adaptation";
        semantic_backend: "rust";
        execution_client: "wasm";
        selection_id: number;
        candidate_index: number;
        credited: false;
        observation_counts: Record<string, Record<string, number>>;
        quarantined_choices: Record<string, string[]>;
    };

    export type RankAdaptationSessionSnapshot = {
        kind: "spiraltorch.rank_adaptation";
        contract_version: "spiraltorch.rank_adaptation.v1";
        semantic_owner: "st-core::runtime::rank_adaptation";
        semantic_backend: "rust";
        execution_client: "wasm";
        policy: "upper_confidence_bound" | "thompson_sampling";
        seed: number;
        bandit_context: [number];
        reward_formula: "1 / (1 + elapsed_ms)";
        candidates: Array<{
            index: number;
            spiralk_source_sha256: string;
            execution_signature: string;
            plan: RankPlanContract;
        }>;
        choice_domains: Record<string, string[]>;
        observation_counts: Record<string, Record<string, number>>;
        quarantined_choices: Record<string, string[]>;
        pending_selection_id: number | null;
    };

    /**
     * Rust-owned SpiralK candidate planner plus Black Cat feedback state.
     * WGPU comparisons require strict_accelerator; declared_native signatures
     * validate static geometry, not device readiness. The caller must execute
     * without fallback and validate output before crediting an observation.
     */
    export class RankAdaptationSession {
        constructor(request: RankAdaptationRequest);
        free(): void;
        choose(): RankAdaptationSelectionReceipt;
        observe(
            selection_id: number,
            elapsed_ms: number,
            correctness_passed: boolean,
        ): RankAdaptationObservationReceipt;
        abandon(selection_id: number): RankAdaptationAbandonmentReceipt;
        snapshot(): RankAdaptationSessionSnapshot;
        pendingSelectionId(): number | undefined;
    }

    export type RouteSelectionProfile =
        | "balanced"
        | "quality"
        | "grounded"
        | "efficiency"
        | "latency";

    export type ToposRoutePolicyProfile = RouteSelectionProfile;

    export type ApiLlmRoutePolicyRowInput = {
        label: string;
        /** Positive observations make a route active; omitted or zero rows cannot win. */
        count?: number;
        runtime_ready_rate?: number | null;
        completion_rate?: number | null;
        incomplete_rate?: number | null;
        empty_text_rate?: number | null;
        refusal_rate?: number | null;
        total_tokens?: number | null;
        latency_ms_mean?: number | null;
        confidence_mean?: number | null;
        text_quality_score?: number | null;
        stability_mean?: number | null;
        frac_mean?: number | null;
        wasm_loss_mean?: number | null;
        wasm_stability_hint_mean?: number | null;
        wasm_webgpu_device_ready_rate?: number | null;
        topos_context_observed_rate?: number | null;
        topos_closure_pressure_mean?: number | null;
        topos_openness_mean?: number | null;
        topos_training_gradient_bias_scale_mean?: number | null;
        topos_optimizer_effective_gradient_bias_scale_mean?: number | null;
        topos_training_clip_scale_mean?: number | null;
        topos_training_plan_rate_scale_mean?: number | null;
        topos_optimizer_rate_scale_mean?: number | null;
        topos_optimizer_raw_rate_scale_mean?: number | null;
        topos_inference_context_weight_mean?: number | null;
        topos_inference_plan_context_weight_mean?: number | null;
        topos_inference_plan_temperature_mean?: number | null;
        topos_runtime_control_energy_mean?: number | null;
        topos_runtime_closure_risk_mean?: number | null;
        topos_runtime_exploration_budget_mean?: number | null;
        topos_runtime_route_score_mean?: number | null;
        topos_runtime_route_guard_score_mean?: number | null;
        topos_runtime_route_exploration_score_mean?: number | null;
        topos_runtime_route_context_score_mean?: number | null;
        /** Compatibility/output field. Rust ignores client-provided values. */
        quality_score?: number;
        /** Compatibility/output field. Rust ignores client-provided values. */
        latency_cost?: number;
        /** Compatibility/output field. Rust ignores client-provided values. */
        token_cost?: number;
        /** Compatibility/output field. Rust ignores client-provided values. */
        health_penalty?: number;
        /** Compatibility/output field. Rust ignores client-provided values. */
        efficiency_score?: number;
        /** Compatibility/output field. Rust ignores client-provided values. */
        route_score?: number;
        /** Compatibility/output field. Rust ignores client-provided values. */
        selection_scores?: Partial<Record<RouteSelectionProfile, number>>;
        /** Compatibility/output field. Rust ignores client-provided values. */
        selection_evidence?: Partial<
            Record<RouteSelectionProfile, ApiLlmRoutePolicyScoreEvidence>
        >;
    };

    export type ApiLlmRoutePolicyScoreEvidence = {
        profile: RouteSelectionProfile;
        formula_version: "spiraltorch.api_llm_route_policy.score.v1";
        raw_score: number;
        score: number;
        evidence_coverage: number;
        sample_count: number;
        sample_confidence: number;
        effective_confidence: number;
        observed_metrics: string[];
        partial_metrics: string[];
        missing_metrics: string[];
        metric_coverage: Record<string, number>;
    };

    export type ApiLlmRoutePolicyRow = ApiLlmRoutePolicyRowInput & {
        quality_score: number;
        latency_cost: number;
        token_cost: number;
        health_penalty: number;
        efficiency_score: number;
        route_score: number;
        selection_scores: Record<RouteSelectionProfile, number>;
        selection_evidence: Record<
            RouteSelectionProfile,
            ApiLlmRoutePolicyScoreEvidence
        >;
    };

    export type ApiLlmRoutePolicyEvaluationRequest = {
        rows: ApiLlmRoutePolicyRowInput[];
        near_best_tolerance?: number;
    };

    export type ApiLlmRoutePolicyWinner = {
        label: string | null;
        score: number;
        route_score: number;
        quality_score: number;
        text_quality_score: number | null;
        efficiency_score: number;
        latency_ms_mean: number | null;
        total_tokens: number | null;
        completion_rate: number | null;
        wasm_loss_mean: number | null;
        wasm_webgpu_device_ready_rate: number | null;
        score_evidence: ApiLlmRoutePolicyScoreEvidence | null;
    };

    export type ApiLlmRoutePolicyEvaluation = {
        kind: "spiraltorch.api_llm_route_policy";
        contract_version: "spiraltorch.api_llm_route_policy.v1";
        semantic_owner: "st-core::runtime::api_llm_route_policy";
        semantic_backend: "rust";
        execution_client: "wasm";
        row_count: number;
        active_row_count: number;
        inactive_row_count: number;
        near_best_tolerance: number;
        score_formula_version: "spiraltorch.api_llm_route_policy.score.v1";
        score_formula: string;
        score_prior_mean: number;
        score_prior_strength: number;
        rows: ApiLlmRoutePolicyRow[];
        ranked_labels: string[];
        near_best: Array<{
            label: string;
            route_score: number;
            route_score_delta: number;
        }>;
        profiles: Record<RouteSelectionProfile, ApiLlmRoutePolicyWinner>;
        winners: Record<string, string | null>;
    };

    export type ToposRoutePolicyScoreEvidence = {
        profile: ToposRoutePolicyProfile;
        formula_version: "spiraltorch.topos_route_policy.score.v2";
        raw_score: number;
        score: number;
        evidence_coverage: number;
        sample_count: number;
        sample_confidence: number;
        observed_metrics: string[];
        missing_metrics: string[];
    };

    export type ToposRoutePolicyRow = {
        label: string;
        /** Positive observations make a route active; omitted or zero rows are not rewarded. */
        count?: number;
        trace_route_score?: number | null;
        trace_quality_score?: number | null;
        trace_efficiency_score?: number | null;
        trace_text_quality_score?: number | null;
        response_text_quality_score?: number | null;
        response_prompt_coverage?: number | null;
        response_completion_rate?: number | null;
        response_incomplete_rate?: number | null;
        response_confidence?: number | null;
        latency_ms_mean?: number | null;
        total_tokens?: number | null;
        adapter_runtime_route_score?: number | null;
        adapter_guard_score?: number | null;
        adapter_exploration_score?: number | null;
        adapter_context_score?: number | null;
        closure_pressure?: number | null;
        openness?: number | null;
        context_weight?: number | null;
        request_temperature?: number | null;
        mode?: string | null;
        /** Compatibility/output field. Rust ignores client-provided values. */
        selection_scores?: Partial<Record<ToposRoutePolicyProfile, number>>;
        /** Compatibility/output field. Rust ignores client-provided values. */
        selection_evidence?: Partial<
            Record<ToposRoutePolicyProfile, ToposRoutePolicyScoreEvidence>
        >;
    };

    export type ToposRoutePolicyWinner = {
        label: string | null;
        score: number;
        trace_route_score: number;
        trace_quality_score: number;
        trace_efficiency_score: number;
        response_text_quality_score: number;
        response_prompt_coverage: number;
        response_completion_rate: number;
        latency_ms_mean: number;
        total_tokens: number;
        adapter_runtime_route_score: number;
        adapter_guard_score: number;
        adapter_context_score: number;
        closure_pressure: number | null;
        openness: number | null;
        context_weight: number | null;
        score_evidence: ToposRoutePolicyScoreEvidence | null;
    };

    export type ToposRoutePolicyEvaluationRequest = {
        rows: ToposRoutePolicyRow[];
    };

    export type ToposRoutePolicyEvaluation = {
        kind: "spiraltorch.topos_route_policy";
        contract_version: "spiraltorch.topos_route_policy.v2";
        semantic_owner: "st-core::runtime::topos_route_policy";
        semantic_backend: "rust";
        execution_client: "wasm";
        row_count: number;
        active_row_count: number;
        score_formula_version: "spiraltorch.topos_route_policy.score.v2";
        score_formula: string;
        score_prior_mean: number;
        score_prior_strength: number;
        rows: ToposRoutePolicyRow[];
        profiles: Record<ToposRoutePolicyProfile, ToposRoutePolicyWinner>;
    };

    export type ToposRouteRewardsRequest = {
        rows: ToposRoutePolicyRow[];
        profile?: ToposRoutePolicyProfile;
    };

    export type ToposRouteReward = {
        index: number;
        source_index: number;
        label: string;
        profile: ToposRoutePolicyProfile;
        reward: number;
        count: number;
        trace_route_score: number;
        response_text_quality_score: number;
        response_completion_rate: number;
        response_incomplete_rate: number;
        adapter_runtime_route_score: number;
        score_evidence: ToposRoutePolicyScoreEvidence;
        source_row: ToposRoutePolicyRow;
    };

    export type ToposRouteRewards = {
        kind: "spiraltorch.topos_route_rewards";
        contract_version: "spiraltorch.topos_route_policy.v2";
        semantic_owner: "st-core::runtime::topos_route_policy";
        semantic_backend: "rust";
        execution_client: "wasm";
        profile: ToposRoutePolicyProfile;
        input_row_count: number;
        active_row_count: number;
        inactive_row_count: number;
        reward_count: number;
        score_formula_version: "spiraltorch.topos_route_policy.score.v2";
        score_formula: string;
        score_prior_mean: number;
        score_prior_strength: number;
        rewards: ToposRouteReward[];
    };

    export type ToposRoutePolicyResolveRequest = {
        rewards: ToposRouteReward[];
        selected_label?: string | null;
        selected_index?: number;
    };

    export type ToposRoutePolicyResolution = {
        kind: "spiraltorch.topos_route_policy_resolution";
        contract_version: "spiraltorch.topos_route_policy.v2";
        semantic_owner: "st-core::runtime::topos_route_policy";
        semantic_backend: "rust";
        execution_client: "wasm";
        score_formula_version: "spiraltorch.topos_route_policy.score.v2";
        resolution: "label" | "index" | "none";
        selected_position: number | null;
        selected_label: string | null;
        selected_reward: number | null;
        route_reward: ToposRouteReward | null;
    };

    export type ToposControlSignalInput = {
        curvature?: number;
        tolerance?: number;
        saturation?: number;
        porosity?: number;
        max_depth?: number;
        max_volume?: number;
        observed_depth?: number;
        visited_volume?: number;
    };

    export type ToposTrainingHints = {
        learning_rate_scale: number;
        regularization_scale: number;
        step_damping: number;
        gradient_bias_scale: number;
        clip_scale: number;
        momentum_damping: number;
        vector: number[];
    };

    export type ToposTrainingPlan = ToposTrainingHints & {
        gain: number;
        raw_rate_scale: number;
        rate_scale: number;
        effective_gradient_bias_scale: number;
        effective_gradient_clip_scale: number;
        effective_momentum_damping: number;
    };

    export type ToposInferenceHints = {
        temperature_scale: number;
        top_p_scale: number;
        sampling_focus: number;
        frequency_penalty_bias: number;
        presence_penalty_bias: number;
        context_weight: number;
        vector: number[];
    };

    export type ToposInferencePlan = {
        gain: number;
        temperature: number;
        top_p: number;
        frequency_penalty: number;
        presence_penalty: number;
        context_weight: number;
        temperature_scale: number;
        top_p_scale: number;
        sampling_focus: number;
        vector: number[];
    };

    export type ToposControlSignal = Required<ToposControlSignalInput> & {
        kind: "spiraltorch.topos_control_signal";
        contract_version: "spiraltorch.topos_control_signal.v2";
        semantic_owner: "st-tensor::pure::topos";
        semantic_backend: "rust";
        execution_client: "wasm";
        remaining_volume: number;
        depth_pressure: number;
        volume_pressure: number;
        closure_pressure: number;
        openness: number;
        guard_strength: number;
        stability_hint: number;
        exploration_hint: number;
        learning_rate_scale: number;
        temperature_scale: number;
        regularization_scale: number;
        step_damping: number;
        sampling_focus: number;
        runtime_hints: number[];
        gradient: number[];
        training_hints: ToposTrainingHints;
        training_plan: ToposTrainingPlan;
        inference_hints: ToposInferenceHints;
        inference_plan: ToposInferencePlan;
        runtime_profile: ToposRuntimeProfile;
        runtime_route: ToposRuntimeRoute;
    };

    export type ToposInferencePlanOptions = {
        gain?: number;
        base_temperature?: number;
        base_top_p?: number;
        min_temperature?: number;
        max_temperature?: number;
        min_top_p?: number;
        max_top_p?: number;
        base_frequency_penalty?: number;
        base_presence_penalty?: number;
    };

    export type ToposControlPlanOptions = {
        training_gain?: number;
        inference?: ToposInferencePlanOptions;
    };

    export type ToposOptimizerSnapshotRequest = {
        signal: ToposControlSignalInput;
        sequence: number;
        hyper_learning_rate: number;
        real_learning_rate: number;
        options?: ToposControlPlanOptions;
        training_hints?: Partial<ToposTrainingHints>;
        inference_hints?: Partial<ToposInferenceHints>;
    };

    export type ToposOptimizerApplication = {
        scope: "learning_rate_and_gradient_state";
        control_path: "control.training_plan";
        input_hyper_learning_rate: number;
        input_real_learning_rate: number;
        rate_scale: number;
        hyper_learning_rate: number;
        real_learning_rate: number;
        gradient_bias_rule: "g_biased[i]=g[i]+rms(g)*bias_scale*basis[i%10]";
        gradient_bias_normalization: "raw_gradient_rms";
        effective_gradient_bias_scale: number;
        gradient_bias_basis_dim: 10;
        gradient_bias_basis: number[];
        gradient_clip_rule: "g_clipped[i]=clamp(g_biased[i],-rms(g_biased)/(1-clip_scale),rms(g_biased)/(1-clip_scale))";
        gradient_clip_normalization: "biased_gradient_rms";
        effective_gradient_clip_scale: number;
        momentum_rule: "m_t=damping*m_(t-1)+(1-damping)*g_clipped";
        effective_momentum_damping: number;
    };

    export type ToposOptimizerSnapshot = {
        kind: "spiraltorch.topos_optimizer_snapshot";
        contract_version: "spiraltorch.topos_optimizer_snapshot.v3";
        semantic_owner: "st-tensor::pure::topos";
        semantic_backend: "rust";
        execution_client: "wasm";
        sequence: number;
        control: Omit<ToposControlSignal, "execution_client">;
        optimizer_application: ToposOptimizerApplication;
    };

    export type ToposZSpaceProjection = {
        kind: "spiraltorch.topos_zspace_projection";
        contract_version: "spiraltorch.topos_zspace_projection.v2";
        semantic_owner: "st-tensor::pure::topos";
        semantic_backend: "rust";
        execution_client: "wasm";
        gradient_basis: "spiraltorch.topos.control_signal.axes.v1";
        gradient_formula: "gradient=resize([openness,guard_strength,stability_hint,exploration_hint,depth_pressure,volume_pressure],gradient_dim,0)";
        gradient_channels: [
            "openness",
            "guard_strength",
            "stability_hint",
            "exploration_hint",
            "depth_pressure",
            "volume_pressure",
        ];
        gradient_dim: number;
        base_gradient_dim: 6;
        speed: number;
        memory: number;
        stability: number;
        drs: number;
        frac: number;
        gradient: number[];
        vector: number[];
    };

    export type ZSpaceFusionStrategy =
        | "mean"
        | "last"
        | "max"
        | "min"
        | "median"
        | "sum";

    export type ZSpaceGradientAlignment = "strict" | "pad_zero";

    export type ZSpaceTelemetrySummary = {
        count: number;
        l1: number;
        l2: number;
        linf: number;
        mean: number;
        variance: number;
        energy: number;
        amplitude: number;
        positive: number;
        negative: number;
        balance: number;
        focus: number;
    };

    export type ZSpaceTelemetrySourceAudit = {
        index: number;
        flattened_count: number;
        ignored_value_count: number;
        conflict_count: number;
    };

    export type ZSpaceTelemetryFusion = {
        kind: "spiraltorch.zspace_telemetry_fusion";
        contract_version: "spiraltorch.zspace_telemetry_fusion.v1";
        semantic_owner: "st-core::telemetry::zspace_fusion";
        semantic_backend: "rust";
        execution_client: "wasm";
        payload: Record<string, number>;
        summary: ZSpaceTelemetrySummary;
        input_count: number;
        active_input_count: number;
        ignored_value_count: number;
        conflict_count: number;
        sources: ZSpaceTelemetrySourceAudit[];
    };

    export type ZSpacePartialInput = {
        metrics: Record<string, number | number[]>;
        weight?: number;
        origin?: string | null;
        gradient_basis?: string | null;
        telemetry?: Record<string, unknown> | null;
    };

    export type ZSpaceMetricGradientProjectionRequest = {
        metrics: Record<string, number>;
        dimension: number;
    };

    export type ZSpaceMetricGradientProjection = {
        kind: "spiraltorch.zspace_metric_gradient_projection";
        contract_version: "spiraltorch.zspace_metric_gradient_projection.v1";
        semantic_owner: "st-core::telemetry::zspace_fusion";
        semantic_backend: "rust";
        execution_client: "wasm";
        basis: "spiraltorch.zspace.canonical_metric_cycle.v1";
        formula: "g_i=m_(i mod 5),m=[speed,memory,stability,frac,drs]";
        dimension: number;
        base_dimension: 5;
        source_metrics: Record<string, number>;
        coordinate_channels: Array<"speed" | "memory" | "stability" | "frac" | "drs">;
        gradient: number[];
    };

    export type ZSpacePartialFusionRequest = {
        partials: Array<ZSpacePartialInput | null>;
        weights?: number[] | null;
        strategy?: ZSpaceFusionStrategy;
        gradient_alignment?: ZSpaceGradientAlignment;
        metric_gradient_dimension?: number | null;
        telemetry?: Array<Record<string, unknown>>;
    };

    export type ZSpacePartialSourceAudit = {
        index: number;
        origin: string | null;
        weight: number | null;
        status: "active" | "suppressed" | "null";
        metric_count: number;
        gradient_present: boolean;
        gradient_dim: number;
        gradient_basis?: string;
        gradient_replaced_by_metric_projection: boolean;
        gradient_padded: boolean;
        telemetry_entry_count: number;
    };

    export type ZSpacePartialFusion = {
        kind: "spiraltorch.zspace_partial_fusion";
        contract_version: "spiraltorch.zspace_partial_fusion.v3";
        semantic_owner: "st-core::telemetry::zspace_fusion";
        semantic_backend: "rust";
        execution_client: "wasm";
        strategy: ZSpaceFusionStrategy;
        gradient_alignment: ZSpaceGradientAlignment;
        gradient_source: "none" | "explicit" | "canonical_metrics";
        gradient_formula?: string;
        metrics: Record<string, number>;
        gradient?: number[];
        gradient_basis?: string;
        telemetry: ZSpaceTelemetryFusion;
        input_count: number;
        active_count: number;
        suppressed_count: number;
        null_count: number;
        gradient_input_count: number;
        gradient_dim: number;
        metric_gradient_projection_applied: boolean;
        gradient_replaced_source_count: number;
        gradient_padding_applied: boolean;
        gradient_padded_source_count: number;
        sources: ZSpacePartialSourceAudit[];
    };

    export type ZSpaceCoherenceDiagnosticsInput = {
        mean_coherence: number;
        coherence_entropy: number;
        energy_ratio: number;
        z_bias: number;
        fractional_order: number;
        normalized_weights?: number[];
        preserved_channels?: number | null;
        discarded_channels?: number | null;
        dominant_channel?: number | null;
    };

    export type ZSpaceCoherenceDistributionWitness = {
        kind: "spiraltorch.zspace_coherence_distribution_witness";
        contract_version: "spiraltorch.zspace_coherence_distribution_witness.v1";
        semantic_owner: "st-core::inference::zspace_coherence";
        semantic_backend: "rust";
        witness_formula: string;
        normalized_weights: number[];
    };

    export type ZSpaceCoherenceDistributionSummary = {
        channels: number;
        weight_mass: number;
        weight_entropy: number;
        normalized_entropy: number;
        concentration: number;
        effective_channels: number;
    };

    export type ZSpaceCoherenceContourInput = {
        coherence_strength: number;
        prosody_index: number;
        articulation_bias: number;
        timbre_spread?: number | null;
    };

    export type ZSpaceCoherenceProjectionConfig = {
        speed_gain?: number;
        stability_gain?: number;
        frac_gain?: number;
        drs_gain?: number;
    };

    export type ZSpaceCoherenceProjectionRequest = {
        diagnostics: ZSpaceCoherenceDiagnosticsInput;
        coherence?: number[];
        contour?: ZSpaceCoherenceContourInput | null;
        config?: ZSpaceCoherenceProjectionConfig;
        classification_policy?: ZSpaceCoherenceClassificationPolicy;
    };

    export type ZSpaceCoherenceProjectionDerived = {
        channels: number;
        distribution_source: "normalized_weights" | "diagnostic_entropy";
        weight_mass: number;
        weight_entropy: number;
        normalized_entropy: number;
        concentration: number;
        effective_channels: number;
        response_peak: number;
        response_mean: number;
    };

    export type ZSpaceCoherenceLabel =
        | "background"
        | "symmetric_pulse"
        | "cascade_imbalance"
        | "diffuse_drift";

    export type ZSpaceCoherenceClassificationPolicy = {
        background_energy_ratio_max: number;
        cascade_energy_ratio_min: number;
    };

    export type ZSpaceCoherenceClassification = {
        kind: "spiraltorch.zspace_coherence_classification";
        contract_version: "spiraltorch.zspace_coherence_classification.v1";
        semantic_owner: "st-core::inference::zspace_coherence";
        semantic_backend: "rust";
        classification_formula: string;
        label: ZSpaceCoherenceLabel;
        reason: string;
        energy_ratio: number;
        swap_invariant: boolean;
        policy: ZSpaceCoherenceClassificationPolicy;
    };

    export type ZSpaceCoherenceControl = {
        kind: "spiraltorch.zspace_coherence_control";
        contract_version: "spiraltorch.zspace_coherence_control.v1";
        semantic_owner: "st-core::inference::zspace_coherence";
        semantic_backend: "rust";
        control_formula: string;
        channels: number;
        raw_mean_coherence: number;
        raw_coherence_entropy: number;
        spectral_radius: number;
        spectral_entropy: number;
        spectral_pressure: number;
        effective_channels: number;
        energy_ratio: number;
    };

    export type ZSpaceCoherenceProjection = {
        kind: "spiraltorch.zspace_coherence_projection";
        contract_version: "spiraltorch.zspace_coherence_projection.v2";
        semantic_owner: "st-core::inference::zspace_coherence";
        semantic_backend: "rust";
        execution_client: "wasm";
        projection_formula: string;
        summary_formula: string;
        evidence_validation_formula: string;
        diagnostics: ZSpaceCoherenceDiagnosticsInput;
        coherence: number[];
        contour?: ZSpaceCoherenceContourInput;
        config: Required<ZSpaceCoherenceProjectionConfig>;
        derived: ZSpaceCoherenceProjectionDerived;
        classification?: ZSpaceCoherenceClassification;
        control?: ZSpaceCoherenceControl;
        partial: Record<string, number>;
    };

    export type ZSpacePosteriorDecodeRequest = {
        z_state: number[];
        alpha?: number;
    };

    export type ZSpacePosteriorDecode = {
        kind: "spiraltorch.zspace_posterior_decode";
        contract_version: "spiraltorch.zspace_posterior.v2";
        semantic_owner: "st-core::inference::zspace_posterior";
        semantic_backend: "rust";
        execution_client: "wasm";
        metric_formula: string;
        fractional_formula: string;
        spectral_formula: string;
        gradient_formula: string;
        gradient_basis: "spiraltorch.zspace.latent.central_difference.zero_boundary.v1";
        barycentric_formula: string;
        z_state: number[];
        alpha: number;
        metrics: Record<string, number>;
        gradient: number[];
        barycentric: [number, number, number];
        energy: number;
        spectral_energy: number;
        parseval_relative_error: number;
        frac_energy: number;
        fractional_energy_ratio: number;
        spectral_centroid: number;
        spectral_bins: number;
    };

    export type ZSpacePosteriorProjectionRequest = {
        z_state: number[];
        alpha?: number;
        partial?: Record<string, number | number[]>;
        gradient_basis?: string | null;
        smoothing?: number;
        telemetry?: Array<Record<string, unknown>>;
    };

    export type ZSpacePosteriorTelemetryAdjustment = {
        variance_reliability: number;
        focus_reliability: number;
        combined_reliability: number;
        residual_before: number;
        confidence_before: number;
    };

    export type ZSpacePosteriorControlGradient = {
        source: "partial";
        basis: string;
        values: number[];
        dimension: number;
        l2: number;
        linf: number;
    };

    export type ZSpacePosteriorProjection = {
        kind: "spiraltorch.zspace_posterior_projection";
        contract_version: "spiraltorch.zspace_posterior.v2";
        semantic_owner: "st-core::inference::zspace_posterior";
        semantic_backend: "rust";
        execution_client: "wasm";
        projection_formula: string;
        telemetry_formula: string;
        smoothing: number;
        metrics: Record<string, number>;
        gradient: number[];
        gradient_basis: "spiraltorch.zspace.latent.central_difference.zero_boundary.v1";
        gradient_source: "latent_state";
        control_gradient?: ZSpacePosteriorControlGradient;
        barycentric: [number, number, number];
        residual: number;
        residual_metric_count: number;
        confidence: number;
        telemetry_reliability: number;
        applied: Record<string, number | number[]>;
        prior: ZSpacePosteriorDecode;
        telemetry?: ZSpaceTelemetryFusion;
        telemetry_adjustment?: ZSpacePosteriorTelemetryAdjustment;
    };

    export type FreeEnergyBandInput = {
        above: number;
        here: number;
        beneath: number;
    };

    export type FreeEnergyBandPriorInput = Partial<FreeEnergyBandInput>;

    export type FreeEnergyConfigInput = {
        loss_scale?: number;
        step_time_scale_ms?: number;
        memory_scale_mb?: number;
        retry_scale?: number;
        observation_entropy_scale?: number;
        loss_weight?: number;
        speed_weight?: number;
        memory_weight?: number;
        retry_weight?: number;
        uncertainty_weight?: number;
        external_penalty_weight?: number;
        temperature?: number;
        prior?: FreeEnergyBandPriorInput;
        band_potentials?: Partial<FreeEnergyBandInput>;
    };

    export type FreeEnergyObservationInput = {
        reference_loss?: number;
        candidate_loss?: number;
        step_time_ms?: number;
        memory_mb?: number;
        retry_rate?: number;
        observation_entropy?: number;
        external_penalty?: number;
        band?: FreeEnergyBandInput;
    };

    export type FreeEnergyRequest = {
        observation?: FreeEnergyObservationInput;
        config?: FreeEnergyConfigInput;
    };

    export type FreeEnergyReport = {
        kind: "spiraltorch.variational_free_energy";
        contract_version: "spiraltorch.variational_free_energy.v1";
        semantic_owner: "st-core::heur::free_energy";
        semantic_backend: "rust";
        execution_client: "wasm";
        formula: "F(q)=E_observed+(E_q[V]-E_prior[V])+temperature*KL(q||prior)";
        acceptance_rule: "P(accept)=1/(1+exp(F_candidate-F_neutral)),F_neutral=0";
        config: Required<Omit<FreeEnergyConfigInput, "prior" | "band_potentials">> & {
            prior: FreeEnergyBandInput;
            band_potentials: FreeEnergyBandInput;
        };
        observation: Required<Omit<FreeEnergyObservationInput, "band">> & {
            band: FreeEnergyBandInput;
        };
        normalized: {
            loss_delta: number;
            step_time: number;
            memory: number;
            retry: number;
            observation_entropy: number;
            external_penalty: number;
        };
        distribution: {
            status: "normalized" | "prior_zero_mass";
            raw_total: number;
            zero_mass_threshold: number;
            above: number;
            here: number;
            beneath: number;
            prior_above: number;
            prior_here: number;
            prior_beneath: number;
            entropy: number;
            normalized_entropy: number;
            cross_entropy: number;
            kl_divergence: number;
            variational_identity_residual: number;
            dominant_band: "above" | "here" | "beneath";
        };
        components: {
            loss: number;
            speed: number;
            memory: number;
            retry: number;
            uncertainty: number;
            external_penalty: number;
            observed_energy: number;
            band_potential_expectation: number;
            prior_band_potential: number;
            band_potential: number;
            relative_entropy: number;
        };
        free_energy: number;
        utility: number;
        acceptance_probability: number;
        component_sum_residual: number;
    };

    export type ZSpaceMetaOptimizerGradientProjection =
        | "tile_or_truncate"
        | "exact";

    export type ZSpaceMetaOptimizerWeights = {
        speed?: number;
        memory?: number;
        stability?: number;
        fractional?: number;
        drift_response?: number;
    };

    export type ZSpaceMetaOptimizerConfigInput = {
        dimension?: number;
        fractional_order?: number;
        weights?: ZSpaceMetaOptimizerWeights;
        learning_rate?: number;
        first_moment_decay?: number;
        second_moment_decay?: number;
        epsilon?: number;
        topos_control_gain?: number;
        gradient_projection?: ZSpaceMetaOptimizerGradientProjection;
    };

    export type ZSpaceMetaOptimizerConfig = Required<
        Omit<ZSpaceMetaOptimizerConfigInput, "weights">
    > & {
        weights: Required<ZSpaceMetaOptimizerWeights>;
    };

    export type ZSpaceMetaOptimizerState = {
        z: number[];
        first_moment: number[];
        second_moment: number[];
        step: number;
    };

    export type ZSpaceMetaOptimizerObservation = {
        speed?: number;
        memory?: number;
        stability?: number;
        drift_response?: number;
        gradient?: number[];
        telemetry?: Record<string, number>;
    };

    export type ZSpaceMetaOptimizerRestoreRequest = {
        config: ZSpaceMetaOptimizerConfigInput;
        state: ZSpaceMetaOptimizerState;
        strict?: boolean;
    };

    export type ZSpaceMetaOptimizerStepRequest = {
        config: ZSpaceMetaOptimizerConfigInput;
        state: ZSpaceMetaOptimizerState;
        observation: ZSpaceMetaOptimizerObservation;
    };

    export type ZSpaceMetaOptimizerCheckpoint = {
        contract_version: "spiraltorch.zspace_meta_optimizer.v2";
        kind: "spiraltorch.zspace_meta_optimizer";
        semantic_owner: "st-core::runtime::zspace_optimizer";
        semantic_backend: "rust";
        execution_client: "wasm";
        config: ZSpaceMetaOptimizerConfig;
        state: ZSpaceMetaOptimizerState;
    };

    export type ZSpaceMetaOptimizerStepReport = {
        contract_version: "spiraltorch.zspace_meta_optimizer.v2";
        kind: "spiraltorch.zspace_meta_optimizer";
        semantic_owner: "st-core::runtime::zspace_optimizer";
        semantic_backend: "rust";
        execution_client: "wasm";
        objective_formula: "J_obs=sum_i(lambda_i*tanh(metric_i))+lambda_topos*tanh(topos_pressure)+lambda_frac_eff*R_alpha(z)";
        transition_validated: true;
        config: ZSpaceMetaOptimizerConfig;
        observation: Required<ZSpaceMetaOptimizerObservation>;
        objective: {
            normalized_speed: number;
            normalized_memory: number;
            normalized_stability: number;
            normalized_drift_response: number;
            speed_term: number;
            memory_term: number;
            stability_term: number;
            drift_response_term: number;
            topos_term: number;
            fractional_term: number;
            observed_resource_penalty: number;
            objective_before: number;
        };
        fractional_regularizer: {
            formula: string;
            order: number;
            signal_length: number;
            spectral_bins: number;
            energy: number;
            raw_gradient: number[];
            gradient_normalization_scale: number;
            normalized_gradient: number[];
        };
        topos_control: {
            present: boolean;
            active: boolean;
            closure_pressure: number;
            depth_pressure: number;
            volume_pressure: number;
            guard_strength: number;
            step_damping: number;
            sampling_focus: number;
            openness: number;
            exploration_hint: number;
            pressure: number;
            learning_rate_hint: number;
            learning_rate_scale: number;
            effective_learning_rate: number;
            clip_hint: number;
            clip_scale: number;
            gradient_clip_rule: string;
            gradient_clip_normalization: "biased_gradient_rms";
            biased_gradient_rms: number;
            gradient_clip_threshold: number | null;
            regularization_hint: number;
            regularization_scale: number;
            effective_fractional_weight: number;
            gradient_bias_rule: string;
            gradient_bias_normalization: "raw_gradient_rms";
            gradient_bias_scale: number;
            gradient_bias_basis: number[];
            raw_gradient_rms: number;
            gradient_bias_amplitude: number;
            gradient_bias: number[];
        };
        gradient: {
            rule: string;
            source_dimension: number;
            target_dimension: number;
            projection: ZSpaceMetaOptimizerGradientProjection;
            observed: number[];
            projected_normalized: number[];
            before_clip: number[];
            applied: number[];
            clipped_values: number;
        };
        adam: {
            rule: string;
            step: number;
            first_moment_bias_correction: number;
            second_moment_bias_correction: number;
            effective_learning_rate: number;
            parameter_delta: number[];
        };
        state_before: ZSpaceMetaOptimizerState;
        state_after: ZSpaceMetaOptimizerState;
    };

    export type ZSpaceParameterControl = {
        contract_version: "spiraltorch.zspace_parameter_control.v2";
        kind: "spiraltorch.zspace_parameter_control";
        semantic_owner: "st-core::runtime::zspace_optimizer";
        semantic_backend: "rust";
        source_contract_version: "spiraltorch.zspace_meta_optimizer.v2";
        source_semantic_owner: "st-core::runtime::zspace_optimizer";
        source_step: number;
        absolute_learning_rate_scale: number;
        source_learning_rate: number;
        source_effective_learning_rate: number;
        execution_client: "wasm";
    };

    export type ZSpaceParameterTrajectoryRequest = {
        raw_learning_rate_scales: number[];
        nominal_learning_rates: number[][];
    };

    export type ZSpaceParameterTrajectoryStep = {
        index: number;
        nominal_learning_rates: number[];
        nominal_weight: number;
        raw_learning_rate_scale: number;
        dose_matched_constant_scale: number;
        dose_normalized_scale: number;
        raw_weighted_dose: number;
        dose_matched_constant_weighted_dose: number;
        dose_normalized_weighted_dose: number;
        dose_normalized_saturated_min: boolean;
        dose_normalized_saturated_max: boolean;
    };

    export type ZSpaceParameterTrajectoryReport = {
        contract_version: "spiraltorch.zspace_parameter_trajectory.v1";
        kind: "spiraltorch.zspace_parameter_trajectory";
        semantic_owner: "st-core::runtime::zspace_optimizer";
        semantic_backend: "rust";
        execution_client: "wasm";
        trajectory_validated: true;
        trajectory_id: string;
        normalization_rule: string;
        constant_rule: string;
        minimum_learning_rate_scale: number;
        maximum_learning_rate_scale: number;
        request: ZSpaceParameterTrajectoryRequest;
        step_count: number;
        parameter_group_count: number;
        identity_relative_tolerance: number;
        identity_absolute_tolerance: number;
        raw_non_identity_update_count: number;
        dose_matched_constant_non_identity_update_count: number;
        dose_normalized_non_identity_update_count: number;
        nominal_dose: number;
        raw_dose: number;
        raw_dose_ratio: number;
        dose_matched_constant_scale: number;
        dose_matched_constant_dose: number;
        dose_normalization_factor: number;
        dose_normalized_dose: number;
        dose_normalized_dose_ratio: number;
        dose_normalized_residual: number;
        dose_invariant_tolerance: number;
        dose_normalized_saturated_min_count: number;
        dose_normalized_saturated_max_count: number;
        steps: ZSpaceParameterTrajectoryStep[];
    };

    export type ZSpaceParameterTrajectoryPolicy =
        "dose_preserving_complement";

    export type ZSpaceParameterTrajectoryPolicyStep = {
        index: number;
        nominal_learning_rates: number[];
        nominal_weight: number;
        raw_learning_rate_scale: number;
        centered_raw_residual: number;
        planned_learning_rate_scale: number;
        planned_weighted_dose: number;
        planned_saturated_min: boolean;
        planned_saturated_max: boolean;
    };

    export type ZSpaceParameterTrajectoryPolicyReport = {
        contract_version: "spiraltorch.zspace_parameter_trajectory_policy.v1";
        kind: "spiraltorch.zspace_parameter_trajectory_policy";
        semantic_owner: "st-core::runtime::zspace_optimizer";
        semantic_backend: "rust";
        execution_client: "wasm";
        policy_validated: true;
        policy_id: string;
        request: {
            source_trajectory_id: string;
            source_request: ZSpaceParameterTrajectoryRequest;
            policy: ZSpaceParameterTrajectoryPolicy;
        };
        source_trajectory_contract_version: "spiraltorch.zspace_parameter_trajectory.v1";
        source_trajectory_id: string;
        policy: ZSpaceParameterTrajectoryPolicy;
        policy_rule: string;
        minimum_learning_rate_scale: number;
        maximum_learning_rate_scale: number;
        step_count: number;
        parameter_group_count: number;
        identity_relative_tolerance: number;
        identity_absolute_tolerance: number;
        weighted_raw_center: number;
        polarity_gain: number;
        nominal_dose: number;
        planned_dose: number;
        planned_dose_ratio: number;
        planned_dose_residual: number;
        dose_invariant_tolerance: number;
        planned_non_identity_update_count: number;
        planned_saturated_min_count: number;
        planned_saturated_max_count: number;
        steps: ZSpaceParameterTrajectoryPolicyStep[];
    };

    export type ZSpacePolarityEvidenceRow = {
        corpus_id: string;
        seed: number;
        dose_normalized_shape_effect: number;
        complement_shape_effect: number;
        polarity_effect: number;
    };

    export type ZSpacePolarityEvidenceRequest = {
        protocol_id: string;
        runtime_identity_id: string;
        trajectory_id: string;
        trajectory_policy_id: string;
        control_sequence_id: string;
        nominal_schedule_sequence_id: string;
        rows: ZSpacePolarityEvidenceRow[];
    };

    export type ZSpacePolarityEvidenceDirection =
        | "left_arm_better"
        | "right_arm_better"
        | "no_observed_difference"
        | "mixed";

    export type ZSpacePolaritySeedContrast = {
        seed: number;
        value: number;
    };

    export type ZSpacePolarityCorpusContrastSummary = {
        corpus_id: string;
        seed_count: number;
        mean: number;
        left_arm_win_count: number;
        right_arm_win_count: number;
        tie_count: number;
        values: ZSpacePolaritySeedContrast[];
    };

    export type ZSpacePolarityContrastSummary = {
        left_arm: string;
        right_arm: string;
        lower_is_better: true;
        observation_count: number;
        corpus_count: number;
        seed_count_per_corpus: number;
        pooled_seed_mean: number;
        corpus_equal_weight_mean: number;
        corpus_mean_minimum: number;
        corpus_mean_maximum: number;
        corpus_mean_population_standard_deviation: number;
        seed_left_arm_win_count: number;
        seed_right_arm_win_count: number;
        seed_tie_count: number;
        corpus_left_arm_win_count: number;
        corpus_right_arm_win_count: number;
        corpus_tie_count: number;
        bounded_trend_ready: boolean;
        bounded_trend_direction: ZSpacePolarityEvidenceDirection;
        corpora: ZSpacePolarityCorpusContrastSummary[];
    };

    export type ZSpacePolarityEvidenceReport = {
        contract_version: "spiraltorch.zspace_polarity_evidence.v1";
        kind: "spiraltorch.zspace_polarity_evidence";
        semantic_owner: "st-core::runtime::zspace_evidence";
        semantic_backend: "rust";
        execution_client: "wasm";
        evidence_validated: true;
        evidence_id: string;
        status: "ready";
        request: ZSpacePolarityEvidenceRequest;
        aggregation_rule: string;
        contrast_rule: string;
        corpus_count: number;
        seed_count_per_corpus: number;
        observation_count: number;
        corpus_ids: string[];
        seeds: number[];
        evidence_scope: string;
        contrasts: Record<
            | "dose_normalized_shape_effect"
            | "complement_shape_effect"
            | "polarity_effect",
            ZSpacePolarityContrastSummary
        >;
        bounded_polarity_improvement_observed: boolean;
        bounded_baseline_improvement_observed: boolean;
        efficacy_claim_ready: false;
        evidence_boundary: string;
        efficacy_claim_requirements: string;
    };

    export type ZSpaceOptimizerFeedbackConfigInput = {
        loss_ema_alpha?: number;
        relative_delta_ema_alpha?: number;
        loss_floor?: number;
        regression_threshold?: number;
        halt_threshold?: number;
        recovery_threshold?: number;
        attenuation_rate?: number;
        recovery_rate?: number;
        halt_regression_streak?: number;
        resume_improvement_streak?: number;
        warmup_observations?: number;
        max_stale_updates?: number;
        maximum_gate?: number;
    };

    export type ZSpaceOptimizerFeedbackConfig =
        Required<ZSpaceOptimizerFeedbackConfigInput>;

    export type ZSpaceOptimizerFeedbackState = {
        control_step: number;
        observation_count: number;
        last_observation_step: number | null;
        last_loss: number | null;
        loss_ema: number | null;
        relative_loss_delta_ema: number | null;
        gate: number;
        regression_streak: number;
        improvement_streak: number;
        halted: boolean;
    };

    export type ZSpaceOptimizerFeedbackObservation = {
        step: number;
        max_steps?: number | null;
        epoch?: number | null;
        loss: number;
        grad_norm?: number | null;
        learning_rate?: number | null;
    };

    export type ZSpaceOptimizerFeedbackRestoreRequest = {
        config: ZSpaceOptimizerFeedbackConfigInput;
        state: ZSpaceOptimizerFeedbackState;
    };

    export type ZSpaceOptimizerFeedbackObserveRequest =
        ZSpaceOptimizerFeedbackRestoreRequest & {
            observation: ZSpaceOptimizerFeedbackObservation;
        };

    export type ZSpaceOptimizerFeedbackControlRequest =
        ZSpaceOptimizerFeedbackRestoreRequest & {
            target_step: number;
            proposed_learning_rate_scale: number;
        };

    export type TrainingTelemetryProjection = {
        kind: "spiraltorch.training_telemetry_projection";
        contract_version: "spiraltorch.training_telemetry_projection.v1";
        semantic_owner: "st-core::telemetry::training_projection";
        semantic_backend: "rust";
        signal_source: "trainer_log_proxy";
        signal_semantics: "surrogate";
        step: number | null;
        max_steps: number | null;
        epoch: number | null;
        progress: number | null;
        loss: number | null;
        previous_loss: number | null;
        loss_delta: number | null;
        loss_improvement: number | null;
        grad_norm: number | null;
        learning_rate: number | null;
        desire: {
            gain: number;
            pressure: number | null;
            stability: number | null;
            saturation: number | null;
            improvement_pressure: number | null;
        };
        psi: {
            gain: number;
            total: number | null;
            loss_component: number | null;
            gradient_component: number | null;
            learning_rate_component: number | null;
        };
        telemetry: Record<string, number>;
        observation_count: number;
        psi_component_count: number;
    };

    export type ZSpaceOptimizerFeedbackCheckpoint = {
        contract_version: "spiraltorch.zspace_optimizer_feedback.v1";
        kind: "spiraltorch.zspace_optimizer_feedback";
        semantic_owner: "st-core::runtime::zspace_optimizer_feedback";
        semantic_backend: "rust";
        execution_client: "wasm";
        config: ZSpaceOptimizerFeedbackConfig;
        state: ZSpaceOptimizerFeedbackState;
    };

    export type ZSpaceOptimizerFeedbackObservationReport = {
        contract_version: "spiraltorch.zspace_optimizer_feedback.v1";
        kind: "spiraltorch.zspace_optimizer_feedback";
        semantic_owner: "st-core::runtime::zspace_optimizer_feedback";
        semantic_backend: "rust";
        execution_client: "wasm";
        transition_validated: true;
        config: ZSpaceOptimizerFeedbackConfig;
        observation: ZSpaceOptimizerFeedbackObservation;
        projection: TrainingTelemetryProjection;
        relative_loss_delta: number | null;
        relative_loss_delta_ema: number | null;
        action:
            | "initialize"
            | "warmup"
            | "hold"
            | "recover"
            | "attenuate"
            | "halt"
            | "hold_halted";
        gate_before: number;
        gate_after: number;
        state_before: ZSpaceOptimizerFeedbackState;
        state_after: ZSpaceOptimizerFeedbackState;
    };

    export type ZSpaceOptimizerFeedbackControlReport = {
        contract_version: "spiraltorch.zspace_optimizer_feedback.v1";
        kind: "spiraltorch.zspace_optimizer_feedback";
        semantic_owner: "st-core::runtime::zspace_optimizer_feedback";
        semantic_backend: "rust";
        execution_client: "wasm";
        control_rule: "applied_scale=1+effective_gate*(proposed_scale-1)";
        transition_validated: true;
        config: ZSpaceOptimizerFeedbackConfig;
        target_step: number;
        proposed_learning_rate_scale: number;
        proposed_deviation_from_identity: number;
        feedback_observation_age_updates: number | null;
        feedback_gate: number;
        effective_feedback_gate: number;
        applied_learning_rate_scale: number;
        applied_deviation_from_identity: number;
        identity_applied: boolean;
        disposition:
            | "no_feedback"
            | "warmup"
            | "halted"
            | "stale"
            | "identity_gate"
            | "active";
        state_before: ZSpaceOptimizerFeedbackState;
        state_after: ZSpaceOptimizerFeedbackState;
    };

    export type WasmReportRuntimeAudit = {
        status: "webgpu_ready" | "webgpu_available" | "wasm_only" | "missing_runtime";
        score: number;
        wasm: boolean;
        webgpu_available: boolean;
        webgpu_device_ready: boolean;
        webgpu_component_ready_count: number;
        webgpu_init_failed: boolean;
    };

    export type WasmReportLearningAudit = {
        source: "trace" | "loss_stats" | "missing";
        loss: number | null;
        first_loss: number | null;
        last_loss: number | null;
        absolute_improvement: number | null;
        relative_improvement: number | null;
        improved: boolean | null;
        progress_score: number;
    };

    export type WasmReportAudit = {
        kind: "spiraltorch.wasm_report_audit";
        schema: string;
        report_kind: string;
        family: "mellin" | "canvas" | "unknown";
        artifact_path: string | null;
        status: WasmReportAuditStatus;
        readiness_score: number;
        runtime: WasmReportRuntimeAudit;
        learning: WasmReportLearningAudit;
        loss_score: number;
        stability_score: number;
        risk_flags: string[];
        recommendations: string[];
    };

    export type WasmReportComparisonRow = {
        label: string;
        schema: string;
        kind: string;
        family: "mellin" | "canvas" | "unknown";
        loss: number | null;
        stability: number | null;
        readiness_score: number | null;
        audit_status: WasmReportAuditStatus;
        risk_flags: string[];
        audit: WasmReportAudit;
    };

    export type WasmReportComparison = {
        kind: "spiraltorch.wasm_report_comparison";
        count: number;
        families: Record<string, number>;
        best_loss: WasmReportComparisonRow | null;
        best_stability: WasmReportComparisonRow | null;
        best_readiness: WasmReportComparisonRow | null;
        reports: WasmReportComparisonRow[];
    };

    export type ScaleStackProbeMode = "scalar" | "semantic::euclidean" | "semantic::cosine";

    export type ScaleStackProbeSample = {
        scale: number;
        gate_mean: number;
    };

    export type ScaleStackPersistenceBin = {
        scale_low: number;
        scale_high: number;
        mass: number;
    };

    export type ScaleStackCoherenceBreak = {
        level: number;
        scale: number | null;
    };

    export type ScaleStackProbe = {
        kind: "spiraltorch.wasm_scale_stack_probe";
        source_crate: "st-frac::scale_stack";
        mode: ScaleStackProbeMode;
        threshold: number;
        sample_count: number;
        samples: ScaleStackProbeSample[];
        persistence: ScaleStackPersistenceBin[];
        interface_density: number | null;
        moment_0: number;
        moment_1: number;
        moment_2: number;
        boundary_dimension: number | null;
        coherence_profile: ScaleStackCoherenceBreak[];
    };

    export type FractalFieldGeneratorConfig = {
        octaves: number;
        lacunarity: number;
        gain: number;
        iterations: number;
    };

    export type FractalFieldLogLattice = {
        log_start: number;
        log_step: number;
        len: number;
        support: [number, number];
    };

    export type FractalFieldProbeSample = {
        index: number;
        log: number;
        re: number;
        im: number;
        abs: number;
        phase: number;
    };

    export type FractalFieldProbe = {
        kind: "spiraltorch.wasm_fractal_field_probe";
        source_crate: "st-frac::fractal_field";
        mode: "branching_field";
        generator: FractalFieldGeneratorConfig;
        log_lattice: FractalFieldLogLattice;
        sample_count: number;
        preview_count: number;
        energy: number;
        mean_abs: number;
        max_abs: number;
        mean_real: number;
        mean_imag: number;
        phase_drift: number;
        total_variation: number;
        coherence_score: number;
        samples: FractalFieldProbeSample[];
    };

    export type LogZSeriesWindow = "rectangular" | "hann";
    export type LogZSeriesNormalisation = "none" | "l1" | "l2";

    export type LogZSeriesLattice = {
        log_start: number;
        log_step: number;
        len: number;
        support: [number, number];
    };

    export type LogZSeriesScalarStats = {
        count: number;
        mean: number;
        min: number;
        max: number;
        energy: number;
    };

    export type LogZSeriesProjectionPreview = {
        index: number;
        re: number;
        im: number;
        abs: number;
        phase: number;
    };

    export type LogZSeriesProjectionStats = {
        count: number;
        mean_abs: number;
        max_abs: number;
        energy: number;
        phase_drift: number;
        stability_score: number;
        preview_count: number;
        preview: LogZSeriesProjectionPreview[];
    };

    export type LogZSeriesProbe = {
        kind: "spiraltorch.wasm_log_z_series_probe";
        source_crate: "st-frac::cosmology";
        mode: "log_z_series";
        log_lattice: LogZSeriesLattice;
        options: {
            window: LogZSeriesWindow;
            normalisation: LogZSeriesNormalisation;
        };
        sample_count: number;
        sample_stats: LogZSeriesScalarStats;
        weight_stats: LogZSeriesScalarStats;
        z_count: number;
        projection: LogZSeriesProjectionStats;
    };

    /** Labels emitted by {@link CanvasDesireControl.eventLabels}. */
    export type DesireControlEventLabel =
        | "lr_increase"
        | "lr_decrease"
        | "lr_clipped"
        | "temperature_suppress"
        | "quality_weight"
        | "quality_suppress"
        | "z_suppress"
        | "lr_slew_limit";

    export class CanvasFftLayout {
        private constructor();
        readonly fieldBytes: number;
        readonly fieldStride: number;
        readonly spectrumBytes: number;
        readonly spectrumStride: number;
        readonly uniformBytes: number;
    }

    export class CanvasGradientSummary {
        private constructor();
        readonly hypergradL1: number;
        readonly hypergradL2: number;
        readonly hypergradLInf: number;
        readonly hypergradMeanAbs: number;
        readonly hypergradRms: number;
        readonly hypergradCount: number;
        readonly realgradL1: number;
        readonly realgradL2: number;
        readonly realgradLInf: number;
        readonly realgradMeanAbs: number;
        readonly realgradRms: number;
        readonly realgradCount: number;
    }

    export class CanvasDesireInterpretation {
        private constructor();
        readonly hyperPressure: number;
        readonly realPressure: number;
        readonly balance: number;
        readonly stability: number;
        readonly saturation: number;
        readonly penaltyGain: number;
        readonly biasMix: number;
        readonly observationGain: number;
    }

    export class CanvasDesireControl {
        private constructor();
        readonly penaltyGain: number;
        readonly biasMix: number;
        readonly observationGain: number;
        readonly damping: number;
        readonly hyperLearningRateScale: number;
        readonly realLearningRateScale: number;
        readonly operatorMix: number;
        readonly operatorGain: number;
        readonly tuningGain: number;
        readonly targetEntropy: number;
        readonly learningRateEta: number;
        readonly learningRateMin: number;
        readonly learningRateMax: number;
        readonly learningRateSlew: number;
        readonly clipNorm: number;
        readonly clipFloor: number;
        readonly clipCeiling: number;
        readonly clipEma: number;
        readonly temperatureKappa: number;
        readonly temperatureSlew: number;
        readonly qualityGain: number;
        readonly qualityBias: number;
        eventsMask(): number;
        eventLabels(): DesireControlEventLabel[];
    }

    export class CanvasFramePacket {
        private constructor();
        readonly width: number;
        readonly height: number;
        readonly pixels: Uint8Array;
        readonly relation: Float32Array;
        readonly field: Float32Array;
        readonly trail: Float32Array;
        readonly hypergradRms: number;
        readonly realgradRms: number;
        readonly hypergradCount: number;
        readonly realgradCount: number;
        readonly balance: number;
        readonly stability: number;
        readonly saturation: number;
        readonly hyperLearningRateScale: number;
        readonly realLearningRateScale: number;
        readonly operatorMix: number;
        readonly operatorGain: number;
        readonly eventsMask: number;
    }

    export class FractalCanvas {
        constructor(capacity: number, width: number, height: number);
        readonly width: number;
        readonly height: number;
        framePacket(curvature: number): CanvasFramePacket;
        push_patch(
            relation: Float32Array,
            coherence: number,
            tension: number,
            depth: number,
        ): void;
        render_to_canvas(canvas: HTMLCanvasElement): void;
        pixels(): Uint8Array;
        vector_field(): Float32Array;
        vectorFieldFft(inverse: boolean): Float32Array;
        emitWasmTrail(curvature: number): Float32Array;
        relation(): Float32Array;
        hypergradWave(curvature: number): Float32Array;
        hypergradWaveCurrent(curvature: number): Float32Array;
        realgradWave(): Float32Array;
        realgradWaveCurrent(): Float32Array;
        gradientSummary(curvature: number): CanvasGradientSummary;
        desireInterpretation(curvature: number): CanvasDesireInterpretation;
        desireControl(curvature: number): CanvasDesireControl;
        desireControlUniform(curvature: number): Uint32Array;
        vectorFieldFftKernel(subgroup: boolean): string;
        vectorFieldFftUniform(inverse: boolean): Uint32Array;
        vectorFieldFftDispatch(subgroup: boolean): Uint32Array;
        hypergradOperatorKernel(subgroup: boolean): string;
        hypergradOperatorUniform(mix: number, gain: number): Float32Array;
        hypergradOperatorUniformFromControl(control: CanvasDesireControl): Float32Array;
        hypergradOperatorUniformAuto(curvature: number): Float32Array;
        hypergradOperatorDispatch(subgroup: boolean): Uint32Array;
        vectorFieldFftLayout(): CanvasFftLayout;
        reset_normalizer(): void;
        set_palette(name: CanvasPaletteName): void;
        palette(): CanvasPaletteCanonicalName;
    }

    export function available_palettes(): CanvasPaletteCanonicalName[];

    export function auditWasmReportJson(reportJson: string): string;
    export function auditWasmReportObject(report: unknown): WasmReportAudit;
    export function compareWasmReportsJson(reportsJson: string): string;
    export function compareWasmReportsObject(reports: unknown): WasmReportComparison;
    export function toposRuntimeRouteJson(profileJson: string): string;
    export function toposRuntimeRouteObject(
        profile: ToposRuntimeProfileInput,
    ): ToposRuntimeRoute;
    export function runtimeDeviceProbeJson(requestJson: string): string;
    export function runtimeDeviceProbeObject(
        request: RuntimeDeviceProbeRequest,
    ): RuntimeDeviceProbe;
    export function runtimeDeviceProbeObserveJson(requestJson: string): string;
    export function runtimeDeviceProbeObserveObject(
        request: RuntimeDeviceProbeObservationRequest,
    ): RuntimeDeviceProbe;
    export function runtimeDeviceProbeValidateJson(payloadJson: string): string;
    export function runtimeDeviceProbeValidateObject(
        payload: RuntimeDeviceProbe,
    ): RuntimeDeviceProbe;
    export function runtimeDeviceProbeValidateAgainstJson(
        payloadJson: string,
        requestJson: string,
    ): string;
    export function runtimeDeviceProbeValidateAgainstObject(
        payload: RuntimeDeviceProbe,
        request: RuntimeDeviceProbeRequest,
    ): RuntimeDeviceProbe;
    export function runtimeDeviceRouteJson(requestJson: string): string;
    export function runtimeDeviceRouteObject(
        request: RuntimeDeviceRouteRequest,
    ): RuntimeDeviceRoute;
    export function runtimeDeviceRouteFromProbesJson(requestJson: string): string;
    export function runtimeDeviceRouteFromProbesObject(
        request: RuntimeDeviceRouteProbeRequest,
    ): RuntimeDeviceRoute;
    export function runtimeDeviceRouteValidateJson(payloadJson: string): string;
    export function runtimeDeviceRouteValidateObject(
        payload: RuntimeDeviceRoute,
    ): RuntimeDeviceRoute;
    export function runtimeDeviceRouteValidateAgainstJson(
        payloadJson: string,
        requestJson: string,
    ): string;
    export function runtimeDeviceRouteValidateAgainstObject(
        payload: RuntimeDeviceRoute,
        request: RuntimeDeviceRouteRequest,
    ): RuntimeDeviceRoute;
    export function runtimeExecutionPlanJson(requestJson: string): string;
    export function runtimeExecutionPlanObject(
        request: RuntimeExecutionPlanRequestInput,
    ): RuntimeExecutionPlan;
    export function runtimeExecutionPlanObserveCapabilitiesJson(requestJson: string): string;
    export function runtimeExecutionPlanObserveCapabilitiesObject(
        request: RuntimeExecutionPlanRequestInput,
    ): RuntimeExecutionPlanRequest;
    export function runtimeExecutionPlanValidateJson(payloadJson: string): string;
    export function runtimeExecutionPlanValidateObject(
        payload: RuntimeExecutionPlan,
    ): RuntimeExecutionPlan;
    export function runtimeExecutionPlanValidateAgainstJson(
        payloadJson: string,
        requestJson: string,
    ): string;
    export function runtimeExecutionPlanValidateAgainstObject(
        payload: RuntimeExecutionPlan,
        request: RuntimeExecutionPlanRequestInput,
    ): RuntimeExecutionPlan;
    export function tensorExecutionReceiptValidateJson(receiptJson: string): string;
    export function tensorExecutionReceiptValidateObject(
        receipt: TensorExecutionReceipt,
    ): TensorExecutionReceipt;
    export function tensorExecutionReceiptValidateAgainstRuntimePlanJson(
        receiptJson: string,
        runtimePlanJson: string,
    ): string;
    export function tensorExecutionReceiptValidateAgainstRuntimePlanObject(
        receipt: TensorExecutionReceipt,
        runtimePlan: RuntimeExecutionPlan,
    ): TensorExecutionReceipt;
    export function trainerOptimizerConfigJson(configJson: string): string;
    export function trainerOptimizerConfigObject(
        config: TrainerOptimizerConfig,
    ): TrainerOptimizerConfigContract;
    export function trainerOptimizerCheckpointJson(checkpointJson: string): string;
    export function trainerOptimizerCheckpointObject(
        checkpoint: TrainerOptimizerCheckpoint,
    ): TrainerOptimizerCheckpointValidation;
    export function trainerExternalStateCheckpointJson(checkpointJson: string): string;
    export function trainerExternalStateCheckpointObject(
        checkpoint: TrainerExternalStateCheckpoint,
    ): TrainerExternalStateCheckpointValidation;
    export function trainerRuntimeCheckpointBundleJson(bundleJson: string): string;
    export function trainerRuntimeCheckpointBundleObject(
        bundle: TrainerRuntimeCheckpointBundle,
    ): TrainerRuntimeCheckpointValidation;
    export function rankPlanJson(requestJson: string): string;
    export function rankPlanObject(request: RankPlanRequest): RankPlanContract;
    export function apiLlmRoutePolicyEvaluateJson(requestJson: string): string;
    export function apiLlmRoutePolicyEvaluateObject(
        request: ApiLlmRoutePolicyEvaluationRequest,
    ): ApiLlmRoutePolicyEvaluation;
    export function toposRoutePolicyEvaluateJson(requestJson: string): string;
    export function toposRoutePolicyEvaluateObject(
        request: ToposRoutePolicyEvaluationRequest,
    ): ToposRoutePolicyEvaluation;
    export function toposRoutePolicyRewardsJson(requestJson: string): string;
    export function toposRoutePolicyRewardsObject(
        request: ToposRouteRewardsRequest,
    ): ToposRouteRewards;
    export function toposRoutePolicyResolveJson(requestJson: string): string;
    export function toposRoutePolicyResolveObject(
        request: ToposRoutePolicyResolveRequest,
    ): ToposRoutePolicyResolution;
    export function toposControlSignalJson(inputJson: string): string;
    export function toposControlSignalObject(
        input: ToposControlSignalInput,
    ): ToposControlSignal;
    export function toposOptimizerSnapshotJson(inputJson: string): string;
    export function toposOptimizerSnapshotObject(
        input: ToposOptimizerSnapshotRequest,
    ): ToposOptimizerSnapshot;
    export function toposZSpaceProjectionJson(
        inputJson: string,
        gradientDim: number,
    ): string;
    export function toposZSpaceProjectionObject(
        input: ToposControlSignalInput,
        gradientDim: number,
    ): ToposZSpaceProjection;
    export function zspaceTelemetryFusionJson(payloadsJson: string): string;
    export function zspaceTelemetryFusionObject(
        payloads: Array<Record<string, unknown>>,
    ): ZSpaceTelemetryFusion;
    export function zspacePartialFusionJson(requestJson: string): string;
    export function zspacePartialFusionObject(
        request: ZSpacePartialFusionRequest,
    ): ZSpacePartialFusion;
    export function zspaceMetricGradientProjectionJson(requestJson: string): string;
    export function zspaceMetricGradientProjectionObject(
        request: ZSpaceMetricGradientProjectionRequest,
    ): ZSpaceMetricGradientProjection;
    export function zspaceCoherenceProjectJson(requestJson: string): string;
    export function zspaceCoherenceProjectObject(
        request: ZSpaceCoherenceProjectionRequest,
    ): ZSpaceCoherenceProjection;
    export function zspaceCoherenceDistributionWitnessJson(
        normalizedWeightsJson: string,
    ): string;
    export function zspaceCoherenceDistributionWitnessObject(
        normalizedWeights: number[],
    ): ZSpaceCoherenceDistributionWitness;
    export function zspaceCoherenceDistributionValidateJson(
        witnessJson: string,
    ): string;
    export function zspaceCoherenceDistributionValidateObject(
        witness: ZSpaceCoherenceDistributionWitness,
    ): ZSpaceCoherenceDistributionSummary;
    export function zspacePosteriorDecodeJson(requestJson: string): string;
    export function zspacePosteriorDecodeObject(
        request: ZSpacePosteriorDecodeRequest,
    ): ZSpacePosteriorDecode;
    export function zspacePosteriorProjectJson(requestJson: string): string;
    export function zspacePosteriorProjectObject(
        request: ZSpacePosteriorProjectionRequest,
    ): ZSpacePosteriorProjection;
    export function zspaceFreeEnergyJson(requestJson: string): string;
    export function zspaceFreeEnergyObject(
        request: FreeEnergyRequest,
    ): FreeEnergyReport;
    export function zspaceMetaOptimizerInitJson(configJson: string): string;
    export function zspaceMetaOptimizerInitObject(
        config: ZSpaceMetaOptimizerConfigInput,
    ): ZSpaceMetaOptimizerCheckpoint;
    export function zspaceMetaOptimizerRestoreJson(requestJson: string): string;
    export function zspaceMetaOptimizerRestoreObject(
        request: ZSpaceMetaOptimizerRestoreRequest,
    ): ZSpaceMetaOptimizerCheckpoint;
    export function zspaceMetaOptimizerStepJson(requestJson: string): string;
    export function zspaceMetaOptimizerStepObject(
        request: ZSpaceMetaOptimizerStepRequest,
    ): ZSpaceMetaOptimizerStepReport;
    export function zspaceMetaOptimizerParameterControlJson(
        reportJson: string,
    ): string;
    export function zspaceMetaOptimizerParameterControlObject(
        report: ZSpaceMetaOptimizerStepReport,
    ): ZSpaceParameterControl;
    export function zspaceParameterTrajectoryJson(requestJson: string): string;
    export function zspaceParameterTrajectoryObject(
        request: ZSpaceParameterTrajectoryRequest,
    ): ZSpaceParameterTrajectoryReport;
    export function zspaceParameterTrajectoryValidateJson(reportJson: string): string;
    export function zspaceParameterTrajectoryValidateObject(
        report: ZSpaceParameterTrajectoryReport,
    ): ZSpaceParameterTrajectoryReport;
    export function zspaceParameterTrajectoryPolicyJson(
        sourceReportJson: string,
        policy: ZSpaceParameterTrajectoryPolicy,
    ): string;
    export function zspaceParameterTrajectoryPolicyObject(
        sourceReport: ZSpaceParameterTrajectoryReport,
        policy: ZSpaceParameterTrajectoryPolicy,
    ): ZSpaceParameterTrajectoryPolicyReport;
    export function zspaceParameterTrajectoryPolicyValidateJson(
        reportJson: string,
    ): string;
    export function zspaceParameterTrajectoryPolicyValidateObject(
        report: ZSpaceParameterTrajectoryPolicyReport,
    ): ZSpaceParameterTrajectoryPolicyReport;
    export function zspacePolarityEvidenceJson(requestJson: string): string;
    export function zspacePolarityEvidenceObject(
        request: ZSpacePolarityEvidenceRequest,
    ): ZSpacePolarityEvidenceReport;
    export function zspacePolarityEvidenceValidateJson(reportJson: string): string;
    export function zspacePolarityEvidenceValidateObject(
        report: ZSpacePolarityEvidenceReport,
    ): ZSpacePolarityEvidenceReport;
    export function zspaceOptimizerFeedbackInitJson(configJson: string): string;
    export function zspaceOptimizerFeedbackInitObject(
        config: ZSpaceOptimizerFeedbackConfigInput,
    ): ZSpaceOptimizerFeedbackCheckpoint;
    export function zspaceOptimizerFeedbackRestoreJson(requestJson: string): string;
    export function zspaceOptimizerFeedbackRestoreObject(
        request: ZSpaceOptimizerFeedbackRestoreRequest,
    ): ZSpaceOptimizerFeedbackCheckpoint;
    export function zspaceOptimizerFeedbackObserveJson(requestJson: string): string;
    export function zspaceOptimizerFeedbackObserveObject(
        request: ZSpaceOptimizerFeedbackObserveRequest,
    ): ZSpaceOptimizerFeedbackObservationReport;
    export function zspaceOptimizerFeedbackControlJson(requestJson: string): string;
    export function zspaceOptimizerFeedbackControlObject(
        request: ZSpaceOptimizerFeedbackControlRequest,
    ): ZSpaceOptimizerFeedbackControlReport;

    export function scalarScaleStackProbeJson(
        field: Float32Array,
        shape: Uint32Array,
        scales: Float32Array,
        threshold: number,
        ambientDim: number,
        dimensionWindow: number,
        levels: Float32Array,
    ): string;

    export function scalarScaleStackProbeObject(
        field: Float32Array,
        shape: Uint32Array,
        scales: Float32Array,
        threshold: number,
        ambientDim: number,
        dimensionWindow: number,
        levels: Float32Array,
    ): ScaleStackProbe;

    export function semanticScaleStackProbeJson(
        embeddings: Float32Array,
        rows: number,
        dims: number,
        scales: Float32Array,
        threshold: number,
        metric: "euclidean" | "cosine",
        ambientDim: number,
        dimensionWindow: number,
        levels: Float32Array,
    ): string;

    export function semanticScaleStackProbeObject(
        embeddings: Float32Array,
        rows: number,
        dims: number,
        scales: Float32Array,
        threshold: number,
        metric: "euclidean" | "cosine",
        ambientDim: number,
        dimensionWindow: number,
        levels: Float32Array,
    ): ScaleStackProbe;

    export type WasmFftPlanObject = {
        radix: number;
        tile_cols: number;
        segments: number;
        subgroup: boolean;
    };

    export type WasmFftDispatch = {
        stage_index: number;
        kind: "bit_reverse" | "butterfly";
        entry_point: "fft_bit_reverse" | "fft_stage";
        radix: number;
        span: number;
        workgroups: [number, number, number];
        source: "primary" | "scratch";
        destination: "primary" | "scratch";
    };

    export type WasmFftDispatchManifest = {
        kind: "spiraltorch.fft_plan";
        contract_version: "spiraltorch.fft_plan.v1";
        semantic_owner: "st-core::backend::spiralk_fft";
        semantic_backend: "rust";
        radix: number;
        tile_cols: number;
        segments: number;
        subgroup: boolean;
        workgroup_size: number;
        dispatches: WasmFftDispatch[];
        output_buffer: "primary" | "scratch";
    };

    export class WasmFftPlan {
        constructor(radix: number, tileCols: number, segments: number, subgroup: boolean);
        readonly radix: number;
        readonly tileCols: number;
        readonly segments: number;
        readonly subgroup: boolean;
        workgroupSize(): number;
        wgsl(): string;
        spiralkHint(): string;
        dispatchManifestJson(): string;
        dispatchManifestObject(): WasmFftDispatchManifest;
        toJson(): string;
        toObject(): WasmFftPlanObject;
        static fromJson(json: string): WasmFftPlan;
        static fromObject(value: unknown): WasmFftPlan;
    }

    export function auto_plan_fft(
        rows: number,
        cols: number,
        k: number,
        subgroup: boolean,
    ): WasmFftPlan | undefined;

    export function auto_fft_wgsl(
        rows: number,
        cols: number,
        k: number,
        subgroup: boolean,
    ): string | undefined;

    export function auto_fft_spiralk(
        rows: number,
        cols: number,
        k: number,
        subgroup: boolean,
    ): string | undefined;

    export function auto_fft_plan_json(
        rows: number,
        cols: number,
        k: number,
        subgroup: boolean,
    ): string | undefined;

    export function auto_fft_plan_object(
        rows: number,
        cols: number,
        k: number,
        subgroup: boolean,
    ): WasmFftPlanObject | undefined;

    export function fft_forward(buffer: Float32Array): Float32Array;
    export function fft_inverse(buffer: Float32Array): Float32Array;
    export function fft_forward_in_place(buffer: Float32Array): void;
    export function fft_inverse_in_place(buffer: Float32Array): void;

    export type LogLatticeWindow =
        | "rect"
        | "rectangular"
        | "none"
        | "hann"
        | "tukey"
        | "blackman";

    export type ComplexArrayPair = [Float32Array, Float32Array];

    export class WasmMellinEvalPlan {
        private constructor();
        static many(
            log_start: number,
            log_step: number,
            sValues: Float32Array,
        ): WasmMellinEvalPlan;
        static verticalLine(
            log_start: number,
            log_step: number,
            real: number,
            imagValues: Float32Array,
        ): WasmMellinEvalPlan;
        static mesh(
            log_start: number,
            log_step: number,
            realValues: Float32Array,
            imagValues: Float32Array,
        ): WasmMellinEvalPlan;
        readonly logStart: number;
        readonly logStep: number;
        len(): number;
        shape(): Uint32Array;
    }

    export class WasmMellinLogGrid {
        constructor(log_start: number, log_step: number, samples: Float32Array);
        static newWithWindow(
            log_start: number,
            log_step: number,
            samples: Float32Array,
            window: LogLatticeWindow,
            preserve_sum: boolean,
        ): WasmMellinLogGrid;
        static expDecay(
            log_start: number,
            log_step: number,
            len: number,
            window: LogLatticeWindow,
            preserve_sum: boolean,
        ): WasmMellinLogGrid;
        static expDecayScaled(
            log_start: number,
            log_step: number,
            len: number,
            rate: number,
            window: LogLatticeWindow,
            preserve_sum: boolean,
        ): WasmMellinLogGrid;
        readonly logStart: number;
        readonly logStep: number;
        len(): number;
        isEmpty(): boolean;
        samples(): Float32Array;
        weights(): Float32Array;
        support(): Float32Array;
        weightedSeries(): Float32Array;
        planMany(sValues: Float32Array): WasmMellinEvalPlan;
        planVerticalLine(real: number, imagValues: Float32Array): WasmMellinEvalPlan;
        planMesh(realValues: Float32Array, imagValues: Float32Array): WasmMellinEvalPlan;
        evaluatePlan(plan: WasmMellinEvalPlan): Float32Array;
        evaluatePlanStable(plan: WasmMellinEvalPlan): Float32Array;
        evaluatePlanWithDerivative(plan: WasmMellinEvalPlan): ComplexArrayPair;
        evaluatePlanWithDerivativeStable(plan: WasmMellinEvalPlan): ComplexArrayPair;
        evaluatePlanMagnitude(plan: WasmMellinEvalPlan): Float32Array;
        evaluatePlanLogMagnitude(plan: WasmMellinEvalPlan, epsilon: number): Float32Array;
        trainStepMatchGridPlan(
            plan: WasmMellinEvalPlan,
            target: WasmMellinLogGrid,
            lr: number,
        ): number;
        evaluate(s: Float32Array): Float32Array;
        evaluateStable(s: Float32Array): Float32Array;
        evaluateWithDerivative(s: Float32Array): ComplexArrayPair;
        evaluateWithDerivativeStable(s: Float32Array): ComplexArrayPair;
        evaluateMany(sValues: Float32Array): Float32Array;
        evaluateManyStable(sValues: Float32Array): Float32Array;
        evaluateManyWithDerivative(sValues: Float32Array): ComplexArrayPair;
        evaluateManyWithDerivativeStable(sValues: Float32Array): ComplexArrayPair;
        evaluateVerticalLine(real: number, imagValues: Float32Array): Float32Array;
        evaluateMesh(realValues: Float32Array, imagValues: Float32Array): Float32Array;
        evaluateMeshMagnitude(realValues: Float32Array, imagValues: Float32Array): Float32Array;
        evaluateMeshLogMagnitude(
            realValues: Float32Array,
            imagValues: Float32Array,
            epsilon: number,
        ): Float32Array;
        hilbertInnerProduct(other: WasmMellinLogGrid): Float32Array;
        hilbertNorm(): number;
    }

    export function mellin_exp_decay_samples(
        log_start: number,
        log_step: number,
        len: number,
    ): Float32Array;

    export function mellin_exp_decay_samples_scaled(
        log_start: number,
        log_step: number,
        len: number,
        rate: number,
    ): Float32Array;

    export class WasmFractalFieldGenerator {
        constructor(octaves: number, lacunarity: number, gain: number, iterations: number);
        readonly octaves: number;
        readonly lacunarity: number;
        readonly gain: number;
        readonly iterations: number;
        branchingField(logStart: number, logStep: number, len: number): Float32Array;
        probeObject(
            logStart: number,
            logStep: number,
            len: number,
            previewLen: number,
        ): FractalFieldProbe;
        probeJson(logStart: number, logStep: number, len: number, previewLen: number): string;
    }

    export function fractalFieldProbeObject(
        octaves: number,
        lacunarity: number,
        gain: number,
        iterations: number,
        logStart: number,
        logStep: number,
        len: number,
        previewLen: number,
    ): FractalFieldProbe;

    export function fractalFieldProbeJson(
        octaves: number,
        lacunarity: number,
        gain: number,
        iterations: number,
        logStart: number,
        logStep: number,
        len: number,
        previewLen: number,
    ): string;

    export class WasmLogZSeries {
        constructor(
            logStart: number,
            logStep: number,
            samples: Float32Array,
            window: LogZSeriesWindow,
            normalisation: LogZSeriesNormalisation,
        );
        len(): number;
        isEmpty(): boolean;
        readonly logStart: number;
        readonly logStep: number;
        readonly window: LogZSeriesWindow;
        readonly normalisation: LogZSeriesNormalisation;
        samples(): Float32Array;
        weights(): Float32Array;
        evaluateZ(z: Float32Array): Float32Array;
        evaluateManyZ(zValues: Float32Array): Float32Array;
        probeObject(zValues: Float32Array, previewLen: number): LogZSeriesProbe;
        probeJson(zValues: Float32Array, previewLen: number): string;
    }

    export function logZSeriesProbeObject(
        logStart: number,
        logStep: number,
        samples: Float32Array,
        window: LogZSeriesWindow,
        normalisation: LogZSeriesNormalisation,
        zValues: Float32Array,
        previewLen: number,
    ): LogZSeriesProbe;

    export function logZSeriesProbeJson(
        logStart: number,
        logStep: number,
        samples: Float32Array,
        window: LogZSeriesWindow,
        normalisation: LogZSeriesNormalisation,
        zValues: Float32Array,
        previewLen: number,
    ): string;

    export class WasmScaleStack {
        private constructor();
        static scalar(
            field: Float32Array,
            shape: Uint32Array,
            scales: Float32Array,
            threshold: number,
        ): WasmScaleStack;
        static semantic(
            embeddings: Float32Array,
            rows: number,
            dims: number,
            scales: Float32Array,
            threshold: number,
            metric: "euclidean" | "cosine",
        ): WasmScaleStack;
        readonly threshold: number;
        readonly mode: ScaleStackProbeMode;
        readonly sampleCount: number;
        samples(): Float32Array;
        persistence(): Float32Array;
        interfaceDensity(): number | undefined;
        moment(order: number): number;
        boundaryDimension(ambientDim: number, window: number): number | undefined;
        coherenceBreakScale(level: number): number | undefined;
        coherenceProfile(levels: Float32Array): Float32Array;
        toObject(ambientDim: number, dimensionWindow: number, levels: Float32Array): ScaleStackProbe;
        toJson(ambientDim: number, dimensionWindow: number, levels: Float32Array): string;
    }

    export interface WasmTunerRecord {
        rows_min?: number | null;
        rows_max?: number | null;
        cols_min?: number;
        cols_max?: number;
        k_min?: number;
        k_max?: number;
        subgroup?: boolean | null;
        algo_topk?: number;
        ctile?: number;
        rank_tile?: number | null;
        wg?: number;
        kl?: number;
        ch?: number;
        mode_midk?: number;
        mode_bottomk?: number;
        tile_cols?: number;
        radix?: number;
        segments?: number;
        use_2ce?: boolean;
    }

    export interface WasmTunerChoice {
        use_2ce: boolean;
        wg: number;
        kl: number;
        ch: number;
        algo_topk: number;
        ctile: number;
        rank_tile?: number | null;
        mode_midk: number;
        mode_bottomk: number;
        tile_cols: number;
        radix: number;
        segments: number;
    }

    export type ResolvedFftPlanReport = {
        plan: WasmFftPlanObject;
        overrideApplied: boolean;
        heuristicUsed: boolean;
        source: "override" | "heuristic" | "fallback";
    };

    export class WasmTuner {
        constructor(json?: string | null);
        static fromObject(value: unknown): WasmTuner;
        loadJson(json: string): void;
        loadObject(value: unknown): void;
        mergeJson(json: string): void;
        mergeObject(value: unknown): void;
        len(): number;
        recordAt(index: number): WasmTunerRecord | undefined;
        findRecord(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): WasmTunerRecord | undefined;
        isEmpty(): boolean;
        clear(): void;
        push(record: WasmTunerRecord): void;
        replaceIndex(index: number, record: WasmTunerRecord): boolean;
        removeIndex(index: number): WasmTunerRecord | undefined;
        removeRecord(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): WasmTunerRecord | undefined;
        toJson(): string;
        records(): WasmTunerRecord[];
        toObject(): WasmTunerRecord[];
        choose(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): WasmTunerChoice | undefined;
        planFft(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): WasmFftPlan | undefined;
        planFftJson(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): string | undefined;
        planFftObject(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): WasmFftPlanObject | undefined;
        planFftWithFallback(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): WasmFftPlan;
        planFftWithFallbackJson(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): string;
        planFftWithFallbackObject(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): WasmFftPlanObject;
        planFftResolution(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): ResolvedWasmFftPlan;
        planFftResolutionJson(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): string;
        planFftResolutionObject(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): ResolvedFftPlanReport;
        planFftReport(
            rows: number,
            cols: number,
            k: number,
            subgroup: boolean,
        ): ResolvedFftPlanReport;
    }

    export enum WasmFftPlanSource {
        Override = 0,
        Heuristic = 1,
        Fallback = 2,
    }

    export class ResolvedWasmFftPlan {
        private constructor();
        readonly plan: WasmFftPlan;
        readonly overrideApplied: boolean;
        readonly heuristicUsed: boolean;
        readonly source: WasmFftPlanSource;
        toJson(): string;
        toObject(): ResolvedFftPlanReport;
        static fromJson(json: string): ResolvedWasmFftPlan;
        static fromObject(value: unknown): ResolvedWasmFftPlan;
    }

    export function baseChoice(
        rows: number,
        cols: number,
        k: number,
        subgroup: boolean,
    ): WasmTunerChoice;

    export type CobolInitiatorType = "human" | "model" | "automation";

    export interface CobolInitiator {
        type: CobolInitiatorType;
        name: string;
        persona?: string;
        revision?: string;
        contact?: string;
        notes?: string[];
    }

    export interface CobolMqRoute {
        manager: string;
        queue: string;
        commit?: string;
    }

    export interface CobolCicsRoute {
        transaction: string;
        program?: string;
        channel?: string;
    }

    export interface CobolNarratorPayload {
        curvature: number;
        temperature: number;
        encoder: string;
        locale?: string;
        coefficients?: number[];
    }

    export interface CobolMetadata {
        tags?: string[];
        annotations?: string[];
        extra?: unknown;
    }

    export interface CobolDatasetRoute {
        dataset: string;
        member?: string;
        disposition?: string;
        volume?: string;
        record_format?: string;
        record_length?: number;
        block_size?: number;
        data_class?: string;
        management_class?: string;
        storage_class?: string;
        space_primary?: number;
        space_secondary?: number;
        space_unit?: string;
        directory_blocks?: number;
        dataset_type?: string;
        like_dataset?: string;
        organization?: string;
        key_length?: number;
        key_offset?: number;
        control_interval_size?: number;
        share_options_cross_region?: number;
        share_options_cross_system?: number;
        reuse?: boolean;
        log?: boolean;
        unit?: string;
        unit_count?: number;
        average_record_unit?: string;
        catalog_behavior?: string;
        retention_period?: number;
        release_space?: boolean;
        erase_on_delete?: boolean;
        expiration_date?: string;
    }

    export interface CobolRoutePlan {
        mq?: CobolMqRoute;
        cics?: CobolCicsRoute;
        dataset?: string | CobolDatasetRoute;
    }

    export interface CobolDispatchEnvelope {
        job_id: string;
        release_channel: string;
        created_at: string;
        initiators: CobolInitiator[];
        route: CobolRoutePlan;
        payload: CobolNarratorPayload;
        metadata: CobolMetadata;
    }

    export interface CobolPreviewDataset {
        dataset: string;
        member?: string;
        disposition?: string;
        volume?: string;
        record_format?: string;
        record_length?: number;
        block_size?: number;
        data_class?: string;
        management_class?: string;
        storage_class?: string;
        space_primary?: number;
        space_secondary?: number;
        space_unit?: string;
        directory_blocks?: number;
        dataset_type?: string;
        like_dataset?: string;
        organization?: string;
        key_length?: number;
        key_offset?: number;
        control_interval_size?: number;
        share_options_cross_region?: number;
        share_options_cross_system?: number;
        reuse?: boolean;
        log?: boolean;
        unit?: string;
        unit_count?: number;
        average_record_unit?: string;
        catalog_behavior?: string;
        retention_period?: number;
        release_space?: boolean;
        erase_on_delete?: boolean;
        expiration_date?: string;
    }

    export interface CobolPreviewEnvelope {
        job_id: string;
        curvature: number;
        temperature: number;
        coefficient_count: number;
        release_channel: string;
        dataset?: CobolPreviewDataset;
    }

    export class CobolDispatchPlanner {
        constructor(jobId: string, releaseChannel?: string | null);
        static fromJson(json: string): CobolDispatchPlanner;
        static fromObject(envelope: CobolDispatchEnvelope): CobolDispatchPlanner;
        setReleaseChannel(channel: string): void;
        setCreatedAt(timestamp: string): void;
        resetCreatedAt(): void;
        setNarratorConfig(
            curvature: number,
            temperature: number,
            encoder: string,
            locale?: string | null,
        ): void;
        setCoefficients(coefficients: Float32Array): void;
        addHumanInitiator(
            name: string,
            persona?: string | null,
            contact?: string | null,
            note?: string | null,
        ): void;
        addModelInitiator(
            name: string,
            revision?: string | null,
            persona?: string | null,
            note?: string | null,
        ): void;
        addAutomationInitiator(
            name: string,
            persona?: string | null,
            note?: string | null,
        ): void;
        clearInitiators(): void;
        setMqRoute(manager: string, queue: string, commitMode?: string | null): void;
        clearMqRoute(): void;
        setCicsRoute(
            transaction: string,
            program?: string | null,
            channel?: string | null,
        ): void;
        clearCicsRoute(): void;
        setDataset(dataset?: string | null): void;
        setDatasetMember(member?: string | null): void;
        setDatasetDisposition(disposition?: string | null): void;
        setDatasetVolume(volume?: string | null): void;
        setDatasetRecordFormat(recordFormat?: string | null): void;
        setDatasetRecordLength(recordLength?: number | null): void;
        setDatasetBlockSize(blockSize?: number | null): void;
        setDatasetDataClass(dataClass?: string | null): void;
        setDatasetManagementClass(managementClass?: string | null): void;
        setDatasetStorageClass(storageClass?: string | null): void;
        setDatasetSpacePrimary(spacePrimary?: number | null): void;
        setDatasetSpaceSecondary(spaceSecondary?: number | null): void;
        setDatasetSpaceUnit(spaceUnit?: string | null): void;
        setDatasetDirectoryBlocks(directoryBlocks?: number | null): void;
        setDatasetType(datasetType?: string | null): void;
        setDatasetLike(likeDataset?: string | null): void;
        setDatasetOrganization(organization?: string | null): void;
        setDatasetKeyLength(keyLength?: number | null): void;
        setDatasetKeyOffset(keyOffset?: number | null): void;
        setDatasetControlIntervalSize(controlIntervalSize?: number | null): void;
        setDatasetShareOptionsCrossRegion(shareOptionsCrossRegion?: number | null): void;
        setDatasetShareOptionsCrossSystem(shareOptionsCrossSystem?: number | null): void;
        setDatasetReuse(reuse?: boolean | null): void;
        setDatasetLog(log?: boolean | null): void;
        setDatasetUnit(unit?: string | null): void;
        setDatasetUnitCount(unitCount?: number | null): void;
        setDatasetAverageRecordUnit(averageRecordUnit?: string | null): void;
        setDatasetCatalogBehavior(catalogBehavior?: string | null): void;
        setDatasetRetentionPeriod(retentionPeriod?: number | null): void;
        setDatasetReleaseSpace(releaseSpace?: boolean | null): void;
        setDatasetEraseOnDelete(eraseOnDelete?: boolean | null): void;
        setDatasetExpirationDate(expirationDate?: string | null): void;
        clearDataset(): void;
        clearRoute(): void;
        addTag(tag: string): void;
        addAnnotation(annotation: string): void;
        mergeMetadata(metadata: unknown): void;
        clearMetadata(): void;
        isValid(): boolean;
        validationIssues(): string[];
        loadJson(json: string): void;
        loadObject(envelope: CobolDispatchEnvelope): void;
        toObject(): CobolDispatchEnvelope;
        toJson(): string;
        toUint8Array(): Uint8Array;
        coefficientsAsBytes(): Uint8Array;
        readonly createdAt: string;
        mqRoute(): CobolMqRoute | undefined;
        cicsRoute(): CobolCicsRoute | undefined;
        toCobolPreview(): CobolPreviewEnvelope;
    }
}
