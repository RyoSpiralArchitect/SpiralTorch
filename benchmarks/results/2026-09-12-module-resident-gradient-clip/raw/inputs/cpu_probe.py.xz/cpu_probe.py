"""Run through the frozen product loader, not the installed wheel."""
import json
from pathlib import Path
import sys
import spiraltorch as st

info = st.build_info()
assert info['features']['nn']
assert not any(info['features'][name] for name in ('wgpu','wgpu-rt','cuda','hip','mps'))
assert not st.wgpu_kernel_reports_available()
report = dict(status='passed', build_info=info, native_path=st._rs.__file__)
with Path(sys.argv[1]).open('x') as output:
    json.dump(report,output,indent=2)
print(json.dumps(report))
