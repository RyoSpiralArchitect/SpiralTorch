/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const run_resident_nd_tensor_fixture: () => any;
export const st_pure_clear_last_error: () => void;
export const st_pure_encoder_encode_z_space: (a: number, b: number, c: number, d: number) => number;
export const st_pure_encoder_free: (a: number) => void;
export const st_pure_encoder_new: (a: number, b: number) => number;
export const st_pure_hypergrad_absorb_text: (a: number, b: number, c: number) => number;
export const st_pure_hypergrad_accumulate_pair: (a: number, b: number, c: number, d: number, e: number) => number;
export const st_pure_hypergrad_apply: (a: number, b: number, c: number) => number;
export const st_pure_hypergrad_free: (a: number) => void;
export const st_pure_hypergrad_gradient: (a: number, b: number, c: number) => number;
export const st_pure_hypergrad_new: (a: number, b: number, c: number, d: number) => number;
export const st_pure_hypergrad_shape: (a: number, b: number, c: number) => number;
export const st_pure_hypergrad_with_topos: (a: number, b: number, c: number, d: number, e: number) => number;
export const st_pure_last_error: () => number;
export const st_pure_topos_free: (a: number) => void;
export const st_pure_topos_new: (a: number, b: number, c: number, d: number, e: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_export_2: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export_5: WebAssembly.Table;
export const closure675_externref_shim: (a: number, b: number, c: any) => void;
export const closure670_externref_shim: (a: number, b: number, c: any) => void;
export const closure699_externref_shim: (a: number, b: number, c: any, d: any) => void;
export const __wbindgen_start: () => void;
