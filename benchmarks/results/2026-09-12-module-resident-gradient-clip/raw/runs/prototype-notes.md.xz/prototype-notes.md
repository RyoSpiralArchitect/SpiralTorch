# Pre-freeze checks

- backend-a.log: the initial scaled-pair norm reduction failed for 513 finite
  gradients of magnitude 1e38. It accepted an unclipped update. This is retained
  as a real numerical failure, not an expected skip.
- backend-b.log: changing the scalar factor-count encoding alone did not fix it.
- backend-c.log: exponent-aware division in norm merging fixed the wide case;
  two backend tests passed. This was before the final limit transport change.
- backend-d.log: normal mantissa/exponent limit transport and mixed-parameter
  weighted-SGD coverage passed three native GPU tests.
- trainer-a.log: the ordinary Rust trainer regression passed for finite-wide
  gradients and limits 1 and 1e-30.

All of these are pre-freeze checks. The verified-a receipt binds the complete
runtime verification to its clean Git commit. None of these logs proves speed,
CUDA behavior, a physically identified browser GPU, or host exclusivity.
