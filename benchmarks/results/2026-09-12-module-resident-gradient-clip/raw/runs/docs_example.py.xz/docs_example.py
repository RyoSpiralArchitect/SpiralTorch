"""Run both published code blocks, preparing a fresh window between them."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import spiraltorch as st

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
RUN = LOG/'verified-a'
receipt = json.loads((RUN/'receipt.json').read_bytes())
assert receipt['status'] == 'passed' and 'active' not in receipt
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == receipt['source']['commit']
library = Path(st._rs.__file__).resolve()
assert library == RUN/'python-release.dylib'
digest = lambda value: hashlib.sha256(value).hexdigest()
assert digest(library.read_bytes()) == receipt['products']['python-release.dylib']
scope = {}
codes = {}
for name in ['module_resident_microbatch.md','module_resident_gradient_clip.md']:
    blocks = re.findall(r'```python\n(.*?)\n```',(ROOT/'docs'/name).read_text(),re.S)
    assert len(blocks) == 1
    if name.endswith('gradient_clip.md'):
        l = scope['learner']; accumulator = scope['accumulator']
        l.zero_accumulator(accumulator)
        for x,y,count in scope['batches']:
            l.set_input_tensor(x); forward=l.forward()
            loss=scope['objective'].evaluate_resident(forward.prediction_tensor(),y)
            g=l.backward(forward,loss.prediction_gradient_tensor())
            l.accumulate(accumulator,g,count/12)
    exec(compile(blocks[0],'docs/'+name,'exec'),scope)
    codes[name] = digest(blocks[0].encode())
l = scope['learner']
assert l.input_generation == 99 and l.update_snapshot().read() == 33
assert l.grad_clip_max_norm is None
scope['updated'].apply_parameters_to(scope['model'], l.parameter_snapshot().read_plan())
adapter = scope['device'].adapter_info(); assert adapter['device_type'].lower() != 'cpu'
output = scope['model'](scope['x'])
actual=output.snapshot().read_values()
expected=l.forward().prediction_tensor().snapshot().read_values()
assert len(actual)==len(expected)==18
assert all(abs(a-b)<=2e-5+2e-4*abs(b) for a,b in zip(actual,expected))
report = dict(status='passed',source=receipt['source'],library=str(library),
    library_sha256=receipt['products']['python-release.dylib'],code_sha256=codes,
    adapter=adapter,updates=33,microbatches=99,output_shape=list(output.shape),
    handoff_max_abs_error=max(abs(a-b) for a,b in zip(actual,expected)),
    boundary='Exact two documentation code blocks with a fresh window prepared between them; not quality or performance evidence, separate from the 69-stage run.')
with (LOG/'docs-example.json').open('x') as stream: json.dump(report,stream,indent=2); stream.write('\n')
print(json.dumps(report))
