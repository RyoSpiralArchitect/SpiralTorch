"""Archive source-bound numerical checks, failed setup and both regression rounds."""
import hashlib
import json
import lzma
import math
from pathlib import Path
import re

LOG=Path(__file__).parent
ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
OUT=ROOT/'benchmarks/results/2026-09-12-graph-arbitrary-vjp'
def read(path): return json.loads(path.read_text())
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()
def gm(values): return math.exp(sum(map(math.log,values))/len(values))

verified=read(LOG/'verified-b/receipt.json'); assert verified['status']=='passed'
for name, sha in verified['products'].items(): assert digest(LOG/'verified-b'/name)==sha
failed=read(LOG/'verified/receipt.json'); assert failed['status']=='error' and failed['error']=="RuntimeError('wasm-forward')"
report=dict(schema='spiraltorch.graph_arbitrary_vjp_evidence.v1',status='passed',source=verified['source'],
    adopted='verified-b',first_attempt=dict(name='verified',status='error',
        reason='The runner omitted forward-fixture.json for the old forward client suite; ENOENT before GPU execution of that suite. Earlier suites passed. The complete runner was corrected and rerun without code changes.'),
    scope='Opt-in frozen graph forward plus arbitrary-cotangent exact VJP; Python and WASM use the same Rust kernels and guards. Not a ModuleTrainer, generic autograd or pure::Tensor migration.',
    performance_scope='Regression comparison of the unchanged ordinary MSE/SGD route, NOT a benchmark of the new arbitrary-cotangent API. Fusion disabled in both lanes.',
    boundaries=['No optimizer/accumulation policy is injected into the new API.',
        'Owned GPU work serial; host contention UNKNOWN. Prior parallel GPU VJP one-off remains UNKNOWN.',
        'Apple M4 Metal/MPS for native; Chrome WebGPU does not attest an exact physical browser adapter.',
        'Eager Torch only, not torch.compile or the fastest possible Torch. No CUDA/Furnace, push, merge or wheel release.'],
    correctness={},rounds=[])
for origin in ['native','browser']:
    item=read(LOG/'verified-b'/(origin+'-correctness.json')); assert item['status']=='passed'
    a=item['autograd']; assert len(a['cases'])==6 and len(a['guards'])==11 and all(g['passed'] for g in a['guards'])
    report['correctness'][origin]=dict(adapter=item['adapter'],cases=len(a['cases']),guards=len(a['guards']),
        vjp_replays=sum(len(c['replays']) for c in a['cases']),
        max_abs_error_vs_rust_module=max(r['max_abs_error'] for c in a['cases'] for r in c['replays']),
        fused_unfused_training_max_abs=max(c['fused_unfused_max_abs_error'] for c in item['pointwise_fusion']['cases']))
torch=read(LOG/'verified-b/torch-correctness.json'); assert torch['status']=='passed'
report['correctness']['torch']=dict(version=torch['torch'],cases=len(torch['cases']),
    comparisons=sum(c['comparisons'] for c in torch['cases']),max_abs=max(c['max_abs_error'] for c in torch['cases']))
vjp=[c for c in torch['cases'] if c['arbitrary_cotangent']]
report['correctness']['torch']['arbitrary_cotangent']=dict(cases=len(vjp),replays=4*len(vjp),
    comparisons=sum(c['comparisons'] for c in vjp),max_abs=max(c['max_abs_error'] for c in vjp))
report['correctness']['python_existing']=read(LOG/'verified-b/python-tests.json')
text=(LOG/'verified-b/python-autograd.log').read_text(); assert 'Ran 3 tests' in text and '\nOK\n' in text
report['correctness']['python_autograd']=dict(tests=3,status='passed')
for name in ['wasm-autograd','wasm-fusion','wasm-forward']:
    item=read(LOG/'verified-b'/(name+'.json')); assert item['status']=='passed'
    report['correctness'][name]={k:item[k] for k in ('status','assertions','adapter') if k in item}
report['test_counts']={name:sum(map(int,re.findall(r'test result: ok\. (\d+) passed',
    (LOG/'verified-b'/(name+'.log')).read_text()))) for name in ['contracts','nn-serial','backend-serial','integration']}
raw_intervals=retained_intervals=updates=0
for name in ['timing','timing-b']:
    receipt=read(LOG/name/'receipt.json'); assert receipt['status']=='passed' and receipt['source']==verified['source']
    value=read(LOG/name/'validation.json'); assert value['status']=='passed' and len(value['cases'])==9
    row=dict(name=name,baseline=receipt['baseline']['source'],candidate=receipt['candidate']['source'],
        max_abs=max(e for c in value['cases'] for e in c['max_abs_errors'].values()),native={},browser={})
    for origin in ['native','browser']:
        for cadence in ['immediate','deferred']:
            ratios=[c[origin][cadence]['baseline_over_candidate'] for c in value['cases']]
            worst=min(range(len(ratios)),key=lambda i:ratios[i])
            stats=dict(baseline_over_candidate_geomean=gm(ratios),min_ratio=min(ratios),max_ratio=max(ratios),
                worst_config=value['cases'][worst]['config'])
            if origin=='native': stats['torch_over_candidate_geomean']=gm([c[origin][cadence]['torch_over_candidate'] for c in value['cases']])
            row[origin][cadence]=stats
        original=read(LOG/name/(origin+'.json'))
        for case in original['cases']:
            for s in case['samples']:
                lanes=len(s['times_ms']); raw_intervals+=lanes
                retained_intervals+=0 if s['warmup'] else lanes
                updates+=lanes*case['config']['steps']
    report['rounds'].append(row)
report['measurement_counts']=dict(raw_intervals=raw_intervals,retained_intervals=retained_intervals,nonzero_sgd_updates=updates)

OUT.mkdir(); (OUT/'raw').mkdir()
files=sorted(p for p in LOG.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.jsonl','.log','.stderr'))
manifest=dict(schema='spiraltorch.compressed_evidence_manifest.v1',artifacts=[])
for i, source in enumerate(files):
    destination=OUT/'raw'/f'{i:03d}-{source.name}.xz'
    with source.open('rb') as src, lzma.open(destination,'wb',filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024*1024)]) as dst:
        for block in iter(lambda:src.read(1024*1024),b''): dst.write(block)
    raw_sha=digest(source); h=hashlib.sha256(); size=0
    with lzma.open(destination,'rb') as restored:
        for block in iter(lambda:restored.read(1024*1024),b''): h.update(block); size+=len(block)
    assert h.hexdigest()==raw_sha and size==source.stat().st_size
    assert destination.stat().st_size < 95*1024*1024
    manifest['artifacts'].append(dict(source=str(source.relative_to(LOG)),path=str(destination.relative_to(OUT)),
        raw_sha256=raw_sha,raw_bytes=size,compressed_sha256=digest(destination),compressed_bytes=destination.stat().st_size))
report['artifacts']=len(manifest['artifacts'])
report['compressed_bytes']=sum(a['compressed_bytes'] for a in manifest['artifacts'])
report['raw_bytes']=sum(a['raw_bytes'] for a in manifest['artifacts'])
for name, value in [('summary',report),('manifest',manifest)]:
    (OUT/(name+'.json')).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2,allow_nan=False))
