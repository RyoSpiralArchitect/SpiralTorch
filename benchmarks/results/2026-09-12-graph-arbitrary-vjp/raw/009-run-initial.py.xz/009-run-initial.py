"""Frozen arbitrary-cotangent graph verification; owned GPU jobs are serial."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT=Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
TARGET=ROOT.parent/'spiraltorch-spiralk-golden-blackcat-contract-v1/target'
LOG=Path(__file__).parent
OUT=LOG/sys.argv[1]; OUT.mkdir()
MODE=sys.argv[2]
P='/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12'
TORCH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/rank-finite-bound-20260907/venv/bin/python'
CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
BINDGEN='/Users/ryospiralarchitect/Library/Caches/.wasm-pack/wasm-bindgen-cargo-install-0.2.104/wasm-bindgen'
LOADER='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py'
env=dict(os.environ,CARGO_BUILD_JOBS='4',CARGO_TARGET_DIR=str(TARGET),PYO3_PYTHON=P,
    SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS='1',PYTORCH_ENABLE_MPS_FALLBACK='0',
    NODE_PATH='/Users/ryospiralarchitect/Library/Logs/SpiralTorch/midk-seek-20260906/browser-deps/node_modules')
git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''): h.update(block)
    return h.hexdigest()
source=dict(commit=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'))
assert not git('status','--porcelain')
report=dict(status='error',source=source,mode=MODE,steps=[],products={},
    contention='UNKNOWN; owned GPU work serial; no host exclusivity claim')
def save(): (OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,args,output=None):
    print('START',name,flush=True); start=time.monotonic()
    with (OUT/(name+'.log')).open('xb') as log:
        if output:
            with (OUT/output).open('xb') as out:
                p=subprocess.run(args,cwd=ROOT,env=env,stdout=out,stderr=log,timeout=1800)
        else: p=subprocess.run(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    report['steps'].append(dict(name=name,command=args,exit_code=p.returncode,seconds=time.monotonic()-start))
    save(); print('END',name,p.returncode,flush=True)
    if p.returncode: raise RuntimeError(name)
def freeze(src,dest):
    dest=OUT/dest; shutil.copyfile(src,dest);dest.chmod(0o555)
    report['products'][str(dest.relative_to(OUT))]=digest(dest); save()
def bindgen(src,folder):
    run(folder+'-bindgen',[BINDGEN,str(src),'--target','web','--out-dir',str(OUT/folder),'--out-name','spiraltorch_wasm'])
    for path in (OUT/folder).rglob('*'):
        if path.is_file(): report['products'][str(path.relative_to(OUT))]=digest(path)
    save()
def products(directory):
    receipt=json.loads((directory/'receipt.json').read_text())
    assert receipt['status']=='passed'
    for name,sha in receipt['products'].items(): assert digest(directory/name)==sha,name
    return receipt
def browser(name,folder,suite):
    run(name,['node','tools/test_resident_browser.cjs',str(OUT/folder),CHROME,str(OUT/(name+'.json')),'','','','',suite])

try:
    if MODE=='verify':
        run('format',['cargo','+nightly-2026-04-15','fmt','--all','--','--check'])
        run('benchmark-admission',[P,'-I','tests/test_resident_training_bench.py','-v'])
        run('profile-admission',[P,'-I','tests/test_resident_training_profile.py','-v'])
        run('contracts',['cargo','+1.98.0','test','--locked','--release','-p','st-kernel-contracts','--lib'])
        run('native-build',['cargo','+1.98.0','build','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu',
            '--example','resident_training_bench','--example','resident_graph_training'])
        for name in ['resident_training_bench','resident_graph_training']: freeze(TARGET/'release/examples'/name,name)
        run('wasm-build',['cargo','+1.98.0','build','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu',
            '--target','wasm32-unknown-unknown','--example','resident_training_bench_browser','--example','resident_graph_training_browser'])
        bindgen(TARGET/'wasm32-unknown-unknown/release/examples/resident_training_bench_browser.wasm','bench')
        bindgen(TARGET/'wasm32-unknown-unknown/release/examples/resident_graph_training_browser.wasm','correctness')
        run('native-correctness',[str(OUT/'resident_graph_training')],output='native-correctness.json')
        browser('browser-correctness','correctness','nn-graph-training')
        run('torch-correctness',[TORCH,'-I','tools/validate_resident_graph_training_vs_torch.py',str(OUT/'native-correctness.json'),
            str(OUT/'browser-correctness.json'),'--devices','cpu','mps','--output',str(OUT/'torch-correctness.json')])
        run('nn-serial',['cargo','+1.98.0','test','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu','--lib','--','--test-threads=1'])
        run('backend-serial',['cargo','+1.98.0','test','--locked','--release','-p','st-backend-wgpu','--lib','--','--test-threads=1'])
        run('integration',['cargo','+1.98.0','test','--locked','--release','-p','st-nn','--no-default-features','--features','wgpu',
            '--test','resident_graph_forward','--test','resident_graph_training','--test','resident_nd_tensor','--test','resident_training','--','--test-threads=1'])
        run('cpu-check',['cargo','+1.98.0','check','--locked','-p','st-nn','--no-default-features'])
        run('python-build',['cargo','+1.98.0','build','--locked','--release','-p','spiraltorch-py'])
        freeze(TARGET/'release/libspiraltorch.dylib','python-release.dylib')
        run('python-tests',[P,'-I',LOADER,str(OUT/'python-release.dylib'),str(ROOT),'tests',str(OUT/'python-tests.json')])
        run('python-autograd',[P,'-I',LOADER,str(OUT/'python-release.dylib'),str(ROOT),'bindings/st-py/tests/test_nn_resident_graph_autograd.py','-v'])
        run('wasm-client-build',['cargo','+1.98.0','build','--locked','--release','-p','spiraltorch-wasm','--features','webgpu','--target','wasm32-unknown-unknown'])
        bindgen(TARGET/'wasm32-unknown-unknown/release/spiraltorch_wasm.wasm','client')
        browser('wasm-autograd','client','nn-autograd-clients')
        browser('wasm-fusion','client','nn-fusion-clients')
        browser('wasm-forward','client','nn-forward-clients')
        run('client-types',['node','bindings/st-wasm/tests/resident_types.cjs',str(OUT/'client/spiraltorch_wasm.d.ts'),str(ROOT/'bindings/st-wasm/types/spiraltorch-wasm.d.ts')])
    elif MODE=='bench':
        candidate=LOG/sys.argv[3]; verified=products(candidate)
        assert verified['source']==source
        baseline=LOG.parent/'graph-pointwise-fusion-20260911/verified'; old=products(baseline)
        report['baseline']=dict(path=str(baseline),source=old['source'])
        report['candidate']=dict(path=str(candidate),source=verified['source'])
        n=OUT/'native.json'; b=OUT/'browser.json'
        run('native',[TORCH,'-I','tools/bench_resident_training_vs_torch.py','--graph','--matrix','standard','--device','mps',
            '--baseline',str(baseline/'resident_training_bench'),'--baseline-source',old['source']['commit'],
            '--candidate',str(candidate/'resident_training_bench'),'--candidate-source',verified['source']['commit'],'--output',str(n)])
        run('browser',['node','tools/bench_resident_training_browser.cjs',str(baseline/'bench'),str(candidate/'bench'),CHROME,str(b),'graph','standard'])
        run('validation',[P,'-I','tools/validate_resident_training_bench.py','--native',str(n),'--browser',str(b),
            '--browser-progress',str(b)+'.progress.jsonl','--baseline-source',old['source']['commit'],
            '--candidate-source',verified['source']['commit'],'--browser-harness-source',source['commit'],'--output',str(OUT/'validation.json')])
        products(candidate);products(baseline)
    else: raise ValueError('unknown mode')
    for name,sha in report['products'].items(): assert digest(OUT/name)==sha,name
    assert git('rev-parse','HEAD')==source['commit'] and not git('status','--porcelain')
    report['status']='passed'
except BaseException as error:
    report['error']=repr(error)
    raise
finally: save()
