"""Preserve the source-bound resident Topos EMA run and its independently replayed data."""
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess

ROOT = Path('/Users/ryospiralarchitect/\U0001f300SpiralReality\U0001f300/_wt/spiraltorch-resident-graph-forward-v1')
LOG = Path(__file__).parent
RUN = LOG/'verified-a'
BASE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-inline-guard-20260912/verified-a')
OUT = ROOT/'benchmarks/results/2026-09-12-module-resident-momentum'
LOADER = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/resident-graph-forward-clients-20260910/python-client.py')
CPU_PROBE = Path('/Users/ryospiralarchitect/Library/Logs/SpiralTorch/module-parameter-handoff-20260912/cpu_probe.py')
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_bytes())
git = lambda *args: subprocess.check_output(['git',*args],cwd=ROOT)
def write(path,data): path.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
assert not OUT.exists(), 'archive exists; inspect rather than overwrite'
run,base = read(RUN/'receipt.json'),read(BASE/'receipt.json')
assert run['status'] == base['status'] == 'passed' and 'active' not in run
assert len(run['steps']) == 69 and all(s['exit_code'] == 0 for s in run['steps'])
assert git('rev-parse','HEAD').decode().strip() == run['source']['commit']
assert not git('status','--porcelain').strip()
assert sha((LOG/'run.py').read_bytes()) == run['harness_sha256']
assert sha(LOADER.read_bytes()) == run['loader_sha256']
assert sha((BASE/'receipt.json').read_bytes()) == run['baseline_receipt_sha256']
products=[]
for label,folder,receipt in [('baseline-control',BASE,base),('candidate',RUN,run)]:
    for name,digest in receipt['products'].items():
        path=folder/name
        assert sha(path.read_bytes()) == digest, str(path)
        products.append(dict(version=label,path=str(path),sha256=digest))
torch=read(RUN/'torch-correctness.json')
assert torch['status']=='passed'
for source in torch['inputs']: assert sha(Path(source['path']).read_bytes())==source['sha256']
micro=[c for c in torch['cases'] if c.get('topos_momentum')]
assert len(micro)==24 and len(torch['cases'])==432 and len(torch['reference_gaps'])==4
trajectories=[]
for route,file in [('native','native-correctness.json'),('browser','browser-correctness.json')]:
    fixture=read(RUN/file)
    section=fixture['momentum']
    assert fixture['status']==section['status']=='passed' and len(section['cases'])==6
    for c in section['cases']:
        control=next(x for x in fixture['gradient_clip']['cases'] if (x['seed'],x['policy'])==(c['seed'],c['policy']))
        assert len(c['windows'])==c['observations_after_updates']==32 and c['module_parameters_applied']==7
        assert sum(len(w['microbatches']) for w in c['windows'])==c['microbatches']==95
        trajectories.append(dict(route=route,seed=c['seed'],policy=c['policy'],shape=c['input_shape'],
            reduction=c['reduction'],initial_loss=c['initial_loss'],final_loss=c['final_loss'],
            final_over_initial=c['final_loss']/c['initial_loss'],loss_decreased=c['final_loss']<c['initial_loss'],
            updates=32,microbatches=95,first_observation_after_updates=32,module_parameters_applied=7,
            optimizer=c['optimizer'],clipped_sgd_final_loss=control['final_loss'],
            final_minus_clipped_sgd=c['final_loss']-control['final_loss'],
            boundary='Same small training fixtures versus the same clipping schedule without EMA; not held-out generalization or an EMA-quality win gate.'))
clients=read(RUN/'browser-microbatch.json')
assert clients['status']=='passed' and len(clients['cases'])==12
guide=read(LOG/'docs-example.json')
assert guide['status']=='passed' and guide['source']==run['source']
assert guide['library_sha256']==run['products']['python-release.dylib']
for name in ['direct-io-validation','module-forward-validation']:
    assert read(RUN/(name+'.json'))['status']=='passed'
counts={}
for path in RUN.glob('*.log'):
    content=path.read_text()
    rust=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',content)
    python=re.findall(r'^Ran (\d+) tests? in',content,re.MULTILINE)
    if rust or python:
        assert all(int(f)==0 for _,f,_ in rust)
        counts[path.name]=dict(rust_passed=sum(int(p) for p,_,_ in rust),rust_ignored=sum(int(i) for _,_,i in rust),python_ran=sum(map(int,python)))
files={'runs/'+str(p.relative_to(LOG)):p for p in LOG.rglob('*') if p.is_file() and '__pycache__' not in p.parts
       and p.suffix in ('.json','.jsonl','.log','.py','.js','.mjs','.ts','.html','.md')}
files.update({'inputs/baseline-receipt.json':BASE/'receipt.json',
    'inputs/baseline-native-fixture.json':BASE/'native-forward-bench.json',
    'inputs/python-client.py':LOADER,'inputs/cpu_probe.py':CPU_PROBE})
payloads={name:(p.read_bytes(),dict(path=str(p))) for name,p in files.items()}
source=run['source']['commit']; parent=git('rev-parse',source+'^').decode().strip()
names=set(git('diff','--name-only',parent,source).decode().splitlines())
shaders=['crates/st-backend-wgpu/src/shaders/gradient_composition.wgsl',
    'crates/st-backend-wgpu/src/shaders/gradient_source_guard.wgsl',
    'crates/st-backend-wgpu/src/shaders/graph_parameter.wgsl']
names.update(shaders)
names.add('crates/st-backend-wgpu/src/shaders/dense_training.wgsl')
names.update(['Cargo.toml','Cargo.lock','crates/st-backend-wgpu/Cargo.toml',
    'crates/st-backend-wgpu/src/runtime.rs','crates/st-backend-wgpu/src/resident_tensor/capture.rs',
    'crates/st-backend-wgpu/src/resident_tensor/classification.rs',
    'crates/st-backend-wgpu/src/resident_tensor/shaders/cross_entropy.wgsl',
    'crates/st-kernel-contracts/src/graph.rs','crates/st-kernel-contracts/src/classification.rs',
    'crates/st-nn/Cargo.toml','crates/st-nn/tests/resident_graph_training.rs',
    'crates/st-nn/examples/resident_graph_training.rs','crates/st-nn/examples/resident_graph_training_browser.rs',
    'bindings/st-py/Cargo.toml','bindings/st-wasm/Cargo.toml',
    'tools/validate_module_forward_paths.py','tools/validate_module_direct_io.py',
    'tools/bench_graph_forward_paths.py','tools/resident_module_handoff_fixture.py'])
for label,commit in [('feature-base',parent),('candidate',source)]:
    existing=set(git('ls-tree','-r','--name-only',commit).decode().splitlines())
    for name in sorted(names & existing):
        payloads[f'source/{label}/{name}']=(git('show',commit+':'+name),dict(git_commit=commit,git_path=name))
identities={}
for name in shaders:
    identities[name]=sha(git('show',parent+':'+name))
    assert identities[name]==sha(git('show',source+':'+name))
(OUT/'raw').mkdir(parents=True)
entries=[]
for name,(data,origin) in sorted(payloads.items()):
    packed=lzma.compress(data); path=OUT/'raw'/(name+'.xz'); path.parent.mkdir(parents=True,exist_ok=True); path.write_bytes(packed)
    assert lzma.decompress(path.read_bytes())==data
    entries.append(dict(archive=str(path.relative_to(OUT)),origin=origin,bytes=len(data),sha256=sha(data),compressed_bytes=len(packed),compressed_sha256=sha(packed)))
manifest=dict(schema='spiraltorch.source_archive.v1',status='passed',records=entries,
    raw_bytes=sum(e['bytes'] for e in entries),compressed_bytes=sum(e['compressed_bytes'] for e in entries))
write(OUT/'manifest.json',manifest)
def torch_summary(cases):
    return dict(version=torch['torch'],cases=len(cases),tensor_or_scalar_comparisons=sum(c['comparisons'] for c in cases),
        max_abs_error=max(c['max_abs_error'] for c in cases),devices=sorted({c['device'] for c in cases}),scope=torch['scope'])
summary=dict(schema='spiraltorch.module_resident_momentum_record.v1',status='passed',candidate_source=run['source'],
    momentum_rule='m_t=damping*m_(t-1)+(1-damping)*g_clipped',
    feature_base_commit=parent,baseline_control_source=base['source'],verification_steps=69,verification_seconds=run['seconds'],
    decision='Reuse Topos EMA after composition, gain normalization and optional global clipping; commit history and all parameters together. Reset or disable explicitly and expose owning history snapshots without host observations in the update loop.',
    test_counts=counts,torch_all_matched=torch_summary(torch['cases']),torch_momentum_matched=torch_summary(micro),
    existing_torch_reference_gaps=torch['reference_gaps'],trajectories=trajectories,browser_clients=clients,docs_example=guide,
    browser_client_gain_scope='Client reference_gain/reference_momentum fields are scalar references after the 32 learning updates, before rejection/recovery/reset probes; they are not GPU dumps. Shared fixtures record actual GPU parameters, losses and history.',
    unchanged_shader_sha256=identities,frozen_products_checked=len(products),products=products,raw_records=len(entries),
    manifest_sha256=sha((OUT/'manifest.json').read_bytes()),
    preliminary_logs='See prototype-notes.md: pre-freeze native GPU and ordinary Topos parity checks are retained, not counted as frozen verification.',
    boundary='Small deterministic learning and correctness, not generalization, LLM/FT quality or speed. Native Apple M4/Metal; browser WebGPU physical GPU UNKNOWN. Owned GPU work serial, host exclusivity UNKNOWN. Eager Torch CPU/MPS, fallback disabled. Fixed microbatch shape, explicit valid-label weights, explicit SGD with optional Topos EMA, no full Topos RMS-control migration, optimizer checkpoint/resume, generic ModuleTrainer migration, implicit averaging, CUDA/Furnace, release, push or merge. Existing forward controls are not sustained-interval performance evidence.')
write(OUT/'summary.json',summary)
print(json.dumps(dict(status='passed',records=len(entries),raw_bytes=manifest['raw_bytes'],compressed_bytes=manifest['compressed_bytes'],
    products=len(products),torch_all=summary['torch_all_matched'],torch_microbatch=summary['torch_momentum_matched'],
    decreasing_trajectories=sum(c['loss_decreased'] for c in trajectories))))
