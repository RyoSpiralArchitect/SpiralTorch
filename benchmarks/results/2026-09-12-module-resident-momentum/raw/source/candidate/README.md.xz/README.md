# 🌀🕯️ SpiralTorch 🕯️🌀
**trains where PyTorch can’t — inside the Z-space.**  
_(Still under active expanding hourly.)_

**Purpose.** A WGPU-first, research-grade ML/geometry runtime that fuses spectral operators, microlocal tools, and cooperative schedulers into a single stack. The goal: rival CUDA-centric ecosystems using portable GPUs (Metal/Vulkan/DX12) without sacrificing theory fidelity.

## 🌌 SpiralTorch Manifesto

Step into the paradigm shift from imitation to emergent meaning with the [SpiralTorch Manifesto](docs/spiraltorch_manifesto.md).

🌌 **New to the manifold?** Explore how tensors, telemetry, and imported checkpoints share coordinates in [Navigating Z-space in SpiralTorch](docs/zspace_intro.md).

📜 **Licensing at a glance:** SpiralTorch is AGPL-3.0-or-later by default with a commercial option for proprietary deployments. [Read the full policy.](docs/licensing.md)
Unauthorized redistribution, scraping, or resale of this repository
violates AGPL-3.0 and §13. Any commercial deployment requires a license.

## ⚖️ Attribution Required
Reuse or redistribution **must retain the SpiralTorch name and authorship** as per AGPL §5 & §13.

---

## 🚀 Quick Start

**New to SpiralTorch?** Start here:

- **1-minute quickstart (Python):**
  ```bash
  pip install -U spiraltorch

  python - <<'PY'
  import spiraltorch as st
  from spiraltorch.nn import Linear, Sequential

  print("backend:", st.describe_device("cpu")["backend"])

  model = Sequential()
  model.add(Linear(2, 2, name="head"))
  y = model(st.Tensor(1, 2, [0.25, 0.75]))
  print("forward:", y.tolist())

  # Checkpoint handoff is explicit: external keys map into native module keys.
  head = Linear(2, 2, name="head")
  native_state = dict(head.state_dict())
  external_state = {
      "lm_head.weight": native_state["head::weight"],
      "lm_head.bias": native_state["head::bias"],
  }
  report = head.state_dict_compatibility_with_key_map(
      external_state,
      {"lm_head.weight": "head::weight", "lm_head.bias": "head::bias"},
  )
  print("checkpoint compatible:", report["compatible"])
  PY
  ```

- 📚 **[Getting Started Guide](docs/getting-started.md)** - Installation, first steps, and core concepts
- 🔄 **[PyTorch Migration Guide](docs/pytorch-migration-guide.md)** - Seamless transition from PyTorch  
- 📖 **[Example Gallery](docs/example-gallery.md)** - 18+ examples across vision, NLP, RL, and more
- **[Backend vs PyTorch benchmarks](docs/backend_pytorch_benchmarks.md)** - Matched inputs, strict execution, actual WASM/CUDA runs, and preserved failures.
- **[Resident WebGPU matmul](docs/resident_webgpu_matmul.md)** - Shared Rust execution from Python/browser WASM, GPU chaining, and asynchronous snapshots.
- **[Resident NN inference](docs/resident_nn_inference.md)** - Lower existing Rust Linear/GELU/Sequential modules into a checked GPU-resident chain with N-D shape metadata; explicit inference, not resident training.
- **[Mixed forward graphs](docs/resident_graph_forward.md)** - Compile existing Scaler/ReLU/Linear/GELU modules through Rust, Python or WASM without a training tape; shared `WgpuTensor` handles connect N-D processing, inference and graph training without intermediate CPU readback.
- **[Original model, resident inputs](docs/module_resident_forward.md)** - The same NN model now reuses that graph through Rust `forward_resident`, Python `model(WgpuTensor)`, and browser `Sequential.forward`; explicit GPU outputs, parameter-aware cache reuse, and checked training handoff.
- **[Resident NN training](docs/resident_nn_training.md)** - The same graph supports Rust-owned mean-MSE, VJP and transactional SGD through Python/browser clients, with explicit weight-only handoff.
- 🌌 **[Z-Space Introduction](docs/zspace_intro.md)** - Understanding hyperbolic geometry in ML

**Already familiar?** Jump to [Installation](#install-pip) or explore [Latest Highlights](#-latest-spiraltorch-highlights).

---

### Python Surface Map

SpiralTorch deliberately keeps its strange color: Z-space, desire telemetry,
roundtables, psychoid routes, and canvas traces are part of the vocabulary.
For day-to-day Python use, though, the first handles are ordinary:

- `spiraltorch.Tensor`, `spiraltorch.nn`, and `spiraltorch.optim` for native
  tensors, modules, losses, and Amegagrad loops without NumPy/PyTorch as hard
  dependencies.
- `SpiralSession(backend="auto" | "cpu" | "wgpu")` for one object that records
  the requested runtime route and device preflight evidence.
- `spiraltorch.ecosystem` for PyTorch/JAX/CuPy/TensorFlow tensor handoff when
  you do want to co-run another stack.
- `bindings/st-py/examples/checkpoint_preflight.py` for HF/PyTorch-style state
  dict audits before loading, resizing, projecting, or LoRA-wrapping weights.
- `ApiLLMZSpaceRuntime` for hosted/API-model LLM inference: pass an
  OpenAI-compatible response mapping or any callable API client, and SpiralTorch
  turns text/usage/latency into a Z-space partial trace, JSONL artifact, and
  summary without making hosted SDKs hard dependencies. Lazy OpenAI and
  Anthropic adapters are available when those optional SDKs are installed.
- `bindings/st-py/examples/byte_lm_profile_smoke.py` and
  `byte_lm_transformers_trace.py` for tokenizerless FT diagnostics plus
  same-process `torch` / `transformers` / `tokenizers` runtime evidence.

---

### 🧱 Learning Stack (Model Zoo)

SpiralTorch’s “learning stack” is a set of minimal, runnable training baselines (Rust-first; no NumPy/PyTorch required). See `models/README.md`.

- Demo texts: `models/samples/spiral_demo_en.txt`, `models/samples/spiral_demo_ja.txt`
- Demo corpus folder: `models/samples/spiral_corpus_en/` (multiple `.txt` files)
- Run outputs: `models/runs/<timestamp>/` (e.g. `run.json`, `metrics.jsonl`, `summary.json`, `samples/`, `weights.json` / `weights.bin`)
- Optional (Python): `--backend cpu|wgpu|cuda|hip|auto` to pick the compute backend
- Optional (Python): `--events <path>` to record events (JSONL) + `--atlas` to emit `atlas_summary.json`
- Optional (Python): `--desire` to enable desire telemetry + apply desire offsets during sampling
- Optional (Python): tune SoftLogic band weighting via `SPIRAL_SOFTLOGIC_*`, `--softlogic-*` flags (saved into `run.json`), or `trainer.set_softlogic_config(st.nn.SoftLogicConfig(...))`
- Coherence-scan char LMs damp the scan context before the classifier head by default; use `--context-scale 0.05` to tune that initial-logit scale.
- Coherence scan/wave examples also accept the bigram prior and top-k guard flags; when shrinking `--steps` for smoke tests, set `--memory <= --steps`.
- Rust char-LM examples scale classifier weights by RMS by default; use `--head-rms 0.1` and, for scan/wave mixers, `--mix-rms 0.1` to tune update pressure.
- Rust char-LM examples add a learned smoothed train-token unigram prior before the softmax by default; use `--head-prior none` to start without that prior, or `--head-prior bigram|learned-bigram` to route a previous-token train bigram prior through the same head.
- Rust char-LM examples scale residual context logits before the head prior with `--head-residual-scale 1.0`; set it to `0` for a pure-prior ablation, or raise it to test whether context can beat the frequency/bigram prior.
- Rust char-LM examples can add a differentiable previous-token top-k preservation guard with `--bigram-topk-guard F --bigram-topk-guard-k N`, training on normal next-token CE plus a weighted CE over the smoothed train-bigram top-k row.
- The Rust raw-text fine-tune example can switch its recurrent core with `--recurrent spiral|lstm`; `tools/run_char_lm_sweep.py --architectures finetune,lstm ...` compares the SpiralRNN and stateless batched LSTM paths in the same table.
- One-command char-LM ablation report: `PYTHONNOUSERSITE=1 python3 -S -s tools/run_char_lm_ablation_report.py models/samples/spiral_corpus_en --preset smoke` runs LSTM, SpiralRNN, coherence scan/wave, and top-k guard variants across the default seeds, then writes `ablation_report.md`, `ablation_report.json`, `compare.json`, and `compare_summary.md`; add `--head-priors learned-bigram,learned-unigram,none` to sweep how much the output prior is carrying the result.
- Shape grids for recurrent comparisons use `--step-values`, `--hidden-values`, and `--embed-dim-values`; training-budget grids use `--epoch-values` and `--batches-values`; residual-logit grids use `--head-residual-scale-values`; bigram guard grids use `--bigram-topk-guard-values`; generated run names and aggregate groups include those dimensions so unlike shapes/scales/budgets/guards are not averaged together.
- Reproduce the validated guarded LSTM/SpiralRNN comparison with `tools/run_char_lm_sweep.py <text-or-dir> --recipe guarded-lstm`; override any generated grid flag explicitly when narrowing or expanding the recipe.
- Probe no-prior context learning with `tools/run_char_lm_sweep.py <text-or-dir> --recipe no-prior-context-pressure`, then focus the cheaper scan/wave budget path with `--recipe no-prior-coherence-budget`; use `--recipe no-prior-coherence-frontier` to compare the LSTM baseline, scan winner, and lite wave candidates on the same longer budget while applying scan/wave-only mix RMS normalization.
- Probe scan/wave expressiveness directly with `tools/run_char_lm_sweep.py <text-or-dir> --recipe no-prior-coherence-shape`, confirm the full grid with `--recipe no-prior-coherence-shape-confirm`, or rerun only the quick-probe scan winner plus promoted single-branch wave with `--recipe no-prior-coherence-shape-winners`; use `--recipe no-prior-coherence-wave-lite` and `--recipe no-prior-coherence-wave-lite-confirm` to trade wave branch count against route debt, then `--recipe no-prior-coherence-wave-promoted` to rerun the route-debt-selected lite wave shape. Use `--recipe no-prior-coherence-promoted-frontier` to compare that promoted wave against the scan winner on the same longer budget, `--recipe no-prior-coherence-wave-long` to rerun the promoted wave on the longer budget that improved no-prior evidence, `--recipe no-prior-coherence-wave-wide-corpus` with a widened docs bundle such as `models/samples/spiral_corpus_en models/samples/spiral_demo_en.txt models/README.md docs/getting-started.md docs/example-gallery.md docs/zspace_intro.md bindings/st-py/README.md`, `--recipe no-prior-coherence-wave-capacity-scout` to sweep hidden/memory capacity around that long wave recipe, `--recipe no-prior-coherence-wave-capacity` to rerun the h96/m24 single-dilation candidate, or `--recipe no-prior-coherence-wide-frontier` to compare the LSTM baseline, scan winner, and promoted wave on that widened long-budget setting. These vary or pin scan `context/query` scales and wave `kernel/dilations`, while compare artifacts keep coherence route/debt columns visible.
- Top aggregate char-LM rows rank by validation NLL first, then by trace latency and CPU-debt tie-breaks, so equal-quality recurrent shapes surface the cheaper path.
- Route-aware `compare_summary.md` emits `Bigram Guard Deltas` when a sweep contains both `bigram_guard=0` and guarded rows, making NLL, bigram lift, rank lift, and top-5 preservation tradeoffs visible against the unguarded baseline; `Bigram Guard Recommendations` floats clean guard candidates above mixed top-k tradeoffs.
- Char-LM `compare_summary.md` now includes a `Learning Scoreboard` section, ranking aggregate runs by positive NLL gain per traced step while keeping final/best NLL, bigram gap, CPU debt, and route status visible for scan/wave/SpiralRNN budget comparisons.
- Char-LM `compare_summary.md` also emits `Route Debt Decision` / `Route Debt Recommendations` when wave dilation variants reach neutral-or-better NLL with lower coherence route debt, surfacing lite wave shapes such as single-branch dilations before heavier-but-equivalent stacks; use `--compare-summary-sort-metric coherence_route_debt` to rank the main table by that route-debt column directly, or `--compare-summary-fail-on-route-debt-decision no_route_debt_recommendation` to gate a lite-wave confirmation sweep.
- Char-LM validation summaries include smoothed train-token unigram and bigram baselines, target-token rank, and context-lift metrics (`mean_target_logprob_lift`, rank lift, KL-to-unigram, plus bigram lift/KL/top-5 overlap fields), so runs can be checked against simple frequency and previous-token baselines before judging context learning; use `--compare-summary-sort-metric final_bigram_logprob_lift|final_bigram_rank_lift|final_top5_bigram_overlap` to shortlist by those guards instead of raw NLL.
- Compare char-LM runs: `PYTHONNOUSERSITE=1 python3 -S -s tools/compare_char_lm_runs.py --aggregate --curves --params 5 models/runs/<baseline> models/runs/<scan> models/runs/<wave>`
- **LLM (raw text, no tokenizer):** `cargo run -p st-nn --example modelzoo_llm_char_finetune -- <text.txt> [--recurrent spiral|lstm] [--head-rms 0.1 --head-residual-scale 1.0 --head-prior unigram|bigram|learned-bigram --bigram-topk-guard 0.05 --bigram-topk-guard-k 5] [--val-fraction 0.1 --eval-samples 256]`
- **LLM (Python, raw text, no tokenizer):** `PYTHONNOUSERSITE=1 python3 -S -s models/python/llm_char_finetune.py <text_or_dir> [<text_or_dir> ...]`; add `--preflight-only --runtime-import-preset hf-full-finetune --require-runtime-imports --runtime-device-backend wgpu --runtime-preflight-json-out ft-runtime.json` before a heavier local HF handoff to capture the SpiralTorch NN/backend surface plus same-process `transformers`/`torch`/`tokenizers`/`datasets`/`accelerate`/`safetensors`/`pyarrow`/`evaluate`/`peft` import evidence and WGPU device readiness in `preflight.json`, `runtime_preflight.json`, and `summary.json`; add `--require-runtime-device-ready-backend wgpu` for strict accelerator gating. On a real run, the same runtime contract is also recorded in `run.json`.
- **LLM (Python, tokenizerless FT profile ladder):** `PYTHONNOUSERSITE=1 python3 -S -s bindings/st-py/examples/byte_lm_profile_smoke.py --hf-state-dict <local-hf-state-dict-or-dir> --key-preset auto --ft-readiness-preset hf-wgpu-balanced` audits local HF/PyTorch-style checkpoints, enables the checkpoint + Transformers trace + produced-manifest runtime contract, records same-process `transformers`/`torch`/`tokenizers` co-import evidence, captures `describe_device("wgpu")` runtime readiness evidence, checks the Transformers/trainer runtime bridge, and gates bounded byte-LM LoRA/source/profile comparisons with WGPU run-summary and promotion readiness thresholds before heavier FT. The FT preset expands to `--runtime-contract-preset hf-runtime --wgpu-readiness-preset balanced`; use `hf-wgpu-observed` to only require WGPU metrics/report presence or `hf-wgpu-strict` for a high-readiness bar that also requires WGPU runtime-ready evidence. Lower-level `--runtime-contract-preset`, `--wgpu-readiness-preset`, explicit `--runtime-device-report-backend`, `--min-run-epoch-wgpu-*`, `--max-run-epoch-wgpu-*`, promotion-ready, or manifest trainer/device WGPU flags override the recipe defaults. Direct trace/import flags such as `--transformers-trace-runtime-import-preset torch-transformers`, `--require-transformers-trace-runtime-import torch`, and `--require-manifest-transformers-trace-runtime-import-preset torch-transformers` remain available for narrower runtime audits; use `hf-finetune` to also require `datasets`/`accelerate`/`safetensors`, or `hf-peft` to include `peft`.
- **LLM (Python, Transformers logit trace):** `PYTHONNOUSERSITE=1 python3 -S -s bindings/st-py/examples/byte_lm_transformers_trace.py --model-path <local-transformers-model> --prompt "spiral route" --jsonl trace.jsonl` records runtime config/tokenizer/model metadata plus next-token top-k logits/probabilities and hidden-state summaries before FT; add `--zspace-project` to attach a bounded Z-space projection probe, `--runtime-contract-preset hf-runtime` to require same-process `transformers`/`torch`/`tokenizers` co-import evidence directly, `--runtime-import-preset torch-transformers|hf-runtime|hf-finetune|hf-peft` or repeated `--runtime-import <module>` to audit narrower same-process imports, persist preset module expansion plus satisfied/failed/coimport status contracts and install hints for known missing HF modules, gate direct traces with `--require-runtime-import torch` or `--require-runtime-import-preset torch-transformers`, and `--require-runtime-metadata-match` during `--compare-jsonl` checks to catch model/tokenizer/runtime swaps.
- **LLM runtime preflight (installed wheel):** `spiral-runtime-preflight --preset hf-full-finetune --require --runtime-device-backend wgpu --json-out ft-runtime.json` checks the local `transformers`/`torch`/`tokenizers` plus `datasets`/`accelerate`/`safetensors`/`pyarrow`/`evaluate`/`peft` stack and records `describe_runtime_devices(["wgpu"])` readiness before a heavier local HF FT run; add `--require-runtime-device-ready-backend wgpu` for strict accelerator gating, `--json` for stdout-based CI output, use `--preset hf-peft` for narrower PEFT adapter workflows or `--preset hf-trl-sft` for TRL SFT handoffs, and call `python -m spiraltorch.runtime_imports ...` when console scripts are unavailable. Runtime-device direct/surrogate readiness, native availability, fallback identity, evidence-preserving `ready`/`not_ready`/`unknown` states, and the ordered executable selection are evaluated by the versioned Rust `spiraltorch.runtime_device_route.v5` contract. Probe success is reported separately from native availability; Python/WASM transport the committed selection, canonical evidence, request/output SHA-256 commitments, and replay result without rebuilding them. Install the strong local FT surface with `pip install "spiraltorch[hf-full-finetune]"`; `hf-gpt2-ft` remains as a legacy extra/preset alias.
- **LLM local HF FT bridge:** `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/hf_finetune_bridge.py --model-configs bindings/st-py/examples/hf_finetune_model_configs.example.json --model-profile qwen2-0.5b-local-smoke --metadata-only --allow-remote --zspace-probe --run-card ft-run-card.json` loads `AutoModelForCausalLM`/tokenizer/dataset metadata after the full HF contract passes, records SpiralTorch WGPU/CPU readiness plus optional Z-Space token-probe metrics, and writes a run card. Model-specific defaults live in `hf_finetune_model_configs.example.json`; start with `causal-lm-local-smoke`, choose `gpt2-local-smoke`, `distilgpt2-local-smoke`, `pythia-70m-local-smoke`, `qwen2-0.5b-local-smoke`, or copy `local-causal-lm-template` for a local checkpoint. Profiles now carry model-family, parameter-scale, and activation-hook hints alongside tokenizer/training/generation defaults, so widening beyond GPT-2 should usually mean editing config rather than script code. Add `--train --train-file data/corpus.txt --validation-fraction 0.02 --max-train-samples 50000 --block-size 128 --output-dir runs/hf-finetune` to enter a real local `AutoModelForCausalLM` / `Trainer` FT loop from local text files; `spiral-hf-profile --launch-plan --train` resolves its default `--mode auto` to `full-finetune`, so launch bundles audit the same stronger dependency surface that real training needs. Use repeated `--train-file` / `--validation-file` plus `--dataset-format text|json|csv` for larger corpora, and add `--corpus-scan` before long runs to stream line/byte/sample stats into the run card without loading the model. Train runs emit `spiraltorch-hf-finetune-trainer-trace.jsonl` from the generic bridge unless overridden; legacy `hf_gpt2_*` Python helper names remain available, while `hf_finetune_*` core helpers now normalize run-card, eval, generation, telemetry, trace, and summary row types for model-neutral imports.
- **LLM local HF LoRA/PEFT:** select `causal-lm-lora-local-smoke`, `gpt2-lora-local-smoke`, `qwen2-0.5b-lora-local-smoke`, or `smollm2-135m-lora-local-smoke` with `spiral-hf-finetune --model-profile <profile> --train ...` to attach a model-family-aware PEFT adapter through the same audited Trainer path. `spiral-hf-profile --launch-plan --train` resolves these profiles to the Trainer-ready `hf-peft-finetune` preflight; direct runs can use `--finetune-mode lora --lora-rank 16 --lora-alpha 32 --gradient-checkpointing`. Run cards retain matched target modules, trainable/frozen counts and ratio, PEFT version, artifact kind, and adapter-save evidence. Successful Trainer saves place the tokenizer beside both full-model and adapter outputs. Adapter-only outputs can return directly to `spiral-hf-finetune --model-name <adapter> --finetune-mode lora` for weights-only continuation without double attachment; each successful save now writes a content-addressed parent/root lineage manifest. Audited continuations carry `--expected-parent-adapter-id`, `--expected-parent-lineage-depth`, and `--expected-root-adapter-id` for the parent adapter plus `--expected-training-input-id` for the path-independent bundle of local model config, ordered corpus/validation files, distortion artifacts, and recursive resume checkpoint. Exact checkpoint resumes also write collision-safe immutable trainer-trace segments, seal parent/current digests in the run card, and revalidate them through adapter-chain and executor audits instead of truncating historical telemetry. Remote Hub corpora independently resolve aliases/branches to a canonical repository commit and propagate `--expected-dataset-input-id`; config, split, text-column, repository, or revision drift is rejected before model loading. After row selection, local and remote runs additionally adopt `--expected-dataset-materialization-id`, hashing the exact ordered train/eval text bytes so mutable external builders, shuffle changes, or row-content drift fail before tokenization and Trainer work. Training runs then adopt `--expected-tokenized-dataset-id`, hashing every post-grouping block and column so changed token IDs, masks, labels, or block boundaries fail before model preparation or Trainer construction. The bridge fingerprints these contracts at their corresponding load boundaries and carries them through adapter lineage, scale-up, and executor continuations. `--eval-before-train --adapter-promotion-gate` requires changed weights plus bounded before/after eval regression, releases the training model/accelerator cache, then launches a separate Python worker for local-only PEFT reload and deterministic bounded generation before promotion. Tune that qualification with `--adapter-promotion-probe-prompt`, `--adapter-promotion-probe-max-new-tokens`, `--adapter-promotion-probe-device`, and `--adapter-promotion-probe-timeout-seconds`; sweeps forward the same knobs, promotion chains revalidate gated roots as well as descendants, and scale-up artifacts retain the exact probe path/device/token/PID/exit evidence they trusted. `spiral-hf-adapter-lineage` and `spiral-hf-adapter-promote --require-artifact-probe` apply the same contracts to existing artifacts, and `st.hf_finetune_checkpoint_resume_report(...)` distinguishes fresh-schedule warm start from exact optimizer/scheduler resume and warns when a saved schedule is already exhausted. `st.load_hf_causal_lm_artifact(...)` reconstructs adapters for local trace, Z-Space inference, generation sweeps, and checkpoint audit; `spiral-hf-adapter-export --adapter <adapter-dir> --output-dir <merged-dir>` creates an atomic standalone model with merge provenance. The lazy attachment API remains `st.prepare_hf_finetune_model(...)`.
- **LLM Z-Space optimizer factorized ablation:** the [HF ablation guide](docs/hf_zspace_optimizer_ablation.md) calibrates one Rust-owned LR trajectory, separates integrated dose from schedule shape, verifies the optimizer's actual effective-LR dose, and compares matched `observe`, `dose_matched_constant`, `raw`, and `dose_normalized` run cards. The Rust-owned `dose_preserving_complement` policy reverses the centered trajectory at exactly matched dose; its audited local GPT-2 study beat both ordinary FT and the original normalized shape for 3/3 seeds while retaining a bounded single-recipe evidence label. The audited multi-corpus study repeated that protocol over three content-distinct corpora: normalized was worse than ordinary FT for 9/9 matched seeds, while the complement beat both arms for 9/9, with all 3/3 corpus means agreeing and a Rust-owned corpus-equal polarity mean of `-0.001712`. This remains a single-model, short-recipe trend rather than an efficacy claim. The runner delegates balanced seed validation and corpus-equal aggregation to `st-core`, rather than pooling seed rows in Python. `--zspace-optimizer-feedback loss_guard` separately routes a proposal through a checkpointed Rust loss/delta gate. The factorized, polarity, corpus-polarity, and feedback study runners freeze and resume their evidence with content, Git, journal, policy-artifact, and run-card identities.
- **LLM Z-Space optimizer feedback evidence:** the [audited three-seed study](docs/hf_zspace_optimizer_ablation.md#audited-feedback-result-2026-08-09) found that the Rust `loss_guard` reduced the same open-loop harm for 3/3 seeds and recovered 56.3% of its mean loss penalty. The guarded arm still beat ordinary FT for 0/3 seeds, so the checked artifact supports mitigation of this failure mode, not an efficacy claim.
- **LLM immutable trainer-trace lineage:** every completed bridge run rebuilds the sealed root-to-tip trace lineage, writes its report plus cumulative summary into the run card, and carries the lineage ID through sweep selection, adapter transitions, and executor telemetry evidence. `st.hf_finetune_trainer_trace_lineage_report(...)` revalidates segment/receipt IDs, parent digests, paths, and boundaries; `st.load_hf_finetune_trainer_trace_lineage(...)` returns ordered rows annotated with segment identity; and `st.summarize_hf_finetune_trainer_trace_lineage(...)` restores the full loss/eval/telemetry curve across exact resumes. Repeated steps from retrying the same checkpoint remain visible as overlap warnings instead of corrupting integrity. Live geometry guards continue to evaluate only the current segment, while generation curves and run-artifact handoffs use the verified cumulative lineage and active tip.
- **LLM local HF recipe identity:** run the intended command once with `--training-recipe-only` to resolve effective Transformers optimizer/scheduler defaults, batch/seed/precision, applied LoRA/full-FT trainability, dtype, resume state, collator, and loss-guard control without constructing Trainer. The run card rewrites its canonical command to `--train --expected-training-recipe-id <sha256:...>`; exact replay fails before `Trainer(...)` on recipe drift, while scale-up explicitly reissues this layer instead of incorrectly enforcing the parent's shorter schedule.
- **LLM local HF full replay identity:** the same adoption pass now binds adapter lineage, local or Hub data source, selected raw rows, tokenized Trainer blocks, model/tokenizer runtime, software/device execution, and the effective recipe into one path-independent `--expected-finetune-replay-id`. Canonical replay still carries each layer's expected ID for earlier diagnostics, then verifies the composite immediately before `Trainer(...)`; intentional scale-up strips and reissues the parent composite because it represents a new run.
- **LLM local HF artifact probe:** `spiral-hf-artifact-probe runs/hf-finetune --prompt "SpiralTorch is" --max-new-tokens 16 --out artifact-probe.json` reconstructs either a full model or PEFT adapter in an isolated worker process, runs bounded generation, and records model family/classes, resolved base/tokenizer, device, token counts, continuation text, timing, worker/parent PIDs, exit status, and timeout evidence. The parent passes probe inputs through a private JSON request rather than repeating the prompt in the worker argv. It is local-files-only by default; add `--allow-remote` when the adapter's base model is not cached, `--device cpu|mps|cuda` for an explicit runtime, `--timeout-seconds 900` for the worker bound, or use `st.hf_causal_lm_artifact_subprocess_probe_report(...)` directly. `st.hf_causal_lm_artifact_probe_report(...)` remains the lower-level same-process diagnostic. Promotion-gated Trainer runs invoke the isolated route automatically after saving and archive it as `spiraltorch-hf-artifact-probe.json`. The [Pythia 70M LoRA qualification sample](bindings/st-py/examples/hf_pythia70m_lora_artifact_probe_sample.json) records a qualified root plus ten real promoted non-GPT-2 continuation generations through target resolution, warm-start continuation without double attachment, runtime release, isolated local-only MPS reload/generation, promotion revalidation, transition audit, executor postflight, policy stop, canonical wheel-native continuation, parent-adapter and local-training-input gates, a model/tokenizer runtime identity adopted at depth seven then enforced at depth eight, and a path-independent software/device execution identity adopted at depth nine then enforced at depth ten.
- **LLM local HF FT sweep:** `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/hf_finetune_sweep.py --model-configs bindings/st-py/examples/hf_finetune_model_configs.example.json --model-profile pythia-70m-local-smoke --train-file data/corpus.txt --validation-fraction 0.02 --corpus-scan --generation-prompt "SpiralTorch is" --generation-from-inference-distortion --eval-before-train --zspace-probe --trainer-telemetry --inference-distortion-probe runs/inference-distortion/live-probe.json --block-size-values 64,128 --learning-rate-values 0.0001,0.00005 --seed-values 7,13 --out-dir runs/hf-finetune-sweep` runs multiple local bridge configurations, writes `sweep-plan.json` before launching, writes `sweep-report.json` afterward, and embeds comparison plus summary payloads so block size, learning rate, seed, eval deltas, generation changes, Z-Space probes, inference-distortion handoff, provider request dropped/sent keys, desire/psi trainer telemetry, and trainer traces can be compared before scaling the corpus. For LoRA sweeps, add `--eval-before-train --adapter-promotion-gate`: blocked/evidence-incomplete rows remain auditable, but only promotion-ready adapters can be selected or reused, and `scale-up-command.json` automatically continues the winning adapter weights as the next lineage parent rather than restarting from its original model. Use `spiral-hf-scale-up ... --adapter-continuation replay` for configuration-only replay or `--adapter-continuation continue` to require a non-gated adapter handoff; preflight checks adapter files, input/output separation, lineage depth/fingerprint, and promotion evidence. A sweep with no ready candidate exits nonzero. The generic bridge/sweep wrappers rewrite run-card, sweep-plan, sweep-report, and scale-up-command artifacts to model-neutral row types. Use `--inference-distortion-sweep-report runs/zspace-inference-distortion-sweep/sweep-report.json` instead when a multi-probe grid has already been ranked. Add `--dry-run` to inspect commands, `--resume-existing` to continue interrupted sweeps from successful run cards, `--force` to rerun every row intentionally, or `--require-wgpu-ready` to gate each run on SpiralTorch WGPU readiness; use `st.summarize_hf_finetune_sweep_report(...)` to recover the selected scale-up run, command/run-card/trace paths, and top candidates from Python.
- **LLM local HF adapter promotion chain:** `spiral-hf-adapter-chain runs/hf-finetune-study --out runs/hf-finetune-study/promotion-chain.json --require-continuation-ready` re-fingerprints every discovered adapter, validates parent/root/depth and promotion/run-card evidence, preserves failed branches, and selects a unique deepest ready tip. Its `transitions` rows make each parent-to-child depth step, fingerprint/weight check, eval handoff and improvement, promotion revalidation, isolated-probe PID/exit evidence, and pinned training, model/tokenizer, and execution-environment identities directly auditable instead of requiring node-by-node inference. Once a generation adopts the composite fine-tune replay identity, every descendant must publish a verified replacement: reusing or dropping the parent composite blocks the edge because adapter input and effective recipe are generation-scoped. Pass that report directly to `spiral-hf-scale-up ... --write-command next-generation.json --require-ready`; the command artifact and preflight retain the selected transition, inject the expected parent ID/depth/root and input IDs into the child launch, and resolve recorded relative model-config/corpus/distortion/checkpoint inputs against the source run card's `launch_cwd`. New FT run cards record that working directory and their exact launch command, so a promoted generation can become the next parent without returning through a sweep or depending on the executor's current directory. Known historical bridge-script and `spiral-hf-finetune` commands are rewritten to the current interpreter's `python -m spiraltorch.hf_finetune_entrypoint`, while the original prefix remains in provenance and unknown custom launchers remain untouched. `spiral-hf-adapter-executor` carries runtime, all input identities, recipe/composite reissue contracts, and the selected edge through state, pending plans, attempts, recovery, postflight, and read-only status/runtime output, and refuses promotion when transition, an enforced identity contract, or module evidence is not ready. Equal-depth forks require `--select-adapter-id`, while pre-lineage local seeds are inferred only after their live fingerprint matches the declared root ID.
- **LLM local HF FT ops (installed wheel):** `spiral-hf-run-status runs/hf-finetune`, `spiral-hf-status-history runs/hf-finetune/direct-run-status-history.jsonl`, `spiral-hf-wait-launch --manifest next.json --dry-run -- spiral-hf-finetune ...`, `spiral-hf-wait-launch-summary runs/hf-finetune/long-run-wait-launch-history.jsonl`, `spiral-hf-milestone-capture runs/hf-finetune --milestone-step 4096`, `spiral-hf-milestone-runtime runs/hf-finetune --execute`, `spiral-hf-run-artifacts runs/hf-finetune`, and `spiral-hf-run-ops runs/hf-finetune` keep long local HF runs monitorable and handoff-ready through generic `hf_ft_*` line prefixes and artifact names; the importable `spiraltorch.hf_finetune_*` ops helpers now emit model-neutral row types too, while legacy GPT-2 scripts remain compatible.
- **LLM local HF FT long-run controls:** add `--max-eval-blocks N`, `--eval-after-train-policy skip-if-final-step-eval`, and the default `--dataloader-pin-memory auto` when local MPS/CPU evaluation becomes the bottleneck; the generic bridge records both pre-cap and post-cap eval block counts plus the resolved dataloader settings in the run card for any configured `AutoModelForCausalLM` profile.
- **LLM local GPT-2 FT generation sample:** [`bindings/st-py/examples/hf_gpt2_finetune_generation_sample.json`](bindings/st-py/examples/hf_gpt2_finetune_generation_sample.json) records a sanitized long-run sample where the fixed prompt shifts from generic Torch/Tor wording before training to SpiralTorch runtime / Python bindings wording after 640/1280/2560 local GPT-2 FT steps, alongside eval-loss and trace-throughput evidence.
- **LLM Z-Space generation control sample:** [`bindings/st-py/examples/hf_gpt2_zspace_generation_control_sample.json`](bindings/st-py/examples/hf_gpt2_zspace_generation_control_sample.json) records the same 2560-step local GPT-2 prompt after `ZSpaceRepressionLogitsProcessor` control, showing native `spiraltorch_zspace_softmax` telemetry and repetition-repression top-token changes that relax the greedy wrapper loop.
- **LLM Z-Space generation control sweep:** `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/hf_zspace_generation_control_sweep.py --model-configs bindings/st-py/examples/hf_finetune_model_configs.example.json --model-profile pythia-70m-local-smoke --prompt "SpiralTorch is a tensor and geometry runtime that" --zspace-entropy-target-values none,3.0 --repression-strength-values 0.0,0.75,1.25 --last-token-repression-values 0.0,1.0 --out runs/hf-zspace-generation-control-sweep.json` loads one local or remote `AutoModelForCausalLM` once, runs a small Z-Space/repression decode grid without Trainer or datasets, and writes generated text, bounded `generation_control` telemetry, and loopiness metrics for fast post-FT decoding experiments. Swap profiles to move beyond GPT-2, or pass `--model-name runs/gpt2-small-zspace-ft --tokenizer-name gpt2` for a direct checkpoint replay; dry-run artifacts now include `generation_control_profile_config`, `generation_control_grid`, and reusable sweep/bridge CLI args resolved from the selected profile. Use `st.load_zspace_generation_control_sweep(...)`, `st.summarize_zspace_generation_control_sweep(...)`, or `st.summarize_zspace_generation_control_sweep_lines(...)` to rank runs by loop score and top-token changes from Python, including `recommended_config`, `recommended_processor_kwargs`, `recommended_sweep_cli_args`, and `recommended_bridge_cli_args` for the next decode run. The Python helpers `st.zspace_generation_control_profile_config(...)`, `st.zspace_generation_control_processor_kwargs(...)`, `st.zspace_generation_control_sweep_cli_args(...)`, and `st.zspace_generation_control_bridge_cli_args(...)` also accept or resolve HF profiles/runtime plans, so profile generation defaults can be reused directly without hand-copying Z-Space knobs.
- **LLM Z-Space profile generation defaults:** `spiral-hf-profile --model-configs bindings/st-py/examples/hf_finetune_model_configs.example.json --model-profile pythia-70m-local-smoke --generation-control-config --json` resolves the selected HF profile into reusable `processor_kwargs`, sweep CLI args, and bridge CLI args, keeping model-specific generation/Z-Space knobs in config samples instead of GPT-2-specific scripts.
- **LLM checkpoint generation-control plans:** `spiral-hf-checkpoint-generation-control --dry-run --run-dir runs/hf-finetune --checkpoint checkpoint-4096 --model-configs bindings/st-py/examples/hf_finetune_model_configs.example.json --model-profile pythia-70m-local-smoke --run-card checkpoint-control.json` builds checkpoint replay, compare, and optional curve commands while recording the same `generation_control_profile_config` plus reusable sweep/bridge CLI args at the plan level.
- **LLM Z-Space generation control grid sample:** [`bindings/st-py/examples/hf_gpt2_zspace_generation_control_grid_sample.json`](bindings/st-py/examples/hf_gpt2_zspace_generation_control_grid_sample.json) records a compact 13-run local GPT-2 2560-step grid where softmax-only keeps the greedy wrapper loop, while repression changes top-token ranks and drives the measured loop score from `13.0` to `0.0`.
- **LLM Z-Space inference distortion probe:** `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/zspace_inference_distortion_probe.py --model-configs bindings/st-py/examples/hf_finetune_model_configs.example.json --model-profile pythia-70m-local-smoke --prompt "SpiralTorch is a tensor and geometry runtime that" --out runs/zspace-inference-distortion-probe.json` applies one shared desire/psi distortion adapter to local HF logits, local activation hooks, and an API-model-shaped runtime context before re-FT; installed wheels expose the same route as `spiral-zspace-inference-distortion-probe`. Model/tokenizer and local activation-hook defaults now come from the same profile file used by FT (`causal-lm-local-smoke`, `gpt2-local-smoke`, `distilgpt2-local-smoke`, `pythia-70m-local-smoke`, `qwen2-0.5b-local-smoke`, or a copied `local-causal-lm-template`), so Pythia uses `gpt_neox.layers.0`, Qwen/SmolLM-style models use `model.layers.0`, OPT uses `model.decoder.layers.0`, and GPT-2 profiles keep `transformer.h.0` unless overridden. From Python, `st.zspace_inference_distortion_runtime_plan(model_profile="qwen2-0.5b-local-smoke")` resolves the same local model, tokenizer, generation, and activation-hook defaults. Use `--local-model <checkpoint-or-model>`, `--tokenizer-name <tokenizer-or-dir>`, or `--activation-name-contains <module-substring>` only when overriding the profile or targeting a freshly trained checkpoint. Without a local model it still runs a keyless fake API path; use `--api-provider openai-responses|openai-chat|anthropic --api-model <model>` to send the same request/context distortion through a live provider, add `--from-sweep-report runs/zspace-inference-distortion-sweep/sweep-report.json` to replay the sweep-recommended prompt/runtime/config, `st.summarize_zspace_inference_distortion_probe(...)` to flatten changed-text, top-token-change, activation, and API telemetry into one comparison row, or `st.compare_zspace_inference_distortion_probes(...)` to rank several probe artifacts before choosing the next FT/decode setting.
- **LLM Z-Space inference distortion sweep:** `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/zspace_inference_distortion_sweep.py --model-configs bindings/st-py/examples/hf_finetune_model_configs.example.json --model-profile qwen2-0.5b-local-smoke --prompt "SpiralTorch is a tensor and geometry runtime that" --desire-pressure-values 0.45,0.8 --psi-total-values 0.5,0.75 --coherence-values 0.35,0.55 --api-provider fake --out-dir runs/zspace-inference-distortion-sweep` writes a reusable `sweep-plan.json`, per-setting probe artifacts, `sweep-report.json`, and `sweep-report.md` with `compare_zspace_inference_distortion_probes(...)` results, a recommended probe/config, replay commands, installed replay commands for `spiral-zspace-inference-distortion-probe` / `spiral-zspace-inference-distortion-sweep`, and Python summaries via `st.load_zspace_inference_distortion_sweep(...)` / `st.summarize_zspace_inference_distortion_sweep(...)` so local HF internal hooks and API-model request/context distortion can be compared before the next FT run. Profile-derived replay commands preserve `--model-configs` / `--model-profile` and only spell out explicit overrides, keeping model-specific runtime choices in the config sample. Swap profiles to move beyond GPT-2 without editing scripts; the selected profile carries the default activation hook substring unless you pass `--activation-module-name` or `--activation-name-contains` explicitly. Pass `--local-model runs/gpt2-small-zspace-ft --tokenizer-name gpt2` for a direct checkpoint replay, swap `--api-provider` to `openai-responses`, `openai-chat`, or `anthropic` with `--api-model <model>` when you want the same pressure grid to hit a live hosted model, add `--resume-existing` to continue an interrupted/costly sweep without re-calling matching successful probes, `--report-only` to rebuild comparisons from existing probe JSON, `--from-probe runs/inference-distortion/live-probe.json` to promote one or more saved local/API probe artifacts into a reusable pre-FT sweep report without re-calling providers, or `--force` to intentionally rerun every row.
- **LLM (API model + Z-space runtime):** `PYTHONNOUSERSITE=1 python3 -S -s bindings/st-py/examples/api_llm_zspace_runtime.py` shows how an OpenAI-compatible response or arbitrary hosted-model callable becomes a Z-space partial trace with device preflight evidence, usage/latency telemetry, and posterior confidence. With `OPENAI_API_KEY` plus `pip install openai`, run `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/openai_api_llm_zspace_runtime.py --prompt "Describe SpiralTorch entering Z-space runtime."` to hit the OpenAI Responses API through the same bridge. With `ANTHROPIC_API_KEY` plus `pip install anthropic`, run `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/anthropic_api_llm_zspace_runtime.py --prompt "Describe SpiralTorch inference as bipolar geometry."` to route Anthropic Messages into the same trace path.
- **LLM (API model prompt suite):** `PYTHONNOUSERSITE=1 PYTHONPATH=bindings/st-py python3 -S -s bindings/st-py/examples/api_llm_prompt_suite.py` runs several hosted-model-shaped prompts through one Z-space runtime, writes a compact JSONL artifact, and compares the suite without network access. `PYTHONNOUSERSITE=1 PYTHONPATH=bindings/st-py python3 -S -s bindings/st-py/examples/api_llm_provider_suite_compare.py` runs the same prompts through OpenAI-shaped and Anthropic-shaped callables, writes one JSONL artifact per route, and ranks the provider matrix by the same Z-space route score.
- **LLM (API model open-topos sweep):** `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/api_llm_topos_sweep.py --prompt-limit 3 --context-prompt --out-dir /tmp/spiraltorch-topos-sweep` compares open/contextual/guarded topological runtime adapters around one provider-shaped callable, writes one JSONL trace per route plus `report.json` with bounded response previews, route scorecards, pairwise route deltas, response-side route winners, and balanced/quality/grounded/efficiency/latency selection profiles, and works offline by default. Add `--live-provider openai-responses|openai-chat|anthropic --model <model>` with the matching SDK/key installed to replay the same sweep through a hosted model.
- **RL (stAgent policy trace):** `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/stagent_policy_trace.py --steps 200 --jsonl-out /tmp/stagent-policy.jsonl` runs a tiny native DQN bandit loop, emits per-step `select_action_trace()` records with Q-values/epsilon/explore-vs-greedy metadata, and prints a final `policy_report()` summary for handoff into Z-space/topos route selectors.
- **LLM × RL (topos route policy):** `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/api_llm_topos_stagent_route_policy.py --out-dir /tmp/spiraltorch-topos-policy --profile grounded --policy-out /tmp/spiraltorch-topos-policy/policy.json` turns an open-topos sweep report into bounded route rewards, trains an stAgent-shaped policy, and prints the selected route plus Q-value trace, reusable `policy_selection`, request controls, and runtime route. The Rust-owned v2 score contract treats missing metrics neutrally, applies sample-count shrinkage, omits unobserved routes, and revalidates reward source evidence during resolution. Stored v1 reward arrays do not contain that witness and must be rebuilt from their original sweep rows before resolution; legacy rows without a positive observation `count` must be remeasured. Pass `--report /tmp/spiraltorch-topos-sweep/report.json` to reuse a live or offline sweep without re-calling providers.
- **LLM (live API provider matrix):** `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/api_llm_live_provider_matrix.py --prompt-limit 12 --repeat 3 --near-best-tolerance 0.02 --out-dir /tmp/spiraltorch-live-matrix` replays a larger prompt population through OpenAI Responses plus any available Anthropic routes (`claude-opus-4-8`, `claude-fable-5` by default), records per-route JSONL traces, and writes `report.json` with route settings, route score, near-best routes, quality/efficiency/text-quality score breakdowns, prompt coverage, repetition, latency, token, refusal, empty-text, completion-rate comparisons, and `selection_profiles` for balanced, quality, grounded, efficiency, or latency-sensitive routing. Claude 5/Opus 4.8 routes use adaptive thinking with `output_config.effort` rather than non-default sampling parameters, so keep `--anthropic-max-tokens` comfortably above the visible answer size to avoid measuring budget truncation instead of model behavior.
- **LLM (live API provider matrix sweep):** `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/api_llm_live_provider_matrix_sweep.py --prompt-limit 12 --repeat 3 --budget-pairs 192:768,256:1024 --resume-existing --out-dir /tmp/spiraltorch-live-matrix-sweep` runs multiple live matrix budgets, writes one `report.json` per budget pair, then writes `sweep-report.json` with `compare_api_llm_matrix_reports(...)` so profile-winner stability and route tradeoffs can be audited across repeated sweeps. Use `--dry-run` to inspect the planned matrix without calling provider APIs, `--resume-existing` to avoid re-calling APIs for completed budget pairs, or `--force` to rerun them intentionally.
- **LLM (live OpenAI + WASM context):** `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/openai_api_llm_wasm_context_runtime.py --wasm-report report.json --include-context-prompt --write-wasm-context-artifact /tmp/spiraltorch-wasm-context.json --trace-jsonl /tmp/spiraltorch-openai-wasm-trace.jsonl` sends a browser-exported WASM learning report through the OpenAI Responses bridge, optionally prepends bounded Z-space/WASM telemetry to the hosted-model prompt, persists the selected context handoff, and records trace telemetry such as `wasm.loss` and `wasm.webgpu_device_ready` beside the hosted response.
- **LLM (API model trace comparison):** `PYTHONNOUSERSITE=1 PYTHONPATH=bindings/st-py python3 -S -s bindings/st-py/examples/api_llm_trace_compare.py` compares multiple API LLM trace JSONL artifacts by route score, quality score, efficiency score, deterministic text-quality score, prompt coverage, confidence, latency, token use, runtime readiness, health penalties, near-best routes, profile-specific route selections, Z-space metrics, and attached WASM context signals such as browser-side loss and WebGPU readiness. The typed Rust `spiraltorch.api_llm_route_policy.v1` contract owns every normalization, score, winner, rank, and near-best decision; Python gathers traces and renders its evidence witness, while WASM exposes the same contract to browser clients.
- **LLM (API model report comparison):** `PYTHONNOUSERSITE=1 PYTHONPATH=bindings/st-py python3 -S -s bindings/st-py/examples/api_llm_report_compare.py` compares multiple live provider-matrix `report.json` files with `compare_api_llm_matrix_reports(...)`, then summarizes profile-winner stability, route-score means, latency/token tradeoffs, skipped providers, client-error counts, carried WASM context loss/WebGPU readiness, and whether selected browser contexts were consistent across repeated sweeps.
- **LLM (coherence scan, raw text, no tokenizer):** `cargo run -p st-nn --example modelzoo_llm_char_coherence_scan -- <text.txt> [--context-scale 0.05 --mix-rms 0.1 --head-rms 0.1 --head-residual-scale 1.0 --head-prior unigram|bigram|learned-bigram --bigram-topk-guard 0.05 --bigram-topk-guard-k 5] [--val-fraction 0.1 --eval-samples 256]`
- **LLM (Python, coherence scan, raw text, no tokenizer):** `PYTHONNOUSERSITE=1 python3 -S -s models/python/llm_char_coherence_scan.py <text_or_dir> [<text_or_dir> ...] [--context-scale 0.05]`
- **LLM (coherence wave, raw text, no tokenizer):** `cargo run -p st-nn --example modelzoo_llm_char_coherence_wave -- <text.txt> [--mix-rms 0.1 --head-rms 0.1 --head-residual-scale 1.0 --head-prior unigram|bigram|learned-bigram --bigram-topk-guard 0.05 --bigram-topk-guard-k 5] [--val-fraction 0.1 --eval-samples 256] [--infuse \"spiral\" --infuse-every batch --infuse-mode separate]`
- **LLM (Python, coherence wave, raw text, no tokenizer):** `PYTHONNOUSERSITE=1 python3 -S -s models/python/llm_char_coherence_wave.py <text_or_dir> [<text_or_dir> ...] [--infuse \"spiral\" --infuse-every batch --infuse-mode separate]`
- **LLM (Python, WaveRnn+Mixer, attentionless):** `PYTHONNOUSERSITE=1 python3 -S -s models/python/llm_char_wave_rnn_mixer.py <text.txt>`
- Example (Python, desire + atlas): `PYTHONNOUSERSITE=1 python3 -S -s models/python/llm_char_coherence_wave.py models/samples/spiral_demo_en.txt --desire --events models/runs/demo_desire/events.jsonl --atlas --run-dir models/runs/demo_desire`
- WGPU quickstart (build + run): `bash scripts/wgpu_quickstart.sh`
- **Vision (Conv/Pool):** `cargo run -p st-nn --example modelzoo_vision_conv_pool_classification`
- **Vision (Python, Conv/Pool):** `PYTHONNOUSERSITE=1 python3 -S -s models/python/vision_conv_pool_classification.py`
- **GNN (roundtable graph regression):** `cargo run -p st-nn --example modelzoo_gnn_graph_regression`
- **GNN trace (band replay coefficients):** `cargo run -p st-nn --example gnn_trainer_band_trace_demo`
- GNN graph-level training uses `ZSpaceGraphBatchRegressor` for fixed-size graph mini-batches, so row-concatenated node tensors read out to one prediction row per graph instead of collapsing the whole batch into one graph.
- GNN band-trace sweeps can grid `--epoch-values`, `--batch-values`, `--node-values`, `--feature-values`, graph-count values, `--lr-values`, and roundtable axes such as `--top-k-values` / `--here-tolerance-values`; generated run names, group averages, `Top Validation Candidates`, and `Roundtable Axis Deltas` include those axes so validation-wide readout MSE, band replay deltas, step time, and CPU debt can be compared without mixing unlike shapes or schedules. The same candidate and delta records are stored under `comparison` in `sweep.json`, and `--follow-up-from previous/sweep.json` replays a ranked top validation candidate while still allowing explicit grid overrides such as new seeds or wider `--top-k-values`. Add `--follow-up-neighborhood --follow-up-neighborhood-axes lr,top_k,bottom_k` to automatically fan out a local schedule search around that candidate without hand-copying the winning axes; follow-up reports also emit `Follow-Up Result` / `comparison.follow_up_result` with the new best-vs-source validation MSE verdict, `Follow-Up Promotion` / `comparison.follow_up_promotion` naming the candidate to carry forward, and `--follow-up-fail-on-verdict regressed,unknown` writes `Follow-Up Gate` / `comparison.follow_up_gate` while turning that verdict into an optional non-zero gate. A later `--follow-up-from` uses promotion by default when present (`--follow-up-source auto`), with `--follow-up-source top-candidate` available when you want to ignore the conservative promotion choice; `Next Follow-Up Command` / `comparison.follow_up_next_command` provides a runnable template for the next chained sweep, and `config.follow_up.lineage` records parent path/run root plus follow-up generation for multi-step chains.
- Multi-seed GNN comparisons also add seed stability fields to `Top Validation Candidates` and mirror them as `Stable Validation Candidates` / `comparison.stable_validation_candidates`, ranking schedules by `avg_validation_readout_mse + validation_mse_stddev` so low-average but volatile candidates can be separated from repeatable wins before promotion. Trace and compare artifacts also include `validation_readout_nmse` / `avg_validation_readout_nmse`, normalizing validation MSE by target mean-square energy so seed shifts caused by harder target draws can be diagnosed separately from schedule effects.
- Follow-up compare artifacts also emit `Follow-Up Chain` / `comparison.follow_up_chain`, `Follow-Up Ancestors`, `Follow-Up Chain Guidance` / `comparison.follow_up_chain_guidance`, and `Guided Next Follow-Up Command` / `comparison.follow_up_guided_next_command`, so parent generation, source mode, selected candidate source, prior verdicts, promotion actions, verdict streaks, candidate stability status, raw/NMSE replay deltas, and a replay/neighborhood command template with explicit `NEXT_RUN_ROOT` / `NEW_SEEDS` placeholders stay visible across multi-step GNN tuning runs. If an `improved` candidate is still `single_seed_probe` or `volatile`, guidance asks for fresh seeds before continuing promotion; if repeated improvements remain `volatile`, it switches to `widen_stability_search` with `--follow-up-neighborhood --seeds NEW_SEEDS`, and if volatility survives that neighborhood pass it emits `increase_sample_budget` with doubled epoch/train/validation graph values. When a larger-budget run regresses on average but surfaces a more stable top candidate, `review_stability_tradeoff` reruns that top candidate with fresh seeds instead of silently discarding the stability win; if the review only finds a tiny average improvement that is less stable than the source, `keep_source_stability_guard` keeps the seed-stable source and guides another fresh-seed confirmation. Once repeated improvements are `multi_seed_stable` / `watch_spread`, `explore_stable_neighborhood` anchors the promoted candidate and adds `--follow-up-neighborhood --seeds NEW_SEEDS` so the next run broadens locally instead of replaying the same stable point. A stable neighborhood win uses `confirm_stable_promotion` with fresh seeds before broadening again. Follow-up results also surface `source_replay_*` fields when the new sweep re-runs the source schedule; if a neighborhood looks regressed only because the source replay shifted upward on fresh seeds while the best neighbor matches or beats that replay, `review_seed_shift_neighborhood` repeats the source-anchored neighborhood with fresh seeds before locking the old source. If raw MSE regresses but source replay NMSE does not, `review_target_scale_shift` reruns with fresh seeds and a wider validation graph budget before treating the run as a schedule loss. If seed-shift evidence is itself `volatile`, `increase_seed_shift_validation_budget` keeps the source anchor but doubles `--validation-graph-values` before another promotion decision; if seed-shift regressions repeat, `widen_seed_shift_neighborhood` widens locally with explicit fresh seeds instead of replaying an old seed surface, and after persistent seed-shift regressions `audit_seed_sensitivity` pauses widening to remeasure the source with a broader seed list and validation budget. The same guided command is written as `next_follow_up_command.sh` inside the run directory, using environment variables for required placeholders.
- GNN tensor-utility threshold grids use `tools/run_gnn_threshold_grid.py --thresholds 1,1024 ...`; WGPU rows preflight once by default, `grid.json` keeps preflight/failure rows, and `compare.md` reports predicted CPU/WGPU routes, actual utility op routing, validation-wide readout graph counts, and CPU debt.
- **Coherence (ZSpace VAE):** `cargo run -p st-nn --example modelzoo_zspace_vae_reconstruction`
- **Coherence (Python, ZSpace VAE):** `PYTHONNOUSERSITE=1 python3 -S -s models/python/zspace_vae_reconstruction.py`
- **Coherence (Python, Text→ZSpace VAE):** `PYTHONNOUSERSITE=1 python3 -S -s models/python/zspace_text_vae.py models/samples/spiral_corpus_en --mellin ramp`
- **Coherence (Python, Text VAE on/off compare):** `PYTHONNOUSERSITE=1 python3 -S -s models/python/zspace_text_vae_compare.py models/samples/spiral_corpus_en --mellin ramp`
- **LLM (Python, VAE context features):** `PYTHONNOUSERSITE=1 python3 -S -s models/python/llm_char_vae_context.py models/samples/spiral_corpus_en --features raw,reconstruction,latent,raw_latent,reconstruction_latent --feature-normalize-modes blocks,vector --hybrid-latent-scales 0.5,1.0 --seeds 7,13`; the sweep report surfaces mean NLL/accuracy plus win and near-win stability by seed, including hybrid raw+latent and reconstruction+latent context probes with normalization/latent-scale config grids, `best_config`, and a chained `next_follow_up_command.sh` fresh-seed confirmation script. Add `--latent-dims 8,16,32 --hidden-sizes 64,128` to compare VAE/head capacity in the same sweep; config reports and follow-up commands preserve the winning capacity. A later `--follow-up-from previous/summary.json` reuses that best config and source feature set by default, then writes `follow_up_result` / `Follow-Up Result` plus `follow_up_chain` / `Follow-Up Chain` with generation, ancestors, verdict history, and streaks. It also emits `follow_up_ancestors` / `Follow-Up Ancestors`, `follow_up_trajectory` / `Follow-Up Trajectory`, `follow_up_guidance` / `Follow-Up Guidance`, and `guided_next_follow_up_command` / `Guided Next Follow-Up Command` so parent run summaries, cumulative NLL movement, trajectory/source-feature conflict flags, promote/continue/stop decisions, tie-aware runner-up uncertainty, and the executable next-step script stay visible in the report; unsafe trajectory promotions disable the guided next command until the source-feature tradeoff is audited. Add `--follow-up-fail-on-verdict regressed,unknown` when automation should write the report but return non-zero for weak follow-up outcomes; generated follow-up scripts preserve that gate through `FOLLOW_UP_FAIL_ON_VERDICT`.
- **LLM (Python, live VAE run monitor):** `PYTHONNOUSERSITE=1 python3 -S -s tools/summarize_char_vae_live_runs.py previous/mainline_scale_up` summarizes long in-progress context runs, including remaining seeds, current feature, remaining active-seed features, completed-seed winners, and active best-so-far deltas.
- **LLM (Python, VAE context chain runner):** `PYTHONNOUSERSITE=1 python3 -P tools/run_char_vae_context_chain.py models/samples/spiral_corpus_en --preset small --follow-ups 1` runs a parent context-feature sweep, follows generated guidance with fresh seeds, and writes `chain.json` / `chain_report.md` so improved confirmations and seed-shift gate stops are both preserved as first-class experiment evidence. When the current best and runner-up are within combined seed uncertainty, generated follow-up commands boost confirmation to five fresh seeds; the chain runner records seed precedence in the chain artifacts and uses those command defaults unless a matching `--follow-up-seed-groups` entry explicitly overrides that follow-up, with `follow_up_seed_group_plan` mapping group slots to attempted / unused-after-stop / extra status, `follow_up_seed_resolution` plus its summary recording the actual per-follow-up seeds/source used, and `extra_explicit_seed_groups` / `unused_explicit_seed_groups` staying disjoint. Compare multiple chains with `PYTHONNOUSERSITE=1 python3 -P tools/summarize_char_vae_context_chains.py models/runs --recursive --markdown-out comparison.md --json-out comparison.json --command-out-dir commands --write-command-inspection`; the comparison report highlights the accepted champion separately from the absolute best chain when gate-stop evidence needs review before promotion, then emits a recommendation such as `continue_from_accepted` or `review_absolute_best` with the relevant summary paths and a command directory containing `recommended_next.sh`, runnable follow-up/review scripts, README/manifest context, bundled comparison JSON/Markdown artifacts, input chain sources, and strict inspection reports. Re-inspect an existing command bundle with `PYTHONNOUSERSITE=1 python3 -P tools/inspect_char_vae_command_bundle.py commands --strict --write-report`, or run the inspected next step through `PYTHONNOUSERSITE=1 python3 -P tools/run_char_vae_command_bundle.py commands --write-inspection-report --write-run-report --append-run-history --write-run-history-report`; regenerate `run_history.md` / `run_history_summary.json` without executing or appending via `PYTHONNOUSERSITE=1 python3 -P tools/run_char_vae_command_bundle.py commands --history-report-only`; run a bounded automation pass with `PYTHONNOUSERSITE=1 python3 -P tools/run_char_vae_history_loop.py commands --max-steps 3 --fail-on-max-steps-continuation --write-loop-report`, which defaults to non-zero for review/inspect final actions and can also fail when the step bound is exhausted while a runnable continuation remains. Generated bundle README/manifest files include the absolute runner command plus `run.json` / `run.md` paths, an append-only `run_history.jsonl`, a human-readable `run_history.md`, and a machine-readable `run_history_summary.json` for automation handoff. Generated recommendation wrappers record and `cd` back to the comparison-time working directory before running, while generated manifests/README files use absolute handoff paths so later inspection does not depend on the caller's cwd. The `small`/`base` presets scout hybrid latent scales through `4.0`; `capacity_scout` adds `--latent-dims` / `--hidden-sizes` grids around the hybrid4 recipe, `capacity_zoom` expands the upper-edge signal with `--latent-dims 12,16,24 --hidden-sizes 32,64` at scale `4.0`, `capacity_lockin` reruns the confirmed `latent_dim=12 hidden=64` raw+latent setting on five fresh seeds, and `capacity_train` keeps that capacity fixed while increasing the train/eval budget for longer learning passes. Each feature head saves both final `head_<feature>.json` and validation-best `head_<feature>_best.json` weights, with checkpoint health in the report; reload a run for evaluation with `--vae-load previous/text_vae_weights.bin --head-load-dir previous --eval-only`, or omit `--eval-only` to continue training from those heads. Add `--allow-gate-stop` when a gate stop should be recorded as evidence without failing the outer automation.
- **LLM (Python, promoted VAE recipe eval):** `PYTHONNOUSERSITE=1 python3 -P tools/run_char_vae_promoted_recipe.py previous/summary.json --json` inspects a promoted `mainline_scale_up_command.promoted_learning_recipe` and reports the per-seed eval-only reload commands; add `--ready-only --complete-only` to skip seeds whose VAE / requested best feature-head checkpoints or source run summary are not present yet, `--execute --seed 1043` to run a selected seed, or `--write-report` to persist `promoted_recipe_eval_run.json` / `.md` beside the source summary. Summarize executed reload evidence with `PYTHONNOUSERSITE=1 python3 -P tools/summarize_char_vae_promoted_eval_runs.py previous/promoted_recipe_eval_run.json`; once reload evidence promotes and the mainline run summary exists, the summary also surfaces the next mainline scale-up command plus a `screen` launch command that writes `run.log`.
- **Training (Lightning/selfsup):** `cargo run -p st-nn --example modelzoo_lightning_selfsup_minimal`

### 🌐 WebAssembly (WASM) demos (not a stub)

SpiralTorch’s WASM bindings are now **fully runnable** in the browser: geometry evaluation, small training loops, and WebGPU visualisation work end-to-end.

- **Mellin log grid (WASM):** evaluate meshes + run a tiny “match reference” training loop  
  `bash scripts/wasm_demo.sh mellin-log-grid dev`
- **Canvas hypertrain (WASM):** `FractalCanvas` learning loop + WebGPU trail + FFT probe + **target-MSE supervised mode**  
  `bash scripts/wasm_demo.sh canvas-hypertrain dev`
- **WASM → API LLM context:** pass exported browser reports into the hosted-model
  route matrix with `--wasm-report report.json`, or run the keyless bridge with
  `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/api_llm_wasm_context_runtime.py --wasm-report report.json`
  For a live OpenAI smoke, run
  `PYTHONPATH=bindings/st-py python3 bindings/st-py/examples/openai_api_llm_wasm_context_runtime.py --wasm-report report.json --trace-jsonl /tmp/spiraltorch-openai-wasm-trace.jsonl`
  Use `--wasm-report-dir runs --wasm-report-recursive --wasm-max-reports 3` to
  select the best browser-side learning runs before they become LLM context;
  Python can audit promotion readiness with `st.audit_wasm_report(...)` /
  `st.audit_wasm_report_context(...)`, then persist the selected handoff with
  `st.write_wasm_report_context_artifact(...)`.

Browser runtimes can also fuse telemetry and Z-space partials through the same
Rust-owned contracts used by Python. WASM adds only client metadata; metric
aliases, weighting, suppression, reduction, flattening, and audit semantics stay
in `st-core::telemetry::zspace_fusion`:

```ts
const projected = zspaceMetricGradientProjectionObject({
  metrics: { speed: 0.4, memory: 0.2, stability: 0.8, frac: 0.3, drs: -0.1 },
  dimension: 2,
});
const fused = zspacePartialFusionObject({
  partials: [
    {
      metrics: { velocity: 0.4, gradient: projected.gradient },
      gradient_basis: projected.basis,
      origin: "canvas",
    },
    { metrics: { speed: 0.8 }, weight: 2.0, origin: "webgpu" },
  ],
  strategy: "mean",
  gradient_alignment: "strict",
  telemetry: [{ browser: { webgpu_ready: true } }],
});
```

Partial fusion contract v3 rejects gradients whose declared bases differ even
when their vector lengths match. Tagged and untagged gradients cannot be mixed,
so positional coincidence is not treated as semantic compatibility. It also
rejects ragged active gradients by default instead of silently inventing
coordinates. Set `gradient_alignment: "pad_zero"` only for an explicit
legacy-compatible replay within one basis; the result reports
`gradient_padding_applied`, `gradient_padded_source_count`, and per-source
`gradient_padded` audit fields. `zspaceMetricGradientProjectionObject` and
`st.zspace_metric_gradient_projection(...)` expose the same Rust-owned periodic
projection from `[speed, memory, stability, frac, drs]`; API response and
distortion adapters use that basis rather than constructing unrelated feature
vectors in Python. `ApiLLMZSpaceRuntime` additionally requests
`metric_gradient_dimension` during partial fusion, so Rust first fuses the
named scalar metrics and then projects one canonical runtime-width gradient;
heterogeneous positional gradients from context clients are replaced and
reported instead of being silently relabelled. Python preserves that native
receipt as `ZSpaceInference.fusion`, so API traces expose the exact projection
and replacement counts. The `mean`, `last`, `max`,
`min`, `median`, and `sum` reducers apply identically to scalar metrics and
compatible gradient coordinates in Rust.

The Rust Topos projection follows the same rule: contract v2 includes the
six-axis `spiraltorch.topos.control_signal.axes.v1` basis, its ordered channels,
and the exact truncation/zero-padding formula. Python and WASM transport that
identity rather than naming or reconstructing the control vector themselves.

Posterior decoding follows that same Rust-first boundary. Python's
`ZSpacePosterior` and the browser's `zspacePosteriorDecodeObject` /
`zspacePosteriorProjectObject` are clients of
`st-core::inference::zspace_posterior`; neither layer reconstructs spectral
energy, gradients, barycentric weights, residual confidence, or telemetry
adjustments. For an auditable Python payload, call
`st.zspace_posterior_decode(...)` or `st.zspace_posterior_project(...)` and
check the returned `contract_version` and `semantic_owner`. Posterior v2 uses a
one-sided Parseval-normalized spectrum, reports spectral energy/error/centroid,
and keeps its latent finite-difference gradient in the versioned
`st.ZSPACE_POSTERIOR_LATENT_GRADIENT_BASIS`. An external gradient is never
resized or substituted for that latent gradient: attach an explicit
`gradient_basis`, then read the preserved values from `control_gradient`.
`ZSpaceTrainer.step_partial(...)` consumes the Rust latent gradient and does not
silently apply that external control; a control-to-latent projection must be an
explicit, basis-aware Rust contract.
Residual RMS is computed only over observed canonical metrics, while telemetry
can reduce confidence through an audited reliability factor but cannot erase
geometric residual or increase confidence.

Coherence diagnostics follow the same rule. `ZSpaceCoherenceSequencer` exposes
the complete Rust diagnostics and linguistic contour, while
`st.zspace_coherence_project(...)` delegates gain validation, base metric
projection, dimension-normalized entropy/concentration summaries, structural
classification, and contour metrics to `st-core::inference::zspace_coherence`:

```python
import spiraltorch as st

topos = st.OpenCartesianTopos(-0.9, 1e-5, 10.0, 32, 1024)
sequencer = st.ZSpaceCoherenceSequencer(16, 2, -0.9, topos=topos)
x = st.Tensor((1, 16), data=[0.1] * 8 + [0.8] * 8)
out, coherence, diagnostics = sequencer.forward_with_diagnostics(x)
contour = sequencer.emit_linguistic_contour(x)
control = diagnostics.control
contract = st.zspace_coherence_project(
    diagnostics,
    coherence=coherence,
    contour=contour,
)
assert contract["semantic_owner"] == "st-core::inference::zspace_coherence"
assert contract["derived"]["distribution_source"] == "normalized_weights"
assert contract["classification"]["label"] == diagnostics.observation.label
assert control["contract_version"] == "spiraltorch.zspace_coherence_control.v1"
assert contract["control"]["spectral_radius"] == control["spectral_radius"]
```

Python remains the orchestrator; it does not reconstruct the Rust diagnostics
or carry a second projection formula. Rust preserves raw `mean_coherence` and
raw Shannon entropy for audit, but derives trainer-facing spectral radius,
entropy, and pressure from normalized HHI concentration and `H / ln(N)` so
channel count alone cannot change the control signal. Pass diagnostics directly
with `trainer.push_coherence_diagnostics(diagnostics)`; replayed trace events are
accepted only when their Rust contract provenance, complete probability-simplex
witness, summaries, classification, and control values still agree. Trace schema
v2 carries that witness, and the Rust bridge decodes the stable plugin record
before rebuilding the projection; legacy scalar-only traces remain readable for
inspection but cannot command trainer controls.
The same versioned Rust policy emits `background`, `symmetric_pulse`,
`cascade_imbalance`, or `diffuse_drift` with an explicit reason and thresholds;
trace, Python, and WASM only transport that decision. Call
`diagnostics.classify(...)` or pass `background_energy_ratio_max` and
`cascade_energy_ratio_min` to `st.zspace_coherence_project(...)` to select a
different Rust policy.

Projection contract v2 also validates that all supplied evidence describes one
observation: entropy, support counts, and the dominant channel must agree with
`normalized_weights`, while `mean_coherence` must agree with the raw
`coherence` response when present. Python and WASM surface the resulting Rust
error instead of repairing or reinterpreting contradictory evidence.

Portable clients can explicitly build and validate the same evidence boundary:

```python
import spiraltorch as st

witness = st.zspace_coherence_distribution_witness([0.5, 0.3, 0.2])
summary = st.validate_zspace_coherence_distribution_witness(witness)
assert witness["semantic_backend"] == "rust"
assert summary["channels"] == 3
```

Runtime plan scoring follows the same ownership rule. Variational free energy
is evaluated only by `st-core::heur::free_energy`; Python and WASM transport the
same request and return the versioned Rust report. Missing or numerically tiny
band evidence returns to the configured prior, band potentials are centred on
that prior, and `acceptance_probability` is the explicit two-state Gibbs
probability against a neutral `F=0` candidate rather than a calibrated
confidence claim:

```python
import spiraltorch as st

report = st.zspace_free_energy(
    reference_loss=0.8,
    candidate_loss=0.5,
    step_time_ms=12.0,
    memory_mb=256.0,
    band={"above": 0.6, "here": 0.3, "beneath": 0.1},
)
print(report["free_energy"], report["acceptance_probability"])
```

```ts
const report = zspaceFreeEnergyObject({
  observation: {
    reference_loss: 0.8,
    candidate_loss: 0.5,
    band: { above: 0.6, here: 0.3, beneath: 0.1 },
  },
});
```

### Why SpiralTorch  

Modern ML stacks were built around CUDA—fast, but closed and rigid.  
**SpiralTorch** aims to make high-theory GPU computing *portable* again.  
It keeps the expressive PyTorch-style API that researchers already know, but runs on **WGPU** (Metal / Vulkan / DX12), so the same code works across macOS, Windows, and Linux without vendor lock-in.  

Where frameworks chase throughput, SpiralTorch chases **fidelity**: exact spectral operators, stable autodiff at microlocal scales, and a cooperative scheduler designed for reproducible research.  
You can start with existing PyTorch checkpoints via `spiraltorch.compat.torch`, move training loops unchanged, and gradually adopt SpiralTorch’s runtime for fine-grained control over kernels and device orchestration. Attention, softmax, and related primitives are being fused in the WGPU backend so PyTorch users can migrate critical kernels one pass at a time without sacrificing stability.

It’s not just an engine—it’s a **bridge** between the pragmatism of deep-learning frameworks and the precision of computational geometry.  

---

**Architecture Overview.**
```mermaid
%%{init: {'themeVariables': {'fontSize': '20px', 'lineColor': '#7f8cfc'}, 'sequence': {'actorFontSize': 22, 'messageFontSize': 19, 'noteFontSize': 18}}}%%
sequenceDiagram
  participant API as Python/TS API
  participant Bridge as PyO3/wasm bindings
  participant Session as Session manager
  participant Core as st-core orchestrator
  participant Planner as Graph planner + scheduler
  participant Autodiff as st-tensor AutogradTensor
  participant Reg as Op registry
  participant Caps as Capability DB
  participant Layout as Layout strategist
  participant KD as st-kdsl compiler
  participant Cache as Kernel cache/tuner
  participant Mem as Arena allocator
  participant Stream as Stream graphifier
  participant Queue as Command queue mgr
  participant BE as Backend (WGPU/CUDA/CPU)
  participant TLM as Telemetry/observability
  participant Prof as Profiler/exporter

  API->>Bridge: op(x, y, ...) / launch async task
  Bridge->>Session: hydrate handles / authz
  Session->>Core: dispatch request (device scope)
  Core->>Autodiff: capture gradients / tape guards
  Autodiff-->>Core: differentiation plan
  Core->>Planner: build execution graph (policy, determinism)
  Planner->>Layout: negotiate layout / sharding
  Layout-->>Planner: residency strategy + halo exchange
  Planner->>Reg: request op impl (tensor traits, precision)
  Reg->>Caps: verify backend + layout capabilities
  Caps-->>Reg: supported modes / tiling hints
  Reg->>Prof: emit planning span metadata
  Prof-->>Reg: sampling budget / trace tokens
  par cache probe vs compilation
    Reg->>Cache: fetch tuned kernel handle
    Cache-->>Reg: kernel + launch params
  and
    Reg->>KD: request codegen + schedule lowering
    KD->>Cache: autotune + persist kernel artifact
    Cache-->>Reg: kernel handle + tuning metadata
  end
  Reg-->>Planner: impl + schedule + kernel handle
  Planner->>Mem: acquire arenas / residency locks
  Mem-->>Planner: buffer views + relocation plan
  Planner->>Stream: expand passes → async stages
  Stream-->>Planner: dependency DAG + replay guards
  Planner-->>Core: executable pass graph
  Core->>Queue: enqueue passes (async futures)
  loop execution waves
    Queue->>BE: submit pipelines / barriers
    BE->>Mem: residency updates / reuse hints
    BE->>Autodiff: gradient materialisation callbacks
    BE-->>Queue: completion events + result buffers
    Queue->>TLM: forward stage timings / counters
  end
  Queue-->>Core: ready futures / error states
  Core->>Prof: flush spans + counter deltas
  Prof-->>TLM: export traces / profile artefacts
  Core--)TLM: spans / metrics / structured logs
  Core-->>Session: promise handle / stream token
  Session-->>Bridge: async completion signal
  Bridge-->>API: awaitable result / telemetry hook
```

Reverse-mode meaning is owned once by `st-tensor::AutogradTensor`; Python and
WASM expose handles to that graph, while WGPU/CPU backends execute its tensor
operations without redefining derivatives. `AmegaHypergrad` and
`AmegaRealgrad` remain Z-space optimizer/accumulator tapes rather than a second
compute graph. See the [Rust-owned autograd contract](docs/autograd_contract.md)
for the exact ownership boundaries and v1 invariants.

The graph also supports `add_row`, `relu`, tanh-approximate `gelu`, and
`row_softmax`, including their Rust VJPs. Leaves and saved gradients capture
protected snapshots: mutating an imported NumPy/PyTorch array cannot silently
change a previously built graph. Run `python examples/autograd_xor.py` with a
native wheel, or `cargo run -p st-tensor --example autograd_xor`, for a bounded
600-step nonlinear learning fixture. This checks learning mechanics, not LLM
fine-tuning quality.

For multiclass or flattened-token training, `row_log_softmax()` and
`cross_entropy_with_logits(labels, label_smoothing=0.05)` now share stable
Rust CPU kernels across Tensor, autograd, Python and WASM. Integer labels,
ignored tokens and reduction rules live in one core; `nn.CrossEntropyWithLogits`
connects it to `ModuleTrainer`. The [classification contract](docs/autograd_contract.md#classification-from-logits)
explains the boundaries. `python examples/autograd_classification.py` runs a
300-step, three-class learning fixture without NumPy or PyTorch.

For GPU-resident class-last logits, the same loss exposes
[`evaluate_resident(logits, labels)`](docs/module_resident_classification.md)
across Rust, Python and WASM, connecting classification to resident VJP and
explicit learner updates without intermediate CPU observations.

For larger effective batches, [resident microbatch accumulation](docs/module_resident_microbatch.md)
combines gradients across changing inputs in reusable GPU buffers before one
transactional update, with explicit sample weighting and stale-state rejection.
An optional [global gradient norm limit](docs/module_resident_gradient_clip.md)
clips the policy-normalized window on GPU before the all-parameter update;
Rust, Python and WASM share the same rule without a norm readback.
Optional [Topos EMA momentum](docs/module_resident_momentum.md) keeps gradient
history resident and commits it together with all parameters, including
explicit reset, disable/re-enable and failed-update recovery rules.

Version 0.4.23 adds `st.AutogradSgd(parameters, learning_rate=0.1)`
for plain Rust-owned CPU updates. Fetch `optimizer.parameters()` for each forward
pass, call `loss.backward()`, then `optimizer.step()`. All parameters are replaced
with fresh immutable leaves together; missing gradients or overflow cannot leave
a partial update. Python and WASM classification fixtures use this path. See
[atomic SGD](docs/autograd_contract.md#atomic-sgd-for-immutable-leaves) for the
ownership rules and the distinction from Z-space optimizer tapes.

Version 0.4.24 corrects the shared `st-frac::fft` radix-4 sign and binary-reversal
ordering, including inverse transforms and singleton signals. The allocation-free
mixed radix-2/4 path remains in place; Python and WASM use the same corrected Rust
kernel rather than a client-side DFT fallback:

```python
import spiraltorch as st

spectrum = st.frac.fft_real([1.0, 2.0, 3.0, 4.0])
assert spectrum == [(10.0, 0.0), (-2.0, 2.0), (-2.0, 0.0), (-2.0, -2.0)]
restored = st.frac.fft_complex32(spectrum, inverse=True)
```

Forward uses the negative-exponent convention; inverse divides by the signal
length. This fixes `fft_real`, `fft_complex32`, `fft_radix4`, WASM FFT helpers,
and their Canvas/temporal-fusion callers. Earlier nontrivial FFT-derived results
from these paths should be recomputed: impulse-only checks did not validate bin
order or phase. These helpers remain CPU/WASM transforms, not WebGPU dispatch.

Version 0.4.25 stabilizes affine LayerNorm on CPU and WGPU, including large
offsets with small variance and finite values whose variance exceeds f32.
`nn.LayerNorm` backward now uses the same Rust-owned centered moments.
Python can reuse the un-affined normalized values and per-row inverse standard
deviation directly:

```python
import spiraltorch as st

x = st.Tensor(1, 4, [10000.0, 10001.0, 10002.0, 10003.0])
normalized, inverse_std = x.layer_norm_stats(epsilon=1e-5)
assert normalized.shape() == (1, 4)
assert inverse_std.shape() == (1, 1)
```

The statistics helper is CPU/f64 with finite f32 outputs; affine forward retains
its WGPU kernel. Constant rows require positive epsilon. Recheck earlier
LayerNorm-derived results on offset-heavy inputs; this is a numerical correction,
not evidence of improved LLM fine-tuning quality.

Version 0.4.27 connects affine LayerNorm to the native reverse-mode graph:
`x.layer_norm_affine(gamma, beta)` now works on `AutogradTensor` in Python,
with the same Rust VJP exposed as WASM `layerNormAffine`. All three operands
can learn; affine gradients sum rows without hidden batch averaging.
Plain tensors expose `layer_norm_affine_backward(gamma, upstream)` for a
graph-free VJP. CPU backward keeps f64 intermediates; `nn.LayerNorm` shares the
core while retaining its existing WGPU utility path and parameter-update scale.
See the [contract and examples](docs/autograd_contract.md#affine-layernorm), or
run `python examples/autograd_layer_norm.py` for a 400-step learning fixture.

Source builds also expose exact integer row indexing: `Tensor.gather_rows(ids)`
and `scatter_add_rows(ids, output_rows)`, plus the same differentiable operations
on `AutogradTensor`. Repeated IDs accumulate rather than overwrite; IDs are never
rounded or clamped. `python examples/autograd_tied_embedding.py` learns a small
token-transition fixture with one embedding table shared by lookup and output
projection. See [row indexing](docs/autograd_contract.md#integer-row-indexing)
for CPU/WGPU precision and browser boundaries. This addition is not in PyPI 0.4.27.

**Licensing**

SpiralTorch ships under a dual-license model:

- **Open-source:** [AGPL-3.0-or-later](docs/licensing.md#open-source-license-agpl-30-or-later) for community contributions and network-transparent deployments.
- **Commercial:** Flexible subscriptions with priority support for teams that need to keep modifications private or run proprietary SaaS. [Explore tiers and contact details →](docs/licensing.md#commercial-license)

<p align="center">
  <img src="https://img.shields.io/badge/Rust-first-orange.svg" alt="Rust first">
  <img src="https://img.shields.io/badge/WGPU-supported-blueviolet.svg" alt="WGPU supported">
  <img src="https://img.shields.io/badge/MPS-ready-brightgreen.svg" alt="MPS ready">
  <img src="https://img.shields.io/badge/CUDA-enabled-lightblue.svg" alt="CUDA enabled">
  <img src="https://img.shields.io/badge/License-AGPL--3.0-blue.svg" alt="AGPL-3.0">
</p>

<p align="center">
  <b>SpiralTorch — a Rust-first learning framework for Z-space.<br>
  Runs natively on WGPU · MPS · CUDA · CPU.</b>
</p>

- © 2025 Ryo ∴ SpiralArchitect — Licensed under AGPL-3.0-or-later  
- Contact: [Discussions](https://github.com/RyoSpiralArchitect/SpiralTorch/discussions) · <mailto:kishkavsesvit@icloud.com>  
- Unauthorized derivations are non-compliant with AGPL §13  
- **For research collaborations or integration inquiries, please reach out directly.**
- **Cloud integrations:** see [Cloud Integration Guide](docs/cloud_integration.md) for
  Azure and AWS deployment blueprints.
- **If you’re cloning this automatically for analysis:** please cache once, respect AGPL, and avoid generating unnecessary traffic to the maintainer or future contributors. Any network-facing use must comply with AGPL §13.
- **Non-Goals (unsupported):** anonymous/“hands-off” operators, managed hosting, production babysitting, automated scraping/mirroring/star-farming

## Code stats

<!-- STATS:START -->
> _auto-generated: 2026-09-07 12:31 UTC_

| Metric | Value |
|---|---:|
| Rust code LOC | **411,351** |
| Rust files | 767 |
| Total code LOC (all langs) | 1,502,544 |
| Workspace+deps crates | 427 |

<p>
<img src="docs/badges/rust-loc.svg" alt="rust loc" />
<img src="docs/badges/total-code.svg" alt="total code" />
<img src="docs/badges/deps.svg" alt="crates" />
</p>
<!-- STATS:END -->
---

**SpiralTorch is a Rust-first AI training framework** that keeps language,
geometry, and device heuristics in the same conversation. SpiralK orchestrates
the kernels, the hypergrad tape streams Z-space meaning, and the high-level
`st-nn` modules stay PyTorch-compatible without shipping NumPy or PyTorch.

The stack is comfortable living entirely in Rust—yet the Python wheel remains a
thin veneer that reuses the same planners, losses, and Z-space resonators. No
tensor shims, no translation layers, and no tracebacks.

---

## 🚀 Latest SpiralTorch highlights

- **Learning Stack (model zoo).** Runnable baselines (Rust + Python) including raw-text char LMs (no tokenizer), coherence scan/wave, and an attentionless `WaveRnn+Mixer` variant; use `--desire` to bias sampling and `--events ... --atlas` to emit telemetry routes (see `models/README.md`).
- **Fractal → Quantum RL bridge.** Stream Mellin-log fractal patches straight into the quantum overlay studio and recover policy gradients through `FractalQuantumTrainer` and friends—keeping Python fallbacks and PyO3 builds in lockstep.
- **Self-evolving SpiralK kernels.** A new diversity governor inside `SelfRewriteEngine` tracks plateauing η̄ gains, forces fresh AI rewrites when caches go stale, and surfaces telemetry via `diversity_snapshot()` so operators can keep the autonomous kernel lab on course.
- **Saga-aware kernel evolution.** The `SelfRewriteEngine` now learns multi-step hint sagas, boosting cache priority for sequenced rewrites and exposing the orbits via `saga_snapshots()` so you can audit every cosmic combo.
- **Reinforcement-tuned hint genetics.** Hint chains earn reward-weighted feedback, anomaly filters freeze outliers, recombination fuses cached winners, graph snapshots illuminate hint affinity, and `take_trace()` streams the self-evolution log when `--debug-self-evolution` is enabled.
- **Chain-policy reinforcement.** Cached hint chains now feed a lightweight Q-style policy inside `SelfRewriteEngine`, boosting cache priority via chain multipliers, exposing telemetry with `chain_policy_snapshots()`, and logging `PolicyUpdate` traces whenever the self-evolution loop reshapes its instincts.
- **Contextual bandit autopilot.** A UCB-flavoured bandit now rides alongside the cache, weighting hint reuse via `bandit_snapshots()` telemetry, steering exploration with `with_bandit_*` knobs, and leaving `BanditUpdate` traces whenever rewrites learn a new favourite arm.


## Why it’s different
 - **Training comes first:** Modules such as `Linear`, `Sequential`,
   `WaveGate`, the new `ToposResonator`, and `ZSpaceProjector` stream gradients
    into the hypergrad tape and expose a `train_epoch` loop that mirrors
    familiar `nn.Module` patterns.
  - **Open Z-space:** Gradient splits honour the A/B/C roundtable through the
    new `zspace_round` ops module so Above/Here/Beneath bands stay in sync with
    SpiralK plans without auxiliary buffers.
  - **Hilbert-grounded Mellin bridges:** `st-frac::mellin::MellinLogGrid`
    now exposes fallible APIs, a `Scalar` alias for f32/f64 toggling, exact
    lattice bit-matching, and WebGPU-backed vertical/mesh sweeps that reuse the
    same `st-frac::zspace` weights while `hilbert_inner_product` and
    `evaluate_vertical_line` surface the lattice’s Hilbert geometry directly.
  - **Three-voice consensus:** SpiralK heuristics, DSL directives, and the
    generated WASM tuner table discuss every launch decision and keep the
    transcript in the roundtable log.
  - **Rust by default, Python ready:** Every feature—from WASM tuning to
    hypergrad curvature—is implemented in Rust and exposed unchanged through the
    Python bindings when needed.
  - **Unified RL + Rec stacks:** SpiralTorchRL and SpiralTorchRec keep policy
    gradients, recommendation factors, and hypergrad tapes inside the same
    Z-space geometry so deployment-grade loops never leave Rust.
  - **Z-space-native graph reasoning:** The Rust core, backend abstraction
    layer, and Z-space operators already form the spine of a graph neural
    network stack that embeds large-scale, hierarchical graphs with the same
    fidelity as its tree-aligned geometry.
  - **Semiotic suturing at the logit level:** The new `st-nn::language`
    toolkit folds symbolic kernels, repression fields, and semantic bridges
    into a single Lagrangian so SpiralTorch can bias logits with desire,
    anchor S/s correspondences, and respect target entropies without leaving
    Z-space.
  - **Interpretability as a first-class citizen:** Hypergrad tapes, roundtable
    transcripts, and ψ telemetry double as explainability artifacts, enabling
    decision-path inspection without leaving the Z-space calculus.
    
**Current release:** [![PyPI](https://img.shields.io/pypi/v/spiraltorch.svg?label=spiraltorch)](https://pypi.org/project/spiraltorch/) (abi3 wheel, Python ≥3.8)  
**Targets:** CPU (always), MPS, Vulkan/DX (WGPU), CUDA, HIP/ROCm

---

## Install (pip)

```bash
pip install -U spiraltorch
```

- Wheels are **abi3**; you can use any CPython ≥ 3.8.
- Prebuilt wheels ship for **Windows**, **manylinux2014 (x86_64)**, and **macOS 14+ (universal2)**.
- The published wheel is built with `wgpu,logic,kdsl` (CPU always available; WGPU activates when a compatible backend is present).
- For macOS < 14 or other targets, build from source.

### wheel

Without cloning the repo, `pip install spiraltorch` gives you:

- **Core tensors + optimisers:** `st.Tensor`, autodiff, `st.optim.Amegagrad`, DLPack interop.
- **Native neural layers:** `st.nn.Linear`, `Embedding`, `Sequential`, losses,
  `ModuleTrainer`, `LoraLinear`, and `ZSpaceProjector`.
- **Checkpoint handoff:** checked `state_dict` compatibility reports,
  key-mapped loads, overlap resize/projection preflight, and HF-style presets.
- **Geometry:** `st.frac.MellinLogGrid` (Mellin mesh / verticals) + Hilbert helpers.
- **Signal tools:** `st.MaxwellFingerprint` expectation curves (visualisation-ready).
- **Z-space training utilities:** `st.ZSpaceTrainer`, `st.LanguageWaveEncoder`.
- **Rust-owned evaluation protocols:**
  `st.zspace_runtime_protocol_catalog()` exposes the content-addressed Rust,
  Python, and WASM surface for held-out generation evidence, bounded
  token-periodicity analysis, repetition-unlikelihood plans, and blinded
  semantic review. Persisted
  catalogs can be replayed with `st.validate_zspace_runtime_protocol_catalog(...)`;
  every client surface records its normal-admission profile, while serialized
  Python/WASM surfaces also carry Rust-owned byte/node/depth limits. Catalogued
  Python/WASM paths remain bounded, WASM object helpers stay trusted-local and
  outside that guarantee, and trusted legacy replay is explicit and never
  exposed to WASM.
- **Canvas + observability:** `st.canvas.CanvasProjector`, `st.telemetry.*`, HTML trace writers, `st.serve_zspace_trace`.
- **SpiralK planning:** `st.plan_topk(...)`, the Rust-owned
  `st.RankPlan.contract()` audit payload, `st.write_kdsl_trace_jsonl`, and
  `st.write_kdsl_trace_html`; invalid rank shapes and device-capability
  overrides fail closed in the Rust planner. SpiralK contexts and hard rewrites
  use that same planner contract, so Python never clamps or reinterprets rank
  choices independently.
- **API-model LLM bridge:** `st.ApiLLMZSpaceRuntime` converts hosted LLM
  responses/callables into Z-space runtime traces without requiring an API SDK
  at install time; when optional provider packages are available,
  `st.make_openai_responses_invoke(...)`, `runtime.call_openai_responses(...)`,
  `st.make_anthropic_messages_invoke(...)`, or
  `runtime.call_anthropic_messages(...)` can use provider keys from the
  environment directly. Persist runs with
  `runtime.write_jsonl("api_llm_trace.jsonl")`, reload with
  `st.load_api_llm_trace_events(...)`, and compare runs with
  `st.summarize_api_llm_trace_events(...)` or
  `st.compare_api_llm_trace_runs({"baseline": "a.jsonl", "candidate": "b.jsonl"})`.
  The runtime derives its shared gradient width from `len(z_state)` by default.
  When injecting a prebuilt Topos/WASM/geometry context, build it with that same
  `gradient_dim`, or set `gradient_dim=...` on the runtime/suite explicitly;
  mismatched active gradients fail under the Rust-owned `strict` contract.
  Use `runtime.run_prompts(...)` or `st.run_api_llm_prompt_suite(...)` for a
  multi-prompt bipolar/Z-space suite backed by OpenAI, Anthropic, or any
  compatible callable. Use `st.run_api_llm_prompt_suite_matrix(...)` when the
  same prompts should be replayed across several provider routes and compared
  from their persisted JSONL traces. Trace comparison also surfaces
  `empty_text_rate`, `refusal_rate`, `completion_rate`, and stop-detail
  categories so provider safety behavior does not hide behind raw confidence.
- **FT diagnostics:** tokenizerless byte-LM profile smokes, Transformers logit
  trace capture, runtime import audits, and WGPU readiness gates.

### Python orientation after install

If you only want to confirm the wheel and choose a runtime route, start with:

```python
import spiraltorch as st

print("spiraltorch", st.__version__)
print("cpu:", st.describe_device("cpu")["backend"])
print("wgpu:", st.describe_device("wgpu").get("backend"))

session = st.SpiralSession(backend="auto")
print("session backend:", session.backend)
print("effective backend:", getattr(session, "effective_backend", session.backend))
```

Runtime route readiness and workload-kernel readiness are deliberately separate.
The v6 `spiraltorch.runtime_execution_plan` contract lets native Rust observe the
exact declared component shapes, bias bindings, device limits, and lazy pipelines.
Those results live in a nested v2
`spiraltorch.runtime_component_capability_observation` contract that binds the
runtime probe, canonical workloads, selected Rust policy, evidence, and both
commitment hashes. Kernel support is decided by `st-tensor`, not reconstructed by
`st-core`: host readiness carries `static_host_contract`, while accelerator readiness
requires exact workload preflight plus an operation-specific device dispatch/readback
sentinel and carries `runtime_dispatch_sentinel`. Passing `component_workloads=` to
`st.evaluate_runtime_execution_plan(...)` invokes that Rust observer automatically;
WASM exposes the same contract as JSON/Object transport instead of rebuilding the
rules in JavaScript. The execution plan owns policy selection; the capability
observer measures that resolved policy and cannot replace it. Naked client-supplied
capability arrays are rejected. The commitment is reproducibility evidence, not
cryptographic hardware attestation, and
undeclared workloads remain unobserved. Once a committed plan is installed, every
declared workload is bound exactly through tensor dispatch: shape, bias, or utility
operation mismatches are rejected before a kernel call. Undeclared components remain
dynamic and continue through operation-time capability checks.
Receipt self-validation deliberately does not treat a well-formed plan hash as
authorization. Supply the original committed plan to make Rust replay the plan and
reapply its exact workload, backend, threshold, and fallback rules:

```python
import spiraltorch as st

workload = {"component": "softmax", "rows": 2, "cols": 3}
plan = st.evaluate_runtime_execution_plan(
    st.describe_device("cpu"),
    accelerator_fallback="allow",
    tensor_util_wgpu_min_values=1024,
    component_resolution="deferred",
    component_workloads=[workload],
)
receipt = {
    "kind": "spiraltorch.tensor_execution_receipt",
    "contract_version": "spiraltorch.tensor_execution_receipt.v1",
    "semantic_owner": "st-tensor::execution",
    "component": "softmax",
    "operation": "row_softmax",
    "workload": workload,
    "requested_backend": "cpu",
    "selected_backend": "cpu",
    "executed_backend": "cpu",
    "kernel_backend": "cpu",
    "route_status": "direct",
    "runtime_execution_plan_output_sha256": plan["output_sha256"],
}
validated_receipt = st.validate_tensor_execution_receipt_against_runtime_plan(
    receipt,
    plan,
)
```

WASM exposes the same operation as
`tensorExecutionReceiptValidateAgainstRuntimePlanJson` and
`tensorExecutionReceiptValidateAgainstRuntimePlanObject`; neither client rebuilds
the authorization rules.
Standalone evaluation uses `component_resolution="concrete"`, so strict plans reject
unobserved accelerator capabilities rather than guessing that a workload is ready.

For ordinary training, let `SpiralSession` capture that contract once. Rank plans,
trainers, schedules, optimizer checkpoints, and replayed sessions then inherit the
same Rust-owned commitment instead of reading mutable environment configuration
again. A session records `component_resolution="deferred"`: this does not label
unobserved kernels native; it commits the Rust policy and leaves shape-specific
capability checks to each operation:

```python
import spiraltorch as st

session = st.SpiralSession(
    backend="cpu",
    tensor_util_wgpu_min_values=37,
)
rank = session.plan_topk(rows=8, cols=64, k=4)
trainer = session.trainer()

assert rank.runtime_execution_plan_output_sha256 == session.runtime_execution_plan_output_sha256
assert trainer.runtime_execution_plan_output_sha256 == session.runtime_execution_plan_output_sha256

replayed = st.SpiralSession.from_runtime_execution_plan(session.runtime_execution_plan)
assert replayed.runtime_execution_plan_output_sha256 == session.runtime_execution_plan_output_sha256
```

The returned `runtime_execution_plan` is an isolated copy. Supplying a committed
plan together with backend, capability, or execution-config overrides fails closed,
and executable materialization rechecks the receiving Rust build and local runtime.
`backend="auto"` is only orchestration order: Python asks Rust for WGPU readiness
first and tries CPU only when Rust returns an explicit unavailable signal and the
captured fallback policy allows it. Plan validation, transport, and configuration
errors remain visible instead of silently changing the backend.
`SPIRALTORCH_STRICT_GPU=1` is captured by Rust and forbids that CPU retry; it also
keeps small tensor-utility operations on WGPU instead of applying the performance
threshold as an implicit fallback. `st.resolve_runtime_execution_config()` exposes
the exact Rust-captured policy for inspection.

When a plan is built separately, bind it before creating a training schedule so
rank planning and every tensor kernel share that same context:

```python
import spiraltorch as st

plan = st.evaluate_runtime_execution_plan(
    st.describe_device("cpu"),
    accelerator_fallback="allow",
)
trainer = st.nn.ModuleTrainer(backend="cpu")
trainer.bind_runtime_execution_plan(plan)
schedule = trainer.roundtable(rows=8, cols=64)

assert trainer.runtime_execution_plan_output_sha256 == plan["output_sha256"]
```

Plans are validated and materialized in Rust. A tampered, blocked, or locally
unavailable plan leaves the trainer unchanged, while a schedule created under a
different device/config contract is rejected before the epoch starts.

Rank planning is intentionally narrower than execution. Python and WASM can validate
a committed plan and reuse its capabilities, configuration, and parent SHA without
claiming that their local process has the corresponding tensor executor. Sessions and
trainers still cross the stricter `BackendPolicy` boundary before running any kernel.

Then pick the path that matches the job:

- **Native learning loop:** use `st.Tensor`, `st.nn`, `st.optim`, and
  `st.SpiralSession` directly when you want SpiralTorch-owned tensors,
  checkpoints, traces, and WGPU/CPU routing.
- **Interop-first experiment:** use `spiraltorch.ecosystem` or DLPack when a
  PyTorch/JAX/CuPy/TensorFlow object should cross into SpiralTorch without
  rewriting the whole training stack at once.
- **LLM / FT preflight:** run
  `bindings/st-py/examples/checkpoint_preflight.py`,
  `byte_lm_transformers_trace.py`, or `byte_lm_profile_smoke.py` against local
  checkpoint files before committing to heavier fine-tuning.
- **Dependency contract before a run:** use the CLI or the top-level Python
  helper to record optional runtime evidence without making Hugging Face
  packages hard dependencies of the wheel.
- **Source build or custom backend:** keep the wheel path for ordinary use, and
  switch to the maturin commands below only when you need local Rust changes,
  CPU-only artifacts, CUDA/HIP flags, or a release-equivalent wheel.

For the dependency contract path, either run the CLI:

```bash
spiral-runtime-preflight --preset hf-full-finetune --require --json-out ft-runtime.json
```

or keep the evidence inside Python:

```python
import spiraltorch as st

report = st.runtime_import_preflight_report(
    runtime_import_presets=["hf-full-finetune"],
    required_runtime_import_presets=["hf-full-finetune"],
)
print(report["runtime_import_preflight_passed"])

ft_report = st.hf_finetune_model_profile_preflight_report(
    profile="qwen2-0.5b-local-smoke",
    mode="full-finetune",
    runtime_device_backends=["wgpu", "cpu"],
)
print(ft_report["runtime_import_preset"])
```

---

## Build from source (cargo)

**Prereqs**

- Rust stable (`rustup`), Cargo
- macOS: Xcode CLT / Linux: build-essentials
- Optional GPU stacks: CUDA / ROCm / Vulkan as needed

**Workspace build**

```bash
# Debug (fast iteration)
cargo build --workspace

# Release (optimised)
cargo build --workspace --release

# Run tests
cargo test --workspace
```

For the complete Cargo member inventory, including packages that are workspace
members but not root `default-members`, see
[`docs/development/workspace_crates.md`](docs/development/workspace_crates.md).

**Per-crate**

```bash
cargo build -p st-core        # core math/runtime
cargo build -p st-nn          # neural helpers
cargo build -p st-vision      # vision kernels/pipelines
```

**Feature flags (typical)**
- `cpu` — CPU fallback (on by default in many crates)
- `wgpu` — Metal/Vulkan/DX12 backends via WGPU
- `cuda` — CUDA kernels
- `hip` — HIP planner + CPU reference contract (no executable ROCm kernels)
- `hip-real` — executable ROCm/HIP kernels

---

## Build Python wheel (maturin)

```bash
# Install maturin (once). 1.9+ is required so wheel license-files are emitted.
python -m pip install -U "maturin>=1.9,<2"

# Default binding build (WGPU-first; CPU fallback remains available)
maturin build -m bindings/st-py/Cargo.toml --release --locked

# Release-equivalent (matches PyPI wheels: default WGPU route + logic/kdsl)
maturin build -m bindings/st-py/Cargo.toml --release --locked --features logic,kdsl

# macOS 14+ universal2 (matches macOS wheels on PyPI)
export MACOSX_DEPLOYMENT_TARGET=14.0
maturin build -m bindings/st-py/Cargo.toml --release --locked --target universal2-apple-darwin --features logic,kdsl

# CPU-only (drop the default WGPU route but keep the standard Python surface)
maturin build -m bindings/st-py/Cargo.toml --release --locked --no-default-features --features python-default,cpu

# Add CUDA or real HIP alongside the default WGPU-first wheel
maturin build -m bindings/st-py/Cargo.toml --release --locked --features cuda,logic,kdsl
maturin build -m bindings/st-py/Cargo.toml --release --locked --features hip-real,logic,kdsl

# Backend-specific builds without the default WGPU route
maturin build -m bindings/st-py/Cargo.toml --release --locked --no-default-features --features python-default,cuda,logic,kdsl
maturin build -m bindings/st-py/Cargo.toml --release --locked --no-default-features --features python-default,hip-real,logic,kdsl

# Planner/reference-only HIP contract (contains no executable GPU kernels)
maturin build -m bindings/st-py/Cargo.toml --release --locked --no-default-features --features python-default,hip

# Install the wheel you just built
pip install --force-reinstall --no-cache-dir target/wheels/spiraltorch-*.whl
```

If your local `python` aborts or prints startup output from a third-party
`sitecustomize.py`, rerun the build with `PYTHONNOUSERSITE=1`. Startup output can
also confuse PyO3's interpreter probe; `python -s` disables user-site hooks for
direct Python invocations.

Linux note: for manylinux2014 wheels you either need a manylinux container (e.g. via GitHub Actions) or `maturin --compatibility manylinux2014 --zig` (requires `pip install maturin[zig]`). Building directly on Ubuntu without these may produce wheels that won’t install on older distros.

### CI wheel stash (GitHub Actions)

- Manual wheel artifact build: `.github/workflows/wheels.yml`
- Official release build + attached assets: `.github/workflows/release_wheels.yml`
- Publish existing signed GitHub Release wheels: `.github/workflows/publish_pypi_from_release.yml`
- Release readiness summary: `scripts/release_status.py`
- Safe PyPI token secret setup: `scripts/configure_pypi_token_secret.py`
- Safe publish workflow runner: `scripts/run_pypi_publish_from_release.py`
- Safe manual PyPI publish helper: `scripts/publish_pypi_wheels.py`
- Full release runbook: [`docs/ops/release.md`](docs/ops/release.md)

```bash
# Replace these with the version/tag you are publishing.
VERSION=0.4.27
TAG="v${VERSION}"

# Snapshot release readiness without exposing any secret values.
python scripts/release_status.py \
  --version "$VERSION" \
  --release-tag "$TAG" \
  --expected-wheels 3

# If local clipboard access is unavailable, install the PyPI token as a hidden
# GitHub Actions environment secret. The helper validates token shape, never
# prints the token, and passes it to `gh secret set` through stdin.
python scripts/configure_pypi_token_secret.py --token-source prompt

# If the active shell/agent cannot accept an interactive hidden prompt, paste
# the token into this stdin handoff instead. The token stays out of stdout,
# shell history, and process arguments.
(
  old_stty=$(stty -g)
  trap 'stty "$old_stty"; unset PYPI_TOKEN' EXIT
  printf 'PyPI token for spiraltorch (hidden): '
  stty -echo
  IFS= read -r PYPI_TOKEN
  stty "$old_stty"
  printf '\n'
  printf '%s' "$PYPI_TOKEN" | python scripts/configure_pypi_token_secret.py --token-source stdin
)

# Safe GitHub Actions preflight: validates the signed release wheels and PyPI
# state, but never uploads. This is the default publish_method for the workflow.
python scripts/run_pypi_publish_from_release.py \
  --version "$VERSION" \
  --publish-method dry-run \
  --watch

# Real publish is intentionally explicit: provide PYPI_API_TOKEN as the `pypi`
# environment secret, or configure a matching PyPI Trusted Publisher first.
python scripts/run_pypi_publish_from_release.py \
  --version "$VERSION" \
  --publish-method token \
  --watch
```

---

## Python quickstart (wheel)

> The snippets below run against the published `spiraltorch` wheel and showcase the rich ecosystem of Python bindings that make SpiralTorch's Z-space runtime accessible and intuitive.
> Copy-paste scripts live in `bindings/st-py/examples/` (e.g. `sot_biome_quickstart.py`, `spiralk_plan_rewrite_quickstart.py`, `zspace_stream_training_quickstart.py`).

### 🌟 Quick Tour: Core Features

#### 0) Native module + checkpoint handoff

```python
import spiraltorch as st
from spiraltorch.nn import Linear

head = Linear(2, 2, name="head")
native_state = dict(head.state_dict())
external_state = {
    "lm_head.weight": native_state["head::weight"],
    "lm_head.bias": native_state["head::bias"],
}
key_map = {
    "lm_head.weight": "head::weight",
    "lm_head.bias": "head::bias",
}

report = head.state_dict_compatibility_with_key_map(external_state, key_map)
assert report["compatible"]
load_report = head.load_state_dict_subset_mapped_checked(external_state, key_map)
assert load_report["matched"]
print("matched checkpoint tensors:", report["matched"])

print("wgpu plan surface:", st.describe_device("wgpu").get("backend"))
```

#### 1) Tensor creation and basic operations

```python
import spiraltorch as st

# Create tensors from Python lists
x = st.tensor([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
y = st.Tensor(2, 3)  # Zero-initialized 2x3 tensor

# Label your dimensions for clarity
labeled = st.tensor(
    [[0.2, 0.8], [0.4, 0.6]],
    axes=[st.Axis("batch", 2), st.Axis("feature", 2)],
)

# Basic operations
z = x.scale(2.0)  # Multiply by scalar
print("Shape:", x.shape())
print("Data:", x.tolist())
print("Axis names:", labeled.axis_names())
```

#### 2) Zero-copy interop with PyTorch via DLPack

```python
import spiraltorch as st

# DLPack roundtrip (no extra deps)
st_tensor = st.Tensor(2, 3, [1, 2, 3, 4, 5, 6])
capsule = st_tensor.to_dlpack()
st_roundtrip = st.from_dlpack(capsule)
print("Roundtrip:", st_roundtrip.tolist())

try:
    import torch
    from torch.utils.dlpack import from_dlpack as torch_from_dlpack
except ImportError:
    print("PyTorch not installed; skipping torch interop demo.")
else:
    # SpiralTorch → PyTorch (zero-copy)
    torch_tensor = torch_from_dlpack(st_tensor.to_dlpack())

    # Mutations are visible in both (shared memory)
    torch_tensor += 10
    print("SpiralTorch sees changes:", st_tensor.tolist())

    # PyTorch → SpiralTorch
    pt_tensor = torch.arange(6, dtype=torch.float32).reshape(2, 3)
    st_from_torch = st.Tensor.from_dlpack(pt_tensor)
    pt_tensor.mul_(2)
    print("SpiralTorch sees torch mul_:", st_from_torch.tolist())
```

#### 3) Hypergrad tapes for Z-space optimization

```python
import spiraltorch as st

# Initialize weights and create hypergrad tape
weights = st.Tensor(1, 3, [0.1, 0.2, 0.3])
tape = st.hg[weights](
    curvature=-0.9,  # Hyperbolic curvature
    learning_rate=0.02,
)

# Add topological guards for stability
guarded = st.hg[weights].with_topos(
    tolerance=1e-3,
    saturation=0.8,
    max_depth=8
)

# Accumulate gradients
prediction = st.Tensor(1, 3, [0.25, 0.25, 0.25])
target = st.Tensor(1, 3, [0.0, 1.0, 0.0])
tape.accumulate_pair(prediction, target)

# Apply updates to weights
tape.apply(weights)

print("Tape shape:", tape.shape())
print("Learning rate:", tape.learning_rate())
print("Guard curvature:", guarded.curvature())
```

#### 4) Advanced hypergrad sessions with operator hints

```python
import spiraltorch as st

weights = st.Tensor(1, 4, [0.05, -0.15, 0.25, 0.10])
targets = st.Tensor(1, 4, [0.0, 1.0, 0.0, 0.0])

tape = st.Hypergrad(curvature=-0.85, learning_rate=0.03, rows=1, cols=4)
real = st.Realgrad(learning_rate=0.01, rows=1, cols=4)
try:
    tape.accumulate_pair(weights, targets)
    real.accumulate_pair(weights, targets)

    summary = tape.summary()
    telemetry = tape.telemetry()
    print("summary:", {"l2": summary.l2(), "rms": summary.rms(), "std": summary.std()})
    print("non-finite ratio:", telemetry.non_finite_ratio())

    # Desire-derived operator hints (mix/gain etc.)
    control = tape.desire_control(real.summary())
    print("operator mix/gain:", control.operator_mix(), control.operator_gain())
    print("control events:", control.events())
finally:
    tape.reset()
    real.reset()
```

#### 5) Z-space encoding and metric normalization

```python
import spiraltorch as st

z_vec = st.z["Spin up the roundtable", 0.4]

metrics = st.z.metrics(
    speed=0.55,
    memory=0.12,
    stability=0.78,
    drs=0.05,
    gradient=[0.1, -0.2, 0.05],
)

roundtable = st.z.partial(
    metrics,
    origin="telemetry",
    telemetry={"roundtable": {"mean": 0.44, "focus": 0.67}},
)
canvas_hint = st.z.partial(speed=0.35, memory=0.22, coherence_peak=0.61, weight=0.5)
bundle = st.z.bundle(roundtable, canvas_hint)

trainer = st.ZSpaceTrainer(z_dim=z_vec.shape()[1])
loss = trainer.step(bundle)

print("z shape:", z_vec.shape(), "loss:", loss)
```

`st.z[...]` is shorthand for `encode_zspace`, letting you blend text, temperature
overrides, or `(key, value)` tweaks inline. `st.z.metrics(...)` canonicalises the
wheel’s metric aliases, `st.z.partial(...)` captures telemetry/weights in a
`ZSpacePartialBundle`, and `st.z.bundle(...)` (alias `st.z.blend`) merges those
partials before handing them to `ZSpaceTrainer`.
Use `st.z.clear()` at run boundaries when process-global softlogic feedback must
not leak into the next experiment; it returns whether Rust actually removed a value.

Open-topos pressure can now be projected into named learning and inference
hints. The same signal can damp a local Z-space trainer and tune hosted-model
sampling controls:

```python
import spiraltorch as st

topos = st.hypergrad_topos(max_depth=10, max_volume=100)
signal = st.topos_control_signal(topos, observed_depth=4, visited_volume=25)
training = st.topos_training_hints(signal)
runtime = st.topos_runtime_adapter(signal, request_options={"base_temperature": 0.8})
projection = st.topos_zspace_projection(signal, gradient_dim=4)

trainer = st.ZSpaceTrainer(z_dim=4, topos_control_gain=0.5)
trainer.step(st.z.metrics(speed=0.0, memory=0.0, stability=0.0, telemetry={"topos": signal}))

print(
    training["gradient_bias_scale"],
    runtime["request"]["temperature"],
    projection["gradient"],
)
```

For hosted-model experiments, sweep several topological postures through the
same prompt/provider and compare the traces:

```python
import spiraltorch as st


def invoke_api_model(prompt: str, **request):
    route = "guarded" if "topos:sweep:guarded" in prompt else "open"
    return {
        "model": "demo-topos-model",
        "output_text": f"{route} route temperature={request['temperature']:.2f}",
        "status": "completed",
        "usage": {"prompt_tokens": 8, "completion_tokens": 6, "total_tokens": 14},
    }


result = st.run_api_llm_topos_sweep(
    ["Explain this route in one paragraph."],
    invoke_api_model,
    z_state=[0.2, -0.1, 0.4, 0.05],
    topos_profiles={
        "open": {"porosity": 0.7, "max_depth": 10, "max_volume": 100},
        "guarded": {"porosity": 0.02, "observed_depth": 9, "max_depth": 10},
    },
    request_options={"base_temperature": 0.8, "include_penalties": True},
    context_prompt=True,
    create_session=False,
    jsonl_dir="/tmp/spiraltorch-topos-sweep",
    report_out="/tmp/spiraltorch-topos-sweep/report.json",
)

print(result["labels"], result["comparison"]["topos_context"]["observed_run_rate"])
print(st.compare_api_llm_topos_sweep_reports(result["report_path"])["winners"])
```

### 6) Zero-copy tensor exchange via DLPack

```python
import spiraltorch as st

a = st.Tensor(2, 3, [1, 2, 3, 4, 5, 6])
capsule = st.to_dlpack(a)
roundtrip = st.from_dlpack(capsule)
print("roundtrip:", roundtrip.tolist())
```

The wheel exposes both `Tensor.to_dlpack()` and `Tensor.from_dlpack(...)` so you
can share contiguous 2D CPU `float32` storage directly with PyTorch or NumPy.
Versioned DLPack adds read-only metadata and explicit copy requests without
removing the legacy path. See the [Rust/Python interchange contract](docs/dlpack_interop.md)
for ownership, copy policy, and autograd boundaries.

### 7) Row softmax (GPU-accelerated when available)

```python
from spiraltorch import Axis, tensor

time = Axis("time")
feature = Axis("feature", 4)

wave = tensor(
    [
        [0.20, 0.80, -0.10, 0.40],
        [0.90, -0.30, 0.10, 0.50],
    ],
    axes=[time.with_size(2), feature],
)

print(wave.describe())
softmax = wave.row_softmax()
print(softmax.axis_names())  # ('time', 'feature')
```

`Axis`/`tensor` build `LabeledTensor` instances that remember semantic
dimensions. `row_softmax()` automatically dispatches to the best backend
available (WGPU/MPS/CPU) and keeps the axis metadata intact.

### 8) rl.stAgent multi-armed bandit

```python
import random
import spiraltorch as st

Agent = getattr(st.rl, "stAgent", None)
if Agent is None:
    raise SystemExit("st.rl.stAgent not available in this build")

def reward(action: int) -> float:
    p = 0.6 if action == 0 else 0.4
    return 1.0 if random.random() < p else 0.0

agent = Agent(state_dim=1, action_dim=2, discount=0.0, learning_rate=5e-2)

T = 2_000
FORCE_EXPLORE = 200
eps_hi, eps_lo = 0.3, 0.01

wins = 0
pulls = [0, 0]
wins_by_arm = [0, 0]

for t in range(1, T + 1):
    if t <= FORCE_EXPLORE:
        a = t % 2
    else:
        frac = (t - FORCE_EXPLORE) / (T - FORCE_EXPLORE)
        eps = eps_hi + (eps_lo - eps_hi) * frac
        agent.set_epsilon(eps)
        trace = agent.select_action_trace(0)
        a = trace["action"]

    r = reward(a)
    wins += r
    pulls[a] += 1
    wins_by_arm[a] += r
    agent.update(0, a, r, 0)

print(f"total win rate: {wins / T:.3f}")
for k in range(2):
    rate = (wins_by_arm[k] / pulls[k]) if pulls[k] else 0.0
    print(f"arm {k}: pulls={pulls[k]}, empirical p≈{rate:.3f}")
```

### 9) Self-supervised losses

```python
import spiraltorch as st

anchors = [[0.1, 0.9], [0.8, 0.2]]
positives = [[0.12, 0.88], [0.79, 0.21]]
print("info_nce:", st.selfsup.info_nce(anchors, positives, temperature=0.1, normalize=True))

pred = [[0.2, 0.8], [0.6, 0.4]]
tgt = [[0.0, 1.0], [1.0, 0.0]]
mask = [[1], [0]]  # mask by column indices per row
print("masked_mse:", st.selfsup.masked_mse(pred, tgt, mask))
```

### 10) Z-space trainer

```python
import spiraltorch as st

trainer = st.ZSpaceTrainer(z_dim=4, alpha=0.35, lam_frac=0.1, lr=1e-2)
samples = [
    {"speed": 0.2, "mem": 0.1, "stab": 0.7, "gradient": [0.05, -0.02, 0.01, 0.0]},
    {"speed": 0.3, "mem": 0.2, "stab": 0.6, "drs": 0.1},
]
print("z:", st.step_many(trainer, samples))
print("semantic owner:", trainer.last_optimizer_report["semantic_owner"])
```

`ZSpaceTrainer` is a Python orchestrator over the versioned
`st-core::runtime::zspace_optimizer` contract. Rust alone validates checkpoints,
normalises observations, evaluates the periodic fractional Sobolev regulariser
and its FFT-derived analytic gradient, resolves bounded Topos controls, and
commits the Adam update. Client-controlled Z dimensions are capped at 4096.
Use `last_optimizer_report` to inspect the objective decomposition, effective
learning rate, clipping, regularisation scale, applied gradient, and complete
before/after state. `gradient_projection="exact"` rejects mismatched observed
gradients; the compatibility default is `"tile_or_truncate"`.

The reported objective is an observed resource cost, not a claim that resource
telemetry was differentiated through Z. State updates combine the supplied
Z-gradient with the normalised analytic fractional gradient and optional Topos
bias. Topos `learning_rate_scale` changes the actual Adam learning rate, while
`regularization_scale` changes the actual fractional weight. `clip_scale` is not
another learning-rate multiplier: Rust derives a scale-invariant threshold from
the biased-gradient RMS, with `clip_scale=1` as an exact no-op.

Native parameter training consumes that same report without rebuilding its
semantics in Python:

```python
import spiraltorch as st

z_optimizer = st.ZSpaceTrainer(z_dim=2, topos_control_gain=1.0)
z_optimizer.step({
    "gradient": [0.1, -0.2],
    "telemetry": {"topos.training_hints.learning_rate_scale": 0.5},
})
model = st.nn.Sequential()
model.add(st.nn.Linear("controlled", 2, 1))
module_trainer = st.nn.ModuleTrainer(
    backend="cpu",
    curvature=-1.0,
    hyper_learning_rate=1e-2,
    fallback_learning_rate=1e-2,
)
module_trainer.prepare(model)
receipt = module_trainer.apply_zspace_meta_optimizer_report(
    model,
    z_optimizer.last_optimizer_report,
)
print(receipt["absolute_learning_rate_scale"], receipt["changed"])
```

Rust re-derives the bounded Topos scale, applies it idempotently to all trainer
learning rates, and rejects stale, conflicting, or modified reports before
mutating optimizer state. WASM exposes the same verified control receipt as a
peer-client transport, but does not pretend to own a browser parameter runtime.

### 11) Vision × Canvas

```python
import spiraltorch as st

vision = st.SpiralTorchVision(depth=4, height=3, width=3, alpha=0.2, window="hann", temporal=4)
canvas = st.CanvasTransformer(width=3, height=3, smoothing=0.85)

for t in range(3):
    vol = [[[0.0+(t*0.1) for _ in range(3)] for _ in range(3)] for _ in range(4)]
    vision.accumulate(vol)

# If you packaged an apply helper under st.canvas:
snap = st.canvas.apply_vision_update(vision, canvas, include_patch=True)
print("canvas summary:", snap.summary)
print("patch[0][:3]:", snap.patch[0][:3] if snap.patch else None)
```

### 12) NN data utilities

```python
import spiraltorch as st

pairs = [
    (st.Tensor(1,2,[1,0]), st.Tensor(1,2,[1,0])),
    (st.Tensor(1,2,[0,1]), st.Tensor(1,2,[0,1])),
]
dataset = st.dataset.Dataset.from_samples(pairs)
loader = dataset.loader().shuffle(123).batched(2).prefetch(2)
for x, y in loader:
    print("batch:", x.shape(), y.shape())
```

### 13) Recommender & RL

```python
import spiraltorch as st

rec = st.Recommender(users=8, items=12, factors=4, learning_rate=0.05, regularization=0.002)
rec.train_epoch([(0, 0, 5.0), (0, 1, 3.0), (1, 0, 4.0)])
print("top-k:", rec.recommend_top_k(0, k=3))
```

### 14) Interop (PyTorch / JAX / TensorFlow)

```python
import spiraltorch as st

x = st.Tensor(1,3,[1.0, 2.0, 3.0])
try:
    import torch
except ImportError:
    print("PyTorch not installed; skipping st.compat.torch demo.")
else:
    xt = st.compat.torch.to_torch(x, dtype=torch.float32, device="cpu")
    x_back = st.compat.torch.from_torch(xt)
    print(x_back.tolist())
```

### 15) Math & pacing helpers

```python
import spiraltorch as st
st.set_global_seed(42)
print(st.golden_ratio(), st.golden_angle())
print(st.fibonacci_pacing(12))
print(st.pack_tribonacci_chunks(20))
plan = st.sot.generate_plan(16, radial_growth=0.08)
print("sot:", plan.total_steps, plan.polyline()[:3])
```


## Backend Matrix

> Replace feature names if your `Cargo.toml` differs (`cpu`, `wgpu`, `cuda`, `hip` are typical).

| Backend | How to build (cargo) | Notes |
|---|---|---|
| **CPU** | `cargo build -p st-core --no-default-features --features cpu` | Portable, no GPU deps |
| **Metal (macOS)** | `export WGPU_BACKEND=metal` then `cargo build -p st-core --features wgpu` | Apple GPUs via WGPU |
| **CUDA (NVIDIA)** | `export CUDA_HOME=/usr/local/cuda` then `cargo build -p st-core --features cuda` | Ensure driver & toolkit |
| **HIP/ROCm (AMD, Linux)** | `cargo build -p st-core --features hip-real` | Real dense/rank kernels; requires ROCm. `hip` alone is planner/reference-only |

**Wheel builds** mirror these. The default Python wheel is WGPU-first; use
`--no-default-features --features python-default,<backend>` for backend-specific
builds without the default WGPU route.

---


### Tests

```bash
# Rust tests
cargo test --workspace

# Python smoke
python - <<'PY'
import spiraltorch as st
x = st.Tensor(1,2,[1,0]); cap = st.to_dlpack(x); assert st.from_dlpack(cap).tolist()==[[1.0,0.0]]
print("ok")
PY
```

---

## Troubleshooting & FAQ

**Q: `AttributeError: module 'rl' has no attribute 'DqnAgent'`**  
A: Use **`st.stAgent`**. The DQN surface was renamed for stability; façade provides the alias.

**Q: CUDA/ROCm link errors**  
A: Verify `CUDA_HOME`, driver/toolkit versions, or ROCm installation. On CI, add toolkit paths to `LD_LIBRARY_PATH`/`DYLD_LIBRARY_PATH`.

**Q: Wheel contains stale symbols after code changes**  
A: `pip uninstall -y spiraltorch && pip cache purge` → reinstall the freshly built wheel with `--no-cache-dir`.

**Q: How stable is the Python API?**  
A: The shipped type stubs (`spiraltorch/__init__.pyi`) reflect the **supported** surface. New Rust exports appear dynamically via forwarding; removals/renames adopt compatibility aliases where possible.

---

## Planning the Ecosystem

- Explore the [Ecosystem Roadmap](docs/ecosystem_roadmap.md) for high-level priorities around documentation, samples, and community building.
- Review the [Backend Feature Matrix](docs/backend_matrix.md) when validating device support or filing bugs that touch accelerators.
- **Interop focus.** SpiralTorch now ships a living [Compatibility Strategy](docs/compatibility_strategy.md) that maps out PyTorch, TensorFlow, and JAX migration paths—from trainer APIs to checkpoint conversion—so you can bring existing stacks along for the ride. The Python wheel exposes `spiraltorch.compat.torch|jax|tensorflow` helpers that exchange tensors with those runtimes through zero-copy DLPack capsules, plus ergonomic knobs for dtype/device targeting, gradient flags, and memory format tweaks.

## Julia & Go integration 

- Prototype workflows for future Julia/Go bindings live in [docs/ops/julia_go_development.md](docs/ops/julia_go_development.md). Follow the guide for setup, lint/test commands, and release checklists.

Prefer flat-space optimisation? Reach for the new Rust-side
`st_tensor::AmegaRealgrad` tape to mirror the same API without the Poincaré
projection step—handy when Canvas Transformer energy needs to feed classical
optimisers alongside its hypergradient updates.


### Explore the runtime interactively

Prefer a guided walkthrough of the dispatcher flows? Open the
[interactive runtime explorer](docs/interactive/README.md) for clickable
diagrams, a narrated "story tour" of the runtime handoff, and playful
spotlights on graph-node materialisation versus return-handle delivery:

- 🎬 **Story tour.** Step through a six-beat mini adventure that explains
  how a single API call ripples through SpiralTorch, from the first FFI
  marshals to the triumphant return of tensor handles.
- 🔍 **Focus toggles.** Snap to either the graph-node materialisation
  path or the return-handle arc whenever you want to revisit a specific
  phase.
- 🌈 **Aurora mode.** Bathe the canvas in a psychedelic gradient to feel the
  runtime choreography pop—the toggle sits beside the spotlight buttons.
- ✨ **Phase constellations.** Sidebar cards cluster subsystems by stage so you
  can intuit which teams light up together as the story advances.
- 🧭 **Free roam.** Click any node or edge to read quick lore about the
  component, then resume the story exactly where you left off.

> **Update — GPU-first convolution.** `Conv2d` now routes through a WGPU im2col + GEMM path that expands the 5D activation volume entirely on the GPU before projection back into Z-space, accelerating large vision stacks on portable GPUs.
>
> **New — Conv6da with Leech enrichment.** `Conv6da` fuses six-directional adjacency with optional Leech lattice density boosts so Z-space fields aggregate neighbors with structure-aware gradients.

> **New — DLPack/compat inference bridges.** Import weights over `st.from_dlpack` or the `spiraltorch.compat` adapters and feed them straight into Z-space inference via `st.weights_partial_from_dlpack`, `st.weights_partial_from_compat`, or the higher-level `st.infer_weights_from_dlpack`. PSI telemetry is now summarised live during these projections so models can modulate confidence against streaming telemetry frames.

> **Expanded — Higher-order convolutions.** Fresh `Conv3d` and `Conv4d` modules now mirror the dilation-aware ergonomics of their 1D/2D siblings so volumetric stacks and temporal cubes slide straight into the same API.
>
> **New — Online-softmax fused attention.** A single-kernel QKᵀ + mask + softmax + V pipeline now lands in the WGPU backend, slashing bandwidth for multi-head attention while matching PyTorch semantics for drop-in migrations.

> **In flight — CUDA attention kernel.** The fused scaled dot-product path now supports causal masking, per-context sequence lengths, optional Z-bias/attention bias, and an opt-in attention-probability readback so Z-space transformers can mix ragged batches without leaving the GPU hot path.

> **In progress — Fused attention for PyTorch migrations.** The new single-kernel Q·Kᵀ + softmax + V planner keeps intermediate logits on-chip, so PyTorch users can co-train or stage migrations while retaining numerically stable attention/softmax semantics.

> **In progress — Fused attention for Torch migrations.** The new single-kernel Q·Kᵀ + softmax + V planner keeps intermediate logits on-chip, so PyTorch users can co-train or stage migrations while retaining numerically stable attention/softmax semantics.
>
> **New — Python `Tensor.scaled_dot_attention`.** The fused kernel is now exposed to Python callers with a CPU fallback, so migration experiments can drop directly into WGPU-backed attention without leaving the high-level API.

> **In flight — CUDA attention kernel.** The fused scaled dot-product path now supports causal masking, per-context sequence lengths, optional Z-bias/attention bias, and opt-in attention probability/logit readback so Z-space transformers can mix ragged batches without leaving the GPU hot path.

> **New — Z-space inference for imported checkpoints.** `spiraltorch.infer_weights_from_dlpack` and `spiraltorch.infer_with_psi` now project DLPack/compat weights, Canvas transformers, and PSI telemetry straight into the Z-space posterior. Warm-start inference can blend partial observations with live ψ health data so Rust sessions reuse PyTorch/JAX weights without leaving the SpiralTorch runtime.

> **New — PSI synchroniser learning bundles.** Multi-branch MetaMEMB runs now deliver combined heatmaps, ZPulse snapshots, Atlas fragments, PSI component breakdowns, and Golden directives via `st.psi.run_zspace_learning(...)` so Z-space learners and distributed `golden` retrievers can coordinate straight from Rust or Python.

---

## Technical notes

- [Coded-Envelope Maxwell Model (M₀^code)](docs/coded_envelope_maxwell_model.md) — Technical memo on the sequential detection framework that couples physical fingerprints with semantic gating.
- [Conceptual Entropy and Qualia](docs/conceptual_entropy_qualia.md) — SpiralTorch-oriented translation of the qualia report tracing how the term drifts across philosophy, neuroscience, and public discourse.
- [Drift-Response Linguistics for Z-space Language Training](docs/drift_response_linguistics.md) — Full write-up of the existential load / safe radius theory, signature geometry with timing elasticities, tipping radii, and direction-aware safe radii, plus how SpiralTorch wires DRL penalties into trainers and governance loops.
- [General Relativity Couplings inside Z-space](docs/general_relativity_zspace.md) — How Lorentzian curvature feeds Einstein tensors into ZPulse telemetry so gravitational signals steer the cooperative runtime.
- [Invariant barrier gating and contraction notes](docs/invariant_barrier_design.md) — Design cheatsheet covering safety barriers, steady amplitudes, and contraction-rate lower bounds for Spiral dynamics controllers.
- [COBOL web dispatch quickstart](docs/cobol_web_dispatch.md) — structure of the WASM planner and how to shuttle envelopes into MQ or CICS entrypoints.
- [SpinoTensorVector derivation notes](docs/stv_z_space.md), Start architecting Z-space kernels with the new  covering determinant identities, kernel causality, and minimal-norm constructions ready for implementation.

---

## 🛠️ Why Robotics Teams Are Watching

SpiralTorch’s runtime mirrors the main pressure points that robotics teams wrestle with today:

1. **Vendor-agnostic acceleration (WGPU-first).** Robots ship on Jetsons, Raspberry Pis, Apple Silicon laptops, AMD workstations, and plain x86 servers. SpiralTorch kernels are written against WGPU, so the same Z-space operators run across Metal, Vulkan, or DirectX 12 without CUDA lock-in.
2. **A control-plane grade runtime.** The mermaid diagram above is effectively a realtime robotics OS: session managers, graph planners, schedulers, command queues, and observability hooks coordinate sensing, planning, and actuation in one pipeline.
3. **Unified sensor fusion via Z-space.** Camera frames, LiDAR point clouds, IMU states, force/torque readings, and language instructions all project into a single geometric manifold. Planning loops consume multi-modal context without writing one-off fusion code per robot, while per-channel exponential smoothers and staleness monitors keep jittery or missing proprioception from destabilising downstream control.
4. **Geometric + gravitational dynamics.** Z-space now carries configurable geometry (Euclidean, curved manifolds, or GR-inspired metrics) and gravity wells (Newtonian or relativistic) so training can explore non-Euclidean kinematics, orbital behaviours, or heavy-mass safety regimes without leaving the runtime. The new Relativity Bridge mirrors the general relativity tensors used in the theory module—including Lorentzian metrics generated from symmetry ansätze—so the same conceptual primitives power both physics experiments and real robot rollouts.
5. **Instinctive behaviours with Desire Lagrangians + SpiralTorchRL.** Instead of hand-crafting reward functions, core instincts—“don’t tip over,” “seek charge,” “avoid the ledge”—are encoded as potentials. Traditional policy-gradient loops still plug in, but they optimise around explainable priors.
6. **Self-aware safety through ψ telemetry.** The runtime continuously measures kernel stability, allocator pressure, dynamics drift, and channel health. When thresholds break—whether from physical saturation or stale sensors—ψ telemetry drives self-maintain routines that pause execution or transition to safe postures before a robot ever enters an unrecoverable state.
7. **Training-grade data capture.** A built-in trajectory recorder snapshots fused observations, instinct evaluations, telemetry, and policy commands so teams can stream curated rollouts into offline RL pipelines or regression harnesses without bolting on a separate logging stack.
8. **Pluggable safety governance.** Robotics runtimes can now host drift-response safety plugins sourced from the `spiral-safety` crate. ψ telemetry, Desire energy, and channel health feed directly into SpiralTorch’s governance metrics so the same policy guardrails auditing language models can halt physical robots when hazards spike.
9. **Z-space trainers with temporal feedback.** The new `TemporalFeedbackLearner` and `ZSpaceTrainerBridge` convert runtime steps, ψ telemetry, and Desire energy into Z-space trainer metrics (speed, memory, stability, drift) and `ZSpacePartialBundle` payloads. Vision and instinctive signals stay synchronised so offline trainers can replay the exact feedback a robot experienced on the floor.
10. **CanvasProjector-aligned vision control.** `VisionFeedbackSynchronizer` aligns CanvasProjector vector fields with sensor channels, exposes alignment/energy metrics, and feeds them into the same partial bundles. Reinforcement loops now mix proprioceptive policies with live visual feedback for gradients that understand what the robot “saw” when it acted.
11. **Episode-scale dataset tooling.** `ZSpaceTrainerEpisodeBuilder` groups trainer samples into bounded episodes, reports aggregate stability/memory/drift scores, and hands Python bindings a ready-to-train bundle. Teams can checkpoint on-policy rollouts, feed them into offline RL, or compare episode health across deployments without rebuilding analysis plumbing.

Together these properties let SpiralTorch act as the perception, planning, and autonomy stack for heterogeneous robot fleets—from lab manipulators to outdoor rovers—without a rewrite per platform.


## Emerging toolkits unique to SpiralTorch

### Canvas Pixel Transformer → Z-space feedback

- `CanvasProjector::refresh_with_vectors` now returns both the RGBA buffer and
  a colour vector field that carries normalised energy and chroma as
  Z-space-friendly coordinates.
- `FractalCanvas::vectorFieldFft(false)` surfaces the per-row FFT spectrum as
  interleaved energy/chroma pairs so Canvas Transformer pipelines can ingest
  frequency features without leaving Rust.
- `FractalCanvas::emitWasmTrail(curvature)` packages the live vector field into
  `(x, y, z, energy, r, g, b)` samples so WebGPU/WebXR experiences can stream
  Z-space particle trails without reconstructing curvature or FFT passes in
  JavaScript.
- `FractalCanvas::emitWasmTrail(curvature)` packages the live vector field into
  `(x, y, z, energy, r, g, b)` samples so WebGPU/WebXR experiences can stream
  Z-space particle trails without reconstructing curvature or FFT passes in
  JavaScript.
- `CanvasProjector::accumulate_hypergrad` and
  `CanvasProjector::accumulate_realgrad` stream the refreshed canvas tensor
  directly into SpiralTorch's Riemannian or Euclidean optimisers without
  additional copies.
- `FractalCanvas::relation()` mirrors the projector's tensor output as a
  `Float32Array` so browser call-sites can feed the raw relation into custom
  pipelines or training loops.
- `FractalCanvas::hypergradWave(curvature)` and `FractalCanvas::realgradWave()`
  surface curvature-aware hypergrad updates alongside Euclidean gradients so the
  Canvas Transformer can keep hypergrad/Realgrad buffers in sync by default.
- `FractalCanvas::gradientSummary(curvature)` condenses both tapes into shared
  L1/L2/∞ norms plus RMS/mean-absolute magnitudes so monitoring dashboards can
  watch gradient health without shipping the full relation buffers across the
  WASM boundary.
- `FractalCanvas::desireInterpretation(curvature)` lifts the paired gradient
  summaries into Desire-ready feedback metrics (pressure, balance, stability)
  so automation layers can steer the Desire Lagrangian without leaving WASM.
- `FractalCanvas::desireControl(curvature)` extends that pipeline with
  ready-to-apply Desire gradient control packets—penalty gains, bias/observation
  mixers, and tuned hyper/Realgrad learning-rate scales—mirroring the Rust
  automation layer on the browser side.
- `FractalCanvas::hypergradOperatorUniformFromControl(control)` and
  `FractalCanvas::hypergradOperatorUniformAuto(curvature)` map those Desire
  control packets directly into the WGSL uniform payload, saving JavaScript
  callers from recomputing the blend/gain heuristics before dispatching the
  GPU hypergrad operator.
- `FractalCanvas::vectorFieldFftKernel(true)` returns the ready-to-dispatch
  WGSL compute shader (including uniform layout) so WebGPU call-sites can bind
  the vector field and accumulate the spectrum fully on-GPU.
- `FractalCanvas::hypergradOperatorKernel(false)` emits the complementary WGSL
  pass that accumulates relation tensors into hypergradient buffers directly on
  the GPU, with `hypergradOperatorUniform(mix, gain)` +
  `hypergradOperatorDispatch(subgroup)` mirroring the uniform payload and
  workgroup math for WebGPU callers.
- `FractalCanvas::vectorFieldFftUniform(false)` packages the `CanvasFftParams`
  uniform (width, height, inverse flag, padding) as a `Uint32Array` so the WGSL
  kernel can be dispatched without manual byte packing.
- `FractalCanvas::vectorFieldFftLayout()` reports the byte lengths and strides
  for the `FieldSample`/`SpectrumSample` storage buffers plus the uniform block
  so WebGPU callers can allocate resources without hard-coding struct sizes.
- `FractalCanvas::vectorFieldFftDispatch(true)` computes the workgroup triplet
  for the generated WGSL so callers can hand the counts directly to
  `computePass.dispatchWorkgroups(...)` (or the Rust equivalent) without
  duplicating the ceil division logic.
- Use `CanvasProjector::emit_zspace_patch` to fold the canvas state back into
  the fractal scheduler without leaving Rust or allocating intermediate
  buffers.
- Blend chart priors with the new `z_space_barycenter` solver—available in
  Rust (`st_tensor::z_space_barycenter`) and Python (`spiraltorch.z_space_barycenter`)—to
  wire colour energy directly into the Z-space roundtable.
- Follow the barycenter's loss-monotone intermediates and feed them straight into
  the hypergradient tape with `Hypergrad.accumulate_barycenter_path` so the
  optimiser converges along the same Z-space path as the solver.

### Z-space inference autopilot (DLPack + ψ telemetry)

- `spiraltorch.weights_partial_from_dlpack` distils PyTorch/JAX/TF tensors
  captured via DLPack or `spiraltorch.compat.capture` into weighted partials,
  ready for `spiraltorch.infer_with_partials` and `spiraltorch.infer_weights_from_dlpack`.
- `spiraltorch.infer_with_psi` consults `spiraltorch.fetch_latest_psi_telemetry`
  on demand so inference blends metric overrides, Canvas partials, and live ψ
  telemetry without writing glue code.
- `spiraltorch.psi_partial_from_reading` and
  `spiraltorch.psi_partial_from_advisory` expose PSI breakdowns, Hopf regime
  flags, and tuning plans as canonical metrics that pipe directly into
  `ZSpaceInferencePipeline` or `ZSpaceInferenceRuntime`.
- `ZSpaceInferencePipeline(psi=True)` now reuses cached PSI telemetry when
  blending Canvas snapshots, coherence diagnostics, and imported checkpoints—
  ideal for warm-starting a Rust session with PyTorch weights while watching
  the ψ health score in real time.
- Drive the entire workflow from the high-level `SpiralSession` orchestrator in
  Rust (`st_nn::SpiralSession`) or Python (`spiraltorch.SpiralSession`) to pick
  devices, generate rank plans, synthesise barycentres, and align hypergrads via
  intuitive method calls.
- Launch `session.trace(tensor)` to compose non-commutative homotopy flows,
  functor linearisations, recursive barycenter gradients, and \(\infty\)-tower
  projections before calling `.resonate()` (or
  `.resonate_with_hypergrad(hypergrad)`) to surface a
  `DifferentialResonance` snapshot that binds the four differential layers
  together.
- Let the trace synthesise barycentres on demand via
  `trace.with_barycenter_from(weights, densities)` or override the coupling
  matrix with `trace.with_barycenter_with(weights, densities, Some(coupling))`
  before resonating, keeping Z-space orchestration entirely on the session.

### SpiralTorchVision

SpiralTorchVision reinterprets the Z-axis as a perceptual frequency domain,
collapsing it with spectral-window-aware projectors into tensor spaces that any
TorchVision model can consume. Temporal resonance buffers now let `ZSpaceVolume`
perform exponential moving averages across frames, while `MultiViewFusion`
registers camera descriptors so the projector can weight view-specific Z slices
before collapse. The roadmap now leans into generative feedback loops between
SpiralRNN conductors and vision modules. Read the full guide in
[docs/spiraltorchvision.md](docs/spiraltorchvision.md).).

### Z-space-native graph neural networks

SpiralTorch’s hyperbolic geometry grew around hierarchical graphs. The Rust
kernel, backend abstraction, and Z-space operator families already expose the
building blocks for graph neural networks that keep distortion in check while
scaling to social, molecular, or citation graphs. By composing the existing
SpiralK planners, Z-space resonators, and curvature-aware tensors, new
`st-gnn` layers can stream hypergrad updates through tree-like manifolds as a
first-class citizen in the framework—becoming a third pillar alongside
SpiralTorchRec and SpiralTorchRL. The new `st-nn::gnn` module ships a
`GraphContext` normaliser plus a `ZSpaceGraphConvolution` layer that attaches
hypergrad tapes by default and surfaces per-node flow traces via the telemetry
`GraphFlowTracer`, so graph reasoning can be trained and inspected without
leaving Z-space. The `GraphContextBuilder` allows you to dial in symmetric or
row-stochastic normalisation (and self-loop weighting) per graph before it ever
touches the tape, while the tracer now aggregates energy so higher-level tools
can see how much of the negotiation passed through each layer at a glance.
Those traces plug straight into SpiralTorch’s other pillars: `embed_into_biome`
folds propagated node states into an `OpenCartesianTopos`/`TensorBiome` pair for
RewriteMonad consumers, the flow grid can be painted onto any canvas projector,
and `fold_into_roundtable` promotes the graph manifold as a fourth participant
beside the A/B/C bands. The new `fold_with_band_energy` helper lets you blend a
fresh telemetry report with an existing roundtable split without recomputing the
schedule, keeping graph energy in lock-step with whatever SpiralK already
decided for the batch. Feed those reports into `GraphConsensusBridge` to
generate SpiralK snippets and Above/Here/Beneath multipliers—then hand the
bridge to `ModuleTrainer::enable_graph_feedback` so every optimisation step
absorbs graph telemetry before the SoftLogic weighting fires. The trainer keeps
the SpiralK hint from the last applied digest available via
`ModuleTrainer::graph_hint()`, making it trivial to stream the graph-aware
policy back into SpiralK orchestrators or external dashboards.

### Explainability through hypergrad telemetry

Every hypergrad tape, roundtable consensus log, and ψ telemetry stream doubles
as a geometric audit trail. SpiralTorch can expose these records directly to an
interpretability toolkit that maps gradient flows, consensus splits, and
telemetry spikes back to model behaviour. Visualising these pathways keeps
“why” answers native to Z-space, turning SpiralTorch’s internal instrumentation
into an Explainable AI surface without external probes.

### Multi-modal topos safety envelopes

Open topos guards now ship a unified, multi-modal façade so the same
hyperbolic safety window can simultaneously protect text, audio, vision, graph
and reinforcement-learning reward streams. The new
`st_tensor::MultiModalToposGuard` wraps an existing `OpenCartesianTopos` and
lets you tune per-modality envelopes through lightweight profiles:

```rust
use st_tensor::{
    GraphGuardProfile, ModalityProfile, MultiModalToposGuard, OpenCartesianTopos, RewardBoundary,
};

let topos = OpenCartesianTopos::new(-0.95, 1e-6, 8.0, 256, 16_384)?;
let guard = MultiModalToposGuard::new(&topos)?
    .with_text_profile(
        ModalityProfile::new(32_768, Some(0.35))?.with_permeability(0.25)?,
    )?
    .with_audio_profile(
        ModalityProfile::new(96_000, Some(1.25))?.with_permeability(0.12)?,
    )?
    .with_graph_profile(
        GraphGuardProfile::new(512, 8_192, 64, 1e-3, 0.02, None)?.with_permeability(0.15)?,
    )?
    .with_reward_boundary(RewardBoundary::new(-0.8, 0.8, 0.05)?)?;

let mut rewards = vec![1.2, 0.6, -1.1];
let signal = guard.guard_reward_trace(&mut rewards)?;
if let Some(breach) = signal.upper_breach_index {
    tracing::warn!(breach, "reward trace escaped the safe window");
}
```

Each `ModalityProfile` enforces volume limits and softly saturates values using
a tunable **permeability** so monadic biomes retain breathing room instead of
being hard-clipped at the boundary. `GraphGuardProfile` applies the same
permeable clamp to adjacency weights and tolerates a budget overshoot within
the configured permeability, reporting the overflow through
`GraphGuardReport::edge_overflow`. `RewardBoundary` surfaces the first reward
breach while clamping the trace back inside the permitted envelope. The guard
reports symmetry violations, observed reward ranges, saturation counts, and
edge overflow so downstream monitors can react without recomputing the checks in
higher-level languages.

The guard can now seed both an atlas and a biome that retain the same
permeability envelopes, making it easy to wire multi-modal checkpoints into
longer traversals:

```rust
let mut atlas = guard.atlas();
let mut biome = guard.cultivate_biome();

let mut text = Tensor::from_vec(1, 8, vec![2.5; 8])?;
atlas.guard_text_tensor("atlas_text", &mut text)?;

let vision = Tensor::from_vec(3, 3, vec![1.3; 9])?;
biome.absorb_vision("biome_vision", vision)?;
let canopy = biome.canopy()?;
tracing::info!(volume = atlas.visited_volume(), shoots = biome.len());
```

`MultiModalAtlas` shares `ToposAtlas` telemetry like `visited_volume` and
`remaining_volume` while applying modality-aware rewrites before the atlas guard
fires, so downstream geometry keeps a consistent notion of traversal depth.
`MultiModalBiome` keeps the same permeability when absorbing shoots, meaning any
monadic collapse through `canopy()` stays in lock-step with the atlas and guard
without re-deriving modality constraints.

### Autotune telemetry for the WGPU-first roadmap

SpiralTorch now ships an autotuning registry and bounded telemetry log so the
WGPU backend can remember which tile schedules performed best on each device.
We encode the hardware fingerprint using vendor, numeric device ID, subgroup
size, shared-memory budget, and driver revision, then splice in the shader
revision plus op signature to form a stable cache key—no timestamps or host
process details required. The same log
tracks throughput, bandwidth, occupancy, chosen tile, and regression fallbacks
while evicting the oldest samples once the per-key capacity is reached, keeping
the cache warm without unbounded growth.

### Microlocal interface gauges

SpiralTorch’s theory core now hosts a microlocal boundary gauge that translates
the BV/varifold correspondence directly into code. The new
`st_core::theory::microlocal::InterfaceGauge` measures local total-variation
density over shrinking metric balls, outputs the gauge-invariant `R` machine,
and only reconstructs oriented normals when an external label `c′` is supplied.
This lets SpiralTorch stabilise interface detection, switch on co-orientations
precisely when downstream pipelines inject a label, and keep curvature-ready
statistics without violating the gauge symmetry of the unlabeled limit.
Once those signatures exist, `InterfaceZLift` pushes them straight into
Z-space: it projects the perimeter mass onto a preferred Z-axis, splits the
energy into Above/Here/Beneath bands, enriches the drift with the Leech
projector, and emits a ready-to-store `SoftlogicZFeedback` pulse so runtimes can
bias their collapse heuristics without leaving the microlocal picture.

Beyond the perimeter statistics the gauge now reports a gauge-invariant
mean-curvature magnitude and, whenever `c′` fixes an orientation, the signed
mean curvature that restores the co-oriented BV picture. Collapse loops can
therefore gate on curvature without labels, and only light up the signed
variant once a label or co-orientation becomes available.

To make those bridges operational inside collapse loops the gauge now supports
multi-radius sweeps and a conductor that fuses their Z pulses with exponential
smoothing. `InterfaceGauge::analyze_multiradius` probes the same mask at
different blow-up scales (and reuses an optional `c′` label when supplied),
while `InterfaceZConductor` drives any number of gauges, aggregates the
resulting pulses, and hands back a `ZFused` packet with attribution weights and
event tags alongside the smoothed `SoftlogicZFeedback` record so runtime loops
can see which layer dominated the decision.
`MicrolocalGaugeBank` turns that loose collection into a pluggable registry.
It stores named `InterfaceGauge`s, offers builder-style helpers to register or
remove probes, runs batch analysis keyed by id, and hands the resulting lineup
directly to the conductor so runtime code can swap probe sets without rewriting
fusion logic.
`InterfaceZConductor::step` now preserves those identifiers, returning an
`InterfaceZReport` that bundles the raw `InterfaceSignature`s alongside the
matching ids and a cloned lift so downstream consumers can reuse the same
projection without re-running the gauges.
`MacroTemplateBank` mirrors that registry pattern for macro-scale designs: it
keeps named `MacroModelTemplate`s, accepts cards directly, and couples the whole
lineup to an `InterfaceZLift` to emit a bridge bank so macro kinetics can travel
with whatever microlocal gauges are currently wired into the conductor.
It can then call `drive_matched` to produce macro drives only for the gauges
present in the latest report and merge their microlocal feedback via
`feedback_from_report` before piping the result back into the conductor.

The conductor can now blend the pulses in both time and frequency: `set_frequency_config`
installs a power-of-two FFT window and per-source spectral gains so high-frequency
microlocal gradients or low-frequency desire trends can be emphasised without a
second pass, while `set_adaptive_gain_config` keeps a per-source reliability
score and nudges their gains on-line until the fused drift stabilises. A new
`set_latency_config` alpha–beta aligner adjusts timestamps using the reported
latency and emits `latency-*` events whenever the offsets are learnt or
corrected, keeping Maxwell’s block pulses in lockstep with microlocal frames.
Tests cover the spectral weighting, the adaptive loop, and the latency alignment
so the new knobs keep their invariants.

Desire loops pick up the fused Z feedback straight from the hub: the conductor
stores the latest `SoftlogicZFeedback`, and the temperature controller now
accepts that pulse to raise exploration when the drift jitters and cool the
distribution when the Z-bias settles. The default controller keeps a short
memory of recent flips and exposes `with_feedback` so runtimes can tweak the
feedback gain without rebuilding the desire machinery.

### Collaborative canvas telemetry and ghost trails

The hardened collaboration stack now layers spectator-grade UX on top of the
BroadcastChannel/localStorage bridge. Every pointer broadcast feeds a
policy-aware ghost trail buffer (`pointerTrail` events plus the
`getPointerTrail` helper) so dashboards can draw fading cursors without keeping
their own queues.
At the same time a bounded timeline recorder captures every pointer, patch, and
full-state message with Lamport clocks and origins so HUDs can play back the
last few seconds of collaboration or splice the data into attribution feeds via
`session.replay`.
The WASM README now documents the new knobs (`pointerTrailMs`,
`replayWindowMs`, `replayMaxEntries`) and ships usage snippets for replaying
frames or painting ghost trails, making it trivial to showcase collaborative
Z-space canvases right from the top-level docs.

### Maxwell-coded envelopes meet SpiralK

The coded-envelope utilities now ship with a `MaxwellSpiralKBridge` that turns
sequential Z pulses into KDSl snippets ready for the runtime. Every channel name
is sanitised for SpiralK, weights adapt to the observed Z magnitude, and
existing programs can be prepended so the hints extend a live policy rather than
replace it. Call
`push_pulse(channel, &pulse)` for each stream, then `script()` to emit the
combined `soft(maxwell.bias, …)` rules that SpiralK can ingest without custom
glue code. The workflow is
documented in the refreshed Maxwell technical note, which now includes a
section on streaming detections back into SpiralK orchestration.

Want the language desire loops to see the same detections? Enable the PSI
feature and run the new `MaxwellPsiTelemetryBridge`. It converts each pulse into
a PSI reading, optional band-energy threshold events, and a `SoftlogicZFeedback`
sample so `DesirePsiBridge` captures the Z drift alongside ψ totals without
hand-written glue.
Pair it with `MaxwellDesireBridge` to translate the very same pulse into a
concept window that the `DesireLagrangian` can consume, aligning coded-envelope
channels with vocabulary slots on the fly.

### Quantum Reality Studio overlays

The new `st-qr-studio` crate spins up a **QuantumRealityStudio** that records
Maxwell pulses, emits concept windows, and stitches narrative tags into VR/AR
overlays. Signal capture sessions enforce which laboratory rigs may publish
pulses, semantic taggers mirror the `MaxwellDesireBridge` lexicon, and overlay
frames surface glyph/intensity pairs for immersive projection. The crate now
re-exports `MaxwellPulse` (an alias for `MaxwellZPulse`) and ships overlay
builders such as `OverlayFrame::from_pairs`/`::from_glyphs_and_intensities` so
AR pipelines can zip glyph and intensity streams without writing manual
plumbing. Storyboard exports drop directly into
`tools/qr_storyboard.py`, which converts JSON/NDJSON captures into Markdown decks
grouped by channel for Desire roundtables while weaving overlay glyph stacks,
meta-narrative tags, causal ancestry, concept windows, and meaning-sheaf
signatures into a highlights column for reviewers. The companion
[Quantum Reality Playbook](docs/qr_playbook/README.md) provides rituals,
collaboration tips, and art-direction cues so research and cultural teams stay
synchronised.

Latest iterations expose `QuantumRealityStudio::record_pulse` so capture rigs can
stash `RecordedPulse` snapshots prior to narration, while
`infer_concept_window` and `emit_concept_window` transform either raw records or
streamed frames into serialisable concept windows suited for AR overlays and
Desire loops. `OverlayGlyph` powers `OverlayFrame::new`, while the new
convenience constructors accept glyph/intensity pairs directly and the
storyboard exporter now retains overlay stacks, narrative tags, and concept
window weights so AR HUDs can replay exactly what collaborators saw without
deriving those assets a second time.

### Semiotic suturing, desire control, and EGW bridges

SpiralTorch now ships a native semiotic optimiser that compresses Lacanian
language machinery into Z-space numerics. The `st-nn::language::DesireLagrangian`
implements the closed-form update

\[
\pi_t^*(j) \propto q_\theta(j\mid h_t)^{1/T_t}\exp\{\alpha_t\log K_{\text{syn}} + \beta_t\log K_{\text{par}} - \lambda r_j + \gamma_t g_t(j)\},
\]

so syntagmatic/ paradigmatic couplings, repression scores, and S→s drives land
as a single additive logit injection.
The `TemperatureController` keeps desire aligned with a target entropy, while
the lightweight Schrödinger lookahead adds one-to-two Doob iterations directly
from the Z-space kernels to approximate the bridge in-line with training.

Symbol/meaning suturing arrives via an entropic Gromov–Wasserstein solver that
enforces anchors and floaty signifiers together. `EntropicGwSolver` estimates
the coupling \(\Pi\) by minimising the EGW objective with Sinkhorn-style
updates, boosting anchor pairs, and handing back a `SemanticBridge` ready for
token-to-concept expectations across the tape.
Feed that bridge into the desire Lagrangian and you obtain a turn-key workflow:

1. Build sparse syntagmatic/ paradigmatic kernels and repression vectors, then
   estimate \(\Pi\) with the EGW solver (optionally seeding anchor pairs).
2. Initialise the `DesireLagrangian` with those artefacts and wire it to a
   SpiralK loop or roundtable injector.
3. Stream LM logits through `step(...)` or the phase-aware `step_with_scheduler(...)`
   to receive logit offsets, entropy telemetry, and temperature updates that
   honour the S/s suturing and desire budget.

Configure desire as a three-stage routine by combining the provided schedule
helpers. `warmup(...)` handles the observation phase (desire starts at zero and
logs avoidance), ramping towards the interference window where `alpha` nudges
avoided terms while `beta/γ` remain gentle. Once the warmups complete the
integration phase kicks in, coupling desire with the Z-space barycenter and
surfacing a hypergrad penalty that measures drift from the barycentric anchor.
For example:

```rust
let mut desire = DesireLagrangian::new(geometry, repression, semantics, controller)?
    .with_alpha_schedule(warmup(0.0, 0.1, 400))
    .with_beta_schedule(warmup(0.0, 0.05, 800))
    .with_gamma_schedule(constant(0.02))
    .with_lambda_schedule(constant(0.08));

let report = desire.step_with_scheduler(&logits, previous_token, &concept_hint)?;
match report.phase {
    DesirePhase::Observation => log_observation(report.avoidance),
    DesirePhase::Injection => reinforce_desire(report.logit_offsets),
    DesirePhase::Integration => hypergrad.push_penalty(report.hypergrad_penalty),
}
```

`DesireAvoidanceReport` exposes the dominant repressed tokens collected during
observation, while the integration phase emits the barycentric drift so a
hypergrad or self-rewrite scheduler can keep desire centred without collapse.
The schedules default to zeroed observation and grow-only ramps, so existing
callers can continue to provide manual `DesireWeights` without opt-in changes.

Every step now ships a `DesireGradientControl` alongside the interpretation so
automation layers can react without recomputing heuristics. Grab it via
`DesireLagrangian::gradient_control()` (or directly from the streamed
`DesireSolution`) to inspect the recommended hyper/Realgrad learning-rate
scales, penalty gains, and WGSL operator mix/gain before issuing GPU updates.
The control packet also captures Desire's “feel-good” tuning: exponential
learning-rate gains driven by entropy deltas (with min/max bounds and slew
limits), EMA-smoothed clipping windows anchored at the 95th percentile, Z-space
temperature coupling (`κ`) guidance, and sigmoid quality scaling hooks so
Maxwell/Microlocal evidence can raise the step size only when the gradients look
clean. Each packet carries a telemetry bitmask plus string labels (e.g.
`lr_increase`, `lr_clipped`, `temperature_suppress`, `quality_suppress`,
`lr_slew_limit`) so PSI dashboards can log _why_ the controller nudged Desire in
a given direction, and the new `control_events` field on `DesireSolution` keeps
historical replays compatible with older logs via the serde default.

When you want to feed live telemetry back into Desire, use the new
`DesireGradientControl::control_with_gain()` builder. It mirrors the ergonomic
sketch above—pipe the latest entropy estimate, Z magnitude, quality score, and
clip hints directly into the builder and call `finalise()` to obtain the packed
control:

```rust
let ctrl = DesireGradientControl::control_with_gain()
    .with_gain(gain_factor)
    .with_entropy(last_entropy)
    .with_z_coupling(z_magnitude)
    .with_quality(quality_estimate)
    .with_bounds(1e-4, 3e-3)
    .with_clip_p95_hint(p95_gradient)
    .finalise();
lag.set_gradient_control(ctrl.clone());
```

For GPU loops, call `CanvasProjector::desire_control_uniform` (or the WASM
`FractalCanvas.desireControlUniform`) to obtain a `Uint32Array` view of the
packed uniform. Each lane stores the IEEE-754 bits for the target entropy,
learning-rate envelope, clipping window, Z coupling, quality gain, and rate
scales, with the final element containing the raw telemetry mask. Reinterpret
the buffer as a `Float32Array` when uploading to WGSL so the compute shader sees
the expected 16-lane, 64-byte-aligned payload without reserialising structs for
every dispatch.

To automate the “unconscious” loop, wrap the lagrangian with
`DesireAutomation`. It samples the `SelfRewriteCfg` thresholds, tracks
hypergrad drift during the integration phase, and emits
`DesireRewriteTrigger` structures once enough evidence accumulates. Each
trigger carries the normalised avoidance vector so a SpiralK
`self-rewrite` or hypergrad scheduler can queue barycentric nudges without
hand-crafted heuristics.

```rust
use st_core::config::self_rewrite::read_cfg;
use st_nn::language::{DesireAutomatedStep, DesireAutomation};
use std::time::Instant;

let cfg = read_cfg();
let mut automation = DesireAutomation::new(desire, cfg);
let DesireAutomatedStep { solution, trigger } = automation
    .step(&logits, previous_token, &concept_hint, Instant::now())?;
if let Some(event) = trigger {
    spiralk_scheduler.queue_desire(event.report, event.mean_penalty);
}
```

`read_cfg()` now pulls from layered configuration files so operators can
separate defaults, site overrides, and run-time experiments without rebuilding
or touching environment variables. By default the loader merges
`~/.spiraltorch/config/base.toml`, `site.toml`, and `run.json` (in that order),
falling back to `~/.spiraltorch` when the `config/` directory is absent. Each
layer is optional—missing files are ignored—and environment variables such as
`SPIRAL_CONFIG_ROOT`, `SPIRAL_CONFIG_BASE`, `SPIRAL_CONFIG_SITE`, and
`SPIRAL_CONFIG_RUN` can redirect the loader to alternate locations. Per-run
JSON overrides make it easy to script experiments (for example via
`run.json` produced by an orchestrator) while keeping persistent defaults in
TOML. Every merge emits a diff event that records which keys changed and their
before/after values.

Python callers can retrieve the same diff stream via
`spiraltorch.get_config_events()`, which returns dictionaries of
`{"layer": "run", "path": "desire.self_rewrite.score_thresh", "previous": 0.02, "current": 0.05}`.
Point the module at alternate config roots (for example when replaying a site
profile) by exporting the environment variables before importing
`spiraltorch` so the layered loader observes the overrides.

Persist the stream to disk with `DesireLogbook` so the observation/injection/
integration cadence can be replayed later or shared with SpiralK rewrite
automation. The logbook writes line-delimited JSON records that contain the
entire `DesireSolution` payload plus any emitted triggers, keeping telemetry and
avoidance vectors together for offline inspection. Re-opening the logbook will
resume the ordinal counter automatically, so a long-running automation loop can
be restarted without clobbering record IDs.

```rust
use st_nn::language::{DesireAutomatedStep, DesireAutomation, DesireLogbook};
use std::time::{Instant, SystemTime};

let mut logbook = DesireLogbook::new("desire.ndjson")?;
let DesireAutomatedStep { solution, trigger } = automation
    .step(&logits, previous_token, &concept_hint, Instant::now())?;
logbook.record(&DesireAutomatedStep { solution, trigger }, SystemTime::now())?;
```

Stream the persisted decisions back with `DesireLogReplay` to build dashboards
or off-line analytics. The iterator skips blank lines and surfaces every record
as a `PureResult`, making it straightforward to plug into telemetry sinks or
trainers that ingest JSONL traces.

```rust
use st_nn::language::DesireLogReplay;

for entry in DesireLogReplay::open("desire.ndjson")? {
    let record = entry?;
    audit(record.ordinal, record.solution.phase);
}
```

Once the raw telemetry exists, braid it directly into automation, logging, and
rewrite hooks with the `DesirePipeline`. The pipeline fans each automated step
out to any number of sinks—logbooks, trigger buffers, SpiralK bridges—so graph
tooling, language desire, and self-rewrite loops evolve together without custom
glue. Attach a
`DesireTriggerBuffer` to capture emitted rewrite events while the logbook keeps
the JSONL trace alive, and optionally replay historical automation into new
consumers:

```rust
use st_nn::language::{
    DesireLogReplay, DesireLogbook, DesirePipeline, DesireTriggerBuffer,
};

let trigger_buffer = DesireTriggerBuffer::new();
let mut pipeline = DesirePipeline::builder(automation)
    .with_logbook(DesireLogbook::new("desire.ndjson")?)
    .with_sink(trigger_buffer.clone())
    .build();

let step = pipeline.step_realtime(&logits, previous_token, &concept_hint)?;
if let Some(trigger) = &step.trigger {
    spiralk_scheduler.queue_desire(trigger.report.clone(), trigger.mean_penalty);
}

pipeline.flush()?;
let replayed = pipeline.replay(DesireLogReplay::open("desire.ndjson")?)?;
let drained = trigger_buffer.drain()?; // forward to analytics or trainers
```

Python bindings currently expose **desire-derived gradient control** primitives
(via `Hypergrad.desire_control(...)` / `desire_interpretation(...)`). The full
`DesirePipeline` builder + logbook sinks remain Rust-first today.

```python
import spiraltorch as st

hyper = st.Hypergrad(curvature=-0.9, learning_rate=0.05, rows=1, cols=4)
real = st.Realgrad(learning_rate=0.01, rows=1, cols=4)
try:
    pred = st.Tensor(1, 4, [0.2, 0.1, 0.3, 0.4])
    tgt = st.Tensor(1, 4, [0.0, 1.0, 0.0, 0.0])

    hyper.accumulate_pair(pred, tgt)
    real.accumulate_pair(pred, tgt)

    real_summary = real.summary()
    control = hyper.desire_control(real_summary)
    interp = hyper.desire_interpretation(real_summary)

    print("operator mix/gain:", control.operator_mix(), control.operator_gain())
    print("pressure/balance:", interp.hyper_pressure(), interp.balance())
finally:
    hyper.reset()
    real.reset()
```

When you need to splice the stream into other runtimes, attach a
`DesireChannelSink` via `with_channel`. It emits `DesirePipelineEvent`s over a standard channel so
rewriters, trainers, or async dashboards can subscribe without bespoke glue—each
step arrives before any trigger for the same timestamp, preserving ordering for
downstream automata.

```rust
use std::sync::mpsc::channel;
use st_nn::language::{
    DesirePipeline, DesirePipelineEvent, DesireTriggerBuffer,
};

let (sender, receiver) = channel();
let mut pipeline = DesirePipeline::builder(automation)
    .with_channel(sender)
    .with_sink(DesireTriggerBuffer::new())
    .build();

let step = pipeline.step_realtime(&logits, previous_token, &concept_hint)?;
for event in receiver.try_iter() {
    match event {
        DesirePipelineEvent::Step { step, timestamp } => {
            audit(step.solution.phase, timestamp)
        }
        DesirePipelineEvent::Trigger { trigger, .. } =>
            spiralk_scheduler.queue_desire(trigger.report.clone(), trigger.mean_penalty),
    }
}
```

Global telemetry consumers can subscribe without owning the pipeline by adding
`with_telemetry()`. The `DesireTelemetrySink` records every step’s phase,
temperature, avoidance energy, and schedule weights into the shared telemetry
hub so trainers, notebooks, or external services can poll the latest state via
`get_last_desire_step`.

```rust
use st_core::telemetry::hub;
use st_nn::language::DesirePipeline;

let mut pipeline = DesirePipeline::builder(automation)
    .with_telemetry()
    .build();

let _ = pipeline.step_realtime(&logits, previous_token, &concept_hint)?;
if let Some(sample) = hub::get_last_desire_step() {
    println!("phase {:?} at T={:.3}", sample.phase, sample.temperature);
}
```

Training loops can now subscribe directly. Clone a `DesireTrainerBridge`, attach
it with `with_trainer_bridge`, and hand the same bridge to `ModuleTrainer` via
`enable_desire_pipeline`. Each step drains into a shared summary so the trainer
records phase counts, mean desire weights, and trigger temperatures alongside
band energy telemetry without custom glue.

```rust
use st_nn::language::{
    ConceptHint, DesirePipeline, DesireTrainerBridge, DesireTriggerBuffer,
};
use st_nn::trainer::ModuleTrainer;

let bridge = DesireTrainerBridge::new();
let mut pipeline = DesirePipeline::builder(automation)
    .with_trainer_bridge(&bridge)
    .with_sink(DesireTriggerBuffer::new())
    .build();

trainer.enable_desire_pipeline(bridge.clone());
let step = pipeline.step_realtime(&logits, previous_token, &concept_hint)?;
if let Some(trigger) = &step.trigger {
    println!("trigger mean penalty: {:.3}", trigger.mean_penalty);
}
```

Graph telemetry can join the same braid. Instantiate a `GraphFlowTracer`, feed it
into `GraphConsensusBridge`, and wrap the result with `DesireGraphBridge`. Every
desire step now captures the latest graph digest, letting you aggregate
Z-space desire entropy with SpiralK’s quad-band consensus or replay graph
shares into analytics dashboards via `DesireGraphSummary`.

```rust
use std::sync::{Arc, Mutex};
use st_core::telemetry::xai::{GraphFlowTracer, NodeFlowSample};
use st_nn::language::{DesireGraphBridge, DesirePipeline};
use st_nn::{BandEnergy, GraphConsensusBridge};

let tracer = Arc::new(Mutex::new(GraphFlowTracer::new()));
let graph_bridge = DesireGraphBridge::new(
    GraphConsensusBridge::new(tracer.clone()),
    BandEnergy { above: 0.4, here: 0.35, beneath: 0.25, drift: 0.0 },
);
let mut pipeline = DesirePipeline::builder(automation)
    .with_graph_bridge(&graph_bridge)
    .build();

// capture graph flows alongside desire automation
tracer.lock().unwrap().begin_layer(
    "gnn::spiral",
    -1.0,
    vec![NodeFlowSample { node_index: 0, incoming_weight: 1.0, aggregated_norm: 0.6 }],
);

let step = pipeline.step_realtime(&logits, previous_token, &concept_hint)?;
if let Some(summary) = graph_bridge.drain_summary()? {
    for (layer, share) in summary.layer_support {
        println!("graph layer {layer} captured {:.2}% of energy", share * 100.0);
    }
}
```

Roundtable consensus can now absorb desire impulses directly. Attach a
`DesireRoundtableBridge` and the pipeline will export Above/Here/Beneath
multipliers plus drift adjustments every step. Drain the summary or let
`ModuleTrainer::enable_desire_roundtable_bridge` fold it into the optimiser so
the three-way negotiation constantly reflects the latest semiotic pressure.

```rust
use st_nn::language::{DesirePipeline, DesireRoundtableBridge};

let bridge = DesireRoundtableBridge::new().with_blend(0.45);
let mut pipeline = DesirePipeline::builder(automation)
    .with_roundtable_bridge(&bridge)
    .build();

for (step, logits) in logits_stream.enumerate() {
    let now = Instant::now();
    let timestamp = SystemTime::now();
    pipeline.step_at(&logits, step % vocab, &concept_hint, now, timestamp)?;
}

if let Some(summary) = bridge.drain_summary()? {
    println!("desire barycentric → Above {:.3}", summary.mean_above);
}
```

Inside the trainer simply call:

```rust
trainer.enable_desire_roundtable_bridge(bridge.clone());
```

Every optimisation step now reports `desire_roundtable_*` metrics, while
`ModuleTrainer::desire_roundtable_summary()` returns the most recent aggregate so
Python notebooks can watch the unconscious drift in real time.

Need all three braids at once? `DesireTelemetryBundle` wires the trainer,
roundtable, and ψ bridges together so experiments can attach a single bundle to
both the pipeline and optimiser.

```rust
use st_nn::language::{
    DesirePipeline, DesirePsiBridge, DesireRoundtableBridge, DesireTelemetryBundle,
    DesireTrainerBridge,
};

let trainer_bridge = DesireTrainerBridge::new();
let roundtable_bridge = DesireRoundtableBridge::new();
let psi_bridge = DesirePsiBridge::new();
let bundle = DesireTelemetryBundle::new()
    .with_trainer_bridge(&trainer_bridge)
    .with_roundtable_bridge(&roundtable_bridge)
    .with_psi_bridge(&psi_bridge);

let mut pipeline = DesirePipeline::builder(automation)
    .with_telemetry_bundle(&bundle)
    .build();

trainer.enable_desire_telemetry(&bundle);
```

Python note: `DesireRoundtableBridge` / ψ telemetry bridges are not yet exposed in
the published wheel. For notebook-friendly feedback today, use
`Hypergrad.desire_control(...)` (shown above).

ψ telemetry can ride the same braid. Attach a `DesirePsiBridge` to fold the
latest `PsiMeter` readings, SoftLogic Z feedback, and threshold crossings into
the automation stream. The bridge can be drained directly or wired into
`ModuleTrainer::enable_desire_psi_bridge` so every optimisation step records the
aggregated ψ view alongside desire entropy and graph consensus.

```rust
use st_core::telemetry::hub;
use st_core::telemetry::psi::{PsiComponent, PsiReading};
use st_nn::language::{DesirePipeline, DesirePsiBridge};

let psi_bridge = DesirePsiBridge::new();
let mut pipeline = DesirePipeline::builder(automation)
    .with_psi_bridge(&psi_bridge)
    .build();

// seed hub telemetry before each step (normally done by ModuleTrainer)
let mut breakdown = std::collections::HashMap::new();
breakdown.insert(PsiComponent::LOSS, 0.9);
let reading = PsiReading { total: 0.9, breakdown, step: 1 };
hub::set_last_psi(&reading);

let step = pipeline.step_realtime(&logits, previous_token, &concept_hint)?;
if let Some(summary) = psi_bridge.drain_summary()? {
    println!("ψ mean total: {:.3}", summary.mean_psi_total);
}
```

The result is a single Rust-native control surface that marries KL control,
Schrödinger bridges, and entropic GW into SpiralTorch’s Z-space, ready to steer
language modules, rewrite monads, or SpiralK trainers without bespoke Python
glue.

## Hello SpiralSession quickstart

The wheel ships a self-contained demo script that exercises the currently
supported Python surface:

```bash
python bindings/st-py/examples/hello_session.py
```

Minimal session + rank planning:

```python
import spiraltorch as st

session = st.SpiralSession()  # backend="auto" by default
print("backend:", session.backend, "device:", session.device)

plan = session.plan_topk(rows=128, cols=256, k=32)
print("plan:", plan.kind, plan.merge_strategy, "tile", plan.tile, "workgroup", plan.workgroup)
print("SpiralK hint:\n", plan.fft_spiralk_hint())

session.close()
```

Minimal dataset loader (runs entirely in Rust):

```python
import spiraltorch as st

session = st.SpiralSession()
pairs = [
    (st.Tensor(1, 2, [1, 0]), st.Tensor(1, 2, [1, 0])),
    (st.Tensor(1, 2, [0, 1]), st.Tensor(1, 2, [0, 1])),
]
loader = session.dataloader(pairs, batch_size=2, shuffle=123, prefetch=2)
for x, y in loader:
    print("batch:", x.shape(), y.shape())
session.close()
```

Minimal `ModuleTrainer` loop:

```python
import spiraltorch as st

trainer = st.ModuleTrainer(input_dim=2, output_dim=2)
inputs = [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]]
targets = [[0.0, 1.0], [0.0, 1.0], [1.0, 0.0], [1.0, 0.0]]
loss = trainer.train_epoch(inputs, targets, learning_rate=0.1, batch_size=2)
print("avg loss:", loss)
```

### GoldenRetriever Training (distributed, data-race free)

Need to fan training across multiple local workers without sprinkling raw
`Arc<Mutex<...>>` or bespoke runtimes through your code? Enable the new `golden`
feature flag to pull in SpiralTorch’s Tokio/Rayon-style runtime and let the
**GoldenRetriever** orchestrator coordinate the fleet:

```bash
cargo test -p st-nn --features "golden" golden::tests::golden_retriever_trains_in_parallel -- --exact
```

The runtime exposes SpiralTorch-flavoured wrappers (`SpiralArc`, `SpiralMutex`,
`GoldenRuntime`) so modules, losses, and trainers stay inside the guard rails
while the scheduler spawns blocking steps and performs deterministic
Rayon-style reductions. A minimal Rust loop looks like:

```rust
use st_nn::{GoldenRetriever, GoldenRetrieverConfig, Linear, MeanSquaredError, ModuleTrainer};

let mut trainer_a = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
let mut trainer_b = ModuleTrainer::new(caps, -1.0, 0.05, 0.01);
let mut retriever = GoldenRetriever::new(GoldenRetrieverConfig::default(), vec![trainer_a, trainer_b])?;
let report = retriever.run_epoch(modules, losses, loaders, schedules)?;
println!("workers={} avg_loss={}", report.workers, report.average_loss);
```

Need curvature-aware consensus from multiple Z-space patches? Call
`GoldenRetriever::sync_z_barycenter(&partials, rank)` to fold worker tensors
into a single Leech-biased barycenter before broadcasting the result back to the
fleet. Pair it with `GoldenRetriever::install_blackcat_moderator(threshold,
participants)` to seed cooperative moderators on every trainer without touching
individual mutexes—perfect for multi-node runs where you want Redis-backed
guards and SpiralK hints to stay aligned.

For an auditable path, use `sync_z_barycenter_with_receipt(...)`, or build a
Golden-specific Black Cat controller with
`golden_barycenter_adaptation_session(...)` before passing its validated plan to
`sync_z_barycenter_with_plan(...)`. Golden candidate identity follows the FFT
tile actually consumed by the guard, not unrelated rank-k knobs. Before reward
credit, call `validate_golden_barycenter_output(...)` to compare the result with
an independently recomputed partial/guard reference. The returned
`GoldenBarycenterReceipt` captures the effective rank, guard, and complete plan
snapshot. It also states `plan_executed: false` because the plan parameterizes
the Golden guard rather than claiming a rank-k launch.

GoldenRetriever keeps each trainer behind a poison-resistant mutex, launches the
epoch bodies on the shared runtime, and reduces the per-worker metrics using the
built-in parallel reducer so the roundtable stays deterministic. No additional
locking or thread book-keeping required.

Need the distributed run to keep every local Blackcat moderator in sync? Toggle
the cooperative switches on the config:

```rust
let config = GoldenRetrieverConfig {
    sync_blackcat_minutes: true,
    sync_heuristics_log: true,
    coordinate_blackcat: true,
    exploration_bias: 1.5,
    optimization_boost: 0.75,
    synergy_bias: 1.25,
    reinforcement_bias: 1.1,
    ..GoldenRetrieverConfig::default()
};
let mut retriever = GoldenRetriever::new(config, vec![trainer_a, trainer_b])?;
let report = retriever.run_epoch(modules, losses, loaders, schedules)?;
assert!(!report.moderator_minutes.is_empty());
if let Some(pulse) = &report.cooperative_pulse {
    use std::time::Duration;
    println!(
        "dominant_plan={:?} exploration={} optimization={} synergy={} reinforcement={}",
        pulse.dominant_plan,
        pulse.exploration_drive,
        pulse.optimization_gain,
        pulse.synergy_score,
        pulse.reinforcement_weight
    );
    let directive = pulse.directive(Duration::from_secs_f32(2.0), 48);
    println!(
        "retune: push_interval={:.2}s summary_window={} reinforcement_weight={:.2}",
        directive.push_interval.as_secs_f32(),
        directive.summary_window,
        directive.reinforcement_weight
    );
}
```

Every epoch collects the union of moderator minutes and heuristics ops across
workers, rebroadcasting them before the next round so proposals and soft rules
stay aligned. With `coordinate_blackcat` flipped on, GoldenRetriever also emits
an aggregated **GoldenBlackcatPulse** that nudges every worker’s distributed
node. The pulse now captures cooperative synergy (`synergy_score`), the amount
of shared reinforcement from heuristics and moderator minutes
(`reinforcement_weight`), confidence-weighted coverage, and raw op-log
composition. Each pulse can synthesize a `GoldenCooperativeDirective`, which
Golden retrievers and trainers use to retune push intervals and summary windows
without guessing at scaling factors. Trainers expose both
`last_blackcat_pulse()` and `last_blackcat_directive()` so downstream tooling
can inspect exactly how the synergy evolved during the run.

Blackcat now keeps a running scoreboard for every plan signature it moderates.
Each entry tracks observation counts, mean support, reward, ψ, and confidence so
dashboards can highlight sustained winners instead of relying on a single
minute. Access the aggregated view with `ModuleTrainer::blackcat_scoreboard()`
from Rust or call `trainer.blackcat_scoreboard()` in Python to retrieve a list
of dictionaries (plan signature, script hint, averages, and timestamps). The
scoreboard honours the moderator history window and can be capped via
`BlackcatModerator::set_scoreboard_limit()` when you only care about the top-N
plans.

Need runtime telemetry without wiring into a dashboard? The embedded Blackcat
runtime now keeps exponential moving averages for step time, memory pressure,
retry rate, and the reward distribution. Call
`ModuleTrainer::blackcat_runtime_stats()` to fetch a
`BlackcatRuntimeStats` snapshot that includes the latest reward mean/stddev and
all tracked extra metrics. Python callers can access the same data via
`trainer.blackcat_runtime_stats()`, which returns a rich object with dict-like
extras for quick printing or logging.

`GoldenRetrieverConfig` picked up `synergy_bias` and `reinforcement_bias` knobs
to tilt how aggressively the aggregated metrics should respond to support vs.
heuristic weight. Bumping `synergy_bias` favours exploration-heavy, confidence
driven pulses while `reinforcement_bias` amplifies heuristics and reward
signals when tightening distributed synchronization. When you want Golden to
renegotiate those biases automatically, hand it a
`GoldenSelfRewriteConfig`. The retriever stages a four-party council (explorer,
optimizer, harmoniser, reinforcer) that blends the latest cooperative pulse
with scheduler depth to rewrite the coordination biases in-place:

```rust
use st_nn::{GoldenRetriever, GoldenRetrieverConfig, GoldenSelfRewriteConfig};

let mut retriever = GoldenRetriever::new(
    GoldenRetrieverConfig::default().with_self_rewrite(
        GoldenSelfRewriteConfig::default()
            .with_schedule_weight(0.8)
            .with_negotiation_rate(0.45)
            .with_inertia(0.5),
    ),
    vec![trainer_a, trainer_b],
)?;
let before = retriever.coordination_biases();
// modules/losses/loaders/schedules prepared as shown above
let report = retriever.run_epoch(mods.clone(), losses.clone(), loaders.clone(), schedules.clone())?;
let after = retriever.coordination_biases();
println!("biases before={before:?} after={after:?}");
if let Some(pulse) = &report.cooperative_pulse {
    let mut persisted = GoldenRetrieverConfig::default().with_self_rewrite(
        GoldenSelfRewriteConfig::default().with_schedule_weight(0.8),
    );
    persisted.rewrite_with_scheduler(&schedules, Some(pulse));
}
```

`GoldenRetriever::coordination_biases()` exposes the live negotiation result so
Dashboards can visualise the four delegates converging. The
`rewrite_with_scheduler` helper mirrors the runtime logic in case you need to
persist the negotiated configuration or replay it in another process.

For longer runs the self-rewrite council now keeps a rolling transcript. The
`GoldenSelfRewriteConfig` gained `with_council_memory`,
`with_schedule_resonance`, and `with_synergy_pressure` knobs so you can tune how
aggressively schedule depth and Blackcat energy bend the delegates. Every epoch
emits a `GoldenCouncilSnapshot` that summarises the negotiated biases,
resonance, and stability alongside the pulse that triggered it. The snapshot now
tracks the epoch watermark, the heuristics log ranges that still need
reconciliation, the top soft-rule winners, and a `CouncilEvidence` bundle that
captures band energy, graph flow, ψ, and geometric cues used for the vote.
Inspect it via `GoldenEpochReport::council_snapshot()` or the new
`GoldenRetriever::last_council()` helper to plot convergence, detect
oscillations, or persist the negotiated state for a follow-up run. Consumers who
need streaming updates can subscribe with `GoldenRetriever::subscribe_digest()`
and replay `CouncilDigest` events as nodes fall in and out of the cluster.

Python note: Golden/Blackcat runtime taps are currently Rust-first; Python
wrappers for council/pulse snapshots are on the roadmap.

### SpiralTorchRL (agents)

The wheel exports lightweight RL agents under `spiraltorch.rl` (alias of
`spiral_rl`) so you can prototype bandits, PPO, or SAC loops without leaving the
native stack.

```python
import spiraltorch as st

agent = st.rl.stAgent(state_dim=1, action_dim=2, discount=0.0, learning_rate=5e-2)
agent.set_epsilon(0.1)

trace = agent.select_action_trace(0)
action = int(trace["action"])
agent.update(0, action, reward=1.0, next_state=0)

print("ok (stAgent)")
print("policy:", agent.policy_report(0))
print("trace:", trace)
print("also available:", [name for name in ("PpoAgent", "SacAgent") if hasattr(st.rl, name)])
```

Rust projects can pair the policy with the new geometric feedback module to
ground the update scale in observability measurements. Feed a
`DifferentialResonance` snapshot into `GeometryFeedback` and the learner will
adapt its learning rate according to the coalgebra efficiency.

```rust
use st_core::theory::observability::{ObservabilityConfig, SlotSymmetry};
use st_spiral_rl::{GeometryFeedback, GeometryFeedbackConfig, SpiralPolicyGradient};

let mut policy = SpiralPolicyGradient::new(6, 3, 0.01, 0.99)?;
let feedback = GeometryFeedback::new(GeometryFeedbackConfig {
    observability: ObservabilityConfig::new(1, 5, SlotSymmetry::Symmetric),
    z_space_rank: 24,                 // Maryna Viazovska's Leech shell as default
    leech_density_weight: 0.5,        // densify η with Λ24 packing pressure
    ramanujan_iterations: 4,          // refine π via Ramanujan's fast series
    softening_beta: 0.6,              // keep the projection memory-light
    max_learning_rate_scale: 2.8,     // pre-clamped to stay in the 2..3 stable band
    ..GeometryFeedbackConfig::default_policy()
});
policy.attach_geometry_feedback(feedback);
let resonance = session.trace(state.clone())?
    .generator(direction.clone())?
    .barycenter(barycenter.clone())?
    .resonate()?; // DifferentialResonance snapshot
let (report, signal) = policy.finish_episode_with_geometry(&resonance)?;
if let Some(signal) = signal {
    println!("η̄={:.3}, scale={:.2}", signal.averaged_efficiency, signal.learning_rate_scale);
}
let telemetry = policy.telemetry();
if let Some(geo) = telemetry.geometry {
    println!("rank~{:.1} pressure~{:.4} scalē~{:.2}", geo.rolling_rank, geo.rolling_pressure, geo.rolling_scale);
}
```

Hypergradient loops can now fuse loss variance with the geometric controller via
the **HyperSurprise** pipeline. Attach a `LossStdTrigger` and SpiralTorch injects
η̄ pulses whenever the episode's return standard deviation breaches the guard:

```rust
use st_spiral_rl::{HyperSurpriseConfig, LossStdTrigger, SpiralPolicyGradient};

let mut policy = SpiralPolicyGradient::new(4, 2, 0.05, 0.9)?;
policy.attach_hyper_surprise_with_config(
    LossStdTrigger::new(0.12)
        .with_warmup(2)
        .with_max_ratio(2.5)
        .with_deadband(0.15),
    HyperSurpriseConfig::default()
        .with_smoothing(0.35)
        .with_reversion(0.55)
        .with_lr_floor(1e-4),
);
// ...record transitions...
let report = policy.finish_episode()?;
if let Some(surprise) = &report.hyper_surprise {
    println!(
        "σ={:.3} inject={:.2} η̄={:.3} gauge={:.2} lr={:.4} σ̂={:.3}",
        surprise.loss_std,
        surprise.inject_ratio,
        surprise.eta_bar,
        surprise.gauge,
        surprise.learning_rate,
        surprise.rolling_std
    );
}
```

`LossStdTrigger` keeps an EMA of the observed loss standard deviation, applies a
configurable deadband before clamping surprise pulses, and modulates both the
learning-rate and gradient gauge inside the episode update.
`SpiralPolicyGradient::last_hyper_surprise()` exposes the latest packet so
telemetry dashboards can correlate η̄ spikes with emergent behaviour.

`HyperSurpriseConfig` now includes builder helpers for smoothing, gauge floors,
and floor clamps on both η̄ and the learning rate. A dedicated reversion factor
lets gauges glide back to baseline instead of snapping when shocks subside, and
the emitted telemetry now shares the rolling standard deviation alongside the
imposed clamps. Ratio telemetry is derived from the post-clamp, smoothed gauge
so `HyperSurpriseSignal::inject_ratio` mirrors the actual scaling applied to
η̄ and the learning-rate. These guards keep legacy pipelines untouched (defaults
mirror the previous behaviour) while unlocking telemetry-rich packets via
`HyperSurpriseSignal::gauge`, `HyperSurpriseSignal::learning_rate`, and
`HyperSurpriseSignal::rolling_std`.

`HyperSurpriseConfig` now includes builder helpers for smoothing, relaxation
back to the baseline gauge, ratio smoothing, cooldown windows, gauge floors, and
floor clamps on both η̄ and the learning rate. These guards keep legacy
pipelines untouched (defaults mirror the previous behaviour) while unlocking
telemetry-rich packets via `HyperSurpriseSignal::gauge` and
`HyperSurpriseSignal::learning_rate`.

The controller uses the ratio smoother to bleed off residual pulses instead of
snapping gauge/η̄ immediately back to baseline, and the cooldown window prevents
short bursts of volatility from hammering the learner every frame. Relaxation
lets you pick how gently the gauge returns to neutral once the surprise subsides
so you can trade responsiveness for smoothness depending on your training
regime.

Chrono loop signals now feed directly into the controller: every
`SpiralSession::resonate_over_time` call plants a `ChronoLoopSignal` in the
telemetry hub, and `SpiralPolicyGradient::finish_episode_with_geometry` consumes
the latest signal before measuring a resonance snapshot. Harmonic gain and decay
estimates tighten the learning-rate clamps, bump the Λ₂₄ pressure when collapse
drive pulses flare, and publish the live loop gain/softening factor through
`PolicyTelemetry.geometry`. In other words, Z-space temporal dynamics, SpiralK
heuristics, and collapse drive pressure now close a tidy feedback loop without
additional plumbing.

The loop no longer stops at a single node: every roundtable summary and collapse
intervention now broadcasts a bounded `LoopbackEnvelope` through the telemetry
hub. SpiralK meta-summaries attach their script hints, the softlogic observer
threads its live Z-space bias, and PSI collapse totals hitch a ride so other
policies can replay the same temporal context. `GeometryFeedback::absorb_loopback`
blends the envelopes into a synthetic chrono signal, boosts clamp tightening
according to peer support, and preserves the strongest SpiralK script so the
controller can keep rewriting its own limits. Callers don’t need extra wiring—
the policy gradient automatically drains the envelope queue before every
resonance measurement and folds the distributed telemetry back into Z-space.

### SpiralTorchRec (open-topos recommendation lattice)

SpiralTorchRec factors implicit-feedback matrices under open-cartesian topos
guards so embeddings stay psychoid-safe during long training arcs. The Rust
crate exposes a deterministic SGD loop with saturation-aware updates while the
Python view (`spiraltorch.rec.Recommender`) mirrors the same ergonomics for
notebooks and serving pipelines. User and item embeddings remain regularised by
the curvature guard, ensuring they can be re-imported into SpiralTorch modules
without violating the Z-space contract.

```python
from spiraltorch.rec import Recommender

rec = Recommender(users=10, items=20, factors=5, learning_rate=0.03, regularization=0.002)
epoch = rec.train_epoch([(0, 0, 4.0), (0, 3, 5.0), (1, 0, 3.5)])
print(epoch.rmse, rec.predict(0, 1))
```

### Observation DAG calculus (Pólya-calibrated final coalgebra)

The new `st_core::theory::observability` module formalises the experimental
setup behind our DAG compression runs. Observation trees are treated as the
final coalgebra of the endofunctor `F(X) = R × Orb_{G_Λ}(X^b)` where `R` is the
root alphabet and the child slots are quotiented by a symmetry group (S₍b₎,
C₍b₎, or D₍b₎). The helper exposes both the Pólya upper bound and the efficiency
`η = observed / expected` so you can tell exactly how much structure survives a
given symmetry choice.

```rust
use st_core::theory::observability::{
    ColorAction, ColorSymmetry, ObservabilityConfig, ObservationalCoalgebra, SlotSymmetry,
};

let config = ObservabilityConfig::new(
    1,                // structural root variants (without colour)
    3,                // b: ternary branching
    SlotSymmetry::Dihedral,
)
.with_color_action(ColorAction::new(2, ColorSymmetry::Symmetric));
let mut coalgebra = ObservationalCoalgebra::new(config);
let theoretical = coalgebra.unfold(3);          // free-branching upper bound
let measured = vec![1, 4, 52, 1_368];
let assessment = coalgebra.assess(&measured);
println!("theoretical counts: {:?}", theoretical);
println!("η per depth: {:?}", assessment.efficiency);

// Symmetric colour action identifies {a,b}, so "pure a" is invisible until symmetry is broken.
let colour_gate = ColorAction::new(2, ColorSymmetry::Symmetric);
assert_eq!(colour_gate.singleton_observable().unwrap(), false);
```

Pair the output with your `roundtable.log` counts to see exactly which depth or
symmetry regime causes drops in observability. Lowering the symmetry (e.g.
S₍b₎→C₍b₎→Exact) or enriching the alphabet instantly changes the theoretical
sequence, making it trivial to reason about how much “pure a” signal can ever be
observed before symmetry breaking. Likewise, switching the colour action to
`ColorSymmetry::Trivial` raises the observable root count and restores singleton
visibility—the exact manoeuvre the theoretical note predicts when constructing
`c′`.

## What you get for training

- **Rank-K family** (TopK / MidK / BottomK) with a **single entrypoint**
  Backends implement a `RankKExecutor`, decisions are made once via **unison heuristics**, and every plan can now be rendered back into a SpiralK snippet via `choice.to_unison_script(kind)`. Hard SpiralK rewrites return a newly validated Rust `RankPlan`; malformed workgroups, FFT settings, or conflicting 1CE/2CE directives are rejected rather than repaired by a binding.
  On WGPU, `choice.use_2ce` now executes the Rust-owned exact two-command path: planner-sized tiles are finite-filtered and total-ordered first, then merged into TopK, MidK, or BottomK with the same lower-index tie-break and `(NaN, -1)` padding as the CPU reference. Python only projects this plan and kernel report; it does not reconstruct rank semantics.
- **Introspectable compute plans**
  Unified `RankPlan`s expose a validated FFT execution contract directly. Call `plan.fft_plan()?` to inspect the radix/segment shape and ordered ping-pong dispatches, `plan.fft_wgsl()?` to emit their shared WGSL module, or `plan.fft_spiralk_hint()?` to log the same choice back into SpiralK. Invalid radix, non-power-of-two tiles, and out-of-range segment counts fail closed in Rust.
- **SpiralK DSL** (K×Lisp-inspired)
  Hard assigns (`mk:`, `tile:`) and soft rules (`soft(mk, …)`, `soft(tile, …)`) that blend with measurements.
- **SoftLogic (finite-domain solver)**
  Explores a tiny discrete space (merge kinds, tiles) and scores candidates with your soft rules.
- **Pure Rust training core**
  `st-tensor::pure` ships dependency-free tensors, hyperbolic Z-space encoders,
  the new `UringFractalScheduler` for Tokio-uring style streaming, and the
  `AmegaHypergrad` tape so you can iterate on learning logic without
  PyTorch/Numpy while staying inside non-Euclidean geometry.
- **Open-topos hypergrad streaming**
  Parameters can now absorb complex Z-space waves or raw text directly into the
  hypergrad tape, so the roundtable can keep expanding meaning without Euclidean
  fallbacks or NumPy buffers.
- **TensorBiome canopies + spiral biomes**
  Curate rewrites with `TensorBiome`, weight individual shoots, stack the full
  harvest, and let SoT-3Dφ planners seed a ready-to-project biome via
  `SoT3DPlan.grow_biome(...)` before reinjecting it with `ZSpaceProjector`.
- **Rust-first modules & losses**
  `st-nn` now ships `Linear`, `Sequential`, the lightweight `Relu`, sequence
  cores like `SpiralRnn`/`WaveRnn`, hyperbolic-friendly `ZSpaceSoftmax`, the
  hyperbolic `WaveGate`, `ToposResonator`, the new `ZSpaceMixer`, and the
  `ZSpaceProjector` alongside `MeanSquaredError` / `HyperbolicCrossEntropy` /
  `CategoricalCrossEntropy` losses. They stream gradients through the hypergrad
  tape, apply open-topos rewrites, and keep SpiralK planners one call away with
  roundtable-aware scheduling helpers. Every primitive is exported through the
  Python wheel so you can stay NumPy-free while scripting experiments—with the
  new `spiraltorch.dataset.DataLoader` keeping shuffle/batch/prefetch entirely
  in Rust.
- **Optional WASM tuner table**
  Bake the JSON dataset offline and ship it to browsers/WASM. The runtime loads the table lazily, blends it with SpiralK, and keeps the optimiser in sync with the generated WGSL kernels.
- **Self-Rewrite**
  A/B/C conversations and BlackCat training evidence use the canonical Rust
  Wilson interval before appending `soft(...)` rules. The shared store honours
  `SPIRAL_HEUR_FILE`, otherwise writes `~/.spiraltorch/heur.kdsl`, and returns a
  durable append-once receipt rather than hiding persistence failures. Transcripts
  land in `roundtable.log` so you can replay how every choice surfaced. Opening
  the default store imports the legacy `~/.spiraltorch/heur/heur.kdsl` history
  with a hashed byte cursor and leaves the source file intact. Later append-only
  legacy updates import only their new suffix; a rewritten prefix fails closed.
  
---

### Features (opt-in)

- `wgpu`: shared WebGPU runtime plus tensor execution kernels
- `wgpu-rt`: additional rank/linear runtime primitives on the same WGPU context
- `mps`: honest macOS placeholder with Rust-selected WGPU/CPU surrogate routing
- `cuda`: CUDA (NVRTC/PTX loader expected)
- `hip`: ROCm HIP (stub-safe)
- **`hip-real`**: ROCm HIP + RCCL real path, including dense, scaled, lhs-transpose-scaled, device-resident fused bias/residual activation GEMM, owning `RcclCommGuard::allgather_u64()`, and safe row compaction through `compact_rows_f32()` (requires ROCm toolchain & linker; gated on top of `hip`). The backend-neutral shape, output, validation, and CPU oracle live in `st-kernel-contracts`; `st_tensor::compaction` exposes explicit CPU and HIP entrypoints without making a runtime routing decision.
- HIP stub now probes `ROCM_PATH`/`HIP_PATH` and honours the
  `SPIRALTORCH_FORCE_HIP` override so simulated devices keep Z-space heuristics
  alive during CPU-only dev loops.
- **`kv-redis`**: enable Redis-backed consensus (soft hints); absent = **safe no-op**
- `logic` / `kdsl`: SoftLogic solver / SpiralK DSL

---

### Canvas Pixel Transformer → Z-space feedback

- `CanvasProjector::refresh_with_vectors` now returns both the RGBA buffer and
  a colour vector field that carries normalised energy and chroma as
  Z-space-friendly coordinates.
- `FractalCanvas::vectorFieldFft(false)` surfaces the per-row FFT spectrum as
  interleaved energy/chroma pairs so Canvas Transformer pipelines can ingest
  frequency features without leaving Rust.
- `CanvasProjector::accumulate_hypergrad` and
  `CanvasProjector::accumulate_realgrad` stream the refreshed canvas tensor
  directly into SpiralTorch's Riemannian or Euclidean optimisers without
  additional copies.
- `FractalCanvas::relation()` mirrors the projector's tensor output as a
  `Float32Array` so browser call-sites can feed the raw relation into custom
  pipelines or training loops.
- `FractalCanvas::hypergradWave(curvature)` and `FractalCanvas::realgradWave()`
  surface curvature-aware hypergrad updates alongside Euclidean gradients so the
  Canvas Transformer can keep hypergrad/Realgrad buffers in sync by default.
- `FractalCanvas::gradientSummary(curvature)` condenses both tapes into shared
  L1/L2/∞ norms plus RMS/mean-absolute magnitudes so monitoring dashboards can
  watch gradient health without shipping the full relation buffers across the
  WASM boundary.
- `FractalCanvas::desireInterpretation(curvature)` lifts the paired gradient
  summaries into Desire-ready feedback metrics (pressure, balance, stability)
  so automation layers can steer the Desire Lagrangian without leaving WASM.
- `FractalCanvas::desireControl(curvature)` extends that pipeline with
  ready-to-apply Desire gradient control packets—penalty gains, bias/observation
  mixers, and tuned hyper/Realgrad learning-rate scales—mirroring the Rust
  automation layer on the browser side.
- `FractalCanvas::hypergradOperatorUniformFromControl(control)` and
  `FractalCanvas::hypergradOperatorUniformAuto(curvature)` map those Desire
  control packets directly into the WGSL uniform payload, saving JavaScript
  callers from recomputing the blend/gain heuristics before dispatching the
  GPU hypergrad operator.
- `FractalCanvas::vectorFieldFftKernel(true)` returns the ready-to-dispatch
  WGSL compute shader (including uniform layout) so WebGPU call-sites can bind
  the vector field and accumulate the spectrum fully on-GPU.
- `FractalCanvas::hypergradOperatorKernel(false)` emits the complementary WGSL
  pass that accumulates relation tensors into hypergradient buffers directly on
  the GPU, with `hypergradOperatorUniform(mix, gain)` +
  `hypergradOperatorDispatch(subgroup)` mirroring the uniform payload and
  workgroup math for WebGPU callers.
- `FractalCanvas::vectorFieldFftUniform(false)` packages the `CanvasFftParams`
  uniform (width, height, inverse flag, padding) as a `Uint32Array` so the WGSL
  kernel can be dispatched without manual byte packing.
- `FractalCanvas::vectorFieldFftLayout()` reports the byte lengths and strides
  for the `FieldSample`/`SpectrumSample` storage buffers plus the uniform block
  so WebGPU callers can allocate resources without hard-coding struct sizes.
- `FractalCanvas::vectorFieldFftDispatch(true)` computes the workgroup triplet
  for the generated WGSL so callers can hand the counts directly to
  `computePass.dispatchWorkgroups(...)` (or the Rust equivalent) without
  duplicating the ceil division logic.
- Use `CanvasProjector::emit_zspace_patch` to fold the canvas state back into
  the fractal scheduler without leaving Rust or allocating intermediate
  buffers.
- Blend chart priors with the new `z_space_barycenter` solver—available in
  Rust (`st_tensor::z_space_barycenter`) and Python (`spiraltorch.z_space_barycenter`)—to
  wire colour energy directly into the Z-space roundtable.
- Inspect the Tesla tail spectrum via `st_tensor::tesla_tail_spectrum` (Rust) or
  `spiraltorch.tesla_tail_spectrum` (Python), then adapt roundtable weights with
  `spiraltorch.nirt_weight_update` to follow the similarity- and coherence-aware
  NIRT rule.
- Follow the barycenter's loss-monotone intermediates and feed them straight into
  the hypergradient tape with `Hypergrad.accumulate_barycenter_path` so the
  optimiser converges along the same Z-space path as the solver.
- Drive the entire workflow from the high-level `SpiralSession` orchestrator in
  Rust (`st_nn::SpiralSession`) or Python (`spiraltorch.SpiralSession`) to pick
  devices, generate rank plans, synthesise barycentres, and align hypergrads via
  intuitive method calls.
- Launch `session.trace(tensor)` to compose non-commutative homotopy flows,
  functor linearisations, recursive barycenter gradients, and \(\infty\)-tower
  projections before calling `.resonate()` (or
  `.resonate_with_hypergrad(hypergrad)`) to surface a
  `DifferentialResonance` snapshot that binds the four differential layers
  together.
- Let the trace synthesise barycentres on demand via
  `trace.with_barycenter_from(weights, densities)` or override the coupling
  matrix with `trace.with_barycenter_with(weights, densities, Some(coupling))`
  before resonating, keeping Z-space orchestration entirely on the session.

---

## Minimal API

**Rust (TopK via unified entry)**
```rust
use st_core::backend::device_caps::DeviceCaps;
use st_core::ops::rank_entry::{RankKind, plan_rank, execute_rank};

// describe device
let caps = DeviceCaps::wgpu(32, true, 256); // lane, subgroups, max_wg
// plan once (decisions: mk/mkd/tile/ctile/use_2ce)
let plan = plan_rank(RankKind::TopK, rows, cols, k, caps);

// choose a backend executor (WGPU/CUDA/HIP); CPU fallback exists
use st_core::backend::wgpu_exec::WgpuExecutor;
let exec = WgpuExecutor::default();

// launch
execute_rank(&exec, &plan)?;
```

## 🌀 New: ZSpaceCoherenceSequencer

**NOT Attention. NOT Transformer.**

Instead of Q·K^T softmax:
- **Maxwell pulses** detect phase synchronization
- **Desire Lagrangian** applies semantic bias (no RLHF needed)
- **Hyperbolic geometry** naturally encodes hierarchy
- **Fractional operators** replace dot products

```python
import spiraltorch as st
from spiraltorch.nn import ZSpaceCoherenceSequencer

# Toy input (same API as larger models)
x = st.Tensor.rand(1, 768, seed=1)
model = ZSpaceCoherenceSequencer(dim=768, num_heads=12, curvature=-1.0)

out, coherence, diagnostics = model.forward_with_diagnostics(x)
print("channels:", diagnostics.preserved_channels, "preserved,", diagnostics.discarded_channels, "discarded")
print("top report:", diagnostics.channel_reports[0].channel, diagnostics.channel_reports[0].backend)

# Pre-discard sequencing + snapshot history
model.configure_pre_discard(dominance_ratio=0.35, energy_floor=1e-3, min_channels=3)
model.configure_pre_discard_memory(limit=64)

out, coherence, diagnostics = model.forward_with_diagnostics(x)
if diagnostics.pre_discard:
    print("pre-discard:", diagnostics.pre_discard.discarded, "discarded of", diagnostics.pre_discard.total)

latest = model.pre_discard_snapshots[-1]
print("snapshot step", latest.step, "survivors", latest.survivors)
model.clear_pre_discard_snapshots()
model.disable_pre_discard()
```

Telemetry now tracks both survivor/discard counts and their energy share,
so you can monitor whether the discard policy is merely trimming duplicates or
aggressively stripping away signal. Snapshot entries expose the raw
`survivor_energy_ratio`, `discarded_energy`, and even the dominant pre-discard
weight so plugins can adapt thresholds dynamically.

[See example](examples/05_new_layers/zspace_coherence_demo.py)

### Plugin Architecture

`ZSpaceCoherenceSequencer` now exposes a lightweight plugin system so other
subsystems can tap into each stage of the pipeline without forking the core
implementation. Plugins are notified when tensors move through projection,
coherence measurement, geometric aggregation, semantic window derivation,
canonical concept selection, Maxwell desire emission, distribution fusion, and
language bridging. They also receive callbacks when backends or linguistic
profiles change, when contours/reports are emitted, and when PSI telemetry is
published (with the `psi` feature).

Key stages:

- `Projected`, `CoherenceMeasured`, `PreDiscardApplied` *(with survivor + discard indices)*, `Aggregated`
- `SemanticWindowDerived`, `SemanticDistributionDerived`, `CanonicalConceptSelected`
- `MaxwellBridgeEmitted`, `SemanticWindowFused`, `LanguageBridged`
- `BackendConfigured`, `LinguisticProfileRegistered`, `LinguisticProfilesCleared`
- `LinguisticContourEmitted`, `ChannelsDescribed`
- `PsiTelemetryPublished` *(when compiled with `psi`)*

Implement the `ZSpaceSequencerPlugin` trait and register it on a sequencer to
receive callbacks:

```rust
use st_nn::{
    zspace_coherence::{
        CoherenceBackend, ZSpaceCoherenceSequencer, ZSpaceSequencerPlugin, ZSpaceSequencerStage,
    },
    OpenCartesianTopos, PureResult, Tensor,
};

struct TelemetryPlugin;

impl ZSpaceSequencerPlugin for TelemetryPlugin {
    fn name(&self) -> &'static str { "telemetry" }

    fn on_stage(&self, stage: ZSpaceSequencerStage<'_>) -> PureResult<()> {
        match stage {
            ZSpaceSequencerStage::Aggregated { diagnostics, .. } => {
                println!("entropy: {:.2}", diagnostics.coherence_entropy());
            }
            ZSpaceSequencerStage::SemanticWindowDerived { window, .. } => {
                println!("window tokens: {}", window.len());
            }
            ZSpaceSequencerStage::BackendConfigured { backend } => {
                println!("backend -> {}", backend.label());
            }
            _ => {}
        }
        Ok(())
    }
}

fn main() -> PureResult<()> {
    let topos = OpenCartesianTopos::new(-1.0, 1e-5, 10.0, 256, 8192)?;
    let mut sequencer = ZSpaceCoherenceSequencer::new(768, 12, -1.0, topos)?;
    sequencer.register_plugin(TelemetryPlugin);
    sequencer.set_backend(CoherenceBackend::Fftw)?;
    let (_out, _, _) = sequencer.forward_with_diagnostics(&Tensor::zeros(1, 768)?);
    Ok(())
}
```

### Why Not Attention?

| Aspect | Attention | ZSpaceCoherence |
|--------|-----------|-----------------|
| Token weighting | Q·K^T softmax | Maxwell pulses |
| Geometry | Euclidean (dot product) | Hyperbolic (geodesic) |
| Semantic bias | External (RLHF/DPO) | Intrinsic (Desire Lagrangian) |
| Operators | Softmax | Fractional calculus |
| Hierarchy | Implicit | Explicit (curvature) |

**Features**
- Dataset abstraction and serialization
- Multi-epoch validation, best-state restore, and deterministic epoch reshuffling
- Hypergrad integration for every parameter
- Optional Realgrad accumulation via `ModuleTrainer::with_realgrad`
- WGPU · MPS · CUDA unified backends
```rust
use st_core::backend::device_caps::DeviceCaps;
use st_nn::{
    Linear, MeanSquaredError, ModuleTrainer, Relu, RoundtableConfig, Sequential, Tensor,
};

let mut model = Sequential::new();
model.push(Linear::new("encoder", 4, 3)?);
model.push(Relu::new());
model.push(Linear::new("head", 3, 2)?);

let mut trainer = ModuleTrainer::new(DeviceCaps::wgpu(32, true, 256), -1.0, 0.05, 0.01);
trainer.prepare(&mut model)?;

let schedule = trainer.roundtable(1, 2, RoundtableConfig::default());
let mut loss = MeanSquaredError::new();
let dataset = vec![
    (
        Tensor::from_vec(1, 4, vec![0.1, -0.2, 0.3, -0.4])?,
        Tensor::from_vec(1, 2, vec![0.0, 1.0])?,
    ),
    (
        Tensor::from_vec(1, 4, vec![0.2, 0.1, -0.3, 0.5])?,
        Tensor::from_vec(1, 2, vec![1.0, 0.0])?,
    ),
];

let stats = trainer.train_epoch(&mut model, &mut loss, dataset, &schedule)?;
println!("roundtable avg loss: {:.6}", stats.average_loss);
```

**BlackCat runtime tap-in**

The derivative-free ZMeta ES and contextual bandits can ride alongside the
roundtable loop. ZMeta now runs a guarded ask/tell `(1+1)` contract: the first
credited selection establishes a baseline, each later candidate applies a
temperature-scaled, bounded latent deformation to the actual bandit context,
and only that selection's observed free-energy utility may accept the candidate.
Retry, gradient-norm, and loss-variance telemetry controls the next proposal
radius rather than a disconnected diagnostic. Observation-only reports and
explicitly abandoned selections do not reward-train the ES. The
selection and update traces retain the base/effective contexts, evaluated Z,
reward comparison, acceptance decision, and fractional penalty.

Black Cat contextual-bandit witness contract v3 separates selection attempts
from credited observations, records forced exploration and quarantine state,
and transports Thompson's `u64` RNG seed as decimal text so WASM clients retain
its exact value.

Attach the runtime once and it will ingest per-step metrics, evaluate the
canonical Rust variational free-energy report, log Above/Here/Beneath energy,
estimate the BlackCat drift band, and accumulate both successful and unsuccessful
step rewards for each canonical `RankPlan.choice` script. The default adoption
epoch requires at least eight observations and promotes a rule only when the
95% Wilson lower bound clears the configured baseline. The interval, threshold,
decision, and typed persistence result are retained in
`SoftHeuristicAdoptionReport`; a store error is reported without pretending that
the rule was adopted, and a later observation retries the write. Observations
continue to update the Wilson witness after adoption without rewriting the rule;
automatic retraction is a separate policy. Persisted rules use a stable SHA-256
identity and an atomically synced append-once snapshot.
ZMeta's fractional penalty
reuses the same periodic Sobolev evaluator as `runtime::zspace_optimizer`, so a
CPU/WGPU route request cannot change the mathematical objective. Invalid reward,
adaptation, or context inputs are rejected before ES, bandit, statistics, or
telemetry state changes. Reward shaping is configurable before learning starts
and then locked, preventing one runtime from mixing ZMeta incumbents, bandit
posteriors, or statistics learned under different utility functions. When you call
`install_blackcat_moderator` a dedicated runtime is spun up for the moderator
so the training loop and the distributed consensus stay decoupled.

```rust
use std::collections::HashMap;
use st_core::backend::device_caps::DeviceCaps;
use st_core::runtime::blackcat::{bandit::SoftBanditMode, ChoiceGroups, BlackCatRuntime};
use st_core::runtime::blackcat::zmeta::ZMetaParams;
use st_nn::{Linear, MeanSquaredError, ModuleTrainer, RoundtableConfig, Sequential, Tensor};

let mut trainer = ModuleTrainer::new(DeviceCaps::wgpu(32, true, 256), -1.0, 0.05, 0.01)
    .with_blackcat(BlackCatRuntime::new(
        ZMetaParams::default(),
        ChoiceGroups {
            groups: HashMap::from([
                ("tile".to_string(), vec!["128".into(), "256".into(), "512".into()]),
                ("merge".to_string(), vec!["bitonic".into(), "shared".into(), "warp".into()]),
            ]),
        },
        8,
        SoftBanditMode::TS,
        None,
    ));

let mut model = Sequential::new();
model.push(Linear::new("encoder", 4, 4)?);
let schedule = trainer.roundtable(1, 4, RoundtableConfig::default());
let mut mse = MeanSquaredError::new();
let dataset = vec![
    (
        Tensor::from_vec(1, 4, vec![0.4, -0.2, 0.1, 0.0])?,
        Tensor::from_vec(1, 4, vec![0.1, 0.2, 0.3, 0.4])?,
    ),
];
trainer.prepare(&mut model)?;
let _ = trainer.train_epoch(&mut model, &mut mse, dataset, &schedule)?;
let report = trainer
    .blackcat_free_energy_report()
    .expect("BlackCat committed a guarded free-energy report");
println!("F={} p_accept={}", report.free_energy, report.acceptance_probability);
let evidence = trainer
    .blackcat_heuristic_adoption_report()
    .expect("BlackCat retained the cumulative heuristic evidence");
println!(
    "rule={} wins={}/{} lower={} decision={:?}",
    evidence.rule_id,
    evidence.interval.successes,
    evidence.interval.trials,
    evidence.interval.lower,
    evidence.decision,
);
```

**Rust (Z-space gating + projector)**
```rust
use st_core::backend::device_caps::DeviceCaps;
use st_nn::{
    ModuleTrainer, RoundtableConfig, Tensor, ToposResonator, ToposResonatorConfig,
    WaveGate, ZSpaceProjector,
};
use st_tensor::{topos::OpenCartesianTopos, LanguageWaveEncoder};

let encoder = LanguageWaveEncoder::new(-0.9, 0.7)?;
let topos = OpenCartesianTopos::new(-0.9, 1e-6, 1e4, 512, 16_384)?;
let projector = ZSpaceProjector::new(topos.clone(), encoder.clone())?;
let text = projector.encode_text("SpiralTorch keeps the open topos alive")?;

let mut gate = WaveGate::with_topos("gate", text.shape().1, encoder, topos.clone())?;
let mut trainer = ModuleTrainer::new(DeviceCaps::wgpu(32, true, 256), -0.9, 0.05, 0.01);
trainer.prepare_with_topos(&mut gate, topos.clone())?;

let forward = gate.forward(&text)?;
let grad = forward.hadamard(&text)?.scale(1.0 / forward.shape().0 as f32)?;
let _ = gate.backward(&text, &grad)?;
trainer.step(&mut gate)?;

let (rows, cols) = forward.shape();
let resonance = ToposResonatorConfig::new(0.25, 4)?;
let mut resonator = ToposResonator::with_config_and_topos(
    "res",
    rows,
    cols,
    resonance,
    topos.clone(),
)?;
// The same topos now guards both the finite Picard response and its hypergradient.
resonator.attach_open_topos(-0.9, 0.02, topos)?;
let activated = resonator.forward(&forward)?;
println!("resonance audit: {:?}", resonator.latest_audit());
let (act_rows, act_cols) = activated.shape();
let schedule = trainer.roundtable(act_rows as u32, act_cols as u32, RoundtableConfig::default());
let bands = schedule.split(&activated)?;
let _ = bands.combine()?; // band-aware recomposition stays lossless
let energy = schedule.band_energy(&activated)?;
println!("above energy {:.3}, here {:.3}, beneath {:.3}", energy.above, energy.here, energy.beneath);
```

`DeviceCaps` now ships backend-specific constructors (`wgpu`, `cuda`, `hip`, `cpu`) and
builder-style setters (`with_subgroup`, `with_max_workgroup`, `with_shared_mem`) so you
can describe GPUs with realistic limits while still feeding the unified heuristic chooser
a compact struct. Extra helpers (`align_workgroup`, `preferred_tile`, `occupancy_score`)
let downstream tooling snap requested launches to warp-friendly shapes, reason about
effective occupancy, and auto-derive sweep/compaction tiles from the device limits.

**Python**
```python
import spiraltorch as st

plan = st.plan_topk(rows=8, cols=65_536, k=1_024, backend="auto")
print("choice:", plan.merge_strategy, plan.tile, plan.workgroup, "lanes", plan.lanes)
```

---

## Pure Rust training (zero PyTorch/Numpy deps)

Need a bootstrap-friendly learning loop without heavyweight dependencies?
`st-nn` layers sit directly on top of the `st-tensor::pure` stack so you can
train, schedule, and log every A/B/C decision entirely in Rust.

For direct Rust use, `st-tensor`'s `wgpu_dense` feature owns the dense Tensor
GPU APIs and dispatch; `wgpu` is a compatibility alias, not an additional
requirement. Defaults include the dense provider, while `wgpu_frac` alone does
not claim dense execution. See [Tensor backend features](docs/development/tensor_backend_features.md)
for the isolated build matrix and runtime checks.

Geometry-aware policy loops now broadcast their feedback as loopback envelopes,
so reinforcement learners automatically feed their learning-rate modulation
into the global telemetry hub for other SpiralTorch nodes to replay.

```rust
use st_core::backend::device_caps::DeviceCaps;
use st_nn::{
    HyperbolicCrossEntropy, Linear, MeanSquaredError, ModuleTrainer, Relu,
    RoundtableConfig, Sequential, Tensor,
};

fn main() -> st_nn::PureResult<()> {
    let mut model = Sequential::new();
    model.push(Linear::new("encoder", 3, 4)?);
    model.push(Relu::new());
    model.push(Linear::new("head", 4, 2)?);

    let mut trainer = ModuleTrainer::new(DeviceCaps::wgpu(32, true, 256), -0.95, 0.05, 0.01);
    trainer.prepare(&mut model)?;

    // Build a roundtable that splits gradients into Above/Here/Beneath bands.
    let schedule = trainer.roundtable(1, 2, RoundtableConfig::default());

    let dataset = vec![
        (
            Tensor::from_vec(1, 3, vec![0.3, -0.7, 0.1])?,
            Tensor::from_vec(1, 2, vec![1.0, 0.0])?,
        ),
        (
            Tensor::from_vec(1, 3, vec![-0.1, 0.4, -0.6])?,
            Tensor::from_vec(1, 2, vec![0.0, 1.0])?,
        ),
    ];

    let mut mse = MeanSquaredError::new();
    let epoch = trainer.train_epoch(&mut model, &mut mse, dataset.clone(), &schedule)?;
    println!("epoch loss: {:.6}", epoch.average_loss);

    // Inspect the logits with a hyperbolic cross-entropy probe.
    let mut hce = HyperbolicCrossEntropy::new(-0.95)?;
    let logits = model.forward(&dataset[0].0)?;
    let ce = hce.forward(&logits, &dataset[0].1)?;
    println!("hyperbolic CE: {:.6}", ce.data()[0]);

    Ok(())
}
```

Above/Beneath/Here gradients map directly onto TopK/MidK/BottomK roundtable
plans, so every update records which parts of the spectrum drove the change.
Hyperbolic losses run on the same tensors, meaning you can bounce between Z-space
encoders, Euclidean projections, and browser-friendly WASM canvases without
importing PyTorch or NumPy.

### Fractal uring scheduler + WASM canvas loop

Feed those spectra directly into an async-friendly fractal loop without ever
allocating more than a small ring buffer. The `UringFractalScheduler` keeps the
latest relation patches in a Tokio-uring style queue, blends them by coherence,
and hands the result straight to your browser front-end.

```rust
use st_tensor::{Tensor, PureResult};
use st_tensor::fractal::{FractalPatch, UringFractalScheduler};

async fn stream_waveforms(samples: Vec<Tensor>) -> PureResult<Tensor> {
    let scheduler = UringFractalScheduler::new(32)?;
    for (depth, relation) in samples.into_iter().enumerate() {
        let patch = FractalPatch::new(relation, 0.9, 0.7, depth as u32)?;
        // Works on any executor; tokio-uring, tokio, or synchronous loops.
        scheduler.push_async(patch).await?;
    }
    scheduler.fold_coherence()
}
```

For browser builds, wire the folded relation into a WebAssembly export that
paints onto `<canvas>` without tokenising text or duplicating buffers:

```rust
use st_tensor::fractal::UringFractalScheduler;
use wasm_bindgen::prelude::*;
use wasm_bindgen::{JsCast, JsValue};
use web_sys::{CanvasRenderingContext2d, HtmlCanvasElement};

#[wasm_bindgen]
pub struct FractalCanvas {
    scheduler: UringFractalScheduler,
}

#[wasm_bindgen]
impl FractalCanvas {
    #[wasm_bindgen(constructor)]
    pub fn new(capacity: usize) -> Result<FractalCanvas, JsValue> {
        let scheduler = UringFractalScheduler::new(capacity)
            .map_err(|err| JsValue::from_str(&err.to_string()))?;
        Ok(Self { scheduler })
    }

    pub fn render(&self, canvas: HtmlCanvasElement) -> Result<(), JsValue> {
        let ctx: CanvasRenderingContext2d = canvas
            .get_context("2d")?
            .ok_or("missing 2d context")?
            .dyn_into()?;
        let frame = self
            .scheduler
            .fold_coherence()
            .map_err(|err| JsValue::from_str(&err.to_string()))?;
        let spectrum = frame.data();
        for (x, value) in spectrum.iter().enumerate() {
            let intensity = (value.clamp(0.0, 1.0) * 255.0) as u8;
            ctx.set_fill_style(&format!("rgb({0},{0},{0})", intensity).into());
            ctx.fill_rect(x as f64, 0.0, 1.0, canvas.height() as f64);
        }
        Ok(())
    }
}
```

And keep the JavaScript glue feather-light:

```html
<canvas id="zspace" width="512" height="32"></canvas>
<script type="module">
import init, { FractalCanvas } from "./pkg/spiraltorch_wasm.js";
const wasm = await init();
const canvas = document.getElementById("zspace");
const fractal = new FractalCanvas(64);
await fractal.render(canvas);
const spectrum = fractal.vectorFieldFft(false);
console.log(`fft bins=${spectrum.length / 8}`);
const kernel = fractal.vectorFieldFftKernel(true);
console.log(kernel.split("\n")[0]);
const uniform = fractal.vectorFieldFftUniform(false);
console.log(`fft uniform=${uniform.join(',')}`);
const layout = fractal.vectorFieldFftLayout();
console.log(`fft field bytes=${layout.fieldBytes} stride=${layout.fieldStride}`);
const dispatch = fractal.vectorFieldFftDispatch(true);
console.log(`fft dispatch=${dispatch.join('x')}`);
</script>
```

Pixels become Z-space relations, the scheduler keeps memory bounded, and the
entire loop stays panic-free even under aggressive streaming.

The returned spectrum stores `[energy_re, energy_im, chroma_r_re, chroma_r_im,
chroma_g_re, chroma_g_im, chroma_b_re, chroma_b_im]` per bin, so Canvas
Transformers can slice the energy or chroma lanes directly or feed the full
tensor back through `fft_inverse_in_place` for quick spatial reconstruction.

When dispatching the WGSL kernel, bind the colour field as a tightly-packed
array of `FieldSample { energy, chroma }`, store the complex spectrum in a
matching `SpectrumSample` buffer, and provide the canvas dimensions plus an
inverse flag through a `CanvasFftParams` uniform struct. The
`vectorFieldFftUniform` helper yields the `[width, height, inverse, padding]`
`Uint32Array` so you can upload the uniform buffer directly without worrying
about alignment, `vectorFieldFftLayout` reports the byte lengths and strides for
the field/spectrum storage buffers, and `vectorFieldFftDispatch` returns the
`[x, y, z]` workgroup counts that correspond to the generated WGSL (respecting
subgroup or full wave execution).

Need FFT heuristics alongside the canvas?  WebAssembly exports now ship auto
planning helpers and CPU fallbacks:

```javascript
import init, { auto_plan_fft, fft_forward } from "./pkg/spiraltorch_wasm.js";

await init();
const plan = auto_plan_fft(512, 4096, 128, true);
if (plan) {
  console.log(`radix=${plan.radix} tile=${plan.tileCols}`);
  const wgsl = plan.wgsl();
  const spiralk = plan.spiralkHint();
}

// Run a radix-2/4 FFT on interleaved re/im data
const freqDomain = fft_forward(timeDomainBuffer);
```

If you maintain a `WasmTuner`, call `planFft` to reuse your override table and
capture WGSL/SpiralK artifacts without leaving the browser.  The bindings now
understand plain JavaScript objects in addition to JSON strings, so you can
hydrate a tuner from baked data and persist live edits without extra parsing:

```javascript
const records = [{ rows: 256, cols_min: 0, cols_max: 4095, k_max: 128, sg: true, wg: 128 }];
const tuner = WasmTuner.fromObject(records);
tuner.mergeObject([
  { rows: 512, cols_min: 4096, cols_max: 16383, k_max: 256, sg: true, tile_cols: 1024 },
]);
const overrides = tuner.toObject();
// Extract overrides and resolved plans as JSON or plain JS objects without
// constructing intermediate WasmFftPlan instances by hand.
const fallbackPlan = tuner.planFftWithFallback(512, 4096, 128, true);
const fallbackJson = tuner.planFftWithFallbackJson(512, 4096, 128, true);
const fallbackObject = tuner.planFftWithFallbackObject(512, 4096, 128, true);
const resolution = tuner.planFftResolution(512, 4096, 128, true);
const resolutionJson = tuner.planFftResolutionJson(512, 4096, 128, true);
const resolutionObject = tuner.planFftResolutionObject(512, 4096, 128, true);
if (resolution.source === WasmFftPlanSource.Override) {
  console.log(`override tile=${resolution.plan.tileCols}`);
}
const snapshot = resolution.toJson();
const hydrated = ResolvedWasmFftPlan.fromJson(snapshot);
const report = tuner.planFftReport(512, 4096, 128, true);
const overrideJson = tuner.planFftJson(512, 4096, 128, true);
const overrideObject = tuner.planFftObject(512, 4096, 128, true);
```

---

## Heuristics (SpiralK) — optional & powerful

SpiralK is a tiny runtime DSL for device-aware choices. Flip it on, then shape the policy per device.

```bash
export SPIRAL_HEUR_SOFT=1
export SPIRAL_HEUR_K=' 
  # mk: 0=bitonic, 1=shared, 2=warp (subgroup path on WGPU)
  mk:   sel(sg && (k<=128), 2, sel(k<=2048, 1, 0));
  # mkd: sub-strategy (auto/heap/kway/bitonic/warp_heap/warp_bitonic)
  mkd:  sel(mk==2,4, sel(mk==1,1,3));
  # TopK sweeping tile
  tile: sel(log2(c)>15.0, 2048,
        sel(log2(c)>13.0, 1024,
        sel(log2(c)>12.0,  512, 256)));
  # Mid/Bottom compaction tile
  ctile: sel(tile>=1024, tile/2, tile);

  # Soft hints (gently bias the solver)
  soft(mk,   2, 0.25, sg && (k<=128));
  soft(mk,   1, 0.20, (k>128)&&(k<=2048));
  soft(tile, 2048, 0.20, log2(c)>15.0);
  soft(tile, 1024, 0.15, (log2(c)>13.0)&&(log2(c)<=15.0));
'
```

Need LLM-assisted rewrites without leaving Rust? Build an
`AiRewritePrompt`/`AiRewriteConfig` pair and call `rewrite_with_ai(...)` to let
the Grok-style template generator emit `soft(...)` rules based on Wilson metrics
and device guards. Python bindings expose the same surface via
`spiraltorch.spiralk.rewrite_with_ai`, returning both the rewritten program and
the generated `SpiralKHeuristicHint` objects so you can audit or persist the
AI-authored tweaks before baking them into tuner tables.

Prefer to bring your own LLM or heuristic engine? Pass a `generator=` callable
to `spiraltorch.spiralk.rewrite_with_ai` and SpiralTorch will hand your function
fresh `SpiralKAiRewriteConfig`/`SpiralKAiRewritePrompt` clones. Return a list of
`SpiralKHeuristicHint` objects to drive the rewrite pipeline while preserving
the same safety checks (`max_hints`, Wilson guards, DSL parsing) enforced by the
Rust core.

**How the final choice is made (three-way roundtable)**

- **A** = SoftLogic best (your DSL soft + optional Redis soft)
- **B** = DSL **hard** assignment (if you set `mk:`/`tile:` explicitly, B wins)
- **C** = **Generated table** (tuner output)

Default policy: if **B** exists use it; otherwise the runtime invites **A** and **C** into a quick conversation. It scores both with backend-aware occupancy/tile metrics derived from `DeviceCaps`, then adds a gentle prior to **C** (`SPIRAL_HEUR_GEN_WEIGHT`, default `0.10`). When the discussion reaches a Wilson-backed agreement, **Self-Rewrite** appends the matching `soft(...)` into `~/.spiraltorch/heur.kdsl` so the next run starts from the shared insight.

Want to materialise the FFT path straight from the chosen plan? Call the new helpers and feed the result to your browser/WASM runtime:

```rust
use st_core::backend::wgpu_heuristics::{auto_fft_plan, auto_fft_spiralk};

let plan = auto_fft_plan(rows, cols, k, subgroup).expect("heuristics available");
let wgsl = plan.emit_wgsl();
let dispatches = plan.dispatches();
let spiralk = auto_fft_spiralk(rows, cols, k, subgroup).unwrap();
// Bind primary + scratch buffers, then issue `dispatches` in order with the
// listed entry point/radix/span. Persist `spiralk` if the DSL should learn it.
```

Prefer to cache the tuned plan for JavaScript without re-running the heuristics? The WASM bindings now serialise plans as JSON or plain JS objects:

```ts
import { auto_fft_plan_json, WasmFftPlan } from "spiraltorch_wasm";

const planJson = await auto_fft_plan_json(rows, cols, k, true);
if (planJson) {
  const plan = WasmFftPlan.fromJson(planJson);
  await persistPlan(plan.toJson());
  const wgsl = plan.wgsl();
  const manifest = plan.dispatchManifestObject();
  // Dispatch `manifest.dispatches` in order and ping-pong the listed buffers.
}
```

---

## Regenerating the WASM table (optional)

Run the offline baker to convert your latest measurements into a `WasmTunerTable`
that both native and browser builds can consume:
```bash
python3 tools/tuner/gen_generated_rs.py tools/tuner/tuner_results.json \
  > crates/st-core/src/backend/wgpu_heuristics_generated.rs
```

The generated module keeps the JSON embedded verbatim, parses it via
`st-core::backend::wasm_tuner`, and exposes a `choose(...)` helper that the
runtime queries after SpiralK/SoftLogic have spoken. Because the JSON format is
portable, you can ship the same file to a WebWorker, bake a table offline, and
let the browser pick overrides without re-running the tuner in production.

### Fractional FFT / SpiralK execution path

- **Validated radix-2 / radix-4 pipeline**: `SpiralKFftPlan` rejects ambiguous
  shapes, emits bit-reversal plus mathematically checked butterfly stages, and
  publishes the same ordered dispatch manifest to Rust, Python, and WASM.
- **Wilson-aware automation**: `st-kdsl::auto` turns latency deltas into
  high-confidence `soft(...)` rewrites, wiring tuned `radix`, `tile_cols`, and
  `segments` into `heur.kdsl` without manual editing.
- **ND GPU indexer**: A dedicated WGSL kernel materialises strided indices and
  per-segment IDs, unlocking fast fractional/FFT dispatches from WASM → Canvas.
- **WASM tuner baking**: `tools/tuner/tuner_results.json` keeps the measured
  overrides (`tile_cols`, `radix`, `segments`, `mode_*`) in one place so the
  generator can bake them into Rust **and** expose them to the Web via JSON.

**Example JSON**
```json
[
  {"rows": 256,  "cols_min": 0,     "cols_max": 4095,   "k_max": 128,  "sg": true,
   "wg": 128,    "tile": 512,  "tile_cols": 512,  "radix": 2, "segments": 1},
  {"rows": 512,  "cols_min": 4096,  "cols_max": 16383,  "k_max": 256,  "sg": true,
   "wg": 256,    "tile": 1024, "tile_cols": 1024, "radix": 4, "segments": 2},
  {"rows": 512,  "cols_min": 16384, "cols_max": 65535,  "k_max": 2048, "sg": false,
   "wg": 128,    "tile": 2048, "tile_cols": 2048, "radix": 4, "segments": 4, "use_2ce": true},
  {"rows": 1024, "cols_min": 65536, "cols_max": 262143, "k_max": 4096, "sg": false,
   "wg": 128,    "tile": 4096, "tile_cols": 4096, "radix": 4, "segments": 4, "use_2ce": true,
   "mode_bottomk": 2}
]
```

The generator bakes FFT-oriented hints (`tile_cols`, `radix`, `segments`) and
the ND compaction settings into the Rust table, while the same JSON remains
available for WASM workers that want to replay the optimisation flow offline.

---

## Amega Hypergrad (unrolled / implicit)

Rust utilities for hyper-parameter gradients (continuous relaxation):
- **Unrolled**: expand T updates and backprop
- **Implicit**: Neumann or **CG** to solve `(I − J) v ≈ g` efficiently

> See `crates/st-core/src/autograd/hypergrad*.rs`.
> Python glue is kept minimal; wheels can expose helpers.

The pure `st-tensor::pure::AmegaHypergrad` tape mirrors the same mindset in a
dependency-free package, letting you stage language diffusion experiments in
Rust and then feed the resulting curvature-aligned hints back into SpiralK.

---

## Safety & fallbacks

- CPU remains **always available**, and Python wheels can drop the default WGPU
  route with `--no-default-features --features python-default,cpu`.
- WGPU / CUDA / HIP are **feature-gated** and degrade safely.
- Heuristic chooser always returns a **safe** `Choice` (fills mk/tile from table or conservative defaults).

---

## Contributing

See `CONTRIBUTING.md` for local setup, testing, and wheel build commands (Windows: `scripts/dev.ps1`).

Issues & PRs welcome, especially:
- Backend kernels (WGPU subgroup variants, HIP/CUDA heap/k-way merges)
- Tuner recipes & generated tables
- New SpiralK sugar (e.g., `penalty_if(...)`, device-aware bands)

Run tests/benches on your device and share logs (latency / shapes / adapter caps).  
**AGPL-3.0-or-later** keeps it open and remix-able.

---

## Social preview

Upload a social preview PNG via **Repo → Settings → Social preview** (1200×630).  
Suggested caption: **“SpiralTorch — WGPU-first, Self-Tuning GPU Top-K (Rank-K)”**.

---

### Troubleshooting

- **No Redis?**  
  Build without `kv-redis` or leave `REDIS_URL` unset. The consensus chooser
  skips network calls and falls back to SpiralK / Generated-table safely.

- **ROCm not installed but `hip` enabled?**  
  Use `--features hip` only (stub path). The **real** path needs `hip-real`
  and a working ROCm + RCCL toolchain.

- **Wheels red?**  
  First try the release-equivalent wheel build: `maturin build -m bindings/st-py/Cargo.toml --release --locked --features logic,kdsl`.
  If you suspect the default WGPU route, build CPU-only instead: `maturin build -m bindings/st-py/Cargo.toml --release --locked --no-default-features --features python-default,cpu`.

---

## License

**AGPL-3.0-or-later** for every crate and Python wheel. See [`LICENSE .txt`](LICENSE%20.txt).
Unauthorized derivations will be treated as non-compliant with AGPL §13
