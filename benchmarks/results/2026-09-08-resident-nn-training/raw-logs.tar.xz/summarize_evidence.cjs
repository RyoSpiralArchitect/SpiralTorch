const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const [base, output] = process.argv.slice(2);
const commit = '2321c6fd518dcedbc228b8323e4de0ccb5f0f90c';
const tree = 'c20ba4913e450a147619d3a2cfc425976c6c8d4a';
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const read = name => JSON.parse(fs.readFileSync(path.join(base, name), 'utf8'));
const native = read('native-training-final.json');
const browser = read('browser-training-final.json');
const browserInference = read('browser-inference-final.json');
const torch = read('torch-training-final.json');
const inference = read('inference-vs-torch-final.json');
for (const r of [native, browser, browserInference]) {
  if (r.status !== 'passed' || r.build_manifest.git.commit !== commit ||
      r.build_manifest.git.tree !== tree || r.build_manifest.git.dirty !== false)
    throw Error('fixture source binding failed');
}
if (torch.status !== 'passed' || inference.status !== 'passed' ||
    !inference.build_source_binding.valid || inference.source.commit !== commit ||
    inference.source.tree !== tree || inference.source.tracked_dirty)
  throw Error('comparison source binding failed');
for (const source of torch.sources) {
  if (hash(path.join(base, path.basename(source.path))) !== source.sha256)
    throw Error('PyTorch replay input hash differs');
}
const training = r => ({
  adapter: r.adapter, vjp_cases: r.vjps.cases.length,
  max_vjp_abs_error: Math.max(...r.vjps.cases.map(x => x.max_abs_error)),
  guards: r.guards, learning: r.learning.runs.map(x => ({seed: x.seed, steps: x.steps,
    shape: x.shape, initial_mse: x.initial.loss, final_mse: x.final.loss,
    loss_reduction_percent: 100 * (1 - x.final.loss / x.initial.loss),
    max_abs_error: x.max_abs_error, exported_inference: x.exported_inference})),
  batch_duplication_factors: r.learning.batch_duplication_factors
});
const cases = inference.cases.map(c => ({shape: c.shape, depth: c.depth, seed: c.seed,
  legacy_ms: c.legacy_mean_ms, resident_ms: c.resident_mean_ms, torch_ms: c.torch_mean_ms,
  speedup_over_legacy: 1 / c.resident_over_legacy, resident_over_torch: c.resident_over_torch}));
const deepSpeedups = cases.filter(c => c.depth === 16).map(c => c.speedup_over_legacy);
const summary = {
  schema: 'spiraltorch.resident_training.study.v1', status: 'passed', commit, tree,
  date: '2026-09-08', native: training(native), browser: training(browser),
  browser_runtime: {version: browser.browser_version, adapter_probe: browser.browser_adapter_probe,
    wasm_sha256: browser.wasm_sha256, page_errors: browser.page_errors, console_messages: browser.console_messages},
  torch: {version: torch.torch, devices: torch.devices, results: torch.sources.map(s => ({
    source_file: path.basename(s.path), source_sha256: s.sha256, devices: s.devices.map(d => ({
      device: d.device, vjp_cases: d.vjps.length, learning_cases: d.learning.length,
      compared_states: [...d.vjps, ...d.learning].reduce((n, c) => n + Object.keys(c.states).length, 0),
      max_abs_error: Math.max(...[...d.vjps, ...d.learning].flatMap(c => Object.values(c.states).flatMap(s => Object.values(s.max_abs_errors))))
    }))})), boundary: torch.boundary},
  inference: {cases, device_admission: inference.device_admission, boundary: inference.boundary,
    semantics: inference.semantics, slower_than_torch: cases.filter(c => c.resident_over_torch > 1).length,
    deep_speedup_over_legacy_range: [Math.min(...deepSpeedups), Math.max(...deepSpeedups)]},
  browser_inference: {cases: browserInference.cases.length, overflow_cases: browserInference.intermediate_guard_cases},
  artifacts: Object.fromEntries(['native-training-final.json', 'browser-training-final.json',
    'torch-training-final.json', 'browser-inference-final.json', 'inference-vs-torch-final.json',
    'resident-training-2321c6fd', 'resident-mlp-2321c6fd'].map(name => [name, hash(path.join(base, name))])),
  boundaries: [
    'Synthetic finite fixture correctness; no language-model quality or training-throughput claim.',
    'Native Metal and real Chrome WebGPU run the same Rust graph and shaders; browser adapter probe is separate, not identity attestation.',
    'Three seeds, not independent evidence from counting duplicate control replays as new seeds.',
    'Inference is one diagnostic run with 12 samples per case, not a matched pre-change performance comparison; macOS GPU contention unknown.',
    'Rust/native and WASM Rust training core only; public Python/JS training clients and CUDA remain out of scope.',
    'Submitted attempt counters are not committed-step counters; per-attempt failures must be captured to retain their individual receipt.',
    'Binary hashes refer to locally retained immutable build products; binaries are not in the raw-log archive.'
  ]
};
fs.writeFileSync(output, JSON.stringify(summary, null, 2) + '\n', {flag:'wx'});
console.log(JSON.stringify({status: summary.status, commit, inference_cases: cases.length,
  slow_vs_torch: summary.inference.slower_than_torch, deep_speedup: summary.inference.deep_speedup_over_legacy_range}));
