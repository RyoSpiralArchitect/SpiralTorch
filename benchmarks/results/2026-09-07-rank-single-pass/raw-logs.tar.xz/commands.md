# Single-pass rank and timestamp replay

Baseline: ed21f2000d49b3add759b8a4b53fb3b46b4e60ee (executable code equals main 1934d709).
Candidate: 2c72e26b5af58da8138c603e8ceb42303bd11135. Initial prototype: c3e37c62.
Build only from clean source, then copy executables out of the shared target,
chmod 555, retain --build-info and hashes. Local Rust 1.98.0, Furnace private
Rust 1.98.1; formatter nightly-2026-04-15, wasm-bindgen 0.2.104.

No GPU processes overlapped, including across hosts. Browser comparisons had
no same-host build running. Local builds overlapped remote tests/benchmarks on
the other host, not remote CPU builds. Existing Furnace CPU llama-server was
left untouched. CUDA is the PyTorch reference, not a new SpiralTorch CUDA path.

## Build and test

```sh
cargo +nightly-2026-04-15 fmt --all -- --check
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 cargo test --locked -p st-backend-wgpu -- --test-threads=1
cargo clippy --locked -p st-backend-wgpu --all-targets -- -D warnings
cargo clippy --locked -p st-backend-wgpu --target wasm32-unknown-unknown --all-targets -- -D warnings
cargo clippy --locked -p st-core --all-targets --no-default-features --features cpu,wgpu-rt -- -D warnings
cargo check --locked --manifest-path bindings/st-py/Cargo.toml --no-default-features --features python-default,cpu
cargo build --locked --release -p st-core --features wgpu-rt,kdsl --example resident_rank_profile_bench --example resident_rank_adaptation_bench
cargo build --locked --release -p spiraltorch-wasm --target wasm32-unknown-unknown --features webgpu
wasm-bindgen --target web --out-dir WEB_CANDIDATE TARGET/wasm32-unknown-unknown/release/spiraltorch_wasm.wasm
maturin build --locked --release --manifest-path bindings/st-py/Cargo.toml --features wgpu-rt --interpreter PRIVATE_PYTHON --out WHEELS
PRIVATE_PYTHON -I -m pip install --force-reinstall --no-deps WHEEL
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 PRIVATE_PYTHON -I -m pytest --import-mode=importlib -q bindings/st-py/tests/test_wgpu_rank.py bindings/st-py/tests/test_wgpu_resident.py bindings/st-py/tests/test_spiralk_rank_tile.py bindings/st-py/tests/test_resident_rank_adaptation.py bindings/st-py/tests/test_wgpu_rank_reports.py bindings/st-py/tests/test_wgpu_rank_profile.py
```

## Measurements

Use the exact corresponding checkout for each native executable. The existing
harness binds the clean commit/tree, copies/links the immutable image, validates
canonical outputs and policy receipts, then runs PyTorch CUDA after native exit.
The order was baseline, candidate, candidate, baseline; each invocation retains
36 cases, three seeds, two policies and four fixed candidate controls.

```sh
python tools/bench_resident_rank_adaptation_vs_torch.py --executable COPIED_EXECUTABLE --output NEW_NATIVE_JSON
python -I run_profile_probe.py --repo CANDIDATE_REPO --executable COPIED_PROFILE_EXECUTABLE --output stage-probe-2c72e26b.json
node tools/test_resident_browser.cjs WEB_CANDIDATE CHROME NEW_PROFILE_JSON '' '' '' '' rank-profile
node tools/test_resident_browser.cjs WEB_CANDIDATE CHROME NEW_MATCHED_JSON '' '' '' '' rank-matched WEB_BASELINE
```

Browser uses a private Playwright installation and a fresh headless profile,
never personal browser state. Two matched runs plus one baseline/baseline run
are retained. These are one deterministic fixture repeated, not new seeds.
The browser exposes anonymous BrowserWebGpu, not physical adapter identity.

## Negative prototypes

The pre-c3e37c62 uncommitted profiler tried 1024 repetitions in separate passes
before one queue submission. Metal command-buffer allocation blocked during
encoding, before submission. metal-profile-hang.sample.txt retains the owned
test-process stack; only that process (PID 95153) was terminated. Its timed-out
test is not a performance observation. Normal rank now uses one compute pass;
instrumentation is chunked and labels native Metal host pacing explicitly.

c3e37c62 browser profiling exhausted counter-sample buffers after repeated
GPUQuerySet creation. Rust handle Drop deferred destruction to JavaScript GC.
Uncaptured errors allowed cleared query results to look like quantized zeros;
cached correct rank outputs did not detect that failure until the final fresh
1024-repetition workspace. The entire c3e37c62 browser run is invalid evidence.
2c72e26b explicitly destroys owned query resources after submission and captures
allocation/validation errors in synchronously popped error-scope futures.

## Recompute

```sh
python -I analyze.py --repo REPO_CONTAINING_THE_HARNESS --output NEW_SUMMARY_JSON
```

Products themselves are not in this compact archive. Native reports embed
source-bound build identity and executable hashes; browser reports hash all
served module/fixture assets. Python/WASM source attribution uses preserved
build logs plus product hashes, not an embedded Git attestation. Summary hashes
cover the raw reports, test/build logs, scripts and source bundles. The separate
matmul/copy/rank chain's maximum repetition boundary was not exercised here.
