"""Revalidate raw reports; keep diagnostic clocks separate from normal comparisons."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics as stats
import sys


def require(value, message):
    if not value:
        raise ValueError(message)


def span(values):
    return dict(min=min(values), median=stats.median(values), max=max(values))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    sys.path.insert(0, str(args.repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    import bench_resident_rank_adaptation_vs_torch as adaptation
    helpers = audit.load_bench_module()
    hashes = {}

    def read(name):
        raw = (root / name).read_bytes()
        hashes[name] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)

    native = []
    expected_requests = list(adaptation.requests(helpers))
    request_digest = hashlib.sha256("".join(json.dumps(r, allow_nan=False) + "\n" for r, _ in expected_requests).encode()).hexdigest()
    for name in ("rank-baseline-fresh.json", "rank-candidate-2c72e26b.json",
                 "rank-candidate-2c72e26b-2.json", "rank-baseline-fresh-2.json"):
        report = read(name)
        require(report["status"] == "passed" and report["provenance"]["valid"], "native validity")
        require(audit.validate_source_binding(report["native_build_identity"], report["source"])["valid"], "native source binding")
        require(report["request_sha256"] == request_digest, "native request hash")
        require(len(report["cases"]) == len(expected_requests) == 36, "native case count")
        for case, (request, tiles) in zip(report["cases"], expected_requests):
            require(case["request"] == {k: v for k, v in request.items() if k != "input"} and case["tiles"] == tiles, "native request identity")
            adaptation.validate_native(case["native"], request, tiles)
            require(case["native"]["adapter"]["name"] == report["torch_device"], "named adapter mismatch")
            values, indices = [], []
            for row in range(request["rows"]):
                data = request["input"][row * request["cols"]:(row + 1) * request["cols"]]
                ids = sorted(range(len(data)), key=lambda i: (-data[i] if request["kind"] == "topk" else data[i], i))
                start = (len(data) - request["k"]) // 2 if request["kind"] == "midk" else 0
                ids = ids[start:start + request["k"]]
                values.extend(data[i] for i in ids)
                indices.extend(ids)
            require(case["native"]["values"] == values and case["native"]["indices"] == indices, "canonical native output")
        native.append(report)

    comparisons = []
    for baseline, candidate in ((native[0], native[1]), (native[3], native[2])):
        cells = []
        for old, new in zip(baseline["cases"], candidate["cases"]):
            for tile, a, b in zip(new["tiles"], old["native"]["control_samples_per_op_ms"], new["native"]["control_samples_per_op_ms"]):
                cells.append(dict(kind=new["request"]["kind"], cols=new["request"]["cols"], k=new["request"]["k"],
                                  seed=new["request"]["seed"], policy=new["request"]["policy"], tile=tile,
                                  mean_ratio=stats.mean(b) / stats.mean(a)))
        comparisons.append(dict(fixed_candidate_over_baseline=span([c["mean_ratio"] for c in cells]),
                                cells=cells, best_fixed_over_torch=span([
                                    min(stats.median(v) for v in c["native"]["control_samples_per_op_ms"]) / c["torch_timing"]["median_ms"]
                                    for c in candidate["cases"]])))

    browsers = []
    for name in ("browser-matched-2c72e26b-1.json", "browser-matched-2c72e26b-2.json", "browser-matched-aa.json"):
        report = read(name)
        require(report["status"] == "passed" and not report["page_errors"] and len(report["cases"]) == 44, "browser matched validity")
        require(report["repetitions"] == 64 and report["warmup_batches"] == 4 and report["retained_batches"] == 16, "browser timing boundary")
        cells = []
        for index, case in enumerate(report["cases"]):
            require(case["status"] == "passed" and len(case["samples"]) == 16, "browser case validity")
            for batch, sample in enumerate(case["samples"]):
                require(sample["order"] == (["baseline", "candidate"] if (index + batch) % 2 == 0 else ["candidate", "baseline"]), "browser pairing")
                require(all(math.isfinite(sample[k]) and sample[k] > 0 for k in ("candidate_ms", "baseline_ms")), "browser finite timing")
            cells.append(dict(cols=case["cols"], k=case["k"], mean_ratio=stats.mean(s["candidate_ms"] for s in case["samples"]) / stats.mean(s["baseline_ms"] for s in case["samples"])))
        assets = report["asset_sha256"]
        if name.endswith("aa.json"):
            require(all(value == assets.get(url.replace("/module/", "/baseline/", 1)) for url, value in assets.items() if url.startswith("/module/")), "A/A asset identity")
        browsers.append(dict(file=name, mean_ratios=span([c["mean_ratio"] for c in cells]), cells=cells,
                             browser=report["browser_version"], asset_sha256=assets))

    stages = read("stage-probe-2c72e26b.json")
    require(stages["status"] == "passed" and stages["provenance_valid"] and len(stages["results"]) == 72, "stage validity")
    require(audit.validate_source_binding(stages["native_build_identity"], stages["source"])["valid"], "stage source binding")
    browser_profile = read("browser-profile-2c72e26b.json")
    require(browser_profile["status"] == "passed" and len(browser_profile["cases"]) == 12 and not browser_profile["page_errors"], "browser profile validity")
    require(not any(any(s in m["text"] for s in ("Invalid QuerySet", "Invalid CommandBuffer", "Cannot allocate sample buffer")) for m in browser_profile["console_messages"]), "uncaptured GPU error")
    require(browser_profile["maximum_repetitions"]["status"] == "passed", "browser max repetitions")
    all_profiles = [b["profiled"]["gpu"] for r in stages["results"] + browser_profile["cases"] for b in r["batches"]]
    all_profiles.append(browser_profile["maximum_repetitions"]["profile"])
    for gpu in all_profiles:
        require(gpu["schema"] == "spiraltorch.rank_gpu_profile.v1" and gpu["instrumented"], "profile schema")
        require(len(gpu["passes"]) == gpu["repetitions"] * 2, "profile pass count")
        require(gpu["timestamp_period_ns"] > 0 and math.isfinite(gpu["timestamp_period_ns"]), "query period")
        require(gpu["compute_submissions"] == math.ceil(gpu["repetitions"] / 256), "profile submissions")
        for index, p in enumerate(gpu["passes"]):
            require(p["stage"] == ("tile_sort" if index % 2 == 0 else "row_merge") and p["repetition"] == index // 2, "profile stage order")
            require(isinstance(p["start_tick"], str) and isinstance(p["end_tick"], str), "lossless raw ticks")
            require(p["elapsed_ns"] == (int(p["end_tick"]) - int(p["start_tick"])) * gpu["timestamp_period_ns"] and math.isfinite(p["elapsed_ns"]) and p["elapsed_ns"] >= 0, "profile integer delta")
        for stage, offset in (("tile_sort", 0), ("row_merge", 1)):
            require(gpu[stage + "_total_ns"] == sum(p["elapsed_ns"] for p in gpu["passes"][offset::2]), "profile total")
        require(gpu["zero_intervals"] == sum(p["elapsed_ns"] == 0 for p in gpu["passes"]), "zero intervals")

    stage_cells = []
    for kind in ("topk", "midk", "bottomk"):
        for tile in (32, 128, 256, 512):
            subset = [r for r in stages["results"] if r["kind"] == kind and r["cols"] == 8193 and r["tile"] == tile]
            stage_cells.append(dict(kind=kind, rows=2, cols=8193, k=65, tile=tile,
                                   **{stage + "_us": stats.median(stats.mean(b["profiled"]["gpu"][stage + "_total_ns"] / 16000 for b in r["batches"]) for r in subset)
                                      for stage in ("tile_sort", "row_merge")}))
    negative = read("browser-profile-c3e37c62.json")
    require(negative["status"] == "error", "preserve failed browser prototype")
    products = read("python-identity-2c72e26b.json")
    require(products["build_info"]["features"]["wgpu-rt"], "profiled wheel feature identity")
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix in (".log", ".py", ".txt", ".sha256", ".bundle", ".md"):
            hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    summary = dict(schema="spiraltorch.rank_single_pass_study.v1", status="passed",
                   baseline_source=native[0]["source"]["commit"], candidate_source=stages["source"]["commit"],
                   native_adapter=stages["results"][0]["adapter"], torch=native[1]["torch"],
                   native_cases=144, adaptive_observations=9216, native_comparisons=comparisons,
                   browser_comparisons=browsers, stage_cases=72, browser_profile_cases=12,
                   diagnostic_stage_cells=stage_cells, validated_profiles=len(all_profiles),
                   negative_browser_prototype="c3e37c62: query allocation failures returned zero buffers; rejected, not admitted timing evidence",
                   limitations=["Three seeds repeated with two policies in A-B-B-A process blocks, not independent seeds per repeat.",
                                "Browser adapter is anonymous and A/A spread is wide; not a general browser speedup claim.",
                                "Stage timestamps instrument separate passes and cannot be subtracted from normal host clocks.",
                                "Best fixed WGPU is hindsight selection; this is not a general PyTorch or training-quality win.",
                                "The 1024-repetition guarantee exercised here is rank-only, not the separate matmul/copy/rank chain."],
                   python_product=products, raw_sha256=hashes)
    with args.output.open("x") as stream:
        json.dump(summary, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": summary["status"], "native": [x["fixed_candidate_over_baseline"] for x in comparisons], "browser": [x["mean_ratios"] for x in browsers]}))


if __name__ == "__main__":
    main()
