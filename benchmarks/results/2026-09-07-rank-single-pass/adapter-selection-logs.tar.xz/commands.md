# Feature-aware adapter selection

Executable source: a64fe2486bf8a9ed33d967770f43a1e3221073c3.
source-adapter.bundle is incremental from fcc028d0.

The production asynchronous adapter preference loop filters requested timestamp
features before accepting a candidate. It preserves high-performance, low-power,
then fallback ordering. Non-profiled construction still accepts the first
available adapter. Absence of every adapter yields NoAdapter; seeing only
unsupported adapters yields TimestampQueriesUnavailable after all preferences.
Device creation errors still return explicitly, without retrying after a request.

The table-driven regression injects six sequences into this exact loop. It checks
a capable second adapter, capable third/fallback adapter, no adapters, unsupported
only, early exit on a capable first adapter, and first-available ordinary behavior.
It verifies probe order/count as well as the selected candidate/error. The red
harness applies the seam to fcc028d0 while retaining the old immediate feature
error and fails expecting candidate 1. This is not a physical multi-GPU test.

Local frozen-source live tests enable both SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1
and SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1. Build/check fresh WASM and Python
products using the preceding archives' commands, with distinct output directories.
Local Rust 1.98.0, formatter nightly-2026-04-15, wasm-bindgen 0.2.104. The installed
extension is checked against its wheel and served browser assets are hashed.
Native/WASM Clippy uses --all-targets -- -D warnings. No Furnace GPU work was
performed for this fix because another training job occupied the node.

The profiled factory may choose a different capable adapter than an ordinary
runtime. Callers comparing results must consult adapterInfo rather than infer
physical device identity from the preference alone. No new timing comparison or
speedup is claimed. Large build products are excluded from this archive.

After extraction:

```sh
python -I analyze_adapter_selection.py --output recomputed.json
```
