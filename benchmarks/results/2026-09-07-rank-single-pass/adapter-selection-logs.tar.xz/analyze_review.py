"""Revalidate post-review controls without rewriting the original speedup study."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics as stats
import sys

BASE = "2c72e26b5af58da8138c603e8ceb42303bd11135"
HEAD = "b7999e8f6ac1082a55a5f9f560859e145969da3e"


def require(value, message):
    if not value:
        raise ValueError(message)


def span(values):
    return dict(min=min(values), median=stats.median(values), max=max(values))


def canonical(request):
    values, indices = [], []
    for row in range(request["rows"]):
        data = request["input"][row * request["cols"]:(row + 1) * request["cols"]]
        ids = sorted(range(len(data)), key=lambda i: (-data[i] if request["kind"] == "topk" else data[i], i))
        start = (len(data) - request["k"]) // 2 if request["kind"] == "midk" else 0
        ids = ids[start:start + request["k"]]
        values.extend(data[i] for i in ids)
        indices.extend(ids)
    return values, indices


def validate_profile(gpu):
    require(gpu["schema"] == "spiraltorch.rank_gpu_profile.v1" and gpu["instrumented"], "profile schema")
    require(len(gpu["passes"]) == gpu["repetitions"] * 2, "pass cardinality")
    require(gpu["compute_submissions"] == math.ceil(gpu["repetitions"] / 256), "submission cardinality")
    require(math.isfinite(gpu["timestamp_period_ns"]) and gpu["timestamp_period_ns"] > 0, "timestamp period")
    for index, item in enumerate(gpu["passes"]):
        require(item["stage"] == ("tile_sort" if index % 2 == 0 else "row_merge") and item["repetition"] == index // 2, "stage order")
        require(type(item["start_tick"]) is str and type(item["end_tick"]) is str, "lossless integer clocks")
        elapsed = (int(item["end_tick"]) - int(item["start_tick"])) * gpu["timestamp_period_ns"]
        require(item["elapsed_ns"] == elapsed and math.isfinite(elapsed) and elapsed >= 0, "integer clock delta")
    for stage, offset in (("tile_sort", 0), ("row_merge", 1)):
        require(gpu[stage + "_total_ns"] == sum(p["elapsed_ns"] for p in gpu["passes"][offset::2]), "stage total")
    require(gpu["zero_intervals"] == sum(p["elapsed_ns"] == 0 for p in gpu["passes"]), "zero interval count")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    sys.path.insert(0, str(args.repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    import bench_resident_rank_adaptation_vs_torch as adaptation
    helpers = audit.load_bench_module()
    hashes = {}

    def read(name):
        raw = (root / name).read_bytes()
        hashes[name] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)

    products = read("products-b7999e8f.json")
    require(products["status"] == "passed" and products["source"] == HEAD, "product source")
    require(products["build_info"]["features"]["wgpu-rt"], "packaged WGPU runtime feature")
    expected = list(adaptation.requests(helpers))
    digest = hashlib.sha256("".join(json.dumps(r, allow_nan=False) + "\n" for r, _ in expected).encode()).hexdigest()
    native = []
    for name, commit in (("rank-pre-review.json", BASE), ("rank-review.json", HEAD)):
        report = read(name)
        require(report["status"] == "passed" and report["provenance"]["valid"], "native validity")
        require(report["source"]["commit"] == commit, "native source identity")
        require(audit.validate_source_binding(report["native_build_identity"], report["source"])["valid"], "native build binding")
        require(report["source"] == report["provenance"]["source_after"], "source changed during native run")
        require(report["request_sha256"] == digest and len(report["cases"]) == len(expected) == 36, "native requests")
        for case, (request, tiles) in zip(report["cases"], expected):
            require(case["request"] == {k: v for k, v in request.items() if k != "input"} and case["tiles"] == tiles, "request identity")
            adaptation.validate_native(case["native"], request, tiles)
            require(case["native"]["adapter"]["name"] == report["torch_device"], "named native/CUDA adapter identity")
            require((case["native"]["values"], case["native"]["indices"]) == canonical(request), "canonical rank output")
        native.append(report)
    require(native[0]["torch"] == native[1]["torch"] and native[0]["torch_device"] == native[1]["torch_device"], "CUDA reference identity")
    cells = []
    for before, after in zip(native[0]["cases"], native[1]["cases"]):
        for tile, a, b in zip(after["tiles"], before["native"]["control_samples_per_op_ms"], after["native"]["control_samples_per_op_ms"]):
            cells.append(dict(kind=after["request"]["kind"], cols=after["request"]["cols"], seed=after["request"]["seed"],
                              policy=after["request"]["policy"], tile=tile, mean_ratio=stats.mean(b) / stats.mean(a)))

    browser = read("browser-matched-b7999e8f.json")
    require(browser["status"] == "passed" and len(browser["cases"]) == 44 and not browser["page_errors"], "browser validity")
    require(browser["repetitions"] == 64 and browser["warmup_batches"] == 4 and browser["retained_batches"] == 16, "browser timing boundary")
    browser_cells = []
    for index, case in enumerate(browser["cases"]):
        require(case["status"] == "passed" and len(case["samples"]) == 16, "browser case validity")
        for batch, sample in enumerate(case["samples"]):
            require(sample["order"] == (["baseline", "candidate"] if (index + batch) % 2 == 0 else ["candidate", "baseline"]), "browser order")
            require(all(math.isfinite(sample[k]) and sample[k] > 0 for k in ("candidate_ms", "baseline_ms")), "browser finite timings")
        browser_cells.append(dict(cols=case["cols"], k=case["k"], mean_ratio=stats.mean(s["candidate_ms"] for s in case["samples"]) / stats.mean(s["baseline_ms"] for s in case["samples"])))

    stages = read("stage-probe-b7999e8f.json")
    require(stages["status"] == "passed" and stages["provenance_valid"] and len(stages["results"]) == 72, "stage validity")
    require(stages["source"]["commit"] == HEAD and audit.validate_source_binding(stages["native_build_identity"], stages["source"])["valid"], "stage build binding")
    requests = []
    for seed in (17, 29, 43):
        for kind in ("topk", "midk", "bottomk"):
            for cols, k in ((257, 7), (8193, 65)):
                values, _ = helpers.fixture(2 * cols, seed)
                if seed == 43:
                    values = [float(int(value * 8)) for value in values]
                for tile in (32, 128, 256, 512):
                    requests.append(dict(kind=kind, rows=2, cols=cols, k=k, tile=tile, input=values))
    require(stages["request_sha256"] == hashlib.sha256("".join(json.dumps(r, allow_nan=False) + "\n" for r in requests).encode()).hexdigest(), "stage request digest")
    for request, result in zip(requests, stages["results"]):
        require(result["status"] == "passed" and all(result[k] == request[k] for k in ("kind", "rows", "cols", "k", "tile")), "stage request identity")
        require((result["values"], result["indices"]) == canonical(request) and len(result["batches"]) == 12, "stage canonical output and batches")

    profile = read("browser-profile-b7999e8f.json")
    require(profile["status"] == "passed" and len(profile["cases"]) == 12 and not profile["page_errors"], "browser profile validity")
    for report in (browser, profile):
        require(not any(any(word in message["text"] for word in ("Invalid QuerySet", "Invalid CommandBuffer", "Cannot allocate sample buffer")) for message in report["console_messages"]), "uncaptured GPU error")
        for url, value in report["asset_sha256"].items():
            if url.startswith("/module/"):
                require(products["wasm_assets"][url.removeprefix("/module/")] == value, "candidate browser asset identity")
            elif url.startswith("/baseline/"):
                require(products["baseline_wasm_assets"][url.removeprefix("/baseline/")] == value, "baseline browser asset identity")
    require(profile["maximum_repetitions"]["status"] == "passed", "browser max repetitions")
    publication = profile["publication_validation"]
    require(publication["status"] == "passed" and publication["injected_query_calls"] == 1 and "GPU timestamp execution failed" in publication["error"], "actual browser rejection and stale output regression")
    all_profiles = [b["profiled"]["gpu"] for result in stages["results"] + profile["cases"] for b in result["batches"]]
    all_profiles.append(profile["maximum_repetitions"]["profile"])
    for gpu in all_profiles:
        validate_profile(gpu)

    for name, marker in (("backend-fixes-mac.log", "86 passed; 0 failed"),
                         ("backend-live-b7999e8f.log", "86 passed; 0 failed"),
                         ("python-b7999e8f.log", "103 passed"),
                         ("typescript-b7999e8f.log", "resident rank/profile TypeScript contract passed")):
        require(marker in (root / name).read_text(), "missing validation marker: " + name)
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix in (".log", ".py", ".patch", ".sha256", ".bundle", ".md"):
            hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    summary = dict(schema="spiraltorch.rank_single_pass_review.v1", status="passed", baseline_source=BASE,
                   candidate_source=HEAD, native_cases=72, adaptive_observations=4608,
                   native_comparison=dict(fixed_candidate_over_baseline=span([c["mean_ratio"] for c in cells]), cells=cells),
                   torch=native[1]["torch"], native_adapter=native[1]["torch_device"],
                   browser_comparison=dict(mean_ratios=span([c["mean_ratio"] for c in browser_cells]), cells=browser_cells, browser=browser["browser_version"]),
                   native_profile_cases=72, browser_profile_cases=12, validated_profiles=len(all_profiles),
                   publication_validation=publication, products=products,
                   limitations=["One sequential before/after native pair and one browser matched run; regression checks, not new speedup evidence.",
                                "Three native seeds repeated with two policies; browser repeats one deterministic fixture on an anonymous adapter.",
                                "Instrumented stage timestamps remain separate from normal dispatch timing and policy feedback.",
                                "CUDA is the PyTorch reference; this does not add or validate a new SpiralTorch CUDA implementation.",
                                "The maximum repetition probe is rank-only, not the separate matmul/copy/rank chain."],
                   raw_sha256=hashes)
    with args.output.open("x") as stream:
        json.dump(summary, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": "passed", "native": summary["native_comparison"]["fixed_candidate_over_baseline"],
                      "browser": summary["browser_comparison"]["mean_ratios"], "validated_profiles": len(all_profiles)}))


if __name__ == "__main__":
    main()
