"""Revalidate feature-aware adapter selection without a multi-GPU speedup claim."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

SOURCE = "a64fe2486bf8a9ed33d967770f43a1e3221073c3"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    sys.path.insert(0, str(root))
    from analyze_review import require, validate_profile
    red = (root / "adapter-red.log").read_text()
    require("left: Err(TimestampQueriesUnavailable)" in red and "right: Ok(1)" in red
            and "0 passed; 1 failed" in red, "old preference selection must fail")
    green = (root / "backend-frozen-mac.log").read_text()
    require("adapter_search_filters_features_before_accepting_a_preference ... ok" in green
            and "92 passed; 0 failed" in green, "feature-aware loop and live backend tests")
    require("103 passed" in (root / "python.log").read_text(), "packaged Python")
    require("shipped resident rank/profile TypeScript contract passed" in (root / "typescript.log").read_text(), "type contract")
    products = json.loads((root / "products-a64fe248.json").read_text())
    require(products["status"] == "passed" and products["source"] == SOURCE, "product attribution")
    browser = json.loads((root / "browser-profile.json").read_text())
    require(browser["status"] == "passed" and not browser["page_errors"] and len(browser["cases"]) == 12, "browser profile")
    require(browser["maximum_repetitions"]["status"] == "passed", "maximum repetitions")
    require(browser["publication_validation"]["status"] == "passed", "real query validation")
    for key in ("internal_validation", "scope_rejection"):
        require(browser[key]["status"] == "passed" and browser[key]["output_current_after_read"] is False, "failed publication")
    for url, digest in browser["asset_sha256"].items():
        if url.startswith("/module/"):
            require(products["wasm_assets"][url.removeprefix("/module/")] == digest, "browser asset identity")
    profiles = [batch["profiled"]["gpu"] for case in browser["cases"] for batch in case["batches"]]
    profiles.append(browser["maximum_repetitions"]["profile"])
    require(len(profiles) == 145, "profile cardinality")
    for profile in profiles:
        validate_profile(profile)
    summary = dict(schema="spiraltorch.rank_adapter_selection_review.v1", status="passed",
                   executable_source=SOURCE, injected_selection_cases=6, native_tests_local=92,
                   packaged_python_tests=103, browser_cases=12, validated_profiles=145,
                   limitations=["Selection cases inject capabilities into the production asynchronous preference loop; they are not a physical multi-GPU experiment.",
                                "Ordinary selection retains first-available behavior; device request failures still return without retry.",
                                "Profile creation can select a different capable adapter than an ordinary runtime; compare adapterInfo explicitly.",
                                "No further Furnace GPU work or new performance measurement was run while external training occupied the node.",
                                "Earlier timing studies remain attributed to their original source; Python/WASM attribution is build logs plus product hashes."],
                   raw_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.iterdir())
                               if p.is_file() and p.name not in ("summary.json", "recomputed.json", args.output.name)})
    with args.output.open("x") as stream:
        json.dump(summary, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": "passed", "source": SOURCE, "profiles": 145}))


if __name__ == "__main__":
    main()
