"""Capture packaged products; build logs, not this snapshot, attribute their source."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "wheel", "web", "baseline-web", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    import spiraltorch as st
    import spiraltorch.spiraltorch as native

    def digest(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def assets(directory):
        return {p.relative_to(directory).as_posix(): digest(p)
                for p in sorted(directory.rglob("*")) if p.is_file()}

    extension = Path(native.__file__).resolve()
    with zipfile.ZipFile(args.wheel) as archive:
        entries = [n for n in archive.namelist() if n.endswith("/" + extension.name)]
        if len(entries) != 1 or hashlib.sha256(archive.read(entries[0])).hexdigest() != digest(extension):
            raise ValueError("imported extension does not match the captured wheel")
    git = lambda *parts: subprocess.check_output(["git", "-C", str(args.repo), *parts], text=True).strip()
    if git("status", "--porcelain"):
        raise ValueError("source checkout is no longer clean")
    report = dict(schema="spiraltorch.rank_review_products.v1", status="passed",
                  attribution="clean source snapshot plus preserved build logs; not an embedded Git attestation",
                  source=git("rev-parse", "HEAD"), python=sys.executable,
                  extension=str(extension), extension_sha256=digest(extension),
                  wheel_sha256=digest(args.wheel), build_info=st.build_info(),
                  wasm_assets=assets(args.web), baseline_wasm_assets=assets(args.baseline_web))
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": "passed", "source": report["source"]}))


if __name__ == "__main__":
    main()
