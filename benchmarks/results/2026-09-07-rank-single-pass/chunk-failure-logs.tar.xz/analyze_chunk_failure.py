"""Revalidate partial-submission publication and packaged-client regressions."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

SOURCE = "5229a06d501c9370688b92989a9ebedff25783c1"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    sys.path.insert(0, str(root))
    from analyze_review import require, validate_profile

    def read(name):
        return json.loads((root / name).read_text())

    red = (root / "chunk-red.log").read_text()
    require("assertion failed: !rank.output_is_current()" in red and "0 passed; 1 failed" in red,
            "the late-publication baseline must reproduce the stale-state failure")
    for filename in ("backend-frozen-mac.log", "backend-linux.log"):
        text = (root / filename).read_text()
        require("failed_submitted_profile_chunk_cannot_leave_output_published ... ok" in text
                and "91 passed; 0 failed" in text, "new failure regression " + filename)
    require("103 passed" in (root / "python.log").read_text(), "packaged Python tests")
    require("shipped resident rank/profile TypeScript contract passed" in (root / "typescript.log").read_text(), "shipped declarations")
    products = read("products-5229a06d.json")
    require(products["status"] == "passed" and products["source"] == SOURCE, "product attribution")
    browser = read("browser-profile.json")
    require(browser["status"] == "passed" and not browser["page_errors"] and len(browser["cases"]) == 12, "browser profile")
    require(browser["maximum_repetitions"]["status"] == "passed", "browser maximum repetitions")
    require(browser["publication_validation"]["status"] == "passed", "real validation error")
    for key in ("internal_validation", "scope_rejection"):
        require(browser[key]["status"] == "passed" and browser[key]["output_current_after_read"] is False,
                "failed browser validation cannot publish")
    for url, digest in browser["asset_sha256"].items():
        if url.startswith("/module/"):
            require(products["wasm_assets"][url.removeprefix("/module/")] == digest, "browser asset identity")
    profiles = [batch["profiled"]["gpu"] for case in browser["cases"] for batch in case["batches"]]
    profiles.append(browser["maximum_repetitions"]["profile"])
    require(len(profiles) == 145, "profile cardinality")
    for profile in profiles:
        validate_profile(profile)
    files = [p for p in root.iterdir() if p.is_file() and p.name not in
             ("summary.json", "recomputed.json", args.output.name, "source-chunk.bundle")]
    summary = dict(schema="spiraltorch.rank_chunk_failure_review.v1", status="passed",
                   executable_source=SOURCE, native_tests_per_host=91, packaged_python_tests=103,
                   browser_cases=12, validated_profiles=len(profiles),
                   red_basis="1336ebb2 plus the local callback harness, retaining late publication",
                   injection="one real chunk submission followed by a synthetic scoped SubmitTimeout; not an induced driver hang",
                   limitations=["No new native/CUDA or browser speedup measurement is claimed.",
                                "Furnace's correctness test briefly overlapped a newly started external training process; its timings are excluded from performance evidence.",
                                "No further Furnace GPU execution was started after detecting the contention; the external process was not modified.",
                                "The earlier uncontended source-bound comparisons and archives remain unchanged.",
                                "Python/WASM attribution uses clean build logs and product hashes, not embedded Git attestation."],
                   raw_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)})
    with args.output.open("x") as stream:
        json.dump(summary, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": "passed", "profiles": len(profiles), "source": SOURCE}))


if __name__ == "__main__":
    main()
