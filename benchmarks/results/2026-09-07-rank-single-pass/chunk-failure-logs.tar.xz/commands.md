# Partial submission failure

Executable source: 5229a06d501c9370688b92989a9ebedff25783c1.
The source-chunk-code.bundle is incremental from 1336ebb2. Earlier measured
artifacts remain frozen at their explicitly recorded source commits.

The internal encoding helper accepts a scoped chunk-submission callback, also
used by production to preserve the existing Metal timeout and other backends'
enqueue-only behavior. The test submits a real chunk and then injects a typed
SubmitTimeout. This is not a real driver timeout or an induced GPU hang.

red-harness.patch applies that test seam to 1336ebb2 but deliberately retains
the old late-publication assignment. It fails on output_is_current. The fixed
method detaches the earlier publication token before any fallible GPU encoding
or submission, after initial admission checks. An older pending read cannot
republish the failed operation, snapshots reject, and ordinary dispatch recovers.

Use the preceding closing archive's build/test commands, with this clean source
and fresh product/output directories. backend-frozen-mac.log runs all 91 tests
with both SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 and
SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1. backend-mac.log is the initial green
working-tree test, not the frozen-source rerun.

Furnace's 91-test correctness run overlapped a newly started external training
process. The status check and unconditional test launch had mistakenly been
batched in one tool call. The test had already ended when its owned processes
were checked; no external process was killed or modified. No further Furnace
GPU jobs were launched. This run's wall times are not performance evidence.
Earlier native/CUDA comparisons and the 72-case stage rerun completed before
that training began. The final packaged-client checks ran on the local Mac.

No kernel, tile selection, ordinary dispatch lock, publication-token allocation
on the ordinary path, or policy feedback changed. No new speedup is claimed.
Native/WASM strict Clippy, fresh WASM/wheel builds and generated/shipped type
checks use the same commands documented in the preceding archive. capture_products.py
checks installed extension bytes against the wheel and records browser assets.
Large binaries/wheels and the redundant source-chunk.bundle are excluded.

After extraction:

```sh
python -I analyze_chunk_failure.py --output recomputed.json
```
