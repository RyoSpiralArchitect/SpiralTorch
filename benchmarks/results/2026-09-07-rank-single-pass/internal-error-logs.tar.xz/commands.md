# Internal GPU error review

Executable source: d8749294c6266f8b43668fc2fbe566146460ac3d.
Previous frozen code: b7999e8f6ac1082a55a5f9f560859e145969da3e.
The source bundle is incremental from b7999e8f and includes the preceding
evidence-only 21e29d95 commit.

The timestamp scope now includes Internal errors. All three scope futures are
drained before validation decides success. The pinned wgpu browser converter
uses GPUInternalError's GPUError base because its generated web-sys snapshot
lacks the derived type; these failures stay typed rather than trapping.

The new browser regression runs real push/pop calls but replaces the Internal
scope's result with a synthetic GPUInternalError. This is not an induced driver
fault. The red baseline lacks that scope, accepts its profile and publishes;
the fixed module rejects with the injected message and keeps output stale.
Both results and all served-asset hashes are retained. The preexisting real
invalid-query Validation failure and normal-dispatch recovery also pass.

Use the prior review's build/test commands with fresh output directories and
this exact clean source. Local Rust 1.98.0; Furnace private Rust 1.98.1;
wasm-bindgen 0.2.104. Copy native executables out of the shared target and chmod
555; the probe checks embedded source/build identity before running. No GPU
processes overlapped across hosts. Local wheel builds did not overlap browser
timing. Existing Furnace CPU work was unchanged.

```sh
node tools/test_resident_browser.cjs FROZEN_BASELINE_WEB CHROME NEW_RED_JSON '' '' '' '' rank-profile
node tools/test_resident_browser.cjs FROZEN_CANDIDATE_WEB CHROME NEW_GREEN_JSON '' '' '' '' rank-profile
python -I run_profile_probe.py --repo CANDIDATE_REPO --executable COPIED_PROFILE_EXECUTABLE --output NEW_NATIVE_JSON
PRIVATE_PYTHON -I capture_products.py --repo CANDIDATE_REPO --wheel WHEEL --web FROZEN_CANDIDATE_WEB --baseline-web FROZEN_BASELINE_WEB --output products-d8749294.json
python -I analyze_internal.py --repo REPO_CONTAINING_THE_HARNESS --output NEW_SUMMARY_JSON
```

The archive includes a copy of the previous analyzer for its canonical output
and timestamp validators; invoke analyze_internal.py, not that analyzer's main.
Python extension bytes must match the new wheel. Build logs and clean source
snapshots attribute Python/WASM source, not an embedded Git attestation. Large
products are excluded. Ordinary rank dispatch and shader code are byte-unchanged
from b7999e8f; this is correctness revalidation, not another speedup study.
