"""Revalidate Internal-error handling separately from normal-path performance."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HEAD = "d8749294c6266f8b43668fc2fbe566146460ac3d"


def require(value, message):
    if not value:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("previous", root / "analyze_review.py")
    previous = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(previous)
    sys.path.insert(0, str(args.repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    hashes = {}

    def read(name):
        raw = (root / name).read_bytes()
        hashes[name] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)

    products = read("products-d8749294.json")
    require(products["status"] == "passed" and products["source"] == HEAD, "product source")
    require(products["build_info"]["features"]["wgpu-rt"], "wheel runtime feature")
    red = read("browser-internal-red-detail.json")
    require(red["status"] == "error" and not red["page_errors"], "negative browser result")
    require(red["internal_validation"]["pushed"] == ["out-of-memory", "validation"], "old missing Internal scope")
    require(red["internal_validation"]["error"] is None and red["internal_validation"]["output_current_after_read"], "old profile published without the injected Internal scope")
    require(red["asset_sha256"]["/module/spiraltorch_wasm_bg.wasm"] == products["baseline_wasm_assets"]["spiraltorch_wasm_bg.wasm"], "red frozen baseline asset")

    browser = read("browser-profile-d8749294.json")
    require(browser["status"] == "passed" and len(browser["cases"]) == 12 and not browser["page_errors"], "browser profile validity")
    internal = browser["internal_validation"]
    require(internal["status"] == "passed" and not internal["output_current_after_read"], "internal error must not publish")
    require(internal["pushed"] == ["internal", "out-of-memory", "validation"] and internal["popped"] == list(reversed(internal["pushed"])), "all scopes are synchronously balanced")
    require("injected timestamp internal error" in internal["error"] and "GPU timestamp execution failed" in internal["error"], "typed Internal conversion without WASM trap")
    require(browser["publication_validation"]["status"] == "passed" and browser["maximum_repetitions"]["status"] == "passed", "validation and max-repetition regressions")
    require(not any(any(word in message["text"] for word in ("Invalid QuerySet", "Invalid CommandBuffer", "Cannot allocate sample buffer")) for message in browser["console_messages"]), "uncaptured GPU errors")
    for url, digest in browser["asset_sha256"].items():
        if url.startswith("/module/"):
            require(products["wasm_assets"][url.removeprefix("/module/")] == digest, "green product identity")

    stages = read("stage-probe-d8749294.json")
    require(stages["status"] == "passed" and stages["provenance_valid"] and len(stages["results"]) == 72, "native profile validity")
    require(stages["source"]["commit"] == HEAD and audit.validate_source_binding(stages["native_build_identity"], stages["source"])["valid"], "native build binding")
    helpers = audit.load_bench_module()
    requests = []
    for seed in (17, 29, 43):
        for kind in ("topk", "midk", "bottomk"):
            for cols, k in ((257, 7), (8193, 65)):
                values, _ = helpers.fixture(2 * cols, seed)
                if seed == 43:
                    values = [float(int(value * 8)) for value in values]
                for tile in (32, 128, 256, 512):
                    requests.append(dict(kind=kind, rows=2, cols=cols, k=k, tile=tile, input=values))
    require(stages["request_sha256"] == hashlib.sha256("".join(json.dumps(r, allow_nan=False) + "\n" for r in requests).encode()).hexdigest(), "native request digest")
    for request, result in zip(requests, stages["results"]):
        require(result["status"] == "passed" and all(result[k] == request[k] for k in ("kind", "rows", "cols", "k", "tile")), "native request identity")
        require((result["values"], result["indices"]) == previous.canonical(request) and len(result["batches"]) == 12, "native canonical output")
    profiles = [b["profiled"]["gpu"] for result in stages["results"] + browser["cases"] for b in result["batches"]]
    profiles.append(browser["maximum_repetitions"]["profile"])
    for profile in profiles:
        previous.validate_profile(profile)

    for name, marker in (("backend-mac.log", "87 passed; 0 failed"),
                         ("backend-linux-d8749294.log", "87 passed; 0 failed"),
                         ("python-d8749294.log", "103 passed"),
                         ("typescript-d8749294.log", "resident rank/profile TypeScript contract passed")):
        require(marker in (root / name).read_text(), "missing test marker: " + name)
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix in (".py", ".log", ".patch", ".bundle", ".md"):
            hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    summary = dict(schema="spiraltorch.rank_internal_error_review.v1", status="passed", candidate_source=HEAD,
                   native_profile_cases=72, browser_profile_cases=12, validated_profiles=len(profiles),
                   native_backend_tests=87, python_tests=103, internal_validation=internal, products=products,
                   limitations=["Internal error injection replaces one real scope's result with a synthetic GPUInternalError; not a real driver fault.",
                                "The separate invalid-query case is a real WebGPU Validation error, not an Internal-error hardware test.",
                                "No new normal-path performance claim. Ordinary rank dispatch and shaders are unchanged from b7999e8f.",
                                "Rank-only maximum repetitions; the matmul/copy/rank chain is outside this test."],
                   raw_sha256=hashes)
    with args.output.open("x") as stream:
        json.dump(summary, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": "passed", "source": HEAD, "validated_profiles": len(profiles)}))


if __name__ == "__main__":
    main()
