"""Compile the shipped declarations, including positive and negative profile calls."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--module", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    declaration = args.repo / "bindings/st-wasm/types/spiraltorch-wasm.d.ts"
    contract = args.repo / "bindings/st-wasm/tests/resident_types.cjs"
    fixture = root / "types/shipped-profile.ts"
    tsc, node = shutil.which("tsc"), shutil.which("node")
    if tsc is None or node is None:
        raise RuntimeError("tsc and node are required; no skipped type checks")
    commands = [
        [tsc, "--version"], [node, "--version"],
        [node, str(contract), str(args.module)],
        [tsc, "--noEmit", "--strict", "--target", "ES2020", "--module", "esnext",
         "--moduleResolution", "node", str(declaration), str(fixture)],
    ]
    results = []
    for command in commands:
        result = subprocess.run(command, text=True, capture_output=True, timeout=60)
        results.append(dict(command=command, returncode=result.returncode,
                            stdout=result.stdout, stderr=result.stderr))
    git = lambda *parts: subprocess.check_output(["git", "-C", str(args.repo), *parts], text=True).strip()
    clean = not git("status", "--porcelain")
    report = dict(status="passed" if clean and all(r["returncode"] == 0 for r in results) else "error",
                  source=git("rev-parse", "HEAD"), clean=clean, commands=results,
                  file_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in (declaration, contract, fixture, args.module.with_suffix(".d.ts"))})
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": report["status"], "source": report["source"]}))
    raise SystemExit(report["status"] != "passed")


if __name__ == "__main__":
    main()
