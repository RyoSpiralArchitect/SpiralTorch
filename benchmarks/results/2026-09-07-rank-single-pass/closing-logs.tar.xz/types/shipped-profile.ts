import { WgpuRank, RankAdaptationSession } from "spiraltorch-wasm";

async function profileRank(session: RankAdaptationSession): Promise<void> {
  const ordinary = await WgpuRank.create("midk", 2, 8193, 65);
  const profiled = await WgpuRank.create("midk", 2, 8193, 65, null, true);
  const adapted = await WgpuRank.createFromAdaptation(session, 0, true);
  const enabled: boolean = profiled.timestampQueriesEnabled;
  const report: Record<string, unknown> = await profiled.profile(16);
  await adapted.profile(null);
  await ordinary.synchronize();
  void [enabled, report];
  // @ts-expect-error The diagnostic flag is a boolean, not a repetition count.
  await WgpuRank.create("midk", 2, 8193, 65, 256, 16);
  // @ts-expect-error Profile repetitions must be numeric.
  await profiled.profile("16");
}

void profileRank;
