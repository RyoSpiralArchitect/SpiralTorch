# Closing review and device lifetime regression

Historical measurements remain frozen in their original archives. This bundle
adds three fixes without relabeling those measurements:

- 1bfdceb0ff3b1af7a2fb793abcc30627cc48d86f: fail closed on a rejected browser
  popErrorScope Promise. scope/ retains the synthetic red/green replay.
- baa0b9629506452989d929a13be28145c9fca88f: private profiling devices cannot
  capture errors from an unrelated ordinary shared-runtime operation.
- 4f00cbc626c66b755b92130c9d09c1e1850bb640: shipped declarations include profile
  arguments/results and the referenced WgpuMatmul class. Generated and shipped
  declarations share tests; strict tsc compiles a positive/negative fixture.
- 8dde25c317b1ff26053d470ef0c3f3d90bbfd2fe: GPU buffers, pending queries and the
  readback pool retire before their last owning device. No execution lock,
  normal-dispatch algorithm, shader, tile choice or policy reward changed.

private/ retains a b7999e8f -> baa0b962 -> baa0b962 -> b7999e8f native ABBA and
one matched browser comparison. These ratios do not measure the later drop-order
fix. The first pair's roughly 2% median increase is retained alongside the reverse
pair, not erased as noise. Every native benchmark runs WGPU and PyTorch CUDA in
separate sequential processes on the same named RTX 5090. This is not a new
SpiralTorch CUDA implementation or a general PyTorch performance win.

The additional 72-case baa0b962 stage run failed after 62 successful cases, then
device initialization errors, and exited with SIGSEGV (-11). The entire failed
run is invalid, including its partial timing data. teardown/stage-probe.json
reruns the same fixture digest successfully at 8dde25c3. The new 96-cycle native
test covers workspace-first, readback-first, and cancellation drop orders.

## Rebuild and execute

Use clean source worktrees, immutable copied executables (chmod 555), and distinct
output directories. Local Rust 1.98.0; Furnace private Rust 1.98.1; formatter
nightly-2026-04-15; wasm-bindgen 0.2.104. Do not execute directly from the shared
Cargo target. No GPU jobs overlapped across the two hosts. The Furnace CPU
llama-server and system configuration were not modified.

```sh
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 cargo test --locked -p st-backend-wgpu -- --test-threads=1
cargo clippy --locked -p st-backend-wgpu --all-targets -- -D warnings
cargo clippy --locked -p st-backend-wgpu --target wasm32-unknown-unknown --all-targets -- -D warnings
cargo build --locked --release -p st-core --features wgpu-rt,kdsl --example resident_rank_profile_bench --example resident_rank_adaptation_bench
cargo build --locked --release -p spiraltorch-wasm --target wasm32-unknown-unknown --features webgpu
wasm-bindgen TARGET/wasm32-unknown-unknown/release/spiraltorch_wasm.wasm --target web --out-dir FROZEN_WEB
python tools/bench_resident_rank_adaptation_vs_torch.py --executable COPIED_ADAPTATION_BINARY --output NEW_NATIVE_JSON
python -I private/run_profile_probe.py --repo CLEAN_REPO --executable COPIED_PROFILE_BINARY --output NEW_STAGE_JSON
node tools/test_resident_browser.cjs FROZEN_WEB CHROME NEW_BROWSER_JSON '' '' '' '' rank-profile
maturin build --locked --release --manifest-path bindings/st-py/Cargo.toml --features wgpu-rt --interpreter PRIVATE_PYTHON --out WHEELS
PRIVATE_PYTHON -I -m pip install --force-reinstall --no-deps WHEEL
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 PRIVATE_PYTHON -I -m pytest --import-mode=importlib -q bindings/st-py/tests/test_wgpu_rank.py bindings/st-py/tests/test_wgpu_resident.py bindings/st-py/tests/test_spiralk_rank_tile.py bindings/st-py/tests/test_resident_rank_adaptation.py bindings/st-py/tests/test_wgpu_rank_reports.py bindings/st-py/tests/test_wgpu_rank_profile.py
PRIVATE_PYTHON -I private/capture_products.py --repo CLEAN_REPO --wheel WHEEL --web FROZEN_WEB --baseline-web FROZEN_BASELINE_WEB --output NEW_PRODUCTS_JSON
python -I validate_types.py --repo CLEAN_REPO --module FROZEN_WEB/spiraltorch_wasm.js --output NEW_TYPE_JSON
```

The native/CUDA runner needs Furnace's user-site Torch, so it intentionally does
not use Python -I. The GPU-only stage runner and offline analyzers do use -I.
The initial teardown/backend-{mac,linux}.log enabled timestamp tests only due to
an incorrect ordinary-runtime environment variable. They are not the all-live
evidence: teardown/backend-live-{mac,linux}.log are the corrected full reruns.

Native reports embed clean commit/tree/build and immutable executable identities.
Python/WASM products are attributed by clean build logs and hashes, not embedded
Git attestation. A separate clean baa0b962 worktree was used to capture the old
products after later edits; the loaded extension was byte-checked against that
wheel before replacing the private environment with the new wheel. Large wheels
and WASM products are excluded from this compact archive.

## Offline replay

```sh
python -I analyze_closing.py --repo /path/to/SpiralTorch --output recomputed.json
```

This validates all five native runs, real Rust policy receipts, fixture digests,
canonical ranks, stage clocks, browser assets, synthetic failure boundaries and
strict type-test receipts. The final native run is a correctness/source check,
not a new matched speedup comparison. Rank-only maximum repetitions do not cover
the independent matmul/copy/rank chain maximum.
