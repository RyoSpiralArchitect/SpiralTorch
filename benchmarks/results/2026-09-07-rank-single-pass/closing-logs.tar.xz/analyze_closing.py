"""Recompute closing review evidence without relabeling earlier measured sources."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics as stats
import sys

BASE = "b7999e8f6ac1082a55a5f9f560859e145969da3e"
PRIVATE = "baa0b9629506452989d929a13be28145c9fca88f"
FINAL = "8dde25c317b1ff26053d470ef0c3f3d90bbfd2fe"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    sys.path.insert(0, str(root / "private"))
    from analyze_review import require, span, canonical, validate_profile
    sys.path.insert(0, str(args.repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    import bench_resident_rank_adaptation_vs_torch as adaptation

    def read(name):
        return json.loads((root / name).read_text())

    expected = list(adaptation.requests(audit.load_bench_module()))
    digest = hashlib.sha256("".join(json.dumps(r, allow_nan=False) + "\n" for r, _ in expected).encode()).hexdigest()
    natives = []
    for name, commit in (("private/native-baseline.json", BASE),
                         ("private/native-candidate.json", PRIVATE),
                         ("private/native-candidate-2.json", PRIVATE),
                         ("private/native-baseline-2.json", BASE),
                         ("teardown/native-final.json", FINAL)):
        report = read(name)
        require(report["status"] == "passed" and report["provenance"]["valid"], "native validity")
        require(report["source"]["commit"] == commit and report["source"] == report["provenance"]["source_after"], "native source")
        require(audit.validate_source_binding(report["native_build_identity"], report["source"])["valid"], "native build binding")
        require(report["request_sha256"] == digest and len(report["cases"]) == len(expected) == 36, "native fixture digest")
        for case, (request, tiles) in zip(report["cases"], expected):
            require(case["request"] == {k: v for k, v in request.items() if k != "input"} and case["tiles"] == tiles, "native request identity")
            adaptation.validate_native(case["native"], request, tiles)
            require(case["native"]["adapter"]["name"] == report["torch_device"], "native/CUDA adapter")
            require((case["native"]["values"], case["native"]["indices"]) == canonical(request), "canonical rank")
        natives.append(report)
    require(all(r["torch"] == natives[0]["torch"] and r["torch_device"] == natives[0]["torch_device"] for r in natives), "CUDA version/device")
    comparisons = []
    for before, after in ((natives[0], natives[1]), (natives[3], natives[2])):
        ratios = [stats.mean(b) / stats.mean(a) for u, v in zip(before["cases"], after["cases"])
                  for a, b in zip(u["native"]["control_samples_per_op_ms"], v["native"]["control_samples_per_op_ms"])]
        comparisons.append(dict(fixed_controls=len(ratios), candidate_over_baseline=span(ratios), ratios=ratios))

    old_products = read("private/products-baa0b962.json")
    final_products = read("teardown/products-8dde25c3.json")
    for products, commit in ((old_products, PRIVATE), (final_products, FINAL)):
        require(products["status"] == "passed" and products["source"] == commit and products["build_info"]["features"]["wgpu-rt"], "packaged source/features")

    browser = read("private/browser-matched.json")
    require(browser["status"] == "passed" and len(browser["cases"]) == 44 and not browser["page_errors"], "browser matched validity")
    require((browser["repetitions"], browser["warmup_batches"], browser["retained_batches"]) == (64, 4, 16), "browser timing boundary")
    browser_ratios = []
    for index, case in enumerate(browser["cases"]):
        require(case["status"] == "passed" and len(case["samples"]) == 16, "browser case")
        for batch, sample in enumerate(case["samples"]):
            require(sample["order"] == (["baseline", "candidate"] if (index + batch) % 2 == 0 else ["candidate", "baseline"]), "browser matched order")
            require(all(math.isfinite(sample[k]) and sample[k] > 0 for k in ("candidate_ms", "baseline_ms")), "browser finite samples")
        browser_ratios.append(stats.mean(s["candidate_ms"] for s in case["samples"]) / stats.mean(s["baseline_ms"] for s in case["samples"]))

    profiles = []
    for name, products in (("private/browser-profile.json", old_products), ("teardown/browser-profile.json", final_products)):
        profile = read(name)
        require(profile["status"] == "passed" and not profile["page_errors"] and len(profile["cases"]) == 12, "browser profile")
        require(profile["maximum_repetitions"]["status"] == "passed", "max profile repetitions")
        require(profile["publication_validation"]["status"] == "passed" and profile["publication_validation"]["injected_query_calls"] == 1, "real query validation")
        for key in ("internal_validation", "scope_rejection"):
            require(profile[key]["status"] == "passed" and profile[key]["output_current_after_read"] is False, "synthetic failure publication")
        for case in profile["cases"]:
            require(case["status"] == "passed" and len(case["batches"]) == 12, "profile batches")
            profiles.extend(b["profiled"]["gpu"] for b in case["batches"])
        profiles.append(profile["maximum_repetitions"]["profile"])
        for url, digest in profile["asset_sha256"].items():
            if url.startswith("/module/"):
                require(products["wasm_assets"][url.removeprefix("/module/")] == digest, "browser profile product")
    for url, digest in browser["asset_sha256"].items():
        if url.startswith("/module/"):
            require(old_products["wasm_assets"][url.removeprefix("/module/")] == digest, "matched candidate product")
        elif url.startswith("/baseline/"):
            require(old_products["baseline_wasm_assets"][url.removeprefix("/baseline/")] == digest, "matched baseline product")

    stage = read("teardown/stage-probe.json")
    require(stage["status"] == "passed" and stage["provenance_valid"] and len(stage["results"]) == 72, "stage validity")
    require(stage["source"]["commit"] == FINAL and audit.validate_source_binding(stage["native_build_identity"], stage["source"])["valid"], "stage source")
    requests = []
    fixture = audit.load_bench_module().fixture
    for seed in (17, 29, 43):
        for kind in ("topk", "midk", "bottomk"):
            for cols, k in ((257, 7), (8193, 65)):
                values, _ = fixture(2 * cols, seed)
                if seed == 43:
                    values = [float(int(v * 8)) for v in values]
                for tile in (32, 128, 256, 512):
                    requests.append(dict(kind=kind, rows=2, cols=cols, k=k, tile=tile, input=values))
    stage_digest = hashlib.sha256("".join(json.dumps(r, allow_nan=False) + "\n" for r in requests).encode()).hexdigest()
    require(stage["request_sha256"] == stage_digest, "stage request digest")
    for request, result in zip(requests, stage["results"]):
        require(result["status"] == "passed" and all(result[k] == request[k] for k in ("kind", "rows", "cols", "k", "tile")), "stage request identity")
        require((result["values"], result["indices"]) == canonical(request) and len(result["batches"]) == 12, "stage canonical result")
        profiles.extend(b["profiled"]["gpu"] for b in result["batches"])
    for profile in profiles:
        validate_profile(profile)

    failed = read("private/stage-probe.json")
    partial = [json.loads(line) for line in failed["stdout"].splitlines()]
    require(failed["status"] == "error" and failed["returncode"] == -11 and failed["source"]["commit"] == PRIVATE, "retained native failure")
    require(failed["request_sha256"] == stage_digest and sum(p["status"] == "passed" for p in partial) == 62, "native failure boundary")
    scope_red, scope_green = read("scope/browser-red-d8749294.json"), read("scope/browser-green-1bfdceb0.json")
    require(scope_red["status"] == "error" and scope_red["scope_rejection"]["error"] is None and scope_red["scope_rejection"]["output_current_after_read"] is True, "scope red reproduction")
    require(scope_green["status"] == "passed" and scope_green["scope_rejection"]["status"] == "passed" and scope_green["scope_rejection"]["output_current_after_read"] is False, "scope green reproduction")
    types = read("type-validation.json")
    require(types["status"] == "passed" and types["source"] == FINAL and types["clean"] and all(c["returncode"] == 0 for c in types["commands"]), "shipped/generated strict types")
    for name, marker in (("teardown/backend-live-mac.log", "90 passed; 0 failed"),
                         ("teardown/backend-live-linux.log", "90 passed; 0 failed"),
                         ("teardown/python.log", "103 passed")):
        require(marker in (root / name).read_text(), "test marker " + name)

    raw = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
           for p in sorted(root.rglob("*")) if p.is_file() and "__pycache__" not in p.parts
           and p.name not in (args.output.name, "recomputed.json", "summary.json")}
    summary = dict(schema="spiraltorch.rank_profile_closing.v1", status="passed",
                   baseline_source=BASE, private_device_source=PRIVATE, final_executable_source=FINAL,
                   native_abba=dict(cases=144, adaptive_observations=9216, pairs=comparisons),
                   final_native_validation=dict(cases=36, adaptive_observations=2304, torch=natives[4]["torch"], adapter=natives[4]["torch_device"]),
                   browser_private_device_regression=dict(cases=44, mean_ratios=span(browser_ratios)),
                   native_profile_cases=72, validated_profiles=len(profiles),
                   retained_native_failure=dict(source=PRIVATE, passing_cases=62, returncode=-11, total_case_lines=len(partial)),
                   limitations=["The native ABBA and browser latency ratios measure baa0b962, not the later lifetime fix.",
                                "The final native/CUDA run validates the final source; it is not a new matched speedup study.",
                                "Instrumented separate-pass clocks do not measure ordinary single-pass costs or feed policy feedback.",
                                "Scope Promise and Internal failures are synthetic; the separate invalid-query test is real validation, not a driver OOM.",
                                "CUDA is the PyTorch reference, not a new SpiralTorch CUDA backend.",
                                "Python/WASM source attribution uses preserved clean build logs and product hashes, not embedded Git attestation."],
                   raw_sha256=raw)
    with args.output.open("x") as stream:
        json.dump(summary, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": "passed", "native_ratios": [c["candidate_over_baseline"] for c in comparisons],
                      "browser_ratios": summary["browser_private_device_regression"]["mean_ratios"], "profiles": len(profiles)}))


if __name__ == "__main__":
    main()
