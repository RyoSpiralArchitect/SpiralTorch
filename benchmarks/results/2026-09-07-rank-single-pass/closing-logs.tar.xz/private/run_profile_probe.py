"""Frozen-source GPU stage diagnostic; not a PyTorch speedup comparison."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--executable", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve() / "tools"))
    import bench_rank_vs_torch as audit
    import bench_resident_rank_vs_torch as resident

    def require(value, message):
        if not value:
            raise ValueError(message)

    report = {"schema": "spiraltorch.rank_stage_study.v1", "status": "error"}
    try:
        resident.require_uncontended_gpu()
        before = audit.source_identity()
        image = audit.file_identity(args.executable)
        identity = audit.read_native_build_identity(args.executable)
        binding = audit.validate_source_binding(identity, before)
        report.update(source=before, executable=image, native_build_identity=identity,
                      build_source_binding=binding)
        require(binding["valid"], "source/build identity mismatch")
        bench = audit.load_bench_module()
        requests, metadata = [], []
        for seed in (17, 29, 43):
            for kind in ("topk", "midk", "bottomk"):
                for cols, k in ((257, 7), (8193, 65)):
                    values, _ = bench.fixture(2 * cols, seed)
                    if seed == 43:
                        values = [float(int(value * 8)) for value in values]
                    for tile in (32, 128, 256, 512):
                        request = dict(kind=kind, rows=2, cols=cols, k=k, tile=tile, input=values)
                        requests.append(request)
                        metadata.append(dict(seed=seed, **{key: v for key, v in request.items() if key != "input"}))
        payload = "".join(json.dumps(r, allow_nan=False) + "\n" for r in requests)
        report.update(request_sha256=hashlib.sha256(payload.encode()).hexdigest(), requests=metadata)
        run = subprocess.run([str(args.executable)], input=payload, text=True,
                             capture_output=True, timeout=600)
        report.update(returncode=run.returncode, stderr=run.stderr, stdout=run.stdout)
        require(run.returncode == 0 and not run.stderr, "native probe failed")
        results = [json.loads(line) for line in run.stdout.splitlines()]
        require(len(results) == len(requests), "probe result cardinality")
        for request, result in zip(requests, results):
            require(result["status"] == "passed", "probe did not pass")
            for key in ("kind", "rows", "cols", "k"):
                require(result[key] == request[key], "request identity")
            # Plan normalizes a requested tile larger than the row length.
            require(result["tile"] == request["tile"], "requested tile identity")
            values, indices = [], []
            for row in range(request["rows"]):
                data = request["input"][row * request["cols"]:(row + 1) * request["cols"]]
                ids = sorted(range(len(data)), key=lambda i: (-data[i] if request["kind"] == "topk" else data[i], i))
                start = (len(data) - request["k"]) // 2 if request["kind"] == "midk" else 0
                selected = ids[start:start + request["k"]]
                indices.extend(selected)
                values.extend(data[i] for i in selected)
            require(result["values"] == values and result["indices"] == indices, "canonical output")
            require(len(result["batches"]) == 12, "retained paired batches")
            for batch_index, batch in enumerate(result["batches"]):
                require(batch["order"] == (["plain", "profiled"] if batch_index % 2 == 0 else ["profiled", "plain"]), "paired order")
                for arm in ("plain", "profiled"):
                    require(all(math.isfinite(batch[arm][key]) and batch[arm][key] >= 0 for key in ("total_ms", "dispatch_call_ms")), "host timing")
                gpu = batch["profiled"]["gpu"]
                require(gpu["schema"] == "spiraltorch.rank_gpu_profile.v1" and gpu["generation"] == "1", "Rust schema")
                require(gpu["compute_submissions"] == 1 and not gpu["host_paced_chunks"], "diagnostic submissions")
                require(gpu["repetitions"] == 16 and len(gpu["passes"]) == 32, "pass cardinality")
                for index, interval in enumerate(gpu["passes"]):
                    require(interval["stage"] == ("tile_sort" if index % 2 == 0 else "row_merge") and interval["repetition"] == index // 2, "stage order")
                    require(interval["elapsed_ns"] == (int(interval["end_tick"]) - int(interval["start_tick"])) * gpu["timestamp_period_ns"], "integer GPU delta")
                    require(math.isfinite(interval["elapsed_ns"]) and interval["elapsed_ns"] >= 0, "GPU interval")
                for stage, offset in (("tile_sort", 0), ("row_merge", 1)):
                    require(gpu[stage + "_total_ns"] == sum(p["elapsed_ns"] for p in gpu["passes"][offset::2]), "stage total")
        resident.require_uncontended_gpu()
        require(before == audit.source_identity() and image == audit.file_identity(args.executable), "provenance changed")
        report.update(status="passed", results=results, provenance_valid=True)
        del report["stdout"]
    except subprocess.TimeoutExpired as error:
        report.update(error=str(error), stdout=str(error.stdout), stderr=str(error.stderr))
    except Exception as error:
        report["error"] = str(error)
    audit.write_report_exclusive(args.output, report)
    print(json.dumps({"status": report["status"], "cases": len(report.get("results", [])), "error": report.get("error")}))
    raise SystemExit(report["status"] != "passed")


if __name__ == "__main__":
    main()
