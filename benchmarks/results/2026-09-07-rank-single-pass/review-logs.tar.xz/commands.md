# Post-review regression replay

Measured baseline: 2c72e26b5af58da8138c603e8ceb42303bd11135.
Measured candidate: b7999e8f6ac1082a55a5f9f560859e145969da3e.
This supplements, rather than replaces, the original A-B-B-A speedup study.

Both reviewer defects were reproduced first; the failing patches and logs are
retained. Native profiles sharing the same actual device now fail fast if their
diagnostic error scopes would overlap. There is no execution/readback lock or
automatic fallback, and ordinary dispatch does not allocate a publication token.
Profiled output becomes current only after its own successful validation/readback.
The browser fixture also injects one real invalid query count, restores the test
prototype synchronously, and checks rejection, stale output and normal recovery.

The generated WASM TypeScript contract failed independently in CI. Its constructor
expectations now include the actual optional timestamp flag and profiling return
types; no workflow was disabled or assertion loosened to an unconstrained match.

## Build and verify

Use separate clean source worktrees. Copy native executables out of the shared
Cargo target, chmod 555, and verify --build-info before each benchmark. Retained
native reports bind source/tree and image hashes. Local Rust is 1.98.0; Furnace
uses its private Rust 1.98.1 installation. Formatter: nightly-2026-04-15;
wasm-bindgen: 0.2.104. No system toolchain, personal browser profile, CPU server,
PyPI package or other user's process was modified.

```sh
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 cargo test --locked -p st-backend-wgpu -- --test-threads=1
cargo clippy --locked -p st-backend-wgpu --all-targets -- -D warnings
cargo build --locked --release -p st-core --features wgpu-rt,kdsl --example resident_rank_profile_bench --example resident_rank_adaptation_bench
cargo build --locked --release -p spiraltorch-wasm --target wasm32-unknown-unknown --features webgpu
wasm-bindgen --target web --out-dir WEB_CANDIDATE TARGET/wasm32-unknown-unknown/release/spiraltorch_wasm.wasm
node bindings/st-wasm/tests/resident_types.cjs WEB_CANDIDATE/spiraltorch_wasm.d.ts
maturin build --locked --release --manifest-path bindings/st-py/Cargo.toml --features wgpu-rt --interpreter PRIVATE_PYTHON --out WHEELS
PRIVATE_PYTHON -I -m pip install --force-reinstall --no-deps WHEEL
SPIRALTORCH_RUN_WGPU_RUNTIME_TESTS=1 SPIRALTORCH_RUN_WGPU_TIMESTAMP_TESTS=1 PRIVATE_PYTHON -I -m pytest --import-mode=importlib -q bindings/st-py/tests/test_wgpu_rank.py bindings/st-py/tests/test_wgpu_resident.py bindings/st-py/tests/test_spiralk_rank_tile.py bindings/st-py/tests/test_resident_rank_adaptation.py bindings/st-py/tests/test_wgpu_rank_reports.py bindings/st-py/tests/test_wgpu_rank_profile.py
```

## Frozen-product measurements

No GPU jobs overlapped, including across hosts. Each native GPU process ended
before the same harness started CUDA. Browser timing did not overlap a local
build. The existing Furnace CPU llama-server was not changed. The native pair
is baseline then candidate, not a second A-B-B-A study.

```sh
python tools/bench_resident_rank_adaptation_vs_torch.py --executable COPIED_EXECUTABLE --output NEW_NATIVE_JSON
python -I run_profile_probe.py --repo CANDIDATE_REPO --executable COPIED_PROFILE_EXECUTABLE --output stage-probe-b7999e8f.json
node tools/test_resident_browser.cjs WEB_CANDIDATE CHROME browser-profile-b7999e8f.json '' '' '' '' rank-profile
node tools/test_resident_browser.cjs WEB_CANDIDATE CHROME browser-matched-b7999e8f.json '' '' '' '' rank-matched WEB_BASELINE
PRIVATE_PYTHON -I capture_products.py --repo CANDIDATE_REPO --wheel WHEEL --web WEB_CANDIDATE --baseline-web WEB_BASELINE --output products-b7999e8f.json
```

The product capture verifies the installed extension against the wheel's bytes.
Build logs and the clean source snapshot attribute Python/WASM source; they are
not an embedded Git attestation. Browser reports hash every served asset.
Large generated products are excluded from the compact archive.

## Offline recomputation

```sh
python -I analyze_review.py --repo REPO_CONTAINING_THE_HARNESS --output NEW_SUMMARY_JSON
```

This checks canonical outputs, source/build binding, all real Rust feedback
receipts, browser pairing/product identity, actual fault-injection rejection,
lossless GPU ticks, stage sums and retained test-log markers. Performance claims
remain limited to the original speedup study; this pair is a regression control.
